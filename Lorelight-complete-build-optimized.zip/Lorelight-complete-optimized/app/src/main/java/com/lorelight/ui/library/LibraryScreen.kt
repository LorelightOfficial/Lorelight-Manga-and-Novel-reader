package com.lorelight.ui.library

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.ui.graphics.Shadow
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalDensity
import kotlin.math.absoluteValue
import androidx.compose.ui.window.Dialog
import com.lorelight.R
import androidx.compose.ui.res.stringResource
import com.lorelight.core.getSafeBoolean
import com.lorelight.core.getSafeFloat
import com.lorelight.core.getSafeInt
import com.lorelight.crawler.CrawlerEngine
import com.lorelight.data.local.NovelPreferences
import com.lorelight.data.repository.LibraryRepository
import com.lorelight.data.model.Novel
import com.lorelight.ui.components.LibraryCoverImage
import com.lorelight.ui.components.NovelCoverImage
import com.lorelight.ui.reader.ReaderViewModel
import com.lorelight.ui.theme.*
import com.lorelight.utils.EpubExtractor
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import androidx.compose.ui.semantics.Role

private val Novel.isManga: Boolean get() = pluginId?.let { com.lorelight.manga.util.MangaNamingUtils.isMangaPluginId(it) } == true

fun formatLastReadTime(timestamp: Long): String =
    NovelPreferences.formatLastReadTime(timestamp)

private fun formatLastReadTimeUnusedLegacy(timestamp: Long): String {
    val now = System.currentTimeMillis()
    val sdfTime = SimpleDateFormat("h:mm a", Locale.US)
    val sdfFull = SimpleDateFormat("d MMMM h:mm a", Locale.US)
    
    val cal1 = Calendar.getInstance()
    cal1.timeInMillis = now
    val cal2 = Calendar.getInstance()
    cal2.timeInMillis = timestamp
    
    val isSameDay = cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                    cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
                    
    cal1.add(Calendar.DAY_OF_YEAR, -1)
    val isYesterday = cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                      cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
                      
    return when {
        isSameDay -> "Today, ${sdfTime.format(Date(timestamp))}"
        isYesterday -> "Yesterday, ${sdfTime.format(Date(timestamp))}"
        else -> sdfFull.format(Date(timestamp))
    }
}

fun getFileName(context: Context, uri: Uri): String {
    var result: String? = null
    if (uri.scheme == "content") {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        try {
            if (cursor != null && cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index != -1) {
                    result = cursor.getString(index)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            cursor?.close()
        }
    }
    if (result == null) {
        result = uri.path
        val cut = result?.lastIndexOf('/')
        if (cut != null && cut != -1) {
            result = result.substring(cut + 1)
        }
    }
    return result ?: context.getString(R.string.library_unknown_novel)
}

@Composable
fun LibraryScreen(
    currentNovel: Novel?,
    importedNovels: List<Novel>,
    onCurrentNovelChange: (Novel?) -> Unit,
    onImportedNovelsChange: (List<Novel>) -> Unit,
    onSelectNovelForDetails: (Novel) -> Unit,
    onReadCurrent: () -> Unit = {},
    readerViewModel: ReaderViewModel,
    heroImageRes: Int = R.drawable.darklibrarygreen,
    libraryLoaded: Boolean = true,
    pendingEpubUri: Uri? = null,
    onPendingEpubHandled: () -> Unit = {}
) {
    val context = LocalContext.current
    val isPlaying by readerViewModel.isPlaying.collectAsState()
    val activeNovel by readerViewModel.activeNovel.collectAsState()

    var ttsSessionShown by remember(activeNovel?.id) { mutableStateOf(false) }
    LaunchedEffect(activeNovel?.id, isPlaying) {
        if (isPlaying) ttsSessionShown = true
        val an = activeNovel
        if (an != null && !an.isManga) {
            LibraryRepository.setLastMode(context, an.id, isPlaying || ttsSessionShown)
        }
    }
    val activeChapterIndex by readerViewModel.activeChapterIndex.collectAsState()
    val chapters by readerViewModel.chapters.collectAsState()
    // FIX C15: the library screen was the ONLY user of the orphan
    // "lorelight_settings" file, so shelf layout, sort mode, media filter and
    // source filter lived outside backup/restore and outside every other
    // settings read. AppPrefs returns the canonical store and folds the old
    // file's keys in exactly once.
    val settingsVersion by com.lorelight.data.local.AppSettingsSignal.version.collectAsState()
    val sharedPrefs = remember(context, settingsVersion) { com.lorelight.data.local.AppPrefs.get(context) }
    
    var isManageMode by remember { mutableStateOf(false) }
    var selectedNovelTitles by remember { mutableStateOf(setOf<String>()) }
    var showEditDialog by remember { mutableStateOf(false) }
    var showMigrateDialog by remember { mutableStateOf(false) }
    if (showMigrateDialog) {
        val migrateTargets = importedNovels.filter { it.title in selectedNovelTitles }
        com.lorelight.browse.migrate.MigrateSourceDialog(
            novels = migrateTargets,
            onDismiss = { showMigrateDialog = false },
            onApplied = { migrated ->
                if (migrated.isNotEmpty()) {
                    val byId = migrated.associateBy { it.id }
                    onImportedNovelsChange(importedNovels.map { byId[it.id] ?: it })
                }
                showMigrateDialog = false
                selectedNovelTitles = emptySet()
                isManageMode = false
            }
        )
    }
    
    var bookshelfCoverScale by remember(settingsVersion) {
        val scale = sharedPrefs.getSafeFloat("bookshelf_cover_scale", 1.0f)
        mutableStateOf(scale)
    }
    var bookshelfRows by remember(settingsVersion) {
        val rows = sharedPrefs.getSafeInt("bookshelf_rows", 2)
        mutableStateOf(rows.coerceIn(1, 3))
    }
    var bookshelfBookDesign by remember(settingsVersion) {
        val enabled = sharedPrefs.getSafeBoolean("bookshelf_book_design", true)
        mutableStateOf(enabled)
    }
    var bookshelfShelfDesign by remember(settingsVersion) {
        val enabled = sharedPrefs.getSafeBoolean("bookshelf_shelf_design", true)
        mutableStateOf(enabled)
    }
    var bookshelfMixMedia by remember(settingsVersion) {
        val mix = sharedPrefs.getSafeBoolean("bookshelf_mix_media", false)
        mutableStateOf(mix)
    }
    // S8: stored values are now stable lowercase constants ("novels" / "manga").
    // Old installs may have title-cased values from before this change; we
    // normalize on read so the migration is silent and needs no data wipe.
    var libraryMediaFilter by remember(settingsVersion) {
        mutableStateOf(
            when (sharedPrefs.getString("library_media_filter", "novels") ?: "novels") {
                "Novels", "novels" -> "novels"
                "Manga",  "manga"  -> "manga"
                else                 -> "novels"
            }
        )
    }
    LaunchedEffect(importedNovels) {
        if (importedNovels.isNotEmpty()) {
            val hasManga = importedNovels.any { it.isManga }
            val hasNovel = importedNovels.any { !it.isManga }
            if (hasManga && !hasNovel) {
                if (libraryMediaFilter != "manga") libraryMediaFilter = "manga"
            } else if (hasNovel && !hasManga) {
                if (libraryMediaFilter != "novels") libraryMediaFilter = "novels"
            }
        }
    }
    var isEpubLoading by remember { mutableStateOf(false) }

    // Library sort & filter state
    var librarySortMode by remember(settingsVersion) { mutableStateOf(sharedPrefs.getString("library_sort_mode", "Last read") ?: "Last read") }
    var librarySourceFilter by remember(settingsVersion) { mutableStateOf(sharedPrefs.getString("library_source_filter", "All") ?: "All") }
    var showSortMenu by remember { mutableStateOf(false) }
    val displayedNovels = remember(importedNovels, librarySortMode, librarySourceFilter, libraryMediaFilter, bookshelfMixMedia) {
        importedNovels
            .filter { novel ->
                if (bookshelfMixMedia) {
                    true
                } else if (libraryMediaFilter == "manga") {
                    novel.isManga
                } else {
                    !novel.isManga
                }
            }
            .filter { novel ->
                when (librarySourceFilter) {
                    "Online" -> novel.isOnline
                    "Local" -> !novel.isOnline
                    else -> true
                }
            }
            .let { list ->
                when (librarySortMode) {
                    "Title (A-Z)" -> list.sortedBy { it.title.lowercase() }
                    "Recently added" -> list.sortedByDescending { it.dateAdded }
                    else -> list.sortedByDescending { it.lastReadTimestamp }
                }
            }
    }
    
    val gridState = rememberLazyGridState()
    val listState = rememberLazyListState()
    
    LaunchedEffect(bookshelfCoverScale, bookshelfRows, bookshelfBookDesign, bookshelfShelfDesign, bookshelfMixMedia) {
        sharedPrefs.edit()
            .putFloat("bookshelf_cover_scale", bookshelfCoverScale)
            .putInt("bookshelf_rows", bookshelfRows)
            .putBoolean("bookshelf_book_design", bookshelfBookDesign)
            .putBoolean("bookshelf_shelf_design", bookshelfShelfDesign)
            .putBoolean("bookshelf_mix_media", bookshelfMixMedia)
            .apply()
    }
    
    LaunchedEffect(Unit) {
        if (CoverFetchSession.done) return@LaunchedEffect
        CoverFetchSession.done = true
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val current = importedNovels
            var changed = false
            val updated = current.map { novel ->
                val cover = novel.coverImageBase64
                if (!cover.isNullOrEmpty() && (cover.startsWith("http://") || cover.startsWith("https://"))) {
                    try {
                        val bytes = org.jsoup.Jsoup.connect(cover)
                            .ignoreContentType(true)
                            .userAgent("Mozilla/5.0")
                            .timeout(12000)
                            .execute()
                            .bodyAsBytes()
                        val path = if (bytes != null && bytes.isNotEmpty())
                            com.lorelight.data.local.CoverStorage.saveCoverBytes(context, novel.id, bytes) else null
                        if (path != null) { changed = true; novel.copy(coverImageBase64 = path) } else novel
                    } catch (e: Exception) { novel }
                } else novel
            }
            if (changed) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    onImportedNovelsChange(updated)
                }
            }
        }
    }
    
    val coroutineScope = rememberCoroutineScope()

    var editedTitle by remember(selectedNovelTitles.firstOrNull()) {
        mutableStateOf("")
    }
    var editedCoverBase64 by remember(selectedNovelTitles.firstOrNull()) {
        mutableStateOf<String?>(null)
    }
    
    val targetNovel = remember(showEditDialog, selectedNovelTitles.firstOrNull()) {
        importedNovels.find { it.title == selectedNovelTitles.firstOrNull() }
    }
    
    LaunchedEffect(targetNovel) {
        if (targetNovel != null) {
            editedTitle = targetNovel.title
            editedCoverBase64 = targetNovel.coverImageBase64
        }
    }
    
    val coverPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    val inputStream = context.contentResolver.openInputStream(uri)
                    val bytes = inputStream?.readBytes()
                    inputStream?.close()
                    if (bytes != null) {
                        val base64Str = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                        editedCoverBase64 = base64Str
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(context, context.getString(R.string.library_toast_cover_load_failed), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    // Single import path, shared by the in-app picker and external triggers.
    suspend fun importEpubFromUri(uri: Uri, fromExternalApp: Boolean = false) {
        isEpubLoading = true
        try {
            val fileName = getFileName(context, uri)
            if (!fileName.endsWith(".epub", ignoreCase = true) && !fromExternalApp) {
                Toast.makeText(context, context.getString(R.string.library_toast_select_epub), Toast.LENGTH_LONG).show()
                isEpubLoading = false
                return
            }
            
            val result = com.lorelight.service.NovelImportManager.importEpub(context, uri)
            when (result) {
                is com.lorelight.service.EpubImportResult.Success -> {
                    val novel = result.novel
                    val freshNovels = LibraryRepository.loadLibrary(context)
                    onImportedNovelsChange(freshNovels)
                    onCurrentNovelChange(novel)
                    onSelectNovelForDetails(novel)
                    val firstChapter = novel.chapters.firstOrNull() ?: novel.currentChapter
                    readerViewModel.startReading(novel, firstChapter)
                    onReadCurrent()
                    Toast.makeText(
                        context,
                        if (result.isNew) "Successfully imported \u201C${novel.title}\u201D" else "Opened \u201C${novel.title}\u201D",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                is com.lorelight.service.EpubImportResult.Error -> {
                    Toast.makeText(context, result.message, Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to import EPUB: ${e.localizedMessage ?: e.message}", Toast.LENGTH_LONG).show()
        } finally {
            isEpubLoading = false
        }
    }

    val epubLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch { importEpubFromUri(uri) }
        }
    }

    // S6: Command Palette "Import EPUB" command. EpubImportTrigger.requestLaunch
    // is set to true by the palette action; we observe it here because the
    // launcher must live in a Composable scope. Same one-shot pattern as the
    // CommandPaletteTrigger used to open the palette itself.
    LaunchedEffect(com.lorelight.ui.components.EpubImportTrigger.requestLaunch) {
        if (com.lorelight.ui.components.EpubImportTrigger.requestLaunch) {
            com.lorelight.ui.components.EpubImportTrigger.requestLaunch = false
            try {
                epubLauncher.launch("application/epub+zip")
            } catch (_: Exception) {
                epubLauncher.launch("*/*")
            }
        }
    }

    // "Open with Lorelight" / share-sheet hand-off is owned solely by MainActivity.
    // This screen must NOT import it as well - running both importers in parallel
    // raced on the extracted epub file and the saved novel list, which is what made
    // books occasionally not land in the library and made a successful import still
    // report "failed". The in-app picker below is the only import this screen starts.

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        val configuration = androidx.compose.ui.platform.LocalConfiguration.current
        val isTablet = configuration.screenWidthDp >= 600
        val heroHeight = if (isTablet) 240.dp else 280.dp

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 680.dp)
                .height(heroHeight)
        ) {
            Image(
                painter = painterResource(id = heroImageRes),
                contentDescription = stringResource(R.string.library_hero_banner_desc),
                contentScale = ContentScale.Crop,
                // TOP-CROP FIX (tablets only). Crop defaulted to centering,
                // which cropped the top and bottom evenly. Aligning to
                // TopCenter on tablets keeps the top edge of the banner art
                // always fully visible, matching the Details screen's hero
                // banner fix. Phones keep the original center crop (previous
                // mobile hero banner setting).
                alignment = if (isTablet) Alignment.TopCenter else Alignment.Center,
                modifier = Modifier.fillMaxSize()
            )
            
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colorStops = arrayOf(
                                0.0f to Color.Transparent,
                                0.45f to Color.Transparent,
                                0.85f to MaterialTheme.colorScheme.background,
                                1.0f to MaterialTheme.colorScheme.background
                            )
                        )
                    )
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clipToBounds()
            ) {
                val appThemeName by readerViewModel.appTheme.collectAsState()
                WindAndFirefliesBackground(
                    themeName = appThemeName,
                    primaryColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.matchParentSize()
                )

                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 32.dp)
                            .height(48.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.library_title),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = MaterialTheme.typography.headlineLarge.fontFamily,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Glass, matching the source-page buttons and the
                            // bottom nav panes rather than a flat filled pill.
                            com.lorelight.ui.theme.GlassPanel(
                                cornerRadius = 12.dp,
                                tintAlpha = 0.65f,
                                modifier = Modifier
                                    .clickable(role = Role.Button) {
                                        try {
                                            epubLauncher.launch("application/epub+zip")
                                        } catch (e: Exception) {
                                            epubLauncher.launch("*/*")
                                        }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.MenuBook,
                                        contentDescription = stringResource(R.string.library_import_desc),
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = stringResource(R.string.library_import_label),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
 
                    Spacer(modifier = Modifier.height(100.dp))
                }
            }

            // TABLET PUSH-DOWN FIX. On tablets, push this whole section (the
            // Continue Reading / audio card) - and, because layout below is
            // strictly sequential, everything that follows it too - down by
            // an amount equal to the section's OWN measured height. The
            // height is measured on the inner box below (before any extra
            // padding is added), then applied as top padding on this outer
            // box, so there's no feedback loop. Phones are unaffected.
            val continueSectionDensity = LocalDensity.current
            var continueSectionHeightPx by remember { mutableStateOf(0) }
            val continueSectionPushDown = if (isTablet) {
                with(continueSectionDensity) { continueSectionHeightPx.toDp() }
            } else {
                0.dp
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = continueSectionPushDown)
            ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .onSizeChanged { continueSectionHeightPx = it.height }
            ) {
                val actNovel = activeNovel
                val showAudioCard = actNovel != null &&
                    !actNovel.isManga &&
                    (isPlaying || ttsSessionShown)
                if (actNovel != null && showAudioCard) {
                    AudioControllerCard(
                        novel = actNovel,
                        isPlaying = isPlaying,
                        onPlayPause = { readerViewModel.togglePlayPause() },
                        onSkipBackward = { readerViewModel.skipBackward() },
                        onSkipForward = { readerViewModel.skipForward() },
                        onPrevChapter = {
                            if (activeChapterIndex > 0) {
                                readerViewModel.selectChapter(activeChapterIndex - 1)
                            }
                        },
                        onNextChapter = {
                            if (activeChapterIndex < chapters.size - 1) {
                                readerViewModel.selectChapter(activeChapterIndex + 1)
                            }
                        },
                        hasPrevChapter = activeChapterIndex > 0,
                        hasNextChapter = activeChapterIndex < chapters.size - 1,
                        onStop = {
                            readerViewModel.stopSpeaking()
                            ttsSessionShown = false
                        },
                        onCardClick = {
                            onCurrentNovelChange(actNovel)
                            onReadCurrent()
                        }
                    )
                } else {
                    val resumeNovel = remember(currentNovel, importedNovels, isPlaying, ttsSessionShown) {
                        val cur = currentNovel
                        if (cur != null) importedNovels.firstOrNull { it.id == cur.id } ?: cur
                        else LibraryRepository.pickResumeEntry(importedNovels)
                    }
                    val resumeIsManga = resumeNovel?.isManga == true
                    ContinueReadingCard(
                        novel = resumeNovel,
                        isManga = resumeIsManga,
                        showPlayButton = !resumeIsManga,
                        onReadClick = {
                            resumeNovel?.let {
                                onCurrentNovelChange(it)
                                LibraryRepository.setLastMode(context, it.id, false)
                                onReadCurrent()
                            }
                        },
                        onPlayTtsClick = {
                            resumeNovel?.let {
                                onCurrentNovelChange(it)
                                LibraryRepository.setLastMode(context, it.id, true)
                                readerViewModel.startReadingAndPlay(it)
                            }
                        }
                    )
                }
            }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
            Column(modifier = Modifier.fillMaxSize()) {
            Spacer(modifier = Modifier.height(12.dp))

            if (isManageMode) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f, fill = false),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(onClick = { 
                            isManageMode = false
                            selectedNovelTitles = emptySet()
                        }) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = stringResource(R.string.action_cancel),
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = "${selectedNovelTitles.size} Selected",
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (importedNovels.isNotEmpty()) {
                            val allSel = selectedNovelTitles.size == importedNovels.size
                            TextButton(
                                onClick = {
                                    selectedNovelTitles = if (allSel) emptySet() else importedNovels.map { it.title }.toSet()
                                }
                            ) {
                                Text(
                                    text = if (allSel) stringResource(R.string.library_deselect_all) else stringResource(R.string.library_select_all),
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        
                        if (selectedNovelTitles.size == 1) {
                            IconButton(onClick = { showEditDialog = true }) {
                                Icon(
                                    imageVector = Icons.Filled.Edit,
                                    contentDescription = stringResource(R.string.library_edit_novel_desc),
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        if (selectedNovelTitles.isNotEmpty()) {
                            IconButton(onClick = { showMigrateDialog = true }) {
                                Icon(
                                    imageVector = Icons.Filled.SwapHoriz,
                                    contentDescription = stringResource(R.string.library_transfer_source_desc),
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        
                        if (selectedNovelTitles.isNotEmpty()) {
                            IconButton(onClick = {
                                val selectedNovels = importedNovels.filter { it.title in selectedNovelTitles }
                                selectedNovels.forEach { novelToRemove ->
                                    com.lorelight.data.local.NovelRemovalManager.removeNovelFromLibrary(context, novelToRemove)
                                }
                                val remainingNovels = importedNovels.filter { it.title !in selectedNovelTitles }
                                onImportedNovelsChange(remainingNovels)
                                if (currentNovel != null && currentNovel.title in selectedNovelTitles) {
                                    onCurrentNovelChange(LibraryRepository.pickResumeEntry(remainingNovels))
                                }
                                selectedNovelTitles = emptySet()
                                isManageMode = false
                            }) {
                                Icon(
                                    imageVector = Icons.Filled.Delete,
                                    contentDescription = stringResource(R.string.library_delete_novels_desc),
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.library_my_bookshelf),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = MaterialTheme.typography.headlineLarge.fontFamily,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        if (!bookshelfMixMedia) {
                            // Was a hand-rolled pill pair that swapped colour
                            // instantly. Now the shared animated control, so
                            // the highlight slides here exactly like it does in
                            // the bottom bar and on the browse tabs.
                            // S8: use the value/label overload so display labels
                            // are string resources (translatable) and stored
                            // constants stay stable across locale changes.
                            com.lorelight.ui.components.LorelightSegmentedControl(
                                options = listOf(
                                    "novels" to androidx.compose.ui.res.stringResource(R.string.library_filter_novels),
                                    "manga"  to androidx.compose.ui.res.stringResource(R.string.library_filter_manga)
                                ),
                                selected = libraryMediaFilter,
                                onSelect = { value ->
                                    libraryMediaFilter = value
                                    sharedPrefs.edit().putString("library_media_filter", value).apply()
                                },
                                modifier = Modifier.width(146.dp),
                                height = 30.dp,
                                cornerRadius = 15.dp,
                                fontSize = 11.sp
                            )
                        }
                    }
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box {
                            // Plain icon buttons by request. The glass pane made
                            // these two read as heavy chips on the bookshelf row.
                            IconButton(onClick = { showSortMenu = true }) {
                                Icon(
                                    imageVector = Icons.Filled.Tune,
                                    contentDescription = stringResource(R.string.library_sort_filter_desc),
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            GlassDropdownMenu(
                                expanded = showSortMenu,
                                onDismissRequest = { showSortMenu = false },
                            ) {
                                Text(stringResource(R.string.library_sort_by_label), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                                listOf("Last read", "Title (A-Z)", "Recently added").forEach { opt ->
                                    DropdownMenuItem(
                                        text = { Text(if (librarySortMode == opt) "${librarySortLabel(opt)}  ✓" else librarySortLabel(opt), color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp) },
                                        onClick = {
                                            librarySortMode = opt
                                            sharedPrefs.edit().putString("library_sort_mode", opt).apply()
                                            showSortMenu = false
                                        }
                                    )
                                }
                                HorizontalDivider()
                                Text(stringResource(R.string.library_show_label), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                                listOf("All", "Online", "Local").forEach { opt ->
                                    DropdownMenuItem(
                                        text = { Text(if (librarySourceFilter == opt) "${librarySourceLabel(opt)}  ✓" else librarySourceLabel(opt), color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp) },
                                        onClick = {
                                            librarySourceFilter = opt
                                            sharedPrefs.edit().putString("library_source_filter", opt).apply()
                                            showSortMenu = false
                                        }
                                    )
                                }
                            }
                        }

                        Box {
                            var showThreeDotMenu by remember { mutableStateOf(false) }
                            var showDisplayDialog by remember { mutableStateOf(false) }
                            
                            IconButton(onClick = { showThreeDotMenu = true }) {
                                Icon(
                                    imageVector = Icons.Filled.MoreVert,
                                    contentDescription = stringResource(R.string.library_bookshelf_options_desc),
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            
                            GlassDropdownMenu(
                                expanded = showThreeDotMenu,
                                onDismissRequest = { showThreeDotMenu = false },
                            ) {
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.library_display_settings), color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp) },
                                    onClick = {
                                        showThreeDotMenu = false
                                        showDisplayDialog = true
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.library_edit_manage_novels), color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp) },
                                    onClick = {
                                        showThreeDotMenu = false
                                        isManageMode = true
                                        selectedNovelTitles = emptySet()
                                    }
                                )
                            }
                            
                            BookshelfDisplaySettingsDialog(
                                showDialog = showDisplayDialog,
                                bookshelfCoverScale = bookshelfCoverScale,
                                onBookshelfCoverScaleChange = { bookshelfCoverScale = it },
                                bookshelfRows = bookshelfRows,
                                onBookshelfRowsChange = { bookshelfRows = it },
                                bookDesignEnabled = bookshelfBookDesign,
                                onBookDesignChange = { bookshelfBookDesign = it },
                                shelfDesignEnabled = bookshelfShelfDesign,
                                onShelfDesignChange = { bookshelfShelfDesign = it },
                                mixMangaAndNovels = bookshelfMixMedia,
                                onMixMangaAndNovelsChange = { bookshelfMixMedia = it },
                                onDismissRequest = { showDisplayDialog = false }
                            )
                        }
                    }
                }
            }

            val animOffsetY = remember { androidx.compose.animation.core.Animatable(40f) }
            val animAlpha = remember { androidx.compose.animation.core.Animatable(0f) }

            LaunchedEffect(libraryMediaFilter, librarySourceFilter, librarySortMode, libraryLoaded) {
                animOffsetY.snapTo(40f)
                animAlpha.snapTo(0f)
                launch {
                    animOffsetY.animateTo(
                        targetValue = 0f,
                        animationSpec = androidx.compose.animation.core.tween(
                            durationMillis = 350,
                            easing = androidx.compose.animation.core.FastOutSlowInEasing
                        )
                    )
                }
                launch {
                    animAlpha.animateTo(
                        targetValue = 1f,
                        animationSpec = androidx.compose.animation.core.tween(
                            durationMillis = 300
                        )
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .graphicsLayer {
                        translationY = animOffsetY.value
                        alpha = animAlpha.value
                    }
            ) {
                BookGrid(
                    importedNovels = displayedNovels,
                    currentNovel = currentNovel,
                    isManageMode = isManageMode,
                    selectedNovelTitles = selectedNovelTitles,
                    bookshelfCoverScale = bookshelfCoverScale,
                    bookshelfRows = bookshelfRows,
                    bookDesign = bookshelfBookDesign,
                    shelfDesign = bookshelfShelfDesign,
                    gridState = gridState,
                    libraryLoaded = libraryLoaded,
                    modifier = Modifier.fillMaxSize(),
                    onNovelSelect = { novel ->
                        if (isManageMode) {
                            selectedNovelTitles = if (novel.title in selectedNovelTitles) {
                                selectedNovelTitles - novel.title
                            } else {
                                selectedNovelTitles + novel.title
                            }
                        } else {
                            onSelectNovelForDetails(novel)
                        }
                    },
                    onNovelLongPress = { novel ->
                        if (!isManageMode) {
                            isManageMode = true
                            selectedNovelTitles = setOf(novel.title)
                        }
                    }
                )
            }
            }
            }
        }
    }

    BookEditDetailsDialog(
        showDialog = showEditDialog,
        targetNovel = targetNovel,
        importedNovels = importedNovels,
        currentNovel = currentNovel,
        editedTitle = editedTitle,
        onEditedTitleChange = { editedTitle = it },
        editedCoverBase64 = editedCoverBase64,
        onCoverPickerLaunch = { coverPickerLauncher.launch("image/*") },
        onImportedNovelsChange = onImportedNovelsChange,
        onCurrentNovelChange = onCurrentNovelChange,
        onDismissRequest = { showEditDialog = false },
        onSuccess = {
            selectedNovelTitles = emptySet()
            showEditDialog = false
            isManageMode = false
        }
    )
}

// Runs the online-cover migration at most once per app process.
private object CoverFetchSession {
    @Volatile var done = false
}
