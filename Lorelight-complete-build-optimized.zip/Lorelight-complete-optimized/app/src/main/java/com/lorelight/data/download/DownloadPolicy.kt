package com.lorelight.data.download

import android.content.Context
import android.content.SharedPreferences

/**
 * S5 - SMART OFFLINE DOWNLOADS: what each title is allowed to fetch on its own.
 *
 * WHY POLICIES ARE NOT FIELDS ON `Novel`
 * `Novel` is serialised TWO ways - `toJSONObject`/`toNovel` into SharedPreferences
 * and through `NovelEntity` into Room. Seven new fields would mean editing both
 * serialisers plus a Room migration, and a mistake in either one does not
 * misplace a setting, it loses somebody's library. Policies are also a
 * different KIND of data: `Novel` describes a book, this describes a standing
 * instruction about a book. So they live in their own preferences file keyed by
 * novel id, which keeps O2's "one owner per concern" rule intact and means a
 * corrupt policy can never take the library down with it.
 *
 * DEFAULTS ARE DELIBERATELY TIMID
 * Everything is OFF until asked for, with two exceptions. `wifiOnly` and
 * `protectMarked` default to ON, because a policy fires when nobody is looking:
 * the cost of a wrong "go ahead" is somebody's data allowance or somebody's
 * annotated chapter, and the cost of a wrong "wait" is only a delay.
 */
object DownloadPolicy {

    private const val PREFS = "lorelight_download_policy"

    // Global defaults. Titles fall back to these until given their own rules.
    private const val KEY_G_KEEP_AHEAD = "g_keep_ahead"
    private const val KEY_G_AUTO_NEW = "g_auto_new_chapters"
    private const val KEY_G_WIFI_ONLY = "g_wifi_only"
    private const val KEY_G_CHARGING_ONLY = "g_charging_only"
    private const val KEY_G_CLEANUP = "g_cleanup_mode"
    private const val KEY_G_KEEP_LAST = "g_keep_last"
    private const val KEY_G_PROTECT = "g_protect_marked"
    private const val KEY_G_QUOTA_MB = "g_quota_mb"
    private const val KEY_LIBRARY_BUDGET_MB = "library_budget_mb"

    // Per-title overrides, suffixed with the novel id.
    private const val P_MANAGED = "t_managed_"
    private const val P_KEEP_AHEAD = "t_keep_ahead_"
    private const val P_AUTO_NEW = "t_auto_new_"
    private const val P_WIFI_ONLY = "t_wifi_only_"
    private const val P_CHARGING_ONLY = "t_charging_only_"
    private const val P_CLEANUP = "t_cleanup_"
    private const val P_KEEP_LAST = "t_keep_last_"
    private const val P_PROTECT = "t_protect_"
    private const val P_QUOTA_MB = "t_quota_mb_"

    // ------------------------------------------------------------ keep ahead

    /** No automatic fetching for this title. */
    const val KEEP_AHEAD_OFF = 0

    /** Everything not yet read. Sentinel rather than a huge number so the
     *  intent survives a series growing past whatever ceiling we picked. */
    const val KEEP_AHEAD_ALL_UNREAD = -1

    val KEEP_AHEAD_CHOICES = listOf(
        KEEP_AHEAD_OFF,
        3,
        5,
        10,
        KEEP_AHEAD_ALL_UNREAD
    )

    fun keepAheadLabel(value: Int): String = when (value) {
        KEEP_AHEAD_OFF -> "Off"
        KEEP_AHEAD_ALL_UNREAD -> "All unread"
        else -> "Next $value"
    }

    // --------------------------------------------------------------- cleanup

    const val CLEANUP_NEVER = "never"
    const val CLEANUP_AFTER_READING = "after_reading"
    const val CLEANUP_KEEP_LAST = "keep_last"

    val CLEANUP_CHOICES = listOf(CLEANUP_NEVER, CLEANUP_AFTER_READING, CLEANUP_KEEP_LAST)

    fun cleanupLabel(mode: String, keepLast: Int): String = when (mode) {
        CLEANUP_AFTER_READING -> "After reading"
        CLEANUP_KEEP_LAST -> "Keep last $keepLast"
        else -> "Never"
    }

    // ---------------------------------------------------------------- bounds

    const val MIN_KEEP_LAST = 1
    const val MAX_KEEP_LAST = 50

    /** 0 means no ceiling, matching how the settings UI shows "No cap". */
    const val QUOTA_UNLIMITED = 0

    // -------------------------------------------------------------- defaults

    private const val DEFAULT_KEEP_AHEAD = KEEP_AHEAD_OFF
    private const val DEFAULT_AUTO_NEW = false
    private const val DEFAULT_WIFI_ONLY = true
    private const val DEFAULT_CHARGING_ONLY = false
    private const val DEFAULT_CLEANUP = CLEANUP_NEVER
    private const val DEFAULT_KEEP_LAST = 5
    private const val DEFAULT_PROTECT = true
    private const val DEFAULT_QUOTA_MB = QUOTA_UNLIMITED
    private const val DEFAULT_LIBRARY_BUDGET_MB = 0

    // ----------------------------------------------------------------- rules

    /**
     * Every decision the scheduler needs, read in ONE shot.
     *
     * Deliberately a snapshot rather than a set of live getters, mirroring
     * `DownloadTuning.Snapshot`: a sweep reads these values several times while
     * deciding, and a settings change landing mid-decision could otherwise
     * produce a plan that matches neither the old rules nor the new ones.
     */
    data class Rules(
        val keepAhead: Int,
        val autoNewChapters: Boolean,
        val wifiOnly: Boolean,
        val chargingOnly: Boolean,
        val cleanupMode: String,
        val keepLast: Int,
        val protectMarked: Boolean,
        val quotaMb: Int,
        /** True when this title has its own rules rather than inheriting. */
        val managed: Boolean
    ) {
        /** Whether this policy asks for any automatic work at all. */
        val active: Boolean
            get() = keepAhead != KEEP_AHEAD_OFF || autoNewChapters

        /**
         * How many chapters ahead of the current one to hold.
         * Resolves the ALL_UNREAD sentinel against the real remaining count.
         */
        fun targetAhead(unreadCount: Int): Int = when (keepAhead) {
            KEEP_AHEAD_OFF -> if (autoNewChapters) 0 else 0
            KEEP_AHEAD_ALL_UNREAD -> unreadCount.coerceAtLeast(0)
            else -> keepAhead.coerceAtLeast(0)
        }
    }

    private fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- global

    fun globalRules(context: Context): Rules {
        val p = prefs(context)
        return Rules(
            keepAhead = p.getInt(KEY_G_KEEP_AHEAD, DEFAULT_KEEP_AHEAD),
            autoNewChapters = p.getBoolean(KEY_G_AUTO_NEW, DEFAULT_AUTO_NEW),
            wifiOnly = p.getBoolean(KEY_G_WIFI_ONLY, DEFAULT_WIFI_ONLY),
            chargingOnly = p.getBoolean(KEY_G_CHARGING_ONLY, DEFAULT_CHARGING_ONLY),
            cleanupMode = p.getString(KEY_G_CLEANUP, DEFAULT_CLEANUP) ?: DEFAULT_CLEANUP,
            keepLast = p.getInt(KEY_G_KEEP_LAST, DEFAULT_KEEP_LAST)
                .coerceIn(MIN_KEEP_LAST, MAX_KEEP_LAST),
            protectMarked = p.getBoolean(KEY_G_PROTECT, DEFAULT_PROTECT),
            quotaMb = p.getInt(KEY_G_QUOTA_MB, DEFAULT_QUOTA_MB).coerceAtLeast(0),
            managed = false
        )
    }

    fun setGlobalRules(context: Context, rules: Rules) {
        prefs(context).edit()
            .putInt(KEY_G_KEEP_AHEAD, rules.keepAhead)
            .putBoolean(KEY_G_AUTO_NEW, rules.autoNewChapters)
            .putBoolean(KEY_G_WIFI_ONLY, rules.wifiOnly)
            .putBoolean(KEY_G_CHARGING_ONLY, rules.chargingOnly)
            .putString(KEY_G_CLEANUP, rules.cleanupMode)
            .putInt(KEY_G_KEEP_LAST, rules.keepLast.coerceIn(MIN_KEEP_LAST, MAX_KEEP_LAST))
            .putBoolean(KEY_G_PROTECT, rules.protectMarked)
            .putInt(KEY_G_QUOTA_MB, rules.quotaMb.coerceAtLeast(0))
            .apply()
    }

    fun getLibraryBudgetMb(context: Context): Int =
        prefs(context).getInt(KEY_LIBRARY_BUDGET_MB, DEFAULT_LIBRARY_BUDGET_MB).coerceAtLeast(0)

    fun setLibraryBudgetMb(context: Context, mb: Int) {
        prefs(context).edit().putInt(KEY_LIBRARY_BUDGET_MB, mb.coerceAtLeast(0)).apply()
    }

    // ------------------------------------------------------------- per title

    /** A title is "managed" only once it has been given rules of its own. */
    fun isManaged(context: Context, novelId: String): Boolean =
        prefs(context).contains(P_MANAGED + novelId)

    /**
     * The rules in force for one title.
     *
     * Unset per-title fields fall back to the LIVE global value, not to a
     * hardcoded default, so changing a global default still reaches every title
     * that never overrode that particular field.
     */
    fun rulesFor(context: Context, novelId: String): Rules {
        val p = prefs(context)
        val g = globalRules(context)
        if (!p.contains(P_MANAGED + novelId)) return g.copy(managed = false)
        return Rules(
            keepAhead = p.getInt(P_KEEP_AHEAD + novelId, g.keepAhead),
            autoNewChapters = p.getBoolean(P_AUTO_NEW + novelId, g.autoNewChapters),
            wifiOnly = p.getBoolean(P_WIFI_ONLY + novelId, g.wifiOnly),
            chargingOnly = p.getBoolean(P_CHARGING_ONLY + novelId, g.chargingOnly),
            cleanupMode = p.getString(P_CLEANUP + novelId, g.cleanupMode) ?: g.cleanupMode,
            keepLast = p.getInt(P_KEEP_LAST + novelId, g.keepLast)
                .coerceIn(MIN_KEEP_LAST, MAX_KEEP_LAST),
            protectMarked = p.getBoolean(P_PROTECT + novelId, g.protectMarked),
            quotaMb = p.getInt(P_QUOTA_MB + novelId, g.quotaMb).coerceAtLeast(0),
            managed = true
        )
    }

    fun setRulesFor(context: Context, novelId: String, rules: Rules) {
        prefs(context).edit()
            .putBoolean(P_MANAGED + novelId, true)
            .putInt(P_KEEP_AHEAD + novelId, rules.keepAhead)
            .putBoolean(P_AUTO_NEW + novelId, rules.autoNewChapters)
            .putBoolean(P_WIFI_ONLY + novelId, rules.wifiOnly)
            .putBoolean(P_CHARGING_ONLY + novelId, rules.chargingOnly)
            .putString(P_CLEANUP + novelId, rules.cleanupMode)
            .putInt(P_KEEP_LAST + novelId, rules.keepLast.coerceIn(MIN_KEEP_LAST, MAX_KEEP_LAST))
            .putBoolean(P_PROTECT + novelId, rules.protectMarked)
            .putInt(P_QUOTA_MB + novelId, rules.quotaMb.coerceAtLeast(0))
            .apply()
    }

    /** Shortcut for the common one-tap case from a title's own screen. */
    fun setKeepAhead(context: Context, novelId: String, value: Int) {
        setRulesFor(context, novelId, rulesFor(context, novelId).copy(keepAhead = value))
    }

    fun setAutoNewChapters(context: Context, novelId: String, enabled: Boolean) {
        setRulesFor(context, novelId, rulesFor(context, novelId).copy(autoNewChapters = enabled))
    }

    /**
     * Hands a title back to the global defaults.
     *
     * REMOVES the keys rather than writing today's globals into them, so a
     * later change to a global default still reaches this title. Writing the
     * values back would silently freeze it at whatever the defaults happened to
     * be at the moment somebody pressed "Use defaults".
     */
    fun clearRulesFor(context: Context, novelId: String) {
        prefs(context).edit()
            .remove(P_MANAGED + novelId)
            .remove(P_KEEP_AHEAD + novelId)
            .remove(P_AUTO_NEW + novelId)
            .remove(P_WIFI_ONLY + novelId)
            .remove(P_CHARGING_ONLY + novelId)
            .remove(P_CLEANUP + novelId)
            .remove(P_KEEP_LAST + novelId)
            .remove(P_PROTECT + novelId)
            .remove(P_QUOTA_MB + novelId)
            .apply()
    }

    /** Ids of every title carrying its own rules, for the Managed list. */
    fun managedNovelIds(context: Context): List<String> =
        prefs(context).all.keys
            .filter { it.startsWith(P_MANAGED) }
            .map { it.removePrefix(P_MANAGED) }
            .filter { it.isNotEmpty() }
}
