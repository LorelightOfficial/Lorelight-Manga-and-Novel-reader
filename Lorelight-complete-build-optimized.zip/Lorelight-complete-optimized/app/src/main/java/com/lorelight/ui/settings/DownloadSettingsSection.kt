package com.lorelight.ui.settings

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.data.download.DownloadPolicy
import com.lorelight.data.download.DownloadTuning
import com.lorelight.manga.download.MangaOcrCache

/**
 * Download & tuning settings — full redesign from scratch.
 *
 * Three visual presets rendered as tap cards, numeric knobs
 * with proper +/\u2212 pill controls, chip rows for fixed-option
 * pickers, and toggle cards for the binary settings.
 * All DownloadTuning / DownloadPolicy / MangaOcrCache wiring
 * is preserved exactly.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DownloadSettingsSection() {
    val context = LocalContext.current

    var preset           by remember { mutableStateOf(DownloadTuning.getPreset(context)) }
    var parallelChapters by remember { mutableStateOf(DownloadTuning.getParallelChapters(context)) }
    var parallelPages    by remember { mutableStateOf(DownloadTuning.getParallelPages(context)) }
    var chapterDelay     by remember { mutableStateOf(DownloadTuning.getChapterDelayMs(context)) }
    var pageDelay        by remember { mutableStateOf(DownloadTuning.getPageDelayMs(context)) }
    var retries          by remember { mutableStateOf(DownloadTuning.getRetryAttempts(context)) }
    var speedKbps        by remember { mutableStateOf(DownloadTuning.getSpeedLimitKbps(context)) }
    var wifiOnly         by remember { mutableStateOf(DownloadTuning.isWifiOnly(context)) }
    var verifyPass       by remember { mutableStateOf(DownloadTuning.isVerifyPassEnabled(context)) }
    var ocrOnDownload    by remember { mutableStateOf(MangaOcrCache.isOcrOnDownloadEnabled(context)) }
    var globalKeepAhead  by remember { mutableStateOf(DownloadPolicy.globalRules(context).keepAhead) }
    var libraryBudget    by remember { mutableStateOf(DownloadPolicy.getLibraryBudgetMb(context)) }

    val reload: () -> Unit = {
        preset           = DownloadTuning.getPreset(context)
        parallelChapters = DownloadTuning.getParallelChapters(context)
        parallelPages    = DownloadTuning.getParallelPages(context)
        chapterDelay     = DownloadTuning.getChapterDelayMs(context)
        pageDelay        = DownloadTuning.getPageDelayMs(context)
        retries          = DownloadTuning.getRetryAttempts(context)
        speedKbps        = DownloadTuning.getSpeedLimitKbps(context)
        wifiOnly         = DownloadTuning.isWifiOnly(context)
        verifyPass       = DownloadTuning.isVerifyPassEnabled(context)
    }

    SettingsGroup(title = "Download tuning") {

        // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 1. SPEED PRESETS \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
        DlSectionLabel(
            "Speed preset",
            "Applies all knobs below at once. Going custom doesn\u2019t change a preset until you tap one of them."
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            PresetCard(
                id     = DownloadTuning.PRESET_GENTLE,
                active = preset,
                icon   = Icons.Default.Download,
                label  = "Gentle",
                desc   = "One at a time, long pauses",
                modifier = Modifier.weight(1f)
            ) {
                DownloadTuning.applyPreset(context, DownloadTuning.PRESET_GENTLE)
                reload()
            }
            PresetCard(
                id     = DownloadTuning.PRESET_BALANCED,
                active = preset,
                icon   = Icons.Default.Speed,
                label  = "Balanced",
                desc   = "Recommended default",
                modifier = Modifier.weight(1f)
            ) {
                DownloadTuning.applyPreset(context, DownloadTuning.PRESET_BALANCED)
                reload()
            }
            PresetCard(
                id     = DownloadTuning.PRESET_TURBO,
                active = preset,
                icon   = Icons.Default.FastForward,
                label  = "Turbo",
                desc   = "Max speed, no pauses",
                modifier = Modifier.weight(1f)
            ) {
                DownloadTuning.applyPreset(context, DownloadTuning.PRESET_TURBO)
                reload()
            }
        }
        if (preset == DownloadTuning.PRESET_CUSTOM) {
            Text(
                "\u2713 Custom values active",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 2.dp)
            )
        }

        SettingsRowDivider()

        // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 2. PARALLELISM \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
        DlSectionLabel("Parallelism", "How many things download at the same time.")

        DlKnobRow(
            label    = "Novel chapters at once",
            note     = "Each chapter = one request. Overlap them to hide round-trip latency.",
            value    = parallelChapters,
            min      = DownloadTuning.MIN_PARALLEL_CHAPTERS,
            max      = DownloadTuning.MAX_PARALLEL_CHAPTERS,
            onChange = {
                DownloadTuning.setParallelChapters(context, it)
                parallelChapters = DownloadTuning.getParallelChapters(context)
                preset = DownloadTuning.getPreset(context)
            }
        )
        SettingsRowDivider()
        DlKnobRow(
            label    = "Manga pages at once",
            note     = "A chapter can be 200 images \u2014 this is the big speed lever for manga.",
            value    = parallelPages,
            min      = DownloadTuning.MIN_PARALLEL_PAGES,
            max      = DownloadTuning.MAX_PARALLEL_PAGES,
            onChange = {
                DownloadTuning.setParallelPages(context, it)
                parallelPages = DownloadTuning.getParallelPages(context)
                preset = DownloadTuning.getPreset(context)
            }
        )
        SettingsRowDivider()
        DlKnobRow(
            label    = "Retry attempts",
            note     = "Tries before a chapter is marked failed. Pause widens each time.",
            value    = retries,
            min      = DownloadTuning.MIN_RETRIES,
            max      = DownloadTuning.MAX_RETRIES,
            onChange = {
                DownloadTuning.setRetryAttempts(context, it)
                retries = DownloadTuning.getRetryAttempts(context)
                preset = DownloadTuning.getPreset(context)
            }
        )

        SettingsRowDivider()

        // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 3. PACING \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
        DlSectionLabel("Pacing", "Politeness gaps that reduce the chance of getting rate-limited.")

        DlChipRow(
            label   = "Pause between chapters",
            options = DownloadTuning.CHAPTER_DELAY_OPTIONS.map { it to DownloadTuning.delayLabel(it) },
            selected = chapterDelay,
            onSelect = {
                DownloadTuning.setChapterDelayMs(context, it)
                chapterDelay = DownloadTuning.getChapterDelayMs(context)
                preset = DownloadTuning.getPreset(context)
            }
        )
        SettingsRowDivider()
        DlChipRow(
            label   = "Pause between manga pages",
            options = DownloadTuning.PAGE_DELAY_OPTIONS.map { it to DownloadTuning.delayLabel(it) },
            selected = pageDelay,
            onSelect = {
                DownloadTuning.setPageDelayMs(context, it)
                pageDelay = DownloadTuning.getPageDelayMs(context)
                preset = DownloadTuning.getPreset(context)
            }
        )
        SettingsRowDivider()
        DlChipRow(
            label   = "Speed limit",
            options = DownloadTuning.SPEED_OPTIONS.map { it to DownloadTuning.speedLabel(it) },
            selected = speedKbps,
            onSelect = {
                DownloadTuning.setSpeedLimitKbps(context, it)
                speedKbps = DownloadTuning.getSpeedLimitKbps(context)
                preset = DownloadTuning.getPreset(context)
            }
        )

        SettingsRowDivider()

        // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 4. SWITCHES \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
        DlSectionLabel("Connectivity & quality")

        DlToggleRow(
            icon  = Icons.Default.Wifi,
            label = "Wi-Fi only",
            note  = "Blocks new jobs on mobile data so you don\u2019t quietly burn your quota.",
            checked = wifiOnly,
            onChange = { wifiOnly = it; DownloadTuning.setWifiOnly(context, it) }
        )
        SettingsRowDivider()
        DlToggleRow(
            icon  = Icons.Default.Refresh,
            label = "Second verification pass (novels)",
            note  = "Slower sweep over missing content. Flaky sources often need it. Off = faster.",
            checked = verifyPass,
            onChange = { verifyPass = it; DownloadTuning.setVerifyPassEnabled(context, it) }
        )
        SettingsRowDivider()
        DlToggleRow(
            icon  = Icons.Default.BatteryChargingFull,
            label = "OCR while downloading (manga)",
            note  = "Pre-reads speech bubbles for read-aloud. Makes downloads noticeably slower.",
            checked = ocrOnDownload,
            onChange = { ocrOnDownload = it; MangaOcrCache.setOcrOnDownloadEnabled(context, it) }
        )

        SettingsRowDivider()

        // \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 5. AUTOMATIC \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500
        DlSectionLabel(
            "Automatic downloads",
            "Default rules for titles that don\u2019t have their own offline policy set."
        )

        DlChipRow(
            label   = "Keep ahead by default",
            options = DownloadPolicy.KEEP_AHEAD_CHOICES.map { it to DownloadPolicy.keepAheadLabel(it) },
            selected = globalKeepAhead,
            onSelect = { choice ->
                globalKeepAhead = choice
                DownloadPolicy.setGlobalRules(
                    context,
                    DownloadPolicy.globalRules(context).copy(keepAhead = choice)
                )
            }
        )
        SettingsRowDivider()
        DlChipRow(
            label   = "Library storage budget",
            options = listOf(0 to "No cap", 500 to "500 MB", 1000 to "1 GB", 2000 to "2 GB", 5000 to "5 GB"),
            selected = libraryBudget,
            onSelect = { mb ->
                libraryBudget = mb
                DownloadPolicy.setLibraryBudgetMb(context, mb)
            }
        )

        SettingsRowDivider()

        // Reset
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Changes apply to the next job you start.",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f),
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = {
                DownloadTuning.resetToDefaults(context)
                MangaOcrCache.setOcrOnDownloadEnabled(context, false)
                ocrOnDownload = false
                reload()
            }) {
                Text("Reset defaults", fontSize = 12.sp)
            }
        }
    }
}

// \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500 Private composables \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500

@Composable
private fun PresetCard(
    id: String,
    active: String,
    icon: ImageVector,
    label: String,
    desc: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val selected = active == id
    val bg by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.32f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "presetBg"
    )
    val borderColor by animateColorAsState(
        if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.70f)
        else MaterialTheme.colorScheme.outline.copy(alpha = 0.20f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "presetBorder"
    )
    Surface(
        shape    = RoundedCornerShape(16.dp),
        color    = bg,
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .border(1.5.dp, borderColor, RoundedCornerShape(16.dp))
            .clickable(role = Role.Button, onClick = onClick)
            .padding(12.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.Start,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    icon, null,
                    tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
                if (selected) {
                    Box(
                        modifier = Modifier.size(18.dp).clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(12.dp))
                    }
                }
            }
            Text(
                label, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
            )
            Text(
                desc, fontSize = 10.sp, lineHeight = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.78f)
            )
        }
    }
}

@Composable
private fun DlSectionLabel(title: String, subtitle: String? = null) {
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp)) {
        Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary, letterSpacing = 0.4.sp)
        if (subtitle != null) {
            Spacer(Modifier.height(2.dp))
            Text(subtitle, fontSize = 11.sp, lineHeight = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.80f))
        }
    }
}

@Composable
private fun DlKnobRow(label: String, note: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Text(note, fontSize = 11.sp, lineHeight = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f))
        }
        // Pill stepper
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            StepButton("\u2212", enabled = value > min) { onChange(value - 1) }
            Box(
                modifier = Modifier.size(38.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    value.toString(),
                    fontSize = 15.sp, fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            StepButton("+", enabled = value < max) { onChange(value + 1) }
        }
    }
}

@Composable
private fun StepButton(symbol: String, enabled: Boolean, onClick: () -> Unit) {
    val bg = if (enabled) MaterialTheme.colorScheme.primary.copy(alpha = 0.13f)
             else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
    val fg = if (enabled) MaterialTheme.colorScheme.primary
             else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
    Box(
        modifier = Modifier.size(34.dp).clip(CircleShape).background(bg)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(symbol, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = fg)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun <T> DlChipRow(label: String, options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp)) {
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
        Spacer(Modifier.height(8.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (value, lbl) ->
                val active = selected == value
                val chipBg by animateColorAsState(
                    if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.40f),
                    label = "chipBg"
                )
                val chipBorder by animateColorAsState(
                    if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)
                    else MaterialTheme.colorScheme.outline.copy(alpha = 0.22f),
                    label = "chipBorder"
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(chipBg)
                        .border(1.dp, chipBorder, RoundedCornerShape(20.dp))
                        .clickable(role = Role.Button) { onSelect(value) }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Text(
                        lbl, fontSize = 12.sp,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                        color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun DlToggleRow(icon: ImageVector, label: String, note: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier.size(34.dp).clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(17.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
            Text(note, fontSize = 11.sp, lineHeight = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f))
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
