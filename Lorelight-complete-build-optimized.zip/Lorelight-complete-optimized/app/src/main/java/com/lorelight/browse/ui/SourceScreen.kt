package com.lorelight.browse.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.ui.theme.getThemedButtonProps
import kotlin.math.roundToInt
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.lorelight.browse.js.JSPluginEngine
import com.lorelight.browse.model.FilterDef
import com.lorelight.browse.model.FilterValue
import com.lorelight.browse.model.FilterValues
import com.lorelight.browse.model.SourceNovelItem
import com.lorelight.browse.repo.SourceChapterCountCache
import com.lorelight.ui.animation.BookGridSkeleton
import com.lorelight.ui.animation.StaggeredItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.lorelight.ui.components.browse.BrowseActionButton
import com.lorelight.ui.components.browse.BrowseCoverBadge
import com.lorelight.ui.components.browse.BrowseGridCard
import com.lorelight.ui.components.browse.BrowseListRow
import androidx.compose.ui.semantics.Role

/**
 * LNReader-style source catalog screen, restyled to match Lorelight's
 * pill/card visual language (same as Library and the Browse root).
 * Public signature unchanged.
 */
@Composable
fun SourceScreen(
    pluginId: String,
    pluginName: String,
    site: String,
    startLatest: Boolean,
    onBack: () -> Unit,
    onOpenNovel: (String, SourceNovelItem) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var showLatest by remember { mutableStateOf(startLatest) }

    var searchActive by remember { mutableStateOf(false) }
    var searchField by remember { mutableStateOf("") }
    var activeQuery by remember { mutableStateOf<String?>(null) }

    var filterDefs by remember { mutableStateOf<List<FilterDef>>(emptyList()) }
    var filterValues by remember { mutableStateOf<FilterValues?>(null) }
    var showFilters by remember { mutableStateOf(false) }

    val items = remember { mutableStateListOf<SourceNovelItem>() }
    var page by remember { mutableStateOf(1) }
    var loading by remember { mutableStateOf(false) }
    var loadingMore by remember { mutableStateOf(false) }
    var endReached by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val gridState = rememberLazyGridState()

    val settingsVersion by com.lorelight.data.local.AppSettingsSignal.version.collectAsState()

    // Catalog display preferences (layout, covers per row, badges...). Stored in
    // the canonical settings file, so the choice sticks across sources/restarts.
    var display by remember(settingsVersion) { mutableStateOf(SourceDisplayPrefs.load(context)) }
    var showDisplaySettings by remember { mutableStateOf(false) }

    // Whether the user flagged THIS source as adult. Drives blur / hide.
    var adultSource by remember(pluginId, settingsVersion) { mutableStateOf(AdultSources.isAdult(context, pluginId)) }

    // Novel paths from THIS source that already live in the library, plus the
    // subset marked Completed. Read off the main thread; failures are silent.
    var libraryPaths by remember { mutableStateOf<Set<String>>(emptySet()) }
    var finishedPaths by remember { mutableStateOf<Set<String>>(emptySet()) }
    val needsLibraryLookup = display.showLibraryBadge ||
        display.dimFinished ||
        display.libraryFilter != SourceLibraryFilter.NORMAL
    LaunchedEffect(pluginId, needsLibraryLookup) {
        if (!needsLibraryLookup) {
            libraryPaths = emptySet()
            finishedPaths = emptySet()
        } else {
            val loaded = withContext(Dispatchers.IO) {
                try {
                    val mine = com.lorelight.data.local.NovelPreferences
                        .loadNovelsFromPrefs(context)
                        .filter { it.pluginId == pluginId }
                    val all = mine.mapNotNull { it.pluginNovelPath }.toSet()
                    val done = mine
                        .filter { it.readingStatus == "Completed" }
                        .mapNotNull { it.pluginNovelPath }
                        .toSet()
                    all to done
                } catch (e: Exception) {
                    emptySet<String>() to emptySet<String>()
                }
            }
            libraryPaths = loaded.first
            finishedPaths = loaded.second
        }
    }

    // What the grid actually draws, after the "already in library" preference
    // and the adult-content preference are applied. Held as a State object so
    // the pagination coroutine further down always reads the live value.
    val displayItemsState = remember {
        derivedStateOf {
            when {
                adultSource && display.nsfwMode == SourceNsfwMode.HIDE -> emptyList()
                display.libraryFilter == SourceLibraryFilter.HIDE_LIBRARY ->
                    items.filter { it.path !in libraryPaths }
                display.libraryFilter == SourceLibraryFilter.LIBRARY_FIRST ->
                    items.sortedByDescending { it.path in libraryPaths }
                else -> items.toList()
            }
        }
    }
    val displayItems = displayItemsState.value
    val blurCovers = adultSource && display.nsfwMode == SourceNsfwMode.BLUR

    LaunchedEffect(pluginId) {
        filterDefs = try {
            JSPluginEngine.getFilters(context.applicationContext, pluginId)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun fetch(p: Int): List<SourceNovelItem> {
        val q = activeQuery
        return if (!q.isNullOrBlank()) {
            JSPluginEngine.searchNovels(context.applicationContext, pluginId, q, p)
        } else {
            JSPluginEngine.popularNovels(
                context.applicationContext, pluginId, p, showLatest,
                filterValues?.toJson()?.toString()
            )
        }
    }

    fun reload() {
        scope.launch {
            loading = true
            error = null
            endReached = false
            page = 1
            try {
                val res = fetch(1)
                items.clear()
                items.addAll(res.distinctBy { it.path })
                endReached = items.isEmpty()
            } catch (e: Exception) {
                error = e.message ?: "Failed to load"
                items.clear()
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(activeQuery, filterValues, showLatest) { reload() }

    LaunchedEffect(gridState) {
        snapshotFlow { gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1 }
            .collect { last ->
                // Compare against the visible list: hiding library rows must
                // not stall paging.
                val visibleCount = displayItemsState.value.size
                if (!loading && !loadingMore && !endReached && items.isNotEmpty() && last >= visibleCount - 6) {
                    loadingMore = true
                    val next = page + 1
                    try {
                        val res = fetch(next)
                        val existing = items.mapTo(HashSet()) { it.path }
                        val fresh = res.filter { it.path !in existing }
                        if (fresh.isEmpty()) endReached = true
                        else {
                            items.addAll(fresh)
                            page = next
                        }
                    } catch (e: Exception) {
                        endReached = true
                    } finally {
                        loadingMore = false
                    }
                }
            }
    }

    // The site's listing selector = its first Picker filter (options differ per site). Null if none.
    val listingFilter = filterDefs.firstOrNull { it is FilterDef.Picker } as? FilterDef.Picker
    val listingCurrentValue = (filterValues?.map?.get(listingFilter?.key)?.value as? String)
        ?: listingFilter?.default

    // Build the dropdown entries (label, isSelected, onSelect). Real site listings when available,
    // otherwise the Popular/Latest fallback.
    fun defaultFilterMap(): MutableMap<String, FilterValue> {
        val map = mutableMapOf<String, FilterValue>()
        filterDefs.forEach { f ->
            map[f.key] = when (f) {
                is FilterDef.Picker -> FilterValue("Picker", f.default)
                is FilterDef.TextInput -> FilterValue("Text", f.default)
                is FilterDef.Switch -> FilterValue("Switch", f.default)
                is FilterDef.CheckboxGroup -> FilterValue("Checkbox", f.defaults.toList())
                is FilterDef.ExcludableCheckboxGroup ->
                    FilterValue("XCheckbox", Pair(f.includedDefaults.toList(), f.excludedDefaults.toList()))
            }
        }
        return map
    }

    val listingEntries: List<Triple<String, Boolean, () -> Unit>> = if (listingFilter != null) {
        listingFilter.options.map { opt ->
            Triple(opt.first, listingCurrentValue == opt.second) {
                // start from all defaults, keep any existing user selections, then apply the chosen listing
                val map = defaultFilterMap()
                filterValues?.map?.forEach { (k, v) -> map[k] = v }
                map[listingFilter.key] = FilterValue("Picker", opt.second)
                filterValues = FilterValues(map)
            }
        }
    } else {
        listOf(
            Triple("Popular", !showLatest) { showLatest = false },
            Triple("Latest", showLatest) { showLatest = true }
        )
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // ── Header: back pill + title + action pills (matches Browse root / Library) ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 12.dp)
                .height(48.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BrowseActionButton(
                icon = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                onClick = onBack
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = pluginName,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = MaterialTheme.typography.headlineLarge.fontFamily,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (!activeQuery.isNullOrBlank()) {
                    Text(
                        "Search: $activeQuery",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BrowseActionButton(
                    icon = Icons.Filled.Search,
                    contentDescription = "Search $pluginName",
                    active = searchActive,
                    onClick = {
                        searchActive = !searchActive
                        if (!searchActive) {
                            searchField = ""
                            if (activeQuery != null) activeQuery = null
                        }
                    }
                )
                if (filterDefs.isNotEmpty()) {
                    BrowseActionButton(
                        icon = Icons.Filled.FilterList,
                        contentDescription = "Filters",
                        onClick = { showFilters = true }
                    )
                }
                BrowseActionButton(
                    icon = Icons.Filled.Tune,
                    contentDescription = "Display settings",
                    active = showDisplaySettings,
                    onClick = { showDisplaySettings = true }
                )
            }
        }

        // ── Inline search field (rounded, themed) ──
        if (searchActive) {
            val focusRequester = remember { FocusRequester() }
            LaunchedEffect(Unit) { focusRequester.requestFocus() }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Filled.Search,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(10.dp))
                BasicTextField(
                    value = searchField,
                    onValueChange = { searchField = it },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = {
                        activeQuery = searchField.trim().ifBlank { null }
                    }),
                    modifier = Modifier
                        .weight(1f)
                        .focusRequester(focusRequester),
                    decorationBox = { inner ->
                        Box {
                            if (searchField.isEmpty()) {
                                Text(
                                    "Search $pluginName",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            inner()
                        }
                    }
                )
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Close search",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .size(18.dp)
                        .clickable(role = Role.Button) {
                            searchActive = false
                            searchField = ""
                            if (activeQuery != null) activeQuery = null
                        }
                )
            }
        }

        // ── Listing selector pill row ──
        // Restyled to use the same sliding animated highlight as the main
        // bottom navigation bar: one gradient pill glides between whichever
        // entry is selected, instead of every pill statically re-tinting.
        if (listingEntries.isNotEmpty()) {
            val density = LocalDensity.current
            // Tracks each pill's live on-screen bounds (x offset + width) so
            // the highlight can slide and resize to match the selection.
            val pillBounds = remember { mutableStateMapOf<Int, Pair<Float, Float>>() }
            val selectedListingIndex = listingEntries.indexOfFirst { it.second }.coerceAtLeast(0)
            val targetPillBounds = pillBounds[selectedListingIndex]
            val highlightX by animateFloatAsState(
                targetValue = targetPillBounds?.first ?: 0f,
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
                label = "listingHighlightX"
            )
            val highlightW by animateFloatAsState(
                targetValue = targetPillBounds?.second ?: 0f,
                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
                label = "listingHighlightW"
            )
            val (_, listingGradient, listingContentColor) = getThemedButtonProps(
                MaterialTheme.colorScheme.primary,
                MaterialTheme.colorScheme.onPrimaryContainer
            )

            Box(
                modifier = Modifier
                    .padding(bottom = 8.dp)
                    .height(34.dp)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
            ) {
                if (targetPillBounds != null) {
                    Box(
                        modifier = Modifier
                            .offset { IntOffset(highlightX.roundToInt(), 0) }
                            .width(with(density) { highlightW.toDp() })
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(14.dp))
                            .background(listingGradient)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxHeight(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listingEntries.forEachIndexed { i, entry ->
                        val label = entry.first
                        val selected = entry.second
                        val onSelect = entry.third
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .onGloballyPositioned { coords ->
                                    pillBounds[i] = coords.positionInParent().x to coords.size.width.toFloat()
                                }
                                .clip(RoundedCornerShape(14.dp))
                                .clickable(role = Role.Button) { onSelect() },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selected) listingContentColor else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // ── Content ──
        Box(Modifier.fillMaxSize()) {
            when {
                loading -> BookGridSkeleton(columns = if (display.columns > 0) display.columns else 3)
                error != null -> com.lorelight.ui.components.LorelightError(
                    message = error,
                    onRetry = { reload() },
                    onOpenWebsite = null,
                    modifier = Modifier.fillMaxSize()
                )
                displayItems.isEmpty() -> com.lorelight.ui.components.LorelightEmpty(
                    icon = Icons.Filled.SearchOff,
                    title = if (items.isNotEmpty()) "Everything is in your library" else "No novels found",
                    message = if (adultSource && display.nsfwMode == SourceNsfwMode.HIDE)
                        "Covers from this source are hidden by your adult content setting"
                    else if (items.isNotEmpty())
                        "Everything here is already in your library"
                    else "Try a different search or filter.",
                    modifier = Modifier.fillMaxSize()
                )
                else -> LazyVerticalGrid(
                    // List mode is a single-column grid so paging keeps working
                    // off the same scroll state as every other layout.
                    columns = when {
                        display.layout == SourceLayoutMode.LIST -> GridCells.Fixed(1)
                        display.columns > 0 -> GridCells.Fixed(display.columns)
                        display.layout == SourceLayoutMode.COMPACT_GRID -> GridCells.Adaptive(88.dp)
                        else -> GridCells.Adaptive(112.dp)
                    },
                    state = gridState,
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(display.spacing.gap),
                    verticalArrangement = Arrangement.spacedBy(display.spacing.gap),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(items = displayItems, key = { _, novel -> novel.path }) { i, novel ->
                        StaggeredItem(index = i, key = novel.path) {
                            if (display.layout == SourceLayoutMode.LIST) {
                                SourceListRow(
                                    item = novel,
                                    pluginId = pluginId,
                                    site = site,
                                    coverRatio = display.coverShape.ratio,
                                    cornerRadius = display.coverCorner.dp,
                                    titleSizeSp = display.titleSize.sp,
                                    showChapterBadge = display.showChapterBadge,
                                    inLibrary = novel.path in libraryPaths,
                                    showLibraryBadge = display.showLibraryBadge,
                                    dim = display.dimFinished && novel.path in finishedPaths,
                                    blurCover = blurCovers,
                                    dataSaver = display.dataSaver,
                                    onClick = { onOpenNovel(pluginId, novel) }
                                )
                            } else {
                                NovelCover(
                                    item = novel,
                                    pluginId = pluginId,
                                    site = site,
                                    aspectRatio = display.coverShape.ratio,
                                    cornerRadius = display.coverCorner.dp,
                                    showTitle = display.titlesVisible,
                                    titleLines = display.titleLines,
                                    titleSizeSp = display.titleSize.sp,
                                    showChapterBadge = display.showChapterBadge,
                                    inLibrary = novel.path in libraryPaths,
                                    showLibraryBadge = display.showLibraryBadge,
                                    dim = display.dimFinished && novel.path in finishedPaths,
                                    blurCover = blurCovers,
                                    dataSaver = display.dataSaver,
                                    onClick = { onOpenNovel(pluginId, novel) }
                                )
                            }
                        }
                    }
                    if (loadingMore) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            com.lorelight.ui.components.LorelightLoading(
                                shape = com.lorelight.ui.components.LoadingShape.INLINE
                            )
                        }
                    }
                }
            }
        }
    }

    if (showFilters) {
        FilterBottomSheet(
            filters = filterDefs,
            initial = filterValues,
            onApply = { fv ->
                filterValues = fv
                showFilters = false
            },
            onDismiss = { showFilters = false }
        )
    }

        SourceDisplaySettingsSheet(
            visible = showDisplaySettings,
            initial = display,
            sourceName = pluginName,
            isAdultSource = adultSource,
            onAdultSourceChange = { flagged ->
                adultSource = flagged
                AdultSources.setAdult(context, pluginId, flagged)
            },
            onApply = { updated ->
                display = updated
                SourceDisplayPrefs.save(context, updated)
            },
            onDismiss = { showDisplaySettings = false }
        )
    }
}

@Composable
private fun NovelCover(
    item: SourceNovelItem,
    pluginId: String,
    site: String = "",
    aspectRatio: Float = 0.7f,
    cornerRadius: Dp = 12.dp,
    showTitle: Boolean = true,
    titleLines: Int = 2,
    titleSizeSp: Int = 11,
    showChapterBadge: Boolean = true,
    inLibrary: Boolean = false,
    showLibraryBadge: Boolean = true,
    dim: Boolean = false,
    blurCover: Boolean = false,
    dataSaver: Boolean = false,
    onClick: () -> Unit
) {
    val chapterCount = rememberSourceChapterCount(pluginId, item.path, showChapterBadge)
    val request = rememberNovelCoverRequest(item.cover, site, dataSaver)

    BrowseGridCard(
        title = item.name,
        aspectRatio = aspectRatio,
        cornerRadius = cornerRadius,
        showTitle = showTitle,
        titleLines = titleLines,
        titleSizeSp = titleSizeSp,
        inLibrary = inLibrary,
        showLibraryBadge = showLibraryBadge,
        dim = dim,
        blurCover = blurCover,
        onClick = onClick,
        overlay = {
            // Chapter count is novel-only: the manga extensions report it as
            // part of the listing, plugins do not.
            if (showChapterBadge && chapterCount != null && chapterCount > 0) {
                BrowseCoverBadge(
                    text = "$chapterCount ch",
                    alignment = Alignment.BottomEnd,
                    background = Color.Black.copy(alpha = 0.72f),
                    contentColor = Color.White
                )
            }
        }
    ) { coverModifier ->
        NovelCoverPixels(
            request = request,
            contentDescription = item.name,
            modifier = coverModifier,
            placeholderIconSize = 32.dp
        )
    }
}

@Composable
private fun SourceListRow(
    item: SourceNovelItem,
    pluginId: String,
    site: String = "",
    coverRatio: Float = 0.7f,
    cornerRadius: Dp = 12.dp,
    titleSizeSp: Int = 13,
    showChapterBadge: Boolean = true,
    inLibrary: Boolean = false,
    showLibraryBadge: Boolean = true,
    dim: Boolean = false,
    blurCover: Boolean = false,
    dataSaver: Boolean = false,
    onClick: () -> Unit
) {
    val chapterCount = rememberSourceChapterCount(pluginId, item.path, showChapterBadge)
    val request = rememberNovelCoverRequest(item.cover, site, dataSaver)

    BrowseListRow(
        title = item.name,
        coverRatio = coverRatio,
        cornerRadius = cornerRadius,
        titleSizeSp = titleSizeSp,
        dim = dim,
        blurCover = blurCover,
        onClick = onClick,
        details = {
            // The novel side states library and chapter state as one joined
            // caption; the manga side uses a pill. Kept per-side on purpose.
            val subtitle = buildList {
                if (showLibraryBadge && inLibrary) add("In library")
                if (showChapterBadge && chapterCount != null && chapterCount > 0) add("$chapterCount chapters")
            }.joinToString("  -  ")
            if (subtitle.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    ) { coverModifier ->
        NovelCoverPixels(
            request = request,
            contentDescription = item.name,
            modifier = coverModifier,
            placeholderIconSize = 20.dp
        )
    }
}

/**
 * Chapter counts are NOT part of a plugin listing response, so each one is
 * fetched per novel and cached. The cache caps itself to two concurrent
 * fetches and remembers failures, so scrolling a long grid cannot stampede
 * the source site.
 *
 * The grid card and the list row each used to carry their own copy of this
 * logic, including the same bug where a cache that nothing ever filled was
 * only PEEKED inside a remember that never re-ran - so the badge could never
 * draw anything at all.
 */
@Composable
private fun rememberSourceChapterCount(
    pluginId: String,
    path: String,
    enabled: Boolean
): Int? {
    val context = LocalContext.current
    var count by remember(pluginId, path) {
        mutableStateOf(SourceChapterCountCache.peek(pluginId, path))
    }
    LaunchedEffect(pluginId, path, enabled) {
        if (!enabled || count != null) return@LaunchedEffect
        val fetched = SourceChapterCountCache.fetch(context.applicationContext, pluginId, path)
        if (fetched != SourceChapterCountCache.UNKNOWN) count = fetched
    }
    return count
}

/**
 * Novel covers need a per-plugin request: a Referer derived from the plugin
 * site, because many sources reject cover requests without one. This is the
 * part of catalog presentation that genuinely cannot be shared with manga,
 * which resolves covers through the extension network stack instead.
 */
@Composable
private fun rememberNovelCoverRequest(
    coverUrl: String?,
    site: String,
    dataSaver: Boolean
): ImageRequest? {
    val context = LocalContext.current
    return remember(coverUrl, site, dataSaver) {
        if (coverUrl.isNullOrBlank()) null
        else {
            ImageRequest.Builder(context)
                .data(coverUrl)
                .memoryCacheKey(coverUrl)
                .diskCacheKey(coverUrl)
                .placeholderMemoryCacheKey(coverUrl)
                .crossfade(true)
                .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .apply {
                    if (site.isNotBlank()) {
                        addHeader("Referer", site)
                    }
                    if (dataSaver) {
                        // Small RGB_565 bitmap: far fewer bytes over the wire
                        // and roughly half the memory once decoded.
                        size(240, 360)
                        bitmapConfig(android.graphics.Bitmap.Config.RGB_565)
                    }
                }
                .build()
        }
    }
}

/** The cover pixels for a novel, or a book glyph when there is no cover. */
@Composable
private fun NovelCoverPixels(
    request: ImageRequest?,
    contentDescription: String,
    modifier: Modifier,
    placeholderIconSize: Dp
) {
    if (request != null) {
        AsyncImage(
            model = request,
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    } else {
        Box(modifier, contentAlignment = Alignment.Center) {
            Icon(
                imageVector = Icons.Filled.MenuBook,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                modifier = Modifier.size(placeholderIconSize)
            )
        }
    }
}
