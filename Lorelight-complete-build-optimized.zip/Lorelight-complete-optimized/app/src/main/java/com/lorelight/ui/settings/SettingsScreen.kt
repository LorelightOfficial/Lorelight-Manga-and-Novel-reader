package com.lorelight.ui.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import com.lorelight.ui.components.LorelightDialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import eu.kanade.tachiyomi.extension.ExtensionManager
import mihon.domain.extension.interactor.AddExtensionStore
import mihon.domain.extension.interactor.GetExtensionStores
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

import com.lorelight.R
import androidx.compose.ui.res.stringResource
import com.lorelight.ui.theme.*
import com.lorelight.data.model.Novel
import com.lorelight.data.model.Website
import com.lorelight.data.model.toJSONObject
import com.lorelight.data.model.toNovel
import com.lorelight.ui.reader.ReaderViewModel
import com.lorelight.core.BackupManager
import com.lorelight.core.BackupInfo
import com.lorelight.core.CrashReporter
import com.lorelight.core.CrashReport
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.ui.semantics.Role


private val SettingCardRadius = 14.dp
private val SettingCardPadding = 14.dp
private val SettingRowMinHeight = 48.dp
private val SettingGroupGap = 14.dp
private val SettingInnerGap = 12.dp

/*
 * SETTINGS CATEGORIES
 *
 * Merged from ten categories down to six. The old set split things that belong
 * together and made the hub feel like a wall of near-duplicates:
 *
 *   Reader Editor + Text-to-Speech          -> Reading & Voice
 *   New Chapter Notifications + Manga Sources -> Library & Sources
 *   Downloads Queue + Storage Maintenance   -> Downloads & Storage
 *   Advanced Tools + About Lorelight        -> Advanced & About
 *
 * Backup & Restore stays on its own because it is high stakes and people look
 * for it by that exact name. Appearance stays on its own because it is the most
 * visited screen.
 */
enum class SettingsCategory(
    val title: String,
    val desc: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    APPEARANCE(
        "Appearance",
        "Theme mode, colour palettes, and typography",
        Icons.Default.Palette
    ),
    READING(
        "Reading & Voice",
        "Reader layout, margins, line spacing, and text-to-speech",
        Icons.Default.Book
    ),
    LIBRARY(
        "Library & Sources",
        "Chapter update checks, notifications, manga sources and extensions",
        Icons.Default.NotificationsActive
    ),
    STORAGE(
        "Downloads & Storage",
        "Download queue, offline chapter cache, and source health",
        Icons.Default.Download
    ),
    BACKUP_RESTORE(
        "Backup & Restore",
        "Export, import, and automatic daily backups",
        Icons.Default.Backup
    ),
    ADVANCED(
        "Advanced & About",
        "Diagnostics, crash reports, app version, and community",
        Icons.Default.Settings
    )
}

@Composable
fun settingsCategoryTitle(category: SettingsCategory): String = when (category) {
    SettingsCategory.APPEARANCE -> stringResource(R.string.settings_category_appearance_title)
    SettingsCategory.READING -> stringResource(R.string.settings_category_reading_title)
    SettingsCategory.LIBRARY -> stringResource(R.string.settings_category_library_title)
    SettingsCategory.STORAGE -> stringResource(R.string.settings_category_storage_title)
    SettingsCategory.BACKUP_RESTORE -> stringResource(R.string.settings_category_backup_title)
    SettingsCategory.ADVANCED -> stringResource(R.string.settings_category_advanced_title)
}

@Composable
fun settingsCategoryDesc(category: SettingsCategory): String = when (category) {
    SettingsCategory.APPEARANCE -> stringResource(R.string.settings_category_appearance_desc)
    SettingsCategory.READING -> stringResource(R.string.settings_category_reading_desc)
    SettingsCategory.LIBRARY -> stringResource(R.string.settings_category_library_desc)
    SettingsCategory.STORAGE -> stringResource(R.string.settings_category_storage_desc)
    SettingsCategory.BACKUP_RESTORE -> stringResource(R.string.settings_category_backup_desc)
    SettingsCategory.ADVANCED -> stringResource(R.string.settings_category_advanced_desc)
}

@Composable
fun SettingsScreen(
    importedNovels: List<Novel>,
    websites: List<Website>,
    readerViewModel: ReaderViewModel,
    onRestoreSuccess: () -> Unit,
    onOpenFontManager: () -> Unit,
    onOpenNewChapters: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    var cacheStats by remember { mutableStateOf(getCacheStats(context)) }
    var perNovelStats by remember { mutableStateOf<List<NovelCacheStat>?>(null) }
    var selectedForDelete by remember { mutableStateOf<NovelCacheStat?>(null) }
    var showClearConfirmDialog by remember { mutableStateOf(false) }
    var isOperating by remember { mutableStateOf(false) }
    var showRestoreConfirmDialog by remember { mutableStateOf(false) }
    var pendingRestoreContent by remember { mutableStateOf("") }
    
    // Auto Backups & Crash Reports states
    var singleBackupInfo by remember { mutableStateOf(BackupManager.getSingleBackupInfo(context)) }
    var crashReports by remember { mutableStateOf(CrashReporter.getCrashReports(context)) }
    var viewingCrashReport by remember { mutableStateOf<CrashReport?>(null) }
    var showAutoRestoreConfirmDialog by remember { mutableStateOf<BackupInfo?>(null) }

    val settingsVersion by com.lorelight.data.local.AppSettingsSignal.version.collectAsState()
    val backupPrefs = remember(settingsVersion) { context.getSharedPreferences("lorelight_backup_prefs", Context.MODE_PRIVATE) }
    var backupLocationType by remember(settingsVersion) { mutableStateOf(backupPrefs.getString(BackupManager.KEY_LOCATION_TYPE, "external") ?: "external") }
    val noFolderSelectedStr = stringResource(R.string.settings_no_folder_selected)
    var customFolderPathName by remember(settingsVersion) { mutableStateOf(backupPrefs.getString(BackupManager.KEY_CUSTOM_PATH_NAME, noFolderSelectedStr) ?: noFolderSelectedStr) }

    // Active detail category state
    var activeCategory by remember { mutableStateOf<SettingsCategory?>(null) }
    // Search-first entry point: filters individual settings across every
    // category, so you no longer have to guess which of six screens owns a
    // toggle before you can find it.
    var settingsQuery by remember { mutableStateOf("") }
    // The download queue is a whole screen, not a settings row. It used to be
    // rendered as an item inside this LazyColumn, which nested a scrollable
    // inside a scrollable. It is now hosted as an overlay instead.
    var showDownloadsQueue by remember { mutableStateOf(false) }

    // BACK ALIGNMENT: the in-app arrow in a settings category header does
    // `activeCategory = null`, returning to the category list. System Back used
    // to skip that level entirely and leave the Settings tab, so the two
    // gestures disagreed on every settings detail page.
    androidx.activity.compose.BackHandler(enabled = activeCategory != null && !showDownloadsQueue) {
        activeCategory = null
    }
    var devModeUnlocked by remember { mutableStateOf(com.lorelight.core.DevLogStore.isDevModeUnlocked(context)) }

    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val takeFlags: Int = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, takeFlags)
                
                val doc = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, uri)
                val folderName = doc?.name ?: context.getString(R.string.settings_custom_folder_fallback)
                
                backupPrefs.edit().apply {
                    putString(BackupManager.KEY_LOCATION_TYPE, "custom")
                    putString(BackupManager.KEY_CUSTOM_URI, uri.toString())
                    putString(BackupManager.KEY_CUSTOM_PATH_NAME, folderName)
                }.commit()
                
                backupLocationType = "custom"
                customFolderPathName = folderName
                
                val success = BackupManager.createBackup(context)
                singleBackupInfo = BackupManager.getSingleBackupInfo(context)
                if (success) {
                    Toast.makeText(context, context.getString(R.string.settings_toast_location_backup_created), Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, context.getString(R.string.settings_toast_location_updated), Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Failed to persist folder permission: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
    
    // Backup Launcher (Saves JSON document)
    val backupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            isOperating = true
            coroutineScope.launch {
                val success = withContext(Dispatchers.IO) {
                    try {
                        val backupText = generateBackupJson(context)
                        context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                            outputStream.write(backupText.toByteArray())
                            outputStream.flush()
                        }
                        true
                    } catch (e: Exception) {
                        e.printStackTrace()
                        false
                    }
                }
                isOperating = false
                if (success) {
                    Toast.makeText(context, context.getString(R.string.settings_toast_backup_exported), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, context.getString(R.string.settings_toast_backup_export_failed), Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    
    // Restore Launcher (Opens JSON document)
    val restoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            isOperating = true
            coroutineScope.launch {
                val fileContent = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openInputStream(uri)?.use { inputStream ->
                            inputStream.reader().readText()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        null
                    }
                }
                isOperating = false
                if (!fileContent.isNullOrEmpty()) {
                    pendingRestoreContent = fileContent
                    showRestoreConfirmDialog = true
                } else {
                    Toast.makeText(context, context.getString(R.string.settings_toast_backup_read_failed), Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    
    LaunchedEffect(importedNovels, cacheStats) {
        cacheStats = getCacheStats(context)
        val stats = withContext(Dispatchers.IO) {
            val novels = com.lorelight.data.repository.LibraryRepository.loadLibrary(context)
            getPerNovelCacheStats(context, novels)
        }
        perNovelStats = stats
    }

    // ADAPTIVE LAYOUT: phones keep the hub -> detail flow, while anything at
    // least 720dp wide (landscape phones, tablets, unfolded foldables) gets a
    // persistent category rail, so switching category costs no Back press.
    val configuration = LocalConfiguration.current
    val twoPane = configuration.screenWidthDp >= 720
    val cat = activeCategory

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = if (twoPane) 1180.dp else 680.dp),
            horizontalArrangement = Arrangement.spacedBy(if (twoPane) 14.dp else 0.dp)
        ) {
        if (twoPane) {
            SettingsCategoryRail(
                activeCategory = cat,
                query = settingsQuery,
                onQueryChange = { settingsQuery = it },
                onSelect = { activeCategory = it },
                modifier = Modifier
                    // Deterministic rail width instead of a width fraction.
                    // weight(0.36f) shrank the rail to roughly 250dp on a
                    // 720dp tablet, which is what forced the category labels
                    // to wrap mid-word. A fixed readable band fixes the cause
                    // rather than squeezing the text, and the detail pane
                    // absorbs whatever space is left.
                    .width(if (configuration.screenWidthDp >= 900) 320.dp else 272.dp)
                    .fillMaxHeight()
                    .padding(start = 16.dp, top = 16.dp, bottom = 24.dp)
            )
        }
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(SettingsGroupGap),
            contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp)
        ) {
            if (cat == null && !twoPane) {
                // SCREEN TITLE & SUBTITLE WITH DISCORD
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = stringResource(R.string.settings_header_title),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = stringResource(R.string.settings_header_subtitle),
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                        
                        val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
                        Button(
                            onClick = { uriHandler.openUri("https://discord.gg/nyFMhq9EFw") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5865F2)),
                            shape = RoundedCornerShape(20.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            modifier = Modifier.height(40.dp)
                        ) {
                            Icon(
                                painter = androidx.compose.ui.res.painterResource(id = R.drawable.ic_discord),
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(stringResource(R.string.settings_discord_label), color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                
                // SEARCH: matches individual settings, not just category titles.
                item {
                    SettingsSearchField(
                        query = settingsQuery,
                        onQueryChange = { settingsQuery = it },
                        onClear = { settingsQuery = "" }
                    )
                }

                // CURRENT DATA SUMMARY CARD
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        border = borderIndicator(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = stringResource(R.string.settings_data_summary_title),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                              ) {
                                StatItem(
                                    label = stringResource(R.string.settings_stat_novels),
                                    value = importedNovels.size.toString(),
                                    modifier = Modifier.weight(1f)
                                )
                                StatItem(
                                    label = stringResource(R.string.settings_stat_websites),
                                    value = websites.size.toString(),
                                    modifier = Modifier.weight(1f)
                                )
                                StatItem(
                                    label = stringResource(R.string.settings_stat_offline_cache),
                                    value = cacheStats.totalSizeFormatted,
                                    subtext = "${cacheStats.fileCount} chapters",
                                    modifier = Modifier.weight(1.2f)
                                )
                            }
                        }
                    }
                }

                val hits = settingsSearchResults(settingsQuery)
                if (settingsQuery.isNotBlank()) {
                    item {
                        SettingsGroup(
                            title = if (hits.isEmpty()) stringResource(R.string.settings_search_no_matches) else hits.size.toString() + " matches"
                        ) {
                            if (hits.isEmpty()) {
                                SettingsRow(
                                    title = stringResource(R.string.settings_search_nothing_found_title),
                                    subtitle = stringResource(R.string.settings_search_nothing_found_subtitle)
                                )
                            } else {
                                hits.forEachIndexed { index, hit ->
                                    if (index > 0) {
                                        SettingsRowDivider()
                                    }
                                    SettingsRow(
                                        title = hit.label,
                                        subtitle = settingsCategoryTitle(hit.category),
                                        icon = hit.category.icon,
                                        showChevron = true,
                                        onClick = {
                                            settingsQuery = ""
                                            activeCategory = hit.category
                                        }
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // HUB CATEGORY ROWS: one glass container, one radius, one row
                    // language, descriptions allowed to wrap, and real lazy items
                    // instead of ten cards composed inside a single item block.
                    items(SettingsCategory.values().toList()) { category ->
                        SettingsGroup {
                            SettingsRow(
                                title = settingsCategoryTitle(category),
                                subtitle = settingsCategoryDesc(category),
                                icon = category.icon,
                                showChevron = true,
                                onClick = { activeCategory = category }
                            )
                        }
                    }
                }
            } else if (cat != null) {
                // DETAILS PANEL VIEW
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!twoPane) {
                            IconButton(onClick = { activeCategory = null }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = stringResource(R.string.action_back),
                                    tint = MaterialTheme.colorScheme.onBackground
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Column {
                            Text(
                                text = settingsCategoryTitle(cat),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = settingsCategoryDesc(cat),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }
                }

                // CATEGORY CORRESPONDING SUB-SECTIONS
                when (cat) {
                    SettingsCategory.APPEARANCE -> {
                        item {
                            AppearanceSettingsSection(readerViewModel = readerViewModel)
                        }
                        item {
                            Spacer(modifier = Modifier.height(12.dp))
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                                border = borderIndicator(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(role = Role.Button) { onOpenFontManager() }
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FontDownload,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = stringResource(R.string.settings_fonts_title),
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = stringResource(R.string.settings_fonts_subtitle),
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.ChevronRight,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                                    )
                                }
                            }
                        }
                    }
                    SettingsCategory.READING -> {
                        item { SettingsSectionLabel(stringResource(R.string.settings_section_reader_layout)) }
                        item {
                            ReaderSettingsSection(
                                readerViewModel = readerViewModel,
                                onOpenFontManager = onOpenFontManager
                            )
                        }
                        item { SettingsSectionLabel(stringResource(R.string.settings_section_tts)) }
                        item {
                            TtsSettingsSection(readerViewModel = readerViewModel)
                        }
                    }
                    SettingsCategory.BACKUP_RESTORE -> {
                        item {
                            BackupSettingsSection(
                                backupLauncher = backupLauncher,
                                restoreLauncher = restoreLauncher,
                                folderPickerLauncher = folderPickerLauncher,
                                singleBackupInfo = singleBackupInfo,
                                onSingleBackupInfoChange = { singleBackupInfo = it },
                                backupLocationType = backupLocationType,
                                onBackupLocationTypeChange = { backupLocationType = it },
                                customFolderPathName = customFolderPathName,
                                onShowAutoRestoreConfirm = { showAutoRestoreConfirmDialog = it }
                            )
                        }
                    }
                    SettingsCategory.LIBRARY -> {
                        item { SettingsSectionLabel(stringResource(R.string.settings_section_chapter_updates)) }
                        item {
                            LibraryUpdatesSettingsSection(onOpenNewChapters = onOpenNewChapters)
                        }
                        // Manual refetch of all Details-page data (keeps reading progress).
                        item {
                            RefetchDetailsSection()
                        }
                        item { SettingsSectionLabel(stringResource(R.string.settings_section_manga_sources)) }
                        item {
                            MangaSourcesSettingsSection()
                        }
                        item {
                            MangaInstalledExtensionsSection()
                        }
                    }
                    SettingsCategory.STORAGE -> {
                        // Opens the real queue screen as an overlay rather than
                        // nesting an 800 line scrollable inside this scroller.
                        item {
                            SettingsGroup(title = stringResource(R.string.settings_group_download_queue)) {
                                SettingsRow(
                                    title = stringResource(R.string.settings_open_download_queue_title),
                                    subtitle = stringResource(R.string.settings_open_download_queue_subtitle),
                                    icon = Icons.Default.Download,
                                    showChevron = true,
                                    onClick = { showDownloadsQueue = true }
                                )
                            }
                        }
                        // FEATURE E29: downloads / storage monitor.
                        item {
                            DownloadsMonitorSection(
                                onOpenDownloadsQueue = { showDownloadsQueue = true }
                            )
                        }
                        // Secondary controls for HOW download work runs:
                        // parallelism, speed ceiling, pacing, retries, Wi-Fi only.
                        item {
                            DownloadSettingsSection()
                        }
                        // FEATURE E32: source & plugin health dashboard.
                        item {
                            SourceHealthSettingsSection()
                        }
                        item {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                border = borderIndicator(),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = stringResource(R.string.settings_local_data_cache_title),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        letterSpacing = 1.sp
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = stringResource(R.string.settings_chapters_cache_size),
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "${cacheStats.fileCount} chapters stored offline (${cacheStats.totalSizeFormatted})",
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Button(
                                            onClick = { showClearConfirmDialog = true },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text(stringResource(R.string.settings_clear_cache), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                border = borderIndicator(),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = stringResource(R.string.settings_per_novel_downloads_title),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        letterSpacing = 1.sp
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))

                                    val currentPerNovel = perNovelStats
                                    if (currentPerNovel == null) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 16.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(24.dp),
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    } else if (currentPerNovel.isEmpty()) {
                                        Text(
                                            text = stringResource(R.string.settings_no_offline_chapters),
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                            modifier = Modifier.padding(vertical = 8.dp)
                                        )
                                    } else {
                                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            currentPerNovel.forEach { item ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.3f))
                                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            text = item.title,
                                                            fontSize = 13.sp,
                                                            fontWeight = FontWeight.SemiBold,
                                                            color = MaterialTheme.colorScheme.onSurface,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                        Spacer(modifier = Modifier.height(2.dp))
                                                        Text(
                                                            text = "${item.fileCount} chapters · ${item.sizeFormatted}",
                                                            fontSize = 11.sp,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                                        )
                                                    }
                                                    IconButton(
                                                        onClick = { selectedForDelete = item },
                                                        modifier = Modifier.size(32.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.Delete,
                                                            contentDescription = stringResource(R.string.settings_delete_cache_for_desc, item.title),
                                                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    SettingsCategory.ADVANCED -> {
                        if (devModeUnlocked) {
                            item {
                                NetworkThrottleSection()
                            }
                        }
                        item {
                            AdvancedSettingsSection(
                                cacheStats = cacheStats,
                                onClearCacheClick = { showClearConfirmDialog = true },
                                crashReports = crashReports,
                                onCrashReportsChange = { crashReports = it },
                                onViewCrashReport = { viewingCrashReport = it }
                            )
                        }
                        item { SettingsSectionLabel(stringResource(R.string.settings_section_about)) }
                        item {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                                border = borderIndicator(),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    var devTapCount by remember { mutableStateOf(0) }
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = stringResource(R.string.settings_about_desc),
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clickable(role = Role.Button) {
                                                if (!devModeUnlocked) {
                                                    devTapCount += 1
                                                    if (devTapCount >= 5) {
                                                        devModeUnlocked = true
                                                        com.lorelight.core.DevLogStore.setDevModeUnlocked(context, true)
                                                        com.lorelight.core.DevLogStore.append(context, "DEV", "Developer mode unlocked")
                                                    }
                                                }
                                            }
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = stringResource(R.string.settings_app_title),
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Version ${com.lorelight.BuildConfig.VERSION_NAME} • Stable Build",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = stringResource(R.string.settings_app_description),
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 18.sp
                                    )
                                    Spacer(modifier = Modifier.height(24.dp))
                                    val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
                                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Button(
                                            onClick = { uriHandler.openUri("https://discord.gg/nyFMhq9EFw") },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5865F2)),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text(stringResource(R.string.settings_join_discord), fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    if (devModeUnlocked) {
                                        Spacer(modifier = Modifier.height(16.dp))
                                        DevLogPanel()
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                item {
                    SettingsPlaceholderPane()
                }
            }
        }
        }

        if (showDownloadsQueue) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                DownloadsQueueScreen(onBack = { showDownloadsQueue = false })
            }
            androidx.activity.compose.BackHandler { showDownloadsQueue = false }
        }
        
        // Modal Loading Indicator during export/import processing
        if (isOperating) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable(enabled = false) {},
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = stringResource(R.string.settings_processing_data),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
        
        // Confirmation dialog for clearing cache
        if (showClearConfirmDialog) {
            LorelightDialog(
                onDismissRequest = { showClearConfirmDialog = false },
                title = { Text(stringResource(R.string.settings_clear_offline_dialog_title), fontWeight = FontWeight.Bold) },
                text = { Text("This will permanently delete ${cacheStats.fileCount} downloaded chapter texts from offline cache, freeing up ${cacheStats.totalSizeFormatted} of space. You will need internet connections to load these chapters next time. Progress is kept.") },
                isDestructive = true,
                confirmButton = {
                    Button(
                        onClick = {
                            showClearConfirmDialog = false
                            val done = deleteChaptersCache(context)
                            if (done) {
                                cacheStats = getCacheStats(context)
                                Toast.makeText(context, context.getString(R.string.settings_toast_cache_cleared), Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, context.getString(R.string.settings_toast_cache_clear_failed), Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text(stringResource(R.string.action_delete), fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showClearConfirmDialog = false }) {
                        Text(stringResource(R.string.action_cancel), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            )
        }

        val toDelete = selectedForDelete
        if (toDelete != null) {
            LorelightDialog(
                onDismissRequest = { selectedForDelete = null },
                title = { Text(stringResource(R.string.settings_delete_downloads_dialog_title), fontWeight = FontWeight.Bold) },
                text = { Text(stringResource(R.string.settings_delete_downloads_body, toDelete.fileCount, toDelete.title)) },
                isDestructive = true,
                confirmButton = {
                    Button(
                        onClick = {
                            val target = toDelete
                            selectedForDelete = null
                            coroutineScope.launch {
                                withContext(Dispatchers.IO) {
                                    val novels = com.lorelight.data.repository.LibraryRepository.loadLibrary(context)
                                    if (target.novelId == "__orphaned__") {
                                        deleteOrphanedCache(context, novels)
                                    } else {
                                        val match = novels.find { it.id == target.novelId }
                                        if (match != null) {
                                            deleteCacheForNovel(context, match)
                                        }
                                    }
                                }
                                cacheStats = getCacheStats(context)
                                val updatedStats = withContext(Dispatchers.IO) {
                                    val novels = com.lorelight.data.repository.LibraryRepository.loadLibrary(context)
                                    getPerNovelCacheStats(context, novels)
                                }
                                perNovelStats = updatedStats
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text(stringResource(R.string.action_delete), fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedForDelete = null }) {
                        Text(stringResource(R.string.action_cancel), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            )
        }
        
        // Confirmation dialog for restoring backup
        if (showRestoreConfirmDialog) {
            LorelightDialog(
                onDismissRequest = { showRestoreConfirmDialog = false },
                title = { Text(stringResource(R.string.settings_confirm_restore_title), fontWeight = FontWeight.Bold) },
                text = { Text("This will safely merge the backup's novels, websites, custom text replacement rules, and custom settings into your current application state. Any current novels and websites will remain completely untouched.") },
                confirmButton = {
                    Button(
                        onClick = {
                            showRestoreConfirmDialog = false
                            isOperating = true
                            coroutineScope.launch {
                                val success = withContext(Dispatchers.IO) {
                                    restoreBackupJson(context, pendingRestoreContent)
                                }
                                isOperating = false
                                if (success) {
                                    onRestoreSuccess()
                                    cacheStats = getCacheStats(context)
                                    Toast.makeText(context, context.getString(R.string.settings_toast_restore_merged), Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, context.getString(R.string.settings_toast_restore_failed), Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text(stringResource(R.string.settings_restore_now), fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showRestoreConfirmDialog = false }) {
                        Text(stringResource(R.string.action_cancel), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            )
        }

        // Confirmation dialog for auto backup restore
        val autoRestoreTarget = showAutoRestoreConfirmDialog
        if (autoRestoreTarget != null) {
            val targetInfo = autoRestoreTarget
            LorelightDialog(
                onDismissRequest = { showAutoRestoreConfirmDialog = null },
                title = { Text(stringResource(R.string.settings_restore_autobackup_dialog_title), fontWeight = FontWeight.Bold) },
                text = { Text("This will restore library progress, custom replacement rules, configured websites and client setup from the daily auto-backup updated on ${targetInfo.dateFormatted}.\n\nYour library will merge safely without losing newer additions.") },
                confirmButton = {
                    Button(
                        onClick = {
                            showAutoRestoreConfirmDialog = null
                            isOperating = true
                            coroutineScope.launch {
                                val success = withContext(Dispatchers.IO) {
                                    try {
                                        val content = if (targetInfo.file != null) {
                                            targetInfo.file.readText()
                                        } else if (targetInfo.uri != null) {
                                            context.contentResolver.openInputStream(targetInfo.uri)?.use { stream ->
                                                stream.bufferedReader().use { it.readText() }
                                            } ?: ""
                                        } else {
                                            ""
                                        }
                                        if (content.isNotEmpty()) {
                                            restoreBackupJson(context, content)
                                        } else {
                                            false
                                        }
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                        false
                                    }
                                }
                                isOperating = false
                                if (success) {
                                    onRestoreSuccess()
                                    cacheStats = getCacheStats(context)
                                    Toast.makeText(context, context.getString(R.string.settings_toast_autobackup_restored), Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, context.getString(R.string.settings_toast_autobackup_restore_failed), Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text(stringResource(R.string.settings_restore_now), fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAutoRestoreConfirmDialog = null }) {
                        Text(stringResource(R.string.action_cancel), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            )
        }

        // Large Dialog to view the Crash Report
        val crashReport = viewingCrashReport
        if (crashReport != null) {
            val report = crashReport
            val metaObj = remember(report) {
                try {
                    if (!report.metadata.isNullOrEmpty()) JSONObject(report.metadata) else null
                } catch (e: Exception) {
                    null
                }
            }
            val copyableContext = remember(report, metaObj) {
                if (metaObj != null) {
                    val logsArr = metaObj.optJSONArray("diagnostic_logs")
                    val logsStr = if (logsArr != null && logsArr.length() > 0) {
                        val sb = java.lang.StringBuilder()
                        for (i in 0 until logsArr.length()) {
                            sb.append(logsArr.optString(i)).append("\n")
                        }
                        sb.toString()
                    } else stringResource(R.string.settings_none_fallback)
                    
                    """
                        App Version: ${metaObj.optString("app_version", "unknown")}
                        Build Type: ${metaObj.optString("build_type", "unknown")}
                        Memory Class: ${metaObj.optString("memory_class", "unknown")}MB
                        Low Memory Mode: ${metaObj.optBoolean("is_low_memory", false)}
                        Device Display info: ${metaObj.optString("device_screen_dp", "unknown")}
                        
                        DIAGNOSTICS LOGS AT CRASH:
                        $logsStr
                    """.trimIndent()
                } else stringResource(R.string.settings_no_context_stored)
            }

            LorelightDialog(
                onDismissRequest = { viewingCrashReport = null },
                title = { Text(stringResource(R.string.settings_diagnostics_title), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error) },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(0.65f)
                            .verticalScroll(androidx.compose.foundation.rememberScrollState())
                    ) {
                        Text(
                            text = stringResource(R.string.settings_primary_message_label),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = report.message,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        Text(
                            text = stringResource(R.string.settings_stacktrace_label),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = report.stackTrace,
                                fontSize = 10.sp,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                                lineHeight = 13.sp
                            )
                        }
                        
                        if (metaObj != null) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = stringResource(R.string.settings_device_metadata_label),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = copyableContext,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            try {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                val reportString = """
                                    == LORELIGHT PREMIUM CRASH REPORT ==
                                    Timestamp: ${report.timestamp}
                                    Message: ${report.message}
                                    Cause: ${report.cause}
                                    Thread: ${report.thread}
                                    $copyableContext
                                    
                                    STACKTRACE:
                                    ${report.stackTrace}
                                """.trimIndent()
                                val clip = android.content.ClipData.newPlainText(context.getString(R.string.settings_crash_report_clip_label), reportString)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, context.getString(R.string.settings_toast_crash_copied), Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, context.getString(R.string.settings_toast_crash_copy_failed), Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.settings_copy_report), fontWeight = FontWeight.Bold)
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { viewingCrashReport = null }) {
                        Text(stringResource(R.string.action_dismiss), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            )
        }
    }
}
