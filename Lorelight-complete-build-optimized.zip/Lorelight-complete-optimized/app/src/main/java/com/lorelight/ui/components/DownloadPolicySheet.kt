package com.lorelight.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.lorelight.R
import com.lorelight.data.download.DownloadPolicy

/**
 * S5: the per-title offline rules, as a dialog.
 *
 * Opens already showing whatever is in force - the title's own rules if it has
 * any, otherwise the live global defaults - so there is no blank state to
 * interpret, and no way to accidentally save an empty policy over a real one.
 *
 * Nothing is written until Save. The edits are held in local state on purpose:
 * writing each toggle straight through would start a download the instant
 * someone tapped "All unread" while they were still deciding.
 */
@Composable
fun DownloadPolicySheet(
    novelId: String,
    novelTitle: String,
    onDismiss: () -> Unit,
    onSaved: () -> Unit = {}
) {
    val context = LocalContext.current

    // remember(novelId) so reopening on a different title never shows the
    // previous title's edits.
    val initial = remember(novelId) { DownloadPolicy.rulesFor(context, novelId) }

    var keepAhead by remember(novelId) { mutableStateOf(initial.keepAhead) }
    var autoNew by remember(novelId) { mutableStateOf(initial.autoNewChapters) }
    var wifiOnly by remember(novelId) { mutableStateOf(initial.wifiOnly) }
    var chargingOnly by remember(novelId) { mutableStateOf(initial.chargingOnly) }
    var cleanupMode by remember(novelId) { mutableStateOf(initial.cleanupMode) }
    var keepLast by remember(novelId) { mutableStateOf(initial.keepLast) }
    var protectMarked by remember(novelId) { mutableStateOf(initial.protectMarked) }
    var quotaMb by remember(novelId) { mutableStateOf(initial.quotaMb) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(stringResource(R.string.offline_policy_title))
                Text(
                    text = novelTitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // ---- keep ahead ----------------------------------------
                PolicyLabel(stringResource(R.string.offline_policy_keep_ahead))
                Text(
                    text = stringResource(R.string.offline_policy_keep_ahead_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DownloadPolicy.KEEP_AHEAD_CHOICES.forEach { choice ->
                        FilterChip(
                            selected = keepAhead == choice,
                            onClick = { keepAhead = choice },
                            label = { Text(DownloadPolicy.keepAheadLabel(choice)) }
                        )
                    }
                }

                Spacer(Modifier.height(14.dp))

                PolicySwitchRow(
                    label = stringResource(R.string.offline_policy_auto_new),
                    checked = autoNew,
                    onCheckedChange = { autoNew = it }
                )

                Spacer(Modifier.height(14.dp))
                PolicyLabel(stringResource(R.string.offline_policy_conditions))
                PolicySwitchRow(
                    label = stringResource(R.string.offline_policy_wifi_only),
                    checked = wifiOnly,
                    onCheckedChange = { wifiOnly = it }
                )
                PolicySwitchRow(
                    label = stringResource(R.string.offline_policy_charging_only),
                    checked = chargingOnly,
                    onCheckedChange = { chargingOnly = it }
                )

                Spacer(Modifier.height(14.dp))
                PolicyLabel(stringResource(R.string.offline_policy_cleanup))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DownloadPolicy.CLEANUP_CHOICES.forEach { mode ->
                        FilterChip(
                            selected = cleanupMode == mode,
                            onClick = { cleanupMode = mode },
                            label = { Text(DownloadPolicy.cleanupLabel(mode, keepLast)) }
                        )
                    }
                }
                if (cleanupMode == DownloadPolicy.CLEANUP_KEEP_LAST) {
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(3, 5, 10, 20).forEach { n ->
                            FilterChip(
                                selected = keepLast == n,
                                onClick = { keepLast = n },
                                label = { Text(n.toString()) }
                            )
                        }
                    }
                }

                Spacer(Modifier.height(6.dp))
                PolicySwitchRow(
                    label = stringResource(R.string.offline_policy_protect),
                    checked = protectMarked,
                    onCheckedChange = { protectMarked = it }
                )

                Spacer(Modifier.height(14.dp))
                PolicyLabel(stringResource(R.string.offline_policy_quota))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        DownloadPolicy.QUOTA_UNLIMITED,
                        100,
                        250,
                        500
                    ).forEach { mb ->
                        FilterChip(
                            selected = quotaMb == mb,
                            onClick = { quotaMb = mb },
                            label = {
                                Text(
                                    if (mb == DownloadPolicy.QUOTA_UNLIMITED) {
                                        stringResource(R.string.offline_policy_quota_none)
                                    } else {
                                        "$mb MB"
                                    }
                                )
                            }
                        )
                    }
                }

                Spacer(Modifier.height(10.dp))
                Text(
                    text = if (initial.managed) {
                        stringResource(R.string.offline_policy_source_title)
                    } else {
                        stringResource(R.string.offline_policy_source_global)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                DownloadPolicy.setRulesFor(
                    context = context,
                    novelId = novelId,
                    rules = initial.copy(
                        keepAhead = keepAhead,
                        autoNewChapters = autoNew,
                        wifiOnly = wifiOnly,
                        chargingOnly = chargingOnly,
                        cleanupMode = cleanupMode,
                        keepLast = keepLast,
                        protectMarked = protectMarked,
                        quotaMb = quotaMb
                    )
                )
                onSaved()
                onDismiss()
            }) {
                Text(stringResource(R.string.offline_policy_save))
            }
        },
        dismissButton = {
            Row {
                // Only worth offering when there is an override to drop.
                if (initial.managed) {
                    TextButton(onClick = {
                        DownloadPolicy.clearRulesFor(context, novelId)
                        onSaved()
                        onDismiss()
                    }) {
                        Text(stringResource(R.string.offline_policy_use_global))
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text(stringResource(R.string.offline_policy_cancel))
                }
            }
        }
    )
}

@Composable
private fun PolicyLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurface
    )
}

@Composable
private fun PolicySwitchRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.fillMaxWidth(0.78f)
        )
        Spacer(Modifier.fillMaxWidth(0.02f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
