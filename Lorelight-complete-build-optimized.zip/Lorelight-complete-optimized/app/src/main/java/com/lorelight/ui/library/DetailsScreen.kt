package com.lorelight.ui.library

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.R
import androidx.compose.ui.res.stringResource
import com.lorelight.crawler.CrawlerDownloadDialog
import com.lorelight.crawler.DownloadMode
import com.lorelight.data.model.Novel
import com.lorelight.data.local.CoverStorage
import com.lorelight.manga.ui.MangaCoverImage
import com.lorelight.ui.components.NovelCoverImage
import com.lorelight.ui.components.LorelightEmpty
import com.lorelight.ui.components.LorelightLoading
import com.lorelight.ui.components.LoadingShape
import com.lorelight.ui.theme.getThemedButtonProps
import com.lorelight.util.ChapterNumbering
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch


private val Novel.isManga: Boolean get() = pluginId?.let { com.lorelight.manga.util.MangaNamingUtils.isMangaPluginId(it) } == true
private val Novel.mangaSourceId: Long? get() = pluginId?.let { com.lorelight.manga.util.MangaNamingUtils.toSourceId(it) }

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun DetailsScreen(
    novel: Novel?,
    onBack: () -> Unit,
    onUpdateCurrentChapter: (Novel, Int, String) -> Unit,
    onReadClick: () -> Unit,
    onDownloadWhole: (Novel) -> Unit = {},
    onMigrated: (Novel) -> Unit = {},
    heroImageRes: Int = R.drawable.darklibrarygreen,
    isLoadingDetails: Boolean = false,
    isInLibrary: Boolean = false,
    onOpenInBrowser: () -> Unit = {},
    onToggleLibrary: () -> Unit = {}
) {
    // The currently open/resumed chapter's own page on the source site, for
    // sharing. Falls back to the novel's landing page when there is no
    // recorded chapter yet (nothing read, or an offline-only import).
    val chapterWebUrl = remember(novel?.id, novel?.currentChapterIndex, novel?.chapterUrls, novel?.sourceUrl) {
        val idx = novel?.currentChapterIndex?.takeIf { it >= 0 } ?: 0
        novel?.chapterUrls?.getOrNull(idx) ?: novel?.sourceUrl
    }

    if (novel == null) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Filled.MenuBook,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = stringResource(R.string.details_select_novel_title),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = stringResource(R.string.details_select_novel_body),
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 32.dp)
                )
            }
        }
        return
    }

    val context = androidx.compose.ui.platform.LocalContext.current
    var activeDownloadMode by remember(novel.id) { mutableStateOf<DownloadMode?>(null) }
    var showDownloadMenu by remember { mutableStateOf(false) }

    // Manual "check for new chapters" state, hoisted to the top of DetailsScreen
    // so the small hero refresh icon AND the big Update action button below
    // share one spinner and one result toast instead of fighting each other.
    // This path handles plugin novels: checkForNewChapters -> (pluginId != null)
    // -> checkForNewPluginChapters, which re-reads the chapter list via the JS plugin.
    val checkScope = rememberCoroutineScope()
    var isCheckingNew by remember(novel.id) { mutableStateOf(false) }
    var newChaptersMsg by remember(novel.id) { mutableStateOf<String?>(null) }
    var showMigrateDialog by remember(novel.id) { mutableStateOf(false) }
    // S5: per-title offline rules. Keyed on novel.id like the migrate flag so
    // opening a different title never inherits the previous one's open state.
    var showPolicySheet by remember(novel.id) { mutableStateOf(false) }
    // S5: "5 chapters ready, next 5 queued" status line for this title.
    // Re-evaluated whenever the novel id or chapter count changes (a sweep
    // just ran and may have queued more) so the row is always fresh.
    var offlineSummaryText by remember(novel.id) { mutableStateOf<String?>(null) }
    LaunchedEffect(novel.id, novel.chapters.size) {
        offlineSummaryText = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            com.lorelight.data.download.DownloadPolicyScheduler.offlineSummary(context, novel)
        }
    }
    val runChapterCheck: () -> Unit = {
        if (!isCheckingNew) {
            isCheckingNew = true
            newChaptersMsg = null
            checkScope.launch {
                val msg = try {
                    val added = com.lorelight.service.NovelImportManager.checkForNewChapters(context, novel.id)
                    if (added > 0) stringResource(R.string.details_new_chapters_added, added.toString()) else stringResource(R.string.details_no_new_chapters)
                } catch (e: Exception) {
                    stringResource(R.string.details_check_failed)
                }
                isCheckingNew = false
                newChaptersMsg = msg
                kotlinx.coroutines.delay(3500)
                newChaptersMsg = null
            }
        }
    }

    if (showPolicySheet) {
        com.lorelight.ui.components.DownloadPolicySheet(
            novelId = novel.id,
            novelTitle = novel.title,
            onDismiss = { showPolicySheet = false }
        )
    }

    activeDownloadMode?.let { mode ->
        CrawlerDownloadDialog(
            novel = novel,
            mode = mode,
            onDismiss = { activeDownloadMode = null }
        )
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .pointerInput(Unit) {
                detectTapGestures { /* consume taps on empty areas; block pass-through */ }
            },
        contentAlignment = Alignment.TopCenter
    ) {
        val screenHeight = maxHeight
        // MOBILE/TABLET SPLIT. The hero banner cap + top-crop alignment below
        // were introduced to fix a tablet-only issue (oversized hero pushing
        // the cover row down, then a cropped-looking top edge once the hero
        // was capped). Phones never had that problem at the old uncapped 33%
        // height, so only tablets use the capped height + top-anchored crop;
        // phones go back to the original uncapped height + center crop.
        val configuration = androidx.compose.ui.platform.LocalConfiguration.current
        val isTablet = configuration.screenWidthDp >= 600
        // TABLET GAP FIX. heroHeight used to be a flat 33% of the full screen
        // height with no ceiling, so on tall tablet screens it grew far past
        // what the fixed-size cover art (157.dp) needed. The cover row is
        // positioned inside this hero block by a percentage of heroHeight, so
        // an oversized hero pushed the cover row down/around inside a much
        // bigger box than it filled, leaving a visible empty gap between the
        // bottom of the cover and the Play / Add to Library / Open in Browser
        // row that follows. Capping heroHeight keeps the hero-to-cover-to
        // -button-row proportions the same on tablets. Phones use the
        // original uncapped 33% height (previous mobile hero banner setting).
        val heroHeight = if (isTablet) {
            (screenHeight * 0.33f).coerceAtMost(260.dp)
        } else {
            screenHeight * 0.33f
        }
        val heroFadeStart = ((heroHeight * 0.7f + 157.dp * 0.04f) / heroHeight).coerceIn(0f, 0.98f)
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Image(
                    painter = painterResource(id = heroImageRes),
                    contentDescription = stringResource(R.string.details_hero_image_desc),
                    contentScale = ContentScale.Crop,
                    // TOP-CROP FIX (tablets only). ContentScale.Crop defaults
                    // to centering the image, so cropping was taken equally
                    // off the top AND bottom. Once heroHeight was capped to
                    // keep tablets from ballooning, that smaller visible
                    // window meant more of the image had to be cropped away,
                    // and centered cropping cut straight into the top of the
                    // artwork -- the screen looked like it "started" partway
                    // down the banner. Aligning to TopCenter on tablets crops
                    // only from the bottom, so the top edge of the hero art is
                    // always the first thing visible there. Phones never had
                    // an oversized hero, so they keep the original center
                    // crop (previous mobile hero banner setting).
                    alignment = if (isTablet) Alignment.TopCenter else Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(heroHeight)
                        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                        .drawWithContent {
                            drawContent()
                            drawRect(
                                brush = Brush.verticalGradient(
                                    colorStops = arrayOf(
                                        0f to Color.Black,
                                        heroFadeStart to Color.Black,
                                        1f to Color.Transparent
                                    )
                                ),
                                blendMode = BlendMode.DstIn
                            )
                        }
                )

                // TOP SCRIM REMOVED, per request: the hero banner is shown as
                // a plain image background with no extra tint/blur/gradient
                // layer over it. (Previously a soft surface-colour fade sat
                // over the top ~40% of the hero to give the back/action icons
                // contrast; removed entirely.)

                val coverWidth = 110.dp
                val coverHeight = 157.dp

                // COVER-DOWN FIX (tablets only). Cover/title/author/genre
                // block starts at 75% of the hero banner's height on tablets,
                // per request -- this moves the whole block down so it no
                // longer sits over the upper part of the hero art that should
                // stay fully visible there. Because heroHeight is capped on
                // tablets, the Row's own content height (overlapPadding +
                // coverHeight + bottom padding) still ends up taller than
                // heroHeight itself, so the hero Box keeps sizing itself to
                // that Row -- the button row right below still starts
                // immediately after the cover with the same constant 16.dp
                // gap, on every device.
                //
                // Phones go back to the original fixed-offset formula (the
                // "normal"/previous mobile setting): the cover hangs a
                // constant 44.dp below the bottom of the uncapped hero image,
                // rather than being tied to a percentage of hero height.
                val coverHangBelowHero = 44.dp
                val overlapPadding = if (isTablet) {
                    heroHeight * 0.75f
                } else {
                    heroHeight - coverHeight + coverHangBelowHero
                }
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = overlapPadding, start = 5.dp, end = 24.dp, bottom = 16.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(coverWidth, coverHeight)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        val coverChoice = remember(novel.id) {
                            val localCoverFile = CoverStorage.coverFile(context, novel.id)
                            val hasLocalCover = localCoverFile.exists() && localCoverFile.length() > 0
                            val coverUrl = novel.coverImageBase64
                            val isExplicitLocal = coverUrl != null && (coverUrl.startsWith("file://") || !coverUrl.startsWith("http", ignoreCase = true))

                            when {
                                hasLocalCover -> "local:${localCoverFile.absolutePath}"
                                isExplicitLocal -> "explicit"
                                novel.isManga && coverUrl != null -> "manga"
                                else -> "novel"
                            }
                        }
                        val remotePlaceholderKey = remember(novel.id) {
                            novel.coverImageBase64?.takeIf { it.startsWith("http://", ignoreCase = true) || it.startsWith("https://", ignoreCase = true) }
                        }

                        when {
                            coverChoice.startsWith("local:") -> {
                                NovelCoverImage(
                                    coverBase64 = "file://${coverChoice.removePrefix("local:")}",
                                    title = novel.title,
                                    placeholderKey = remotePlaceholderKey,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            coverChoice == "explicit" -> {
                                NovelCoverImage(
                                    coverBase64 = novel.coverImageBase64,
                                    title = novel.title,
                                    placeholderKey = remotePlaceholderKey,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            coverChoice == "manga" -> {
                                MangaCoverImage(
                                    coverUrl = novel.coverImageBase64,
                                    sourceId = novel.mangaSourceId,
                                    title = novel.title,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            else -> {
                                NovelCoverImage(
                                    coverBase64 = novel.coverImageBase64,
                                    title = novel.title,
                                    placeholderKey = remotePlaceholderKey,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.width(16.dp))
                    
                    Column(
                        // BOTTOM-ANCHORED FIX. The title/author/genre block is
                        // now exactly as tall as the cover art beside it and
                        // lays its content out from the BOTTOM up, so the
                        // genre chips' row always lines up with the bottom
                        // edge of the cover image, the author line sits just
                        // above that, and the title sits above the author --
                        // regardless of how many lines the title ends up
                        // using.
                        modifier = Modifier
                            .weight(1f)
                            .height(coverHeight),
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        // NOVEL / MANGA TITLE: TWO LINES RESERVED, BUT A
                        // ONE-LINE NAME GROWS TO FILL THAT SPACE.
                        //
                        // maxLines alone only capped the title, so the block's
                        // height depended on how long the name happened to be.
                        // "I'm the Only Living Person in This Chat Group?" wrapped
                        // to two lines and filled the header, while "The First
                        // Order" took one line at the same small size and left a
                        // blank second line under it.
                        //
                        // We measure once at the base size with room for 2 lines.
                        // If the title only needed 1 of those lines, we bump the
                        // font size up and re-render as a single line so it fills
                        // the same two-line height instead of sitting small with
                        // dead space beneath it. If that bigger size no longer
                        // fits the width, we fall back to the safe 2-line/base-size
                        // rendering. Titles that genuinely need two lines at base
                        // size are unaffected.
                        //
                        // This is the title only. Chapter names in the list are a
                        // different thing and stay at one line each.
                        val baseTitleFontSize = 15.sp
                        val expandedTitleFontSize = 20.sp
                        var titleFitsOneLine by remember(novel.id) { mutableStateOf<Boolean?>(null) }
                        // THEME-TINTED TITLE. A flat onSurface title read the
                        // same in every theme. Blending in a slight amount of
                        // the current theme's own `primary` hue gives each
                        // theme its own subtle title tint (a soft olive-green
                        // whisper for the Forest theme, a soft rose whisper
                        // for Satin Pink, a soft blood-red whisper for Blood
                        // Red, and so on) without turning the title into a
                        // loud, hard-to-read accent color.
                        // `primary` is already chosen per-mode for contrast --
                        // a light, bright tone in dark mode and a deep, dark
                        // tone in light mode -- so blending a small amount of
                        // it into `onSurface` (which is likewise light-on-dark
                        // or dark-on-light already) naturally keeps the tinted
                        // title lighter in dark mode and darker in light mode.
                        val titleTintColor = lerp(
                            MaterialTheme.colorScheme.onSurface,
                            MaterialTheme.colorScheme.primary,
                            0.22f
                        )
                        Text(
                            text = novel.title,
                            fontSize = if (titleFitsOneLine == true) expandedTitleFontSize else baseTitleFontSize,
                            fontWeight = FontWeight.Bold,
                            color = titleTintColor,
                            minLines = if (titleFitsOneLine == true) 1 else 2,
                            maxLines = if (titleFitsOneLine == true) 1 else 2,
                            overflow = TextOverflow.Ellipsis,
                            onTextLayout = { result ->
                                when (titleFitsOneLine) {
                                    null -> titleFitsOneLine = result.lineCount <= 1 && !result.isLineEllipsized(0)
                                    true -> if (result.lineCount > 1 || result.isLineEllipsized(0)) titleFitsOneLine = false
                                    false -> {}
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                        
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        if (novel.author.isNotBlank()) {
                            // THEME-TINTED AUTHOR. Same treatment as the title
                            // above -- blend a little of the theme's `primary`
                            // into `onSurfaceVariant` instead of using a flat
                            // neutral grey, so the author line also carries a
                            // touch of the active theme's colour in both light
                            // and dark mode, while staying legible as secondary
                            // text.
                            val authorTintColor = lerp(
                                MaterialTheme.colorScheme.onSurfaceVariant,
                                MaterialTheme.colorScheme.primary,
                                0.22f
                            )
                            Text(
                                text = "By ${novel.author}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = authorTintColor,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.fillMaxWidth()
                            )
                            
                            Spacer(modifier = Modifier.height(8.dp))
                        } else {
                            Spacer(modifier = Modifier.height(6.dp))
                        }
                        
                        val genresToDisplay = novel.genres
                            .filter { g -> !g.trim().equals("fantasy novel", ignoreCase = true) }
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 22.dp)
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (novel.isManga) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f))
                                        .border(0.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = stringResource(R.string.details_manga_badge),
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            genresToDisplay.forEach { genre ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f))
                                        .border(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = genre,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }

                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .statusBarsPadding()
                        .padding(top = 16.dp, start = 16.dp)
                        .size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.action_back),
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // --- Manual "check for new chapters" button (top-right) ---
                // State lives at the top of DetailsScreen now, so the Update
                // action button in the row below drives the same spinner.

                // L-shaped action cluster. The top arm runs Save EPUB / Share /
                // Refresh with Refresh at the corner, and the vertical arm hangs
                // straight below Refresh with download and (novels only) source
                // transfer. horizontalAlignment = End is what keeps the vertical
                // arm pinned under the corner instead of centred on the widest
                // row. No circles and no container: contrast comes from the top
                // scrim above plus full-strength icon tint at a larger size,
                // which keeps the hero art clean.
                Column(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .statusBarsPadding()
                        .padding(top = 16.dp, end = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { activeDownloadMode = DownloadMode.SAVE_EPUB },
                            modifier = Modifier
                                .size(40.dp)
                        ) {
                            Icon(Icons.Filled.Save, contentDescription = stringResource(R.string.details_save_epub_desc), tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(22.dp))
                        }

                        IconButton(
                            onClick = {
                                val shareText = buildString {
                                    append(novel.title)
                                    val shareUrl = chapterWebUrl ?: novel.sourceUrl
                                    shareUrl?.let { append("\n"); append(it) }
                                }
                                val sendIntent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(android.content.Intent.EXTRA_SUBJECT, novel.title)
                                    putExtra(android.content.Intent.EXTRA_TEXT, shareText)
                                }
                                context.startActivity(android.content.Intent.createChooser(sendIntent, context.getString(R.string.details_share_via)))
                            },
                            modifier = Modifier
                                .size(40.dp)
                        ) {
                            Icon(Icons.Filled.Share, contentDescription = stringResource(R.string.details_share_desc), tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(22.dp))
                        }

                        IconButton(
                            onClick = { runChapterCheck() },
                            modifier = Modifier
                                .size(40.dp)
                        ) {
                            if (isCheckingNew) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Filled.Refresh,
                                    contentDescription = stringResource(R.string.details_check_new_chapters_desc),
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }

                    Box {
                        IconButton(
                            onClick = { showDownloadMenu = true },
                            modifier = Modifier
                                .size(40.dp)
                        ) {
                            Icon(Icons.Filled.Download, contentDescription = stringResource(R.string.details_download_desc), tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(22.dp))
                        }
                        DropdownMenu(
                            expanded = showDownloadMenu,
                            onDismissRequest = { showDownloadMenu = false },
                            modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.details_download_whole), color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp) },
                                onClick = { showDownloadMenu = false; onDownloadWhole(novel) }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.details_select_chapters), color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp) },
                                onClick = { showDownloadMenu = false; activeDownloadMode = DownloadMode.SELECT_DOWNLOAD }
                            )
                            // S5: the automatic route, sitting beside the two
                            // manual ones it is meant to replace for anyone
                            // tired of repeating them.
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.details_offline_settings), color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp) },
                                onClick = { showDownloadMenu = false; showPolicySheet = true }
                            )
                        }
                    }

                    // Transfer this novel to a different source. Hidden for
                    // manga, which runs on the extension pipeline rather than
                    // the novel JS plugins the migrator searches.
                    if (!novel.isManga) {
                        IconButton(
                            onClick = { showMigrateDialog = true },
                            modifier = Modifier
                                .size(40.dp)
                        ) {
                            Icon(Icons.Filled.SwapHoriz, contentDescription = stringResource(R.string.details_transfer_source_desc), tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(22.dp))
                        }
                    }
                }

                if (showMigrateDialog) {
                    com.lorelight.browse.migrate.MigrateSourceDialog(
                        novels = listOf(novel),
                        onDismiss = { showMigrateDialog = false },
                        onApplied = { migratedList ->
                            migratedList.firstOrNull()?.let { onMigrated(it) }
                            showMigrateDialog = false
                        }
                    )
                }

                newChaptersMsg?.let { msg ->
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .statusBarsPadding()
                            .padding(top = 58.dp, end = 52.dp),
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        tonalElevation = 4.dp,
                        shadowElevation = 6.dp
                    ) {
                        Text(
                            text = msg,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                .semantics { liveRegion = LiveRegionMode.Polite }
                        )
                    }
                }
            }
            
            // Chapter-list state: user can expand the chapter pane to 73% width
            // via the expand toggle in the chapter toolbar so long titles aren't cut off.
            val chapterListState = rememberLazyListState()
            var chaptersExpanded by remember { mutableStateOf(false) }

            val leftPaneWeight by animateFloatAsState(
                targetValue = if (chaptersExpanded) 0.27f else 0.45f,
                animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
                label = "detailsLeftPane"
            )
            val rightPaneWeight by animateFloatAsState(
                targetValue = if (chaptersExpanded) 0.73f else 0.65f,
                animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing),
                label = "detailsRightPane"
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .navigationBarsPadding()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(leftPaneWeight)
                        .padding(horizontal = 16.dp)
                ) {
                    var showDownloadDialog by remember { mutableStateOf(false) }

                    val isNew = novel.currentChapter == novel.chapters.firstOrNull()
                    val (isPremiumBtn, btnGrad, btnContent) = getThemedButtonProps(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.onPrimaryContainer)
                    if (isLoadingDetails) {
                        ShimmerBox(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                        )
                    } else if (novel.pluginId != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            DetailsCircleIcon(
                                icon = if (isInLibrary) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                                desc = if (isInLibrary) stringResource(R.string.details_remove_from_library) else stringResource(R.string.details_add_to_library),
                                onClick = onToggleLibrary,
                                highlighted = isInLibrary,
                                modifier = Modifier.weight(1f)
                            )
                            DetailsCircleIcon(
                                icon = Icons.Filled.PlayArrow,
                                desc = if (isNew) stringResource(R.string.details_start) else stringResource(R.string.details_continue),
                                onClick = onReadClick,
                                highlighted = true,
                                modifier = Modifier.weight(1f)
                            )
                            DetailsCircleIcon(
                                icon = Icons.Filled.Language,
                                desc = stringResource(R.string.details_open_in_browser),
                                onClick = onOpenInBrowser,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    } else {
                    Button(
                        onClick = onReadClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .then(
                                if (isPremiumBtn) {
                                    Modifier.background(btnGrad, RoundedCornerShape(12.dp))
                                } else {
                                    Modifier.background(Color.Transparent, RoundedCornerShape(12.dp))
                                }
                            )
                            .border(
                                1.dp,
                                if (isPremiumBtn) Color.Transparent else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                RoundedCornerShape(12.dp)
                            ),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isPremiumBtn) Color.Transparent else MaterialTheme.colorScheme.primaryContainer,
                            contentColor = btnContent
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(if (isNew) stringResource(R.string.details_start) else stringResource(R.string.details_continue), fontWeight = FontWeight.Bold)
                    }
                    }
                    
                    if (showDownloadDialog) {
                        CrawlerDownloadDialog(
                            novel = novel,
                            mode = DownloadMode.SAVE_EPUB,
                            onDismiss = { showDownloadDialog = false }
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = stringResource(R.string.details_about_title),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    val statusText = if (novel.status == "Importing") {
                        "Importing (${novel.chapters.size} / ${novel.totalChapters} chapters)"
                    } else {
                        novel.status
                    }
                    if (isLoadingDetails) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            repeat(4) {
                                ShimmerBox(
                                    modifier = Modifier
                                        .fillMaxWidth(0.7f)
                                        .height(12.dp)
                                )
                            }
                        }
                    } else {
                        AboutItemInline(label = stringResource(R.string.details_status_label), value = statusText)
                        AboutItemInline(label = stringResource(R.string.details_author_label), value = novel.author)
                        AboutItemInline(label = "Chapters", value = "${novel.totalChapters}")
                        AboutItemInline(label = stringResource(R.string.details_language_label), value = novel.language)
                        // S5: only shown when an automatic download policy is active
                        offlineSummaryText?.let {
                            AboutItemInline(label = stringResource(R.string.details_offline_label), value = it)
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(20.dp))
                    
                    Text(
                        text = stringResource(R.string.details_description_title),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Column(modifier = Modifier.fillMaxWidth().animateContentSize().weight(1f)) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f, fill = false)
                                .verticalScroll(rememberScrollState())
                        ) {
                            if (isLoadingDetails) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    repeat(6) {
                                        ShimmerBox(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(12.dp)
                                        )
                                    }
                                }
                            } else {
                                Text(
                                    text = novel.description,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                                    lineHeight = 17.sp,
                                    maxLines = Int.MAX_VALUE,
                                    overflow = TextOverflow.Clip
                                )
                            }
                        }
                    }
                }
                
                VerticalDivider(
                    modifier = Modifier
                        .fillMaxHeight()
                        .padding(horizontal = 4.dp),
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                    thickness = 1.dp
                )
                
                // The pane itself is bare again. Glassing the whole column made
                // one big slab; the glass belongs on each chapter box instead,
                // which is what ChapterListItem does now.
                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(rightPaneWeight)
                        .padding(start = 4.dp, end = 16.dp, bottom = 8.dp)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    var chapterSearchQuery by remember { mutableStateOf("") }

                    // Sort state: mode + direction
                    var sortByChapter by remember(novel.id) { mutableStateOf(false) } // false = By source, true = By chapter
                    var sortDescending by remember(novel.id) { mutableStateOf(false) }

                    // Which chapters are cached (downloaded) on disk. Computed off the main thread.
                    var downloadedIndices by remember(novel.id) { mutableStateOf<Set<Int>>(emptySet()) }

                    // mihon parity: per-chapter read state, so finished chapters can
                    // dull out and unfinished ones can advertise their resume page.
                    // Reloads whenever the reader (or this screen) records a change.
                    // CHAPTER LIST v2. The backend behind this list was
                    // replaced outright. Read marks now live in
                    // ChapterReadStore, keyed by a chapter's URL rather than by
                    // its POSITION in the list, and they arrive as a StateFlow
                    // instead of a snapshot re-read whenever a counter moved.
                    //
                    // That kills both faults you were seeing:
                    //  - a new chapter landing at the top of a source list can no
                    //    longer slide every dim mark one chapter off, because
                    //    nothing is stored against an index any more;
                    //  - a mark appears the instant it is recorded, because the
                    //    screen collects the store instead of polling it.
                    val chapterStateFlow = remember(novel.id) {
                        com.lorelight.data.chapters.ChapterReadStore.observe(context, novel.id)
                    }
                    val chapterState by chapterStateFlow.collectAsState()
                    val chapterKeys = remember(novel.id, novel.chapters, novel.chapterUrls) {
                        novel.chapters.indices.map {
                            com.lorelight.data.chapters.ChapterReadStore.keyFor(novel, it)
                        }
                    }
                    // DETAILS RESUME FIX. This screen worked out "where you are"
                    // from the mutable currentChapter NAME on the novel row --
                    // the same field that goes stale and made the reader reopen
                    // chapter 12 when you were on 23. The chapters table is
                    // stamped on every page turn, so it is the same authority the
                    // reader now uses. -1 means nothing recorded (or a text
                    // novel, which does not use the chapters table): the old
                    // name lookup below stays in charge in that case.
                    // Where you are is a RECORDED FACT: the store stamps the
                    // chapter's key every time one is opened, from either reader
                    // and from this list. No load, no polling, no guessing.
                    val recordedChapterIdx = remember(chapterState.currentKey, chapterKeys) {
                        chapterKeys.indexOfFirst { it.isNotEmpty() && it == chapterState.currentKey }
                    }
                    // Chapter menu target (long-press), mihon's per-chapter actions.
                    var chapterMenuIndex by remember(novel.id) { mutableStateOf<Int?>(null) }
                    val cacheTrigger by com.lorelight.crawler.CrawlerEngine.cacheUpdateTrigger.collectAsState()
                    LaunchedEffect(novel.id, novel.chapterUrls, activeDownloadMode, cacheTrigger) {
                        downloadedIndices = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                            novel.chapterUrls.withIndex()
                                .filter { (_, url) -> url.isNotEmpty() && com.lorelight.crawler.CrawlerEngine.isChapterCached(context, url) }
                                .map { it.index }
                                .toSet()
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = stringResource(R.string.details_search_icon_desc),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            BasicTextField(
                                value = chapterSearchQuery,
                                onValueChange = { chapterSearchQuery = it },
                                singleLine = true,
                                textStyle = TextStyle(
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 12.sp
                                ),
                                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                                modifier = Modifier.fillMaxWidth(),
                                decorationBox = { innerTextField ->
                                    if (chapterSearchQuery.isEmpty()) {
                                        Text(
                                            stringResource(R.string.details_search_placeholder),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                            fontSize = 12.sp
                                        )
                                    }
                                    innerTextField()
                                }
                            )
                        }
                        
                        Spacer(modifier = Modifier.width(4.dp))

                        IconButton(
                            onClick = { chaptersExpanded = !chaptersExpanded },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (chaptersExpanded) Icons.Filled.UnfoldLess else Icons.Filled.UnfoldMore,
                                contentDescription = if (chaptersExpanded) stringResource(R.string.details_collapse_chapter_pane_desc) else stringResource(R.string.details_expand_chapter_pane_desc),
                                tint = if (chaptersExpanded) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        
                        var showMenu by remember { mutableStateOf(false) }
                        Box {
                            IconButton(
                                onClick = { showMenu = true },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.MoreVert,
                                    contentDescription = stringResource(R.string.details_chapter_options_desc),
                                    tint = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            
                            DropdownMenu(
                                expanded = showMenu,
                                onDismissRequest = { showMenu = false },
                                modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Text(
                                    stringResource(R.string.details_sort_chapters),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.details_by_source), color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp) },
                                    trailingIcon = {
                                        if (!sortByChapter) {
                                            Icon(
                                                imageVector = if (sortDescending) Icons.Filled.ArrowDownward else Icons.Filled.ArrowUpward,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    },
                                    onClick = {
                                        if (!sortByChapter) {
                                            sortDescending = !sortDescending
                                        } else {
                                            sortByChapter = false
                                            sortDescending = false // By source defaults to normal order
                                        }
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text(stringResource(R.string.details_by_chapter), color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp) },
                                    trailingIcon = {
                                        if (sortByChapter) {
                                            Icon(
                                                imageVector = if (sortDescending) Icons.Filled.ArrowDownward else Icons.Filled.ArrowUpward,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    },
                                    onClick = {
                                        if (sortByChapter) {
                                            sortDescending = !sortDescending
                                        } else {
                                            sortByChapter = true
                                            sortDescending = true // By chapter defaults to descending (down)
                                        }
                                    }
                                )
                                Text(
                                    stringResource(R.string.details_reading_progress),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            stringResource(R.string.details_mark_all_read),
                                            color = MaterialTheme.colorScheme.onSurface,
                                            fontSize = 13.sp
                                        )
                                    },
                                    onClick = {
                                        showMenu = false
                                        com.lorelight.manga.progress.MangaReadProgress
                                            .setAllRead(context, novel, true)
                                    }
                                )
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            stringResource(R.string.details_mark_all_unread),
                                            color = MaterialTheme.colorScheme.onSurface,
                                            fontSize = 13.sp
                                        )
                                    },
                                    onClick = {
                                        showMenu = false
                                        com.lorelight.manga.progress.MangaReadProgress
                                            .setAllRead(context, novel, false)
                                    }
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    val filteredChapters = remember(novel.chapters, novel.chapterNumbers, novel.chapterUrls, chapterSearchQuery, sortByChapter, sortDescending) {
                        novel.chapters.indices
                            .map { index ->
                                val name = novel.chapters[index]
                                val resolvedNum = ChapterNumbering.resolveChapterNumber(novel, index, name)
                                val displayLabel = ChapterNumbering.formatDisplayLabel(resolvedNum, name)
                                Triple(index, resolvedNum, displayLabel)
                            }
                            .filter { (origIndex, _, displayLabel) ->
                                val rawName = novel.chapters.getOrNull(origIndex) ?: displayLabel
                                chapterSearchQuery.isEmpty() ||
                                    displayLabel.contains(chapterSearchQuery, ignoreCase = true) ||
                                    rawName.contains(chapterSearchQuery, ignoreCase = true)
                            }
                            .let { list ->
                                val sorted = if (sortByChapter) {
                                    list.sortedWith(
                                        compareBy<Triple<Int, Float?, String>, Float?>(nullsLast()) { it.second }
                                            .thenBy { it.first }
                                    )
                                } else {
                                    list.sortedBy { it.first }
                                }
                                if (sortDescending) sorted.reversed() else sorted
                            }
                    }
                    
                    val currentOrigIndex = remember(recordedChapterIdx, novel.currentChapterIndex, novel.currentChapter, novel.chapters, novel.chapterUrls) {
                        // RESUME REDESIGN. Order of authority:
                        //   1. the chapters table, stamped on every page turn
                        //   2. currentChapterIndex on the novel row
                        //   3. the old name/URL lookup
                        // Step 3 is what listed chapter 189 while you were on
                        // 234: chapter names repeat and the list shifts when new
                        // chapters land, so indexOf found the wrong match and
                        // reported it with total confidence. It is now the last
                        // resort, used only for rows saved before the index
                        // existed.
                        if (recordedChapterIdx >= 0 && (recordedChapterIdx < novel.chapters.size || recordedChapterIdx < novel.chapterUrls.size)) {
                            recordedChapterIdx
                        } else if (novel.currentChapterIndex >= 0 &&
                            (novel.currentChapterIndex < novel.chapters.size ||
                                novel.currentChapterIndex < novel.chapterUrls.size)
                        ) {
                            novel.currentChapterIndex
                        } else {
                            // NAME MATCHING IS GONE. Chapter names repeat and get
                            // re-titled, so indexOf used to point the highlight
                            // at a completely different chapter with total
                            // confidence. Nothing recorded now means nothing
                            // highlighted, which is at least honest.
                            -1
                        }
                    }

                    val targetPos = remember(filteredChapters, currentOrigIndex) {
                        if (currentOrigIndex >= 0) {
                            filteredChapters.indexOfFirst { it.first == currentOrigIndex }
                        } else {
                            -1
                        }
                    }

                    LaunchedEffect(currentOrigIndex, sortByChapter, sortDescending, chapterSearchQuery, filteredChapters.size, isLoadingDetails) {
                        if (!isLoadingDetails && targetPos >= 0) {
                            chapterListState.scrollToItem(index = (targetPos - 2).coerceAtLeast(0), scrollOffset = 0)
                        }
                    }


                    com.lorelight.ui.components.VerticalFastScroller(
                        listState = chapterListState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        LazyColumn(
                            state = chapterListState,
                            modifier = Modifier.fillMaxSize()
                        ) {
                            if (isLoadingDetails) {
                                item {
                                    LorelightLoading(
                                        shape = LoadingShape.CHAPTER_ROWS,
                                        itemCount = 8
                                    )
                                }
                            } else if (filteredChapters.isEmpty()) {
                                item {
                                    LorelightEmpty(
                                        icon = Icons.Filled.MenuBook,
                                        title = if (chapterSearchQuery.isNotEmpty()) stringResource(R.string.details_no_chapters_match) else stringResource(R.string.details_no_chapters_yet),
                                        message = if (chapterSearchQuery.isNotEmpty())
                                            "Nothing matches \"$chapterSearchQuery\". Try a different search."
                                        else
                                            stringResource(R.string.details_chapters_importing_hint),
                                        compact = true
                                    )
                                }
                            }
                            items(filteredChapters, key = { it.first }) { (origIndex, resolvedNum, displayLabel) ->
                                val rawName = novel.chapters.getOrNull(origIndex) ?: displayLabel
                                // Index-based: follows the chapters-table record
                                // via currentOrigIndex, and cannot misfire on
                                // duplicate or re-titled chapter names.
                                val chapterKey = chapterKeys.getOrNull(origIndex).orEmpty()
                                val isCurrent = origIndex == currentOrigIndex

                                Box {
                                    ChapterListItem(
                                        chapterName = rawName,
                                        displayLabel = displayLabel,
                                        resolvedNumber = resolvedNum,
                                        isCurrent = isCurrent,
                                        isDownloaded = downloadedIndices.contains(origIndex),
                                        isRead = chapterState.isCompleted(chapterKey),
                                        lastPageRead = chapterState.pageOf(chapterKey),
                                        isBookmarked = chapterState.isBookmarked(chapterKey),
                                        onClick = {
                                            onUpdateCurrentChapter(novel, origIndex, rawName)
                                        },
                                        onLongClick = { chapterMenuIndex = origIndex }
                                    )
                                    DropdownMenu(
                                        expanded = chapterMenuIndex == origIndex,
                                        onDismissRequest = { chapterMenuIndex = null }
                                    ) {
                                        val isReadNow = chapterState.isCompleted(chapterKey)
                                        DropdownMenuItem(
                                            text = { Text(if (isReadNow) stringResource(R.string.details_mark_as_unread) else stringResource(R.string.details_mark_as_read)) },
                                            onClick = {
                                                chapterMenuIndex = null
                                                com.lorelight.data.chapters.ChapterReadStore
                                                    .setCompleted(context, novel, listOf(origIndex), !isReadNow)
                                            }
                                        )
                                        if (origIndex > 0) {
                                            DropdownMenuItem(
                                                text = { Text(stringResource(R.string.details_mark_previous_as_read)) },
                                                onClick = {
                                                    chapterMenuIndex = null
                                                    com.lorelight.data.chapters.ChapterReadStore
                                                        .markPreviousCompleted(context, novel, origIndex)
                                                }
                                            )
                                        }
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    if (chapterState.isBookmarked(chapterKey)) stringResource(R.string.details_remove_bookmark)
                                                    else stringResource(R.string.details_bookmark)
                                                )
                                            },
                                            onClick = {
                                                chapterMenuIndex = null
                                                com.lorelight.data.chapters.ChapterReadStore.setBookmark(
                                                    context,
                                                    novel,
                                                    origIndex,
                                                    !chapterState.isBookmarked(chapterKey)
                                                )
                                            }
                                        )
                                    }
                                }
                            }
                            if (novel.status == "Importing") {
                                item {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(16.dp),
                                                strokeWidth = 2.dp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Text(
                                                text = stringResource(R.string.details_importing_more_chapters),
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ShimmerBox(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val x by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "x"
    )
    val base = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
    val hi = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.20f)
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(base, hi, base),
                    start = androidx.compose.ui.geometry.Offset(x - 300f, 0f),
                    end = androidx.compose.ui.geometry.Offset(x, 0f)
                )
            )
    )
}

@Composable
fun DetailsCircleIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String,
    onClick: () -> Unit,
    highlighted: Boolean = false,
    modifier: Modifier = Modifier
) {
    androidx.compose.material3.FilledTonalButton(
        onClick = onClick,
        modifier = modifier.height(52.dp),
        shape = RoundedCornerShape(16.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
        colors = androidx.compose.material3.ButtonDefaults.filledTonalButtonColors(
            containerColor = if (highlighted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            contentColor = if (highlighted) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
        )
    ) {
        Icon(
            imageVector = icon,
            contentDescription = desc,
            modifier = Modifier.size(24.dp)
        )
    }
}

@Composable
fun AboutItemInline(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.60f),
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium
        )
        Text(
            text = " - ",
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.40f),
            fontSize = 10.sp
        )
        Text(
            text = value,
            color = MaterialTheme.colorScheme.onSurface,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
fun ChapterListItem(
    chapterName: String,
    isCurrent: Boolean,
    modifier: Modifier = Modifier,
    chapterNum: Int = 0,
    displayLabel: String = chapterName,
    resolvedNumber: Float? = null,
    isDownloaded: Boolean = false,
    /** mihon: Chapter.read. Finished chapters are dulled out. */
    isRead: Boolean = false,
    /** mihon: Chapter.lastPageRead. Surfaced as a "Page N" resume hint. */
    lastPageRead: Int = 0,
    isBookmarked: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    // mihon's rule: a read chapter is visually de-emphasised (dulled), the one
    // you are on is highlighted, and everything else is normal. "Started but not
    // finished" keeps full contrast and advertises its resume page instead.
    val isInProgress = !isRead && lastPageRead > 0
    val titleColor = when {
        isCurrent -> MaterialTheme.colorScheme.primary
        isRead -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
        else -> MaterialTheme.colorScheme.onSurface
    }
    // PER-CHAPTER GLASS. Each row is its own small pane, so the list reads as a
    // stack of cards rather than one large sheet. The current chapter keeps the
    // primary tint on top of the glass so it still stands out.
    val rowShape = RoundedCornerShape(10.dp)
    val rowGlass = com.lorelight.ui.theme.rememberGlassPalette()
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clip(rowShape)
            .background(
                when {
                    // The chapter you are on gets a real tint, not just bold text.
                    isCurrent -> MaterialTheme.colorScheme.primary.copy(alpha = 0.22f)
                    // Finished: the whole row recedes, not only its label.
                    isRead -> rowGlass.container.copy(alpha = rowGlass.container.alpha * 0.45f)
                    else -> rowGlass.container
                },
                rowShape
            )
            .border(
                1.dp,
                if (isCurrent) {
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
                } else {
                    rowGlass.borderTop
                },
                rowShape
            )
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(vertical = 5.dp, horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isRead) {
            Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = stringResource(R.string.details_read_desc),
                tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f),
                modifier = Modifier
                    .size(11.dp)
                    .padding(end = 1.dp)
            )
            Spacer(modifier = Modifier.width(3.dp))
        }
        // ONE LINE PER CHAPTER, ALWAYS. The name never wraps to a second row,
        // so every row in the list is exactly the same height and the list scans
        // as a column rather than a ragged stack. The resume point moved out of a
        // second line and into the small trailing pill below.
        Text(
            text = displayLabel,
            color = titleColor,
            fontSize = 10.sp,
            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        if (isInProgress) {
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                // lastPageRead is 0-based; humans count from 1.
                text = "p${lastPageRead + 1}",
                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                fontSize = 8.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (isBookmarked) {
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Filled.Bookmark,
                contentDescription = stringResource(R.string.details_bookmarked_desc),
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(12.dp)
            )
        }
        if (isDownloaded) {
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
                imageVector = Icons.Filled.Download,
                contentDescription = stringResource(R.string.details_downloaded_desc),
                tint = if (isRead) {
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
                } else {
                    MaterialTheme.colorScheme.primary
                },
                modifier = Modifier.size(14.dp)
            )
        }
    }
}
