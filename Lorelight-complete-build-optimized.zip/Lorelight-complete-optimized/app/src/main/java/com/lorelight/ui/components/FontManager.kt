package com.lorelight.ui.components

import android.content.Context
import android.util.Log
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.ui.platform.testTag
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalFontFamilyResolver
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.em
import com.lorelight.ui.reader.ReaderViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import androidx.compose.ui.semantics.Role

// ==========================================
// DATA MODELS & CONFIG
// ==========================================

data class GoogleFontItem(
    val family: String,
    val category: String,
    val variants: List<String>,
    val axes: List<String>,
    val files: Map<String, String>,
    val version: String,
    val lastModified: String
) {
    val isVariable: Boolean
        get() = axes.isNotEmpty() || variants.any { it.contains("variable", ignoreCase = true) }
}

data class DownloadedFont(
    val family: String,
    val filePath: String,
    val category: String,
    val isVariable: Boolean,
    val version: String,
    val addedTimestamp: Long
)

data class FontCat(
    val key: String,
    val displayName: String,
    val description: String,
    val defaultFont: String
)

val FONT_CATEGORIES = listOf(
    FontCat("app_interface", "App Interface Font", "Controls the visual typography of Library, Settings, Buttons, Menus, Dialogs...", "System Default"),
    FontCat("reader", "Reader Font", "Controls the text style for books, chapters, paragraphs, and EPUB/TXT content.", "System Default")
)

// Global cache for preview loaded FontFamilies to prevent stuttering/flicker
private val loadedPreviewFontMap = mutableStateMapOf<String, FontFamily>()

// Resolve standard or custom font families
fun resolveFontFamily(fontName: String, context: Context): FontFamily {
    if (CustomFontManager.appContext?.get() == null) {
        CustomFontManager.init(context)
    }
    return CustomFontManager.getFontFamily(context, fontName)
}

// Generate Typography styled globally using the App Interface Font
fun getAppTypography(fontFamily: FontFamily): Typography {
    val default = Typography()
    return Typography(
        displayLarge = default.displayLarge.copy(fontFamily = fontFamily),
        displayMedium = default.displayMedium.copy(fontFamily = fontFamily),
        displaySmall = default.displaySmall.copy(fontFamily = fontFamily),
        headlineLarge = default.headlineLarge.copy(
            fontFamily = fontFamily,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.02).em
        ),
        headlineMedium = default.headlineMedium.copy(
            fontFamily = fontFamily,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.02).em
        ),
        headlineSmall = default.headlineSmall.copy(fontFamily = fontFamily),
        titleLarge = default.titleLarge.copy(
            fontFamily = fontFamily,
            fontWeight = FontWeight.SemiBold
        ),
        titleMedium = default.titleMedium.copy(fontFamily = fontFamily),
        titleSmall = default.titleSmall.copy(fontFamily = fontFamily),
        bodyLarge = default.bodyLarge.copy(
            fontFamily = fontFamily,
            lineHeight = 24.sp
        ),
        bodyMedium = default.bodyMedium.copy(fontFamily = fontFamily),
        bodySmall = default.bodySmall.copy(fontFamily = fontFamily),
        labelLarge = default.labelLarge.copy(fontFamily = fontFamily),
        labelMedium = default.labelMedium.copy(fontFamily = fontFamily),
        labelSmall = default.labelSmall.copy(
            fontFamily = fontFamily,
            fontSize = 11.sp,
            letterSpacing = 0.08.em,
            fontWeight = FontWeight.Medium
        )
    )
}

object CustomFontManager {
    private const val TAG = "CustomFontManager"
    private const val PREFS_NAME = "font_prefs"
    private const val KEY_APP_FONT = "app_interface_font"
    private const val KEY_READER_FONT = "reader_font_family"

    /**
     * The interface face the app is designed around. It is a Google font
     * rather than a bundled one, so on a fresh install the file does not
     * exist yet: the name is the default immediately, and the file is
     * fetched once in the background on first launch. Until it lands the
     * app simply renders in the system face.
     */
    const val DEFAULT_APP_FONT = "Agbalumo"
    private const val KEY_DEFAULT_FONT_TRIES = "default_app_font_tries"
    
    // Loaded font cache mapping Font Name -> FontFamily
    private val loadedFontFamilies = mutableMapOf<String, FontFamily>()

    var appContext: java.lang.ref.WeakReference<Context>? = null

    fun init(context: Context) {
        appContext = java.lang.ref.WeakReference(context.applicationContext)
    }

    fun getFontFamily(fontName: String): FontFamily {
        val context = appContext?.get()
        if (context == null) {
            // Static fallbacks
            if (fontName == "System Default") return FontFamily.Default
            if (fontName == "System Serif" || fontName == "Serif") return FontFamily.Serif
            if (fontName == "System Monospace" || fontName == "Monospace") return FontFamily.Monospace
            if (fontName == "System Cursive" || fontName == "Cursive") return FontFamily.Cursive
            return FontFamily.Default
        }
        return getFontFamily(context, fontName)
    }

    fun getFontFolder(context: Context): File {
        val folder = File(context.filesDir, "downloaded_fonts")
        if (!folder.exists()) {
            folder.mkdirs()
        }
        return folder
    }

    fun getPreviewFolder(context: Context): File {
        val folder = File(context.cacheDir, "preview_fonts")
        if (!folder.exists()) {
            folder.mkdirs()
        }
        return folder
    }

    fun getFontFile(context: Context, fontName: String): File {
        return File(getFontFolder(context), "$fontName.ttf")
    }

    fun getPreviewFontFile(context: Context, fontName: String): File {
        return File(getPreviewFolder(context), "$fontName.ttf")
    }

    fun isFontDownloaded(context: Context, fontName: String): Boolean {
        if (isBuiltInFont(fontName)) return true
        val file = getFontFile(context, fontName)
        return file.exists() && file.length() > 500
    }

    fun isBuiltInFont(fontName: String): Boolean {
        return fontName == "System Default" || fontName == "System Serif" || fontName == "Serif" ||
                fontName == "System Monospace" || fontName == "Monospace" || fontName == "System Cursive" || fontName == "Cursive"
    }

    fun getDownloadedFonts(context: Context): List<String> {
        val builtIns = listOf("System Default")
        val files = getFontFolder(context).listFiles() ?: emptyArray()
        val downloaded = files.filter { it.isFile && it.name.endsWith(".ttf") && it.length() > 500 }
            .map { it.name.removeSuffix(".ttf").replace("_", " ") }
        return builtIns + downloaded
    }

    fun deleteFont(context: Context, fontName: String): Boolean {
        if (isBuiltInFont(fontName)) return false
        val file = getFontFile(context, fontName)
        if (file.exists()) {
            val deleted = file.delete()
            if (deleted) {
                loadedFontFamilies.remove(fontName)
                loadedPreviewFontMap.remove(fontName)
            }
            return deleted
        }
        return false
    }

    fun getFontFamily(context: Context, fontName: String): FontFamily {
        if (fontName == "System Default") return FontFamily.Default
        if (fontName == "System Serif" || fontName == "Serif") return FontFamily.Serif
        if (fontName == "System Monospace" || fontName == "Monospace") return FontFamily.Monospace
        if (fontName == "System Cursive" || fontName == "Cursive") return FontFamily.Cursive

        // Check cache
        val cached = loadedFontFamilies[fontName]
        if (cached != null) return cached

        // Check downloaded permanent folder
        val fontFile = getFontFile(context, fontName)
        if (fontFile.exists() && fontFile.length() > 500) {
            try {
                val typeface = android.graphics.Typeface.createFromFile(fontFile)
                if (typeface != null) {
                    val fontFamily = FontFamily(typeface)
                    loadedFontFamilies[fontName] = fontFamily
                    loadedPreviewFontMap[fontName] = fontFamily
                    return fontFamily
                }
            } catch (t: Throwable) {
                Log.e(TAG, "CRITICAL ERROR: Failed to load downloaded font file for '$fontName': ${t.message}", t)
                try {
                    fontFile.delete()
                } catch (ignored: Exception) { com.lorelight.core.CrashReporter.recordError(context, "FontManager.loadDownloadedFont", ignored) }
            }
        }

        // Check preview cache directory (render instantly)
        val previewFile = getPreviewFontFile(context, fontName)
        if (previewFile.exists() && previewFile.length() > 500) {
            try {
                val typeface = android.graphics.Typeface.createFromFile(previewFile)
                if (typeface != null) {
                    val fontFamily = FontFamily(typeface)
                    loadedFontFamilies[fontName] = fontFamily
                    loadedPreviewFontMap[fontName] = fontFamily
                    return fontFamily
                }
            } catch (t: Throwable) {
                Log.e(TAG, "CRITICAL ERROR: Failed to load preview font file for '$fontName': ${t.message}", t)
                try {
                    previewFile.delete()
                } catch (ignored: Exception) { com.lorelight.core.CrashReporter.recordError(context, "FontManager.loadPreviewFont", ignored) }
            }
        }

        return FontFamily.Default
    }

    // Persisted Category selectors
    fun getSavedFontForCategory(context: Context, categoryKey: String): String {
        val mappedKey = when (categoryKey) {
            "app_interface" -> "app_interface_font"
            "reader" -> "reader_font_family"
            else -> categoryKey
        }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        // Only the interface font defaults to Agbalumo. The reader font
        // must stay on the system face -- a display face is the wrong
        // thing to read four hundred pages in.
        val fallback = if (mappedKey == "app_interface_font") DEFAULT_APP_FONT else "System Default"
        return prefs.getString(mappedKey, fallback) ?: fallback
    }

    fun saveFontForCategory(context: Context, categoryKey: String, fontName: String) {
        val mappedKey = when (categoryKey) {
            "app_interface" -> "app_interface_font"
            "reader" -> "reader_font_family"
            else -> categoryKey
        }
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(mappedKey, fontName).apply()
    }

    fun getAppFont(context: Context) = getSavedFontForCategory(context, KEY_APP_FONT)
    fun saveAppFont(context: Context, name: String) = saveFontForCategory(context, KEY_APP_FONT, name)

    fun getReaderFont(context: Context) = getSavedFontForCategory(context, KEY_READER_FONT)
    fun saveReaderFont(context: Context, name: String) = saveFontForCategory(context, KEY_READER_FONT, name)

    /** Drops a cached typeface so a newly downloaded file is picked up. */
    fun invalidate(fontName: String) {
        loadedFontFamilies.remove(fontName)
        loadedPreviewFontMap.remove(fontName)
    }

    /**
     * Fetches the default interface font if it is not on disk yet.
     *
     * Blocking on purpose -- call it from an IO dispatcher. Returns true
     * only when the file has just become usable, which is the caller's cue
     * to re-resolve the typography once. Gives up after a few launches so a
     * permanently offline device is not retrying forever, and every failure
     * is silent: the app is perfectly usable in the system face.
     */
    fun ensureDefaultAppFont(context: Context): Boolean {
        if (isFontDownloaded(context, DEFAULT_APP_FONT)) return false
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val tries = prefs.getInt(KEY_DEFAULT_FONT_TRIES, 0)
        if (tries >= 5) return false
        prefs.edit().putInt(KEY_DEFAULT_FONT_TRIES, tries + 1).apply()

        val target = getFontFile(context, DEFAULT_APP_FONT)
        val temp = File(target.parentFile, DEFAULT_APP_FONT + ".ttf.tmp")
        return try {
            val link = fetchFontUrlFromCssEndpoint(DEFAULT_APP_FONT) ?: return false
            val conn = URL(link).openConnection() as HttpURLConnection
            conn.connectTimeout = 12000
            conn.readTimeout = 12000
            if (conn.responseCode != 200) return false
            conn.inputStream.use { input ->
                FileOutputStream(temp).use { out -> input.copyTo(out) }
            }
            if (temp.length() <= 500) {
                temp.delete()
                return false
            }
            if (target.exists()) target.delete()
            val moved = temp.renameTo(target)
            if (moved) {
                invalidate(DEFAULT_APP_FONT)
                prefs.edit().putInt(KEY_DEFAULT_FONT_TRIES, 0).apply()
            }
            moved
        } catch (t: Throwable) {
            Log.e(TAG, "Default interface font fetch failed: " + t.message)
            try {
                temp.delete()
            } catch (ignored: Exception) {
            }
            false
        }
    }

    // Official Google Fonts CSS parser to resolve TTF font file link
    fun fetchFontUrlFromCssEndpoint(fontName: String): String? {
        return try {
            val encoded = URLEncoder.encode(fontName, "UTF-8")
            val url = URL("https://fonts.googleapis.com/css?family=$encoded")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            // Set an older mobile User-Agent to force Google Fonts CDN to return standard TTF format instead of WOFF2
            conn.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30"
            )
            conn.connectTimeout = 5000
            conn.readTimeout = 5000
            val code = conn.responseCode
            if (code == 200) {
                val cssContent = conn.inputStream.bufferedReader().use { it.readText() }
                // Match url(...) with ttf or otf extension inside CSS
                val regex = Regex("""url\((https?://[^)]+\.(?:ttf|otf|woff2|woff))\)""")
                val match = regex.find(cssContent)
                val matchedUrl = match?.groupValues?.get(1)
                if (matchedUrl != null) {
                    Log.d(TAG, "Successfully extracted direct url from CSS for $fontName: $matchedUrl")
                    matchedUrl
                } else {
                    null
                }
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed parsing CSS endpoint for $fontName", e)
            null
        }
    }
}

@Composable
fun rememberSafeFontFamily(
    fontName: String,
    context: Context = LocalContext.current,
    recomposeKey: Any? = null
): FontFamily {
    val rawFontFamily = remember(fontName, recomposeKey) { CustomFontManager.getFontFamily(context, fontName) }
    val resolver = LocalFontFamilyResolver.current
    return remember(rawFontFamily, resolver, recomposeKey) {
        try {
            val resolvedState = resolver.resolve(rawFontFamily)
            resolvedState.value
            rawFontFamily
        } catch (e: Exception) {
            Log.e("CustomFontManager", "Failed to resolve font: $fontName - fallback to default", e)
            FontFamily.Default
        }
    }
}

// ==========================================
// OFFLINE METADATA ENGINE & DOWNLOAD HANDLER
// ==========================================

object FontManagerEngine {
    private const val PREFS_FONTS = "lorelight_font_settings"
    private const val KEY_DOWNLOADED_LIST = "downloaded_fonts_list"
    private val API_KEY = com.lorelight.BuildConfig.FONTS_API_KEY
    private const val CATALOG_CACHE_FILE = "google_fonts_catalog_cache.json"

    // Download state for active download UI
    class DownloadState(
        val family: String,
        val progress: Int, // 0 - 100
        val speedKbps: Double,
        val speedText: String,
        val status: String, // "Connecting...", "Downloading...", "Completed", "Failed"
        val errorMsg: String? = null
    )

    // Flow for active downloads progress indicators
    val activeDownloads = mutableStateMapOf<String, DownloadState>()

    // Clear download state
    fun clearDownloadState(family: String) {
        activeDownloads.remove(family)
    }

    // Get selected font family name for a category
    fun getSelectedFont(context: Context, categoryKey: String, defaultValue: String = "System Default"): String {
        return CustomFontManager.getSavedFontForCategory(context, categoryKey)
    }

    // Set selected font family name for a category
    fun setSelectedFont(context: Context, categoryKey: String, fontFamily: String) {
        CustomFontManager.saveFontForCategory(context, categoryKey, fontFamily)
    }

    // Get list of downloaded fonts
    fun getDownloadedFonts(context: Context): List<DownloadedFont> {
        val prefs = context.getSharedPreferences(PREFS_FONTS, Context.MODE_PRIVATE)
        val jsonStr = prefs.getString(KEY_DOWNLOADED_LIST, "[]") ?: "[]"
        val list = mutableListOf<DownloadedFont>()
        try {
            val arr = JSONArray(jsonStr)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val family = obj.getString("family")
                val path = obj.getString("filePath")
                val cat = obj.optString("category", "sans-serif")
                val isVar = obj.optBoolean("isVariable", false)
                val ver = obj.optString("version", "1.0")
                val time = obj.optLong("addedTimestamp", 0L)
                list.add(DownloadedFont(family, path, cat, isVar, ver, time))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    // Save list of downloaded fonts meta
    private fun saveDownloadedFonts(context: Context, list: List<DownloadedFont>) {
        val prefs = context.getSharedPreferences(PREFS_FONTS, Context.MODE_PRIVATE)
        try {
            val arr = JSONArray()
            list.forEach { item ->
                val obj = JSONObject()
                obj.put("family", item.family)
                obj.put("filePath", item.filePath)
                obj.put("category", item.category)
                obj.put("isVariable", item.isVariable)
                obj.put("version", item.version)
                obj.put("addedTimestamp", item.addedTimestamp)
                arr.put(obj)
            }
            prefs.edit().putString(KEY_DOWNLOADED_LIST, arr.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Delete a downloaded font
    fun deleteDownloadedFont(context: Context, family: String): Boolean {
        try {
            val list = getDownloadedFonts(context).toMutableList()
            val item = list.find { it.family.equals(family, ignoreCase = true) }
            if (item != null) {
                val file = File(item.filePath)
                if (file.exists()) {
                    file.delete()
                }
                list.remove(item)
                saveDownloadedFonts(context, list)

                // Revert loaded map cache
                loadedPreviewFontMap.remove(family)
                CustomFontManager.deleteFont(context, family)

                // If currently active font, revert to default
                FONT_CATEGORIES.forEach { cat ->
                    if (getSelectedFont(context, cat.key) == family) {
                        setSelectedFont(context, cat.key, "System Default")
                    }
                }
                return true
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    // Fetch Google Fonts catalog from network, caching it offline
    suspend fun fetchGoogleFontsCatalog(context: Context, forceRefresh: Boolean = false): List<GoogleFontItem> {
        val list = mutableListOf<GoogleFontItem>()
        val cacheFile = File(context.cacheDir, CATALOG_CACHE_FILE)

        // If cached and no force refresh, load cached content
        if (!forceRefresh && cacheFile.exists() && cacheFile.isFile) {
            try {
                val cachedContent = cacheFile.readText()
                val parsed = parseWebFontsJson(cachedContent)
                if (parsed.isNotEmpty()) {
                    return parsed
                }
            } catch (e: java.io.IOException) {
                Log.e("FontManager", "Failed to read cached catalog JSON: ${e.message}")
            }
        }

        // Fetch from network API
        return withContext(Dispatchers.IO) {
            // 1) Try the official keyed API only if a key is actually set
            if (API_KEY.toString().isNotBlank()) {
                try {
                    val urlStr = "https://www.googleapis.com/webfonts/v1/webfonts?sort=popularity&key=$API_KEY"
                    val connection = URL(urlStr).openConnection() as HttpURLConnection
                    connection.requestMethod = "GET"
                    connection.connectTimeout = 12000
                    connection.readTimeout = 12000
                    if (connection.responseCode == 200) {
                        val responseText = connection.inputStream.reader().readText()
                        cacheFile.writeText(responseText)
                        return@withContext parseWebFontsJson(responseText)
                    } else {
                        Log.e("FontManager", "Keyed API failed with HTTP ${connection.responseCode}, trying keyless endpoint")
                    }
                } catch (e: Exception) {
                    Log.e("FontManager", "Keyed API error: ${e.message}, trying keyless endpoint")
                }
            }

            // 2) Keyless official metadata endpoint (no API key needed, always current)
            try {
                val keyless = fetchKeylessCatalogJson()
                if (keyless != null) {
                    val parsed = parseWebFontsJson(keyless)
                    if (parsed.isNotEmpty()) {
                        cacheFile.writeText(keyless)
                        return@withContext parsed
                    }
                }
            } catch (e: Exception) {
                Log.e("FontManager", "Keyless catalog error: ${e.message}")
            }

            // 3) Stale cache, then tiny hardcoded fallback as last resort
            if (cacheFile.exists() && cacheFile.isFile) {
                try {
                    return@withContext parseWebFontsJson(cacheFile.readText())
                } catch (ex: Exception) { /* fall through */ }
            }
            parseWebFontsJson(getFallbackCatalogJson())
        }
    }

    /**
     * Fetches the full Google Fonts catalog from the keyless endpoint
     * https://fonts.google.com/metadata/fonts (used by fonts.google.com itself)
     * and converts it to the same "webfonts items" JSON shape the rest of the
     * app already parses. The files map is left empty on purpose: downloads
     * resolve the real .ttf URL via fetchFontFromOfficialCss (also keyless).
     */
    private fun fetchKeylessCatalogJson(): String? {
        val conn = URL("https://fonts.google.com/metadata/fonts").openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 15000
        conn.readTimeout = 15000
        conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36")
        if (conn.responseCode != 200) return null
        var body = conn.inputStream.reader().readText()
        // Google prefixes this endpoint with an anti-JSON-hijacking token
        body = body.removePrefix(")]}'").trim()

        val root = JSONObject(body)
        val familyList = root.optJSONArray("familyMetadataList") ?: return null
        val itemsArr = org.json.JSONArray()
        for (i in 0 until familyList.length()) {
            val fam = familyList.getJSONObject(i)
            val obj = JSONObject()
            obj.put("family", fam.getString("family"))
            // "Sans Serif" -> "sans-serif", "Display" -> "display"
            obj.put("category", fam.optString("category", "Sans Serif").lowercase().replace(" ", "-"))
            obj.put("lastModified", fam.optString("lastModified", ""))
            obj.put("version", "v1")

            val variantsArr = org.json.JSONArray()
            val fontsObj = fam.optJSONObject("fonts")
            if (fontsObj != null) {
                val keys = fontsObj.keys()
                while (keys.hasNext()) {
                    val k = keys.next() // e.g. "400", "700i"
                    val variant = when {
                        k == "400" -> "regular"
                        k == "400i" -> "italic"
                        k.endsWith("i") -> k.dropLast(1) + "italic"
                        else -> k
                    }
                    variantsArr.put(variant)
                }
            }
            if (variantsArr.length() == 0) variantsArr.put("regular")
            obj.put("variants", variantsArr)

            val axesArr = org.json.JSONArray()
            val axes = fam.optJSONArray("axes")
            if (axes != null) {
                for (j in 0 until axes.length()) {
                    val ax = axes.optJSONObject(j)
                    if (ax != null) axesArr.put(ax.optString("tag", ""))
                }
            }
            obj.put("axes", axesArr)
            obj.put("files", JSONObject()) // resolved keylessly at download time
            itemsArr.put(obj)
        }
        val out = JSONObject()
        out.put("items", itemsArr)
        return out.toString()
    }

    private fun parseWebFontsJson(jsonStr: String): List<GoogleFontItem> {
        val list = mutableListOf<GoogleFontItem>()
        try {
            val root = JSONObject(jsonStr)
            val items = root.getJSONArray("items")
            for (i in 0 until items.length()) {
                val obj = items.getJSONObject(i)
                val family = obj.getString("family")
                val category = obj.optString("category", "sans-serif")
                val version = obj.optString("version", "v1")
                val lastMod = obj.optString("lastModified", "")

                val variantsList = mutableListOf<String>()
                val variantsArr = obj.optJSONArray("variants")
                if (variantsArr != null) {
                    for (j in 0 until variantsArr.length()) {
                        variantsList.add(variantsArr.getString(j))
                    }
                }

                val axesList = mutableListOf<String>()
                val axesArr = obj.optJSONArray("axes")
                if (axesArr != null) {
                    for (j in 0 until axesArr.length()) {
                        axesList.add(axesArr.getString(j))
                    }
                }

                val filesMap = mutableMapOf<String, String>()
                val filesObj = obj.optJSONObject("files")
                if (filesObj != null) {
                    val keys = filesObj.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        filesMap[key] = filesObj.getString(key)
                    }
                }

                list.add(GoogleFontItem(family, category, variantsList, axesList, filesMap, version, lastMod))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    private fun getFallbackCatalogJson(): String {
        return """
        {
          "items": [
            {
              "family": "Inter",
              "category": "sans-serif",
              "variants": ["regular", "500", "700"],
              "files": {
                "regular": "https://fonts.gstatic.com/s/inter/v13/UcCO3FwrK3iLTeHuS_fvQtMwCp5VKnOw1iE.ttf"
              }
            },
            {
              "family": "Roboto",
              "category": "sans-serif",
              "variants": ["regular", "500", "700"],
              "files": {
                "regular": "https://fonts.gstatic.com/s/roboto/v30/KFOmCnqEu92Fr1Mu4mxKKTU1Kg.ttf"
              }
            },
            {
              "family": "Open Sans",
              "category": "sans-serif",
              "variants": ["regular", "600", "700"],
              "files": {
                "regular": "https://fonts.gstatic.com/s/opensans/v34/memvYaGs126MiZpBA-UvWbX2vVnXBbObj2OVTSKmu1aB.ttf"
              }
            },
            {
              "family": "Montserrat",
              "category": "sans-serif",
              "variants": ["regular", "600", "700"],
              "files": {
                "regular": "https://fonts.gstatic.com/s/montserrat/v25/JTUHjIg1_i6t8kCHKm4MV96gxZQfNq52pw.ttf"
              }
            },
            {
              "family": "Lato",
              "category": "sans-serif",
              "variants": ["regular", "700"],
              "files": {
                "regular": "https://fonts.gstatic.com/s/lato/v23/S6uyw4BMUTPHjxAwXiWtFCfQ7A.ttf"
              }
            },
            {
              "family": "Merriweather",
              "category": "serif",
              "variants": ["regular", "700"],
              "files": {
                "regular": "https://fonts.gstatic.com/s/merriweather/v30/u-4n0qyOJr139kGLusOF6I7M76i_A_622Ww.ttf"
              }
            },
            {
              "family": "Playfair Display",
              "category": "serif",
              "variants": ["regular", "600", "700"],
              "files": {
                "regular": "https://fonts.gstatic.com/s/playfairdisplay/v30/nuFvD7K3a3X7_41m6_aM-180U5_p4_uAVgB-N6f_N70.ttf"
              }
            },
            {
              "family": "Lora",
              "category": "serif",
              "variants": ["regular", "600", "700"],
              "files": {
                "regular": "https://fonts.gstatic.com/s/lora/v23/0QI6MX1D_JOuGo_p9EvfO18.ttf"
              }
            },
            {
              "family": "EB Garamond",
              "category": "serif",
              "variants": ["regular", "600", "700"],
              "files": {
                "regular": "https://fonts.gstatic.com/s/ebgaramond/v22/SlXCc15Y_RVDl1g55iID8KXdgZg0f8sz2vCAdS9MTA.ttf"
              }
            },
            {
              "family": "Caveat",
              "category": "handwriting",
              "variants": ["regular", "700"],
              "files": {
                "regular": "https://fonts.gstatic.com/s/caveat/v17/WnznHAc5bTCYB2I7L_F-EXR88w.ttf"
              }
            },
            {
              "family": "Pacifico",
              "category": "handwriting",
              "variants": ["regular"],
              "files": {
                "regular": "https://fonts.gstatic.com/s/pacifico/v22/FwZY7-Qis1N6o-K36_uPreu-7A.ttf"
              }
            },
            {
              "family": "Roboto Mono",
              "category": "monospace",
              "variants": ["regular", "700"],
              "files": {
                "regular": "https://fonts.gstatic.com/s/robotomono/v22/L0x5DF4xlVMF-BfR8bXMIjhLq3qcYgo.ttf"
              }
            },
            {
              "family": "Fira Code",
              "category": "monospace",
              "variants": ["regular", "500", "700"],
              "files": {
                "regular": "https://fonts.gstatic.com/s/firacode/v21/u04X6pxm4yapQI_ZVTriRupG8A.ttf"
              }
            },
            {
              "family": "Inter Tight",
              "category": "sans-serif",
              "variants": ["regular", "700"],
              "files": {
                "regular": "https://fonts.gstatic.com/s/intertight/v1/HI_KiYs3Mst4L_H6vN_SIn_n2T0S0yM.ttf"
              }
            }
          ]
        }
        """.trimIndent()
    }

    // Try fetching the direct .ttf URL from the official Google Fonts CSS endpoint
    fun fetchFontFromOfficialCss(familyName: String): String? {
        return CustomFontManager.fetchFontUrlFromCssEndpoint(familyName)
    }

    // High performance on-demand background loader for Browse fonts preview
    fun runPreviewOnDemandDownload(context: Context, item: GoogleFontItem, scope: kotlinx.coroutines.CoroutineScope, onReady: () -> Unit) {
        val fontName = item.family
        val target = CustomFontManager.getPreviewFontFile(context, fontName)
        if (target.exists() && target.length() > 500) {
            onReady()
            return
        }

        val folder = target.parentFile
        if (folder != null && !folder.exists()) {
            folder.mkdirs()
        }

        // Load asynchronously in thread
        scope.launch(Dispatchers.IO) {
            var success = false
            try {
                // Determine source: fetch from web Fonts CSS url first for preview validation, fallback to catalogue direct download
                var fileUrl = fetchFontFromOfficialCss(fontName)
                if (fileUrl == null) {
                    fileUrl = item.files["regular"] ?: item.files["400"] ?: item.files.values.firstOrNull()
                }

                if (fileUrl != null) {
                    var finalUrl = fileUrl
                    if (finalUrl.startsWith("http://")) {
                        finalUrl = finalUrl.replace("http://", "https://")
                    } else if (!finalUrl.startsWith("https://")) {
                        finalUrl = "https://$finalUrl"
                    }

                    val conn = URL(finalUrl).openConnection() as HttpURLConnection
                    conn.connectTimeout = 8000
                    conn.readTimeout = 8000
                    if (conn.responseCode == 200) {
                        val tmpStream = conn.inputStream
                        val tempFile = File(folder, "$fontName.ttf.tmp")
                        val destStream = tempFile.outputStream()
                        tmpStream.copyTo(destStream)
                        destStream.close()
                        tmpStream.close()

                        if (tempFile.exists() && tempFile.length() > 500) {
                            if (target.exists()) {
                                target.delete()
                            }
                            tempFile.renameTo(target)
                            success = true
                        } else {
                            try { tempFile.delete() } catch (ignored: Exception) { com.lorelight.core.CrashReporter.recordError("FontManager.downloadMicroFontPreview", ignored) }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("FontManager", "Error downloading micro-font preview: ${e.message}")
            } finally {
                withContext(Dispatchers.Main) {
                    if (success) {
                        loadedPreviewFontMap.remove(fontName) // Refresh any stale mapping
                        resolveFontFamily(fontName, context)   // Prime caching
                    }
                    onReady()
                }
            }
        }
    }

    // Execute background download of whole font with speed statistics
    fun triggerFontDownload(context: Context, item: GoogleFontItem, scope: kotlinx.coroutines.CoroutineScope, onFinished: (Boolean) -> Unit) {
        val fontName = item.family
        activeDownloads[fontName] = DownloadState(
            family = fontName,
            progress = 0,
            speedKbps = 0.0,
            speedText = "0 KB/s",
            status = "Connecting..."
        )

        scope.launch(Dispatchers.IO) {
            val destinationFile = CustomFontManager.getFontFile(context, fontName)
            val destinationFolder = destinationFile.parentFile
            if (destinationFolder != null && !destinationFolder.exists()) {
                destinationFolder.mkdirs()
            }
            val tempFile = File(destinationFolder, "$fontName.ttf.tmp")

            try {
                // Retrieve URL from HTML CSS endpoints as requested, fall-back to direct static CDN url
                var fileUrl = fetchFontFromOfficialCss(fontName)
                if (fileUrl == null) {
                    fileUrl = item.files["regular"] ?: item.files["500"] ?: item.files["400"] ?: item.files.values.firstOrNull()
                }

                if (fileUrl == null) {
                    throw Exception("No valid download links found in Google Fonts Catalogue mappings.")
                }

                var finalUrl = fileUrl
                if (finalUrl.startsWith("http://")) {
                    finalUrl = finalUrl.replace("http://", "https://")
                } else if (!finalUrl.startsWith("https://")) {
                    finalUrl = "https://$finalUrl"
                }

                val url = URL(finalUrl)
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 12000
                conn.readTimeout = 12000
                val totalLength = conn.contentLength

                val startCode = conn.responseCode
                if (startCode != 200) {
                    throw Exception("Cloud Server responded with non-200 HTTP response code: $startCode")
                }

                val reader = conn.inputStream
                val writer = tempFile.outputStream()
                val data = ByteArray(4096)
                var bytesRead: Int
                var totalBytesRead = 0L
                val speedMeasureStartTime = System.currentTimeMillis()

                activeDownloads[fontName] = DownloadState(fontName, 0, 0.0, "0 KB/s", "Downloading...")

                while (reader.read(data).also { bytesRead = it } != -1) {
                    writer.write(data, 0, bytesRead)
                    totalBytesRead += bytesRead

                    val progress = if (totalLength > 0) (totalBytesRead * 100 / totalLength).toInt() else -1
                    val deltaSeconds = (System.currentTimeMillis() - speedMeasureStartTime) / 1000.0
                    val speedKbps = if (deltaSeconds > 0) (totalBytesRead / 1024.0 / deltaSeconds) else 0.0
                    val speedStr = if (speedKbps > 1024) String.format(Locale.getDefault(), "%.1f MB/s", speedKbps / 1024) else String.format(Locale.getDefault(), "%.1f KB/s", speedKbps)

                    activeDownloads[fontName] = DownloadState(fontName, progress, speedKbps, speedStr, "Downloading...")
                }

                writer.flush()
                writer.close()
                reader.close()

                if (tempFile.exists() && tempFile.length() > 500) {
                    if (destinationFile.exists()) {
                        destinationFile.delete()
                    }
                    tempFile.renameTo(destinationFile)
                } else {
                    throw Exception("Downloaded file is empty or corrupted.")
                }

                // Save onto downloaded list metadata
                val downList = getDownloadedFonts(context).toMutableList()
                downList.removeAll { it.family.equals(fontName, ignoreCase = true) }
                downList.add(DownloadedFont(
                    family = fontName,
                    filePath = destinationFile.absolutePath,
                    category = item.category,
                    isVariable = item.isVariable,
                    version = item.version,
                    addedTimestamp = System.currentTimeMillis()
                ))
                saveDownloadedFonts(context, downList)

                activeDownloads[fontName] = DownloadState(fontName, 100, 0.0, "Done", "Completed")

                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "$fontName downloaded successfully offline!", Toast.LENGTH_SHORT).show()
                    loadedPreviewFontMap.remove(fontName) // Refresh
                    resolveFontFamily(fontName, context)
                    onFinished(true)
                }

            } catch (e: Exception) {
                Log.e("FontManager", "Failed font pack download: ${e.message}")
                if (tempFile.exists()) {
                    tempFile.delete()
                }
                if (destinationFile.exists()) {
                    destinationFile.delete()
                }

                val failureState = DownloadState(
                    family = fontName,
                    progress = 0,
                    speedKbps = 0.0,
                    speedText = "0 KB/s",
                    status = "Failed",
                    errorMsg = e.message ?: "Stream Connection lost."
                )
                activeDownloads[fontName] = failureState

                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Download failed for $fontName: ${e.message}", Toast.LENGTH_LONG).show()
                    onFinished(false)
                }
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
//  FONT STUDIO — redesigned Font Manager UI
//  Loads typefaces off the main thread and defers preview
//  downloads so fast flings never stutter.
// ═══════════════════════════════════════════════════════════════

/** Loads a FontFamily on Dispatchers.IO. Returns null while loading. */
@Composable
fun rememberAsyncFontFamily(fontName: String, recomposeKey: Any? = null): FontFamily? {
    val context = LocalContext.current
    return produceState<FontFamily?>(initialValue = null, fontName, recomposeKey) {
        value = withContext(Dispatchers.IO) {
            try {
                CustomFontManager.getFontFamily(context, fontName)
            } catch (e: Exception) {
                FontFamily.Default
            }
        }
    }.value
}

@Composable
fun FontManagerScreen(
    onBack: () -> Unit,
    readerViewModel: ReaderViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedTab by remember { mutableStateOf(0) }
    var localSearchQuery by remember { mutableStateOf("") }
    var downloadedFonts by remember { mutableStateOf(CustomFontManager.getDownloadedFonts(context)) }
    var allFontsCatalog by remember { mutableStateOf<List<GoogleFontItem>>(emptyList()) }
    var isLoadingCatalog by remember { mutableStateOf(false) }
    var catalogError by remember { mutableStateOf<String?>(null) }
    var onlineSearchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf("All") }
    val categories = listOf("All", "Serif", "Sans Serif", "Display", "Handwriting", "Monospace")
    var sortBy by remember { mutableStateOf("popularity") }
    val sortOptions = listOf("popularity" to "Popular", "date" to "Newest", "alpha" to "A-Z")
    var fontListVersion by remember { mutableStateOf(0) }
    val activeDownloads = FontManagerEngine.activeDownloads

    val currentAppFont by readerViewModel.appInterfaceFont.collectAsState()
    val currentReaderFont by readerViewModel.readerFontFamily.collectAsState()

    fun loadCatalog(force: Boolean = false) {
        if (!force && allFontsCatalog.isNotEmpty()) return
        isLoadingCatalog = true
        catalogError = null
        coroutineScope.launch {
            try {
                val items = FontManagerEngine.fetchGoogleFontsCatalog(context, forceRefresh = force)
                if (items.isNotEmpty()) allFontsCatalog = items
                else catalogError = "Google Fonts catalog is empty."
            } catch (e: Exception) {
                catalogError = e.localizedMessage ?: "Unknown connection error"
            } finally {
                isLoadingCatalog = false
            }
        }
    }

    LaunchedEffect(selectedTab) { if (selectedTab == 1) loadCatalog() }

    Surface(modifier = modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Vertical))
        ) {
            // ── Header ──
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp, end = 8.dp, top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Font Studio",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${downloadedFonts.size} installed  •  Google Fonts",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
                if (selectedTab == 1) {
                    IconButton(onClick = { loadCatalog(force = true) }) {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = "Refresh catalog",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // ── Active fonts hero ──
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ActiveFontSlot(
                    label = "APP INTERFACE",
                    fontName = currentAppFont,
                    icon = Icons.Default.PhoneAndroid,
                    accent = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                ActiveFontSlot(
                    label = "READER",
                    fontName = currentReaderFont,
                    icon = Icons.Default.MenuBook,
                    accent = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ── Segmented tabs ──
            FontStudioTabs(
                selected = selectedTab,
                labels = listOf("Installed", "Discover"),
                onSelect = { selectedTab = it }
            )

            Spacer(modifier = Modifier.height(10.dp))

            AnimatedContent(
                targetState = selectedTab,
                transitionSpec = {
                    fadeIn(tween(180)).togetherWith(fadeOut(tween(120)))
                },
                label = "fontTabContent",
                modifier = Modifier.weight(1f)
            ) { tab ->
                if (tab == 0) {
                    InstalledFontsView(
                        readerViewModel = readerViewModel,
                        searchQuery = localSearchQuery,
                        onSearchQueryChange = { localSearchQuery = it },
                        downloadedFontsList = downloadedFonts,
                        fontListVersion = fontListVersion,
                        currentAppFont = currentAppFont,
                        currentReaderFont = currentReaderFont,
                        onDeleteFont = { font ->
                            val success = FontManagerEngine.deleteDownloadedFont(context, font)
                            if (success) {
                                downloadedFonts = CustomFontManager.getDownloadedFonts(context)
                                fontListVersion++
                                Toast.makeText(context, "$font deleted", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Could not delete $font", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                } else {
                    DiscoverFontsView(
                        readerViewModel = readerViewModel,
                        catalog = allFontsCatalog,
                        isLoading = isLoadingCatalog,
                        errorMessage = catalogError,
                        searchQuery = onlineSearchQuery,
                        selectedCategory = selectedCategoryFilter,
                        sortBy = sortBy,
                        sortOptions = sortOptions,
                        categories = categories,
                        activeDownloads = activeDownloads,
                        currentAppFont = currentAppFont,
                        currentReaderFont = currentReaderFont,
                        onSearchQueryChange = { onlineSearchQuery = it },
                        onCategoryChange = { selectedCategoryFilter = it },
                        onSortChange = { sortBy = it },
                        onRetryLoadCatalog = {
                            allFontsCatalog = emptyList()
                            loadCatalog(force = true)
                        },
                        onDownloadFont = { fontItem ->
                            FontManagerEngine.triggerFontDownload(context, fontItem, coroutineScope) { success ->
                                if (success) {
                                    downloadedFonts = CustomFontManager.getDownloadedFonts(context)
                                    fontListVersion++
                                }
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ActiveFontSlot(
    label: String,
    fontName: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    modifier: Modifier = Modifier
) {
    val family = rememberAsyncFontFamily(fontName)
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .border(1.dp, accent.copy(alpha = 0.35f), RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(5.dp))
            Text(label, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = accent)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Ag",
            fontFamily = family ?: FontFamily.Default,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = fontName,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun FontStudioTabs(selected: Int, labels: List<String>, onSelect: (Int) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(4.dp)
    ) {
        labels.forEachIndexed { i, label ->
            val isSel = selected == i
            val bg by animateColorAsState(
                if (isSel) MaterialTheme.colorScheme.primary else Color.Transparent,
                tween(200), label = "tabBg$i"
            )
            val fg by animateColorAsState(
                if (isSel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                tween(200), label = "tabFg$i"
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(bg)
                    .clickable(role = Role.Button) { onSelect(i) }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label, color = fg, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun FontStudioSearchBar(
    value: String,
    placeholder: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        singleLine = true,
        placeholder = {
            Text(placeholder, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
        },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
        trailingIcon = {
            if (value.isNotEmpty()) {
                IconButton(onClick = { onValueChange("") }) {
                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = MaterialTheme.colorScheme.primary,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
            focusedTextColor = MaterialTheme.colorScheme.onBackground,
            unfocusedTextColor = MaterialTheme.colorScheme.onBackground,
            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier.fillMaxWidth()
    )
}

/** Small pill chip used to assign a font to App or Reader. */
@Composable
private fun ApplyChip(
    text: String,
    isActive: Boolean,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bg by animateColorAsState(
        if (isActive) accent.copy(alpha = 0.18f) else Color.Transparent,
        tween(180), label = "chipBg"
    )
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(bg)
            .border(
                1.dp,
                if (isActive) accent else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                RoundedCornerShape(10.dp)
            )
            .clickable(role = Role.Button) { onClick() }
            .padding(horizontal = 10.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (isActive) {
            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(12.dp), tint = accent)
            Spacer(modifier = Modifier.width(4.dp))
        }
        Text(
            text,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = if (isActive) accent else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun InstalledFontsView(
    readerViewModel: ReaderViewModel,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    downloadedFontsList: List<String>,
    fontListVersion: Int,
    currentAppFont: String,
    currentReaderFont: String,
    onDeleteFont: (String) -> Unit
) {
    val context = LocalContext.current
    val filtered = remember(downloadedFontsList, searchQuery) {
        if (searchQuery.isBlank()) downloadedFontsList
        else downloadedFontsList.filter { it.contains(searchQuery, ignoreCase = true) }
    }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        FontStudioSearchBar(
            value = searchQuery,
            placeholder = "Search installed fonts...",
            onValueChange = onSearchQueryChange
        )
        Spacer(modifier = Modifier.height(10.dp))

        if (filtered.isEmpty()) {
            com.lorelight.ui.components.LorelightEmpty(
                icon = Icons.Default.CloudDownload,
                title = if (searchQuery.isEmpty()) "No fonts installed yet" else "No matching fonts",
                message = if (searchQuery.isEmpty()) "Grab some from Discover." else "Try a different search.",
                compact = true,
                modifier = Modifier.weight(1f).fillMaxWidth()
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(filtered, key = { it }) { font ->
                    InstalledFontCard(
                        fontName = font,
                        fontListVersion = fontListVersion,
                        isAppFont = currentAppFont == font,
                        isReaderFont = currentReaderFont == font,
                        onApplyApp = {
                            readerViewModel.appInterfaceFont.value = font
                            Toast.makeText(context, "$font set as App font", Toast.LENGTH_SHORT).show()
                        },
                        onApplyReader = {
                            readerViewModel.readerFontFamily.value = font
                            Toast.makeText(context, "$font set as Reader font", Toast.LENGTH_SHORT).show()
                        },
                        onDelete = { onDeleteFont(font) },
                        modifier = Modifier.animateItemPlacement(tween(220))
                    )
                }
            }
        }
    }
}

@Composable
private fun InstalledFontCard(
    fontName: String,
    fontListVersion: Int,
    isAppFont: Boolean,
    isReaderFont: Boolean,
    onApplyApp: () -> Unit,
    onApplyReader: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val family = rememberAsyncFontFamily(fontName, fontListVersion)
    val isActive = isAppFont || isReaderFont
    val borderColor by animateColorAsState(
        if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
        else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f),
        tween(200), label = "cardBorder"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .border(1.dp, borderColor, RoundedCornerShape(18.dp))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Big type specimen
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Ag",
                    fontFamily = family ?: FontFamily.Default,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = fontName,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "The quiet mind is the gate to light.",
                    fontFamily = family ?: FontFamily.Default,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (!CustomFontManager.isBuiltInFont(fontName)) {
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete $fontName",
                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ApplyChip(
                text = "App Interface",
                isActive = isAppFont,
                accent = MaterialTheme.colorScheme.primary,
                onClick = onApplyApp,
                modifier = Modifier.weight(1f)
            )
            ApplyChip(
                text = "Reader",
                isActive = isReaderFont,
                accent = MaterialTheme.colorScheme.secondary,
                onClick = onApplyReader,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun DiscoverFontsView(
    readerViewModel: ReaderViewModel,
    catalog: List<GoogleFontItem>,
    isLoading: Boolean,
    errorMessage: String?,
    searchQuery: String,
    selectedCategory: String,
    sortBy: String,
    sortOptions: List<Pair<String, String>>,
    categories: List<String>,
    activeDownloads: Map<String, FontManagerEngine.DownloadState>,
    currentAppFont: String,
    currentReaderFont: String,
    onSearchQueryChange: (String) -> Unit,
    onCategoryChange: (String) -> Unit,
    onSortChange: (String) -> Unit,
    onRetryLoadCatalog: () -> Unit,
    onDownloadFont: (GoogleFontItem) -> Unit
) {
    val context = LocalContext.current
    val filteredCatalog = remember(catalog, searchQuery, selectedCategory, sortBy) {
        var result = catalog.filter { item ->
            item.family.contains(searchQuery, ignoreCase = true) &&
                (selectedCategory == "All" ||
                    item.category.replace("-", " ").equals(selectedCategory, ignoreCase = true))
        }
        when (sortBy) {
            "alpha" -> result = result.sortedBy { it.family }
            "date" -> result = result.sortedByDescending { it.lastModified }
        }
        result
    }

    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        FontStudioSearchBar(
            value = searchQuery,
            placeholder = if (catalog.isEmpty()) "Search Google Fonts..." else "Search ${catalog.size} fonts...",
            onValueChange = onSearchQueryChange
        )
        Spacer(modifier = Modifier.height(10.dp))

        // Category chips
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            items(categories, key = { it }) { cat ->
                val isSelected = selectedCategory == cat
                val bg by animateColorAsState(
                    if (isSelected) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    tween(180), label = "catBg"
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(bg)
                        .clickable(role = Role.Button) { onCategoryChange(cat) }
                        .padding(horizontal = 12.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = cat,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Sort chips + result count
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            sortOptions.forEach { (key, label) ->
                val isSel = sortBy == key
                Text(
                    text = label,
                    fontSize = 11.sp,
                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSel) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(role = Role.Button) { onSortChange(key) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
            Spacer(modifier = Modifier.weight(1f))
            if (filteredCatalog.isNotEmpty()) {
                Text(
                    text = "${filteredCatalog.size} fonts",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        when {
            isLoading -> {
                com.lorelight.ui.components.LorelightLoading(
                    shape = com.lorelight.ui.components.LoadingShape.LIST_ROWS,
                    itemCount = 6,
                    label = "Fetching Google Fonts...",
                    modifier = Modifier.weight(1f).fillMaxWidth()
                )
            }
            errorMessage != null -> {
                com.lorelight.ui.components.LorelightError(
                    message = errorMessage,
                    title = "Couldn't reach Google Fonts",
                    onRetry = onRetryLoadCatalog,
                    modifier = Modifier.weight(1f).fillMaxWidth()
                )
            }
            filteredCatalog.isEmpty() -> {
                com.lorelight.ui.components.LorelightEmpty(
                    title = "No fonts match",
                    message = "Try a different search.",
                    compact = true,
                    modifier = Modifier.weight(1f).fillMaxWidth()
                )
            }
            else -> {
                val listState = rememberLazyListState()
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(filteredCatalog, key = { it.family }) { item ->
                        DiscoverFontCard(
                            item = item,
                            dlState = activeDownloads[item.family],
                            isAppFont = currentAppFont == item.family,
                            isReaderFont = currentReaderFont == item.family,
                            onDownload = { onDownloadFont(item) },
                            onApplyApp = {
                                readerViewModel.appInterfaceFont.value = item.family
                                Toast.makeText(context, "${item.family} set as App font", Toast.LENGTH_SHORT).show()
                            },
                            onApplyReader = {
                                readerViewModel.readerFontFamily.value = item.family
                                Toast.makeText(context, "${item.family} set as Reader font", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DiscoverFontCard(
    item: GoogleFontItem,
    dlState: FontManagerEngine.DownloadState?,
    isAppFont: Boolean,
    isReaderFont: Boolean,
    onDownload: () -> Unit,
    onApplyApp: () -> Unit,
    onApplyReader: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isPreviewLoading by remember { mutableStateOf(false) }
    var fontVersionTrigger by remember { mutableStateOf(0) }

    // File IO off the main thread
    val isDownloaded by produceState(initialValue = false, item.family, dlState?.status, fontVersionTrigger) {
        value = withContext(Dispatchers.IO) {
            CustomFontManager.isFontDownloaded(context, item.family)
        }
    }

    val previewFamily = rememberAsyncFontFamily(item.family, fontVersionTrigger)

    // Deferred preview download: waits 400ms so cards flung past never hit the network
    LaunchedEffect(item.family) {
        val hasFile = withContext(Dispatchers.IO) {
            CustomFontManager.isFontDownloaded(context, item.family) ||
                CustomFontManager.getPreviewFontFile(context, item.family).exists()
        }
        if (!hasFile) {
            delay(400)
            isPreviewLoading = true
            FontManagerEngine.runPreviewOnDemandDownload(context, item, coroutineScope) {
                isPreviewLoading = false
                fontVersionTrigger++
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .border(
                1.dp,
                if (isDownloaded) MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)
                else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f),
                RoundedCornerShape(18.dp)
            )
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.family,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (item.isVariable) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text("VAR", color = MaterialTheme.colorScheme.secondary, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Text(
                    text = "${item.category.replace("-", " ")}  •  ${item.variants.size} weights",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }

            when {
                dlState?.status == "Connecting..." || dlState?.status == "Downloading..." -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            progress = { dlState.progress / 100f },
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "${dlState.progress}%",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                dlState?.status == "Failed" -> {
                    IconButton(onClick = onDownload, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Refresh, contentDescription = "Retry download", tint = MaterialTheme.colorScheme.error)
                    }
                }
                isDownloaded -> {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = "Installed",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(22.dp)
                    )
                }
                else -> {
                    IconButton(onClick = onDownload, modifier = Modifier.size(36.dp)) {
                        Icon(
                            Icons.Default.CloudDownload,
                            contentDescription = "Download ${item.family}",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (isPreviewLoading && previewFamily == null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(modifier = Modifier.size(10.dp), strokeWidth = 1.dp, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    "Loading preview...",
                    fontSize = 12.sp,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
            }
        } else {
            Text(
                text = "The quiet mind is the gate to light.",
                fontFamily = previewFamily ?: FontFamily.Default,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.92f)
            )
        }

        if (isDownloaded) {
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ApplyChip(
                    text = "App Interface",
                    isActive = isAppFont,
                    accent = MaterialTheme.colorScheme.primary,
                    onClick = onApplyApp,
                    modifier = Modifier.weight(1f)
                )
                ApplyChip(
                    text = "Reader",
                    isActive = isReaderFont,
                    accent = MaterialTheme.colorScheme.secondary,
                    onClick = onApplyReader,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
