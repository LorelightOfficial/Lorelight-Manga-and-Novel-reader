package com.lorelight.ui.onboarding

import android.content.Context
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.reader.ReaderViewModel
import com.lorelight.ui.components.StorageOnboardingScreen
import kotlinx.coroutines.delay

// ────────────────────────────── Prefs ──────────────────────────────

object OnboardingPrefs {
    private const val PREFS    = "lorelight_onboarding"
    const val KEY_CONTENT_TYPE = "ob_content_type"
    const val KEY_THEME        = "ob_theme"
    const val KEY_AUTO_UPDATES = "ob_auto_updates"
    const val KEY_WIFI_UPDATES = "ob_wifi_updates"
    const val CONTENT_NOVELS   = 0
    const val CONTENT_MANGA    = 1
    const val CONTENT_BOTH     = 2

    fun put(ctx: Context, key: String, v: String) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(key, v).apply()
    fun putBool(ctx: Context, key: String, v: Boolean) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(key, v).apply()
    fun get(ctx: Context, key: String, def: String = "") =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key, def) ?: def
    fun getBool(ctx: Context, key: String, def: Boolean = true) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(key, def)
    fun markDone(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("completed", true).apply()
    fun isDone(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("completed", false)
}

// ────────────────────────────── Steps & themes ──────────────────────────────

private enum class OnboardStep { WELCOME, STORAGE, CONTENT, LOOK, UPDATES, SOURCES, TIPS, FINISH }

private data class OTheme(val id: String, val label: String, val bg: Color, val fg: Color)
private val onboardThemes = listOf(
    OTheme("light",  "Light",  Color(0xFFFFFBFE), Color(0xFF1C1B1F)),
    OTheme("sepia",  "Sepia",  Color(0xFFF2EAD3), Color(0xFF3B2B1F)),
    OTheme("dark",   "Dark",   Color(0xFF1C1B1F), Color(0xFFE6E1E5)),
    OTheme("black",  "AMOLED", Color(0xFF000000), Color(0xFFDDDDDD)),
    OTheme("forest", "Forest", Color(0xFF1B2A1E), Color(0xFFBCD4BF)),
    OTheme("ocean",  "Ocean",  Color(0xFF0D1B2A), Color(0xFFB8D4E8)),
)

// ────────────────────────────── Entry point ──────────────────────────────

/**
 * Full onboarding flow — redesigned from scratch.
 * Smooth directional slide between steps, animated hero per step,
 * staggered entrance for each step's content.
 * Public API is unchanged.
 */
@Composable
fun OnboardingFlow(
    readerViewModel: ReaderViewModel,
    storageConfigured: Boolean,
    onStorageSelected: (String, String) -> Unit,
    onFinished: (Int) -> Unit
) {
    val context = LocalContext.current
    val steps = remember(storageConfigured) {
        OnboardStep.entries.filter { it != OnboardStep.STORAGE || !storageConfigured }
    }
    var idx           by remember { mutableIntStateOf(0) }
    var forward       by remember { mutableStateOf(true) }
    var contentChoice by remember { mutableIntStateOf(OnboardingPrefs.CONTENT_BOTH) }
    var themeId       by remember { mutableStateOf(OnboardingPrefs.get(context, OnboardingPrefs.KEY_THEME, "dark")) }
    var autoUp        by remember { mutableStateOf(OnboardingPrefs.getBool(context, OnboardingPrefs.KEY_AUTO_UPDATES)) }
    var wifiUp        by remember { mutableStateOf(OnboardingPrefs.getBool(context, OnboardingPrefs.KEY_WIFI_UPDATES)) }

    fun advance() {
        if (idx < steps.lastIndex) { forward = true; idx++ }
        else { OnboardingPrefs.markDone(context); onFinished(contentChoice) }
    }
    fun back() { if (idx > 0) { forward = false; idx-- } }

    val step = steps[idx]
    val isLast = idx == steps.lastIndex
    val showStorage = step == OnboardStep.STORAGE

    Box(
        modifier = Modifier.fillMaxSize()
            .background(Brush.verticalGradient(
                0f   to MaterialTheme.colorScheme.background,
                0.55f to MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.11f),
                1f   to MaterialTheme.colorScheme.background
            ))
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // Progress dots – hidden when storage step shows its own UI
        if (!showStorage) {
            StepDots(count = steps.size, current = idx,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 22.dp))
        }

        // Animated step content
        AnimatedContent(
            targetState = idx,
            transitionSpec = {
                val d = if (forward) 1 else -1
                (slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { it * d } + fadeIn(tween(200)))
                    .togetherWith(slideOutHorizontally(tween(280)) { -it * d } + fadeOut(tween(160)))
            },
            modifier = Modifier.fillMaxSize(),
            label = "obStep"
        ) { i ->
            when (steps.getOrElse(i) { OnboardStep.WELCOME }) {
                OnboardStep.WELCOME  -> WelcomeStep()
                OnboardStep.STORAGE  -> StorageOnboardingScreen {
                    uri, name -> onStorageSelected(uri, name); advance()
                }
                OnboardStep.CONTENT  -> ContentStep(contentChoice) { contentChoice = it }
                OnboardStep.LOOK     -> LookStep(themeId) {
                    themeId = it
                    OnboardingPrefs.put(context, OnboardingPrefs.KEY_THEME, it)
                    readerViewModel.applyTheme(it)
                }
                OnboardStep.UPDATES  -> UpdatesStep(autoUp, wifiUp,
                    { autoUp = it; OnboardingPrefs.putBool(context, OnboardingPrefs.KEY_AUTO_UPDATES, it) },
                    { wifiUp = it; OnboardingPrefs.putBool(context, OnboardingPrefs.KEY_WIFI_UPDATES, it) }
                )
                OnboardStep.SOURCES  -> SourcesStep()
                OnboardStep.TIPS     -> TipsStep()
                OnboardStep.FINISH   -> FinishStep()
            }
        }

        // Bottom nav bar — hidden for STORAGE which has its own CTA
        if (!showStorage) {
            Row(
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (idx > 0) TextButton(onClick = ::back) {
                    Text("Back", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else Spacer(Modifier.width(64.dp))

                Button(
                    onClick = ::advance,
                    shape = CircleShape,
                    modifier = Modifier.height(50.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor   = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text(
                        when { isLast -> "  GET STARTED  "; step == OnboardStep.WELCOME -> "  LET'S GO  "; else -> "  NEXT  " },
                        fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp
                    )
                }

                val canSkip = step != OnboardStep.WELCOME && !isLast
                if (canSkip) TextButton(onClick = ::advance) {
                    Text("Skip", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f))
                } else Spacer(Modifier.width(64.dp))
            }
        }
    }
}

// ────────────────────────────── Progress dots ──────────────────────────────

@Composable
private fun StepDots(count: Int, current: Int, modifier: Modifier = Modifier) {
    Row(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(count) { i ->
            val on = i == current
            Box(Modifier.height(6.dp).width(if (on) 22.dp else 6.dp).clip(CircleShape)
                .background(if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.22f)))
        }
    }
}

// ────────────────────────────── Shared scaffold ──────────────────────────────

@Composable
private fun OBScaffold(hero: @Composable () -> Unit, title: String, sub: String, body: (@Composable () -> Unit)? = null) {
    var on by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(60); on = true }
    Column(
        Modifier.fillMaxSize().padding(horizontal = 28.dp).padding(top = 68.dp, bottom = 100.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AnimatedVisibility(on, enter = fadeIn(tween(380)) + androidx.compose.animation.slideInVertically(tween(400, easing = FastOutSlowInEasing)) { it / 5 }) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { hero() }
        }
        Spacer(Modifier.height(30.dp))
        AnimatedVisibility(on, enter = fadeIn(tween(320, 80))) {
            Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground, textAlign = TextAlign.Center, letterSpacing = (-0.3).sp)
        }
        Spacer(Modifier.height(10.dp))
        AnimatedVisibility(on, enter = fadeIn(tween(320, 140))) {
            Text(sub, fontSize = 13.sp, lineHeight = 19.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.60f), textAlign = TextAlign.Center)
        }
        if (body != null) {
            Spacer(Modifier.height(26.dp))
            AnimatedVisibility(on, enter = fadeIn(tween(320, 200))) { body() }
        }
    }
}

// ────────────────────────────── WELCOME ──────────────────────────────

@Composable
private fun WelcomeStep() {
    OBScaffold(
        hero = {
            val pulse = rememberInfiniteTransition(label = "wP")
            val sc by pulse.animateFloat(1f, 1.14f, infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(120.dp)) {
                Box(Modifier.size(114.dp).scale(sc).clip(CircleShape).background(Brush.radialGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.09f), Color.Transparent))))
                Box(Modifier.size(76.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.20f), MaterialTheme.colorScheme.primary.copy(alpha = 0.06f))))
                    .border(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.20f), CircleShape),
                    contentAlignment = Alignment.Center) {
                    Text("L", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                }
            }
        },
        title = "Welcome to Lorelight",
        sub   = "Your pocket library for light novels, manga, and web fiction.\nFree, offline-first, and always yours."
    ) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            FeaturePill(Icons.Default.MenuBook,     "Novels & web fiction, beautifully formatted")
            FeaturePill(Icons.Default.AutoStories,  "Manga with built-in image reader and OCR")
            FeaturePill(Icons.Default.Language,     "Hundreds of community sources, worldwide")
            FeaturePill(Icons.Default.CheckCircle,  "Fully offline once downloaded")
        }
    }
}

// ────────────────────────────── CONTENT ──────────────────────────────

@Composable
private fun ContentStep(sel: Int, onSel: (Int) -> Unit) {
    OBScaffold(
        hero = {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.MenuBook, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
                Text("+", fontSize = 24.sp, fontWeight = FontWeight.Light, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.35f))
                Icon(Icons.Default.AutoStories, null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(40.dp))
            }
        },
        title = "What do you like to read?",
        sub   = "We'll surface the right sources and browsing experience for you."
    ) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            OptionCard(Icons.Default.MenuBook,          "Light Novels & Web Fiction", "Text-based stories, chapter by chapter",         sel == OnboardingPrefs.CONTENT_NOVELS) { onSel(OnboardingPrefs.CONTENT_NOVELS) }
            OptionCard(Icons.Default.AutoStories,       "Manga",                      "Image reader with zoom and OCR support",         sel == OnboardingPrefs.CONTENT_MANGA)  { onSel(OnboardingPrefs.CONTENT_MANGA)  }
            OptionCard(Icons.Default.CollectionsBookmark, "Both",                     "Full Lorelight — novels and manga together",      sel == OnboardingPrefs.CONTENT_BOTH)   { onSel(OnboardingPrefs.CONTENT_BOTH)   }
        }
    }
}

// ────────────────────────────── LOOK ──────────────────────────────

@Composable
private fun LookStep(themeId: String, onSel: (String) -> Unit) {
    OBScaffold(
        hero = { Icon(Icons.Default.ColorLens, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(52.dp)) },
        title = "Pick your reading theme",
        sub   = "Changes the reader and chapter background.\nYou can switch any time in Settings."
    ) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            onboardThemes.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { t ->
                        val sel = themeId == t.id
                        Box(
                            modifier = Modifier.weight(1f).height(52.dp).clip(RoundedCornerShape(14.dp))
                                .background(t.bg)
                                .border(if (sel) 2.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.15f), RoundedCornerShape(14.dp))
                                .clickable(role = Role.Button) { onSel(t.id) },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                if (sel) Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
                                Text(t.label, fontSize = 11.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal, color = t.fg)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ────────────────────────────── UPDATES ──────────────────────────────

@Composable
private fun UpdatesStep(auto: Boolean, wifi: Boolean, onAuto: (Boolean) -> Unit, onWifi: (Boolean) -> Unit) {
    OBScaffold(
        hero = { Icon(Icons.Default.Notifications, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(52.dp)) },
        title = "Stay up to date",
        sub   = "Lorelight can check your library for new chapters and queue them for offline reading while you sleep."
    ) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.34f)).padding(16.dp)) {
            TogRow(Icons.Default.Update, "Auto-download new chapters", auto, onAuto)
            AnimatedVisibility(auto) {
                Column {
                    Spacer(Modifier.height(4.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outline.copy(alpha = 0.12f)))
                    Spacer(Modifier.height(4.dp))
                    TogRow(Icons.Default.WbSunny, "Wi-Fi only", wifi, onWifi)
                }
            }
        }
    }
}

// ────────────────────────────── SOURCES ──────────────────────────────

@Composable
private fun SourcesStep() {
    OBScaffold(
        hero = { Icon(Icons.Default.Language, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(52.dp)) },
        title = "Explore hundreds of sources",
        sub   = "Community-maintained plugins for novels and manga in dozens of languages. Install and remove them any time."
    ) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            FeaturePill(Icons.Default.Search,      "Search across all installed sources at once")
            FeaturePill(Icons.Default.Language,    "Sources in English, Japanese, Korean & more")
            FeaturePill(Icons.Default.PhoneAndroid, "Install new sources from the in-app catalogue")
        }
    }
}

// ────────────────────────────── TIPS ──────────────────────────────

@Composable
private fun TipsStep() {
    OBScaffold(
        hero = { Icon(Icons.Default.TouchApp, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(52.dp)) },
        title = "A few gestures to know",
        sub   = "Lorelight is built for fast, one-handed reading."
    ) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            TipRow("👆", "Tap left / right edge",    "Previous or next chapter")
            TipRow("👇", "Tap the bottom of screen", "Jump to the chapter list")
            TipRow("💪", "Hold volume button",        "Hands-free page flip")
            TipRow("⇕",  "Swipe up on reader",       "Open the floating settings panel")
        }
    }
}

// ────────────────────────────── FINISH ──────────────────────────────

@Composable
private fun FinishStep() {
    val pulse = rememberInfiniteTransition(label = "fin")
    val sc by pulse.animateFloat(0.90f, 1.10f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
    OBScaffold(
        hero = {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(110.dp)) {
                Box(Modifier.size(104.dp).scale(sc).clip(CircleShape).background(Brush.radialGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f), Color.Transparent))))
                Box(Modifier.size(72.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.20f), MaterialTheme.colorScheme.primary.copy(alpha = 0.07f))))
                    .border(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.22f), CircleShape),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(38.dp))
                }
            }
        },
        title = "You're all set!",
        sub   = "Your library is ready. Head to Browse to discover your first title, or open Downloads to grab something for offline reading."
    )
}

// ────────────────────────────── Shared small composables ──────────────────────────────

@Composable
private fun FeaturePill(icon: ImageVector, text: String) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.34f))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
        Text(text, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun OptionCard(icon: ImageVector, label: String, desc: String, sel: Boolean, onClick: () -> Unit) {
    val bg  = if (sel) MaterialTheme.colorScheme.primary.copy(alpha = 0.13f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.30f)
    val bdc = if (sel) MaterialTheme.colorScheme.primary.copy(alpha = 0.62f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.18f)
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(bg)
            .border(1.5.dp, bdc, RoundedCornerShape(16.dp))
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(Modifier.size(38.dp).clip(CircleShape).background(if (sel) MaterialTheme.colorScheme.primary.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
            Text(desc, fontSize = 11.sp, lineHeight = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.72f))
        }
        if (sel) Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(17.dp))
    }
}

@Composable
private fun TogRow(icon: ImageVector, label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun TipRow(emoji: String, gesture: String, result: String) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.34f))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(emoji, fontSize = 22.sp)
        Column {
            Text(gesture, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
            Text(result, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f))
        }
    }
}
