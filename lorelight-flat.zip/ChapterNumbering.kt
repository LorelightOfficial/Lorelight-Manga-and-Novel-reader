package com.lorelight.util

import com.lorelight.data.model.Novel

object ChapterNumbering {
    private val DECIMAL_REGEX = Regex("""(\d+(?:\.\d+)?)""")

    /**
     * Resolves the numeric value for a chapter at [index] in [novel], or parsed from [name].
     * Priority:
     * 1) Source provided number >= 0 (from novel.chapterNumbers)
     * 2) Decimal-aware regex parse from name
     * 3) null if unknown
     */
    fun resolveChapterNumber(
        novel: Novel?,
        index: Int,
        name: String
    ): Float? {
        val sourceNumber = novel?.chapterNumbers?.getOrNull(index)
        if (sourceNumber != null && sourceNumber >= 0f) {
            return sourceNumber
        }
        return parseChapterNumberFromName(name)
    }

    fun parseChapterNumberFromName(name: String): Float? {
        val match = DECIMAL_REGEX.find(name) ?: return null
        return match.groupValues[1].toFloatOrNull()
    }

    /**
     * Formats a Float chapter number:
     * 1.0f -> "1", 12.0f -> "12", 0.1f -> "0.1", 12.5f -> "12.5"
     */
    fun formatChapterNumber(num: Float): String {
        return if (num % 1.0f == 0.0f) {
            num.toInt().toString()
        } else {
            num.toString().trimEnd('0').trimEnd('.')
        }
    }

    /**
     * Resolves the display label for a chapter.
     * When the number is null OR the raw title clearly isn't a blank / plain placeholder,
     * displays the original title instead of fabricating "Chapter N".
     */
    fun formatDisplayLabel(
        number: Float?,
        rawName: String
    ): String {
        val trimmed = rawName.trim()
        if (trimmed.isEmpty() || trimmed.equals("Chapter", ignoreCase = true)) {
            return if (number != null) "Chapter ${formatChapterNumber(number)}" else "Chapter"
        }
        return rawName
    }
}
