package com.lorelight.browse.js

import org.json.JSONArray
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.nodes.Node
import org.jsoup.nodes.TextNode

/**
 * Jsoup-backed, handle-based DOM operations behind the cheerio shim.
 * One instance per QuickJS context; accessed only on that context's single JS thread.
 * Selection ops return a JSON array string of int handles (parsed in JS).
 * Scalar ops return Int handle (-1 = none), String (null = missing), or Boolean.
 */
class CheerioBridge {
    private val handles = HashMap<Int, Node>()
    private var counter = 1

    private fun put(node: Node): Int { val id = counter++; handles[id] = node; return id }
    private fun get(handle: Int): Node? = handles[handle]
    private fun asElement(handle: Int): Element? = handles[handle] as? Element

    private fun toHandleArray(nodes: List<Node>): String {
        val arr = JSONArray()
        for (n in nodes) arr.put(put(n))
        return arr.toString()
    }

    fun parse(html: String): Int = put(Jsoup.parse(html))

    fun select(handle: Int, css: String): String {
        val el = asElement(handle) ?: return "[]"
        return toHandleArray(el.select(css).toList())
    }

    fun selectOne(handle: Int, css: String): Int {
        val el = asElement(handle) ?: return -1
        val found = el.selectFirst(css) ?: return -1
        return put(found)
    }

    fun children(handle: Int): String {
        val el = asElement(handle) ?: return "[]"
        return toHandleArray(el.children().toList())
    }

    fun childrenSelector(handle: Int, css: String): String {
        val el = asElement(handle) ?: return "[]"
        return toHandleArray(el.children().filter { it.`is`(css) })
    }

    fun contents(handle: Int): String {
        val el = asElement(handle) ?: return "[]"
        return toHandleArray(el.childNodes())
    }

    fun text(handle: Int): String {
        return when (val node = get(handle)) {
            is Element -> node.text()
            is TextNode -> node.text()
            null -> ""
            else -> node.toString()
        }
    }

    fun ownText(handle: Int): String = asElement(handle)?.ownText() ?: ""

    fun html(handle: Int): String {
        return when (val node = get(handle)) {
            is Document -> node.html()
            is Element -> node.html()
            else -> ""
        }
    }

    fun outerHtml(handle: Int): String = get(handle)?.outerHtml() ?: ""

    fun attr(handle: Int, name: String): String? {
        val el = asElement(handle) ?: return null
        return if (el.hasAttr(name)) el.attr(name) else null
    }

    fun setAttr(handle: Int, name: String, value: String) { asElement(handle)?.attr(name, value) }

    fun prop(handle: Int, name: String): String? {
        val el = asElement(handle) ?: return null
        return when (name.lowercase()) {
            "tagname" -> el.tagName().uppercase()
            "outerhtml" -> el.outerHtml()
            "innerhtml" -> el.html()
            "href", "src" -> el.absUrl(name).ifEmpty { if (el.hasAttr(name)) el.attr(name) else null }
            else -> if (el.hasAttr(name)) el.attr(name) else null
        }
    }

    fun data(handle: Int, key: String): String? = attr(handle, "data-$key")

    fun value(handle: Int): String = asElement(handle)?.`val`() ?: ""

    fun hasClass(handle: Int, cls: String): Boolean = asElement(handle)?.hasClass(cls) ?: false
    fun addClass(handle: Int, cls: String) { asElement(handle)?.addClass(cls) }
    fun removeClass(handle: Int, cls: String) { asElement(handle)?.removeClass(cls) }
    fun className(handle: Int): String = asElement(handle)?.className() ?: ""

    fun remove(handle: Int) { get(handle)?.remove() }

    fun parent(handle: Int): Int { val p = get(handle)?.parent() ?: return -1; return put(p) }

    fun parents(handle: Int): String {
        val el = asElement(handle) ?: return "[]"
        return toHandleArray(el.parents().toList())
    }

    fun closest(handle: Int, css: String): Int {
        var cur: Element? = asElement(handle)
        while (cur != null) { if (cur.`is`(css)) return put(cur); cur = cur.parent() }
        return -1
    }

    fun next(handle: Int): Int { val n = asElement(handle)?.nextElementSibling() ?: return -1; return put(n) }
    fun prev(handle: Int): Int { val n = asElement(handle)?.previousElementSibling() ?: return -1; return put(n) }

    fun nextAll(handle: Int): String {
        val el = asElement(handle) ?: return "[]"
        val list = ArrayList<Node>()
        var cur = el.nextElementSibling()
        while (cur != null) { list.add(cur); cur = cur.nextElementSibling() }
        return toHandleArray(list)
    }

    fun prevAll(handle: Int): String {
        val el = asElement(handle) ?: return "[]"
        val list = ArrayList<Node>()
        var cur = el.previousElementSibling()
        while (cur != null) { list.add(cur); cur = cur.previousElementSibling() }
        return toHandleArray(list)
    }

    fun siblings(handle: Int): String {
        val el = asElement(handle) ?: return "[]"
        val parent = el.parent() ?: return "[]"
        return toHandleArray(parent.children().filter { it !== el })
    }

    fun isMatch(handle: Int, css: String): Boolean = asElement(handle)?.`is`(css) ?: false

    fun replaceWith(handle: Int, html: String) { val el = asElement(handle) ?: return; el.before(html); el.remove() }
    fun before(handle: Int, html: String) { asElement(handle)?.before(html) }
    fun after(handle: Int, html: String) { asElement(handle)?.after(html) }
    fun append(handle: Int, html: String) { asElement(handle)?.append(html) }
    fun prepend(handle: Int, html: String) { asElement(handle)?.prepend(html) }
    fun empty(handle: Int) { asElement(handle)?.empty() }

    fun css(handle: Int, prop: String): String {
        val style = asElement(handle)?.attr("style") ?: return ""
        for (part in style.split(";")) {
            val kv = part.split(":", limit = 2)
            if (kv.size == 2 && kv[0].trim().equals(prop, ignoreCase = true)) return kv[1].trim()
        }
        return ""
    }

    fun count(handle: Int): Int = asElement(handle)?.children()?.size ?: 0

    // Do NOT reset counter. Two entry points (e.g. the reader and the TTS
    // background prefetch) can share one plugin context and interleave calls.
    // Resetting the counter lets a disposed call's stale handle numbers get
    // silently reissued to a different call's new nodes, returning wrong data.
    // Leaving the counter monotonic means a stale handle simply misses (get()
    // returns null) instead of aliasing something else.
    fun disposeAll() { handles.clear() }
}
