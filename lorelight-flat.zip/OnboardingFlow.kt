package com.lorelight.ui.onboarding

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.lorelight.data.local.AppPrefs
import com.lorelight.ui.reader.ReaderViewModel
import com.lorelight.ui.settings.AppearanceThemeControls
import com.lorelight.work.LibraryUpdateScheduler
import com.lorelight.ui.components.StorageOnboardingScreen
import kotlinx.coroutines.delay

// ────────────────────────────── Prefs ──────────────────────────────

object OnboardingPrefs {
    private const val PREFS    = "lorelight_onboarding"
    const val KEY_THEME        = "ob_theme"
    const val KEY_AUTO_UPDATES = "ob_auto_updates"
    const val KEY_WIFI_UPDATES = "ob_wifi_updates"

    fun put(ctx: Context, key: String, v: String) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(key, v).apply()
    fun putBool(ctx: Context, key: String, v: Boolean) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(key, v).apply()
    fun get(ctx: Context, key: String, def: String = "") =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key, def) ?: def
    fun getBool(ctx: Context, key: String, def: Boolean = true) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(key, def)
    fun markDone(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("completed", true).apply()
    fun isDone(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("completed", false)
    /** Alias of [isDone] used by MainActivity's onboarding gate. */
    fun isComplete(ctx: Context) = isDone(ctx)
    /** Clears the completed flag so the onboarding flow runs again next launch. */
    fun reset(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("completed", false).apply()
}

// ────────────────────────────── Steps ──────────────────────────────

private enum class OnboardStep { WELCOME, STORAGE, LOOK, UPDATES, SOURCES, FINISH }

// ────────────────────────────── Entry point ──────────────────────────────

/**
 * Full onboarding flow — redesigned from scratch.
 * Smooth directional slide between steps, animated hero per step,
 * staggered entrance for each step's content.
 * Public API is unchanged.
 */
@Composable
fun OnboardingFlow(
    readerViewModel: ReaderViewModel,
    storageConfigured: Boolean,
    onStorageSelected: (String, String) -> Unit,
    onFinished: (Int) -> Unit
) {
    val context = LocalContext.current
    // Freeze the route for this run. Choosing storage updates the parent;
    // rebuilding the route then would shift later indices and skip the theme page.
    val includeStorage = rememberSaveable { !storageConfigured }
    val steps = remember(includeStorage) {
        OnboardStep.entries.filter { it != OnboardStep.STORAGE || includeStorage }
    }
    val libraryPrefs = remember(context) { AppPrefs.get(context) }
    var idx by rememberSaveable { mutableIntStateOf(0) }
    var forward by rememberSaveable { mutableStateOf(true) }
    var autoUp by rememberSaveable {
        mutableStateOf(OnboardingPrefs.getBool(context, OnboardingPrefs.KEY_AUTO_UPDATES))
    }
    var wifiUp by rememberSaveable {
        mutableStateOf(OnboardingPrefs.getBool(
            context, OnboardingPrefs.KEY_WIFI_UPDATES,
            libraryPrefs.getBoolean("lib_update_wifi_only", true)
        ))
    }
    // This is the real Settings > Library preference, not an onboarding-only flag.
    var chapterNotifications by remember {
        mutableStateOf(libraryPrefs.getBoolean("lib_update_enabled", false))
    }
    var notificationPermissionDenied by rememberSaveable { mutableStateOf(false) }

    fun syncChapterNotificationWork() {
        if (chapterNotifications) {
            LibraryUpdateScheduler.schedule(
                context,
                libraryPrefs.getLong("lib_update_hours", 12L),
                wifiUp,
                libraryPrefs.getBoolean("lib_update_charging_only", false)
            )
        } else {
            LibraryUpdateScheduler.cancel(context)
        }
    }

    fun setChapterNotifications(enabled: Boolean) {
        chapterNotifications = enabled
        libraryPrefs.edit()
            .putBoolean("lib_update_enabled", enabled)
            .putBoolean("lib_update_wifi_only", wifiUp)
            .apply()
        syncChapterNotificationWork()
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        notificationPermissionDenied = !granted
        setChapterNotifications(granted)
    }

    fun advance() {
        if (idx < steps.lastIndex) { forward = true; idx++ }
        else { OnboardingPrefs.markDone(context); onFinished(0) } // Open Library; no media-choice step.
    }
    fun back() { if (idx > 0) { forward = false; idx-- } }

    val step = steps[idx]
    val isLast = idx == steps.lastIndex
    val showStorage = step == OnboardStep.STORAGE

    Column(
        modifier = Modifier.fillMaxSize()
            .background(Brush.verticalGradient(
                0f   to MaterialTheme.colorScheme.background,
                0.55f to MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.11f),
                1f   to MaterialTheme.colorScheme.background
            ))
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // Progress dots – hidden when storage step shows its own UI
        if (!showStorage) {
            StepDots(count = steps.size, current = idx,
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 22.dp, bottom = 18.dp))
        }

        // Animated step content
        AnimatedContent(
            targetState = idx,
            transitionSpec = {
                val d = if (forward) 1 else -1
                (slideInHorizontally(tween(320, easing = FastOutSlowInEasing)) { it * d } + fadeIn(tween(200)))
                    .togetherWith(slideOutHorizontally(tween(280)) { -it * d } + fadeOut(tween(160)))
            },
            modifier = Modifier.weight(1f).fillMaxWidth(),
            label = "obStep"
        ) { i ->
            when (steps.getOrElse(i) { OnboardStep.WELCOME }) {
                OnboardStep.WELCOME  -> WelcomeStep()
                OnboardStep.STORAGE  -> StorageOnboardingScreen {
                    uri, name -> onStorageSelected(uri, name); advance()
                }
                OnboardStep.LOOK     -> LookStep(readerViewModel)
                OnboardStep.UPDATES  -> UpdatesStep(
                    auto = autoUp,
                    wifi = wifiUp,
                    chapterNotifications = chapterNotifications,
                    notificationPermissionDenied = notificationPermissionDenied,
                    onAuto = {
                        autoUp = it
                        OnboardingPrefs.putBool(context, OnboardingPrefs.KEY_AUTO_UPDATES, it)
                    },
                    onWifi = {
                        wifiUp = it
                        OnboardingPrefs.putBool(context, OnboardingPrefs.KEY_WIFI_UPDATES, it)
                        libraryPrefs.edit().putBoolean("lib_update_wifi_only", it).apply()
                        syncChapterNotificationWork()
                    },
                    onChapterNotifications = { enabled ->
                        notificationPermissionDenied = false
                        if (enabled && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
                            PackageManager.PERMISSION_GRANTED
                        ) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            setChapterNotifications(enabled)
                        }
                    }
                )
                OnboardStep.SOURCES  -> SourcesStep()
                OnboardStep.FINISH   -> FinishStep()
            }
        }

        // Bottom nav bar — hidden for STORAGE which has its own CTA
        if (!showStorage) {
            Row(
                modifier = Modifier.fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (idx > 0) TextButton(onClick = ::back) {
                        Text("Back", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Button(
                    onClick = ::advance,
                    shape = CircleShape,
                    modifier = Modifier.heightIn(min = 50.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor   = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text(
                        when { isLast -> "  GET STARTED  "; step == OnboardStep.WELCOME -> "  LET'S GO  "; else -> "  NEXT  " },
                        fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp
                    )
                }

                val canSkip = step != OnboardStep.WELCOME && !isLast
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                    if (canSkip) TextButton(onClick = ::advance) {
                        Text("Skip", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f))
                    }
                }
            }
        }
    }
}

// ────────────────────────────── Progress dots ──────────────────────────────

@Composable
private fun StepDots(count: Int, current: Int, modifier: Modifier = Modifier) {
    Row(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        repeat(count) { i ->
            val on = i == current
            Box(Modifier.height(6.dp).width(if (on) 22.dp else 6.dp).clip(CircleShape)
                .background(if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.22f)))
        }
    }
}

// ────────────────────────────── Shared scaffold ──────────────────────────────

@Composable
private fun OBScaffold(hero: @Composable () -> Unit, title: String, sub: String, body: (@Composable () -> Unit)? = null) {
    var on by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(60); on = true }
    Column(
        // Scroll only the body; all cards measure at their natural height.
        // The parent reserves separate, measured slots for dots and buttons.
        Modifier.fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AnimatedVisibility(on, enter = fadeIn(tween(380)) + androidx.compose.animation.slideInVertically(tween(400, easing = FastOutSlowInEasing)) { it / 5 }) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { hero() }
        }
        Spacer(Modifier.height(30.dp))
        AnimatedVisibility(on, enter = fadeIn(tween(320, 80))) {
            Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground, textAlign = TextAlign.Center, letterSpacing = (-0.3).sp)
        }
        Spacer(Modifier.height(10.dp))
        AnimatedVisibility(on, enter = fadeIn(tween(320, 140))) {
            Text(sub, fontSize = 13.sp, lineHeight = 19.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.60f), textAlign = TextAlign.Center)
        }
        if (body != null) {
            Spacer(Modifier.height(26.dp))
            AnimatedVisibility(on, enter = fadeIn(tween(320, 200))) { body() }
        }
    }
}

// ────────────────────────────── WELCOME ──────────────────────────────

@Composable
private fun WelcomeStep() {
    OBScaffold(
        hero = {
            val pulse = rememberInfiniteTransition(label = "wP")
            val sc by pulse.animateFloat(1f, 1.14f, infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(120.dp)) {
                Box(Modifier.size(114.dp).scale(sc).clip(CircleShape).background(Brush.radialGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.09f), Color.Transparent))))
                Box(Modifier.size(76.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.20f), MaterialTheme.colorScheme.primary.copy(alpha = 0.06f))))
                    .border(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.20f), CircleShape),
                    contentAlignment = Alignment.Center) {
                    Text("L", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                }
            }
        },
        title = "Welcome to Lorelight",
        sub   = "Your pocket library for light novels, manga, and web fiction.\nFree, offline-first, and always yours."
    ) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            FeaturePill(Icons.Default.MenuBook,     "Novels & web fiction, beautifully formatted")
            FeaturePill(Icons.Default.AutoStories,  "Manga with built-in image reader and OCR")
            FeaturePill(Icons.Default.Language,     "Hundreds of community sources, worldwide")
            FeaturePill(Icons.Default.CheckCircle,  "Fully offline once downloaded")
        }
    }
}

// ────────────────────────────── LOOK ──────────────────────────────

@Composable
private fun LookStep(readerViewModel: ReaderViewModel) {
    OBScaffold(
        hero = { Icon(Icons.Default.ColorLens, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(52.dp)) },
        title = "Pick your reading theme",
        sub = "Choose your app theme and display mode.\nThese are the same options as Settings > Appearance."
    ) {
        AppearanceThemeControls(readerViewModel)
    }
}

// ────────────────────────────── UPDATES ──────────────────────────────

@Composable
private fun UpdatesStep(
    auto: Boolean,
    wifi: Boolean,
    chapterNotifications: Boolean,
    notificationPermissionDenied: Boolean,
    onAuto: (Boolean) -> Unit,
    onWifi: (Boolean) -> Unit,
    onChapterNotifications: (Boolean) -> Unit
) {
    OBScaffold(
        hero = { Icon(Icons.Default.Notifications, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(52.dp)) },
        title = "Stay up to date",
        sub = "Choose your download preferences and get notified when your library has new chapters."
    ) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.34f))
                    .padding(16.dp)
            ) {
                TogRow(Icons.Default.Update, "Auto-download new chapters", auto, onAuto)
                UpdateDivider()
                // Keep this visible: notifications can use Wi-Fi even with downloads off.
                TogRow(Icons.Default.Wifi, "Wi-Fi only", wifi, onWifi)
                UpdateDivider()
                TogRow(Icons.Default.NotificationsActive, "New chapter notifications", chapterNotifications, onChapterNotifications)
            }
            Text(
                text = if (notificationPermissionDenied) {
                    "Notification permission wasn't granted. You can continue without alerts, or allow notifications in your phone's app settings and turn this on again."
                } else {
                    "Chapter notifications can be enabled without auto-downloads. You can change them later in Settings > Library."
                },
                fontSize = 13.sp,
                lineHeight = 19.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun UpdateDivider() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outline.copy(alpha = 0.12f)))
}

// ────────────────────────────── SOURCES ──────────────────────────────

@Composable
private fun SourcesStep() {
    OBScaffold(
        hero = { Icon(Icons.Default.Language, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(52.dp)) },
        title = "Explore hundreds of sources",
        sub   = "Community-maintained plugins for novels and manga in dozens of languages. Install and remove them any time."
    ) {
        Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            FeaturePill(Icons.Default.Search,      "Search across all installed sources at once")
            FeaturePill(Icons.Default.Language,    "Sources in English, Japanese, Korean & more")
            FeaturePill(Icons.Default.PhoneAndroid, "Install new sources from the in-app catalogue")
        }
    }
}

// ────────────────────────────── FINISH ──────────────────────────────

@Composable
private fun FinishStep() {
    val pulse = rememberInfiniteTransition(label = "fin")
    val sc by pulse.animateFloat(0.90f, 1.10f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s")
    OBScaffold(
        hero = {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(110.dp)) {
                Box(Modifier.size(104.dp).scale(sc).clip(CircleShape).background(Brush.radialGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f), Color.Transparent))))
                Box(Modifier.size(72.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.20f), MaterialTheme.colorScheme.primary.copy(alpha = 0.07f))))
                    .border(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.22f), CircleShape),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(38.dp))
                }
            }
        },
        title = "You're all set!",
        sub   = "Your library is ready. Head to Browse to discover your first title, or open Downloads to grab something for offline reading."
    )
}

// ────────────────────────────── Shared small composables ──────────────────────────────

@Composable
private fun FeaturePill(icon: ImageVector, text: String) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.34f))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
        Text(text, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun TogRow(icon: ImageVector, label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .toggleable(value = checked, role = Role.Switch, onValueChange = onChange)
            .heightIn(min = 56.dp)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Text(label, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = null)
    }
}

