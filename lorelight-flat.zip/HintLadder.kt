/*
 * =============================================================================
 * HintLadder.kt - teaching the user that the sun is a button.
 * Package: com.lorelight.companion
 *
 * THE PROBLEM THIS SOLVES
 *
 * The sun/moon on the altar is the light/dark theme toggle. It is also the
 * prettiest thing on the screen, which means a lot of people will read it as
 * decoration and never once tap it - and never find out the app has a whole
 * other skin.
 *
 * A tooltip would fix that and cheapen everything. So the character tells you
 * himself, and does it in character: five launches, five escalating hints,
 * each one a little more exasperated that you still have not pressed him.
 *
 * THE RULES
 *
 *  - Rung 0..4 map to launches 1..5. One hint per launch, never two.
 *  - The ladder is CANCELLED FOREVER the moment the user toggles even once.
 *    He has learned it; mentioning it again would be nagging.
 *  - After the five rungs are spent, the ladder stops permanently on its own.
 *  - After an app UPDATE, a user who has STILL never toggled gets one more
 *    nudge, and one more on the third launch after that. Then permanent
 *    silence.
 *  - The first-ever toggle earns a payoff line, spoken immediately by the
 *    mood that just arrived. That line outranks the ordinary MODE_SWITCHED
 *    comment that one time - it is the punchline to five hints.
 *
 * Hint lines are curated whole sentences. No opener, no tail, ever.
 * =============================================================================
 */
package com.lorelight.companion

class HintLadder(
    private val store: CompanionStore,
    private val corpus: CompanionCorpus,
    private val assembler: LineAssembler
) {

    /* --- state ------------------------------------------------------------ */

    val hasEverToggled: Boolean
        get() = store.getBoolean(EVER_TOGGLED, false)

    private val rung: Int
        get() = store.getInt(RUNG, 0)

    private val launchCount: Int
        get() = store.getInt(LAUNCHES, 0)

    /* --- lifecycle -------------------------------------------------------- */

    /**
     * Call once per app start, before asking for a hint.
     *
     * @param appVersionCode the running build, so an update can be detected.
     */
    fun onLaunch(appVersionCode: Int) {
        store.putInt(LAUNCHES, launchCount + 1)

        val seenVersion = store.getInt(SEEN_VERSION, -1)
        if (seenVersion != appVersionCode) {
            store.putInt(SEEN_VERSION, appVersionCode)
            // Only meaningful for someone who never found the toggle. A user
            // who already knows gets nothing, forever.
            if (seenVersion != -1 && !hasEverToggled) {
                store.putInt(UPDATE_LAUNCHES, 1)
            }
        } else if (store.getInt(UPDATE_LAUNCHES, 0) in 1 until UPDATE_NUDGE_LAST) {
            store.putInt(UPDATE_LAUNCHES, store.getInt(UPDATE_LAUNCHES, 0) + 1)
        }
    }

    /**
     * Records the user tapping the toggle.
     *
     * @return true if this was the FIRST time ever, which earns the payoff.
     */
    fun noteToggled(): Boolean {
        if (hasEverToggled) return false
        store.putBoolean(EVER_TOGGLED, true)
        return true
    }

    /* --- lines ------------------------------------------------------------ */

    /**
     * The payoff line, spoken once, by the mood that just took the sky.
     * Returns null unless this really was the first toggle.
     */
    fun payoffLine(newMood: Mood): CompanionLine? {
        if (store.getBoolean(PAYOFF_SPOKEN, false)) return null
        store.putBoolean(PAYOFF_SPOKEN, true)
        return assembler.curated(
            pool = corpus.firstToggle(newMood),
            mood = newMood,
            bagKey = "payoff.${newMood.wire}"
        )
    }

    /**
     * The next hint, or null when the ladder has nothing to say - which is
     * most of the time, and always once the user has toggled.
     *
     * Consumes the rung, so call this only when the line will actually be
     * spoken.
     */
    fun nextHint(mood: Mood): CompanionLine? {
        if (hasEverToggled) return null

        // Post-update nudges take over once the five rungs are spent.
        if (rung >= corpus.hintRungCount(mood)) return updateNudge(mood)

        // One hint per launch: a hint already spoken this launch is done.
        if (store.getInt(HINT_LAUNCH, -1) == launchCount) return null

        val pool = corpus.hintRung(mood, rung)
        if (pool.isEmpty()) return null

        val line = assembler.curated(
            pool = pool,
            mood = mood,
            bagKey = "hint.${mood.wire}.$rung"
        ) ?: return null

        store.putInt(RUNG, rung + 1)
        store.putInt(HINT_LAUNCH, launchCount)
        return line
    }

    /**
     * One nudge on the first launch after an update, one more on the third,
     * then permanent silence.
     */
    private fun updateNudge(mood: Mood): CompanionLine? {
        val n = store.getInt(UPDATE_LAUNCHES, 0)
        if (n != 1 && n != UPDATE_NUDGE_LAST) return null
        if (store.getInt(UPDATE_NUDGE_DONE, 0) >= n) return null

        val line = assembler.curated(
            pool = corpus.hintUpdate(mood),
            mood = mood,
            bagKey = "hint.update.${mood.wire}"
        ) ?: return null

        store.putInt(UPDATE_NUDGE_DONE, n)
        return line
    }

    companion object {
        /** The second and final post-update nudge lands on this launch. */
        private const val UPDATE_NUDGE_LAST = 3

        private const val EVER_TOGGLED = "hint.everToggled"
        private const val PAYOFF_SPOKEN = "hint.payoffSpoken"
        private const val RUNG = "hint.rung"
        private const val LAUNCHES = "hint.launches"
        private const val HINT_LAUNCH = "hint.lastLaunch"
        private const val SEEN_VERSION = "hint.seenVersion"
        private const val UPDATE_LAUNCHES = "hint.updateLaunches"
        private const val UPDATE_NUDGE_DONE = "hint.updateNudgeDone"
    }
}
