package com.lorelight.ui.components.browse

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/*
 * O1 - SHARED BROWSE PRESENTATION
 *
 * The novel plugin side (browse/ui/SourceScreen.kt) and the manga extension
 * side (manga/ui/MangaSourceScreen.kt) had their own copy of every catalog
 * visual: the tinted action button, the grid card, the list row, the 18+
 * scrim and the "In library" badge. The backends genuinely differ; these
 * visuals did not, so fixes kept landing on one side only. That is exactly
 * how the two source screens drifted apart.
 *
 * Everything in this file is backend agnostic. It knows nothing about
 * SourceNovelItem, SManga, plugin ids or source ids.
 *
 * WHERE THE BACKENDS REALLY DIFFER: cover loading. The novel side needs a
 * per-plugin Coil ImageRequest (Referer header derived from the plugin site,
 * plus an optional data-saver RGB_565 downscale); the manga side goes through
 * its own MangaCoverImage, which resolves covers via the extension's own
 * network stack. Neither can be collapsed into the other, so the cover is a
 * SLOT: callers pass a composable and receive the Modifier to apply. The
 * frame, blur, badges, title and spacing are shared; only the pixels inside
 * the cover box are caller-supplied.
 *
 * DELIBERATE UNIFICATIONS (the two copies had drifted; one had to win):
 *   - cover border  : outline at 40% alpha (was full-opacity outline on the
 *                     novel side, 40% on manga). The softer border is the
 *                     newer of the two.
 *   - card clipping : the whole card clips to the cover shape and the click
 *                     ripple is bounded by it (manga behaviour). The novel
 *                     card did not clip, so its ripple painted square.
 *   - title spacing : 6dp gap (novel value) with manga's explicit lineHeight,
 *                     which prevents two-line titles from crowding.
 * These are visible changes on the novel grid, and they are the point of the
 * section: one presentation, one place to change it.
 */

/**
 * The tinted 40dp action button used by both source screens' headers.
 *
 * Both files already carried this identical recipe, and the manga copy even
 * carried a comment saying it was deliberately the same as the novel one.
 * State is carried by BOTH fill strength and outline strength, so an active
 * button is obvious without relying on colour alone.
 */
@Composable
fun BrowseActionButton(
    icon: ImageVector,
    contentDescription: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    // Filled with the theme's own light "container" tone (the soft pre-tuned
    // colour each theme ships for tinted surfaces) rather than a raw
    // alpha-blended primary, which looked wrong on some themes.
    val buttonTint = if (active) MaterialTheme.colorScheme.primaryContainer
    else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
    // Outline stays derived from the active theme's primary colour, so it
    // follows whatever theme is applied.
    val buttonOutline = if (active) MaterialTheme.colorScheme.primary
    else MaterialTheme.colorScheme.primary.copy(alpha = 0.60f)
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(buttonTint)
            .border(1.dp, buttonOutline, RoundedCornerShape(14.dp))
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (active) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.size(18.dp)
        )
    }
}

/** The large rounded glyph used by empty and error states on both screens. */
@Composable
fun BrowseStateIcon(icon: ImageVector) {
    Box(
        modifier = Modifier
            .size(64.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(28.dp)
        )
    }
}

/**
 * Obscures a cover flagged as adult.
 *
 * Modifier.blur is a no-op below API 31, so this scrim is what actually keeps
 * the cover hidden on older devices - the blur alone is not enough.
 */
@Composable
fun AdultCoverScrim(labelSizeSp: Int = 13, showLabel: Boolean = true) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f)),
        contentAlignment = Alignment.Center
    ) {
        if (showLabel) {
            Text(
                "18+",
                fontSize = labelSizeSp.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White.copy(alpha = 0.85f)
            )
        }
    }
}

/**
 * Small badge pinned inside a cover. Used for "In library" (top start) and the
 * novel side's chapter count (bottom end).
 */
@Composable
fun BoxScope.BrowseCoverBadge(
    text: String,
    alignment: Alignment = Alignment.TopStart,
    background: Color = MaterialTheme.colorScheme.primary,
    contentColor: Color = MaterialTheme.colorScheme.onPrimary
) {
    Box(
        modifier = Modifier
            .align(alignment)
            .padding(6.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(background)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = contentColor,
            maxLines = 1
        )
    }
}

/** The "In library" pill shown under a title in the list layout. */
@Composable
fun InLibraryListBadge(text: String = "In library") {
    Surface(
        shape = RoundedCornerShape(4.dp),
        color = MaterialTheme.colorScheme.primaryContainer
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

/**
 * One catalog card for the grid layout, shared by novels and manga.
 *
 * @param cover receives the Modifier to apply to the cover image. It already
 *   carries fillMaxSize and the blur when the cover is obscured, so callers
 *   only supply the loader.
 * @param overlay extra badges drawn inside the cover box, on top of the
 *   built-in library badge. The novel side uses this for its chapter count.
 */
@Composable
fun BrowseGridCard(
    title: String,
    aspectRatio: Float = 0.7f,
    cornerRadius: Dp = 12.dp,
    showTitle: Boolean = true,
    titleLines: Int = 2,
    titleSizeSp: Int = 11,
    inLibrary: Boolean = false,
    showLibraryBadge: Boolean = true,
    dim: Boolean = false,
    blurCover: Boolean = false,
    onClick: () -> Unit,
    overlay: @Composable BoxScope.() -> Unit = {},
    cover: @Composable (Modifier) -> Unit
) {
    val coverShape = RoundedCornerShape(cornerRadius)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(if (dim) 0.42f else 1f)
            .clip(coverShape)
            .clickable(role = Role.Button, onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(aspectRatio)
                .clip(coverShape)
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), coverShape)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            cover(
                Modifier
                    .fillMaxSize()
                    .then(if (blurCover) Modifier.blur(18.dp) else Modifier)
            )

            if (blurCover) AdultCoverScrim(labelSizeSp = 13)

            if (showLibraryBadge && inLibrary) {
                BrowseCoverBadge(text = "In library", alignment = Alignment.TopStart)
            }

            overlay()
        }

        if (showTitle) {
            Spacer(Modifier.height(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                fontSize = titleSizeSp.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = titleLines,
                overflow = TextOverflow.Ellipsis,
                lineHeight = (titleSizeSp + 3).sp
            )
        }
    }
}

/**
 * One catalog row for the list layout, shared by novels and manga: small cover
 * on the left, title plus caller-supplied detail lines on the right.
 *
 * @param cover receives the Modifier to apply to the cover image, already
 *   carrying fillMaxSize and the blur when obscured.
 * @param details rendered under the title. The two sides describe library and
 *   chapter state differently (novels use a joined subtitle line, manga uses a
 *   pill), so that stays with the caller while the frame is shared.
 */
@Composable
fun BrowseListRow(
    title: String,
    coverRatio: Float = 0.7f,
    cornerRadius: Dp = 12.dp,
    titleSizeSp: Int = 13,
    titleWeight: FontWeight = FontWeight.Medium,
    dim: Boolean = false,
    blurCover: Boolean = false,
    onClick: () -> Unit,
    details: @Composable ColumnScope.() -> Unit = {},
    cover: @Composable (Modifier) -> Unit
) {
    val rowShape = RoundedCornerShape(cornerRadius)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(if (dim) 0.42f else 1f)
            .clip(rowShape)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), rowShape)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(48.dp)
                .aspectRatio(coverRatio)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            cover(
                Modifier
                    .fillMaxSize()
                    .then(if (blurCover) Modifier.blur(12.dp) else Modifier)
            )
            // No "18+" wordmark at this size - it would not fit legibly, so the
            // list layout obscures with the scrim alone.
            if (blurCover) AdultCoverScrim(showLabel = false)
        }

        Spacer(Modifier.width(12.dp))

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontSize = titleSizeSp.sp,
                fontWeight = titleWeight,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            details()
        }
    }
}
