package com.lorelight.widget

import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.lorelight.R
import com.lorelight.data.model.Novel
import com.lorelight.data.repository.LibraryRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class BookshelfWidgetConfigActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,AppWidgetManager.INVALID_APPWIDGET_ID)
        val info = AppWidgetManager.getInstance(this).getAppWidgetInfo(id)
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID || info == null || info.provider.className != MiniBookshelfWidget::class.java.name ||
            info.provider.packageName != packageName) { finish(); return }
        val existing = WidgetPreferences.load(this,id)
        setContent {
            MaterialTheme(colorScheme = WidgetAppearance.scheme(this)) {
                Surface(Modifier.fillMaxSize()) {
                    var mode by rememberSaveable { mutableStateOf(existing.mode.name) }
                    var media by rememberSaveable { mutableStateOf(existing.media.name) }
                    var selected by rememberSaveable { mutableStateOf(ArrayList(existing.ids)) }
                    var query by rememberSaveable { mutableStateOf("") }
                    var error by remember { mutableStateOf(false) }
                    val novels by produceState<List<Novel>?>(null) {
                        value = withContext(Dispatchers.IO) {
                            try {
                                LibraryRepository.loadLibrary(applicationContext).also { if (!LibraryRepository.isHealthy()) error = true }
                            } catch (_: Exception) { error = true; emptyList() }
                        }
                    }
                    Column(Modifier.fillMaxSize().safeDrawingPadding().padding(20.dp),verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(stringResource(R.string.widget_shelf_name),style=MaterialTheme.typography.headlineSmall)
                        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                            item { Text(stringResource(R.string.widget_which_books),style=MaterialTheme.typography.titleMedium) }
                            items(ShelfMode.entries) { item ->
                                val title = when (item) {
                                    ShelfMode.RECENT -> R.string.widget_recent
                                    ShelfMode.FAVOURITES -> R.string.widget_favourites
                                    ShelfMode.SELECTED -> R.string.widget_selected
                                }
                                Row(Modifier.fillMaxWidth().clickable { mode=item.name }.heightIn(min=48.dp),verticalAlignment=Alignment.CenterVertically) {
                                    RadioButton(mode==item.name,onClick={mode=item.name}); Text(stringResource(title))
                                }
                            }
                            item { Text(stringResource(R.string.widget_media),style=MaterialTheme.typography.titleMedium) }
                            items(ShelfMedia.entries) { item ->
                                Row(Modifier.fillMaxWidth().clickable { media=item.name }.heightIn(min=48.dp),verticalAlignment=Alignment.CenterVertically) {
                                    RadioButton(media==item.name,onClick={media=item.name})
                                    Text(stringResource(when(item) { ShelfMedia.ALL -> R.string.widget_all_media; ShelfMedia.NOVELS -> R.string.widget_novels; ShelfMedia.MANGA -> R.string.widget_manga }))
                                }
                            }
                            if (mode == ShelfMode.SELECTED.name) {
                                item { OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text(stringResource(R.string.widget_find_book))},singleLine=true) }
                                if (novels == null) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
                                else if (error) item { Text(stringResource(R.string.widget_load_error)) }
                                else if (novels!!.isEmpty()) item { Text(stringResource(R.string.widget_empty_shelf)) }
                                items(novels.orEmpty().filter { it.title.contains(query,true) },key={it.id}) { novel ->
                                    fun toggle() { selected = ArrayList(selected.toMutableList().apply { if (!remove(novel.id)) add(novel.id) }) }
                                    Row(Modifier.fillMaxWidth().clickable { toggle() }.heightIn(min=48.dp),verticalAlignment=Alignment.CenterVertically) {
                                        Checkbox(novel.id in selected,onCheckedChange={toggle()})
                                        Text(novel.title,Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                        Text(stringResource(R.string.widget_config_hint),style=MaterialTheme.typography.bodySmall)
                        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                            OutlinedButton(onClick={finish()},modifier=Modifier.weight(1f)) { Text(stringResource(R.string.widget_cancel)) }
                            Button(onClick={
                                WidgetPreferences.save(this@BookshelfWidgetConfigActivity,id,ShelfSettings(
                                    ShelfMode.valueOf(mode),ShelfMedia.valueOf(media),selected.toList(),0))
                                WidgetRuntime.request(applicationContext)
                                WidgetRuntime.preloadCovers(applicationContext)
                                setResult(RESULT_OK,Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,id))
                                finish()
                            },modifier=Modifier.weight(1f),enabled=mode!=ShelfMode.SELECTED.name || (novels!=null && !error && selected.isNotEmpty())) {
                                Text(stringResource(R.string.widget_save))
                            }
                        }
                    }
                }
            }
        }
    }
}
