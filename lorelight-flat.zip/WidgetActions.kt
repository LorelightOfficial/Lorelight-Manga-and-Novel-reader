package com.lorelight.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.lorelight.MainActivity
import com.lorelight.R
import com.lorelight.data.repository.LibraryRepository
import com.lorelight.tts.TtsPlaybackManager

internal object WidgetActions {
    const val ACTION = "com.lorelight.widget.CONTROL"
    fun open(context: Context, widgetId: Int, route: String, novelId: String? = null): PendingIntent {
        val uri = Uri.Builder().scheme("lorelight").authority(route).apply {
            if (novelId != null) appendPath(novelId)
            appendQueryParameter("widget", widgetId.toString())
        }.build()
        val intent = Intent(context, MainActivity::class.java).setAction(Intent.ACTION_VIEW).setData(uri)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    fun control(context: Context, widgetId: Int, action: String, novelId: String? = null): PendingIntent {
        val intent = Intent(context, WidgetActionReceiver::class.java).setAction(ACTION)
            .setData(Uri.Builder().scheme("lorelight-widget").authority(action).appendPath(widgetId.toString()).appendPath(novelId ?: "shelf").build())
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId).putExtra("command", action).putExtra("novel_id", novelId)
        return PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    fun configure(context: Context, widgetId: Int): PendingIntent {
        val intent = Intent(context, BookshelfWidgetConfigActivity::class.java)
            .setData(Uri.parse("lorelight-widget://configure/$widgetId"))
            .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
        return PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}

/** Private explicit broadcasts; a stale widget can never control a different book. */
class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != WidgetActions.ACTION) return
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        val provider = AppWidgetManager.getInstance(context).getAppWidgetInfo(id)?.provider ?: return
        if (provider.packageName != context.packageName) return
        val command = intent.getStringExtra("command") ?: return
        if (provider.className == MiniBookshelfWidget::class.java.name && command in setOf("shelf_prev", "shelf_next")) {
            val old = WidgetPreferences.load(context,id)
            WidgetPreferences.save(context,id,old.copy(page = ((intent.getStringExtra("novel_id")?.toIntOrNull() ?: old.page) + if (command == "shelf_next") 1 else -1).coerceAtLeast(0)))
            WidgetRuntime.request(context)
            WidgetRuntime.preloadCovers(context)
            return
        }
        if (provider.className != ContinueReadingWidget::class.java.name) return
        val novel = TtsPlaybackManager.activeNovel.value
        if (novel == null || novel.id != intent.getStringExtra("novel_id") || !TtsPlaybackManager.sessionActive.value) {
            // Do not start an activity from a broadcast trampoline, or restart a killed
            // session unexpectedly. Refresh to Reading mode, whose Play is a direct activity intent.
            Toast.makeText(context, R.string.widget_session_ended, Toast.LENGTH_SHORT).show()
            WidgetRuntime.request(context)
            return
        }
        val action = when (command) {
            "play" -> TtsPlaybackManager.TtsCommand.Play
            "pause" -> TtsPlaybackManager.TtsCommand.Pause
            "prev_sentence" -> TtsPlaybackManager.TtsCommand.PrevSentence
            "next_sentence" -> TtsPlaybackManager.TtsCommand.NextSentence
            "prev_chapter" -> if (TtsPlaybackManager.activeChapterIndex.value > 0) TtsPlaybackManager.TtsCommand.PrevChapter else return
            "next_chapter" -> if (TtsPlaybackManager.activeChapterIndex.value < TtsPlaybackManager.chapters.value.lastIndex) TtsPlaybackManager.TtsCommand.NextChapter else return
            "stop" -> {
                LibraryRepository.setLastMode(context,novel.id,false)
                TtsPlaybackManager.sessionActive.value = false
                TtsPlaybackManager.TtsCommand.Stop
            }
            else -> return
        }
        TtsPlaybackManager.dispatch(action)
        WidgetRuntime.request(context)
    }
}
