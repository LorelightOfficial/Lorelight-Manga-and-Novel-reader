package com.lorelight.browse.ui

import com.lorelight.R
import android.content.Context
import androidx.compose.ui.res.stringResource
import com.lorelight.manga.ui.NsfwFilterMode
import com.lorelight.manga.ui.nextNsfwMode
import com.lorelight.manga.ui.readNsfwMode
import com.lorelight.manga.ui.writeNsfwMode
import com.lorelight.ui.animation.BookGridSkeleton
import com.lorelight.ui.animation.StaggeredItem
import com.lorelight.ui.components.InAppBrowserIconButton

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TravelExplore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.lorelight.browse.model.InstalledPlugin
import com.lorelight.browse.model.PluginInfo
import com.lorelight.browse.model.SourceNovelItem
import com.lorelight.ui.theme.GlassPanel
import com.lorelight.ui.theme.getThemedButtonProps
import kotlinx.coroutines.launch
import androidx.compose.ui.semantics.Role

private sealed class BrowseNav {
    data object Root : BrowseNav()
    data class Source(val pluginId: String, val name: String, val site: String, val latest: Boolean) : BrowseNav()
    data object Global : BrowseNav()
    data object MangaGlobal : BrowseNav()
    data class MangaSource(val sourceId: Long, val latest: Boolean) : BrowseNav()
}

// Shared flag so MainActivity can hide the bottom tab bar while a source
// (opened website) or global search is on screen. Reset when Browse leaves.
val browseInSourceState = mutableStateOf(false)

/**
 * Browse tab entry point. Signature unchanged so MainActivity keeps working:
 * BrowseScreen(onOpenNovel = { pluginId, item -> ... }).
 */
@Composable
fun BrowseScreen(
    onOpenNovel: (String, SourceNovelItem) -> Unit,
    onOpenManga: (Long, eu.kanade.tachiyomi.source.model.SManga) -> Unit = { _, _ -> }
) {
    var nav by remember { mutableStateOf<BrowseNav>(BrowseNav.Root) }
    var mediaType by rememberSaveable { mutableIntStateOf(0) } // 0 = Novels, 1 = Manga
    var mangaTab by rememberSaveable { mutableIntStateOf(0) } // 0 = Sources, 1 = Extensions
    var tab by rememberSaveable { mutableIntStateOf(0) } // 0 = Installed, 1 = Available

    LaunchedEffect(nav) { browseInSourceState.value = nav !is BrowseNav.Root }
    DisposableEffect(Unit) { onDispose { browseInSourceState.value = false } }

    // BACK ALIGNMENT: the in-app arrow on Source / Global search / Manga source
    // returns to the Browse root (onBack = { nav = BrowseNav.Root }). Without
    // this handler the system/gesture Back fell straight through to
    // MainActivity's global handler, which popped the whole Browse tab and
    // dumped the user on Library. Same gesture, two different results.
    androidx.activity.compose.BackHandler(enabled = nav !is BrowseNav.Root) {
        nav = BrowseNav.Root
    }

    Box(modifier = Modifier.fillMaxSize()) {
    when (val n = nav) {
        is BrowseNav.Root -> BrowseRoot(
            mediaType = mediaType,
            onMediaTypeChange = { mediaType = it },
            mangaTab = mangaTab,
            onMangaTabChange = { mangaTab = it },
            tab = tab,
            onTabChange = { tab = it },
            onOpenSource = { id, name, site, latest -> nav = BrowseNav.Source(id, name, site, latest) },
            onOpenGlobal = { nav = if (mediaType == 1) BrowseNav.MangaGlobal else BrowseNav.Global },
            onOpenMangaSource = { sourceId, latest -> nav = BrowseNav.MangaSource(sourceId, latest) }
        )
        is BrowseNav.Source -> SourceScreen(
            pluginId = n.pluginId,
            pluginName = n.name,
            site = n.site,
            startLatest = n.latest,
            onBack = { nav = BrowseNav.Root },
            onOpenNovel = onOpenNovel
        )
        is BrowseNav.Global -> GlobalSearchScreen(
            onBack = { nav = BrowseNav.Root },
            onOpenNovel = onOpenNovel
        )
        is BrowseNav.MangaGlobal -> com.lorelight.manga.ui.MangaGlobalSearchScreen(
            onBack = { nav = BrowseNav.Root },
            onOpenManga = onOpenManga
        )
        is BrowseNav.MangaSource -> com.lorelight.manga.ui.MangaSourceScreen(
            sourceId = n.sourceId,
            startLatest = n.latest,
            onBack = { nav = BrowseNav.Root },
            onOpenManga = onOpenManga
        )
    }
    }
}

@Composable
private fun BrowseRoot(
    mediaType: Int,
    onMediaTypeChange: (Int) -> Unit,
    mangaTab: Int,
    onMangaTabChange: (Int) -> Unit,
    tab: Int,
    onTabChange: (Int) -> Unit,
    onOpenSource: (String, String, String, Boolean) -> Unit,
    onOpenGlobal: () -> Unit,
    onOpenMangaSource: (Long, Boolean) -> Unit
) {
    val context = LocalContext.current
    val vm: BrowseViewModel = viewModel()

    val available by vm.available.collectAsState()
    val installed by vm.installed.collectAsState()
    val loading by vm.loading.collectAsState()
    val error by vm.error.collectAsState()
    val busyIds by vm.busyIds.collectAsState()
    val selectedLangs by vm.selectedLangs.collectAsState()

    LaunchedEffect(Unit) { vm.ensureLoaded(context) }

    var searchActive by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var showRepos by remember { mutableStateOf(false) }
    var showBrowseSettings by remember { mutableStateOf(false) }
    var nsfwMode by remember { mutableStateOf(readNsfwMode(context)) }

    // BACK ALIGNMENT: the in-app close (X) on the expanded search field clears
    // the query and collapses the field. System Back now does exactly that
    // instead of leaving the tab with a search still open underneath.
    androidx.activity.compose.BackHandler(enabled = searchActive) {
        searchActive = false
        query = ""
    }

    // In-app browser host for NOVEL plugin sources only.
    //
    // The manga sources screen is composed inside this one and hosts the same
    // dialog for its own origin, so gating on the origin is what stops a
    // single request opening two dialogs at once.
    val browserTarget = SourceBrowserRequest.target
    if (browserTarget != null && browserTarget.origin is BrowserOrigin.NovelPlugin) {
        InAppBrowserDialog(
            startUrl = browserTarget.url,
            siteName = browserTarget.siteName,
            origin = browserTarget.origin,
            onAddNovel = { novel -> addBrowserResultToLibrary(context, novel) },
            onDismiss = { SourceBrowserRequest.target = null }
        )
    }

    val installedIds = remember(installed) { installed.map { it.info.id }.toSet() }
    val availableById = remember(available) { available.associateBy { it.id } }
    val updatesCount = remember(installed, availableById) {
        installed.count { ip ->
            val latest = availableById[ip.info.id]
            latest != null && latest.version != ip.installedVersion
        }
    }

    Column(Modifier.fillMaxSize()) {
        // ── Header: Always displays "Browse" at the top of the screen ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 4.dp)
                .height(48.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.browse_title),
                fontSize = 32.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = MaterialTheme.typography.headlineLarge.fontFamily,
                color = MaterialTheme.colorScheme.onSurface
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (mediaType == 1) {
                    IconButton(
                        onClick = {
                            val m = nextNsfwMode(nsfwMode)
                            nsfwMode = m
                            writeNsfwMode(context, m)
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                when (nsfwMode) {
                                    NsfwFilterMode.NSFW_TOP -> MaterialTheme.colorScheme.error
                                    NsfwFilterMode.NSFW_LAST -> MaterialTheme.colorScheme.primary
                                    NsfwFilterMode.NORMAL -> MaterialTheme.colorScheme.surfaceVariant
                                }
                            )
                    ) {
                        Text(
                            when (nsfwMode) {
                                NsfwFilterMode.NSFW_TOP -> "18\u2191"
                                NsfwFilterMode.NSFW_LAST -> "18\u2193"
                                NsfwFilterMode.NORMAL -> "18+"
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (nsfwMode) {
                                NsfwFilterMode.NSFW_TOP -> MaterialTheme.colorScheme.onError
                                NsfwFilterMode.NSFW_LAST -> MaterialTheme.colorScheme.onPrimary
                                NsfwFilterMode.NORMAL -> MaterialTheme.colorScheme.onSurfaceVariant
                            }
                        )
                    }
                }
                HeaderActionButton(
                    icon = Icons.Filled.Search,
                    contentDescription = stringResource(R.string.browse_search_websites_desc),
                    active = searchActive,
                    onClick = {
                        searchActive = !searchActive
                        if (!searchActive) query = ""
                    }
                )
                HeaderActionButton(
                    icon = Icons.Filled.TravelExplore,
                    contentDescription = stringResource(R.string.browse_global_search_desc),
                    onClick = onOpenGlobal
                )
                HeaderActionButton(
                    icon = Icons.Filled.Settings,
                    contentDescription = stringResource(R.string.browse_repositories_desc),
                    onClick = {
                        if (mediaType == 1) showBrowseSettings = true else showRepos = true
                    }
                )
            }
        }

        // ── Scrollable Tab Row: Positioned directly BELOW the "Browse" header row ──
        BrowseSectionTabs(
            mediaType = mediaType,
            novelTab = tab,
            mangaTab = mangaTab,
            onSelect = { m, t ->
                onMediaTypeChange(m)
                if (m == 0) onTabChange(t) else onMangaTabChange(t)
            }
        )

        // ── Inline search field (rounded, themed — replaces TopAppBar swap) ──
        if (searchActive) {
            val focusRequester = remember { FocusRequester() }
            LaunchedEffect(Unit) { focusRequester.requestFocus() }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 8.dp)
                    // RESTYLE: the search field used a hard Material outline,
                    // which read as stock Android next to the glass panels the
                    // rest of Browse already uses. Softer translucent fill with
                    // a gradient hairline edge instead.
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
                    .border(
                        width = 1.dp,
                        brush = Brush.verticalGradient(
                            listOf(
                                MaterialTheme.colorScheme.onSurface.copy(alpha = 0.16f),
                                MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)
                            )
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Filled.Search,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(10.dp))
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .weight(1f)
                        .focusRequester(focusRequester),
                    decorationBox = { inner ->
                        Box {
                            if (query.isEmpty()) {
                                Text(
                                    stringResource(R.string.browse_search_placeholder),
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                )
                            }
                            inner()
                        }
                    }
                )
                Icon(
                    Icons.Filled.Close,
                    contentDescription = stringResource(R.string.browse_close_search_desc),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .size(18.dp)
                        .clickable(role = Role.Button) { searchActive = false; query = "" }
                )
            }
        }

        if (mediaType == 1) {
            if (mangaTab == 0) {
                com.lorelight.manga.ui.MangaSourcesScreen(
                    onOpenSource = { id, latest -> onOpenMangaSource(id, latest) },
                    onOpenExtensions = { onMangaTabChange(1) },
                    hideHeader = true,
                    searchQuery = query
                )
            } else {
                com.lorelight.manga.ui.MangaExtensionsScreen(
                    onOpenSourceScreen = { onMangaTabChange(0) },
                    hideHeader = true,
                    searchQuery = query,
                    nsfwMode = nsfwMode
                )
            }
        } else {
            val q = query.trim()

        if (tab == 0) {
            // ── Updates banner ──
            if (updatesCount > 0) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .padding(bottom = 8.dp)
                        // RESTYLE: translucent tinted glass instead of a flat
                        // opaque primaryContainer slab, so the banner sits in
                        // the same visual language as the rest of the app.
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.92f),
                                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.68f)
                                )
                            )
                        )
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.32f),
                            RoundedCornerShape(16.dp)
                        )
                        .padding(start = 14.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.FileDownload,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "$updatesCount update${if (updatesCount == 1) "" else "s"} available",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    TextButton(onClick = { vm.updateAll(context) }) {
                        Text(
                            stringResource(R.string.browse_update_all),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            val list = remember(installed, q) {
                installed
                    .filter { q.isBlank() || it.info.name.contains(q, ignoreCase = true) }
                    .sortedWith(compareByDescending<InstalledPlugin> { it.pinned }.thenBy { it.info.name.lowercase() })
            }
            if (list.isEmpty()) {
                EmptyHint(
                    icon = Icons.Filled.Extension,
                    text = if (installed.isEmpty()) stringResource(R.string.browse_no_sources_installed)
                    else stringResource(R.string.browse_no_matches)
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(items = list, key = { _, ip -> ip.info.id }) { i, ip ->
                        val latest = availableById[ip.info.id]
                        val updateAvailable = latest != null && latest.version != ip.installedVersion
                        StaggeredItem(index = i, key = ip.info.id) {
                            InstalledRow(
                                plugin = ip,
                                latest = latest,
                                updateAvailable = updateAvailable,
                                busy = busyIds.contains(ip.info.id),
                                onOpenPopular = { onOpenSource(ip.info.id, ip.info.name, ip.info.site, false) },
                                onOpenInAppBrowser = {
                                    // Carry the plugin identity, so adding from
                                    // the browser links the novel to THIS
                                    // plugin instead of scraping the page.
                                    SourceBrowserRequest.target = BrowserTarget(
                                        url = ip.info.site,
                                        siteName = ip.info.name,
                                        origin = BrowserOrigin.NovelPlugin(
                                            pluginId = ip.info.id,
                                            site = ip.info.site
                                        )
                                    )
                                },
                                onTogglePin = { vm.setPinned(context, ip.info.id, !ip.pinned) },
                                onUninstall = { vm.uninstall(context, ip.info.id) },
                                onUpdate = { vm.update(context, latest ?: ip.info) }
                            )
                        }
                    }
                }
            }
        } else {
            val langs = remember(available) {
                available.map { it.lang }.filter { it.isNotBlank() }.distinct().sorted()
            }
            val filtered = remember(available, q, selectedLangs) {
                available.filter { p ->
                    (q.isBlank() || p.name.contains(q, ignoreCase = true)) &&
                        (selectedLangs.isEmpty() || selectedLangs.contains(p.lang))
                }
            }
            Column(Modifier.fillMaxSize()) {
                // ── Language filter pills ──
                if (langs.isNotEmpty()) {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        items(langs.size) { i ->
                            val lang = langs[i]
                            val selected = selectedLangs.contains(lang)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (selected) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    )
                                    .border(
                                        1.dp,
                                        if (selected) Color.Transparent
                                        else MaterialTheme.colorScheme.outline,
                                        RoundedCornerShape(10.dp)
                                    )
                                    .clickable(role = Role.Button) { vm.setLangSelected(context, lang, !selected) }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    lang,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selected) MaterialTheme.colorScheme.onPrimary
                                    else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                when {
                    loading && available.isEmpty() -> BookGridSkeleton(columns = 3)
                    error != null && available.isEmpty() -> Column(
                        Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            error ?: "",
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { vm.refresh(context) }) { Text(stringResource(R.string.browse_retry)) }
                    }
                    filtered.isEmpty() -> EmptyHint(icon = Icons.Filled.Public, text = stringResource(R.string.browse_no_websites_match))
                    else -> {
                        val otherLangLabel = stringResource(R.string.browse_lang_other)
                        val grouped = remember(filtered, otherLangLabel) {
                            filtered.groupBy { it.lang.ifBlank { otherLangLabel } }.toSortedMap()
                        }
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            grouped.forEach { (lang, plugins) ->
                                item(key = "header_$lang") {
                                    Text(
                                        lang.uppercase(),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(start = 4.dp, top = 8.dp)
                                    )
                                }
                                items(plugins.size, key = { i -> plugins[i].id }) { i ->
                                    val p = plugins[i]
                                    StaggeredItem(index = i, key = p.id) {
                                        AvailableRow(
                                            plugin = p,
                                            installed = installedIds.contains(p.id),
                                            busy = busyIds.contains(p.id),
                                            onInstall = { vm.install(context, p) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    }

    if (showRepos) {
        RepoSettingsDialog(
            onDismiss = { showRepos = false },
            onChanged = { vm.refresh(context) }
        )
    }

    if (showBrowseSettings) {
        Dialog(
            onDismissRequest = { showBrowseSettings = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                com.lorelight.manga.ui.MangaBrowseSettingsScreen(
                    onBack = { showBrowseSettings = false },
                    onChanged = { }
                )
            }
        }
    }
}

/** Pill icon button matching the Library header's "Import" pill style. */
@Composable
private fun HeaderActionButton(
    icon: ImageVector,
    contentDescription: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    GlassPanel(
        cornerRadius = 14.dp,
        tintAlpha = if (active) 0.85f else 0.55f,
        modifier = Modifier
            .size(40.dp)
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = if (active) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

/**
 * Single flattened selector that replaces the old three stacked rows
 * (Novels|Manga, then Sources|Extensions, then Installed|Available).
 *
 * Features highlight flow & wobbly spring animation matching app style.
 *
 * onSelect reports (mediaType, subTab) where mediaType 0 = Novels, 1 = Manga
 * and subTab 0 = Sources/Installed, 1 = Available/Extensions.
 */
@Composable
private fun BrowseSectionTabs(
    mediaType: Int,
    novelTab: Int,
    mangaTab: Int,
    onSelect: (Int, Int) -> Unit
) {
    val selectedIndex = when {
        mediaType == 0 && novelTab == 0 -> 0
        mediaType == 0 -> 1
        mangaTab == 0 -> 2
        else -> 3
    }

    data class TabItem(val label: String, val icon: ImageVector)
    val novelsLabel = stringResource(R.string.browse_tab_novels)
    val novelsAvailableLabel = stringResource(R.string.browse_tab_novels_available)
    val mangaLabel = stringResource(R.string.browse_tab_manga)
    val mangaAvailableLabel = stringResource(R.string.browse_tab_manga_available)
    val items = remember(novelsLabel, novelsAvailableLabel, mangaLabel, mangaAvailableLabel) {
        listOf(
            TabItem(novelsLabel, Icons.Filled.Extension),
            TabItem(novelsAvailableLabel, Icons.Filled.TravelExplore),
            TabItem(mangaLabel, Icons.Filled.Extension),
            TabItem(mangaAvailableLabel, Icons.Filled.TravelExplore)
        )
    }

    val density = LocalDensity.current
    val scrollState = rememberScrollState()

    var tabOffsets by remember { mutableStateOf(List(4) { 0.dp }) }
    var tabWidths by remember { mutableStateOf(List(4) { 0.dp }) }

    val targetX = tabOffsets.getOrElse(selectedIndex) { 0.dp }
    val targetWidth = tabWidths.getOrElse(selectedIndex) { 0.dp }

    val animatedX by animateDpAsState(
        targetValue = targetX,
        animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing),
        label = "tabPillX"
    )
    val animatedWidth by animateDpAsState(
        targetValue = targetWidth,
        animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing),
        label = "tabPillWidth"
    )

    LaunchedEffect(selectedIndex, tabOffsets) {
        val xVal = tabOffsets.getOrNull(selectedIndex)
        if (xVal != null && xVal > 0.dp) {
            val px = with(density) { xVal.toPx().toInt() }
            scrollState.animateScrollTo(
                value = (px - 80).coerceAtLeast(0),
                animationSpec = tween(durationMillis = 220, easing = FastOutSlowInEasing)
            )
        }
    }

    val primaryColor = MaterialTheme.colorScheme.primary
    val (_, appThemeGradient, appThemeContentColor) = getThemedButtonProps(
        primaryColor,
        fallbackContent = MaterialTheme.colorScheme.onPrimary
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        GlassPanel(
            cornerRadius = 20.dp,
            tintAlpha = 0.55f,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState)
                    .padding(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(contentAlignment = Alignment.CenterStart) {
                    if (targetWidth > 0.dp) {
                        Box(
                            modifier = Modifier
                                .offset(x = animatedX)
                                .width(animatedWidth)
                                .height(38.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(appThemeGradient)
                        )
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        items.forEachIndexed { index, item ->
                            val selected = selectedIndex == index

                            Box(
                                modifier = Modifier
                                    .onGloballyPositioned { coordinates ->
                                        val xInParent = coordinates.positionInParent().x
                                        val w = coordinates.size.width
                                        with(density) {
                                            val xDp = xInParent.toDp()
                                            val wDp = w.toDp()
                                            if (tabOffsets.getOrNull(index) != xDp || tabWidths.getOrNull(index) != wDp) {
                                                val newOffsets = tabOffsets.toMutableList()
                                                val newWidths = tabWidths.toMutableList()
                                                if (index < newOffsets.size) {
                                                    newOffsets[index] = xDp
                                                    newWidths[index] = wDp
                                                    tabOffsets = newOffsets
                                                    tabWidths = newWidths
                                                }
                                            }
                                        }
                                    }
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable(role = Role.Button) {
                                        when (index) {
                                            0 -> onSelect(0, 0)
                                            1 -> onSelect(0, 1)
                                            2 -> onSelect(1, 0)
                                            else -> onSelect(1, 1)
                                        }
                                    }
                                    .padding(horizontal = 16.dp, vertical = 9.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = item.icon,
                                        contentDescription = null,
                                        tint = if (selected) appThemeContentColor
                                               else MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = item.label,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (selected) appThemeContentColor
                                               else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TabPill(
    text: String,
    count: Int,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(
                if (selected) MaterialTheme.colorScheme.primary else Color.Transparent
            )
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (selected) MaterialTheme.colorScheme.onPrimary
            else MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (count > 0) {
            Spacer(Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (selected) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.2f)
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                    .padding(horizontal = 6.dp, vertical = 1.dp)
            ) {
                Text(
                    "$count",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (selected) MaterialTheme.colorScheme.onPrimary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun InstalledRow(
    plugin: InstalledPlugin,
    latest: PluginInfo?,
    updateAvailable: Boolean,
    busy: Boolean,
    onOpenPopular: () -> Unit,
    onOpenInAppBrowser: () -> Unit,
    onTogglePin: () -> Unit,
    onUninstall: () -> Unit,
    onUpdate: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    GlassPanel(
        cornerRadius = 18.dp,
        tintAlpha = 0.55f,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpenPopular)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SourceIcon(plugin.info.iconUrl)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        plugin.info.name,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (plugin.pinned) {
                        Spacer(Modifier.width(6.dp))
                        Icon(
                            Icons.Filled.PushPin,
                            contentDescription = stringResource(R.string.browse_pinned_desc),
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
                val sub = buildString {
                    append(plugin.info.lang.ifBlank { plugin.info.site })
                    append(" · v").append(plugin.installedVersion)
                    if (updateAvailable && latest != null) append(" → v").append(latest.version)
                }
                Text(
                    sub,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (updateAvailable) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (busy) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.width(4.dp))
            } else if (updateAvailable) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primary)
                        .clickable(onClick = onUpdate)
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.FileDownload,
                            contentDescription = stringResource(R.string.browse_update_desc),
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            stringResource(R.string.browse_update_label),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
                Spacer(Modifier.width(4.dp))
            }
            // Its own button now, sitting just left of the overflow menu, so
            // the browser is one tap away instead of buried in the menu.
            InAppBrowserIconButton(
                onClick = onOpenInAppBrowser,
                buttonSize = 32.dp,
                iconSize = 18.dp,
                ringSize = 26.dp
            )
            Box {
                IconButton(onClick = { menu = true }, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.Filled.MoreVert,
                        contentDescription = stringResource(R.string.browse_more_desc),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text(if (updateAvailable) stringResource(R.string.browse_update_label) else stringResource(R.string.browse_reinstall_update)) },
                        onClick = { menu = false; onUpdate() }
                    )
                    DropdownMenuItem(
                        text = { Text(if (plugin.pinned) stringResource(R.string.browse_unpin) else stringResource(R.string.browse_pin)) },
                        onClick = { menu = false; onTogglePin() }
                    )
                    DropdownMenuItem(
                        text = { Text(stringResource(R.string.browse_uninstall)) },
                        onClick = { menu = false; onUninstall() }
                    )
                }
            }
        }
    }
}

@Composable
private fun AvailableRow(
    plugin: PluginInfo,
    installed: Boolean,
    busy: Boolean,
    onInstall: () -> Unit
) {
    GlassPanel(
        cornerRadius = 18.dp,
        tintAlpha = 0.55f,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SourceIcon(plugin.iconUrl)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    plugin.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val sub = "${plugin.lang.ifBlank { plugin.site }} · v${plugin.version}"
                Text(
                    sub,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            when {
                busy -> CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.primary
                )
                installed -> Icon(
                    Icons.Filled.CheckCircle,
                    contentDescription = stringResource(R.string.browse_installed_desc),
                    tint = MaterialTheme.colorScheme.primary
                )
                else -> Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.primary)
                        .clickable(onClick = onInstall)
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        stringResource(R.string.browse_install),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun SourceIcon(url: String?) {
    Box(
        modifier = Modifier
            .size(42.dp)
            // RESTYLE: softer hairline edge to match the app's glass chips.
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.92f))
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.18f),
                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f)
                    )
                ),
                shape = RoundedCornerShape(12.dp)
            ),
        contentAlignment = Alignment.Center
    ) {
        if (url.isNullOrBlank()) {
            Icon(
                Icons.Filled.Public,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
            )
        } else {
            AsyncImage(
                model = url,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun EmptyHint(icon: ImageVector, text: String) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                // RESTYLE: glass badge instead of a hard-outlined square.
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.62f),
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.38f)
                        )
                    )
                )
                .border(
                    width = 1.dp,
                    brush = Brush.verticalGradient(
                        listOf(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.28f),
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
                        )
                    ),
                    shape = RoundedCornerShape(20.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(28.dp)
            )
        }
        Spacer(Modifier.height(16.dp))
        Text(
            text,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
