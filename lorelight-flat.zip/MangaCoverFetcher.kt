package com.lorelight.manga.ui

import android.content.Context
import android.net.Uri
import coil.ImageLoader
import coil.decode.DataSource
import coil.decode.ImageSource
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.fetch.SourceResult
import coil.request.Options
import eu.kanade.tachiyomi.network.await
import eu.kanade.tachiyomi.source.online.HttpSource
import okhttp3.Request
import okio.Path.Companion.toOkioPath
import okio.buffer
import okio.source
import tachiyomi.domain.manga.model.MangaCover
import tachiyomi.domain.source.service.SourceManager
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import java.io.File

class MangaCoverFetcher(
    private val cover: MangaCover,
    private val options: Options,
    private val context: Context,
) : Fetcher {

    override suspend fun fetch(): FetchResult? {
        val url = cover.url
        if (url.isNullOrBlank()) return null

        // 1. Local file path or file:// URI
        if (url.startsWith("file://") || url.startsWith("/")) {
            val file = File(url.removePrefix("file://"))
            if (!file.exists()) return null
            return SourceResult(
                source = ImageSource(file = file.toOkioPath()),
                mimeType = null,
                dataSource = DataSource.DISK,
            )
        }

        // 2. Content URI
        if (url.startsWith("content://")) {
            val uri = Uri.parse(url)
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null
            return SourceResult(
                source = ImageSource(source = inputStream.source().buffer(), context = options.context),
                mimeType = context.contentResolver.getType(uri),
                dataSource = DataSource.DISK,
            )
        }

        // 3. Network HTTP / HTTPS URL using source.client for rate-limiting & auth
        if (url.startsWith("http://") || url.startsWith("https://")) {
            val sourceManager = Injekt.get<SourceManager>()
            val source = sourceManager.get(cover.sourceId) as? HttpSource
            val client = source?.client ?: com.lorelight.network.HttpClients.shared()

            val reqBuilder = Request.Builder().url(url)
            var hasUserAgent = false
            var hasReferer = false

            if (source != null) {
                val headers = source.headers
                for (i in 0 until headers.size) {
                    val name = headers.name(i)
                    val value = headers.value(i)
                    if (name.equals("User-Agent", ignoreCase = true)) hasUserAgent = true
                    if (name.equals("Referer", ignoreCase = true)) hasReferer = true
                    reqBuilder.addHeader(name, value)
                }
                if (!hasReferer && source.baseUrl.isNotBlank()) {
                    reqBuilder.addHeader("Referer", source.baseUrl)
                }
            }
            if (!hasUserAgent) {
                reqBuilder.addHeader("User-Agent", "Mozilla/5.0 (Android)")
            }

            val request = reqBuilder.build()
            val response = client.newCall(request).await()

            if (!response.isSuccessful) {
                response.close()
                throw IllegalStateException("HTTP ${response.code}: ${response.message}")
            }

            val body = response.body ?: throw IllegalStateException("Null response body")

            return SourceResult(
                source = ImageSource(
                    source = body.source(),
                    context = options.context,
                ),
                mimeType = body.contentType()?.toString(),
                dataSource = DataSource.NETWORK,
            )
        }

        return null
    }

    class Factory(private val context: Context) : Fetcher.Factory<MangaCover> {
        override fun create(data: MangaCover, options: Options, imageLoader: ImageLoader): Fetcher {
            return MangaCoverFetcher(data, options, context)
        }
    }
}
