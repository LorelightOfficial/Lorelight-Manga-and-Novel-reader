# Lorelight - change set for the 11 Aug round

Apply `all-changes.patch` (project root) to your copy. It is a plain
`diff -ruN` against the exact zip you uploaded, so it applies cleanly.

**14 code files changed. Nothing was deleted. No file was moved or renamed.**

Two groups are included:

* **Group A - Phase 1B** (already sent you separately, re-included here so the
  patch applies against the zip you uploaded): `ProgressStore.kt`,
  `ReadingProgressDao.kt`, `NovelPreferences.kt`, `MangaReaderViewModel.kt`,
  `NovelImportManager.kt`, `TtsPlaybackManager.kt`.
* **Group B - this round**, everything below.

---

## 1. EPUB export was broken 100% of the time

`utils/EpubGenerator.kt`

**Cause.** It wrote straight to
`Environment.getExternalStoragePublicDirectory(DIRECTORY_DOWNLOADS)` with a raw
`FileOutputStream`. The app targets SDK 36 and `AndroidManifest.xml` declares
**no storage permission at all**, so scoped storage rejected that call on every
modern device. `FileNotFoundException: Permission denied` was swallowed by the
outer catch, the function returned `null`, and the UI said
"Failed to generate EPUB."

**Fix.** Three-tier output, no permission required anywhere:

1. API 29+: insert a `MediaStore.Downloads` row with `IS_PENDING = 1`, stream
   into it, then flip `IS_PENDING = 0` so it appears in Downloads.
2. API 24-28: the original legacy `File` path, which genuinely works there.
3. If both fail: `getExternalFilesDir(DIRECTORY_DOWNLOADS)`, always writable.

On failure the pending MediaStore row is deleted, so no half-written ghost file
is left in Downloads. Also set `mimeEntry.compressedSize` alongside the existing
`size`/`crc` - `STORED` zip entries need it or some runtimes reject the entry.

The caller (`CrawlerDownloadDialog.kt`) only reads `.name` off the returned
`File`, so the MediaStore branch returns a name-only handle. No caller change.

## 2. Backup export always failed, and auto-recovery could never find a backup

`core/BackupManager.kt`

**Cause 1.** `createBackup()` only wrote when `KEY_CUSTOM_URI` (a SAF folder the
user picks manually) was set. No folder picked meant control fell through to
`return false`. There was no fallback path whatsoever, so "Backup Now" reported
"Failed to update backup file" for anyone who never opened the folder picker.
The settings screen defaults `backupLocationType` to `"external"`, a value
`BackupManager` never honoured.

**Cause 2, the serious one.** `SelfHealingEngine` looks for a backup in three
places: the SAF folder, `getExternalFilesDir("AutoBackups")`, and `filesDir`.
`createBackup` **never wrote to the last two**. Your automatic recovery path was
searching two locations that nothing ever populated.

**Fix.** Local copies are now always written to exactly the two paths
`SelfHealingEngine` already probes, before the SAF attempt. Neither needs a
permission. The SAF folder is still written when configured. `createBackup`
returns true if any target succeeded.

Writes go through a temp-file-then-rename helper, so a process death mid-write
can never truncate a good backup.

`getSingleBackupInfo()` also had to change - it returned `null` without a custom
URI, so the settings card looked broken. It now reports the local copy with a
real date and size.

## 3. Back navigation

`MainActivity.kt`

**The Continue Reading bug you described.** `onReadCurrent` called
`startReading()` and `showReader = true` **without setting
`selectedNovelForDetails` first**. The nav stack became `[Tab(0), Reader]`, so
back popped Reader and landed on Library. `HistoryScreen`'s `onPlayClick`
already did it correctly - it sets details first, producing
`[Tab(1), Details, Reader]`. Continue Reading now follows that same pattern, so
back goes to Details.

**The "back goes too far" class of bugs.** Two `BackHandler`s were competing.
The one at the details layer ran `selectedNovelForDetails = null`, and that
setter unwinds *every* trailing Details and Reader entry in one shot. So
Tab -> Details(A) -> Details(B) collapsed all the way to the tab on a single
back press. It now pops exactly one entry.

**Third entry point.** Opening the reader from the TTS media notification had
the same missing-Details problem. It now seats the playing novel's Details page
under the Reader too.

## 4. History backend - a real bug, in two places

`data/local/NovelPreferences.kt`

`loadHistoryFromPrefs()` runs a cover migration (Base64 blobs out of the row and
into files on disk) and then calls `saveHistoryToPrefs()` to persist the slimmed
result. But `saveHistoryToPrefs` -> `guardSaveHistory` **refuses to write while
`historyReadHealthy` is false**, and that flag was not set until the line
*after* the migration save.

So the migration write was silently rejected on every single launch, logging
"SAVE BLOCKED: history was never read successfully this session", and the same
covers were re-migrated from scratch every time the app started.

`loadNovelsFromPrefs()` has the identical ordering bug with `novelsReadHealthy`.
Both are fixed by setting the healthy flag before the migration save.

The rest of the history backend audited clean - `HistoryDao` is well guarded
(`trimToLimit` uses a single-variable subquery, `deleteAllExcept` chunks by 500,
`replaceAll` early-returns on empty), and `addHistoryEntry` already writes one
row instead of rewriting the table.

## 5. History tab redesign

`ui/library/HistoryScreen.kt`

Purely additive. `HistoryItem` is untouched and still renders every row.

Entries are now grouped into **Today / Yesterday / weekday name / full date**,
with a continuous vertical timeline rail down the left edge. Each row gets a
node on the rail with a soft halo; the rail breaks between day groups so each
day reads as its own segment. Date headers carry a filled node, the label, a
hairline rule, and a count.

New: `HistoryRow`, `historyDayLabel()`, `buildHistoryTimeline()`,
`HistoryDateHeader()`, `HistoryTimelineItem()`.

## 6. Manga reader restyle

Nothing removed - these are container-level restyles only.

* **Chapters drawer** (`MangaReaderChrome.kt`) - this was the worst offender, a
  hard-edged fully opaque rectangle. Now a rounded trailing edge, translucent
  glass surface, and a gradient hairline highlight.
* **Settings sheet** (`MangaReaderSettingsPanel.kt`) - translucent glass with a
  hairline edge instead of a flat stock Material panel. **Every alpha is still
  multiplied by `panelAlpha`**, so your 1.5s tap-zone vanish still goes fully
  invisible at `panelAlpha = 0f`.
* **Reading mode popup** (`MangaModePopup.kt`) - moved onto `GlassPanel`, the
  same container the library and reader sheets use. Mode rows are now rounded
  and inset instead of full-bleed stripes.
* **Page indicator** (`MangaReaderChrome.kt`) - full pill with a hairline edge,
  matching the glass chips elsewhere.

## 7. Browse screen restyle

`browse/ui/BrowseScreen.kt`. Nothing removed. Browse already used `GlassPanel`
in four places; these were the leftovers still using hard Material outlines:

* Search field - translucent fill plus a gradient hairline edge.
* Updates banner - tinted translucent gradient instead of a flat opaque slab.
* Source icon - softer hairline, slightly rounder.
* Empty-state badge - glass badge with a primary-tinted gradient edge.

---

## Verification done

* Brace balance equal on all 9 touched files.
* All new symbols resolve; imports added where needed (`Canvas`, `Offset`,
  `StrokeCap`, `SimpleDateFormat`/`Calendar`/`Date`/`Locale` in `HistoryScreen`;
  `clip` and `Brush` in `MangaReaderChrome`; `GlassPanel` in `MangaModePopup`).
* `BackupManager` already imported `File`, `SimpleDateFormat`, `Date`, `Locale`.
* No public signature changed. No file deleted, moved, or renamed.
* `eu/kanade/`, `mihon/`, `tachiyomi/` untouched.

## Not done in this round

* Manga tap-zone demo overlay restyle - it is full-bleed colour regions by
  design, so glass would fight its purpose. Say the word and I will round the
  region corners.
* The main-thread ANR risk on "Backup Now" (`createBackup` runs
  `generateBackupJson` synchronously). Safe today only because
  `allowMainThreadQueries()` is on. Scheduled for Phase 4.
* Phases 2-4 of the storage rearchitecture.

---

## Round 4 — 11 Aug, follow-up fixes

### 1. Manga reader: swipe-scroll dead zone when zoomed out

**File:** `app/src/main/java/com/lorelight/manga/reader/MangaWebtoonViewer.kt`

**Cause.** The page column is drawn inside a `graphicsLayer` with `scaleX/scaleY = scale`.
Compose applies the inverse transform when hit-testing, so once `scale < 1` the
`LazyColumn` only receives touches inside its *shrunken* bounds. The container height
compensates (`webtoonContainerHeightPx` divides by scale, so it still fills vertically),
but the width does not — the column becomes `viewportWidth * scale` wide and leaves a
dead margin down each side. Touches there landed on the outer `BoxWithConstraints`,
which had no scroll handling, so the list simply did not move.

**Fix.** A pointer handler on the outer box forwards a single-finger vertical drag from
those margins into `listState.scrollBy()`, dividing by `scale` to convert screen pixels
into content pixels so the page tracks the finger 1:1.

Deliberately narrow, to avoid regressing gestures already fixed:
- Bails out unless the touch *starts* outside the scaled content (`|x - centerX| > halfContentW`).
  Drags on a page still belong to the `LazyColumn`, so there is no race for touch slop
  and no double-scroll.
- Bails out on a second pointer, so pinch-to-zoom is untouched.
- Consumes nothing until touch slop is exceeded, so tap-to-toggle-the-UI still works.

### 2. Continue Reading stuck on the previously read book

**File:** `app/src/main/java/com/lorelight/MainActivity.kt`

**Cause.** Two places kept `currentNovel` stale:
- The `LaunchedEffect(importedNovels)` sync only refreshed the novel it was *already*
  holding (`importedNovels.firstOrNull { it.id == cur.id }`) and called
  `pickResumeNovel` only when `currentNovel` was null. So once the card latched onto a
  book, reading a different one never moved it.
- The `LaunchedEffect(activeNovel)` handler guarded on
  `if (currentNovel?.id == updatedNov.id)`, which is false precisely when the user
  switches books — the one case where the card most needs updating.

Reading a manga, then a novel, left the card on the manga even though the novel had the
newer `lastReadTimestamp`.

**Fix.**
- The library sync now re-runs `pickResumeNovel` (max `lastReadTimestamp`) on every
  library change and adopts the winner.
- The active-novel handler now promotes whatever is open in the reader, unconditionally.
  `nextChapter()` dispatches through `TtsPlaybackManager`, which owns `activeNovel`, so
  tapping Next Chapter updates the card immediately in both read and listen mode.

### 3. Back button parity — system Back vs in-app arrow

`MainActivity.kt`. The phone's Back button and the on-screen back arrow ran
two different code paths. System Back popped one `navStack` entry; the in-app
arrow assigned `selectedNovelForDetails = null`, whose setter unwinds EVERY
trailing Details/Reader entry at once. On Library -> Details(A) -> Details(B),
hardware Back landed on Details(A) while the arrow jumped all the way out.

Added a single `goBackOneLevel()` and routed all five entry points through it:
the root handler, the details handler, `DetailsScreen.onBack`, and both reader
`onClose` callbacks. Left the other `selectedNovelForDetails = null` sites
alone — those are deliberate resets (error toasts, reset-to-home, novel
removal), not back navigation.

### 4. MediaPlayer silent-track failure and native leak

`res/raw/silence.wav` was a malformed 346-byte stub, so `MediaPlayer.create()`
could never prepare it. `create()` returns null on failure, but the code piped
that null through `?.apply { }` and logged "Started continuous silent loop"
regardless. `silentPlayer` stayed null, so every notification update retried
and leaked another native player.

Replaced the stub with a valid 1-second 44.1 kHz mono 16-bit PCM WAV (88,244
bytes) and added a `silentPlayerUnavailable` latch in `TtsPlaybackService.kt`
so a genuine device-level failure is logged once and never retried, with the
player released and nulled on the error path.

### 5. Manual update option in Details

`ui/library/DetailsScreen.kt`. The only manual trigger was a 20dp refresh icon
overlaid on the hero image. The backend routing was already correct for manga
(`checkForNewChapters` -> `checkForNewPluginChapters` -> `checkForNewMangaChapters`,
which re-reads the chapter list from the Tachiyomi source), but there was no
visible control for it.

Hoisted the check state (`isCheckingNew`, `newChaptersMsg`, `checkScope`) to the
top of `DetailsScreen` and extracted the work into one shared `runChapterCheck`
lambda, then added an **Update** button to the source-backed action row next to
Bookmark / Play / Open in browser. Both triggers now drive the same spinner and
the same result toast, so they cannot desync. The button reads "Checking..." and
highlights while a fetch is in flight.

---

## Round 5

### 6. Zoom "groove" detent in the manga reader (fidget feel)

**File:** `app/src/main/java/com/lorelight/manga/reader/MangaReaderGestures.kt`

The old behaviour was a *release* snap: you could pinch freely, and only when you
lifted your fingers did the scale jump back to 1.0 if it happened to land within
0.12 of it. Nothing held while your fingers were still down, so the default view
never felt like it had a home position.

This is now a live detent, like a fidget that clicks into a groove:

- `WebtoonTransformState` gained `rawScale` — the honest, un-detented pinch scale
  sitting behind the rendered `scale`. It is deliberately **not** state-backed
  (only ever touched inside the gesture handler, so it must not recompose).
- `rawScale` is reseeded from the current `scale` at the start of every pinch,
  so the groove re-arms each time you touch down.
- The rendered scale is `rawScale` mapped through a dead zone of half-width
  `groove = 0.12f` centred on 1.0:
  - `|raw - 1| <= groove` -> rendered scale is pinned to **exactly 1.0**
  - past the groove the mapping resumes **continuously from 1.0**

That second point is what makes it feel mechanical rather than broken: there is
no jump when it pops free. You feel resistance, then it releases smoothly.
`rawScale` is allowed to overshoot the limits by one groove width so the
detented result can still reach `minScale` and `maxS` exactly.

The release snap was narrowed from `0.12f` to `0.03f`. It had to be: the groove
is now the same width, so leaving the old value would have yanked back any zoom
the user had deliberately pushed out of the groove.

### 7. Manga Contents drawer now matches the novel Contents drawer

**File:** `app/src/main/java/com/lorelight/manga/reader/MangaReaderChrome.kt`

The two drawers had drifted apart. The manga one was 292dp wide with a rounded
trailing edge, a translucent surface (`alpha = 0.94f`) and a white gradient
hairline border. The novel one is a flat, fully opaque 280dp panel. Side by side
they read as two different apps.

The manga drawer shell is now identical to the novel one: `width(280.dp)` and a
plain `MaterialTheme.colorScheme.surface` background, with the clip and border
removed. Only the content differs now. Both drawers already shared the same
`ChapterRowItem`, header row and divider, so the rows themselves were never the
problem.

Nothing was deleted from the drawer — only the shell styling changed.

### 8. Chapter search in BOTH Contents drawers

**Files:** `manga/reader/MangaReaderChrome.kt`, `ui/reader/ReaderScreen.kt`

A magnifier icon now sits between the "Contents" title and the close button in
both drawers. Tapping it reveals an `OutlinedTextField` below the divider;
tapping it again hides the field and clears the query.

Implementation notes, identical on both sides:

- The icon tints to the reader highlight colour while search is open.
- Filtering is done over `withIndex()`, so each row keeps its **original**
  chapter index. This matters: tapping a filtered row calls
  `selectChapter(index)` / `onSelectChapter(index)` with the true index, not the
  filtered position. Getting this wrong would open the wrong chapter.
- Match is case-insensitive `contains` on the trimmed query.
- A trailing clear (X) button appears once the field is non-empty.
- An empty state ("No chapters match ...") renders inside the `LazyColumn` when
  the filter matches nothing.
- State lives inside the drawer's own `Column`, so it is disposed when the
  drawer closes — search always starts fresh on reopen.

No new imports were required in either file: `material3.*`,
`material.icons.filled.*`, `runtime.*`, `animation.*` and `itemsIndexed` were
already present in both.


## Round 6 - Screen-based manga TTS (experimental)

### 9. Experimental toggle gates the whole feature

`MangaReaderPrefs.kt`
- New keys `experimental_manga_tts` and `show_ocr_boxes`, both defaulting to **false**.
- New accessors `getExperimentalTts` / `setExperimentalTts` and `getShowOcrBoxes` / `setShowOcrBoxes`.

`MangaReaderSettingsPanel.kt`
- New **EXPERIMENTAL** section (section 8, directly above ADVANCED).
- "Read aloud (beta)" switch. While it is off, nothing about the reader changes: the voice button is not rendered at all.
- "Show detected text" switch, revealed only when the feature is on.

### 10. The reader-side feature

New file `manga/reader/MangaTtsController.kt`
- `MangaPageOcr` reads the page through the **same** `MangaPageKey(sourceId, page)` Coil path the viewer uses, so extension headers/cookies still apply and the already-displayed page is a cache hit. Loading by bare URL would 403 on most sources.
- Detection cleanup tuned for English scans: line joining with de-hyphenation, sound-effect rejection by median glyph height, scanlation credit/watermark rejection, edge-hugging page-number rejection, and ALL-CAPS normalisation so the engine reads words instead of spelling them out.
- Reading order follows the reading mode, including right-to-left panel order.
- `MangaTtsController` owns its **own** `TextToSpeech` instance. It reads voice, rate and pitch from `TtsPlaybackManager` but never writes to it, so `activeNovel` and `sessionActive` stay untouched and no play button appears on the Continue Reading card.

`MangaReaderChrome.kt`
- Control Pill gains a fifth `RecordVoiceOver` button, rendered only when the experimental toggle is on.
- While reading, the pill morphs into the same five-button transport the novel reader uses, plus a voice button to end the session. The original four controls return the moment the session ends. Nothing was removed.
- All new parameters are defaulted, so every existing call site keeps compiling.

`MangaReaderScreen.kt`
- Speech drives movement: each bubble is scrolled to the centre of the viewport before it is spoken, so voice and page never drift apart.
- Paged modes auto-flip to the next page. The pager lives in a narrower scope, so the session posts a target page and a new effect beside the pager consumes it.
- Bound to the screen by construction: a lifecycle observer stops playback on `ON_STOP`, and `onDispose` shuts the engine down. There is no service and no wake lock, so it cannot run with the screen off.
- Optional overlay lists what was detected and the order it will be read in, with the current line highlighted.

`app/build.gradle.kts`
- Added `com.google.mlkit:text-recognition:16.0.1`, the **bundled** model rather than the Play Services variant, so it works fully offline and adds no Google Play Services dependency. The build is already `arm64-v8a` only, so the cost is roughly 3-4 MB.


---

## Round 7 - Dead manga settings

An audit of every `MangaReaderPrefs` getter against its consumers found which
settings were genuinely inert rather than guessing from the symptoms. Result:
most settings were already wired. Three were not.

### 1. Background chip did nothing (the 5:32 PM report)

Root cause was a split-brain store, not the image mapping.

- The settings panel wrote the choice with `MangaReaderPrefs.setReaderBackgroundType()`, which lands in `lorelight_manga_reader_prefs`.
- The reader read `readerPrefs.getString("reader_background_type")`, which reads `reader_prefs` - the *novel* reader's store.

Two different files, so the chip could never take effect. The theme to image
mapping was checked against `ReaderContent.kt` and is identical, so it was not
at fault.

`MangaReaderPrefs.kt`
- Added `getReaderBackgroundTypeOrNull()`, returning null when the user has never made a manga-specific choice.

`MangaReaderScreen.kt`
- `readerBackgroundType` now prefers the manga override and falls back to the app theme. Choosing a background affects manga only and leaves the novel reader alone; leaving it untouched keeps following the app theme as before.

### 2. Crop borders was inert

`getCropBorders` had a switch in the UI and zero consumers.

New file `MangaCropBorders.kt`
- `CropBordersTransformation`, a Coil transformation that trims flat scanlator margins so pages sit flush in long strip mode.
- Deliberately conservative: it only crops when all four corners agree on a background colour (otherwise there is real art at the edge), and refuses to remove more than three quarters of the page so a near-blank page cannot collapse.
- Scans on a 64-step grid rather than every pixel.

`MangaWebtoonViewer.kt`, `MangaReaderScreen.kt`
- Added a defaulted `cropBorders: Boolean = false` parameter to `MangaWebtoonViewer`, `WebtoonPageItem` and `MangaPageItem`, applied to the image request. Wired through all four call sites, so it works in webtoon and all three paged modes.

### 3. Preload pages was inert

`getPreloadPages` defaulted to 4 and was never read.

`MangaReaderScreen.kt`
- Added an effect that enqueues the next N pages into the Coil cache as the page index advances. It collects `viewModel.uiState` directly rather than capturing a snapshot, so it keeps preloading while you read instead of running once. Setting the slider to 0 disables it.

### Not bugs, confirmed by the audit

Grayscale, invert colours, scale type, page gap, max zoom, double-tap level,
fullscreen, invert volume keys, side padding, tap zones and brightness overlay
all have live consumers in `MangaReaderScreen.kt`. `getBackground`,
`getMangaOrientation` and `getModeOverride` are vestigial, superseded by
`getReaderBackgroundType`, `getOrientation` and `getEffectiveReadingMode`; they
are left in place rather than deleted.

---

## Storage Reset

### One-time hard reset
`data/local/StorageReset.kt`
- Created `StorageReset.kt` to perform a one-time idempotent hard reset of legacy storage files, shared preferences, and database files before any storage or preference reads occur.
- Executed via `StorageReset.executeIfNeeded(this)` in `LorelightApplication.kt`.

