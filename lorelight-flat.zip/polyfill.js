(function(){
  var G = globalThis;
  function fmt(args){ return Array.prototype.map.call(args, function(a){
    if (a && typeof a === 'object'){ try { return JSON.stringify(a); } catch(e){ return String(a); } }
    return String(a);
  }).join(' '); }
  G.console = {
    log: function(){ __native.log(fmt(arguments)); },
    info: function(){ __native.log(fmt(arguments)); },
    debug: function(){ __native.log(fmt(arguments)); },
    warn: function(){ __native.log('[warn] ' + fmt(arguments)); },
    error: function(){ __native.log('[error] ' + fmt(arguments)); }
  };

  var timers = {}; var timerSeq = 1;
  G.setTimeout = function(fn, ms){ var id = timerSeq++; timers[id] = fn; __native.setTimeoutNative(id, ms||0); return id; };
  G.clearTimeout = function(id){ delete timers[id]; };
  G.setInterval = function(){ __native.log('[polyfill] setInterval not supported'); return 0; };
  G.clearInterval = function(){};
  G.__timeoutFire = function(id){ var fn = timers[id]; if (fn){ delete timers[id]; try { fn(); } catch(e){ __native.log('[setTimeout cb] ' + (e && e.stack || e)); } } };

  var B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  function b64encode(str){
    var out=''; var i=0;
    while (i < str.length){
      var c1=str.charCodeAt(i++)&0xff, c2=str.charCodeAt(i++)&0xff, c3=str.charCodeAt(i++)&0xff;
      var e1=c1>>2, e2=((c1&3)<<4)|(c2>>4), e3=((c2&15)<<2)|(c3>>6), e4=c3&63;
      if (isNaN(c2)){ e3=e4=64; } else if (isNaN(c3)){ e4=64; }
      out += B64.charAt(e1)+B64.charAt(e2)+(e3===64?'=':B64.charAt(e3))+(e4===64?'=':B64.charAt(e4));
    }
    return out;
  }
  function b64decode(str){
    str = String(str).replace(/[^A-Za-z0-9+/=]/g,''); var out=''; var i=0;
    while (i < str.length){
      var e1=B64.indexOf(str.charAt(i++)), e2=B64.indexOf(str.charAt(i++)),
          e3=B64.indexOf(str.charAt(i++)), e4=B64.indexOf(str.charAt(i++));
      var c1=(e1<<2)|(e2>>4), c2=((e2&15)<<4)|(e3>>2), c3=((e3&3)<<6)|e4;
      out += String.fromCharCode(c1);
      if (e3!==64) out += String.fromCharCode(c2);
      if (e4!==64) out += String.fromCharCode(c3);
    }
    return out;
  }
  G.atob = function(s){ return b64decode(s); };
  G.btoa = function(s){ return b64encode(s); };

  function toUtf8(str){ return unescape(encodeURIComponent(String(str))); }
  function fromUtf8(bytes){ return decodeURIComponent(escape(bytes)); }

  G.TextEncoder = function(){};
  G.TextEncoder.prototype.encode = function(str){ var u=toUtf8(str); var a=new Uint8Array(u.length); for(var i=0;i<u.length;i++) a[i]=u.charCodeAt(i)&0xff; return a; };
  G.TextDecoder = function(){};
  G.TextDecoder.prototype.decode = function(bytes){ var a = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes||[]); var s=''; for(var i=0;i<a.length;i++) s+=String.fromCharCode(a[i]); return fromUtf8(s); };

  G.Buffer = {
    from: function(data, enc){
      enc = enc || 'utf8'; var bin;
      if (enc === 'base64') bin = b64decode(String(data));
      else if (enc === 'hex'){ bin=''; var s=String(data); for(var i=0;i<s.length;i+=2) bin+=String.fromCharCode(parseInt(s.substr(i,2),16)); }
      else bin = toUtf8(data);
      return {
        _bin: bin,
        toString: function(e){
          e = e || 'utf8';
          if (e === 'base64') return b64encode(this._bin);
          if (e === 'hex'){ var h=''; for(var i=0;i<this._bin.length;i++){ var v=this._bin.charCodeAt(i).toString(16); h+=(v.length<2?'0':'')+v; } return h; }
          return fromUtf8(this._bin);
        }
      };
    }
  };

  G.URLSearchParams = function(init){
    this._p = [];
    if (typeof init === 'string'){
      init = init.replace(/^\?/, '');
      if (init){ var parts = init.split('&'); for (var i=0;i<parts.length;i++){ var kv=parts[i].split('='); this._p.push([decodeURIComponent(kv[0]||''), decodeURIComponent(kv[1]||'')]); } }
    } else if (init && typeof init === 'object'){
      for (var k in init){ if(init.hasOwnProperty(k)) this._p.push([k, String(init[k])]); }
    }
  };
  G.URLSearchParams.prototype.append = function(k,v){ this._p.push([k,String(v)]); };
  G.URLSearchParams.prototype.set = function(k,v){ this.delete(k); this._p.push([k,String(v)]); };
  G.URLSearchParams.prototype.get = function(k){ for(var i=0;i<this._p.length;i++){ if(this._p[i][0]===k) return this._p[i][1]; } return null; };
  G.URLSearchParams.prototype.getAll = function(k){ var r=[]; for(var i=0;i<this._p.length;i++){ if(this._p[i][0]===k) r.push(this._p[i][1]); } return r; };
  G.URLSearchParams.prototype.has = function(k){ return this.get(k)!==null; };
  G.URLSearchParams.prototype.delete = function(k){ this._p = this._p.filter(function(e){ return e[0]!==k; }); };
  G.URLSearchParams.prototype.toString = function(){ return this._p.map(function(e){ return encodeURIComponent(e[0])+'='+encodeURIComponent(e[1]); }).join('&'); };

  G.__fetchCallbacks = {};
  G.__fetchResolve = function(token, rawJson){ var cb = G.__fetchCallbacks[token]; if(!cb) return; delete G.__fetchCallbacks[token]; try { cb.resolve(JSON.parse(rawJson)); } catch(e){ cb.reject(e); } };
  G.__fetchReject = function(token, msg){ var cb = G.__fetchCallbacks[token]; if(!cb) return; delete G.__fetchCallbacks[token]; cb.reject(new Error(String(msg))); };

  G.window = G.window || G;
  G.global = G.global || G;
})();
