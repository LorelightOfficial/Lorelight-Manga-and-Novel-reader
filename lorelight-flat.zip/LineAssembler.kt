/*
 * =============================================================================
 * LineAssembler.kt - turns an event into one sentence the character says.
 * Package: com.lorelight.companion
 *
 * The corpus is authored in three pieces so that 240 bodies can become tens
 * of thousands of distinct lines:
 *
 *     [opener]  +  body  +  [tail]
 *     "Oh -"       "you added {title}. Ohh, pictures. My favourite."
 *
 * Both brackets are optional, and the corpus deliberately gives the EMPTY
 * opener and EMPTY tail the heaviest weight - so most lines are a bare body,
 * and the decorations stay rare enough to keep their flavour.
 *
 * RULES THIS FILE ENFORCES
 *
 *  1. Openers and tails only attach to a body of a compatible class
 *     (arr / evt / amb), read from the corpus itself.
 *  2. A line NEVER reaches the screen with a raw {placeholder} in it. A body
 *     that needs a title is skipped when no title is available.
 *  3. Bodies are authored lowercase. Capitalisation happens here, and depends
 *     on how the opener ended.
 *  4. The finished line stays inside the character guard so it cannot spill
 *     past two lines in the bubble - the tail is dropped first, then the
 *     opener, because the body carries the meaning.
 *  5. Nothing is drawn twice in a row: bodies come from a persisted shuffle
 *     bag, and a non-empty opener or tail never immediately repeats.
 *
 * Hint-ladder and first-toggle lines are CURATED: they are spoken exactly as
 * authored, with no opener and no tail ever attached.
 * =============================================================================
 */
package com.lorelight.companion

import kotlin.random.Random

class LineAssembler(
    private val corpus: CompanionCorpus,
    private val store: CompanionStore,
    private val bag: ShuffleBag = ShuffleBag(store),
    private val random: Random = Random.Default
) {

    /**
     * Builds the line for [event] in [mood], or null when this event simply
     * cannot be spoken right now (no bodies, or every body needs a value we
     * were not given).
     */
    fun assemble(
        event: CompanionEvent,
        mood: Mood,
        params: LineParams = LineParams()
    ): CompanionLine? {
        val bodies = corpus.bodies(mood, event)
        if (bodies.isEmpty()) return null

        val rawBody = drawBody(bodies, event, mood, params) ?: return null
        val cls = corpus.classOf(event)
        val body = substitute(rawBody, params)

        val opener = pickFragment(corpus.openers(mood), cls, "open.${mood.wire}.${cls.wire}")
        val tail = pickFragment(corpus.tails(mood), cls, "tail.${mood.wire}.${cls.wire}")

        val text = join(opener, body, tail)
        store.putString(LAST_TEXT, text)

        return CompanionLine(text = text, mood = mood, event = event)
    }

    /**
     * Draws one curated line (hint ladder, update nudge, first-toggle payoff)
     * straight from a pool. No opener, no tail, no substitution.
     *
     * @param bagKey a stable key so the pool cycles instead of repeating.
     */
    fun curated(pool: List<String>, mood: Mood, bagKey: String, event: CompanionEvent? = null): CompanionLine? {
        if (pool.isEmpty()) return null
        val index = bag.draw(bagKey, pool.size)
        if (index < 0) return null
        val text = pool[index]
        store.putString(LAST_TEXT, text)
        return CompanionLine(text = text, mood = mood, event = event, isCurated = true)
    }

    /* --- body selection ---------------------------------------------------- */

    /**
     * Pulls from the shuffle bag until it lands on a body whose placeholders
     * can all be filled.
     *
     * Bodies that need a title are common, so rather than failing we retry -
     * but only a bounded number of times, and then fall back to scanning for
     * any fillable body so a real event is never silently dropped.
     */
    private fun drawBody(
        bodies: List<String>,
        event: CompanionEvent,
        mood: Mood,
        params: LineParams
    ): String? {
        val key = "body.${mood.wire}.${event.key}"
        val attempts = bodies.size.coerceAtMost(MAX_DRAW_ATTEMPTS)

        repeat(attempts) {
            val index = bag.draw(key, bodies.size)
            if (index >= 0) {
                val candidate = bodies[index]
                if (canFill(candidate, params)) return candidate
            }
        }

        // Nothing came up fillable - take the first one that is.
        return bodies.firstOrNull { canFill(it, params) }
    }

    private fun canFill(body: String, params: LineParams): Boolean {
        if (body.contains(TITLE) && params.title.isNullOrBlank()) return false
        if (body.contains(DAYS) && params.days == null) return false
        if (body.contains(COUNT) && params.n == null) return false
        return true
    }

    private fun substitute(body: String, params: LineParams): String {
        var out = body
        params.title?.let { out = out.replace(TITLE, shortenTitle(it)) }
        params.days?.let { out = out.replace(DAYS, it.toString()) }
        params.n?.let { out = out.replace(COUNT, it.toString()) }
        return out
    }

    /**
     * Book titles can be enormous. Left alone, one light novel title would
     * blow the whole character guard and push the bubble past two lines, so
     * a long title is cut at a word boundary.
     */
    private fun shortenTitle(title: String): String {
        val clean = title.trim()
        if (clean.length <= TITLE_MAX) return clean

        val cut = clean.lastIndexOf(' ', TITLE_MAX)
        val stem = if (cut > TITLE_MIN) clean.substring(0, cut) else clean.substring(0, TITLE_MAX)
        return stem.trimEnd(' ', ',', '-', ':', ';') + "..."
    }

    /* --- opener / tail selection ------------------------------------------- */

    /**
     * Weighted draw among the fragments that fit this class.
     *
     * The empty fragment is a legitimate, high-weight outcome - it means the
     * body stands alone. Only a NON-empty fragment is blocked from repeating,
     * because hearing "Oh -" twice running is what makes a character sound
     * scripted, whereas two plain lines in a row sound normal.
     */
    private fun pickFragment(all: List<Fragment>, cls: LineClass, lastKey: String): Fragment? {
        if (all.isEmpty()) return null

        val lastText = store.getString(lastKey, null)
        var total = 0
        var eligible = 0

        for (f in all) {
            if (!f.allows(cls)) continue
            eligible++
            if (blocked(f, lastText)) continue
            total += f.weight
        }
        if (eligible == 0) return null

        // Everything eligible was blocked (only possible with one candidate):
        // allow the repeat rather than returning nothing.
        if (total <= 0) {
            val fallback = all.firstOrNull { it.allows(cls) }
            return fallback
        }

        var roll = random.nextInt(total)
        for (f in all) {
            if (!f.allows(cls)) continue
            if (blocked(f, lastText)) continue
            roll -= f.weight
            if (roll < 0) {
                store.putString(lastKey, f.text)
                return f
            }
        }
        return null
    }

    private fun blocked(f: Fragment, lastText: String?): Boolean =
        !f.isEmpty && f.text == lastText

    /* --- joining ----------------------------------------------------------- */

    /**
     * Glues the three pieces together, fixes capitalisation, and drops
     * decorations until the line fits.
     */
    private fun join(opener: Fragment?, body: String, tail: Fragment?): String {
        val openText = opener?.text.orEmpty()
        val tailText = tail?.text.orEmpty()

        val full = build(openText, body, tailText)
        if (full.length <= MAX_CHARS) return full

        // Too long: the tail is pure decoration, so it goes first.
        val noTail = build(openText, body, "")
        if (noTail.length <= MAX_CHARS) return noTail

        // Still too long: drop the opener too. The body always survives.
        return build("", body, "")
    }

    private fun build(openText: String, body: String, tailText: String): String {
        val sb = StringBuilder(openText.length + body.length + tailText.length + 2)

        if (openText.isNotEmpty()) sb.append(openText)

        val needsCapital = openText.isEmpty() || endsSentence(openText)
        val shapedBody = if (needsCapital) capitalise(body) else body

        if (sb.isNotEmpty()) sb.append(' ')
        sb.append(shapedBody)

        if (tailText.isNotEmpty()) {
            sb.append(' ')
            sb.append(tailText)
        }
        return sb.toString()
    }

    /**
     * "Hey." closed a sentence, so the body must start with a capital.
     * "Oh -" and "Well," did not, so the body stays lowercase and the line
     * reads as one continuous thought.
     */
    private fun endsSentence(text: String): Boolean {
        val last = text.trimEnd().lastOrNull() ?: return false
        return last == '.' || last == '!' || last == '?'
    }

    private fun capitalise(text: String): String {
        if (text.isEmpty()) return text
        val first = text[0]
        if (!first.isLetter() || first.isUpperCase()) return text
        return first.uppercaseChar() + text.substring(1)
    }

    companion object {
        /**
         * Hard character guard. Bodies are authored at <= 85 chars and the
         * bubble is measured for two lines at 240dp, so this keeps even a
         * fully decorated line inside the box.
         */
        const val MAX_CHARS = 96

        private const val TITLE_MAX = 30
        private const val TITLE_MIN = 12
        private const val MAX_DRAW_ATTEMPTS = 4

        private const val TITLE = "{title}"
        private const val DAYS = "{days}"
        private const val COUNT = "{n}"

        private const val LAST_TEXT = "last.text"
    }
}
