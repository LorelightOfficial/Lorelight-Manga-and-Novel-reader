package com.lorelight.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reading_progress")
data class ReadingProgressEntity(
    @PrimaryKey val novelId: String,
    val currentChapter: String,
    val currentParagraphIndex: Int,
    val currentScrollOffset: Int,
    val currentWordIndex: Int,
    val lastReadTimestamp: Long,
    val updatedAt: Long,
    // RESUME REDESIGN. This is the HOT path -- one row per novel, rewritten on
    // every page turn -- while the novels row is only touched on a full save. If
    // the index did not travel with the name, the fresher of the two copies
    // would carry a name and a stale index. -1 = nothing recorded.
    val currentChapterIndex: Int = -1
)
