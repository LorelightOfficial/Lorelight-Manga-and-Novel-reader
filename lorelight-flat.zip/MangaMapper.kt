package com.lorelight.manga.model

import com.lorelight.data.model.MANGA_PLUGIN_PREFIX
import com.lorelight.data.model.Novel
import com.lorelight.data.model.encodeMangaChapterUrl
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga

fun mapMangaStatus(status: Int): String {
    return when (status) {
        SManga.ONGOING -> "Ongoing"
        SManga.COMPLETED, SManga.PUBLISHING_FINISHED -> "Completed"
        SManga.CANCELLED -> "Cancelled"
        SManga.ON_HIATUS -> "On Hiatus"
        SManga.UNKNOWN, SManga.LICENSED -> "Unknown"
        else -> "Unknown"
    }
}

fun List<SChapter>.toChapterUrls(sourceId: Long): List<String> {
    // source.getChapterList() returns chapters NEWEST FIRST.
    // The app stores and displays chapters in reading order (oldest first).
    // Reversing here ensures all chapter lists in Novel are stored oldest-first.
    return reversed().map { encodeMangaChapterUrl(sourceId, it.url) }
}

fun List<SChapter>.toChapterNames(): List<String> {
    // source.getChapterList() returns chapters NEWEST FIRST.
    // The app stores and displays chapters in reading order (oldest first).
    // Reversing here ensures all chapter names in Novel are stored oldest-first.
    return reversed().mapIndexed { index, chapter ->
        chapter.name.takeIf { it.isNotBlank() } ?: "Chapter ${index + 1}"
    }
}

fun List<SChapter>.toChapterNumbers(): List<Float> {
    // source.getChapterList() returns chapters NEWEST FIRST.
    // The app stores and displays chapters in reading order (oldest first).
    // Reversing here ensures all chapter numbers in Novel are stored oldest-first.
    return reversed().map { it.chapter_number }
}

fun SManga.toNovel(
    sourceId: Long,
    existing: Novel? = null,
    chapters: List<SChapter> = emptyList()
): Novel {
    val pluginIdStr = MANGA_PLUGIN_PREFIX + sourceId
    val mappedAuthor = author?.takeIf { it.isNotBlank() }
        ?: artist?.takeIf { it.isNotBlank() }
        ?: ""
    val mappedStatus = mapMangaStatus(status)
    val mappedGenres = genre
        ?.split(",")
        ?.map { it.trim() }
        ?.filter { it.isNotEmpty() }
        ?.takeIf { it.isNotEmpty() }
        ?: listOf("Manga")
    val mappedDescription = description ?: ""
    val mappedCover = thumbnail_url ?: ""

    val chapterNames = if (chapters.isNotEmpty()) chapters.toChapterNames() else (existing?.chapters ?: emptyList())
    val chapterUrls = if (chapters.isNotEmpty()) chapters.toChapterUrls(sourceId) else (existing?.chapterUrls ?: emptyList())
    val chapterNumbers = if (chapters.isNotEmpty()) chapters.toChapterNumbers() else (existing?.chapterNumbers ?: emptyList())

    return if (existing != null) {
        existing.copy(
            title = title,
            author = mappedAuthor,
            status = mappedStatus,
            totalChapters = if (chapters.isNotEmpty()) chapterNames.size else existing.totalChapters,
            genres = mappedGenres,
            description = mappedDescription,
            chapters = chapterNames,
            coverImageBase64 = mappedCover,
            isOnline = true,
            sourceUrl = url,
            chapterUrls = chapterUrls,
            chapterNumbers = chapterNumbers,
            pluginId = pluginIdStr,
            pluginNovelPath = url,
            dateModified = System.currentTimeMillis()
        )
    } else {
        Novel(
            title = title,
            currentChapter = chapterNames.firstOrNull() ?: "Chapter 1",
            lastReadTimestamp = 0L,
            author = mappedAuthor,
            status = mappedStatus,
            totalChapters = chapterNames.size,
            genres = mappedGenres,
            description = mappedDescription,
            chapters = chapterNames,
            coverImageBase64 = mappedCover,
            isOnline = true,
            sourceUrl = url,
            chapterUrls = chapterUrls,
            chapterNumbers = chapterNumbers,
            pluginId = pluginIdStr,
            pluginNovelPath = url
        )
    }
}
