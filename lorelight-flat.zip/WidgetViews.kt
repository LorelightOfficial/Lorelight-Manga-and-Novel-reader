package com.lorelight.widget

import android.appwidget.AppWidgetManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.graphics.RectF
import android.text.format.DateUtils
import android.view.View
import android.widget.RemoteViews
import com.lorelight.R
import com.lorelight.data.model.Novel
import kotlin.math.max
import kotlin.math.min

internal object WidgetViews {
    internal data class Bounds(val width: Int, val height: Int)
    private fun bounds(context: Context, id: Int, landscape: Boolean): Bounds {
        val options = AppWidgetManager.getInstance(context).getAppWidgetOptions(id)
        val w = options.getInt(if (landscape) AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH else AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 320)
        val h = options.getInt(if (landscape) AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 180)
        return Bounds(w.coerceAtLeast(120),h.coerceAtLeast(80))
    }
    private fun background(b: Bounds, p: WidgetPalette): Bitmap {
        // Rendered at exact widget pixel dimensions — matches the in-app ContinueReadingCard
        // visually: same 16 dp corner, same surfaceVariant@55 % alpha base, same outline@30 %.
        val w = b.width.coerceAtLeast(1)
        val h = b.height.coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val inset = 1f
        // 16 dp corner — identical to RoundedCornerShape(16.dp) in ContinueReadingCard
        val corner = 16f * (w / 360f).coerceIn(0.8f, 1.5f)
        val rect = RectF(inset, inset, w - inset, h - inset)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // --- Base: surfaceVariant at 55 % alpha (exact match to app card) ---
        paint.color = (p.surface and 0x00FFFFFF) or (0x8C shl 24)  // 0x8C = round(255 * 0.55)
        canvas.drawRoundRect(rect, corner, corner, paint)

        // --- Glass sheen: soft top-to-mid gradient, keeps the glassy feel ---
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_OVER)
        paint.shader = LinearGradient(
            0f, inset, 0f, h * 0.55f,
            intArrayOf(0x20FFFFFF, 0x0AFFFFFF, 0x00FFFFFF),
            floatArrayOf(0f, 0.30f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(rect, corner, corner, paint)
        paint.shader = null

        // --- Subtle bottom depth shadow ---
        paint.shader = LinearGradient(
            0f, h * 0.70f, 0f, h.toFloat(),
            intArrayOf(0x00000000, 0x14000000),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(rect, corner, corner, paint)
        paint.shader = null

        // --- Outline: outline.copy(alpha = 0.30f) — exact match to app card border ---
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        paint.color = (p.outline and 0x00FFFFFF) or (0x4D shl 24)  // 0x4D = round(255 * 0.30)
        canvas.drawRoundRect(rect, corner, corner, paint)

        return bitmap
    }
    private fun base(context: Context, layout: Int, b: Bounds, p: WidgetPalette): RemoteViews = RemoteViews(context.packageName, layout).apply {
        setImageViewBitmap(R.id.w_bg,background(b,p))
    }
    private fun RemoteViews.text(id: Int, value: CharSequence, color: Int) { setTextViewText(id,value); setTextColor(id,color) }
    private fun RemoteViews.icon(id: Int, resource: Int, description: String, color: Int) {
        setImageViewResource(id,resource); setContentDescription(id,description); setInt(id,"setColorFilter",color)
    }
    private suspend fun RemoteViews.cover(context: Context, id: Int, novel: Novel) {
        val bitmap = try { WidgetCovers.get(context,novel) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (_: Exception) { null }
        if (bitmap == null) setImageViewResource(id,R.drawable.widget_book) else setImageViewBitmap(id,bitmap)
        setContentDescription(id,novel.title)
    }
    private fun message(context: Context, widgetId: Int, b: Bounds, p: WidgetPalette, title: Int, body: Int): RemoteViews =
        base(context,R.layout.widget_message,b,p).apply {
            text(R.id.w_message_title,context.getString(title),p.text)
            text(R.id.w_message_body,context.getString(body),p.secondary)
            text(R.id.w_open,context.getString(R.string.widget_open_library),p.accent)
            setOnClickPendingIntent(R.id.w_open,WidgetActions.open(context,widgetId,"widget-library"))
            if (title == R.string.widget_resize_title) setViewVisibility(R.id.w_open,View.GONE)
        }
    suspend fun continueReading(context: Context, id: Int, state: WidgetResume): RemoteViews {
        val p = WidgetAppearance.palette(context)
        suspend fun draw(b: Bounds): RemoteViews {
            val font = context.resources.configuration.fontScale.coerceAtLeast(1f)
            val minimumHeight = 150 + ((font - 1f) * 90f).toInt()
            if (b.width < 250 + ((font - 1f) * 72f).toInt() || b.height < minimumHeight) return message(context,id,b,p,R.string.widget_resize_title,R.string.widget_resize_body)
            val novel = state.novel ?: return message(context,id,b,p,R.string.widget_no_active,R.string.widget_empty_reading)
            val audio = state.mode == ResumeMode.PLAYING || state.mode == ResumeMode.PAUSED
            return base(context,R.layout.widget_continue,b,p).apply {
                val status = when (state.mode) {
                    ResumeMode.PLAYING -> R.string.widget_now_playing
                    ResumeMode.PAUSED -> R.string.widget_audio_paused
                    ResumeMode.MANGA -> R.string.widget_continue_manga
                    else -> R.string.widget_continue_name
                }
                text(R.id.w_status,context.getString(status),p.accent)
                text(R.id.w_title,novel.title,p.text)
                text(R.id.w_chapter,if (state.mode == ResumeMode.MANGA && state.page > 0)
                    context.getString(R.string.widget_chapter_page,state.chapter,state.page+1) else state.chapter,p.secondary)
                val time = if (novel.lastReadTimestamp > 0) DateUtils.getRelativeTimeSpanString(novel.lastReadTimestamp,System.currentTimeMillis(),DateUtils.MINUTE_IN_MILLIS)
                    else context.getString(R.string.widget_not_started)
                text(R.id.w_time,time,p.secondary)
                val progress = Bitmap.createBitmap(240,3,Bitmap.Config.ARGB_8888)
                Canvas(progress).apply {
                    val paint = Paint().apply { color = p.accent; alpha = 40 }
                    drawRect(0f,0f,240f,3f,paint)
                    paint.alpha = 255
                    drawRect(0f,0f,240f * state.percent / 100f,3f,paint)
                }
                setImageViewBitmap(R.id.w_progress,progress)
                setContentDescription(R.id.w_progress,context.getString(R.string.widget_progress_description,state.percent))
                setViewVisibility(R.id.w_progress,if (!audio && state.percent > 0) View.VISIBLE else View.GONE)
                setViewVisibility(R.id.w_time,if (audio) View.GONE else View.VISIBLE)
                setViewVisibility(R.id.w_audio_controls,if (audio) View.VISIBLE else View.GONE)
                setViewVisibility(R.id.w_read_controls,if (audio) View.GONE else View.VISIBLE)
                setViewVisibility(R.id.w_stop,if (audio) View.VISIBLE else View.GONE)
                setViewVisibility(R.id.w_play_read,if (state.mode == ResumeMode.MANGA) View.GONE else View.VISIBLE)
                cover(context,R.id.w_cover,novel)
                val read = WidgetActions.open(context,id,"widget-read",novel.id)
                setOnClickPendingIntent(R.id.w_summary,read)
                setOnClickPendingIntent(R.id.w_continue,read)
                text(R.id.w_continue,context.getString(R.string.widget_continue_button),p.accent)
                text(R.id.w_play_read,context.getString(R.string.widget_play),p.accent)
                setContentDescription(R.id.w_continue,context.getString(R.string.widget_continue_title,novel.title))
                setOnClickPendingIntent(R.id.w_play_read,WidgetActions.open(context,id,"widget-listen",novel.id))
                fun action(view: Int, drawable: Int, label: Int, command: String, enabled: Boolean = true) {
                    icon(view,drawable,context.getString(label),if (enabled) p.text else (p.text and 0x00FFFFFF) or 0x55000000)
                    setBoolean(view,"setEnabled",enabled)
                    if (enabled) setOnClickPendingIntent(view,WidgetActions.control(context,id,command,novel.id))
                }
                action(R.id.w_stop,R.drawable.widget_close,R.string.widget_stop,"stop")
                action(R.id.w_prev_chapter,R.drawable.widget_prev_chapter,R.string.widget_prev_chapter,"prev_chapter",state.chapterIndex > 0)
                action(R.id.w_prev_sentence,R.drawable.widget_prev_sentence,R.string.widget_prev_sentence,"prev_sentence")
                action(R.id.w_play_pause,if (state.mode == ResumeMode.PLAYING) R.drawable.widget_pause else R.drawable.widget_play,
                    if (state.mode == ResumeMode.PLAYING) R.string.widget_pause else R.string.widget_play,
                    if (state.mode == ResumeMode.PLAYING) "pause" else "play")
                setInt(R.id.w_play_pause,"setColorFilter",p.accent)
                action(R.id.w_next_sentence,R.drawable.widget_next_sentence,R.string.widget_next_sentence,"next_sentence")
                action(R.id.w_next_chapter,R.drawable.widget_next_chapter,R.string.widget_next_chapter,"next_chapter",state.chapterIndex < state.chapterCount-1)
            }
        }
        return RemoteViews(draw(bounds(context,id,true)),draw(bounds(context,id,false)))
    }
    internal fun shelfGrid(width: Int, height: Int, fontScale: Float): Pair<Int,Int> {
        val rows = if (height >= (270 + (fontScale-1).coerceAtLeast(0f)*70).toInt()) 2 else 1
        val columns = when { rows == 2 && width >= 260 -> 3; width >= 320 -> 4; width >= 250 -> 3; else -> 2 }
        return columns to rows
    }
    fun visibleShelfEntries(context: Context, id: Int, library: List<Novel>): List<Novel> {
        val settings = WidgetPreferences.load(context,id)
        val entries = WidgetPreferences.entries(library,settings)
        return listOf(false,true).flatMap { landscape ->
            val b = bounds(context,id,landscape)
            val (cols,rows) = shelfGrid(b.width,b.height,context.resources.configuration.fontScale)
            val capacity = cols*rows
            val pages = ((entries.size + capacity-1)/capacity).coerceAtLeast(1)
            entries.drop(settings.page.coerceIn(0,pages-1)*capacity).take(capacity)
        }.distinctBy { it.id }
    }
    suspend fun bookshelf(context: Context, id: Int, library: List<Novel>): RemoteViews {
        val p = WidgetAppearance.palette(context)
        val settings = WidgetPreferences.load(context,id)
        val entries = WidgetPreferences.entries(library,settings)
        suspend fun draw(b: Bounds): RemoteViews {
            val font = context.resources.configuration.fontScale.coerceAtLeast(1f)
            if (b.width < 250 + ((font-1)*72).toInt() || b.height < 150 + ((font-1)*55).toInt()) return message(context,id,b,p,R.string.widget_resize_title,R.string.widget_resize_body)
            val (cols,rows) = shelfGrid(b.width,b.height,font)
            val capacity = cols*rows
            val pages = ((entries.size + capacity-1)/capacity).coerceAtLeast(1)
            val page = settings.page.coerceIn(0,pages-1)
            val shown = entries.drop(page*capacity).take(capacity)
            return base(context,R.layout.widget_shelf,b,p).apply {
                text(R.id.w_shelf_title,context.getString(R.string.widget_shelf_name),p.text)
                val category = context.getString(when (settings.mode) {
                    ShelfMode.RECENT -> R.string.widget_recent
                    ShelfMode.FAVOURITES -> R.string.widget_favourites
                    ShelfMode.SELECTED -> R.string.widget_selected
                })
                text(R.id.w_shelf_subtitle,context.getString(R.string.widget_shelf_page,category,page+1,pages),p.secondary)
                icon(R.id.w_settings,R.drawable.widget_settings,context.getString(R.string.widget_configure),p.accent)
                setOnClickPendingIntent(R.id.w_settings,WidgetActions.configure(context,id))
                setOnClickPendingIntent(R.id.w_shelf_heading,WidgetActions.open(context,id,"widget-library"))
                icon(R.id.w_shelf_prev,R.drawable.widget_previous,context.getString(R.string.widget_previous_page),p.secondary)
                icon(R.id.w_shelf_next,R.drawable.widget_next,context.getString(R.string.widget_next_page),p.secondary)
                setViewVisibility(R.id.w_shelf_prev,if (pages > 1) View.VISIBLE else View.GONE)
                setViewVisibility(R.id.w_shelf_next,if (pages > 1) View.VISIBLE else View.GONE)
                setBoolean(R.id.w_shelf_prev,"setEnabled",page>0)
                setBoolean(R.id.w_shelf_next,"setEnabled",page<pages-1)
                setOnClickPendingIntent(R.id.w_shelf_prev,WidgetActions.control(context,id,"shelf_prev",page.toString()))
                setOnClickPendingIntent(R.id.w_shelf_next,WidgetActions.control(context,id,"shelf_next",page.toString()))
                setViewVisibility(R.id.w_shelf_empty,if (shown.isEmpty()) View.VISIBLE else View.GONE)
                text(R.id.w_shelf_empty,context.getString(if (library.isEmpty()) R.string.widget_empty_shelf else R.string.widget_empty_filter),p.secondary)
                setOnClickPendingIntent(R.id.w_shelf_empty,WidgetActions.configure(context,id))
                removeAllViews(R.id.w_shelf_rows)
                for (row in 0 until rows) {
                    val rowViews = RemoteViews(context.packageName,R.layout.widget_shelf_row)
                    for (column in 0 until cols) {
                        val novel = shown.getOrNull(row*cols+column)
                        val tile = RemoteViews(context.packageName,R.layout.widget_shelf_tile)
                        if (novel == null) tile.setViewVisibility(R.id.w_tile_content,View.INVISIBLE)
                        else {
                            tile.text(R.id.w_tile_title,novel.title,p.text)
                            tile.cover(context,R.id.w_tile_cover,novel)
                            tile.setOnClickPendingIntent(R.id.w_tile_content,WidgetActions.open(context,id,"title",novel.id))
                            tile.setContentDescription(R.id.w_tile_content,context.getString(R.string.widget_open_title,novel.title))
                        }
                        rowViews.addView(R.id.w_row,tile)
                    }
                    addView(R.id.w_shelf_rows,rowViews)
                }
            }
        }
        return RemoteViews(draw(bounds(context,id,true)),draw(bounds(context,id,false)))
    }
}
