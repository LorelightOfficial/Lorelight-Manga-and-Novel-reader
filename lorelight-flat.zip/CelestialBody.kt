package com.lorelight.ui.theme.modeswitch.celestial

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.center
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.lorelight.ui.theme.LocalMotionLevel
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.random.Random

enum class CelestialForm { SUN, MOON }

/** A broad expression library. Legacy names preserved as compatibility labels. */
enum class CelestialExpression {
    NEUTRAL, BLINK, DOUBLE_BLINK, TWITCH, BROW_RAISE, SURPRISE, WINK, LOOK_AROUND,
    SLEEPY, SHIVER, JOY, LAUGH, GIGGLE, EXCITED, DELIGHTED, PROUD, CONTENT, AFFECTIONATE,
    SHY, EMBARRASSED, PLAYFUL, SMUG, CURIOUS, CONFUSED, THINKING, SKEPTICAL, FOCUSED,
    DETERMINED, ANNOYED, FRUSTRATED, ANGRY, POUT, SAD, DISAPPOINTED, WORRIED, TEARFUL,
    AFRAID, SHOCKED, RELIEVED, YAWN, DOZING, AWAKENING, TIRED, BORED, HOPEFUL, GRATEFUL
}

/** Eye/brow/mouth animation data. Negative brows slant inward; negative smile frowns. */
data class CelestialFaceSnapshot(
    val lidLeft: Float    = 0.1f,
    val lidRight: Float   = 0.1f,
    val browLeft: Float   = 0f,
    val browRight: Float  = 0f,
    val pupilX: Float     = 0f,
    val pupilY: Float     = 0f,
    val mouthOpen: Float  = 0f,
    val mouthSmile: Float = 0.28f,
    val headTilt: Float   = 0f,
    val squash: Float     = 0f,
    val cheekGlow: Float  = 0f,
    val tears: Float      = 0f,
    val pupilScale: Float = 1f
)

internal val CelestialRest = CelestialFaceSnapshot()

/** Key poses for every expression. */
internal fun celestialPose(expression: CelestialExpression): CelestialFaceSnapshot = when (expression) {
    CelestialExpression.NEUTRAL      -> CelestialRest
    CelestialExpression.BLINK        -> CelestialRest.copy(lidLeft = 1f, lidRight = 1f)
    CelestialExpression.DOUBLE_BLINK -> CelestialRest.copy(lidLeft = 1f, lidRight = 1f)
    CelestialExpression.TWITCH       -> CelestialRest.copy(lidLeft = 0.55f, browLeft = -0.2f, mouthSmile = 0.05f)
    CelestialExpression.BROW_RAISE   -> CelestialRest.copy(browLeft = 0.8f, browRight = -0.12f, pupilX = 0.3f, mouthSmile = 0.22f)
    CelestialExpression.SURPRISE     -> CelestialRest.copy(lidLeft = 0f, lidRight = 0f, browLeft = 0.8f, browRight = 0.8f, mouthOpen = 0.7f, mouthSmile = 0f, pupilScale = 0.7f)
    CelestialExpression.WINK         -> CelestialRest.copy(lidRight = 1f, mouthSmile = 0.85f, cheekGlow = 0.35f)
    CelestialExpression.LOOK_AROUND  -> CelestialRest.copy(pupilX = -0.8f, pupilY = -0.15f, browLeft = 0.3f)
    CelestialExpression.SLEEPY       -> CelestialRest.copy(lidLeft = 0.66f, lidRight = 0.66f, pupilY = 0.4f, mouthOpen = 0.08f, mouthSmile = 0.05f)
    CelestialExpression.SHIVER       -> CelestialRest.copy(lidLeft = 0.28f, lidRight = 0.18f, browLeft = 0.8f, browRight = 0.5f, mouthSmile = -0.25f, mouthOpen = 0.12f)
    CelestialExpression.JOY          -> CelestialRest.copy(lidLeft = 0.45f, lidRight = 0.45f, mouthSmile = 1f, mouthOpen = 0.4f, cheekGlow = 0.5f)
    CelestialExpression.LAUGH        -> CelestialRest.copy(lidLeft = 1f, lidRight = 1f, mouthSmile = 1f, mouthOpen = 0.85f, cheekGlow = 0.7f)
    CelestialExpression.GIGGLE       -> CelestialRest.copy(lidLeft = 0.75f, lidRight = 0.62f, mouthSmile = 0.9f, mouthOpen = 0.22f, cheekGlow = 0.6f)
    CelestialExpression.EXCITED      -> CelestialRest.copy(browLeft = 0.7f, browRight = 0.7f, mouthSmile = 0.9f, mouthOpen = 0.72f, pupilScale = 1.18f, cheekGlow = 0.5f)
    CelestialExpression.DELIGHTED    -> CelestialRest.copy(browLeft = 0.32f, browRight = 0.4f, mouthSmile = 0.85f, mouthOpen = 0.32f, pupilScale = 1.12f, cheekGlow = 0.45f)
    CelestialExpression.PROUD        -> CelestialRest.copy(lidLeft = 0.32f, lidRight = 0.32f, browLeft = 0.2f, mouthSmile = 0.72f, pupilY = -0.22f)
    CelestialExpression.CONTENT      -> CelestialRest.copy(lidLeft = 0.35f, lidRight = 0.35f, mouthSmile = 0.45f, cheekGlow = 0.18f)
    CelestialExpression.AFFECTIONATE -> CelestialRest.copy(lidLeft = 0.22f, lidRight = 0.22f, mouthSmile = 0.55f, pupilScale = 1.2f, cheekGlow = 0.85f)
    CelestialExpression.SHY          -> CelestialRest.copy(pupilX = 0.65f, pupilY = 0.35f, lidLeft = 0.2f, lidRight = 0.22f, mouthSmile = 0.32f, cheekGlow = 1f)
    CelestialExpression.EMBARRASSED  -> CelestialRest.copy(lidLeft = 0.5f, lidRight = 0.38f, pupilX = -0.5f, browLeft = 0.55f, browRight = 0.15f, mouthSmile = -0.1f, cheekGlow = 1f)
    CelestialExpression.PLAYFUL      -> CelestialRest.copy(lidLeft = 0.1f, lidRight = 0.5f, browLeft = 0.65f, mouthSmile = 0.9f, mouthOpen = 0.16f, pupilX = 0.4f)
    CelestialExpression.SMUG         -> CelestialRest.copy(lidLeft = 0.5f, lidRight = 0.4f, browRight = 0.7f, mouthSmile = 0.7f, pupilX = -0.25f)
    CelestialExpression.CURIOUS      -> CelestialRest.copy(browLeft = 0.75f, browRight = 0.08f, pupilX = 0.55f, mouthOpen = 0.12f, mouthSmile = 0.15f)
    CelestialExpression.CONFUSED     -> CelestialRest.copy(browLeft = 0.9f, browRight = -0.35f, lidRight = 0.28f, pupilX = -0.35f, mouthSmile = -0.12f)
    CelestialExpression.THINKING     -> CelestialRest.copy(pupilX = 0.65f, pupilY = -0.7f, lidLeft = 0.25f, lidRight = 0.15f, browLeft = 0.3f, mouthSmile = 0f)
    CelestialExpression.SKEPTICAL    -> CelestialRest.copy(lidLeft = 0.45f, lidRight = 0.15f, browRight = 0.85f, mouthSmile = -0.15f, pupilX = 0.45f)
    CelestialExpression.FOCUSED      -> CelestialRest.copy(lidLeft = 0.22f, lidRight = 0.22f, browLeft = -0.45f, browRight = -0.45f, mouthSmile = 0f, pupilScale = 0.9f)
    CelestialExpression.DETERMINED   -> CelestialRest.copy(browLeft = -0.8f, browRight = -0.8f, mouthSmile = 0.28f, mouthOpen = 0.05f, pupilScale = 0.85f)
    CelestialExpression.ANNOYED      -> CelestialRest.copy(lidLeft = 0.45f, lidRight = 0.3f, browLeft = -0.6f, browRight = -0.35f, mouthSmile = -0.4f)
    CelestialExpression.FRUSTRATED   -> CelestialRest.copy(lidLeft = 0.55f, lidRight = 0.55f, browLeft = -0.8f, browRight = -0.8f, mouthSmile = -0.6f, mouthOpen = 0.15f)
    CelestialExpression.ANGRY        -> CelestialRest.copy(lidLeft = 0.22f, lidRight = 0.22f, browLeft = -1f, browRight = -1f, mouthSmile = -0.7f, mouthOpen = 0.35f, pupilScale = 0.75f)
    CelestialExpression.POUT         -> CelestialRest.copy(lidLeft = 0.3f, lidRight = 0.3f, mouthSmile = -0.8f, cheekGlow = 0.5f, mouthOpen = 0.04f)
    CelestialExpression.SAD          -> CelestialRest.copy(browLeft = 0.8f, browRight = 0.8f, lidLeft = 0.22f, lidRight = 0.22f, mouthSmile = -0.7f, pupilY = 0.3f, tears = 0.25f)
    CelestialExpression.DISAPPOINTED -> CelestialRest.copy(lidLeft = 0.55f, lidRight = 0.55f, browLeft = 0.45f, browRight = 0.45f, mouthSmile = -0.5f, pupilY = 0.65f)
    CelestialExpression.WORRIED      -> CelestialRest.copy(browLeft = 0.85f, browRight = 0.55f, mouthSmile = -0.4f, mouthOpen = 0.13f, pupilX = -0.3f)
    CelestialExpression.TEARFUL      -> CelestialRest.copy(browLeft = 0.9f, browRight = 0.9f, mouthSmile = -0.6f, mouthOpen = 0.2f, tears = 1f, pupilScale = 1.1f)
    CelestialExpression.AFRAID       -> CelestialRest.copy(lidLeft = 0f, lidRight = 0f, browLeft = 1f, browRight = 1f, mouthSmile = -0.5f, mouthOpen = 0.65f, pupilScale = 0.55f)
    CelestialExpression.SHOCKED      -> CelestialRest.copy(lidLeft = 0f, lidRight = 0f, browLeft = 1f, browRight = 1f, mouthOpen = 1f, mouthSmile = 0f, pupilScale = 0.5f)
    CelestialExpression.RELIEVED     -> CelestialRest.copy(lidLeft = 0.9f, lidRight = 0.9f, mouthSmile = 0.55f, mouthOpen = 0.2f, browLeft = 0.15f, browRight = 0.15f)
    CelestialExpression.YAWN        -> CelestialRest.copy(lidLeft = 0.72f, lidRight = 0.72f, mouthOpen = 1f, mouthSmile = 0f, pupilY = 0.3f)
    CelestialExpression.DOZING      -> CelestialRest.copy(lidLeft = 1f, lidRight = 1f, mouthSmile = 0.1f, mouthOpen = 0.07f)
    CelestialExpression.AWAKENING   -> CelestialRest.copy(lidLeft = 0.04f, lidRight = 0.18f, browLeft = 0.8f, browRight = 0.6f, mouthOpen = 0.48f, mouthSmile = 0.05f)
    CelestialExpression.TIRED       -> CelestialRest.copy(lidLeft = 0.62f, lidRight = 0.5f, mouthSmile = -0.16f, pupilY = 0.5f)
    CelestialExpression.BORED       -> CelestialRest.copy(lidLeft = 0.58f, lidRight = 0.58f, mouthSmile = -0.12f, pupilX = 0.55f)
    CelestialExpression.HOPEFUL     -> CelestialRest.copy(browLeft = 0.5f, browRight = 0.5f, pupilY = -0.4f, mouthSmile = 0.6f, pupilScale = 1.16f, cheekGlow = 0.35f)
    CelestialExpression.GRATEFUL    -> CelestialRest.copy(lidLeft = 0.6f, lidRight = 0.6f, mouthSmile = 0.8f, browLeft = 0.3f, browRight = 0.3f, cheekGlow = 0.6f)
}

internal fun blendCelestial(a: CelestialFaceSnapshot, b: CelestialFaceSnapshot, t: Float): CelestialFaceSnapshot {
    val f = t.coerceIn(0f, 1f)
    fun mix(x: Float, y: Float) = x + (y - x) * f
    return CelestialFaceSnapshot(
        lidLeft = mix(a.lidLeft, b.lidLeft), lidRight = mix(a.lidRight, b.lidRight),
        browLeft = mix(a.browLeft, b.browLeft), browRight = mix(a.browRight, b.browRight),
        pupilX = mix(a.pupilX, b.pupilX), pupilY = mix(a.pupilY, b.pupilY),
        mouthOpen = mix(a.mouthOpen, b.mouthOpen), mouthSmile = mix(a.mouthSmile, b.mouthSmile),
        headTilt = mix(a.headTilt, b.headTilt), squash = mix(a.squash, b.squash),
        cheekGlow = mix(a.cheekGlow, b.cheekGlow), tears = mix(a.tears, b.tears),
        pupilScale = mix(a.pupilScale, b.pupilScale)
    )
}

/** Single-owner keyframe sequencer with built-in idle loop. */
@Stable
class CelestialFaceState {
    private var pose by mutableStateOf(CelestialRest)
    internal var pinnedSnapshot by mutableStateOf<CelestialFaceSnapshot?>(null)
    private val lock = Mutex()
    private var idleJob: Job? = null
    fun snapshot(): CelestialFaceSnapshot = pinnedSnapshot ?: pose

    private suspend fun move(target: CelestialFaceSnapshot, durationMs: Int) {
        val from = pose
        Animatable(0f).animateTo(1f, tween(durationMs, easing = FastOutSlowInEasing)) {
            pose = blendCelestial(from, target, value)
        }
    }

    suspend fun play(expression: CelestialExpression) = perform(expression)

    suspend fun perform(
        expression: CelestialExpression,
        timeScale: Float = 1f,
        reduced: Boolean = false,
        background: Boolean = false
    ) {
        if (!background) { idleJob?.cancelAndJoin(); idleJob = null }
        lock.withLock {
            val target = celestialPose(expression)
            fun ms(v: Int) = (v * timeScale).toInt().coerceAtLeast(1)
            try {
                if (reduced) {
                    move(target.copy(headTilt = 0f, squash = 0f), 150)
                    delay(240); move(CelestialRest, 180); return@withLock
                }
                when (expression) {
                    CelestialExpression.NEUTRAL -> move(CelestialRest, ms(240))
                    CelestialExpression.BLINK, CelestialExpression.DOUBLE_BLINK -> {
                        repeat(if (expression == CelestialExpression.DOUBLE_BLINK) 2 else 1) {
                            move(target, ms(65)); delay(ms(30).toLong())
                            move(CelestialRest, ms(155)); delay(ms(85).toLong())
                        }
                    }
                    CelestialExpression.LOOK_AROUND -> {
                        move(target, ms(190)); delay(ms(290).toLong())
                        move(target.copy(pupilX = 0.7f, browLeft = 0f, browRight = 0.3f), ms(320))
                        delay(ms(260).toLong()); move(CelestialRest, ms(270))
                    }
                    CelestialExpression.LAUGH, CelestialExpression.GIGGLE -> {
                        move(target, ms(230))
                        repeat(3) {
                            move(target.copy(mouthOpen = target.mouthOpen * 0.4f), ms(100))
                            move(target, ms(145))
                        }
                        move(CelestialRest, ms(330))
                    }
                    CelestialExpression.YAWN, CelestialExpression.DOZING, CelestialExpression.SLEEPY -> {
                        move(target.copy(mouthOpen = 0.05f), ms(330))
                        move(target, ms(480)); delay(ms(450).toLong())
                        move(target.copy(lidLeft = 1f, lidRight = 1f, mouthOpen = 0.03f), ms(250))
                        move(CelestialRest, ms(450))
                    }
                    else -> {
                        val fast = expression in listOf(
                            CelestialExpression.SHOCKED, CelestialExpression.SURPRISE, CelestialExpression.AWAKENING
                        )
                        move(blendCelestial(CelestialRest, target, 0.28f), ms(if (fast) 60 else 140))
                        move(target, ms(if (fast) 100 else 250))
                        delay(ms(if (fast) 400 else 650).toLong())
                        val emphasis = when (expression) {
                            CelestialExpression.TEARFUL       -> target.copy(tears = 0.55f, lidLeft = 0.45f, lidRight = 0.45f)
                            CelestialExpression.SHY, CelestialExpression.EMBARRASSED -> target.copy(pupilY = 0.7f, lidLeft = 0.45f, lidRight = 0.45f)
                            CelestialExpression.ANGRY, CelestialExpression.FRUSTRATED -> target.copy(mouthOpen = 0f, lidLeft = 0.4f, lidRight = 0.4f)
                            CelestialExpression.CURIOUS, CelestialExpression.CONFUSED, CelestialExpression.THINKING -> target.copy(pupilX = -target.pupilX, pupilY = -0.4f)
                            else -> target.copy(lidLeft = (target.lidLeft + 0.12f).coerceAtMost(1f), mouthOpen = target.mouthOpen * 0.65f)
                        }
                        move(emphasis, ms(220)); delay(ms(160).toLong())
                        move(CelestialRest, ms(350))
                    }
                }
            } finally {
                pose = CelestialRest; pinnedSnapshot = null
            }
        }
    }

    internal suspend fun idle(expression: CelestialExpression) = coroutineScope {
        val task = launch { perform(expression, background = true) }
        idleJob = task
        try { task.join() } finally { if (idleJob === task) idleJob = null }
    }

    /** Finite speech performance: alternating phoneme shapes. */
    suspend fun speak(durationMs: Long, cadenceMs: Long, moon: Boolean, reduced: Boolean) {
        idleJob?.cancelAndJoin(); idleJob = null
        lock.withLock {
            try {
                val base = celestialPose(if (moon) CelestialExpression.CONTENT else CelestialExpression.DELIGHTED)
                move(base.copy(mouthOpen = 0f), if (reduced) 100 else 170)
                val end = System.nanoTime() + durationMs.coerceAtLeast(0L) * 1_000_000L
                var beat = 0
                while (System.nanoTime() < end) {
                    val remaining = ((end - System.nanoTime()) / 1_000_000L).coerceAtLeast(1L)
                    val step = minOf(cadenceMs / 2, remaining).toInt().coerceAtLeast(1)
                    val open = if (reduced) 0.10f else listOf(0.38f, 0.10f, 0.58f, 0.04f, 0.25f, 0.12f)[beat % 6]
                    move(base.copy(mouthOpen = open,
                        mouthSmile = if (beat % 4 == 0) 0.08f else base.mouthSmile,
                        lidLeft  = if (beat % 13 == 12) 0.9f else base.lidLeft,
                        lidRight = if (beat % 13 == 12) 0.9f else base.lidRight), step)
                    beat++
                }
                move(CelestialRest, 230)
            } finally { pose = CelestialRest; pinnedSnapshot = null }
        }
    }
}

@Composable
fun rememberCelestialFaceState(autoIdle: Boolean = true): CelestialFaceState {
    val state = remember { CelestialFaceState() }
    val animateIdle = LocalMotionLevel.current.allowsLoopingAnimation && autoIdle
    LaunchedEffect(state, animateIdle) {
        if (!animateIdle) return@LaunchedEffect
        val idle = listOf(
            CelestialExpression.BLINK, CelestialExpression.BLINK, CelestialExpression.DOUBLE_BLINK,
            CelestialExpression.CONTENT, CelestialExpression.CURIOUS, CelestialExpression.THINKING,
            CelestialExpression.LOOK_AROUND, CelestialExpression.PLAYFUL, CelestialExpression.WINK
        )
        while (isActive) { delay(Random.nextLong(2800L, 6800L)); state.idle(idle.random()) }
    }
    return state
}

/**
 * Routes to the correct drawing function based on [CelestialStyleStore.current].
 * All 5 designs share the same [face] animation data, so expressions and idles
 * work identically across style switches.
 */
fun DrawScope.drawCelestialBody(
    center: Offset, radius: Float, form: Float,
    face: CelestialFaceSnapshot, timeSec: Float, alpha: Float = 1f
) {
    when (CelestialStyleStore.current) {
        CelestialStyle.DREAMY  -> drawAnimeCelestial(center, radius, form, face, timeSec, alpha)
        CelestialStyle.CHIBI   -> drawChibi(center, radius, form, face, alpha)
        CelestialStyle.MINIMAL -> drawMinimal(center, radius, form, face, alpha)
        CelestialStyle.GLOWY   -> drawGlowy(center, radius, form, face, alpha)
        CelestialStyle.PIXEL   -> drawPixel(center, radius, form, face, alpha)
    }
}

/** Fixed centre; the legacy [hover] parameter is intentionally ignored. */
@Suppress("UNUSED_PARAMETER")
@Composable
fun CelestialBodyView(
    form: Float,
    modifier: Modifier = Modifier,
    face: CelestialFaceState = rememberCelestialFaceState(),
    hover: Boolean = false
) {
    // Re-read style so Canvas redraws whenever the user changes it
    val style = CelestialStyleStore.current
    Canvas(modifier) {
        drawCelestialBody(size.center, size.minDimension * CELESTIAL_BODY_RADIUS_FRACTION, form, face.snapshot(), 0f)
    }
}

internal fun previewSnapshotFor(expression: CelestialExpression) = celestialPose(expression)
