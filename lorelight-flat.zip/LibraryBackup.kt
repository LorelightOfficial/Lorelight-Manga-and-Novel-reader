package com.lorelight.data.backup

import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.lorelight.data.db.HistoryEntity
import com.lorelight.data.db.LorelightDatabase
import com.lorelight.data.db.NovelEntity
import com.lorelight.data.db.toEntity
import com.lorelight.data.db.toHistoryEntry
import com.lorelight.data.db.toNovel
import com.lorelight.data.model.HistoryEntry
import com.lorelight.data.model.Novel
import com.lorelight.data.model.toJSONObject
import com.lorelight.data.model.toNovel
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object LibraryBackup {

    const val FORMAT_VERSION = 1
    private const val DB_NAME = "lorelight.db"

    fun backupDir(context: Context): File =
        File(context.filesDir, "backups").apply { if (!exists()) mkdirs() }

    data class Payload(
        val formatVersion: Int,
        val createdAt: Long,
        val novels: List<Novel>,
        val history: List<HistoryEntry>
    )

    private fun writeEnvelope(context: Context, label: String, novels: List<Novel>, history: List<HistoryEntry>): File? {
        return try {
            val root = JSONObject()
            root.put("formatVersion", FORMAT_VERSION)
            val createdAt = System.currentTimeMillis()
            root.put("createdAt", createdAt)
            root.put("label", label)

            val novelsArr = JSONArray()
            novels.forEach { novelsArr.put(it.toJSONObject()) }
            root.put("novels", novelsArr)

            val historyArr = JSONArray()
            history.forEach { item ->
                val o = JSONObject()
                o.put("novelId", item.novelId)
                o.put("novelTitle", item.novelTitle)
                o.put("chapterId", item.chapterId)
                o.put("chapterTitle", item.chapterTitle)
                o.put("timestamp", item.timestamp)
                o.put("lastModified", item.lastModified)
                o.put("novelJson", item.novelJson)
                historyArr.put(o)
            }
            root.put("history", historyArr)

            val dateStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date(createdAt))
            val fileName = "backup_${label}_${dateStr}.json"

            val dir = backupDir(context)
            val tmpFile = File(dir, "$fileName.tmp")
            tmpFile.writeText(root.toString())

            val targetFile = File(dir, fileName)
            if (targetFile.exists()) targetFile.delete()
            if (tmpFile.renameTo(targetFile)) {
                targetFile
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    fun exportFromDaoBlocking(context: Context, label: String): File? {
        return try {
            val db = LorelightDatabase.get(context)
            val novelEntities = db.novelDao().getAll()
            val historyEntities = db.historyDao().getAll()

            val novels = novelEntities.map { it.toNovel() }
            val history = historyEntities.map { it.toHistoryEntry() }

            if (novels.isEmpty() && history.isEmpty()) {
                null
            } else {
                writeEnvelope(context, label, novels, history)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun Cursor.getStringOr(colName: String, default: String): String {
        val idx = getColumnIndex(colName)
        if (idx == -1 || isNull(idx)) return default
        return getString(idx) ?: default
    }

    private fun Cursor.getNullableString(colName: String): String? {
        val idx = getColumnIndex(colName)
        if (idx == -1 || isNull(idx)) return null
        return getString(idx)
    }

    private fun Cursor.getIntOr(colName: String, default: Int): Int {
        val idx = getColumnIndex(colName)
        if (idx == -1 || isNull(idx)) return default
        return getInt(idx)
    }

    private fun Cursor.getLongOr(colName: String, default: Long): Long {
        val idx = getColumnIndex(colName)
        if (idx == -1 || isNull(idx)) return default
        return getLong(idx)
    }

    private fun Cursor.getBooleanOr(colName: String, default: Boolean): Boolean {
        val idx = getColumnIndex(colName)
        if (idx == -1 || isNull(idx)) return default
        return getInt(idx) != 0
    }

    fun exportRawBlocking(context: Context, label: String): File? {
        val dbFile = context.getDatabasePath(DB_NAME)
        if (!dbFile.exists()) return null

        val novels = mutableListOf<Novel>()
        val history = mutableListOf<HistoryEntry>()

        var db: SQLiteDatabase? = null
        try {
            db = SQLiteDatabase.openDatabase(dbFile.absolutePath, null, SQLiteDatabase.OPEN_READONLY)

            try {
                val cursor = db.rawQuery("SELECT * FROM novels", null)
                cursor.use { c ->
                    while (c.moveToNext()) {
                        val entity = NovelEntity(
                            id = c.getStringOr("id", ""),
                            title = c.getStringOr("title", ""),
                            currentChapter = c.getStringOr("currentChapter", ""),
                            lastReadTimestamp = c.getLongOr("lastReadTimestamp", 0L),
                            author = c.getStringOr("author", ""),
                            status = c.getStringOr("status", ""),
                            totalChapters = c.getIntOr("totalChapters", 0),
                            language = c.getStringOr("language", ""),
                            genresJson = c.getStringOr("genresJson", ""),
                            description = c.getStringOr("description", ""),
                            chaptersJson = c.getStringOr("chaptersJson", ""),
                            coverImageBase64 = c.getNullableString("coverImageBase64"),
                            isOnline = c.getBooleanOr("isOnline", false),
                            sourceUrl = c.getNullableString("sourceUrl"),
                            chapterUrlsJson = c.getStringOr("chapterUrlsJson", ""),
                            currentParagraphIndex = c.getIntOr("currentParagraphIndex", 0),
                            completedChaptersJson = c.getStringOr("completedChaptersJson", ""),
                            currentScrollOffset = c.getIntOr("currentScrollOffset", 0),
                            currentWordIndex = c.getIntOr("currentWordIndex", 0),
                            isFavorite = c.getBooleanOr("isFavorite", false),
                            categoriesJson = c.getStringOr("categoriesJson", ""),
                            readingStatus = c.getStringOr("readingStatus", ""),
                            dateAdded = c.getLongOr("dateAdded", 0L),
                            dateModified = c.getLongOr("dateModified", 0L),
                            lastCheckedTimestamp = c.getLongOr("lastCheckedTimestamp", 0L),
                            pluginId = c.getNullableString("pluginId"),
                            pluginNovelPath = c.getNullableString("pluginNovelPath"),
                            // RESUME REDESIGN. Carry the index through a restore.
                            // Without this a restored library would fall back to
                            // the chapter NAME lookup and the old wrong-chapter
                            // behaviour would come straight back. Backups taken
                            // before this column existed simply return -1.
                            currentChapterIndex = c.getIntOr("currentChapterIndex", -1)
                        )
                        novels.add(entity.toNovel())
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            try {
                val cursor = db.rawQuery("SELECT * FROM history", null)
                cursor.use { c ->
                    while (c.moveToNext()) {
                        val entity = HistoryEntity(
                            novelId = c.getStringOr("novelId", ""),
                            novelTitle = c.getStringOr("novelTitle", ""),
                            chapterId = c.getStringOr("chapterId", ""),
                            chapterTitle = c.getStringOr("chapterTitle", ""),
                            timestamp = c.getLongOr("timestamp", 0L),
                            lastModified = c.getLongOr("lastModified", 0L),
                            novelJson = c.getStringOr("novelJson", ""),
                            chapterIndex = c.getIntOr("chapterIndex", -1)
                        )
                        history.add(entity.toHistoryEntry())
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } catch (e: Exception) {
            return null
        } finally {
            try {
                db?.close()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        if (novels.isEmpty() && history.isEmpty()) {
            return null
        }

        return writeEnvelope(context, label, novels, history)
    }

    fun listBackups(context: Context): List<File> {
        return try {
            val dir = backupDir(context)
            val files = dir.listFiles()?.filter { it.isFile && it.name.endsWith(".json") } ?: emptyList()
            files.sortedByDescending { it.name }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun readBackup(file: File): Payload? {
        return try {
            if (!file.exists()) return null
            val content = file.readText()
            val root = JSONObject(content)

            val formatVersion = root.optInt("formatVersion", FORMAT_VERSION)
            val createdAt = root.optLong("createdAt", System.currentTimeMillis())

            val novelsList = mutableListOf<Novel>()
            val novelsArr = root.optJSONArray("novels")
            if (novelsArr != null) {
                for (i in 0 until novelsArr.length()) {
                    try {
                        val obj = novelsArr.getJSONObject(i)
                        novelsList.add(obj.toNovel())
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }

            val historyList = mutableListOf<HistoryEntry>()
            val historyArr = root.optJSONArray("history")
            if (historyArr != null) {
                for (i in 0 until historyArr.length()) {
                    try {
                        val o = historyArr.getJSONObject(i)
                        historyList.add(
                            HistoryEntry(
                                novelId = o.optString("novelId"),
                                novelTitle = o.optString("novelTitle"),
                                chapterId = o.optString("chapterId"),
                                chapterTitle = o.optString("chapterTitle"),
                                timestamp = o.optLong("timestamp", System.currentTimeMillis()),
                                lastModified = o.optLong("lastModified", System.currentTimeMillis()),
                                novelJson = o.optString("novelJson")
                            )
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }

            Payload(
                formatVersion = formatVersion,
                createdAt = createdAt,
                novels = novelsList,
                history = historyList
            )
        } catch (e: Exception) {
            null
        }
    }

    fun restoreBlocking(context: Context, file: File): Boolean {
        return try {
            val payload = readBackup(file) ?: return false
            var novelSuccess = false

            if (payload.novels.isNotEmpty()) {
                val db = LorelightDatabase.get(context)
                db.novelDao().replaceAll(payload.novels.map { it.toEntity() })
                novelSuccess = true
            }

            if (payload.history.isNotEmpty()) {
                val db = LorelightDatabase.get(context)
                db.historyDao().replaceAll(payload.history.map { it.toEntity() })
            }

            novelSuccess
        } catch (e: Exception) {
            false
        }
    }

    fun pruneOldBackups(context: Context, keep: Int = 8) {
        try {
            val files = listBackups(context)
            if (files.size > keep) {
                val toDelete = files.drop(keep)
                toDelete.forEach { it.delete() }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
