package com.lorelight.ui.theme

import android.content.Context
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.TweenSpec
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import com.lorelight.data.local.AppPrefs
import com.lorelight.data.local.AppSettingsSignal

/**
 * The one place that decides how much the app is allowed to move.
 *
 * Lorelight animates a lot - hero art, glass, the celestial companion and its
 * props, gradient highlights, full-screen theme switches, fireflies. That is
 * part of its character, but there was no single switch for people who get
 * motion sick, for older devices, or for a phone on 4% battery. Individual
 * call sites each invented their own timing, so "turn the animations down"
 * was not expressible anywhere.
 *
 * Every animated surface should now ask this policy instead of hardcoding a
 * duration or a spring. Read it with [LocalMotionLevel] (or
 * [rememberMotionLevel] outside the provided tree) and build specs with
 * [motionTween] / [motionSpring].
 */
enum class MotionLevel {
    /** Everything, as designed. */
    FULL,

    /** Cross-fades instead of slides, no loops, shorter durations. */
    REDUCED,

    /** Effectively still: no ambient effects, no blur, instant state changes. */
    BATTERY_SAVER;

    /** False means "change state instantly". */
    val animatesTransitions: Boolean get() = this != BATTERY_SAVER

    /** Slides, scales and parallax. Reduced keeps opacity changes only. */
    val usesSpatialTransitions: Boolean get() = this == FULL

    /** Shimmer, fireflies, breathing glows, anything that never ends. */
    val allowsLoopingAnimation: Boolean get() = this == FULL

    /** Decorative background effects that carry no information. */
    val allowsAmbientEffects: Boolean get() = this == FULL

    /** Real blur is expensive on mid-range GPUs; fall back to a tint. */
    val allowsHeavyBlur: Boolean get() = this == FULL

    /** The companion may still blink and glance when motion is only reduced. */
    val allowsCompanionMotion: Boolean get() = this != BATTERY_SAVER

    /** Props are pure decoration, so they are the first thing to go. */
    val allowsCompanionProps: Boolean get() = this == FULL

    /** Full-screen theme-switch choreography. Reduced turns it into a fade. */
    val allowsThemeSwitchAnimation: Boolean get() = this == FULL

    /** List and grid entrance staggers. */
    val allowsEntranceStagger: Boolean get() = this == FULL

    /**
     * Scales a designed duration to this level. Battery saver returns 0, which
     * Compose treats as "snap", so no call site needs a special case.
     */
    fun duration(millis: Int): Int = when (this) {
        FULL -> millis
        REDUCED -> (millis * 0.55f).toInt().coerceAtLeast(90)
        BATTERY_SAVER -> 0
    }

    /** Stored preference value for this level. */
    val prefValue: String
        get() = when (this) {
            FULL -> MOTION_PREF_FULL
            REDUCED -> MOTION_PREF_REDUCED
            BATTERY_SAVER -> MOTION_PREF_SAVER
        }

    /** Label used by the Appearance setting. */
    val label: String
        get() = when (this) {
            FULL -> "Full"
            REDUCED -> "Reduced"
            BATTERY_SAVER -> "Battery saver"
        }
}

/** Preference key in [AppPrefs]. */
const val MOTION_LEVEL_KEY = "motion_level"

const val MOTION_PREF_AUTO = "auto"
const val MOTION_PREF_FULL = "full"
const val MOTION_PREF_REDUCED = "reduced"
const val MOTION_PREF_SAVER = "saver"

/** Labels for the four choices the user actually sees, in display order. */
val motionPreferenceLabels = listOf("Auto", "Full", "Reduced", "Battery saver")

fun motionPreferenceLabelToValue(label: String): String = when (label) {
    "Full" -> MOTION_PREF_FULL
    "Reduced" -> MOTION_PREF_REDUCED
    "Battery saver" -> MOTION_PREF_SAVER
    else -> MOTION_PREF_AUTO
}

fun motionPreferenceValueToLabel(value: String): String = when (value) {
    MOTION_PREF_FULL -> "Full"
    MOTION_PREF_REDUCED -> "Reduced"
    MOTION_PREF_SAVER -> "Battery saver"
    else -> "Auto"
}

/**
 * Provided once, high in the tree, by MainActivity. Defaults to FULL so a
 * composable used outside the provider (previews, tests) still behaves.
 */
val LocalMotionLevel = compositionLocalOf { MotionLevel.FULL }

/** The raw stored choice, including "auto". */
fun readMotionPreference(context: Context): String =
    try {
        AppPrefs.get(context).getString(MOTION_LEVEL_KEY, MOTION_PREF_AUTO) ?: MOTION_PREF_AUTO
    } catch (e: Exception) {
        MOTION_PREF_AUTO
    }

fun writeMotionPreference(context: Context, value: String) {
    try {
        AppPrefs.get(context).edit().putString(MOTION_LEVEL_KEY, value).apply()
        AppSettingsSignal.notifyChanged()
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

/**
 * Resolves the effective level.
 *
 * An explicit choice always wins. "Auto" respects the platform, in this order:
 *  1. battery saver is on            -> BATTERY_SAVER
 *  2. animator duration scale is off -> REDUCED  (the accessibility
 *     "remove animations" switch and Developer options both land here)
 *  3. otherwise                      -> FULL
 */
fun resolveMotionLevel(context: Context): MotionLevel {
    when (readMotionPreference(context)) {
        MOTION_PREF_FULL -> return MotionLevel.FULL
        MOTION_PREF_REDUCED -> return MotionLevel.REDUCED
        MOTION_PREF_SAVER -> return MotionLevel.BATTERY_SAVER
    }

    val powerSaving = try {
        (context.getSystemService(Context.POWER_SERVICE) as? PowerManager)?.isPowerSaveMode == true
    } catch (e: Exception) {
        false
    }
    if (powerSaving) return MotionLevel.BATTERY_SAVER

    val animatorScale = try {
        Settings.Global.getFloat(
            context.contentResolver,
            Settings.Global.ANIMATOR_DURATION_SCALE,
            1f
        )
    } catch (e: Exception) {
        1f
    }
    if (animatorScale == 0f) return MotionLevel.REDUCED

    return MotionLevel.FULL
}

/**
 * Reads the effective level and re-reads it whenever any setting changes, so
 * flipping the control in Appearance takes effect immediately.
 */
@Composable
fun rememberMotionLevel(): MotionLevel {
    val context = LocalContext.current
    val settingsVersion by AppSettingsSignal.version.collectAsState()
    return remember(context, settingsVersion) { resolveMotionLevel(context) }
}

/* ───────────────────────────── Spec builders ─────────────────────────── */

fun <T> MotionLevel.tweenSpec(
    durationMillis: Int = 300,
    delayMillis: Int = 0,
    easing: Easing = FastOutSlowInEasing
): TweenSpec<T> = tween(
    durationMillis = duration(durationMillis),
    delayMillis = if (this == MotionLevel.BATTERY_SAVER) 0 else delayMillis,
    easing = easing
)

fun <T> MotionLevel.springSpec(
    dampingRatio: Float = Spring.DampingRatioNoBouncy,
    stiffness: Float = Spring.StiffnessMedium
): FiniteAnimationSpec<T> = when (this) {
    // Snap, without every call site having to know it should snap.
    MotionLevel.BATTERY_SAVER -> tween(durationMillis = 0)
    // Bounce reads as playful at FULL and as nausea at REDUCED, so reduced
    // keeps the spring but removes the overshoot.
    MotionLevel.REDUCED -> spring(dampingRatio = 1f, stiffness = stiffness)
    MotionLevel.FULL -> spring(dampingRatio = dampingRatio, stiffness = stiffness)
}

/** Motion-aware [tween] for use inside composition. */
@Composable
fun <T> motionTween(
    durationMillis: Int = 300,
    delayMillis: Int = 0,
    easing: Easing = FastOutSlowInEasing
): TweenSpec<T> = LocalMotionLevel.current.tweenSpec(durationMillis, delayMillis, easing)

/** Motion-aware [spring] for use inside composition. */
@Composable
fun <T> motionSpring(
    dampingRatio: Float = Spring.DampingRatioNoBouncy,
    stiffness: Float = Spring.StiffnessMedium
): FiniteAnimationSpec<T> = LocalMotionLevel.current.springSpec(dampingRatio, stiffness)
