package eu.kanade.tachiyomi.util.system

import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.core.graphics.drawable.toBitmap

/**
 * Returns a [Bitmap] for this [Drawable], or null when it cannot be rasterized
 * (e.g. it has no intrinsic size). Mirrors the small helper the notification
 * code relies on after loading a cover through the image loader.
 */
fun Drawable.getBitmapOrNull(): Bitmap? {
    return when {
        this is BitmapDrawable -> bitmap
        intrinsicWidth <= 0 || intrinsicHeight <= 0 -> null
        else -> toBitmap()
    }
}
