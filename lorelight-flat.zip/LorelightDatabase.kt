package com.lorelight.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * v1 -> v2: adds an index on history.timestamp (FIX #28).
 *
 * The index name MUST be exactly `index_history_timestamp`. That is what Room
 * generates for @Index(value = ["timestamp"]) on the `history` table, and Room
 * validates the name on open. A mismatch triggers the destructive fallback in
 * buildSafely() and wipes user data.
 */
val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_history_timestamp` ON `history` (`timestamp`)")
    }
}

/**
 * v2 -> v3: adds the `chapters` and `reading_progress` tables.
 *
 * PURELY ADDITIVE. No existing table or column is touched, so this migration
 * cannot lose data. Nothing reads these tables yet; a later phase backfills
 * and switches the read/write paths over.
 *
 * The index name MUST be exactly `index_chapters_novelId`. That is what Room
 * generates for @Index(value = ["novelId"]) on the `chapters` table, and Room
 * validates the name on open. A mismatch triggers the destructive fallback.
 */
val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `chapters` (" +
                "`novelId` TEXT NOT NULL, " +
                "`idx` INTEGER NOT NULL, " +
                "`title` TEXT NOT NULL, " +
                "`url` TEXT NOT NULL, " +
                "`completed` INTEGER NOT NULL, " +
                "PRIMARY KEY(`novelId`, `idx`))"
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_chapters_novelId` ON `chapters` (`novelId`)")
        db.execSQL(
            "CREATE TABLE IF NOT EXISTS `reading_progress` (" +
                "`novelId` TEXT NOT NULL, " +
                "`currentChapter` TEXT NOT NULL, " +
                "`currentParagraphIndex` INTEGER NOT NULL, " +
                "`currentScrollOffset` INTEGER NOT NULL, " +
                "`currentWordIndex` INTEGER NOT NULL, " +
                "`lastReadTimestamp` INTEGER NOT NULL, " +
                "`updatedAt` INTEGER NOT NULL, " +
                "PRIMARY KEY(`novelId`))"
        )
    }
}

/**
 * v3 -> v4: adds the per-chapter read-state columns to `chapters`.
 *
 * PURELY ADDITIVE. Three ALTER TABLE ADD COLUMN statements, no table rebuild,
 * so no existing row or column is touched and the migration cannot lose data.
 *
 * The DEFAULT clauses MUST match the @ColumnInfo(defaultValue = ...) values on
 * ChapterEntity. Room compares them on open; a mismatch triggers the
 * destructive fallback in buildSafely() and wipes user data.
 *
 * ALTER TABLE ADD COLUMN is not idempotent in SQLite (there is no IF NOT
 * EXISTS), so each statement is guarded individually: a migration that was
 * interrupted half-way can be re-run safely.
 */
val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        val existing = mutableSetOf<String>()
        db.query("PRAGMA table_info(`chapters`)").use { c ->
            val nameCol = c.getColumnIndex("name")
            while (c.moveToNext()) {
                if (nameCol >= 0) existing.add(c.getString(nameCol))
            }
        }
        if ("lastPageRead" !in existing) {
            db.execSQL("ALTER TABLE `chapters` ADD COLUMN `lastPageRead` INTEGER NOT NULL DEFAULT 0")
        }
        if ("bookmark" !in existing) {
            db.execSQL("ALTER TABLE `chapters` ADD COLUMN `bookmark` INTEGER NOT NULL DEFAULT 0")
        }
        if ("lastReadAt" !in existing) {
            db.execSQL("ALTER TABLE `chapters` ADD COLUMN `lastReadAt` INTEGER NOT NULL DEFAULT 0")
        }
    }
}

// RESUME REDESIGN. novels.currentChapterIndex and history.chapterIndex replace
// the old name-based resume. Both default to -1, which every reader treats as
// "nothing recorded", so existing rows keep working exactly as before until the
// next page turn stamps a real index. Nothing is dropped or rewritten.
private fun addIntColumnIfMissing(
    db: SupportSQLiteDatabase,
    table: String,
    column: String,
    default: Int
) {
    val existing = mutableSetOf<String>()
    db.query("PRAGMA table_info(`" + table + "`)").use { c ->
        val nameCol = c.getColumnIndex("name")
        while (c.moveToNext()) {
            if (nameCol >= 0) existing.add(c.getString(nameCol))
        }
    }
    if (column !in existing) {
        db.execSQL(
            "ALTER TABLE `" + table + "` ADD COLUMN `" + column +
                "` INTEGER NOT NULL DEFAULT " + default
        )
    }
}

val MIGRATION_4_5 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        addIntColumnIfMissing(db, "novels", "currentChapterIndex", -1)
        addIntColumnIfMissing(db, "history", "chapterIndex", -1)
        addIntColumnIfMissing(db, "reading_progress", "currentChapterIndex", -1)
    }
}

const val LORELIGHT_DB_VERSION = 5

@Database(
    entities = [
        NovelEntity::class,
        HistoryEntity::class,
        ChapterEntity::class,
        ReadingProgressEntity::class
    ],
    version = LORELIGHT_DB_VERSION,
    exportSchema = false
)
abstract class LorelightDatabase : RoomDatabase() {
    abstract fun novelDao(): NovelDao
    abstract fun historyDao(): HistoryDao
    abstract fun chapterDao(): ChapterDao
    abstract fun readingProgressDao(): ReadingProgressDao

    companion object {
        @Volatile
        var lastOpenFailed: Boolean = false
            private set

        // True if the app had to throw the database away and start over.
        // A later phase surfaces this to the user with a restore option.
        @Volatile
        var didDestructiveRebuild: Boolean = false
            private set

        fun get(context: Context): LorelightDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildSafely(context.applicationContext).also { INSTANCE = it }
            }
        }

        @Volatile
        private var INSTANCE: LorelightDatabase? = null

        private fun openStrict(app: Context): LorelightDatabase {
            val db = Room.databaseBuilder(app, LorelightDatabase::class.java, "lorelight.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
                .allowMainThreadQueries()
                .build()
            // Force the file open NOW so a downgrade/corruption fails here
            // instead of half-way through a write.
            db.openHelper.readableDatabase
            return db
        }

        private fun buildSafely(app: Context): LorelightDatabase {
            // Always take a pre-migration copy before Room can touch the file.
            preMigrationBackup(app)

            // Attempt 1: strict. No destructive fallback.
            try {
                val db = openStrict(app)
                lastOpenFailed = false
                return db
            } catch (t: Throwable) {
                android.util.Log.e("LorelightDatabase", "Strict open failed (attempt 1).", t)
            }

            // Attempt 2: rescue the raw files, then try strict again. This
            // recovers transient failures such as a locked file or a WAL that
            // needed replaying after the process was killed mid-write.
            rescueDatabaseFiles(app)
            try {
                val db = openStrict(app)
                lastOpenFailed = false
                android.util.Log.w("LorelightDatabase", "Strict open succeeded on attempt 2.")
                return db
            } catch (t: Throwable) {
                android.util.Log.e("LorelightDatabase", "Strict open failed (attempt 2).", t)
            }

            // Last resort. Salvage everything possible to a portable backup
            // BEFORE allowing Room to discard the file.
            lastOpenFailed = true
            didDestructiveRebuild = true
            try {
                val saved = com.lorelight.data.backup.LibraryBackup
                    .exportRawBlocking(app, "before_destructive_rebuild")
                android.util.Log.e("LorelightDatabase", "DESTRUCTIVE REBUILD. Salvage backup: ${saved?.absolutePath ?: "FAILED"}")
            } catch (e: Exception) { e.printStackTrace() }

            return Room.databaseBuilder(app, LorelightDatabase::class.java, "lorelight.db")
                .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5)
                .allowMainThreadQueries()
                .fallbackToDestructiveMigration()
                .build()
        }

        // Copies the database aside when the on-disk schema is older than the
        // code's schema, i.e. immediately before Room runs a migration.
        private fun preMigrationBackup(app: Context) {
            try {
                val dbFile = app.getDatabasePath("lorelight.db")
                if (!dbFile.exists()) return

                val onDisk: Int = try {
                    val raw = android.database.sqlite.SQLiteDatabase.openDatabase(
                        dbFile.absolutePath, null,
                        android.database.sqlite.SQLiteDatabase.OPEN_READONLY
                    )
                    val v = raw.version
                    raw.close()
                    v
                } catch (e: Exception) {
                    return // unreadable; the buildSafely rescue path handles it
                }

                if (onDisk <= 0 || onDisk >= LORELIGHT_DB_VERSION) return

                android.util.Log.w("LorelightDatabase", "Migration pending ($onDisk -> $LORELIGHT_DB_VERSION); backing up first.")

                val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US)
                    .format(java.util.Date())
                val dir = java.io.File(app.filesDir, "db_premigration").apply { if (!exists()) mkdirs() }
                listOf("lorelight.db", "lorelight.db-wal", "lorelight.db-shm").forEach { name ->
                    val src = java.io.File(dbFile.parentFile, name)
                    if (src.exists()) src.copyTo(java.io.File(dir, "v${onDisk}_${stamp}_$name"), overwrite = true)
                }

                // Portable copy too, so a rescue is possible even off-device.
                com.lorelight.data.backup.LibraryBackup.exportRawBlocking(app, "premigration_v$onDisk")
                com.lorelight.data.backup.LibraryBackup.pruneOldBackups(app)
            } catch (e: Exception) { e.printStackTrace() }
        }

        // Copies the raw .db/.db-wal/.db-shm files aside so data is never
        // truly gone, even if Room has to rebuild. Keeps the 3 newest sets.
        private fun rescueDatabaseFiles(app: Context) {
            try {
                val stamp = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US)
                    .format(java.util.Date())
                val dir = java.io.File(app.filesDir, "db_rescue").apply { if (!exists()) mkdirs() }
                listOf("lorelight.db", "lorelight.db-wal", "lorelight.db-shm").forEach { name ->
                    val src = java.io.File(app.getDatabasePath("lorelight.db").parentFile, name)
                    if (src.exists()) src.copyTo(java.io.File(dir, "${stamp}_$name"), overwrite = true)
                }
                dir.listFiles()
                    ?.filter { it.name.endsWith("lorelight.db") }
                    ?.sortedByDescending { it.name }
                    ?.drop(3)
                    ?.forEach { old ->
                        val prefix = old.name.removeSuffix("lorelight.db")
                        dir.listFiles()?.filter { it.name.startsWith(prefix) }?.forEach { it.delete() }
                    }
            } catch (e: Exception) { e.printStackTrace() }
        }
    }
}
