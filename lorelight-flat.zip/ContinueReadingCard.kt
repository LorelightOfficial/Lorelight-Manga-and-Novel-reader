package com.lorelight.ui.library

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.sp
import com.lorelight.data.chapters.ChapterReadStore
import com.lorelight.data.model.Novel
import com.lorelight.ui.components.LibraryCoverImage
import com.lorelight.ui.theme.getThemedButtonProps

/**
 * CONTINUE READING CARD - REBUILT.
 *
 * Same card, same buttons, new insides. Nothing here is carried over from the
 * old implementation; it was rewritten against the chapter-state store instead.
 *
 * WHAT WAS WRONG WITH THE OLD ONE
 * -------------------------------
 * It answered "where was I" by asking two different things and hoping. It ran a
 * coroutine on every recomposition key change to read a high-water mark out of
 * the chapters table - a query that breaks ties by "highest read index", so
 * after an autoscroll session it reported the FURTHEST chapter ever reached
 * rather than the one being read. When that failed it fell back to looking up a
 * mutable chapter NAME with indexOf, which lands on the wrong chapter when a
 * source re-titles its list and misses entirely when a new chapter shifts it -
 * at which point the card cheerfully printed chapter 1.
 *
 * WHAT IT DOES NOW
 * ----------------
 *  - Position comes from ChapterReadStore, which stamps the chapter you OPEN,
 *    keyed by that chapter's URL. It is a position, not a maximum, so it cannot
 *    run ahead of you, and it cannot slide when new chapters land at the top.
 *  - It is collected as a StateFlow, so the card redraws the moment a page turn
 *    is recorded. No coroutine, no disk read, no snapshot that goes stale while
 *    the card is on screen.
 *  - No chapter-name lookup anywhere. If nothing has been recorded, the card
 *    uses the index the novel row carries and otherwise stays honest.
 *  - Because the store also knows the page inside the chapter, the card now
 *    shows the resume page for long manga chapters.
 *
 * The look is unchanged on purpose: flat surface, hairline border, 16dp radius.
 * No glass, no glare, no corner brackets - those were removed by request and are
 * not coming back through a rewrite.
 */
@Composable
fun ContinueReadingCard(
    novel: Novel?,
    onReadClick: () -> Unit = {},
    onPlayTtsClick: () -> Unit = {},
    isManga: Boolean = false,
    showPlayButton: Boolean = true
) {
    val cardShape = RoundedCornerShape(16.dp)
    val clickModifier = if (novel != null) {
        // S9: role = Role.Button so TalkBack announces this card as a button.
        Modifier.clickable(role = Role.Button, onClickLabel = "Continue reading ${novel.title}") { onReadClick() }
    } else {
        Modifier
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(cardShape)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.30f), cardShape)
            .then(clickModifier)
    ) {
        if (novel == null) {
            EmptyResumeState()
        } else {
            ResumeContent(
                novel = novel,
                isManga = isManga,
                showPlayButton = showPlayButton,
                onReadClick = onReadClick,
                onPlayTtsClick = onPlayTtsClick
            )
        }
    }
}

@Composable
private fun EmptyResumeState() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp, horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Filled.MenuBook,
            contentDescription = "No Novel Active",
            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
            modifier = Modifier.size(30.dp)
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "No Novel Active",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun ResumeContent(
    novel: Novel,
    isManga: Boolean,
    showPlayButton: Boolean,
    onReadClick: () -> Unit,
    onPlayTtsClick: () -> Unit
) {
    val resume = rememberResumePosition(novel)
    val animatedFraction by animateFloatAsState(
        targetValue = resume.fraction,
        label = "continueProgress"
    )
    val (_, gradientBrush, onGradientText) = getThemedButtonProps(
        primary = MaterialTheme.colorScheme.primary,
        fallbackContent = MaterialTheme.colorScheme.onPrimary
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp, horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(width = 44.dp, height = 62.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.outline),
            contentAlignment = Alignment.Center
        ) {
            LibraryCoverImage(novel = novel, modifier = Modifier.fillMaxSize())
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = novel.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = resume.chapterLabel,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                // The store knows the page inside the chapter, so on a 200-page
                // manhua chapter the card can say where the tap will land.
                if (resume.pageIndex > 0) {
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "p${resume.pageIndex + 1}",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                        maxLines = 1
                    )
                }
            }

            if (resume.fraction > 0f) {
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { animatedFraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatLastReadTime(novel.lastReadTimestamp),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (showPlayButton && !isManga) {
                        ResumePillButton(
                            label = "Play",
                            icon = Icons.Filled.PlayArrow,
                            contentDescription = "Play ${novel.title} with text to speech",
                            brush = gradientBrush,
                            contentColor = onGradientText,
                            iconSize = 14.dp,
                            horizontalPadding = 10.dp,
                            onClick = onPlayTtsClick
                        )
                    }
                    ResumePillButton(
                        label = "Continue",
                        icon = if (isManga) Icons.Filled.Collections else Icons.Filled.MenuBook,
                        contentDescription = "Continue reading ${novel.title}",
                        brush = gradientBrush,
                        contentColor = onGradientText,
                        iconSize = 13.dp,
                        horizontalPadding = 12.dp,
                        onClick = onReadClick
                    )
                }
            }
        }
    }
}

@Composable
private fun ResumePillButton(
    label: String,
    icon: ImageVector,
    contentDescription: String,
    brush: Brush,
    contentColor: Color,
    iconSize: androidx.compose.ui.unit.Dp,
    horizontalPadding: androidx.compose.ui.unit.Dp,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .heightIn(min = 28.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(brush)
            // S9: role = Role.Button to match the icon-button semantics.
            .clickable(role = Role.Button, onClickLabel = contentDescription) { onClick() }
            .padding(horizontal = horizontalPadding),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = contentColor,
                modifier = Modifier.size(iconSize)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                color = contentColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

/** Everything the card needs to describe the resume point, resolved once. */
private data class ResumePosition(
    val chapterIndex: Int,
    val chapterLabel: String,
    val pageIndex: Int,
    val fraction: Float
)

/**
 * Resolves the resume point live.
 *
 * AUTHORITY ORDER, and the reasoning behind it:
 *  1. ChapterReadStore's stamped current chapter. It is written when a chapter is
 *     opened and keyed by that chapter's URL, so it is a genuine position that
 *     survives the list being reordered.
 *  2. novel.currentChapterIndex, for anything read before the store existed.
 *  3. Nothing. Not a name lookup - that is the bug, not the fallback.
 */
@Composable
private fun rememberResumePosition(novel: Novel): ResumePosition {
    val context = LocalContext.current
    val stateFlow = remember(novel.id) { ChapterReadStore.observe(context, novel.id) }
    val snapshot by stateFlow.collectAsState()

    return remember(snapshot, novel) {
        val storedIndex = ChapterReadStore.currentIndex(novel, snapshot)
        val index = when {
            storedIndex in novel.chapters.indices -> storedIndex
            novel.currentChapterIndex in novel.chapters.indices -> novel.currentChapterIndex
            else -> -1
        }

        val total = if (novel.chapters.isNotEmpty()) novel.chapters.size else novel.totalChapters
        val key = if (index >= 0) ChapterReadStore.keyFor(novel, index) else ""

        ResumePosition(
            chapterIndex = index,
            // The name is only ever DISPLAYED, never used to find anything.
            chapterLabel = novel.chapters.getOrNull(index)
                ?: novel.currentChapter.ifBlank { "Not started" },
            pageIndex = if (key.isEmpty()) 0 else snapshot.pageOf(key),
            fraction = if (index >= 0 && total > 0) {
                ((index + 1).toFloat() / total.toFloat()).coerceIn(0f, 1f)
            } else {
                0f
            }
        )
    }
}
