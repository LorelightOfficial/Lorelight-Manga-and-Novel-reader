# Celestial replacement — new artwork and expression engine

This source revision builds on the library-layout update. It replaces the old celestial face artwork, expression sequencer, companion gesture poses, and speech choreography. Existing public event identifiers are retained only to keep the app connected to the new implementation; the old rendering and pose functions are removed.

## Requested behaviour

- Dark mode: the sun sits in the bowl. Light mode: the moon sits in the bowl.
- At rest, the character stays in a fixed seat. There is no hover, vertical bob, floating shadow, body-breathing loop, or rotating idle corona.
- Celestial Arc: the current body slides upward out of the bowl, hands off to the flight effect at the slide endpoint, performs the screen animation, then the opposite body appears in the seat.
- Other theme-switch effects: the current body fades away and the opposite body fades in, without the celestial departure slide or a rising-body animation.
- The user's existing reduced-motion/battery-saver policy remains. Full-screen effects can still be bypassed by that policy.
- Tap and long-press continue to switch mode and open the command palette respectively.

## Bowl and proportions

The new bowl is code-drawn, top-down stone, not an image. Its drawing box is 96 x 72 dp beside 64 dp-tall panels; the reserved centre navigation gap remains 88 dp. The actual stone circle is about 71 dp tall, with short connectors reaching the panel edges. The character canvas is 64 dp and its body diameter is about 49 dp, substantially filling the opening. Compact sun-ray petals stay attached to the body rather than making the character look tiny inside a large halo.

Rim bevels, inner-wall shading, a recessed seat, grain, cracks, highlights, and a fixed cast shadow supply depth. Materials have different details rather than simply different tints:

- Forest: moss rooted in cracks and small leaves.
- Blood Red: charcoal stone with dried dark-red stains and droplets in the rim.
- Gold: dark stone with gold repair veins.
- Satin Pink: weathered rose stone with petal details.
- Black: fractured obsidian with sharp pale facets.
- Ocean: water-worn stone, pale deposits, and small shell-like rings.
- Cyan: turquoise mineral fragments.
- Purple: amethyst-like crystal facets.
- Creme White legacy theme: pale stone with warm repair veins.

No newly generated image, PNG/JPEG texture, bitmap face, or sprite sheet is used by these components.

## New character style

The old renderer is replaced by a new code-drawn design with compact curved solar petals, shaded solar/lunar volume, lunar craters kept around the face, almond-shaped eyes with sclera/iris/pupil layers, upper lids, reflected eye highlights, independent expressive brows, shaded cheeks, a small nose, variable mouth shapes, blush, and tears.

Old companion prop artwork is no longer supplied to the navigation character. The companion's dialogue/events are retained, but their face performance uses the new expression/speech engine. The optional prop API remains for compatibility outside this navigation call site.

## Expression repertoire

46 named expressions and behaviours:

Neutral, blink, double blink, twitch, brow raise, surprise, wink, look around, sleepy, shiver, joy, laugh, giggle, excited, delighted, proud, content, affectionate, shy, embarrassed, playful, smug, curious, confused, thinking, skeptical, focused, determined, annoyed, frustrated, angry, pout, sad, disappointed, worried, tearful, afraid, shocked, relieved, yawn, dozing, awakening, tired, bored, hopeful, grateful.

These are named poses/behaviours, not 46 unrelated animation engines. Blink and double-blink intentionally share the closed-eye pose but use different sequences. Other emotion families differ in brows, lids, gaze, pupil size, mouth shape, cheek colour, and/or tears. The rebuilt engine uses notice/expression/emphasis/release beats, special blink/laughter/yawn sequences, and a new finite speech performance. Some compatibility names such as SHIVER, HOP, and BREATHE are now facial reactions rather than body-floating effects.

Idle reactions use a restrained subset; app events select other relevant families. The complete catalogue can be invoked through the expression API and inspected through the debug previews. More intense moods are not randomly shown every few seconds. Interaction and speech can interrupt idle performances, and cancellation resets the face rather than leaving a frozen expression.

## What was preserved

The earlier bookshelf/header/selection-toolbar fixes, onboarding changes, appearance controls, notification toggle, storage screen, library contents and operations, application ID, version, dependencies, and signing configuration are unchanged by this revision.

## Validation and limitations

23 source-level checks passed, covering catalogue completeness, replacement of the old renderer and choreography, fixed seating, mode/form mapping, celestial-only departure, fade-in replacement, flight hand-off coordinates, material variants, absence of image assets in the new art, companion integration, balanced Kotlin delimiters, and preservation of prior fixes.

These are source-level checks only. They are NOT Kotlin compilation, native visual inspection, animation/device testing, or a successful APK build. The current environment has no Android SDK/Gradle installation, and the original project is missing gradle/wrapper/gradle-wrapper.jar. Running the wrapper still stops at that missing JAR. Restore it from your trusted working setup or use a compatible installed Gradle in your usual Android environment.

Added for testing in that environment:

- `app/src/debug/java/com/lorelight/ui/theme/modeswitch/celestial/CelestialRedesignPreviews.kt`: actual native drawing previews parameterized over every expression and all stone materials.
- `app/src/test/java/com/lorelight/ui/theme/modeswitch/celestial/CelestialPoseTest.kt`: catalogue/channel bounds, distinct mood families, interpolation endpoints, and fixed-rest tests. These JUnit tests have been added but could not be run here.

## Before distributing a build

1. Compile the debug variant and run the new pose tests plus the existing test suite.
2. Render every expression and material in the new Android Studio previews. Inspect the eye/mouth shapes, rim readability, contrast, and actual small-size output, not just enlarged artwork.
3. On a small phone and a tablet, confirm the bowl is only slightly taller than the panels and never covers navigation targets. Repeat with larger text/display sizes and both app modes.
4. Confirm the sun is seated in dark mode and the moon in light mode. Leave each idle and check that no body or shadow floats/bobs.
5. Select Celestial Arc and test both directions: slide-out, no duplicate captured body, continuous flight hand-off, correct opposite body appearing afterward.
6. Test every other effect, plus reduced motion/battery saver: no departure slide for non-celestial effects. Interrupt/rotate/background the app during transitions and check that the character returns visible.
7. Trigger companion speech, milestone, failure, sleepy, and curiosity events. Confirm new expression/speech performances, cancellation, tap/long-press, and no old prop overlay.
8. Recheck the previous library and onboarding fixes before release.
