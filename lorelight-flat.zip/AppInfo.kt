package eu.kanade.tachiyomi

/**
 * ADAPTED FOR LORELIGHT — upstream Mihon generates this from its own BuildConfig.
 * Some extensions call these to branch on host capabilities.
 */
object AppInfo {
    fun getVersionCode(): Int = com.lorelight.BuildConfig.VERSION_CODE
    fun getVersionName(): String = com.lorelight.BuildConfig.VERSION_NAME
}
