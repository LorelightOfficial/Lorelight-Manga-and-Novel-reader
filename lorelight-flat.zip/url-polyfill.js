(function () {
  if (typeof globalThis.URL === 'function' && globalThis.__lorelightURL) return;

  var URI = /^(?:([^:\/?#]+):)?(?:\/\/([^\/?#]*))?([^?#]*)(?:\?([^#]*))?(?:#(.*))?$/;

  function parse(u) {
    var m = URI.exec(u || '');
    return { scheme: m[1], authority: m[2], path: m[3] || '', query: m[4], fragment: m[5] };
  }
  function removeDots(path) {
    var out = [], inp = path || '';
    while (inp.length) {
      if (inp.indexOf('../') === 0) inp = inp.slice(3);
      else if (inp.indexOf('./') === 0) inp = inp.slice(2);
      else if (inp.indexOf('/./') === 0) inp = '/' + inp.slice(3);
      else if (inp === '/.') inp = '/';
      else if (inp.indexOf('/../') === 0) { inp = '/' + inp.slice(4); out.pop(); }
      else if (inp === '/..') { inp = '/'; out.pop(); }
      else if (inp === '.' || inp === '..') inp = '';
      else {
        var start = inp.charAt(0) === '/' ? 1 : 0;
        var i = inp.indexOf('/', start), seg;
        if (i === -1) { seg = inp; inp = ''; } else { seg = inp.slice(0, i); inp = inp.slice(i); }
        out.push(seg);
      }
    }
    return out.join('');
  }
  function merge(base, refPath) {
    if (base.authority != null && base.path === '') return '/' + refPath;
    var i = base.path.lastIndexOf('/');
    return i === -1 ? refPath : base.path.slice(0, i + 1) + refPath;
  }
  function recompose(t) {
    var r = '';
    if (t.scheme != null) r += t.scheme + ':';
    if (t.authority != null) r += '//' + t.authority;
    r += t.path;
    if (t.query != null) r += '?' + t.query;
    if (t.fragment != null) r += '#' + t.fragment;
    return r;
  }
  function resolve(baseStr, refStr) {
    var R = parse(refStr), B = parse(baseStr), T = {};
    if (R.scheme != null) { T.scheme = R.scheme; T.authority = R.authority; T.path = removeDots(R.path); T.query = R.query; }
    else {
      if (R.authority != null) { T.authority = R.authority; T.path = removeDots(R.path); T.query = R.query; }
      else {
        if (R.path === '') { T.path = B.path; T.query = (R.query != null) ? R.query : B.query; }
        else {
          if (R.path.charAt(0) === '/') T.path = removeDots(R.path);
          else T.path = removeDots(merge(B, R.path));
          T.query = R.query;
        }
        T.authority = B.authority;
      }
      T.scheme = B.scheme;
    }
    T.fragment = R.fragment;
    return recompose(T);
  }

  function URLPolyfill(url, base) {
    if (!(this instanceof URLPolyfill)) return new URLPolyfill(url, base);
    var full = String(url == null ? '' : url);
    var hasBase = (base !== undefined && base !== null && String(base) !== '');
    if (hasBase) full = resolve(String(base), full);
    var p = parse(full);
    if (p.scheme == null && !hasBase) throw new TypeError('Invalid URL: ' + url);

    var auth = p.authority || '', userinfo = '', hostport = auth;
    var at = auth.indexOf('@');
    if (at !== -1) { userinfo = auth.slice(0, at); hostport = auth.slice(at + 1); }
    var host = hostport, port = '';
    var colon = hostport.lastIndexOf(':');
    if (colon !== -1 && /^[0-9]+$/.test(hostport.slice(colon + 1))) { host = hostport.slice(0, colon); port = hostport.slice(colon + 1); }
    var uname = '', pass = '', uc = userinfo.indexOf(':');
    if (uc !== -1) { uname = userinfo.slice(0, uc); pass = userinfo.slice(uc + 1); } else uname = userinfo;

    this.href = full;
    this.protocol = p.scheme != null ? p.scheme + ':' : '';
    this.username = uname;
    this.password = pass;
    this.hostname = host;
    this.port = port;
    this.host = host + (port ? ':' + port : '');
    this.pathname = p.path || (auth ? '/' : '');
    this.search = (p.query != null) ? '?' + p.query : '';
    this.hash = (p.fragment != null) ? '#' + p.fragment : '';
    this.origin = (p.scheme != null && auth) ? (p.scheme + '://' + this.host) : 'null';
    try { this.searchParams = (typeof URLSearchParams !== 'undefined') ? new URLSearchParams(p.query || '') : undefined; }
    catch (e) { this.searchParams = undefined; }
  }
  URLPolyfill.prototype.toString = function () { return this.href; };
  URLPolyfill.prototype.toJSON = function () { return this.href; };

  globalThis.URL = URLPolyfill;
  globalThis.__lorelightURL = true;
})();
