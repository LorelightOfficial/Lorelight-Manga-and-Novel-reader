package com.lorelight.data.chapters

import android.content.Context
import android.util.Log
import com.lorelight.data.db.DbWriter
import com.lorelight.data.model.Novel
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * CHAPTER READ STATE, REBUILT FROM SCRATCH.
 *
 * WHY THE OLD ONE WAS WRONG
 * -------------------------
 * The previous backend (the `chapters` Room table + MangaReadProgress) stored
 * read state against a chapter's INDEX in the list, and it had three faults
 * that no amount of patching was going to fix:
 *
 *  1. INDEX IDENTITY. Manga/manhua sources publish newest-first, so one new
 *     chapter shifts every existing chapter by one position. Read marks stayed
 *     behind on the old numbers, so every dim slid one chapter off. There was a
 *     realignment pass bolted on top of it, but it only ran when it could prove
 *     the list had moved, and it worked by DELETING and re-inserting every row.
 *
 *  2. NOVELS WERE NEVER RECORDED. Only the manga reader wrote to that table.
 *     Text novels tracked "finished" in a list of chapter NAME strings on the
 *     novel row, which the details list did not read at all - which is why
 *     nothing ever dulled out for novels.
 *
 *  3. NOT LIVE. The details screen re-read the whole table whenever a revision
 *     counter changed, so what you saw was a snapshot taken at some earlier
 *     moment rather than the current truth.
 *
 * HOW THIS ONE WORKS
 * ------------------
 *  - IDENTITY IS THE CHAPTER'S URL (falling back to its title, then its index
 *    for sources that expose neither). Nothing is keyed by position, so new
 *    chapters arriving at the top of a list cannot move anybody's read mark.
 *
 *  - ONE SMALL JSON FILE PER SERIES under filesDir/chapter_state. No Room
 *    entity, no schema version, no migration: this store cannot put the
 *    database into Room's destructive fallback, and it starts EMPTY, which is
 *    the clean slate that was asked for.
 *
 *  - THE UI COLLECTS A StateFlow. A mark is published to the flow in the same
 *    frame it is made, so a chapter dims (or the highlight moves) immediately;
 *    disk is written afterwards, off the main thread.
 *
 *  - EVERY WRITE GOES THROUGH [DbWriter], the app's single writer thread, so
 *    these writes are ordered against library and progress writes and can never
 *    interleave with each other.
 *
 * WHAT "CURRENT" MEANS
 * -------------------
 * [setCurrent] is stamped whenever a chapter is actually opened. The highlight
 * is therefore a recorded fact. The old screen guessed it by looking up a
 * mutable chapter-name string, which is what used to highlight chapter 189
 * while you were reading 234.
 */
object ChapterReadStore {

    private const val TAG = "ChapterReadStore"
    private const val DIR = "chapter_state"
    private const val FORMAT = 1

    /** Recorded state for ONE chapter. */
    data class Entry(
        val completed: Boolean = false,
        /** 0-based page/paragraph the chapter was left on. */
        val page: Int = 0,
        /** Epoch millis of the last change; 0 = never touched. */
        val at: Long = 0L,
        val bookmark: Boolean = false
    )

    /** Everything the chapter list needs, for one series. */
    data class Snapshot(
        val novelId: String = "",
        val entries: Map<String, Entry> = emptyMap(),
        val currentKey: String = "",
        val currentAt: Long = 0L,
        /** False until disk has been read once. */
        val loaded: Boolean = false
    ) {
        fun isCompleted(key: String): Boolean = entries[key]?.completed == true

        fun pageOf(key: String): Int = entries[key]?.page ?: 0

        fun isBookmarked(key: String): Boolean = entries[key]?.bookmark == true

        fun isCurrent(key: String): Boolean = key.isNotEmpty() && key == currentKey

        /** Started but not finished - worth advertising a resume point for. */
        fun isInProgress(key: String): Boolean {
            val e = entries[key] ?: return false
            return !e.completed && e.page > 0
        }

        val completedCount: Int get() = entries.values.count { it.completed }
    }

    // -----------------------------------------------------------------
    // Identity
    // -----------------------------------------------------------------

    /**
     * The durable identity of a chapter. URL first, because that is what the
     * source itself uses to identify it; a title is the fallback for sources
     * that publish none, and the index is the last resort.
     */
    fun keyFor(novel: Novel, index: Int): String {
        if (index < 0) return ""
        val url = novel.chapterUrls.getOrNull(index)?.trim().orEmpty()
        if (url.isNotEmpty()) return "u:" + url
        val title = novel.chapters.getOrNull(index)?.trim().orEmpty()
        if (title.isNotEmpty()) return "t:" + title
        return "i:" + index
    }

    /** All keys for a series, in list order. */
    fun keysFor(novel: Novel): List<String> =
        novel.chapters.indices.map { keyFor(novel, it) }

    /** Indices of finished chapters - for the in-reader contents drawers. */
    fun completedIndices(novel: Novel, snapshot: Snapshot): Set<Int> {
        if (snapshot.entries.isEmpty()) return emptySet()
        val out = HashSet<Int>()
        for (i in novel.chapters.indices) {
            if (snapshot.isCompleted(keyFor(novel, i))) out.add(i)
        }
        return out
    }

    /** Index of the recorded current chapter, or -1 when nothing is recorded. */
    fun currentIndex(novel: Novel, snapshot: Snapshot): Int {
        val key = snapshot.currentKey
        if (key.isEmpty()) return -1
        for (i in novel.chapters.indices) {
            if (keyFor(novel, i) == key) return i
        }
        return -1
    }

    // -----------------------------------------------------------------
    // Observation
    // -----------------------------------------------------------------

    private val lock = Any()
    private val flows = HashMap<String, MutableStateFlow<Snapshot>>()
    private val loadStarted = HashSet<String>()

    private fun flowFor(novelId: String): MutableStateFlow<Snapshot> = synchronized(lock) {
        flows.getOrPut(novelId) { MutableStateFlow(Snapshot(novelId = novelId)) }
    }

    /**
     * Live state for one series. Safe to call from composition: the disk read is
     * kicked off at most once per series and lands on the flow when it is done.
     */
    fun observe(context: Context, novelId: String): StateFlow<Snapshot> {
        val flow = flowFor(novelId)
        ensureLoaded(context, novelId)
        return flow.asStateFlow()
    }

    /** Current value without observing. */
    fun snapshot(novelId: String): Snapshot = flowFor(novelId).value

    private fun ensureLoaded(context: Context, novelId: String) {
        if (novelId.isEmpty()) return
        val shouldLoad = synchronized(lock) {
            if (loadStarted.contains(novelId)) false else {
                loadStarted.add(novelId)
                true
            }
        }
        if (!shouldLoad) return
        val app = context.applicationContext
        DbWriter.submit("chapterStateLoad(" + novelId + ")") {
            val flow = flowFor(novelId)
            // Merge rather than overwrite: a mark made in the moment before the
            // read finished lives only in memory, and must not be dropped.
            flow.value = merge(readFromDisk(app, novelId), flow.value)
        }
    }

    /**
     * Disk + memory into one snapshot. Per chapter the fresher timestamp wins,
     * so neither side can drag the other backwards.
     */
    private fun merge(disk: Snapshot, memory: Snapshot): Snapshot {
        val entries = HashMap<String, Entry>(disk.entries)
        for ((key, mem) in memory.entries) {
            val onDisk = entries[key]
            if (onDisk == null || mem.at >= onDisk.at) entries[key] = mem
        }
        val useMemoryCurrent = memory.currentKey.isNotEmpty() && memory.currentAt >= disk.currentAt
        return Snapshot(
            novelId = if (disk.novelId.isNotEmpty()) disk.novelId else memory.novelId,
            entries = entries,
            currentKey = if (useMemoryCurrent) memory.currentKey else disk.currentKey,
            currentAt = if (useMemoryCurrent) memory.currentAt else disk.currentAt,
            loaded = true
        )
    }

    // -----------------------------------------------------------------
    // Writes
    // -----------------------------------------------------------------

    private fun mutate(
        context: Context,
        novelId: String,
        tag: String,
        transform: (Snapshot) -> Snapshot
    ) {
        if (novelId.isEmpty()) return
        val app = context.applicationContext
        val flow = flowFor(novelId)
        ensureLoaded(app, novelId)
        val before = flow.value
        val after = transform(before).copy(novelId = novelId)
        if (after == before) return
        // Publish first so the list updates in this frame, persist after.
        flow.value = after
        DbWriter.submit(tag) { persist(app, after) }
    }

    private fun persist(app: Context, snapshot: Snapshot) {
        // A snapshot built before the first disk read holds only what happened
        // since launch. Writing it as-is would truncate the file, so fold disk
        // in first - we are on the writer thread, so nothing can race us.
        val toWrite = if (snapshot.loaded) {
            snapshot
        } else {
            val merged = merge(readFromDisk(app, snapshot.novelId), snapshot)
            flowFor(snapshot.novelId).value = merged
            merged
        }
        writeToDisk(app, toWrite)
    }

    /** Stamps the chapter you just opened. Drives the list's highlight. */
    fun setCurrent(context: Context, novel: Novel, chapterIndex: Int) {
        val key = keyFor(novel, chapterIndex)
        if (key.isEmpty()) return
        val now = System.currentTimeMillis()
        mutate(context, novel.id, "chapterCurrent(" + novel.id + ":" + chapterIndex + ")") { s ->
            val prev = s.entries[key] ?: Entry()
            s.copy(
                entries = s.entries + (key to prev.copy(at = now)),
                currentKey = key,
                currentAt = now
            )
        }
    }

    /**
     * THE HOT PATH: called as pages turn. Records the resume point and completes
     * the chapter on its final page. [pageCount] of 0 means "not known yet", in
     * which case completion is not inferred.
     */
    fun notePage(
        context: Context,
        novel: Novel,
        chapterIndex: Int,
        pageIndex: Int,
        pageCount: Int
    ) {
        val key = keyFor(novel, chapterIndex)
        if (key.isEmpty()) return
        val page = pageIndex.coerceAtLeast(0)
        val finished = pageCount > 0 && page >= pageCount - 1
        val now = System.currentTimeMillis()
        mutate(context, novel.id, "chapterPage(" + novel.id + ":" + chapterIndex + ")") { s ->
            val prev = s.entries[key] ?: Entry()
            // Never let a stale tick walk the resume page backwards.
            val page2 = if (!finished && !prev.completed && prev.page > page) prev.page else page
            s.copy(
                entries = s.entries + (
                    key to prev.copy(
                        completed = prev.completed || finished,
                        page = page2,
                        at = now
                    )
                    ),
                currentKey = key,
                currentAt = now
            )
        }
    }

    /**
     * Mark chapters finished / unfinished. Un-marking also clears the saved
     * page, so an unread chapter genuinely restarts from the beginning.
     */
    fun setCompleted(
        context: Context,
        novel: Novel,
        chapterIndices: List<Int>,
        completed: Boolean
    ) {
        if (chapterIndices.isEmpty()) return
        val keys = chapterIndices.map { keyFor(novel, it) }.filter { it.isNotEmpty() }
        if (keys.isEmpty()) return
        val now = System.currentTimeMillis()
        mutate(
            context,
            novel.id,
            "chapterCompleted(" + novel.id + ":" + keys.size + ":" + completed + ")"
        ) { s ->
            val next = HashMap(s.entries)
            for (key in keys) {
                val prev = next[key] ?: Entry()
                next[key] = prev.copy(
                    completed = completed,
                    page = if (completed) prev.page else 0,
                    at = now
                )
            }
            s.copy(entries = next)
        }
    }

    fun markCompleted(context: Context, novel: Novel, chapterIndex: Int) =
        setCompleted(context, novel, listOf(chapterIndex), true)

    fun markNotCompleted(context: Context, novel: Novel, chapterIndex: Int) =
        setCompleted(context, novel, listOf(chapterIndex), false)

    /** "Mark previous as read": everything strictly before [beforeIndex]. */
    fun markPreviousCompleted(context: Context, novel: Novel, beforeIndex: Int) {
        if (beforeIndex <= 0) return
        setCompleted(context, novel, (0 until beforeIndex).toList(), true)
    }

    /** Whole-series mark read / unread. */
    fun setAllCompleted(context: Context, novel: Novel, completed: Boolean) {
        if (novel.chapters.isEmpty()) return
        setCompleted(context, novel, novel.chapters.indices.toList(), completed)
    }

    fun setBookmark(context: Context, novel: Novel, chapterIndex: Int, bookmark: Boolean) {
        val key = keyFor(novel, chapterIndex)
        if (key.isEmpty()) return
        val now = System.currentTimeMillis()
        mutate(context, novel.id, "chapterBookmark(" + novel.id + ":" + chapterIndex + ")") { s ->
            val prev = s.entries[key] ?: Entry()
            s.copy(entries = s.entries + (key to prev.copy(bookmark = bookmark, at = now)))
        }
    }

    /** Drops everything recorded for a series that is leaving the library. */
    fun clear(context: Context, novelId: String) {
        if (novelId.isEmpty()) return
        val app = context.applicationContext
        flowFor(novelId).value = Snapshot(novelId = novelId, loaded = true)
        DbWriter.submit("chapterStateClear(" + novelId + ")") {
            try {
                val f = fileFor(app, novelId)
                if (f.exists()) f.delete()
            } catch (t: Throwable) {
                Log.e(TAG, "Could not clear chapter state: " + t.message)
            }
        }
    }

    // -----------------------------------------------------------------
    // Disk
    // -----------------------------------------------------------------

    private fun fileFor(app: Context, novelId: String): File {
        val dir = File(app.filesDir, DIR)
        if (!dir.exists()) dir.mkdirs()
        val safe = novelId.map { c -> if (c.isLetterOrDigit()) c else '_' }
            .joinToString("")
            .take(48)
        return File(dir, safe + "_" + Integer.toHexString(novelId.hashCode()) + ".json")
    }

    private fun readFromDisk(app: Context, novelId: String): Snapshot {
        if (novelId.isEmpty()) return Snapshot(loaded = true)
        return try {
            val f = fileFor(app, novelId)
            if (!f.exists() || f.length() <= 2L) {
                return Snapshot(novelId = novelId, loaded = true)
            }
            val root = JSONObject(f.readText())
            val arr = root.optJSONArray("entries") ?: JSONArray()
            val entries = HashMap<String, Entry>(arr.length() * 2)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val key = o.optString("k")
                if (key.isEmpty()) continue
                entries[key] = Entry(
                    completed = o.optInt("c", 0) == 1,
                    page = o.optInt("p", 0),
                    at = o.optLong("t", 0L),
                    bookmark = o.optInt("b", 0) == 1
                )
            }
            Snapshot(
                novelId = novelId,
                entries = entries,
                currentKey = root.optString("current"),
                currentAt = root.optLong("currentAt", 0L),
                loaded = true
            )
        } catch (t: Throwable) {
            Log.e(TAG, "Unreadable chapter state for " + novelId + ": " + t.message)
            Snapshot(novelId = novelId, loaded = true)
        }
    }

    private fun writeToDisk(app: Context, snapshot: Snapshot) {
        if (snapshot.novelId.isEmpty()) return
        try {
            val arr = JSONArray()
            for ((key, e) in snapshot.entries) {
                // Nothing recorded at all - no reason to keep the row.
                if (!e.completed && !e.bookmark && e.page == 0 && e.at == 0L) continue
                val o = JSONObject()
                o.put("k", key)
                if (e.completed) o.put("c", 1)
                if (e.page != 0) o.put("p", e.page)
                if (e.at != 0L) o.put("t", e.at)
                if (e.bookmark) o.put("b", 1)
                arr.put(o)
            }
            val root = JSONObject()
            root.put("v", FORMAT)
            root.put("entries", arr)
            if (snapshot.currentKey.isNotEmpty()) {
                root.put("current", snapshot.currentKey)
                root.put("currentAt", snapshot.currentAt)
            }
            val target = fileFor(app, snapshot.novelId)
            val tmp = File(target.absolutePath + ".tmp")
            tmp.writeText(root.toString())
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) {
                // Rename can fail on some OEM filesystems; fall back to a copy.
                target.writeText(root.toString())
                tmp.delete()
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Could not save chapter state: " + t.message)
        }
    }
}
