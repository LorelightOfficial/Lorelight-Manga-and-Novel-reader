package eu.kanade.domain.ui

import eu.kanade.domain.ui.model.AppTheme
import eu.kanade.domain.ui.model.ThemeMode
import tachiyomi.core.common.preference.Preference
import tachiyomi.core.common.preference.PreferenceStore
import tachiyomi.core.common.preference.getEnum

class UiPreferences(
    private val preferenceStore: PreferenceStore,
) {

    val themeMode: Preference<ThemeMode> =
        preferenceStore.getEnum("pref_theme_mode_key", ThemeMode.SYSTEM)

    val appTheme: Preference<AppTheme> =
        preferenceStore.getEnum("pref_app_theme", AppTheme.DEFAULT)

    val themeDarkAmoled: Preference<Boolean> =
        preferenceStore.getBoolean("pref_theme_dark_amoled_key", false)
}
