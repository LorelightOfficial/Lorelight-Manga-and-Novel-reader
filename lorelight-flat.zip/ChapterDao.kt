package com.lorelight.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface ChapterDao {
    @Query("SELECT * FROM chapters WHERE novelId = :novelId ORDER BY idx ASC")
    fun getForNovel(novelId: String): List<ChapterEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsertAll(chapters: List<ChapterEntity>)

    /**
     * Insert-only: existing rows are left completely untouched.
     *
     * This is what read-state code uses to make sure a row exists, because
     * [upsertAll] would REPLACE the row and therefore reset completed /
     * lastPageRead / bookmark back to their defaults - silently erasing reading
     * progress every time the chapter list was refreshed.
     */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insertMissing(chapters: List<ChapterEntity>)

    @Query("DELETE FROM chapters WHERE novelId = :novelId")
    fun deleteForNovel(novelId: String)

    /**
     * FIX (B13): the old implementation returned early when [chapters] was empty,
     * BEFORE deleting, so "replace with nothing" silently left the previous rows
     * behind. Clearing is now always performed; only the insert pass is skipped.
     *
     * NOTE: this DESTROYS read state (it deletes first). For a chapter-list
     * refresh that must preserve progress, use [syncChapterList] instead.
     */
    @Transaction
    fun replaceForNovel(novelId: String, chapters: List<ChapterEntity>) {
        if (novelId.isEmpty()) return
        deleteForNovel(novelId)
        if (chapters.isEmpty()) return
        chapters.chunked(500).forEach { upsertAll(it) }
    }

    @Query("SELECT COUNT(*) FROM chapters WHERE novelId = :novelId AND completed = 1")
    fun countCompletedForNovel(novelId: String): Int

    @Query("UPDATE chapters SET completed = :completed WHERE novelId = :novelId AND idx = :idx")
    fun setCompleted(novelId: String, idx: Int, completed: Boolean)

    @Query("SELECT COUNT(*) FROM chapters WHERE novelId = :novelId")
    fun countForNovel(novelId: String): Int

    @Query("SELECT DISTINCT novelId FROM chapters")
    fun novelIdsWithChapters(): List<String>

    // ---------------------------------------------------------------
    // Read state (mihon parity)
    // ---------------------------------------------------------------

    @Query("SELECT idx FROM chapters WHERE novelId = :novelId ORDER BY idx ASC")
    fun indicesForNovel(novelId: String): List<Int>

    @Query("SELECT idx FROM chapters WHERE novelId = :novelId AND completed = 1 ORDER BY idx ASC")
    fun completedIndicesForNovel(novelId: String): List<Int>

    /** Refreshes display metadata only - never touches read state. */
    @Query("UPDATE chapters SET title = :title, url = :url WHERE novelId = :novelId AND idx = :idx")
    fun refreshMeta(novelId: String, idx: Int, title: String, url: String)

    /** Hot path: called as the reader turns pages. */
    @Query(
        "UPDATE chapters SET lastPageRead = :page, lastReadAt = :readAt " +
            "WHERE novelId = :novelId AND idx = :idx"
    )
    fun setLastPageRead(novelId: String, idx: Int, page: Int, readAt: Long)

    /**
     * mihon SetReadStatus parity: marking a chapter UNREAD also clears its saved
     * page, so it genuinely restarts from the beginning. Marking it read keeps
     * whatever page was stored.
     */
    @Query(
        "UPDATE chapters SET completed = :read, lastReadAt = :readAt, " +
            "lastPageRead = CASE WHEN :read = 0 THEN 0 ELSE lastPageRead END " +
            "WHERE novelId = :novelId AND idx IN (:indices)"
    )
    fun setReadForIndices(novelId: String, indices: List<Int>, read: Boolean, readAt: Long)

    /** mihon's "Mark previous as read": everything strictly before [before]. */
    @Query(
        "UPDATE chapters SET completed = 1, lastReadAt = :readAt " +
            "WHERE novelId = :novelId AND idx < :before AND completed = 0"
    )
    fun markPreviousAsRead(novelId: String, before: Int, readAt: Long)

    @Query(
        "UPDATE chapters SET completed = :read, lastReadAt = :readAt, " +
            "lastPageRead = CASE WHEN :read = 0 THEN 0 ELSE lastPageRead END " +
            "WHERE novelId = :novelId"
    )
    fun setReadForNovel(novelId: String, read: Boolean, readAt: Long)

    @Query("UPDATE chapters SET bookmark = :bookmark WHERE novelId = :novelId AND idx = :idx")
    fun setBookmark(novelId: String, idx: Int, bookmark: Boolean)

    /** mihon GetNextChapters parity: the earliest unfinished chapter. */
    @Query(
        "SELECT idx FROM chapters WHERE novelId = :novelId AND completed = 0 " +
            "ORDER BY idx ASC LIMIT 1"
    )
    fun firstUnreadIndex(novelId: String): Int?

    /**
     * The chapter that was read most recently.
     *
     * lastReadAt is stamped by [setLastPageRead] on every single page turn, so
     * this is a recorded fact rather than a guess -- which is what makes it a
     * safe authority for "where was I" when reopening a series.
     */
    @Query(
        "SELECT idx FROM chapters WHERE novelId = :novelId AND lastReadAt > 0 " +
            "ORDER BY lastReadAt DESC, idx DESC LIMIT 1"
    )
    fun lastReadIndex(novelId: String): Int?

    @Query("SELECT COUNT(*) FROM chapters WHERE novelId = :novelId AND completed = 0")
    fun countUnreadForNovel(novelId: String): Int

    /**
     * Progress-preserving chapter-list sync: adds rows for new chapters and
     * refreshes titles/urls for existing ones, without ever clearing read state.
     * This is the safe counterpart to [replaceForNovel].
     */
    @Transaction
    fun syncChapterList(novelId: String, chapters: List<ChapterEntity>) {
        if (novelId.isEmpty() || chapters.isEmpty()) return

        val existing = getForNovel(novelId)
        if (existing.isEmpty()) {
            chapters.chunked(500).forEach { insertMissing(it) }
            return
        }

        // SLIDING-DIM FIX.
        //
        // Read state is stored against idx, and the old body only ever called
        // refreshMeta(), which overwrites the title and url AT an index while
        // leaving completed / lastPageRead / bookmark exactly where they were.
        // Manga sources publish newest-first, so a single new chapter pushes
        // every existing chapter down one index -- and the read marks stayed
        // behind on the old numbers. Every dim slid one chapter off, which is
        // why the marks looked scrambled rather than merely late.
        //
        // A chapter's url is its real identity, so carry read state across on
        // the url (falling back to the title for sources that expose none)
        // whenever the numbering has actually moved.
        val byUrl = HashMap<String, ChapterEntity>(existing.size * 2)
        val byTitle = HashMap<String, ChapterEntity>(existing.size * 2)
        for (row in existing) {
            if (row.url.isNotEmpty()) byUrl[row.url] = row
            if (row.title.isNotEmpty() && !byTitle.containsKey(row.title)) byTitle[row.title] = row
        }

        fun identityOf(fresh: ChapterEntity): ChapterEntity? =
            if (fresh.url.isNotEmpty()) byUrl[fresh.url] else byTitle[fresh.title]

        // Only rewrite rows when the numbering genuinely moved, and never when
        // the incoming list is SHORTER than what is on disk. A partial or failed
        // fetch must not be allowed to delete recorded progress.
        var shifted = false
        if (chapters.size >= existing.size) {
            for (fresh in chapters) {
                val identity = identityOf(fresh)
                if (identity != null && identity.idx != fresh.idx) {
                    shifted = true
                    break
                }
            }
        }

        if (!shifted) {
            chapters.chunked(500).forEach { insertMissing(it) }
            chapters.forEach { refreshMeta(novelId, it.idx, it.title, it.url) }
            return
        }

        val realigned = ArrayList<ChapterEntity>(chapters.size)
        for (fresh in chapters) {
            val identity = identityOf(fresh)
            realigned.add(
                if (identity == null) {
                    fresh
                } else {
                    fresh.copy(
                        completed = identity.completed,
                        lastPageRead = identity.lastPageRead,
                        bookmark = identity.bookmark,
                        lastReadAt = identity.lastReadAt
                    )
                }
            )
        }
        deleteForNovel(novelId)
        realigned.chunked(500).forEach { upsertAll(it) }
    }

    /** SQLite caps bound variables (999), so IN (...) updates are chunked. */
    @Transaction
    fun setReadChunked(novelId: String, indices: List<Int>, read: Boolean, readAt: Long) {
        if (novelId.isEmpty() || indices.isEmpty()) return
        indices.chunked(500).forEach { setReadForIndices(novelId, it, read, readAt) }
    }
}
