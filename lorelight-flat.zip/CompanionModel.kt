/*
 * =============================================================================
 * CompanionModel.kt - the vocabulary every other companion file shares.
 * Package: com.lorelight.companion
 *
 * Three ideas only:
 *
 *   Mood           which character is on the altar right now (sun = light
 *                  theme, moon = dark theme). Never stored; always read from
 *                  the live theme so it can never drift out of sync.
 *
 *   LineClass      arr / evt / amb. Decides which openers and tails are
 *                  allowed to attach to a body. The corpus file is the
 *                  authority for this, NOT this enum - see CompanionCorpus.
 *
 *   CompanionEvent the 16 things the character can notice, each with its
 *                  rank. Rank 1 outranks rank 16. When two events land in
 *                  the same moment the lower rank wins and the other is
 *                  DISCARDED, never queued.
 * =============================================================================
 */
package com.lorelight.companion

enum class Mood(val wire: String) {
    SUN("sun"),
    MOON("moon");

    val other: Mood get() = if (this == SUN) MOON else SUN

    companion object {
        /** The mood follows the theme. Light theme = the sun is up. */
        fun forTheme(isLightTheme: Boolean): Mood = if (isLightTheme) SUN else MOON
    }
}

/**
 * Which family a line belongs to. Openers and tails carry a set of these,
 * and only attach to a body of a matching class.
 */
enum class LineClass(val wire: String) {
    ARR("arr"),   // arrival moments - opening the app, coming back
    EVT("evt"),   // milestones - added a book, finished a chapter
    AMB("amb");   // ambient - late night, idle, long session

    /** Bit for the cheap mask used during assembly. */
    val bit: Int get() = 1 shl ordinal

    companion object {
        fun fromWire(wire: String): LineClass? =
            entries.firstOrNull { it.wire == wire }
    }
}

/**
 * Every moment the companion can speak about.
 *
 * `key` must match the corpus JSON exactly - it is the lookup name in
 * `bodies.sun` / `bodies.moon` and in `eventClass`.
 *
 * `rank` is the tie-break order from the policy table. Lower wins.
 */
enum class CompanionEvent(val key: String, val rank: Int) {

    // --- arrival: mutually exclusive, at most one can ever be true --------
    FIRST_EVER("FIRST_EVER", 1),
    BACK_AFTER_AGES("BACK_AFTER_AGES", 2),
    BACK_AFTER_WEEK("BACK_AFTER_WEEK", 3),
    BACK_AFTER_DAY("BACK_AFTER_DAY", 4),
    BACK_SAME_DAY("BACK_SAME_DAY", 5),

    // --- milestones -------------------------------------------------------
    CHAPTER_DONE("CHAPTER_DONE", 6),
    MODE_SWITCHED("MODE_SWITCHED", 7),
    STREAK("STREAK", 8),
    NOVEL_ADDED("NOVEL_ADDED", 9),
    MANGA_ADDED("MANGA_ADDED", 10),

    // --- ambient ----------------------------------------------------------
    LONG_SESSION("LONG_SESSION", 11),
    UNFINISHED_WAITING("UNFINISHED_WAITING", 12),
    LIBRARY_GROWING("LIBRARY_GROWING", 13),
    LATE_NIGHT("LATE_NIGHT", 14),
    EARLY_MORNING("EARLY_MORNING", 15),
    IDLE_MUSING("IDLE_MUSING", 16);

    /** True for the five arrival events, which share one once-per-day slot. */
    val isArrival: Boolean
        get() = rank <= 5

    companion object {
        fun fromKey(key: String): CompanionEvent? = entries.firstOrNull { it.key == key }

        /** All events, best rank first. */
        val byRank: List<CompanionEvent> = entries.sortedBy { it.rank }
    }
}

/**
 * The values a line might need substituted into it.
 *
 * All optional. If a body asks for {title} and no title was supplied, the
 * assembler rejects that body and draws another - a line must never reach
 * the screen with a raw placeholder in it.
 */
data class LineParams(
    val title: String? = null,
    val days: Int? = null,
    val n: Int? = null
)

/**
 * A line the companion has decided to say. Produced by the assembler,
 * consumed by the speech box.
 */
data class CompanionLine(
    val text: String,
    val mood: Mood,
    val event: CompanionEvent?,
    /** True for hint-ladder and first-toggle lines: never assembled, spoken whole. */
    val isCurated: Boolean = false
)
