# Bookshelf and selection-toolbar layout update

This revision builds on Lorelight-onboarding-updated.zip and preserves its welcome scrolling, shared Appearance controls, new-chapter notification option, and removal of the gestures page.

## Changes

### My Bookshelf header

- The title is width-constrained and single-line, with ellipsis only if necessary. It can no longer take space reserved for the menu buttons.
- Sort/filter and the three-dot Bookshelf Options button each keep a 48 dp touch target.
- Novels/Manga is sized from the rendered labels and current app font rather than a fixed 146 dp width.
- The title, media filter, and menu buttons share a row only when their measured sizes fit. Otherwise, the filter moves below the title/menu row. It stays content-sized instead of stretching across a tablet.
- Existing media selection/persistence, sort/filter dropdown contents, bookshelf display settings, and manage-mode entry callbacks are preserved.

### Novels/Manga text centering

- The shared segmented control has an explicit line height and centered line-height alignment instead of inheriting an unrelated body-text line height.
- Height accounts for measured Medium and Bold text, including the actual app font and Android font scaling, with room around the text.
- The old 30 dp library pill height is removed. Text is not shrunk and system font scaling is not disabled.
- Equal Row weights distribute pixels across the segments, avoiding cumulative fixed-width rounding at the last segment.
- Existing highlight animation, theme colors, selection callbacks, and haptics remain.
- This is a shared component: Appearance and other callers also receive the text-height correction. Their supplied height is now a minimum subject to a 48 dp touch-target floor and measured label height.

### Long-press / edit-manage toolbar

- The selected count is constrained to one line with ellipsis if necessary. It cannot wrap one or two letters per line and inflate the toolbar.
- Close and Select All / Deselect All remain accessible with proper content descriptions.
- If measured text plus actions fits, Edit, Transfer, and Delete appear inline as before.
- At narrower widths or larger text sizes, Select All uses an icon, and Edit / Transfer / Delete move to a three-dot Selection actions menu.
- Edit is available for exactly one selection; Transfer and Delete are available for a nonempty selection. Existing data-operation callbacks are preserved, including deletion behavior.
- The toolbar has no expanding height, spacer weight in the vertical direction, or unbounded multiline count.

### Onboarding

Removed “What do you like to read?”, its route entry, temporary choice state, obsolete preference constants, and unused option-card helper.

Final route:

Welcome → Storage (when needed) → Pick your reading theme → Stay up to date → Sources → Finish.

Completion opens Library. Novels/Manga remains available from the bookshelf, without an onboarding choice. The storage route stays fixed for the current onboarding run, so saving a folder cannot shift the next step's index.

## Source changes in this revision

Modified:

- app/src/main/java/com/lorelight/ui/library/LibraryScreen.kt
- app/src/main/java/com/lorelight/ui/components/LorelightSegmentedControl.kt
- app/src/main/java/com/lorelight/ui/onboarding/OnboardingFlow.kt
- app/src/main/java/com/lorelight/MainActivity.kt (onboarding comment)
- app/src/main/res/values/strings.xml (selected-count and selection-actions strings)

Added:

- app/src/main/java/com/lorelight/ui/library/LibraryHeaders.kt
- app/src/debug/java/com/lorelight/ui/library/LibraryHeadersPreview.kt

The debug preview uses the actual new native components. It provides small-phone, 150%/200% text, and tablet cases, with 0, 1, 12, and 12,345 selections. It does not ship in release builds.

## Validation status

Thirteen source-level checks passed, including preserved data-operation callbacks, reserved menu widths, responsive filter placement, measured tab height and explicit line height, bounded selected-count text, access to all selection actions, removal of the onboarding route, preservation of previous fixes, XML resource validation, and balanced Kotlin delimiters.

No Kotlin/Android compilation, APK build, native preview rendering, device screenshots, or end-to-end device testing was possible in this environment. Source checks are not proof of visual correctness. The Android SDK and Gradle installation are unavailable here, and the original supplied project is missing gradle/wrapper/gradle-wrapper.jar. Restore the wrapper from your trusted working project or use your compatible installed Gradle distribution in your normal Android build setup.

## Device acceptance checklist

1. In Android Studio, open LibraryHeadersPreview.kt in the debug variant and render all five previews. Check for overlap/clipping, label centering, compact toolbar height, and both bookshelf menu buttons remaining inside the screen.
2. Test a 320–360 dp phone with normal, 150%, and 200% text, plus increased Display size. Both bookshelf menus must remain tappable. Novels/Manga may move below the title but must not expand unnecessarily.
3. Repeat on a tablet and in landscape. Check both selected pill states, all app themes, and Light / Dark / System modes. Verify that label baselines remain centered.
4. Add a test title and long-press it. “1 Selected” must stay on one line. On narrow layouts, open Selection actions and verify Edit, Transfer, and Delete. Check Close and Select All / Deselect All. Use disposable test entries for deletion.
5. Select multiple titles and a large count. Edit must disappear for multiple selections; Transfer and Delete must remain available. Test TalkBack labels and an RTL locale.
6. Rotate while in normal and manage mode and while an action menu is open. Confirm no actions disappear and the toolbar does not become tall.
7. Verify that sort, source filtering, display settings, mixed-media mode, media-filter persistence, and the book grid still work normally.
8. With a test install or safely reset onboarding, verify the final route above. There must be no reading-choice or gestures page. Complete onboarding, check the Library destination, and recheck the previous theme/mode and notification changes.

Back up your library before clearing app data or testing destructive actions.
