package com.lorelight.browse.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lorelight.browse.js.JSPluginEngine
import com.lorelight.browse.model.InstalledPlugin
import com.lorelight.browse.model.PluginInfo
import com.lorelight.browse.repo.PluginManager
import com.lorelight.browse.repo.PluginRepositoryManager
import com.lorelight.browse.repo.PluginStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/*
- Plain ViewModel (no DI), matching the app's manual-state style.
- Context is passed into each function from the composable (LocalContext).
*/
class BrowseViewModel : ViewModel() {

    private val _available = MutableStateFlow<List<PluginInfo>>(emptyList())
    val available: StateFlow<List<PluginInfo>> = _available.asStateFlow()

    private val _installed = MutableStateFlow<List<InstalledPlugin>>(emptyList())
    val installed: StateFlow<List<InstalledPlugin>> = _installed.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _busyIds = MutableStateFlow<Set<String>>(emptySet())
    val busyIds: StateFlow<Set<String>> = _busyIds.asStateFlow()

    private val _selectedLangs = MutableStateFlow<Set<String>>(emptySet())
    val selectedLangs: StateFlow<Set<String>> = _selectedLangs.asStateFlow()

    private var langsLoaded = false

    private fun prefs(context: Context) =
        context.getSharedPreferences("lorelight_browse_prefs", Context.MODE_PRIVATE)

    fun loadInstalled(context: Context) {
        _installed.value = PluginStore.getInstalled(context.applicationContext)
    }

    /** Call once when the Browse tab opens. */
    fun ensureLoaded(context: Context) {
        val appContext = context.applicationContext
        if (!langsLoaded) {
            langsLoaded = true
            val saved = prefs(appContext).getString("selected_langs", null)
            _selectedLangs.value = if (saved == null) setOf("English")
            else saved.split("\u0001").filter { it.isNotBlank() }.toSet()
        }
        loadInstalled(appContext)
        if (_available.value.isEmpty() && !_loading.value) refresh(appContext)
    }

    fun refresh(context: Context) {
        val appContext = context.applicationContext
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                val plugins = withContext(Dispatchers.IO) {
                    PluginRepositoryManager.fetchAllPlugins(appContext)
                }
                _available.value = plugins
                _installed.value = PluginStore.getInstalled(appContext)
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to load plugins"
            } finally {
                _loading.value = false
            }
        }
    }

    fun setLangSelected(context: Context, lang: String, selected: Boolean) {
        val cur = _selectedLangs.value.toMutableSet()
        if (selected) cur.add(lang) else cur.remove(lang)
        _selectedLangs.value = cur
        prefs(context.applicationContext).edit()
            .putString("selected_langs", cur.joinToString("\u0001")).apply()
    }

    fun install(context: Context, info: PluginInfo) {
        val appContext = context.applicationContext
        viewModelScope.launch {
            _busyIds.value = _busyIds.value + info.id
            try {
                PluginManager.installPlugin(appContext, info)
                _installed.value = PluginStore.getInstalled(appContext)
            } finally {
                _busyIds.value = _busyIds.value - info.id
            }
        }
    }

    fun update(context: Context, info: PluginInfo) {
        val appContext = context.applicationContext
        viewModelScope.launch {
            _busyIds.value = _busyIds.value + info.id
            try {
                PluginManager.updatePlugin(appContext, info)
                JSPluginEngine.evict(info.id)
                _installed.value = PluginStore.getInstalled(appContext)
            } finally {
                _busyIds.value = _busyIds.value - info.id
            }
        }
    }

    fun updateAll(context: Context) {
        val appContext = context.applicationContext
        viewModelScope.launch {
            val avail = _available.value.associateBy { it.id }
            val toUpdate = _installed.value.mapNotNull { ip ->
                val latest = avail[ip.info.id]
                if (latest != null && latest.version != ip.installedVersion) latest else null
            }
            for (info in toUpdate) {
                _busyIds.value = _busyIds.value + info.id
                try {
                    PluginManager.updatePlugin(appContext, info)
                    JSPluginEngine.evict(info.id)
                } finally {
                    _busyIds.value = _busyIds.value - info.id
                }
            }
            _installed.value = PluginStore.getInstalled(appContext)
        }
    }

    fun uninstall(context: Context, id: String) {
        val appContext = context.applicationContext
        PluginManager.uninstallPlugin(appContext, id)
        JSPluginEngine.evict(id)
        _installed.value = PluginStore.getInstalled(appContext)
    }

    fun setPinned(context: Context, id: String, pinned: Boolean) {
        val appContext = context.applicationContext
        PluginStore.setPinned(appContext, id, pinned)
        _installed.value = PluginStore.getInstalled(appContext)
    }
}
