package com.lorelight.network

import android.content.Context
import android.content.SharedPreferences
import okhttp3.Interceptor
import okhttp3.MediaType
import okhttp3.Response
import okhttp3.ResponseBody
import okio.Buffer
import okio.BufferedSource
import okio.ForwardingSource
import okio.Source
import okio.buffer

/**
 * Debug-only network speed throttling engine for simulating slow network conditions
 * on demand (e.g. testing progressive image streaming, error handling, and timeout behavior).
 */
object NetworkThrottle {

    private const val PREFS_NAME = "debug_network_prefs"
    const val KEY_THROTTLE_KBPS = "debug_network_throttle_kbps"

    /**
     * The user-facing download speed ceiling, which is a different thing from
     * the dev throttle above: that one simulates a bad network and is gated
     * behind developer mode, this one is a real setting anybody can use to stop
     * a big download job from eating the whole connection.
     */
    const val KEY_DOWNLOAD_LIMIT_KBPS = "download_limit_kbps"

    // Presets in KB/s (0 = Off)
    const val SPEED_OFF = 0
    const val SPEED_VERY_SLOW = 50
    const val SPEED_SLOW = 150
    const val SPEED_MEDIUM = 400

    data class ThrottlePreset(
        val kbps: Int,
        val label: String,
        val description: String
    )

    val PRESETS = listOf(
        ThrottlePreset(SPEED_OFF, "Off", "Unlimited"),
        ThrottlePreset(SPEED_VERY_SLOW, "Very Slow", "~50 KB/s"),
        ThrottlePreset(SPEED_SLOW, "Slow", "~150 KB/s"),
        ThrottlePreset(SPEED_MEDIUM, "Medium", "~400 KB/s")
    )

    @Volatile
    var currentThrottleKbps: Int = SPEED_OFF
        private set

    /** User download speed ceiling in KB/s. 0 = unlimited. */
    @Volatile
    var downloadLimitKbps: Int = SPEED_OFF
        private set

    private fun getPrefs(context: Context): SharedPreferences {
        return context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Initializes the in-memory throttle speed from SharedPreferences.
     */
    fun init(context: Context) {
        currentThrottleKbps = getThrottleKbps(context)
        downloadLimitKbps = getDownloadLimitKbps(context)
    }

    /**
     * Returns the currently configured throttle speed in KB/s (0 = off).
     * Returns 0 (SPEED_OFF) if developer mode is not unlocked.
     */
    fun getThrottleKbps(context: Context): Int {
        if (!com.lorelight.core.DevLogStore.isDevModeUnlocked(context)) {
            currentThrottleKbps = SPEED_OFF
            return SPEED_OFF
        }
        val speed = getPrefs(context).getInt(KEY_THROTTLE_KBPS, SPEED_OFF)
        currentThrottleKbps = speed
        return speed
    }

    /**
     * Sets the throttle speed in KB/s and persists it to SharedPreferences.
     * Takes effect immediately for active and upcoming requests without restarting the app.
     */
    fun setThrottleKbps(context: Context, value: Int) {
        if (!com.lorelight.core.DevLogStore.isDevModeUnlocked(context)) {
            currentThrottleKbps = SPEED_OFF
            getPrefs(context).edit().putInt(KEY_THROTTLE_KBPS, SPEED_OFF).apply()
            return
        }
        currentThrottleKbps = value.coerceAtLeast(0)
        getPrefs(context).edit().putInt(KEY_THROTTLE_KBPS, currentThrottleKbps).apply()
    }

    /**
     * Reads the user's download speed ceiling. Deliberately NOT gated behind
     * developer mode, unlike the throttle above.
     */
    fun getDownloadLimitKbps(context: Context): Int {
        val value = getPrefs(context).getInt(KEY_DOWNLOAD_LIMIT_KBPS, SPEED_OFF).coerceAtLeast(0)
        downloadLimitKbps = value
        return value
    }

    /** Takes effect immediately, including for transfers already in flight. */
    fun setDownloadLimitKbps(context: Context, value: Int) {
        downloadLimitKbps = value.coerceAtLeast(0)
        getPrefs(context).edit().putInt(KEY_DOWNLOAD_LIMIT_KBPS, downloadLimitKbps).apply()
    }

    /**
     * The limit the interceptor actually enforces. Two independent ceilings can
     * be active (the dev simulator and the user's setting), and the correct
     * answer is the tighter of the two, ignoring whichever is off.
     */
    fun effectiveKbps(): Int {
        val dev = currentThrottleKbps
        val user = downloadLimitKbps
        return when {
            dev > 0 && user > 0 -> minOf(dev, user)
            dev > 0 -> dev
            else -> user
        }
    }

    /**
     * Shared global rate limiter across all concurrent connections.
     * Uses a token bucket model with a capped idle burst allowance (max 1 second).
     */
    private object GlobalRateLimiter {
        private val lock = Any()
        private var availableTokens: Double = 0.0
        private var lastNanos: Long = System.nanoTime()

        fun acquire(bytes: Long, kbps: Int) {
            if (kbps <= 0 || bytes <= 0L) return

            var sleepMs = 0L

            synchronized(lock) {
                val now = System.nanoTime()
                val elapsedSec = (now - lastNanos).coerceAtLeast(0L) / 1_000_000_000.0
                lastNanos = now

                val bytesPerSec = kbps * 1024.0
                val maxBurst = maxOf(8192.0, bytesPerSec * 1.0) // cap idle credit accumulation to at most 1 sec

                // Replenish tokens based on elapsed time, capped at maxBurst
                availableTokens = (availableTokens + elapsedSec * bytesPerSec).coerceAtMost(maxBurst)

                // Deduct bytes
                availableTokens -= bytes

                // If tokens are in deficit, sleep for the required duration to pace aggregate throughput
                if (availableTokens < 0) {
                    val deficit = -availableTokens
                    sleepMs = ((deficit / bytesPerSec) * 1000.0).toLong()
                }
            }

            if (sleepMs > 0L) {
                try {
                    Thread.sleep(sleepMs)
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
            }
        }
    }

    /**
     * Creates an OkHttp network interceptor that paces response body streaming
     * according to the configured throughput limit.
     */
    fun createNetworkInterceptor(): Interceptor = ThrottleInterceptor()

    private class ThrottleInterceptor : Interceptor {
        override fun intercept(chain: Interceptor.Chain): Response {
            val response = chain.proceed(chain.request())
            val kbps = effectiveKbps()
            if (kbps <= 0) return response

            val body = response.body ?: return response
            return response.newBuilder()
                .body(ThrottledResponseBody(body) { effectiveKbps() })
                .build()
        }
    }

    private class ThrottledResponseBody(
        private val delegate: ResponseBody,
        private val kbpsProvider: () -> Int
    ) : ResponseBody() {

        private val source: BufferedSource by lazy {
            ThrottledSource(delegate.source(), kbpsProvider).buffer()
        }

        override fun contentType(): MediaType? = delegate.contentType()

        override fun contentLength(): Long = delegate.contentLength()

        override fun source(): BufferedSource = source

        override fun close() {
            delegate.close()
        }
    }

    /**
     * ForwardingSource that paces read() calls against the shared GlobalRateLimiter
     * so aggregate throughput across all concurrent connections stays at or below
     * the configured KB/s without buffering entire responses into memory.
     */
    private class ThrottledSource(
        delegate: Source,
        private val kbpsProvider: () -> Int
    ) : ForwardingSource(delegate) {

        override fun read(sink: Buffer, byteCount: Long): Long {
            val kbps = kbpsProvider()
            if (kbps <= 0) {
                return super.read(sink, byteCount)
            }

            // Read in chunks (max 8KB) to ensure responsive pacing
            val maxChunk = minOf(byteCount, 8192L)
            val readBytes = super.read(sink, maxChunk)
            if (readBytes <= 0L) return readBytes

            // Acquire tokens globally across all concurrent connections
            GlobalRateLimiter.acquire(readBytes, kbps)

            return readBytes
        }
    }
}
