package com.lorelight.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.ui.theme.*
import com.lorelight.ui.reader.ReaderViewModel
import androidx.compose.ui.semantics.Role

@Composable
fun AppearanceSettingsSection(
    readerViewModel: ReaderViewModel
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "APPEARANCE & PALETTE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(start = 4.dp, top = 8.dp)
        )

        AppearanceThemeControls(readerViewModel)

        // How much the app is allowed to move at all
        MotionSettingsCard()

        // Which animation plays when the sun / moon in the bottom bar is tapped
        com.lorelight.ui.theme.modeswitch.ModeSwitchAnimationSettings(readerViewModel = readerViewModel)
    }
}

/**
 * The same theme and display-mode controls are used by Settings and onboarding.
 * Both edit ReaderViewModel's persisted values, including highlight colours.
 * Motion/animation settings deliberately remain in the full Settings section.
 */
@Composable
fun AppearanceThemeControls(readerViewModel: ReaderViewModel) {
    val activeTheme by readerViewModel.appTheme.collectAsState()
    // FIX B14: was `val isLightMode = false`. Every swatch below already has a
    // light and a dark variant; only the dark one was ever reachable.
    val themeMode by readerViewModel.appThemeMode.collectAsState()
    val systemInDark = androidx.compose.foundation.isSystemInDarkTheme()
    val isLightMode = when (themeMode) {
        "Light" -> true
        "Dark" -> false
        else -> !systemInDark
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Theme selector first: picking a color is the main reason people open
        // this page, so it sits at the top.
        ThemeSelectorCard(readerViewModel, activeTheme, isLightMode)

        // FIX B14: new control. Light / Dark / System now actually switches the
        // palette, instead of the app being locked to dark.
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isLightMode) Icons.Default.WbSunny else Icons.Default.NightsStay,
                            contentDescription = "Display mode",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Display Mode",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = when (themeMode) {
                                "Light" -> "Light palette of the selected theme"
                                "Dark" -> "Dark palette of the selected theme"
                                else -> "Follows your device light / dark setting"
                            },
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Was three hand-rolled boxes with an instant colour swap.
                // Now the one shared animated control, so this row, the
                // library's Novels/Manga pills and the browse tabs look and
                // behave identically.
                com.lorelight.ui.components.LorelightSegmentedControl(
                    options = listOf("System", "Light", "Dark"),
                    selected = when (themeMode) {
                        "Light" -> "Light"
                        "Dark" -> "Dark"
                        else -> "System"
                    },
                    onSelect = { mode -> readerViewModel.appThemeMode.value = mode },
                    height = 42.dp,
                    cornerRadius = 12.dp,
                    fontSize = 12.sp
                )
            }
        }
    }
}

/**
 * Motion & performance.
 *
 * Lorelight animates a lot on purpose, but there was no way to turn any of it
 * down: no reduced-motion option for people who get motion sick, and nothing
 * that eased off on older phones or on low battery. This one control feeds
 * every animated surface in the app through LocalMotionLevel.
 */
@Composable
private fun MotionSettingsCard() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val settingsVersion by com.lorelight.data.local.AppSettingsSignal.version.collectAsState()
    val storedLabel = remember(settingsVersion) {
        motionPreferenceValueToLabel(readMotionPreference(context))
    }
    val effective = LocalMotionLevel.current

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PhoneAndroid,
                        contentDescription = "Motion",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Motion & Performance",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = when (storedLabel) {
                            "Auto" ->
                                "Follows your device - currently ${effective.label.lowercase()}"
                            "Full" -> "Every animation and effect, as designed"
                            "Reduced" -> "Shorter transitions, no looping or ambient effects"
                            else -> "Almost still. Best on low battery or older devices"
                        },
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            com.lorelight.ui.components.LorelightSegmentedControl(
                options = motionPreferenceLabels,
                selected = storedLabel,
                onSelect = { label ->
                    writeMotionPreference(context, motionPreferenceLabelToValue(label))
                },
                height = 42.dp,
                cornerRadius = 12.dp,
                fontSize = 10.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Applies to the theme switch, the companion, glass blur, " +
                    "hero parallax, shimmer placeholders and list entrances. " +
                    "Auto also picks up your device's \"remove animations\" " +
                    "setting and battery saver.",
                fontSize = 10.sp,
                lineHeight = 15.sp,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
    }
}

// Selected Theme Card with visual cue and chooser. Split out of the section
// body so it can be ordered independently of the other cards.
@Composable
private fun ThemeSelectorCard(
    readerViewModel: ReaderViewModel,
    activeTheme: String,
    isLightMode: Boolean
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        border = borderIndicator(),
        modifier = Modifier.fillMaxWidth()
    ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = "Theme",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Active Theme Color",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = when (activeTheme) {
                                "blackgold" -> "Black Gold (Premium Gold & Ivory)"
                                "Satin Pink" -> "Satin Pink (Plum & Velvet Rose)"
                                "readerblacknew" -> "Black (Midnight OLED & Pure Dark)"
                                "Ocean Blue" -> "Ocean Blue (Marine & Deep Sea)"
                                "cyne" -> "Cyan (Electric Turquoise & Sea)"
                                "readerpurple" -> "Purple (Amethyst & Orchid)"
                                "readerwhite" -> "Creme White (Porcelain & Soft Sand)"
                                "readerblood" -> "Blood Red (Crimson & Coral)"
                                else -> "Forest Green (Lush Wood & Pines)"
                            },
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(
                                when (activeTheme) {
                                    "blackgold" -> if (isLightMode) Color(0xFF855D1F) else Color(0xFFE1B970)
                                    "Satin Pink" -> if (isLightMode) Color(0xFF90325A) else Color(0xFFFFB0D0)
                                    "readerblacknew" -> if (isLightMode) Color(0xFF1C1C1E) else Color(0xFF888888)
                                    "Ocean Blue" -> if (isLightMode) Color(0xFF1B5985) else Color(0xFF81C7F4)
                                    "cyne" -> if (isLightMode) Color(0xFF005E68) else Color(0xFF62D2DF)
                                    "readerpurple" -> if (isLightMode) Color(0xFF671499) else Color(0xFFD59DFB)
                                    "readerwhite" -> if (isLightMode) Color(0xFF38312B) else Color(0xFFECE3D5)
                                    "readerblood" -> if (isLightMode) Color(0xFF9E1F2D) else Color(0xFFFA5F70)
                                    else -> if (isLightMode) Color(0xFF3F631C) else Color(0xFF75974D)
                                }
                            )
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                val themeOptions = remember(isLightMode) {
                    listOf(
                        com.lorelight.ui.settings.ThemeOption("forest", "Forest", RefinedForestGradient, if (isLightMode) Color(0xFF3F631C) else Color(0xFF1B5E20), if (isLightMode) Color(0xFF81C784) else Color(0xFF4CAF50), 0xFF2E7D32L, 0xFF81C784L, if (isLightMode) Color(0xFF3F631C) else Color(0xFF1B5E20)),
                        com.lorelight.ui.settings.ThemeOption("blackgold", "Gold", RefinedGoldGradient, if (isLightMode) Color(0xFF855D1F) else Color(0xFF2E1901), if (isLightMode) Color(0xFFE1B970) else Color(0xFFE1B970), 0xFFE1B970L, 0xFFFFD700L, if (isLightMode) Color(0xFF855D1F) else Color(0xFF2E1901)),
                        com.lorelight.ui.settings.ThemeOption("Satin Pink", "Satin Pink", RefinedPinkGradient, if (isLightMode) Color(0xFF90325A) else Color(0xFF4A0E23), if (isLightMode) Color(0xFFFFB0D0) else Color(0xFFFFB0D0), 0xFFFFB0D0L, 0xFFFFC2DCL, if (isLightMode) Color(0xFF90325A) else Color(0xFF4A0E23)),
                        com.lorelight.ui.settings.ThemeOption("readerblacknew", "Black", RefinedMidnightGradient, if (isLightMode) Color(0xFF1C1C1E) else Color(0xFF121212), if (isLightMode) Color(0xFF888888) else Color(0xFF888888), 0xFF888888L, 0xFFCCCCCCL, if (isLightMode) Color(0xFF1C1C1E) else Color(0xFF000000)),
                        com.lorelight.ui.settings.ThemeOption("Ocean Blue", "Ocean", RefinedOceanGradient, if (isLightMode) Color(0xFF1B5985) else Color(0xFF002171), if (isLightMode) Color(0xFF81C7F4) else Color(0xFF81C7F4), 0xFF0D47A1L, 0xFF1976D2L, if (isLightMode) Color(0xFF1B5985) else Color(0xFF002171)),
                        com.lorelight.ui.settings.ThemeOption("cyne", "Cyan", RefinedCyanGradient, if (isLightMode) Color(0xFF005E68) else Color(0xFF00363A), if (isLightMode) Color(0xFF62D2DF) else Color(0xFF62D2DF), 0xFF006064L, 0xFF00838FL, if (isLightMode) Color(0xFF005E68) else Color(0xFF00363A)),
                        com.lorelight.ui.settings.ThemeOption("readerpurple", "Purple", RefinedPurpleGradient, if (isLightMode) Color(0xFF671499) else Color(0xFF30003C), if (isLightMode) Color(0xFFD59DFB) else Color(0xFFD500F9), 0xFF4A148CL, 0xFFEA80FCL, if (isLightMode) Color(0xFF671499) else Color(0xFF30003C)),
                        com.lorelight.ui.settings.ThemeOption("readerblood", "Blood Red", RefinedBloodGradient, if (isLightMode) Color(0xFF9E1F2D) else Color(0xFFFA5F70), if (isLightMode) Color(0xFFFA5F70) else Color(0xFFFA5F70), 0xFFFA5F70L, 0xFFFFB3BCL, if (isLightMode) Color(0xFF9E1F2D) else Color(0xFF3F000A))
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    themeOptions.chunked(3).forEach { rowThemes ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowThemes.forEach { theme ->
                                val isActive = if (theme.id == "forest") {
                                    activeTheme != "blackgold" && activeTheme != "Satin Pink" && activeTheme != "readerblacknew" && activeTheme != "Ocean Blue" && activeTheme != "cyne" && activeTheme != "readerpurple" && activeTheme != "readerblood"
                                } else {
                                    activeTheme == theme.id
                                }
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(12.dp))
                                        .then(
                                            if (isActive) {
                                                Modifier.background(theme.gradient)
                                            } else {
                                                Modifier.background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                            }
                                        )
                                        .border(
                                            1.dp,
                                            if (isActive) Color.Transparent else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f),
                                            RoundedCornerShape(12.dp)
                                        )
                                        .clickable(role = Role.Button) {
                                            readerViewModel.appTheme.value = theme.id
                                            readerViewModel.readerHighlightColor.value = theme.highlightColor
                                            readerViewModel.customHighlightColor.value = theme.customHighlightColor
                                        }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(CircleShape)
                                                .background(if (isActive) theme.dotColorActive else theme.dotColorInactive)
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = theme.label,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isActive) theme.textOnActive else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                            maxLines = 1,
                                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                            // Keep every swatch the same width: pad short rows
                            // with invisible fillers instead of letting the
                            // last two swatches stretch.
                            repeat(3 - rowThemes.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
    }
}

data class ThemeOption(
    val id: String,
    val label: String,
    val gradient: androidx.compose.ui.graphics.Brush,
    val dotColorActive: Color,
    val dotColorInactive: Color,
    val highlightColor: Long,
    val customHighlightColor: Long,
    val textOnActive: Color
)
