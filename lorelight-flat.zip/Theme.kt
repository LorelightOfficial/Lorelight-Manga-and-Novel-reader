package com.lorelight.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.animation.animateColorAsState

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush

// Forest Green Theme
val ForestPrimary = Color(0xFF75974D)
val ForestPrimaryLight = Color(0xFF566B21)

val ForestDarkScheme = darkColorScheme(
    primary = ForestPrimary,
    onPrimary = Color(0xFF0D1A11),
    primaryContainer = Color(0xFF1B3224),
    onPrimaryContainer = ForestPrimary,
    secondary = Color(0xFF6DA17F),
    onSecondary = Color(0xFF0B190E),
    secondaryContainer = Color(0xFF142918),
    onSecondaryContainer = Color(0xFF6DA17F),
    background = Color(0xFF050907),
    onBackground = Color(0xFFDEEBE2),
    surface = Color(0xFF0A1410),
    onSurface = Color(0xFFDEEBE2),
    surfaceVariant = Color(0xFF111E17),
    onSurfaceVariant = Color(0xFFACC2B6),
    outline = Color(0xFF233A2D)
)

val ForestLightScheme = lightColorScheme(
    primary = ForestPrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFDCE3C0),
    onPrimaryContainer = Color(0xFF293A00),
    secondary = Color(0xFF6E7654),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFE9EDD9),
    onSecondaryContainer = Color(0xFF394124),
    background = Color(0xFFF7F8F4),
    onBackground = Color(0xFF292E1B),
    surface = Color(0xFFFCFCFA),
    onSurface = Color(0xFF292E1B),
    surfaceVariant = Color(0xFFEBEEE2),
    onSurfaceVariant = Color(0xFF5E634F),
    outline = Color(0xFFB5B7AA),
    outlineVariant = Color(0xFFDFE0D8)
)

// Black Gold Theme
val BlackGoldPrimary = Color(0xFFFFD580)
val BlackGoldPrimaryLight = Color(0xFFB8860B)

val BlackGoldDarkScheme = darkColorScheme(
    primary = BlackGoldPrimary,
    onPrimary = Color(0xFF2E1A00),
    primaryContainer = Color(0xFF4D2F02),
    onPrimaryContainer = Color(0xFFFFECC4),
    secondary = Color(0xFFE1B970),
    onSecondary = Color(0xFF2A1C00),
    secondaryContainer = Color(0xFF4A3410),
    onSecondaryContainer = Color(0xFFE1B970),
    background = Color(0xFF0E0B08),
    onBackground = Color(0xFFFFF8EE),
    surface = Color(0xFF191410),
    onSurface = Color(0xFFFFF8EE),
    surfaceVariant = Color(0xFF261E18),
    onSurfaceVariant = Color(0xFFDFCCA8),
    outline = Color(0xFF423321)
)

val BlackGoldLightScheme = lightColorScheme(
    primary = BlackGoldPrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFE29A),
    onPrimaryContainer = Color(0xFF4A3200),
    secondary = Color(0xFF9C6F1E),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFFE8B8),
    onSecondaryContainer = Color(0xFF4D3600),
    background = Color(0xFFFFFAF0),
    onBackground = Color(0xFF2E2211),
    surface = Color(0xFFFFFDF8),
    onSurface = Color(0xFF2E2211),
    surfaceVariant = Color(0xFFF6E7C9),
    onSurfaceVariant = Color(0xFF6E5A2E),
    outline = Color(0xFFC7AD7C),
    outlineVariant = Color(0xFFEBDDBC)
)

// Satin Pink Theme
val PinkPrimary = Color(0xFFFFB0D0)
val PinkPrimaryLight = Color(0xFFD6336C)

val SatinPinkDarkScheme = darkColorScheme(
    primary = PinkPrimary,
    onPrimary = Color(0xFF4A102D),
    primaryContainer = Color(0xFF6D1B43),
    onPrimaryContainer = Color(0xFFFFD0E0),
    secondary = Color(0xFFFF8DA1),
    onSecondary = Color(0xFF4E0827),
    secondaryContainer = Color(0xFF6F1739),
    onSecondaryContainer = Color(0xFFFFD0E0),
    background = Color(0xFF0F080B),
    onBackground = Color(0xFFFFF0F5),
    surface = Color(0xFF1A0E13),
    onSurface = Color(0xFFFFF0F5),
    surfaceVariant = Color(0xFF29151E),
    onSurfaceVariant = Color(0xFFE5BCCB),
    outline = Color(0xFF4F263C)
)

// REMADE FROM THE STATUS BAR TINT. MainActivity paints the light-mode status
// bar strip for this theme with Color(0xFFF3B0A1) -- a warm, dusty coral-pink
// sampled straight off the theme's own light hero banner. The light palette
// below is rebuilt from that exact colour as its seed/primary, instead of the
// old cooler magenta-pink primary, so the whole light scheme now reads as a
// continuation of that banner colour rather than a separate, unrelated pink.
val PinkStatusBarSeed = Color(0xFFF3B0A1)

val SatinPinkLightScheme = lightColorScheme(
    primary = PinkStatusBarSeed,
    onPrimary = Color(0xFF5C1B10),
    primaryContainer = Color(0xFFFFDBD2),
    onPrimaryContainer = Color(0xFF5C1B10),
    secondary = Color(0xFFC97158),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFFE4DA),
    onSecondaryContainer = Color(0xFF63291A),
    background = Color(0xFFFFF6F3),
    onBackground = Color(0xFF3D2620),
    surface = Color(0xFFFFFBF9),
    onSurface = Color(0xFF3D2620),
    surfaceVariant = Color(0xFFFBE4DC),
    onSurfaceVariant = Color(0xFF7C5A4F),
    outline = Color(0xFFCFA095),
    outlineVariant = Color(0xFFF0D8CF)
)

// Black (Midnight/OLED) Theme
val BlackNewPrimary = Color(0xFFFFFFFF)
val BlackNewPrimaryLight = Color(0xFF1C1C1C)

// TRUE AMOLED. Only `background` used to be #000000; every surface the UI
// actually paints -- cards, glass panels, bars, chips -- came from `surface`
// (#0C0C0C), `surfaceVariant` (#1A1A1A), `primaryContainer` (#2D2D2D) and
// `secondaryContainer` (#1F1F1F). GlassPanel compounds it, because in dark
// mode its container is `surface.copy(alpha = tintAlpha)`. So the panel the
// user looks at was grey even though the wallpaper behind it was black, and
// an OLED panel never got to switch its pixels off.
//
// Fills are now pure black. Separation comes from `outline`, which is a
// 1px stroke rather than a filled region, so it costs no lit pixels worth
// mentioning while keeping cards distinguishable.
val BlackDarkScheme = darkColorScheme(
    primary = BlackNewPrimary,
    onPrimary = Color(0xFF000000),
    primaryContainer = Color(0xFF000000),
    onPrimaryContainer = BlackNewPrimary,
    secondary = Color(0xFFCCCCCC),
    onSecondary = Color(0xFF000000),
    secondaryContainer = Color(0xFF000000),
    onSecondaryContainer = Color(0xFFD4D4D4),
    background = Color(0xFF000000),
    onBackground = Color(0xFFF3F4F6),
    surface = Color(0xFF000000),
    onSurface = Color(0xFFF3F4F6),
    surfaceVariant = Color(0xFF000000),
    onSurfaceVariant = Color(0xFF9CA3AF),
    outline = Color(0xFF3A3A3A),
    outlineVariant = Color(0xFF242424),
    surfaceContainer = Color(0xFF000000),
    surfaceContainerHigh = Color(0xFF000000),
    surfaceContainerHighest = Color(0xFF050505),
    surfaceContainerLow = Color(0xFF000000),
    surfaceContainerLowest = Color(0xFF000000),
    surfaceBright = Color(0xFF0A0A0A),
    surfaceDim = Color(0xFF000000),
    inverseSurface = Color(0xFFE5E5E5),
    inverseOnSurface = Color(0xFF000000),
    scrim = Color(0xFF000000),
    // The single biggest reason this theme looked grey. Material 3 tints any
    // surface that has tonal elevation with `surfaceTint`, which DEFAULTS TO
    // `primary`. Here primary is pure white, so every elevated Card, Surface,
    // menu, sheet and bar had a white veil blended over it -- the higher the
    // elevation, the greyer it got. Pinning it to black disables the overlay.
    surfaceTint = Color(0xFF000000)
)

val BlackLightScheme = lightColorScheme(
    primary = BlackNewPrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE3E3E3),
    onPrimaryContainer = Color(0xFF1A1A1A),
    secondary = Color(0xFF4A4A4A),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFEDEDED),
    onSecondaryContainer = Color(0xFF2A2A2A),
    background = Color(0xFFFFFFFF),
    onSurface = Color(0xFF111111),
    surface = Color(0xFFFFFFFF),
    onBackground = Color(0xFF111111),
    surfaceVariant = Color(0xFFEDEDED),
    onSurfaceVariant = Color(0xFF4A4A4A),
    outline = Color(0xFFB0B0B0),
    outlineVariant = Color(0xFFDCDCDC)
)

// Ocean Blue Theme
val OceanPrimary = Color(0xFF81C7F4)
val OceanPrimaryLight = Color(0xFF0077C8)

val OceanBlueDarkScheme = darkColorScheme(
    primary = OceanPrimary,
    onPrimary = Color(0xFF003354),
    primaryContainer = Color(0xFF004D7C),
    onPrimaryContainer = Color(0xFFCDE5FF),
    secondary = Color(0xFF5C93E2),
    onSecondary = Color(0xFF00224D),
    secondaryContainer = Color(0xFF003D80),
    onSecondaryContainer = Color(0xFFCDE5FF),
    background = Color(0xFF060B12),
    onBackground = Color(0xFFECF5FF),
    surface = Color(0xFF0E1624),
    onSurface = Color(0xFFECF5FF),
    surfaceVariant = Color(0xFF162338),
    onSurfaceVariant = Color(0xFFA9CBEA),
    outline = Color(0xFF203A58)
)

val OceanBlueLightScheme = lightColorScheme(
    primary = OceanPrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFC7E4FF),
    onPrimaryContainer = Color(0xFF00335A),
    secondary = Color(0xFF0091D5),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFCDEEFF),
    onSecondaryContainer = Color(0xFF00344D),
    background = Color(0xFFF3F9FF),
    onBackground = Color(0xFF102436),
    surface = Color(0xFFFBFDFF),
    onSurface = Color(0xFF102436),
    surfaceVariant = Color(0xFFDCEBFB),
    onSurfaceVariant = Color(0xFF41566B),
    outline = Color(0xFF9BB4CB),
    outlineVariant = Color(0xFFD3E4F0)
)

// Cyan Theme
val CyanPrimary = Color(0xFF54D6E4)
val CyanPrimaryLight = Color(0xFF00838F)

val CyanDarkScheme = darkColorScheme(
    primary = CyanPrimary,
    onPrimary = Color(0xFF00353B),
    primaryContainer = Color(0xFF004D54),
    onPrimaryContainer = CyanPrimary,
    secondary = Color(0xFF3BBFA5),
    onSecondary = Color(0xFF003729),
    secondaryContainer = Color(0xFF004F3D),
    onSecondaryContainer = Color(0xFF4DBC9E),
    background = Color(0xFF040A0F),
    onBackground = Color(0xFFE2FAF9),
    surface = Color(0xFF0A141C),
    onSurface = Color(0xFFE2FAF9),
    surfaceVariant = Color(0xFF12202B),
    onSurfaceVariant = Color(0xFFA2CCD4),
    outline = Color(0xFF1C3A44)
)

val CyanLightScheme = lightColorScheme(
    primary = CyanPrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFB0EEF5),
    onPrimaryContainer = Color(0xFF00363D),
    secondary = Color(0xFF00ACC1),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFC3F1F7),
    onSecondaryContainer = Color(0xFF00373F),
    background = Color(0xFFF0FBFC),
    onBackground = Color(0xFF0D2A2E),
    surface = Color(0xFFFAFEFE),
    onSurface = Color(0xFF0D2A2E),
    surfaceVariant = Color(0xFFD6EEF1),
    onSurfaceVariant = Color(0xFF3D5B60),
    outline = Color(0xFF8FB6BB),
    outlineVariant = Color(0xFFCCE5E8)
)

// Purple Theme
val PurplePrimary = Color(0xFFD59DFB)
val PurplePrimaryLight = Color(0xFF8E24AA)

val PurpleDarkScheme = darkColorScheme(
    primary = PurplePrimary,
    onPrimary = Color(0xFF380044),
    primaryContainer = Color(0xFF530063),
    onPrimaryContainer = PurplePrimary,
    secondary = Color(0xFFB388FF),
    onSecondary = Color(0xFF22004D),
    secondaryContainer = Color(0xFF3D0080),
    onSecondaryContainer = Color(0xFFB693FE),
    background = Color(0xFF080510),
    onBackground = Color(0xFFFAF4FF),
    surface = Color(0xFF110B22),
    onSurface = Color(0xFFFAF4FF),
    surfaceVariant = Color(0xFF1C1236),
    onSurfaceVariant = Color(0xFFDAC6F2),
    outline = Color(0xFF2E1C4B)
)

val PurpleLightScheme = lightColorScheme(
    primary = PurplePrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFF2CFFF),
    onPrimaryContainer = Color(0xFF4A0060),
    secondary = Color(0xFFAB47BC),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFF6DBFF),
    onSecondaryContainer = Color(0xFF4E1361),
    background = Color(0xFFFCF6FE),
    onBackground = Color(0xFF2C1533),
    surface = Color(0xFFFEFAFF),
    onSurface = Color(0xFF2C1533),
    surfaceVariant = Color(0xFFEEDFF3),
    onSurfaceVariant = Color(0xFF5C4C63),
    outline = Color(0xFFB39CBB),
    outlineVariant = Color(0xFFE2D3E6)
)

// Creme White Theme
val WhitePrimary = Color(0xFF8A5A2B)
val CremeWhiteDarkPrimary = Color(0xFFECE3D5)

val CremeWhiteDarkScheme = darkColorScheme(
    primary = CremeWhiteDarkPrimary,
    onPrimary = Color(0xFF261D12),
    primaryContainer = Color(0xFF3E3324),
    onPrimaryContainer = CremeWhiteDarkPrimary,
    secondary = Color(0xFFC7B7A3),
    onSecondary = Color(0xFF241B10),
    secondaryContainer = Color(0xFF362C1E),
    onSecondaryContainer = Color(0xFFC7B7A3),
    background = Color(0xFF13110E),
    onBackground = Color(0xFFFAF6EE),
    surface = Color(0xFF1C1915),
    onSurface = Color(0xFFFAF6EE),
    surfaceVariant = Color(0xFF2B251F),
    onSurfaceVariant = Color(0xFFC7B7A3),
    outline = Color(0xFF3F372F)
)

val CremeWhiteLightScheme = lightColorScheme(
    primary = WhitePrimary,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFE1B8),
    onPrimaryContainer = Color(0xFF3D2200),
    secondary = Color(0xFFA9762E),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFFEAC4),
    onSecondaryContainer = Color(0xFF402C00),
    background = Color(0xFFFBF3E3),
    onBackground = Color(0xFF2E2211),
    surface = Color(0xFFFFFAF0),
    onSurface = Color(0xFF2E2211),
    surfaceVariant = Color(0xFFF3E4C8),
    onSurfaceVariant = Color(0xFF6B5738),
    outline = Color(0xFFD8BE93),
    outlineVariant = Color(0xFFEDDDBC)
)

// Blood Red Theme
val BloodPrimary = Color(0xFFFF1F3D)
val BloodPrimaryLight = Color(0xFFC00021)

val BloodRedDarkScheme = darkColorScheme(
    primary = BloodPrimary,
    onPrimary = Color(0xFF3D000A),
    primaryContainer = Color(0xFF7A0012),
    onPrimaryContainer = Color(0xFFFFB3BA),
    secondary = Color(0xFFE0102C),
    onSecondary = Color(0xFF330008),
    secondaryContainer = Color(0xFF5C000E),
    onSecondaryContainer = Color(0xFFFF8B96),
    background = Color(0xFF0A0203),
    onBackground = Color(0xFFFFEBEC),
    surface = Color(0xFF160607),
    onSurface = Color(0xFFFFEBEC),
    surfaceVariant = Color(0xFF2E0A0D),
    onSurfaceVariant = Color(0xFFDB9BA0),
    outline = Color(0xFF5C1218)
)

val BloodRedLightScheme = lightColorScheme(
    primary = BloodPrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFD4D8),
    onPrimaryContainer = Color(0xFF5C0011),
    secondary = Color(0xFF9C0E24),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFFDBDF),
    onSecondaryContainer = Color(0xFF52000D),
    background = Color(0xFFFFF5F5),
    onBackground = Color(0xFF3A0508),
    surface = Color(0xFFFFFBFB),
    onSurface = Color(0xFF3A0508),
    surfaceVariant = Color(0xFFFCDEE1),
    onSurfaceVariant = Color(0xFF75444A),
    outline = Color(0xFFC79BA0),
    outlineVariant = Color(0xFFEBD3D6)
)

// Gradients
val RefinedCyanGradient = Brush.linearGradient(colors = listOf(Color(0xFF4DB6AC), Color(0xFF62D2DF), Color(0xFFB2DFDB)))
val CyanOnGradient = Color(0xFF00353A)

val RefinedPurpleGradient = Brush.linearGradient(colors = listOf(Color(0xFF9575CD), Color(0xFFD59DFB), Color(0xFFEDE7F6)))
val PurpleOnGradient = Color(0xFF380041)

val RefinedWhiteGradient = Brush.linearGradient(colors = listOf(Color(0xFFE8E4DC), Color(0xFFFAF7F2), Color(0xFFFFFFFF)))
val WhiteOnGradient = Color(0xFF262626)

val RefinedBloodGradient = Brush.linearGradient(colors = listOf(Color(0xFF98001C), Color(0xFFFA5F70), Color(0xFFFFB3BC)))
val BloodOnGradient = Color(0xFF3F000A)

val RefinedGoldGradient = Brush.linearGradient(colors = listOf(Color(0xFFC59832), Color(0xFFE5B942), Color(0xFFF5D68F)))
val GoldOnGradient = Color(0xFF1E1405)

val RefinedPinkGradient = Brush.linearGradient(colors = listOf(Color(0xFFDC829F), Color(0xFFEFA5C0), Color(0xFFFFCBDC)))
val PinkOnGradient = Color(0xFF3B0B24)

val RefinedMidnightGradient = Brush.linearGradient(colors = listOf(Color(0xFFBCBCC0), Color(0xFFD8D8DC), Color(0xFFF2F2F7)))
val MidnightOnGradient = Color(0xFF000000)

val RefinedOceanGradient = Brush.linearGradient(colors = listOf(Color(0xFF4DA6FF), Color(0xFF7AD3FF), Color(0xFFA1ECFF)))
val OceanOnGradient = Color(0xFF001F3F)

val RefinedForestGradient = Brush.linearGradient(colors = listOf(Color(0xFF5B7A3E), Color(0xFF75974D), Color(0xFF9EBA7B)))
val ForestOnGradient = Color(0xFF0C1B0E)

// Backwards compatibility declarations
val SophisticatedDarkScheme = ForestDarkScheme
val BlackGoldScheme = BlackGoldDarkScheme
val SatinPinkScheme = SatinPinkDarkScheme
val MidnightBlackScheme = BlackDarkScheme
val BlackNewScheme = BlackDarkScheme
val OceanBlueScheme = OceanBlueDarkScheme
val CyanScheme = CyanDarkScheme
val PurpleScheme = PurpleDarkScheme
val WhiteScheme = CremeWhiteLightScheme
val BloodRedScheme = BloodRedDarkScheme

val ForestBackground = Color(0xFF050907)
val ForestSurface = Color(0xFF0A1410)
val ForestSurfaceVariant = Color(0xFF111E17)
val ForestBorder = Color(0xFF233A2D)

val BlackGoldBackground = Color(0xFF0E0B08)
val BlackGoldSurface = Color(0xFF191410)
val BlackGoldSurfaceVariant = Color(0xFF261E18)
val BlackGoldBorder = Color(0xFF423321)

val PinkBackground = Color(0xFF0F080B)
val PinkSurface = Color(0xFF1A0E13)
val PinkSurfaceVariant = Color(0xFF29151E)
val PinkBorder = Color(0xFF4F263C)

val BlackNewBackground = Color(0xFF000000)
val BlackNewSurface = Color(0xFF0C0C0C)
val BlackNewSurfaceVariant = Color(0xFF1A1A1A)
val BlackNewBorder = Color(0xFF2E2E2E)

val MidnightBackground = BlackNewBackground
val MidnightSurface = BlackNewSurface
val MidnightSurfaceVariant = BlackNewSurfaceVariant
val MidnightPrimary = BlackNewPrimary
val MidnightOnBackground = Color(0xFFF3F4F6)
val MidnightOnSurfaceVariant = Color(0xFF9CA3AF)
val MidnightBorder = BlackNewBorder

val OceanBackground = Color(0xFF060B12)
val OceanSurface = Color(0xFF0E1624)
val OceanSurfaceVariant = Color(0xFF162338)
val OceanBorder = Color(0xFF203A58)

val CyanBackground = Color(0xFF040A0F)
val CyanSurface = Color(0xFF0A141C)
val CyanSurfaceVariant = Color(0xFF12202B)
val CyanBorder = Color(0xFF1C3A44)

val PurpleBackground = Color(0xFF080510)
val PurpleSurface = Color(0xFF110B22)
val PurpleSurfaceVariant = Color(0xFF1C1236)
val PurpleBorder = Color(0xFF2E1C4B)

val WhiteBackground = Color(0xFFFAF7F2)
val WhiteSurface = Color(0xFFF1EDE4)
val WhiteSurfaceVariant = Color(0xFFE6DEC9)
val WhiteOnBackground = Color(0xFF2F241A)
val WhiteOnSurfaceVariant = Color(0xFF5E4E3F)
val WhiteBorder = Color(0xFFD2C1A8)

val BloodBackground = Color(0xFF0C0304)
val BloodSurface = Color(0xFF1A080A)
val BloodSurfaceVariant = Color(0xFF2A0F11)
val BloodBorder = Color(0xFF4A1A1D)

@Composable
fun ColorScheme.animated(): ColorScheme {
    val spec = androidx.compose.animation.core.tween<Color>(durationMillis = 450)
    return copy(
        primary = animateColorAsState(primary, spec, label = "primary").value,
        onPrimary = animateColorAsState(onPrimary, spec, label = "onPrimary").value,
        secondary = animateColorAsState(secondary, spec, label = "secondary").value,
        background = animateColorAsState(background, spec, label = "background").value,
        onBackground = animateColorAsState(onBackground, spec, label = "onBackground").value,
        surface = animateColorAsState(surface, spec, label = "surface").value,
        onSurface = animateColorAsState(onSurface, spec, label = "onSurface").value,
        surfaceVariant = animateColorAsState(surfaceVariant, spec, label = "surfaceVariant").value,
        onSurfaceVariant = animateColorAsState(onSurfaceVariant, spec, label = "onSurfaceVariant").value
    )
}

fun getAppColorScheme(theme: String, isLightMode: Boolean): ColorScheme {
    return if (isLightMode) {
        when (theme) {
            "blackgold" -> BlackGoldLightScheme
            "Satin Pink" -> SatinPinkLightScheme
            "readerblacknew" -> BlackLightScheme
            "Ocean Blue" -> OceanBlueLightScheme
            "cyne" -> CyanLightScheme
            "readerpurple" -> PurpleLightScheme
            "readerblood" -> BloodRedLightScheme
            else -> ForestLightScheme
        }
    } else {
        when (theme) {
            "blackgold" -> BlackGoldDarkScheme
            "Satin Pink" -> SatinPinkDarkScheme
            "readerblacknew" -> BlackDarkScheme
            "Ocean Blue" -> OceanBlueDarkScheme
            "cyne" -> CyanDarkScheme
            "readerpurple" -> PurpleDarkScheme
            "readerblood" -> BloodRedDarkScheme
            else -> ForestDarkScheme
        }
    }
}

fun getThemedButtonProps(primary: Color, fallbackContent: Color = Color.Black): Triple<Boolean, Brush, Color> {
    // FIX: these matches only ever listed each theme's DARK-mode primary
    // color. In light mode, ColorScheme.primary is a different (lighter)
    // color per theme, so it always missed every branch and fell through to
    // the plain "else" case below -- a flat solid color with no gradient at
    // all. Each theme's light-mode primary is now matched to the exact same
    // gradient/on-gradient pair as its dark counterpart, so light mode gets
    // a real gradient too.
    val isPremium = primary == Color(0xFFF3C77D) || primary == Color(0xFFFFD580) ||
                    primary == Color(0xFFFFB0D0) || 
                    primary == Color(0xFFE5E5E5) ||
                    primary == Color(0xFF6ABFFF) ||
                    primary == ForestPrimary ||
                    primary == Color(0xFF00E5FF) ||
                    primary == Color(0xFFD500F9) ||
                    primary == Color(0xFF1A1A1A) ||
                    primary == Color(0xFFFF3333) ||
                    primary == BloodPrimary ||
                    primary == BlackGoldPrimaryLight ||
                    primary == PinkStatusBarSeed ||
                    primary == BlackNewPrimaryLight ||
                    primary == OceanPrimaryLight ||
                    primary == ForestPrimaryLight ||
                    primary == CyanPrimaryLight ||
                    primary == PurplePrimaryLight ||
                    primary == WhitePrimary ||
                    primary == BloodPrimaryLight
    val gradient = when (primary) {
        Color(0xFFF3C77D), Color(0xFFFFD580), BlackGoldPrimaryLight -> RefinedGoldGradient
        Color(0xFFFFB0D0), PinkStatusBarSeed -> RefinedPinkGradient
        Color(0xFFE5E5E5), BlackNewPrimaryLight -> RefinedMidnightGradient
        Color(0xFF6ABFFF), OceanPrimaryLight -> RefinedOceanGradient
        ForestPrimary, ForestPrimaryLight -> RefinedForestGradient
        Color(0xFF00E5FF), CyanPrimaryLight -> RefinedCyanGradient
        Color(0xFFD500F9), PurplePrimaryLight -> RefinedPurpleGradient
        Color(0xFF1A1A1A), WhitePrimary -> RefinedWhiteGradient
        Color(0xFFFF3333), BloodPrimary, BloodPrimaryLight -> RefinedBloodGradient
        else -> Brush.linearGradient(colors = listOf(primary, primary))
    }
    val contentColor = when (primary) {
        Color(0xFFF3C77D), Color(0xFFFFD580), BlackGoldPrimaryLight -> GoldOnGradient
        Color(0xFFFFB0D0), PinkStatusBarSeed -> PinkOnGradient
        Color(0xFFE5E5E5), BlackNewPrimaryLight -> MidnightOnGradient
        Color(0xFF6ABFFF), OceanPrimaryLight -> OceanOnGradient
        ForestPrimary, ForestPrimaryLight -> ForestOnGradient
        Color(0xFF00E5FF), CyanPrimaryLight -> CyanOnGradient
        Color(0xFFD500F9), PurplePrimaryLight -> PurpleOnGradient
        Color(0xFF1A1A1A), WhitePrimary -> WhiteOnGradient
        Color(0xFFFF3333), BloodPrimary, BloodPrimaryLight -> BloodOnGradient
        else -> fallbackContent
    }
    return Triple(isPremium, gradient, contentColor)
}
