package com.lorelight.ui.library

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import com.lorelight.ui.animation.StaggeredItem
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import com.lorelight.ui.components.LibraryCoverImage
import com.lorelight.ui.components.LorelightDialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Context
import com.lorelight.R
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import com.lorelight.data.model.Novel
import com.lorelight.ui.components.NovelCoverImage
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.draw.clipToBounds
import com.lorelight.ui.reader.ReaderViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import androidx.compose.ui.semantics.Role

fun getCompactChapterText(chapter: String): String {
    val regex = Regex("""(?i)^(chapter\s+\d+)\b""", RegexOption.IGNORE_CASE)
    val match = regex.find(chapter)
    return if (match != null) {
        match.groupValues[1]
    } else {
        if (chapter.length > 15) {
            chapter.take(12) + "..."
        } else {
            chapter
        }
    }
}

@Composable
fun ComingSoonScreen(title: String) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "$title Coming Soon",
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
        )
    }
}

@Composable
fun HistoryScreen(
    history: List<Novel>,
    onPlayClick: (Novel) -> Unit,
    onDeleteClick: (Novel) -> Unit = {},
    onClearAllClick: () -> Unit = {},
    heroImageRes: Int = R.drawable.darklibrarygreen,
    readerViewModel: ReaderViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    val settingsVersion by com.lorelight.data.local.AppSettingsSignal.version.collectAsState()
    // Row awaiting delete confirmation (null = no dialog showing).
    var pendingDelete by remember { mutableStateOf<Novel?>(null) }
    var showClearAllDialog by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        // MOBILE/TABLET SPLIT. See Details/Library hero banners: the
        // top-anchored crop below is only needed on tablets. Phones keep the
        // original center crop (previous mobile hero banner setting).
        val configuration = androidx.compose.ui.platform.LocalConfiguration.current
        val isTablet = configuration.screenWidthDp >= 600
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .clipToBounds()
        ) {
            Image(
                painter = painterResource(id = heroImageRes),
                contentDescription = stringResource(R.string.history_hero_banner_desc),
                contentScale = ContentScale.Crop,
                // TOP-CROP FIX (tablets only). Crop defaulted to centering,
                // which cropped the top and bottom evenly. Aligning to
                // TopCenter on tablets keeps the top edge of the banner art
                // always fully visible, matching the Details screen's hero
                // banner fix. Phones keep the original center crop (previous
                // mobile hero banner setting).
                alignment = if (isTablet) Alignment.TopCenter else Alignment.Center,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colorStops = arrayOf(
                                0.0f to Color.Transparent,
                                0.45f to Color.Transparent,
                                0.85f to MaterialTheme.colorScheme.background,
                                1.0f to MaterialTheme.colorScheme.background
                            )
                        )
                    )
            )
            val appThemeName by readerViewModel.appTheme.collectAsState()
            WindAndFirefliesBackground(
                themeName = appThemeName,
                primaryColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.matchParentSize()
            )
        }
        
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 32.dp)
                    .height(48.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = stringResource(R.string.history_title),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = MaterialTheme.typography.headlineLarge.fontFamily,
                    color = Color.White
                )
                
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (history.isNotEmpty()) {
                        IconButton(
                            onClick = { showClearAllDialog = true },
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color.Black.copy(alpha = 0.35f), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = stringResource(R.string.history_clear_all_desc),
                                tint = Color.White.copy(alpha = 0.9f),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
                    Button(
                        onClick = { uriHandler.openUri("https://discord.gg/nyFMhq9EFw") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5865F2)),
                        shape = RoundedCornerShape(20.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        modifier = Modifier.height(40.dp)
                    ) {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_discord),
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.history_discord_label), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(100.dp))
            
            val listState = rememberLazyListState()
            val density = LocalDensity.current
            val fadeHeightPx = with(density) { 48.dp.toPx() }
            val isScrolled by remember {
                derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 0 }
            }

            val sortedHistory = remember(history) { history.sortedByDescending { it.lastReadTimestamp } }
            // Grouped into Today / Yesterday / weekday / full date, with a
            // continuous timeline rail running down the left edge.
            val historyContext = LocalContext.current
            val timelineRows = remember(sortedHistory) { buildHistoryTimeline(historyContext, sortedHistory) }
            if (sortedHistory.isEmpty()) {
                com.lorelight.ui.components.LorelightEmpty(
                    icon = Icons.Filled.History,
                    title = stringResource(R.string.history_empty_title),
                    message = stringResource(R.string.history_empty_message),
                    modifier = Modifier.fillMaxWidth().weight(1f)
                )
            } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .graphicsLayer { alpha = 0.99f }
                    .drawWithContent {
                        drawContent()
                        if (isScrolled) {
                            drawRect(
                                brush = Brush.verticalGradient(
                                    0f to Color.Transparent,
                                    1f to Color.Black,
                                    startY = 0f,
                                    endY = fadeHeightPx
                                ),
                                blendMode = BlendMode.DstIn
                            )
                        }
                    },
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(items = timelineRows, key = { _, row -> row.key }) { index, row ->
                    when (row) {
                        is HistoryRow.DateHeader -> HistoryDateHeader(
                            label = row.label,
                            count = row.count
                        )
                        is HistoryRow.Entry -> StaggeredItem(index = index, key = row.novel.id) {
                            HistoryTimelineItem(
                                novel = row.novel,
                                isFirstInGroup = row.isFirstInGroup,
                                isLastInGroup = row.isLastInGroup,
                                onPlayClick = { onPlayClick(row.novel) },
                                onDeleteClick = { pendingDelete = row.novel }
                            )
                        }
                    }
                }
                
                item {
                    Spacer(modifier = Modifier.height(120.dp))
                }
            }
            }
        }

        // Confirm before removing a row. This only clears the history entry -
        // the novel, its library entry and its reading progress all stay.
        pendingDelete?.let { target ->
            LorelightDialog(
                onDismissRequest = { pendingDelete = null },
                title = { Text(stringResource(R.string.history_remove_dialog_title)) },
                text = {
                    Text("\"${target.title}\" will be removed from your reading history. The novel stays in your library and your reading progress is kept.")
                },
                isDestructive = true,
                confirmButton = {
                    TextButton(onClick = {
                        onDeleteClick(target)
                        pendingDelete = null
                    }) {
                        Text(stringResource(R.string.history_remove_action), color = MaterialTheme.colorScheme.error)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingDelete = null }) { Text(stringResource(R.string.action_cancel)) }
                }
            )
        }

        if (showClearAllDialog) {
            LorelightDialog(
                onDismissRequest = { showClearAllDialog = false },
                title = { Text(stringResource(R.string.history_clear_all_dialog_title)) },
                text = {
                    Text(stringResource(R.string.history_clear_all_body))
                },
                isDestructive = true,
                confirmButton = {
                    TextButton(onClick = {
                        onClearAllClick()
                        showClearAllDialog = false
                    }) {
                        Text(stringResource(R.string.history_clear_all_action), color = MaterialTheme.colorScheme.error)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showClearAllDialog = false }) { Text(stringResource(R.string.action_cancel)) }
                }
            )
        }
    }
}

// ── History timeline scaffolding ─────────────────────────────────────────────
// Purely additive: HistoryItem below is untouched and still renders every row.
// These wrap it with a date rail so the tab reads as a chronological timeline.

sealed class HistoryRow {
    abstract val key: String

    data class DateHeader(val label: String, val count: Int) : HistoryRow() {
        override val key: String get() = "history_header_$label"
    }

    data class Entry(
        val novel: Novel,
        val isFirstInGroup: Boolean,
        val isLastInGroup: Boolean
    ) : HistoryRow() {
        override val key: String get() = "history_entry_${novel.id}"
    }
}

private fun startOfDayMillis(millis: Long): Long {
    val c = Calendar.getInstance()
    c.timeInMillis = millis
    c.set(Calendar.HOUR_OF_DAY, 0)
    c.set(Calendar.MINUTE, 0)
    c.set(Calendar.SECOND, 0)
    c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun historyDayLabel(context: Context, timestamp: Long): String {
    if (timestamp <= 0L) return context.getString(R.string.history_earlier)
    val todayStart = startOfDayMillis(System.currentTimeMillis())
    val dayStart = startOfDayMillis(timestamp)
    val diffDays = ((todayStart - dayStart) / 86_400_000L).toInt()
    return when {
        diffDays <= 0 -> context.getString(R.string.history_today)
        else -> SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(timestamp))
    }
}

fun buildHistoryTimeline(context: Context, sorted: List<Novel>): List<HistoryRow> {
    if (sorted.isEmpty()) return emptyList()
    val rows = mutableListOf<HistoryRow>()
    // groupBy keeps insertion order, and `sorted` is newest-first, so the
    // buckets come out newest-first too.
    sorted.groupBy { historyDayLabel(context, it.lastReadTimestamp) }.forEach { (label, items) ->
        rows.add(HistoryRow.DateHeader(label, items.size))
        items.forEachIndexed { i, novel ->
            rows.add(
                HistoryRow.Entry(
                    novel = novel,
                    isFirstInGroup = i == 0,
                    isLastInGroup = i == items.lastIndex
                )
            )
        }
    }
    return rows
}

@Composable
fun HistoryDateHeader(label: String, count: Int) {
    val accent = MaterialTheme.colorScheme.primary
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 12.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.width(26.dp), contentAlignment = Alignment.Center) {
            Box(
                modifier = Modifier
                    .size(11.dp)
                    .clip(CircleShape)
                    .background(accent)
                    .border(3.dp, accent.copy(alpha = 0.22f), CircleShape)
            )
        }
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label.uppercase(Locale.getDefault()),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp,
            color = accent
        )
        Spacer(modifier = Modifier.width(10.dp))
        Box(
            modifier = Modifier
                .weight(1f)
                .height(1.dp)
                .background(accent.copy(alpha = 0.18f))
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
            text = if (count == 1) "1 title" else "$count titles",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f)
        )
    }
}

@Composable
fun HistoryTimelineItem(
    novel: Novel,
    isFirstInGroup: Boolean,
    isLastInGroup: Boolean,
    onPlayClick: () -> Unit,
    onDeleteClick: () -> Unit = {}
) {
    val accent = MaterialTheme.colorScheme.primary
    val railColor = accent.copy(alpha = 0.30f)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
    ) {
        Canvas(
            modifier = Modifier
                .width(26.dp)
                .fillMaxHeight()
        ) {
            val cx = size.width / 2f
            val dotY = size.height / 2f
            val stroke = 2.dp.toPx()
            val gap = 9.dp.toPx()

            // Rail above the node (skipped for the first row so it tucks under
            // the date header dot instead of colliding with it).
            drawLine(
                color = railColor,
                start = Offset(cx, if (isFirstInGroup) -4.dp.toPx() else 0f),
                end = Offset(cx, dotY - gap),
                strokeWidth = stroke,
                cap = StrokeCap.Round
            )

            // Rail below the node, omitted on the last row of a day so each
            // group reads as a closed segment.
            if (!isLastInGroup) {
                drawLine(
                    color = railColor,
                    start = Offset(cx, dotY + gap),
                    end = Offset(cx, size.height),
                    strokeWidth = stroke,
                    cap = StrokeCap.Round
                )
            }

            drawCircle(color = accent.copy(alpha = 0.20f), radius = 8.dp.toPx(), center = Offset(cx, dotY))
            drawCircle(color = accent, radius = 3.5.dp.toPx(), center = Offset(cx, dotY))
        }

        Spacer(modifier = Modifier.width(6.dp))

        Box(modifier = Modifier.weight(1f)) {
            SwipeToDeleteRow(onDelete = onDeleteClick) {
                HistoryItem(novel = novel, onPlayClick = onPlayClick, onDeleteClick = onDeleteClick)
            }
        }
    }
}

@Composable
fun HistoryItem(novel: Novel, onPlayClick: () -> Unit, onDeleteClick: () -> Unit = {}) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(role = Role.Button) { onPlayClick() }
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(42.dp, 60.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.outline),
            contentAlignment = Alignment.Center
        ) {
            LibraryCoverImage(
                novel = novel,
                modifier = Modifier.fillMaxSize()
            )
        }
        
        Spacer(modifier = Modifier.width(10.dp))
        
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = novel.title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = getCompactChapterText(novel.currentChapter),
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = formatLastReadTime(novel.lastReadTimestamp),
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
        }
        
        Spacer(modifier = Modifier.width(10.dp))

        // Delete sits left of the play button and swallows its own taps, so a
        // tap here never falls through to the card's "resume reading" click.
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.45f), CircleShape)
                .clickable(role = Role.Button) { onDeleteClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.Delete,
                contentDescription = stringResource(R.string.history_remove_desc),
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(17.dp)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
                .clickable(role = Role.Button) { onPlayClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.PlayArrow,
                contentDescription = stringResource(R.string.history_resume_reading_desc),
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}


/**
 * Swipe a history card to the left to remove it.
 *
 * Deliberately built from `draggable` + `Animatable` rather than a Material
 * dismiss container so the gesture behaves identically on every Android version
 * we ship to. Releasing past the threshold calls [onDelete], which opens the
 * same confirmation dialog as the trash button, and the card always springs
 * back so nothing disappears without the user confirming.
 */
@Composable
private fun SwipeToDeleteRow(
    onDelete: () -> Unit,
    content: @Composable () -> Unit
) {
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val maxDragPx = with(density) { 130.dp.toPx() }
    val triggerPx = with(density) { 88.dp.toPx() }
    val offsetX = remember { Animatable(0f) }
    val dragged = offsetX.value < -1f
    val progress = if (triggerPx <= 0f) 0f else (-offsetX.value / triggerPx).coerceIn(0f, 1f)

    Box(modifier = Modifier.fillMaxWidth()) {
        // Reveal behind the card, only drawn while it is actually moving.
        if (dragged) {
            Row(
                modifier = Modifier
                    .matchParentSize()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.error.copy(alpha = 0.12f + 0.25f * progress))
                    .padding(end = 18.dp),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size((18f + 6f * progress).dp)
                )
            }
        }

        Box(
            modifier = Modifier
                .offset { IntOffset(offsetX.value.roundToInt(), 0) }
                .draggable(
                    orientation = Orientation.Horizontal,
                    state = rememberDraggableState { delta ->
                        scope.launch {
                            offsetX.snapTo((offsetX.value + delta).coerceIn(-maxDragPx, 0f))
                        }
                    },
                    onDragStopped = {
                        if (offsetX.value <= -triggerPx) onDelete()
                        offsetX.animateTo(0f, animationSpec = tween(220))
                    }
                )
        ) {
            content()
        }
    }
}
