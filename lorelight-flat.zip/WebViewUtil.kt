package eu.kanade.tachiyomi.util.system

import android.content.Context
import android.content.pm.PackageManager
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.webkit.WebView

object WebViewUtil {

    /**
     * Returns true if this device has a usable WebView implementation.
     *
     * Touching [CookieManager] forces the WebView package to load; if it's being
     * updated or is missing it throws, in which case WebView isn't usable.
     */
    fun supportsWebView(context: Context): Boolean {
        try {
            CookieManager.getInstance()
        } catch (e: Throwable) {
            return false
        }
        return context.packageManager.hasSystemFeature(PackageManager.FEATURE_WEBVIEW)
    }
}

/**
 * Applies the settings the network WebView interceptor expects.
 */
fun WebView.setDefaultSettings() {
    with(settings) {
        javaScriptEnabled = true
        domStorageEnabled = true
        useWideViewPort = true
        loadWithOverviewMode = true
        cacheMode = WebSettings.LOAD_DEFAULT
    }
}

/**
 * Sets the WebView user agent, avoiding an empty value (Chromium resets empty
 * user agents back to its default).
 */
fun WebView.setUserAgent(userAgent: String) {
    settings.userAgentString = userAgent
}
