package com.lorelight.browse.model

import org.json.JSONObject

data class PluginInfo(
    val id: String,
    val name: String,
    val site: String,
    val lang: String,
    val version: String,
    val url: String,
    val iconUrl: String,
    val hasSettings: Boolean = false,
    val hasUpdate: Boolean = false,
    val repoUrl: String = "",
    val customJS: String? = null,
    val customCSS: String? = null
)

data class InstalledPlugin(
    val info: PluginInfo,
    val filePath: String,
    val installedVersion: String,
    val pinned: Boolean = false
)

data class SourceNovelItem(
    val name: String,
    val path: String,
    val cover: String? = null
)

data class SourceChapter(
    val name: String,
    val path: String,
    val releaseTime: String? = null,
    val chapterNumber: Int? = null
)

data class SourceNovelDetails(
    val path: String,
    val name: String,
    val cover: String? = null,
    val genres: String? = null,
    val summary: String? = null,
    val author: String? = null,
    val status: String? = null,
    val chapters: List<SourceChapter> = emptyList()
)

sealed class FilterDef(open val key: String, open val label: String) {
    data class Picker(
        override val key: String,
        override val label: String,
        val options: List<Pair<String, String>>, // (label, value)
        val default: String
    ) : FilterDef(key, label)

    data class CheckboxGroup(
        override val key: String,
        override val label: String,
        val options: List<Pair<String, String>>, // (label, value)
        val defaults: List<String>
    ) : FilterDef(key, label)

    data class Switch(
        override val key: String,
        override val label: String,
        val default: Boolean
    ) : FilterDef(key, label)

    data class TextInput(
        override val key: String,
        override val label: String,
        val default: String
    ) : FilterDef(key, label)

    data class ExcludableCheckboxGroup(
        override val key: String,
        override val label: String,
        val options: List<Pair<String, String>>, // (label, value)
        val includedDefaults: List<String>,
        val excludedDefaults: List<String>
    ) : FilterDef(key, label)
}

// One resolved filter value. `type` is the VERIFIED FilterTypes string:
// Text | Picker | Checkbox | Switch | XCheckbox
// value shapes: Text->String, Picker->String, Checkbox->List<String>,
// Switch->Boolean, XCheckbox->Pair<included:List<String>, excluded:List<String>>
data class FilterValue(val type: String, val value: Any)

// Serializes to LNReader shape: { key: { type: "<FilterTypes string>", value: <v> } }
class FilterValues(val map: Map<String, FilterValue>) {
    fun toJson(): JSONObject {
        val root = JSONObject()
        for ((key, fv) in map) {
            val entry = JSONObject()
            entry.put("type", fv.type)
            when (fv.type) {
                "XCheckbox" -> {
                    @Suppress("UNCHECKED_CAST")
                    val pair = fv.value as Pair<List<String>, List<String>>
                    val v = JSONObject()
                    v.put("include", org.json.JSONArray(pair.first))
                    v.put("exclude", org.json.JSONArray(pair.second))
                    entry.put("value", v)
                }
                "Checkbox" -> {
                    @Suppress("UNCHECKED_CAST")
                    entry.put("value", org.json.JSONArray(fv.value as List<String>))
                }
                else -> entry.put("value", fv.value)
            }
            root.put(key, entry)
        }
        return root
    }
}
