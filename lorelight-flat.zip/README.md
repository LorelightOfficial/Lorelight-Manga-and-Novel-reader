# Lorelight

Lorelight is an Android web-novel reader with built-in crawling, offline reading,
text-to-speech playback, and a plugin system for novel sources.

## Features
- Import and read web novels with a customizable reader
- Background text-to-speech playback with media controls
- Offline chapter caching
- Plugin-based source system (QuickJS)
- Library backup and restore

## Building
1. Open the project in Android Studio (or use Gradle 8.11+).
2. Debug build: `gradle assembleDebug`
3. Release build requires signing credentials via environment variables:
   - `RELEASE_STORE_PASSWORD`
   - `RELEASE_KEY_PASSWORD`
   - `RELEASE_KEY_ALIAS`
   and a `release.keystore` file in the project root.

## License & Acknowledgments
Lorelight contains code derived from [Mihon](https://github.com/mihonapp/mihon) (Apache-2.0) for Tachiyomi/Mihon extension compatibility.
