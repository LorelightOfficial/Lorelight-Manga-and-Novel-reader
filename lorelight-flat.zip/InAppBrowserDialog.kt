package com.lorelight.browse.ui

import com.lorelight.R
import androidx.compose.foundation.background
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lorelight.browse.model.toNovel as pluginToNovel
import com.lorelight.crawler.CrawlerEngine
import com.lorelight.data.model.Novel
import com.lorelight.data.model.getChapterList
import com.lorelight.data.model.getMangaDetails
import com.lorelight.manga.model.toNovel as mangaToNovel
import com.lorelight.ui.library.cleanBrowserTitle
import com.lorelight.ui.library.AD_COSMETIC_JS
import com.lorelight.ui.library.isAdOrTracker
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.online.HttpSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import tachiyomi.domain.source.service.SourceManager
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

/**
 * Full-screen in-app browser for a Browse source.
 *
 * Opening a source's website used to mean leaving Lorelight entirely for the
 * system browser, which is a one-way trip: whatever you found there could not
 * come back into the library. This keeps the whole loop inside the app.
 *
 * The bar across the top holds exactly what was asked for, left to right:
 * close, an in-site Back arrow, the website name, and Add to Library.
 *
 * ## What Add to Library does
 *
 * It runs the current page through [CrawlerEngine.analyzeMetadata] -- the same
 * metadata-only pass the Websites tab uses -- and hands the resulting husk up
 * to the caller, which drops it into the library immediately and streams the
 * chapters in behind it. That is the same destination as the details page's
 * add-to-library button, reached from a raw URL instead of from a source entry.
 *
 * A source homepage is refused on purpose: there is no novel on it to read, and
 * silently adding a junk row is worse than saying so.
 *
 * ## Why the WebView settings look like this
 *
 * They are copied deliberately from the Websites tab browser, which has already
 * been through several rounds of real-world breakage. The parts that matter:
 * JavaScript and DOM storage on (most novel sites render their chapter lists
 * client-side), a real mobile user agent (desktop UA gets served desktop
 * layouts that the crawler reads badly), mixed content allowed, an https ->
 * http retry for the many sources with broken certificates, and the shared ad
 * and tracker block list so pages on cheap hosts actually finish loading.
 */
@Composable
fun InAppBrowserDialog(
    startUrl: String,
    siteName: String,
    onAddNovel: (Novel) -> Unit,
    onDismiss: () -> Unit,
    origin: BrowserOrigin = BrowserOrigin.Crawler
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var webViewInstance by remember { mutableStateOf<android.webkit.WebView?>(null) }
    var canGoBack by remember { mutableStateOf(false) }
    var pageTitle by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }

    var working by remember { mutableStateOf(false) }
    var successMsg by remember { mutableStateOf<String?>(null) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        // The WebView holds a native surface and its own JS runtime. Without an
        // explicit teardown it survives the dialog and keeps timers running.
        DisposableEffect(Unit) {
            onDispose {
                webViewInstance?.apply {
                    stopLoading()
                    clearHistory()
                    removeAllViews()
                    destroy()
                }
                webViewInstance = null
            }
        }

        // In-site Back first, and only close the browser once the site itself
        // has nowhere left to go back to.
        androidx.activity.compose.BackHandler {
            val wv = webViewInstance
            if (wv != null && wv.canGoBack()) wv.goBack() else onDismiss()
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            AndroidView(
                factory = { ctx ->
                    android.webkit.WebView(ctx).apply {
                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            databaseEnabled = true
                            cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
                            loadsImagesAutomatically = true
                            mixedContentMode =
                                android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            useWideViewPort = true
                            loadWithOverviewMode = true
                            setSupportMultipleWindows(false)
                            javaScriptCanOpenWindowsAutomatically = false
                            allowFileAccess = false
                            allowContentAccess = false
                            if (android.os.Build.VERSION.SDK_INT >=
                                android.os.Build.VERSION_CODES.O
                            ) {
                                safeBrowsingEnabled = false
                            }
                            userAgentString = CrawlerEngine.MOBILE_UA
                        }

                        setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
                        isFocusable = true
                        isFocusableInTouchMode = true

                        webViewClient = object : android.webkit.WebViewClient() {
                            override fun onPageStarted(
                                view: android.webkit.WebView?,
                                url: String?,
                                favicon: android.graphics.Bitmap?
                            ) {
                                super.onPageStarted(view, url, favicon)
                                loading = true
                                canGoBack = view?.canGoBack() ?: false
                            }

                            override fun onPageFinished(
                                view: android.webkit.WebView?,
                                url: String?
                            ) {
                                super.onPageFinished(view, url)
                                loading = false
                                canGoBack = view?.canGoBack() ?: false

                                // Blocking the advert's network request does
                                // not always remove the empty slot it was
                                // sitting in, and some source sites reserve a
                                // tall one that shoves the chapter off screen.
                                view?.evaluateJavascript(AD_COSMETIC_JS, null)
                            }

                            override fun shouldInterceptRequest(
                                view: android.webkit.WebView?,
                                request: android.webkit.WebResourceRequest?
                            ): android.webkit.WebResourceResponse? {
                                val u = request?.url?.toString() ?: ""
                                val host = request?.url?.host ?: ""
                                if (isAdOrTracker(host, u)) {
                                    return android.webkit.WebResourceResponse(
                                        "text/plain",
                                        "UTF-8",
                                        java.io.ByteArrayInputStream(ByteArray(0))
                                    )
                                }
                                return super.shouldInterceptRequest(view, request)
                            }

                            override fun onReceivedSslError(
                                view: android.webkit.WebView?,
                                handler: android.webkit.SslErrorHandler?,
                                error: android.net.http.SslError?
                            ) {
                                handler?.proceed()
                            }

                            override fun onReceivedError(
                                view: android.webkit.WebView?,
                                request: android.webkit.WebResourceRequest?,
                                error: android.webkit.WebResourceError?
                            ) {
                                super.onReceivedError(view, request, error)
                                if (request?.isForMainFrame == true) {
                                    val failing = request.url?.toString() ?: ""
                                    if (failing.startsWith("https://")) {
                                        view?.loadUrl(
                                            failing.replaceFirst("https://", "http://")
                                        )
                                    }
                                }
                            }

                            override fun shouldOverrideUrlLoading(
                                view: android.webkit.WebView?,
                                request: android.webkit.WebResourceRequest?
                            ): Boolean {
                                val u = request?.url?.toString() ?: return false
                                // Swallow app-link schemes so a rogue redirect
                                // cannot bounce the user into another app.
                                return !u.startsWith("http://") && !u.startsWith("https://")
                            }
                        }

                        webChromeClient = object : android.webkit.WebChromeClient() {
                            override fun onReceivedTitle(
                                view: android.webkit.WebView?,
                                title: String?
                            ) {
                                super.onReceivedTitle(view, title)
                                if (!title.isNullOrEmpty()) pageTitle = title
                            }
                        }

                        loadUrl(startUrl)
                        webViewInstance = this
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 56.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .height(56.dp)
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss, modifier = Modifier.size(40.dp)) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = stringResource(R.string.browser_close_desc),
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = { webViewInstance?.takeIf { it.canGoBack() }?.goBack() },
                    enabled = canGoBack,
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = stringResource(R.string.action_back),
                        tint = if (canGoBack) MaterialTheme.colorScheme.onSurface
                        else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(Modifier.width(4.dp))

                Text(
                    text = cleanBrowserTitle(
                        pageTitle.ifBlank { siteName },
                        webViewInstance?.url ?: startUrl
                    ).ifBlank { siteName },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Spacer(Modifier.width(6.dp))

                Button(
                    onClick = {
                        val url = webViewInstance?.url ?: startUrl
                        if (url.isBlank() || working) return@Button
                        scope.launch {
                            working = true
                            successMsg = null
                            errorMsg = null
                            try {
                                if (CrawlerEngine.isProbablyHomepageUrl(url)) {
                                    throw Exception(context.getString(R.string.browser_homepage_error))
                                }
                                val novel = resolveBrowserNovel(
                                    context = context,
                                    origin = origin,
                                    url = url,
                                    fallbackTitle = pageTitle
                                )
                                onAddNovel(novel)
                                working = false
                                successMsg = novel.title.ifBlank { context.getString(R.string.browser_added_fallback) }
                                delay(2200)
                                successMsg = null
                            } catch (e: Exception) {
                                working = false
                                errorMsg = e.localizedMessage ?: context.getString(R.string.browser_couldnt_read_page)
                                delay(3500)
                                errorMsg = null
                            }
                        }
                    },
                    enabled = !working,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                    modifier = Modifier.padding(end = 4.dp)
                ) {
                    Text(
                        text = stringResource(R.string.browser_add_to_library),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (loading) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(top = 56.dp)
                        .height(2.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }

            if (working || successMsg != null || errorMsg != null) {
                Card(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .statusBarsPadding()
                        .padding(top = 66.dp, end = 12.dp)
                        .widthIn(max = 268.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        when {
                            working -> {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = stringResource(R.string.browser_reading_page),
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            successMsg != null -> {
                                Icon(
                                    imageVector = Icons.Filled.Check,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = stringResource(R.string.browser_added_prefix, successMsg ?: ""),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            else -> {
                                Icon(
                                    imageVector = Icons.Filled.Close,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = errorMsg ?: "",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.error,
                                    maxLines = 3,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Resolves the page currently on screen into a Novel, through whichever
 * source opened the browser.
 *
 * The whole point of the origin: a manga page must come back as a manga bound
 * to its extension, and a plugin novel must come back bound to its plugin.
 * Only a page with no source behind it falls through to the crawler.
 */
private suspend fun resolveBrowserNovel(
    context: android.content.Context,
    origin: BrowserOrigin,
    url: String,
    fallbackTitle: String
): Novel = when (origin) {
    is BrowserOrigin.Manga -> resolveMangaNovel(context, origin, url, fallbackTitle)
    is BrowserOrigin.NovelPlugin -> resolvePluginNovel(context, origin, url)
    BrowserOrigin.Crawler -> resolveCrawledNovel(context, url)
}

/**
 * Asks the installed manga extension about this page, then takes its chapter
 * list. The result carries pluginId "manga:<sourceId>", which is what makes
 * the app open it in the manga reader rather than the text reader.
 */
private suspend fun resolveMangaNovel(
    context: android.content.Context,
    origin: BrowserOrigin.Manga,
    url: String,
    fallbackTitle: String
): Novel = withContext(Dispatchers.IO) {
    val source = Injekt.get<SourceManager>().get(origin.sourceId) as? HttpSource
        ?: throw Exception(context.getString(R.string.browser_manga_source_removed))

    val base = source.baseUrl.trim().ifEmpty { origin.baseUrl }
    val path = sourceRelativePath(url, base)
    if (path.isBlank() || path == "/") {
        throw Exception(context.getString(R.string.browser_manga_open_own_page))
    }

    // SManga.title and SManga.url are lateinit in the extension API: reading
    // either before it is set throws, so both are seeded and every later read
    // is guarded.
    val request = SManga.create().apply {
        this.url = path
        this.title = fallbackTitle.ifBlank { context.getString(R.string.browser_manga_fallback_title) }
    }

    val details = source.getMangaDetails(request)

    val detailsUrl = try {
        details.url
    } catch (e: Throwable) {
        ""
    }
    if (detailsUrl.isBlank()) details.url = path

    val detailsTitle = try {
        details.title
    } catch (e: Throwable) {
        ""
    }
    if (detailsTitle.isBlank()) {
        details.title = fallbackTitle.ifBlank { context.getString(R.string.browser_manga_fallback_title) }
    }

    val chapters = source.getChapterList(details)
    if (chapters.isEmpty()) {
        throw Exception(context.getString(R.string.browser_no_chapters_found_manga))
    }

    details.mangaToNovel(origin.sourceId, chapters = chapters)
}

/**
 * Runs the page through the novel plugin that opened the browser, so the
 * saved novel reads its chapters through that plugin instead of scraped text.
 */
private suspend fun resolvePluginNovel(
    context: android.content.Context,
    origin: BrowserOrigin.NovelPlugin,
    url: String
): Novel = withContext(Dispatchers.IO) {
    val app = context.applicationContext
    val path = sourceRelativePath(url, origin.site)

    // Plugins do not agree on what parseNovel() wants. Some are written against
    // a site-relative path ("/novel/foo"), some against that same path with no
    // leading slash, and some against the full absolute URL they handed out in
    // their own listing.
    //
    // Guessing one shape is exactly why adding from the browser failed with
    // "no chapters found" on a perfectly good novel page: the plugin was given
    // a shape it did not recognise, returned an empty shell rather than an
    // error, and the empty chapter list got reported back as the user's
    // mistake. The manga side never had this problem because it asks the
    // extension for details FIRST and then asks for the chapter list, so a
    // wrong path fails loudly instead of quietly.
    //
    // So: try every shape the plugin might accept, and keep the first result
    // that actually carries chapters.
    val candidates = LinkedHashSet<String>()
    if (path.isNotBlank() && path != "/") {
        candidates.add(path)
        candidates.add(path.removePrefix("/"))
    }
    candidates.add(url)
    candidates.removeAll { it.isBlank() }

    var best: com.lorelight.browse.model.SourceNovelDetails? = null
    var lastError: Throwable? = null
    for (candidate in candidates) {
        val attempt = try {
            com.lorelight.browse.js.JSPluginEngine.parseNovel(
                app,
                origin.pluginId,
                candidate
            )
        } catch (e: Throwable) {
            lastError = e
            null
        } ?: continue

        if (attempt.chapters.isNotEmpty()) {
            best = attempt
            break
        }
        // Keep the first readable-but-empty result as a fallback so the error
        // below can still be the accurate one.
        if (best == null) best = attempt
    }

    val details = best ?: throw Exception(
        context.getString(
            R.string.browser_source_read_failed,
            lastError?.message ?: context.getString(R.string.browser_open_novel_own_page)
        )
    )

    if (details.chapters.isEmpty()) {
        throw Exception(context.getString(R.string.browser_no_chapters_found))
    }

    details.pluginToNovel(origin.pluginId)
}

/** No source behind the page: the generic crawler reads it as a web novel. */
private suspend fun resolveCrawledNovel(
    context: android.content.Context,
    url: String
): Novel {
    val crawled = CrawlerEngine.analyzeMetadata(url, context)
    return Novel(
        title = crawled.title,
        currentChapter = context.getString(R.string.browser_default_chapter_one),
        lastReadTimestamp = System.currentTimeMillis(),
        author = crawled.author,
        status = crawled.status.ifBlank { context.getString(R.string.browser_status_ongoing_fallback) },
        totalChapters = 0,
        language = context.getString(R.string.browser_default_language),
        genres = crawled.genres.takeIf { it.isNotEmpty() } ?: listOf(context.getString(R.string.browser_default_genre_online)),
        description = crawled.description,
        chapters = emptyList(),
        coverImageBase64 = crawled.coverUrl,
        isOnline = true,
        sourceUrl = crawled.sourceUrl,
        chapterUrls = emptyList()
    )
}
