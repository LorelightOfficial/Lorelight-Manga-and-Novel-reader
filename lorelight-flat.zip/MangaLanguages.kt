package com.lorelight.manga.util

import android.content.Context
import org.json.JSONArray
import java.util.Locale

object MangaLanguages {
    const val PREFS = "lorelight_manga_prefs"
    const val KEY_SOURCE_LANGS = "manga_selected_langs"

    fun displayName(code: String): String {
        if (code.equals("all", ignoreCase = true)) return "All languages"
        if (code.isBlank()) return code
        val loc = Locale(code)
        val name = loc.displayLanguage
        if (name.equals(code, ignoreCase = true) || name.isBlank()) {
            return code.uppercase()
        }
        return name.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }
    }

    fun readSelected(context: Context): Set<String>? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = p.getString(KEY_SOURCE_LANGS, null) ?: return null
        return try {
            val arr = JSONArray(raw)
            val set = mutableSetOf<String>()
            for (i in 0 until arr.length()) {
                set.add(arr.getString(i))
            }
            if (set.isEmpty()) null else set
        } catch (e: Exception) {
            null
        }
    }

    fun writeSelected(context: Context, langs: Set<String>) {
        val arr = JSONArray()
        langs.forEach { arr.put(it) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_SOURCE_LANGS, arr.toString())
            .apply()
    }

    fun defaultFor(present: Set<String>): Set<String> {
        val sysLang = Locale.getDefault().language
        val set = setOf("all", "en", sysLang).intersect(present)
        return if (set.isEmpty()) present else set
    }

    fun effective(context: Context, present: Set<String>): Set<String> {
        val saved = readSelected(context)
        if (saved != null && saved.isNotEmpty()) return saved
        val def = defaultFor(present)
        if (def.isNotEmpty()) return def
        return if (present.isNotEmpty()) present else setOf("all")
    }
}
