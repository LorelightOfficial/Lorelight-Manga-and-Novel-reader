package com.lorelight.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lorelight.R
import com.lorelight.data.download.DownloadPolicy

/**
 * Per-title offline rules, as an app-native Dialog.
 *
 * Replaces the generic AlertDialog with a themed Surface dialog that
 * matches the app\'s visual language (rounded card, primary-tinted header,
 * styled action buttons).  All policy wiring is identical to before.
 */
@Composable
fun DownloadPolicySheet(
    novelId: String,
    novelTitle: String,
    onDismiss: () -> Unit,
    onSaved: () -> Unit = {}
) {
    val context = LocalContext.current

    val initial = remember(novelId) { DownloadPolicy.rulesFor(context, novelId) }

    var keepAhead     by remember(novelId) { mutableStateOf(initial.keepAhead) }
    var autoNew       by remember(novelId) { mutableStateOf(initial.autoNewChapters) }
    var wifiOnly      by remember(novelId) { mutableStateOf(initial.wifiOnly) }
    var chargingOnly  by remember(novelId) { mutableStateOf(initial.chargingOnly) }
    var cleanupMode   by remember(novelId) { mutableStateOf(initial.cleanupMode) }
    var keepLast      by remember(novelId) { mutableStateOf(initial.keepLast) }
    var protectMarked by remember(novelId) { mutableStateOf(initial.protectMarked) }
    var quotaMb       by remember(novelId) { mutableStateOf(initial.quotaMb) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier      = Modifier.fillMaxWidth(0.92f),
            shape         = RoundedCornerShape(20.dp),
            color         = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {

                // ── Header ───────────────────────────────────────────────
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f))
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                ) {
                    Column {
                        Text(
                            text  = stringResource(R.string.offline_policy_title),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text  = novelTitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // ── Scrollable content ───────────────────────────────────
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 440.dp)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                ) {
                    // keep ahead
                    PolicyLabel(stringResource(R.string.offline_policy_keep_ahead))
                    Spacer(Modifier.height(2.dp))
                    Text(
                        text  = stringResource(R.string.offline_policy_keep_ahead_hint),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        DownloadPolicy.KEEP_AHEAD_CHOICES.forEach { choice ->
                            FilterChip(
                                selected = keepAhead == choice,
                                onClick  = { keepAhead = choice },
                                label    = { Text(DownloadPolicy.keepAheadLabel(choice)) }
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    PolicySwitchRow(
                        label           = stringResource(R.string.offline_policy_auto_new),
                        checked         = autoNew,
                        onCheckedChange = { autoNew = it }
                    )

                    Spacer(Modifier.height(16.dp))
                    PolicyLabel(stringResource(R.string.offline_policy_conditions))
                    Spacer(Modifier.height(6.dp))
                    PolicySwitchRow(
                        label           = stringResource(R.string.offline_policy_wifi_only),
                        checked         = wifiOnly,
                        onCheckedChange = { wifiOnly = it }
                    )
                    PolicySwitchRow(
                        label           = stringResource(R.string.offline_policy_charging_only),
                        checked         = chargingOnly,
                        onCheckedChange = { chargingOnly = it }
                    )

                    Spacer(Modifier.height(16.dp))
                    PolicyLabel(stringResource(R.string.offline_policy_cleanup))
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        DownloadPolicy.CLEANUP_CHOICES.forEach { mode ->
                            FilterChip(
                                selected = cleanupMode == mode,
                                onClick  = { cleanupMode = mode },
                                label    = { Text(DownloadPolicy.cleanupLabel(mode, keepLast)) }
                            )
                        }
                    }
                    if (cleanupMode == DownloadPolicy.CLEANUP_KEEP_LAST) {
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(3, 5, 10, 20).forEach { n ->
                                FilterChip(
                                    selected = keepLast == n,
                                    onClick  = { keepLast = n },
                                    label    = { Text(n.toString()) }
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(6.dp))
                    PolicySwitchRow(
                        label           = stringResource(R.string.offline_policy_protect),
                        checked         = protectMarked,
                        onCheckedChange = { protectMarked = it }
                    )

                    Spacer(Modifier.height(16.dp))
                    PolicyLabel(stringResource(R.string.offline_policy_quota))
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            DownloadPolicy.QUOTA_UNLIMITED, 100, 250, 500
                        ).forEach { mb ->
                            FilterChip(
                                selected = quotaMb == mb,
                                onClick  = { quotaMb = mb },
                                label    = {
                                    Text(
                                        if (mb == DownloadPolicy.QUOTA_UNLIMITED)
                                            stringResource(R.string.offline_policy_quota_none)
                                        else "$mb MB"
                                    )
                                }
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    Text(
                        text  = if (initial.managed)
                            stringResource(R.string.offline_policy_source_title)
                        else
                            stringResource(R.string.offline_policy_source_global),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f)
                    )
                }

                // ── Action row ───────────────────────────────────────────
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.20f)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment     = Alignment.CenterVertically
                ) {
                    if (initial.managed) {
                        TextButton(onClick = {
                            DownloadPolicy.clearRulesFor(context, novelId)
                            onSaved()
                            onDismiss()
                        }) {
                            Text(stringResource(R.string.offline_policy_use_global))
                        }
                    }
                    TextButton(onClick = onDismiss) {
                        Text(stringResource(R.string.offline_policy_cancel))
                    }
                    Spacer(Modifier.width(4.dp))
                    Button(onClick = {
                        DownloadPolicy.setRulesFor(
                            context  = context,
                            novelId  = novelId,
                            rules    = initial.copy(
                                keepAhead        = keepAhead,
                                autoNewChapters  = autoNew,
                                wifiOnly         = wifiOnly,
                                chargingOnly     = chargingOnly,
                                cleanupMode      = cleanupMode,
                                keepLast         = keepLast,
                                protectMarked    = protectMarked,
                                quotaMb          = quotaMb
                            )
                        )
                        onSaved()
                        onDismiss()
                    }) {
                        Text(stringResource(R.string.offline_policy_save))
                    }
                }
            }
        }
    }
}

@Composable
private fun PolicyLabel(text: String) {
    Text(
        text          = text,
        fontSize      = 12.sp,
        fontWeight    = FontWeight.Bold,
        color         = MaterialTheme.colorScheme.primary,
        letterSpacing = 0.3.sp
    )
}

@Composable
private fun PolicySwitchRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text     = label,
            style    = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
