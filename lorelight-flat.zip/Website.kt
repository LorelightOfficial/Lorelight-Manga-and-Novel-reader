package com.lorelight.data.model

import org.json.JSONObject

data class Website(
    val url: String,
    val title: String,
    val logoUrl: String? = null,
    val isPinned: Boolean = false
)

fun Website.toJSONObject(): JSONObject {
    val obj = JSONObject()
    obj.put("url", url)
    obj.put("title", title)
    obj.put("logoUrl", logoUrl ?: JSONObject.NULL)
    obj.put("isPinned", isPinned)
    return obj
}

fun JSONObject.toWebsite(): Website {
    val logo = optString("logoUrl", null)
    val logoVal = if (logo == "null" || logo.isNullOrEmpty()) null else logo
    return Website(
        url = optString("url", ""),
        title = optString("title", ""),
        logoUrl = logoVal,
        isPinned = optBoolean("isPinned", false)
    )
}
