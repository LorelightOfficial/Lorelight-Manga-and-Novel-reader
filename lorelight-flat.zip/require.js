(function(){
  globalThis.__modules = globalThis.__modules || {};
  globalThis.__registerModule = function(name, factory){
    globalThis.__modules[name] = { factory: factory, exports: null, loaded: false };
  };
  globalThis.require = function(name){
    var m = globalThis.__modules[name];
    if (!m){ __native.log("[require] Module not found: " + name); throw new Error("Module not found: " + name); }
    if (!m.loaded){
      if (typeof m.factory === 'function'){
        var module = { exports: {} };
        m.factory(module, module.exports, globalThis.require);
        m.exports = module.exports;
      } else { m.exports = m.factory; }
      m.loaded = true;
    }
    return m.exports;
  };
})();
