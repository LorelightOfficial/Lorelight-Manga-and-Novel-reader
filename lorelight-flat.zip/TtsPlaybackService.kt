package com.lorelight.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import android.util.Base64
import android.util.Log
import com.lorelight.MainActivity
import com.lorelight.R
import com.lorelight.data.model.toNovel

class TtsPlaybackService : Service() {

    companion object {
        const val TAG = "TtsPlaybackService"
        const val NOTIFICATION_ID = 2026
        const val CHANNEL_ID = "tts_playback_channel"

        const val ACTION_PLAY = "com.lorelight.action.PLAY"
        const val ACTION_PAUSE = "com.lorelight.action.PAUSE"
        const val ACTION_PREV = "com.lorelight.action.PREV"
        const val ACTION_NEXT = "com.lorelight.action.NEXT"
        const val ACTION_PREV_CHAPTER = "com.lorelight.action.PREV_CHAPTER"
        const val ACTION_NEXT_CHAPTER = "com.lorelight.action.NEXT_CHAPTER"
        const val ACTION_STOP = "com.lorelight.action.STOP"
        const val ACTION_UPDATE = "com.lorelight.action.UPDATE"

        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_AUTHOR = "extra_author"
        const val EXTRA_NOVEL_ID = "extra_novel_id"
        const val EXTRA_PLAYING = "extra_playing"
        const val EXTRA_COVER = "extra_cover"
        const val EXTRA_TEXT = "extra_text"
        const val EXTRA_CHAPTER = "extra_chapter"
        const val EXTRA_SENTENCE_INDEX = "extra_sentence_index"
        const val EXTRA_SENTENCE_COUNT = "extra_sentence_count"
        const val EXTRA_POSITION_MS = "extra_position_ms"
        const val EXTRA_DURATION_MS = "extra_duration_ms"

        var currentCoverBase64: String? = null

        // Global interfaces to connect back to the active player
        var onPlayPauseAction: (() -> Unit)? = null
        var onPlayAction: (() -> Unit)? = null
        var onPauseAction: (() -> Unit)? = null
        var onNextAction: (() -> Unit)? = null
        var onPrevAction: (() -> Unit)? = null
        var onStopAction: (() -> Unit)? = null

        @Volatile
        private var instance: TtsPlaybackService? = null

        fun acquireWakeLock(context: Context) {
            val s = instance
            if (s != null) {
                s.acquireWakeLock()
            } else {
                Log.d(TAG, "[WakeLock] Service instance null on acquireWakeLock, starting service to ensure wake lock is held...")
                val intent = Intent(context, TtsPlaybackService::class.java).apply {
                    action = ACTION_UPDATE
                    val novel = com.lorelight.tts.TtsPlaybackManager.activeNovel.value
                    if (novel != null) {
                        putExtra(EXTRA_TITLE, novel.title)
                        putExtra(EXTRA_AUTHOR, novel.author)
                        putExtra(EXTRA_NOVEL_ID, novel.id)
                        putExtra(EXTRA_PLAYING, com.lorelight.tts.TtsPlaybackManager.isPlaying.value)
                        putExtra(EXTRA_COVER, novel.coverImageBase64)
                        val block = com.lorelight.tts.TtsPlaybackManager.filteredSentences.value.getOrNull(com.lorelight.tts.TtsPlaybackManager.activeSentenceIndex.value)
                        val txt = when (block) {
                            is com.lorelight.ui.reader.ReaderBlock.TextBlock -> block.text
                            is com.lorelight.ui.reader.ReaderBlock.ImageBlock -> "[Image]"
                            else -> ""
                        }
                        putExtra(EXTRA_TEXT, txt)
                        putExtra(EXTRA_CHAPTER, com.lorelight.tts.TtsPlaybackManager.chapters.value.getOrNull(com.lorelight.tts.TtsPlaybackManager.activeChapterIndex.value) ?: "")
                    }
                }
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(intent)
                    } else {
                        context.startService(intent)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to auto-start service for wake lock", e)
                }
            }
        }
    }

    private var mediaSession: MediaSession? = null

    private var wakeLock: android.os.PowerManager.WakeLock? = null

    private var silentPlayer: android.media.MediaPlayer? = null
    // Set once the silent keep-alive track proves unplayable on this device, so
    // we stop retrying it on every single notification update.
    private var silentPlayerUnavailable = false

    private fun startSilentPlayer() {
        if (silentPlayerUnavailable) return
        try {
            val player = silentPlayer
            if (player != null) {
                if (player.isPlaying) {
                    return // Already playing continuously!
                } else {
                    player.start()
                    return
                }
            }
            val attrs = android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            val created = android.media.MediaPlayer.create(this, R.raw.silence, attrs, 0)
            if (created == null) {
                // create() returns null when prepare() fails. The old code fed that
                // null straight into ?.apply and then logged success anyway, so every
                // notification update retried the load and leaked another native
                // player ("MediaPlayer finalized without being released").
                silentPlayerUnavailable = true
                Log.w(TAG, "[SilentPlayer] Unavailable on this device; continuing without keep-alive track")
                return
            }
            silentPlayer = created.apply {
                isLooping = true
                setVolume(0f, 0f)
                start()
            }
            Log.d(TAG, "[SilentPlayer] Started continuous silent loop")
        } catch (e: Exception) {
            silentPlayerUnavailable = true
            try { silentPlayer?.release() } catch (_: Exception) {}
            silentPlayer = null
            Log.e(TAG, "silent player failed", e)
        }
    }

    private fun stopSilentPlayer() { try { silentPlayer?.release() } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError(this, "TtsPlaybackService.stopSilentPlayer", e) } ; silentPlayer = null ; silentPlayerUnavailable = false }

    internal fun acquireWakeLock() {
        try {
            if (wakeLock == null) {
                val powerManager = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
                wakeLock = powerManager.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "Lorelight::TtsWakeLock").apply {
                    setReferenceCounted(false)
                }
            }
            wakeLock?.let {
                if (!it.isHeld) {
                    it.acquire(10 * 60 * 1000L)
                    Log.d(TAG, "[WakeLock] WakeLock acquired")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "[WakeLock] Exception acquiring wake lock", e)
        }
    }

    private fun releaseWakeLock() {
        try {
            wakeLock?.let {
                if (it.isHeld) {
                    it.release()
                    Log.d(TAG, "[WakeLock] WakeLock released")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "[WakeLock] Exception releasing wake lock", e)
        }
    }

    private val noisyReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (AudioManager.ACTION_AUDIO_BECOMING_NOISY == intent?.action) {
                Log.d(TAG, "Headphones disconnected! Pausing playback via noisyReceiver.")
                com.lorelight.tts.TtsPlaybackManager.dispatch(com.lorelight.tts.TtsPlaybackManager.TtsCommand.Pause)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        Log.d(TAG, "TtsPlaybackService Created")
        startForegroundServiceProperly()
        setupMediaSession()
        try {
            androidx.core.content.ContextCompat.registerReceiver(
                this,
                noisyReceiver,
                android.content.IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
                androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
            )
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register ACTION_AUDIO_BECOMING_NOISY receiver", e)
        }
    }

    private fun startForegroundServiceProperly() {
        createNotificationChannel()
        
        var title = "Lorelight"
        var chapter = "Preparing playback..."
        var cover: String? = null
        var novelId: String? = null
        
        try {
            val activeNovel = com.lorelight.tts.TtsPlaybackManager.activeNovel.value
            if (activeNovel != null) {
                title = activeNovel.title
                cover = activeNovel.coverImageBase64
                novelId = activeNovel.id
                val activeChIdx = com.lorelight.tts.TtsPlaybackManager.activeChapterIndex.value
                chapter = com.lorelight.tts.TtsPlaybackManager.chapters.value.getOrNull(activeChIdx) ?: activeNovel.currentChapter.ifBlank { "Preparing playback..." }
            } else {
                val history = com.lorelight.data.local.NovelPreferences.loadHistoryFromPrefs(this)
                val lastEntry = history.firstOrNull()
                if (lastEntry != null && lastEntry.novelJson.isNotEmpty()) {
                    val novel = org.json.JSONObject(lastEntry.novelJson).toNovel()
                    title = novel.title
                    chapter = novel.currentChapter.ifBlank { "Preparing playback..." }
                    cover = novel.coverImageBase64
                    novelId = novel.id
                }
            }
        } catch (e: Exception) {
            // ignore
        }

        val coverBmp = resolveCoverBitmap(cover, novelId, title)

        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
            .setContentTitle(title)
            .setContentText(chapter)
            .setSubText(chapter)
            .setSmallIcon(R.drawable.ic_tts_notification)

        if (coverBmp != null) {
            notification.setLargeIcon(coverBmp)
        }

        val builtNotification = notification.build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, builtNotification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, builtNotification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Audiobook Reading Controls"
            val descriptionText = "Displays notification controls and artwork for the active audiobook"
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                setShowBadge(false)
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun setupMediaSession() {
        mediaSession = MediaSession(this, "EpubTtsSession").apply {
            setCallback(object : MediaSession.Callback() {
                override fun onPlay() {
                    Log.d(TAG, "MediaSession: onPlay")
                    com.lorelight.tts.TtsPlaybackManager.dispatch(com.lorelight.tts.TtsPlaybackManager.TtsCommand.Play)
                }

                override fun onPause() {
                    Log.d(TAG, "MediaSession: onPause")
                    com.lorelight.tts.TtsPlaybackManager.dispatch(com.lorelight.tts.TtsPlaybackManager.TtsCommand.Pause)
                }

                override fun onSkipToNext() {
                    Log.d(TAG, "MediaSession: onSkipToNext")
                    com.lorelight.tts.TtsPlaybackManager.dispatch(com.lorelight.tts.TtsPlaybackManager.TtsCommand.NextChapter)
                }

                override fun onSkipToPrevious() {
                    Log.d(TAG, "MediaSession: onSkipToPrevious")
                    com.lorelight.tts.TtsPlaybackManager.dispatch(com.lorelight.tts.TtsPlaybackManager.TtsCommand.PrevChapter)
                }

                override fun onStop() {
                    Log.d(TAG, "MediaSession: onStop")
                    com.lorelight.tts.TtsPlaybackManager.dispatch(com.lorelight.tts.TtsPlaybackManager.TtsCommand.Stop)
                    stopPlayService()
                }

                override fun onCustomAction(action: String, extras: android.os.Bundle?) {
                    Log.d(TAG, "MediaSession custom action: $action")
                    if (action == "com.lorelight.action.PREV") {
                        com.lorelight.tts.TtsPlaybackManager.dispatch(com.lorelight.tts.TtsPlaybackManager.TtsCommand.PrevSentence)
                    } else if (action == "com.lorelight.action.NEXT") {
                        com.lorelight.tts.TtsPlaybackManager.dispatch(com.lorelight.tts.TtsPlaybackManager.TtsCommand.NextSentence)
                    }
                }
            })
            isActive = true
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            com.lorelight.tts.TtsPlaybackManager.tryRestoreLastActiveSession()
            return START_STICKY
        }

        val action = intent.action
        Log.d(TAG, "onStartCommand Action: $action")

        when (action) {
            ACTION_PLAY -> com.lorelight.tts.TtsPlaybackManager.dispatch(com.lorelight.tts.TtsPlaybackManager.TtsCommand.Play)
            ACTION_PAUSE -> com.lorelight.tts.TtsPlaybackManager.dispatch(com.lorelight.tts.TtsPlaybackManager.TtsCommand.Pause)
            ACTION_PREV -> com.lorelight.tts.TtsPlaybackManager.dispatch(com.lorelight.tts.TtsPlaybackManager.TtsCommand.PrevSentence)
            ACTION_NEXT -> com.lorelight.tts.TtsPlaybackManager.dispatch(com.lorelight.tts.TtsPlaybackManager.TtsCommand.NextSentence)
            ACTION_PREV_CHAPTER -> com.lorelight.tts.TtsPlaybackManager.dispatch(com.lorelight.tts.TtsPlaybackManager.TtsCommand.PrevChapter)
            ACTION_NEXT_CHAPTER -> com.lorelight.tts.TtsPlaybackManager.dispatch(com.lorelight.tts.TtsPlaybackManager.TtsCommand.NextChapter)
            ACTION_STOP -> {
                com.lorelight.tts.TtsPlaybackManager.dispatch(com.lorelight.tts.TtsPlaybackManager.TtsCommand.Stop)
                stopPlayService()
                return START_NOT_STICKY
            }
            ACTION_UPDATE -> {
                val title = intent.getStringExtra(EXTRA_TITLE) ?: "Reading"
                val author = intent.getStringExtra(EXTRA_AUTHOR) ?: ""
                val novelId = intent.getStringExtra(EXTRA_NOVEL_ID)
                val isPlaying = intent.getBooleanExtra(EXTRA_PLAYING, false)
                val coverBase64 = intent.getStringExtra(EXTRA_COVER) ?: currentCoverBase64
                val text = intent.getStringExtra(EXTRA_TEXT) ?: ""
                val chapter = intent.getStringExtra(EXTRA_CHAPTER) ?: ""
                
                val positionMs = if (intent.hasExtra(EXTRA_POSITION_MS)) {
                    intent.getLongExtra(EXTRA_POSITION_MS, 0L)
                } else {
                    intent.getIntExtra(EXTRA_SENTENCE_INDEX, 0) * 1000L
                }
                
                val durationMs = if (intent.hasExtra(EXTRA_DURATION_MS)) {
                    intent.getLongExtra(EXTRA_DURATION_MS, 1000L)
                } else {
                    intent.getIntExtra(EXTRA_SENTENCE_COUNT, 0) * 1000L
                }

                updatePlaybackStateAndNotification(title, novelId, isPlaying, coverBase64, text, chapter, positionMs, durationMs)
            }
        }

        return START_STICKY
    }

    private fun updatePlaybackStateAndNotification(
        title: String,
        novelId: String?,
        isPlaying: Boolean,
        coverBase64: String?,
        text: String,
        chapter: String,
        positionMs: Long,
        durationMs: Long
    ) {
        val session = mediaSession ?: return

        // 1. Resolve cover image from storage, local file, base64, or web
        val coverBitmap = resolveCoverBitmap(coverBase64, novelId, title)
        val chapterDisplay = chapter.ifBlank { "Reading" }

        // 2. Update MediaSession Metadata (Title, Chapter as Artist, Album, Duration, Cover Art)
        val metaBuilder = MediaMetadata.Builder()
            .putString(MediaMetadata.METADATA_KEY_TITLE, title) // Book Title
            .putString(MediaMetadata.METADATA_KEY_ARTIST, chapterDisplay) // Chapter Number / Title instead of Author
            .putString(MediaMetadata.METADATA_KEY_ALBUM, chapterDisplay)
            .putString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE, title)
            .putString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE, chapterDisplay)
            .putString(MediaMetadata.METADATA_KEY_DISPLAY_DESCRIPTION, text)
            .putLong(MediaMetadata.METADATA_KEY_DURATION, durationMs)

        if (coverBitmap != null) {
            metaBuilder.putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, coverBitmap)
            metaBuilder.putBitmap(MediaMetadata.METADATA_KEY_ART, coverBitmap)
        }
        session.setMetadata(metaBuilder.build())

        // 3. Update MediaSession Playback State with native position progress
        val customRewindAction = PlaybackState.CustomAction.Builder(
            "com.lorelight.action.PREV",
            "Rewind Sentence",
            android.R.drawable.ic_media_rew
        ).build()

        val customForwardAction = PlaybackState.CustomAction.Builder(
            "com.lorelight.action.NEXT",
            "Forward Sentence",
            android.R.drawable.ic_media_ff
        ).build()

        val stateBuilder = PlaybackState.Builder()
            .setActions(
                PlaybackState.ACTION_PLAY or
                PlaybackState.ACTION_PAUSE or
                PlaybackState.ACTION_SKIP_TO_NEXT or
                PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                PlaybackState.ACTION_STOP
            )
            .addCustomAction(customRewindAction)
            .addCustomAction(customForwardAction)
            .setState(
                if (isPlaying) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                positionMs,
                1.0f
            )
        session.setPlaybackState(stateBuilder.build())

        // 4. Build Notification with Custom media style
        val notification = buildMediaNotification(title, chapterDisplay, text, isPlaying, coverBitmap)

        // 5. Run service as foreground service
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        Log.d(TAG, "[ForegroundService] startForeground called with ID $NOTIFICATION_ID. Title = $title, Chapter = $chapterDisplay")

        val isSessionActive = com.lorelight.tts.TtsPlaybackManager.sessionActive.value
        if (isPlaying || isSessionActive) {
            acquireWakeLock()
            startSilentPlayer()
        } else {
            releaseWakeLock()
            stopSilentPlayer()
        }

        // If not playing, stop foreground but keep notification so user can hit play or swipe away
        if (!isPlaying && !isSessionActive) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_DETACH)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(false)
            }
            Log.d(TAG, "[ForegroundService] Detached from foreground (stopped or paused)")
        }
    }

    private var cachedCoverKey: String? = null
    private var cachedBitmap: Bitmap? = null
    private var isDownloadingWebCover = false

    private fun resolveCoverBitmap(coverStr: String?, novelId: String?, title: String): Bitmap? {
        val activeId = novelId ?: com.lorelight.tts.TtsPlaybackManager.activeNovel.value?.id
        val activeCoverStr = coverStr ?: currentCoverBase64 ?: com.lorelight.tts.TtsPlaybackManager.activeNovel.value?.coverImageBase64
        val key = "${activeId}_${activeCoverStr}"

        if (key == cachedCoverKey && cachedBitmap != null && !cachedBitmap!!.isRecycled) {
            return cachedBitmap
        }

        var loadedBitmap: Bitmap? = null

        // 1. Check local file from CoverStorage if activeId is present
        if (!activeId.isNullOrEmpty()) {
            try {
                val f = com.lorelight.data.local.CoverStorage.coverFile(this, activeId)
                if (f.exists() && f.isFile && f.length() > 0) {
                    loadedBitmap = BitmapFactory.decodeFile(f.absolutePath)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error decoding file from CoverStorage: ${e.message}")
            }
        }

        // 2. Check if activeCoverStr is a file path
        if (loadedBitmap == null && !activeCoverStr.isNullOrEmpty()) {
            val cleanPath = when {
                activeCoverStr.startsWith("file://") -> activeCoverStr.substring(7)
                activeCoverStr.startsWith("/") -> activeCoverStr
                else -> null
            }
            if (cleanPath != null) {
                try {
                    val f = java.io.File(cleanPath)
                    if (f.exists() && f.isFile && f.length() > 0) {
                        loadedBitmap = BitmapFactory.decodeFile(f.absolutePath)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Error decoding cover file path: ${e.message}")
                }
            }
        }

        // 3. Check if activeCoverStr is a Base64 string
        if (loadedBitmap == null && !activeCoverStr.isNullOrEmpty() &&
            !activeCoverStr.startsWith("http://") && !activeCoverStr.startsWith("https://")) {
            try {
                val rawBase64 = if (activeCoverStr.contains(",")) {
                    activeCoverStr.substringAfter(",")
                } else {
                    activeCoverStr
                }
                val bytes = Base64.decode(rawBase64.trim(), Base64.DEFAULT)
                if (bytes != null && bytes.isNotEmpty()) {
                    loadedBitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error decoding cover Base64: ${e.message}")
            }
        }

        // 4. Check if activeCoverStr is an HTTP/HTTPS URL
        if (loadedBitmap == null && !activeCoverStr.isNullOrEmpty() &&
            (activeCoverStr.startsWith("http://") || activeCoverStr.startsWith("https://"))) {
            loadWebCoverBitmap(activeCoverStr, activeId)
        }

        if (loadedBitmap != null) {
            cachedCoverKey = key
            cachedBitmap = loadedBitmap
            return loadedBitmap
        }

        val placeholder = generateProceduralPlaceholder(title)
        cachedCoverKey = key
        cachedBitmap = placeholder
        return placeholder
    }

    private fun loadWebCoverBitmap(urlStr: String, novelId: String?) {
        if (isDownloadingWebCover) return
        isDownloadingWebCover = true
        Thread {
            try {
                val req = okhttp3.Request.Builder()
                    .url(urlStr)
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                    .build()
                val client = okhttp3.OkHttpClient.Builder()
                    .connectTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(10, java.util.concurrent.TimeUnit.SECONDS)
                    .followRedirects(true)
                    .build()
                client.newCall(req).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val bytes = resp.body?.bytes()
                        if (bytes != null && bytes.isNotEmpty()) {
                            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                            if (bmp != null) {
                                if (!novelId.isNullOrEmpty()) {
                                    try {
                                        com.lorelight.data.local.CoverStorage.saveCoverBytes(this@TtsPlaybackService, novelId, bytes)
                                    } catch (_: Exception) {}
                                }
                                android.os.Handler(android.os.Looper.getMainLooper()).post {
                                    cachedCoverKey = "${novelId}_${urlStr}"
                                    cachedBitmap = bmp
                                    val session = mediaSession ?: return@post
                                    val meta = session.controller.metadata
                                    if (meta != null) {
                                        val builder = MediaMetadata.Builder(meta)
                                            .putBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART, bmp)
                                            .putBitmap(MediaMetadata.METADATA_KEY_ART, bmp)
                                        session.setMetadata(builder.build())
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error downloading web cover image: ${e.message}", e)
            } finally {
                isDownloadingWebCover = false
            }
        }.start()
    }

    private fun generateProceduralPlaceholder(title: String): Bitmap {
        val width = 200
        val height = 280
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        
        // Colors equivalent to BookCoverGraphic
        val colors = listOf(
            0xFF6366F1.toInt(), // Indigo
            0xFF10B981.toInt(), // Emerald
            0xFF06B6D4.toInt(), // Cyan
            0xFFF59E0B.toInt(), // Amber
            0xFFEC4899.toInt()  // Pink
        )
        val index = kotlin.math.abs(title.hashCode()) % colors.size
        val bgColor = colors[index]
        
        // Paint background gradient
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        val shader = android.graphics.LinearGradient(
            0f, 0f, width.toFloat(), height.toFloat(),
            bgColor, 0xFFF43F5E.toInt(), // Gradient to Rose
            android.graphics.Shader.TileMode.CLAMP
        )
        paint.shader = shader
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        
        // Reset shader
        paint.shader = null
        
        // Draw binding visual line on left edge
        paint.color = 0x33FFFFFF // white copy 20%
        canvas.drawRect(0f, 0f, 10f, height.toFloat(), paint)
        
        // Draw first letter of title in the center
        paint.color = android.graphics.Color.WHITE
        paint.textSize = 90f
        paint.typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        paint.textAlign = android.graphics.Paint.Align.CENTER
        
        val displayChar = if (title.isNotEmpty()) title.take(1).uppercase() else "B"
        
        val textBounds = android.graphics.Rect()
        paint.getTextBounds(displayChar, 0, displayChar.length, textBounds)
        val x = width / 2.0f
        val y = height / 2.0f - textBounds.exactCenterY()
        canvas.drawText(displayChar, x, y, paint)
        
        // Draw footer "EPUB" text
        paint.textSize = 24f
        paint.color = 0xB2FFFFFF.toInt() // white 70%
        canvas.drawText("EPUB", x, height - 30f, paint)
        
        return bitmap
    }

    private fun buildMediaNotification(
        title: String,
        chapter: String,
        text: String,
        isPlaying: Boolean,
        coverBitmap: Bitmap?
    ): Notification {
        val session = mediaSession ?: throw IllegalStateException("MediaSession must not be null")

        // Clicking the notification opens MainActivity directly into the Reader
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            putExtra(MainActivity.EXTRA_OPEN_READER, true)
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        // PendingIntents for media control actions
        val playIntent = Intent(this, TtsPlaybackService::class.java).apply { action = ACTION_PLAY }
        val pauseIntent = Intent(this, TtsPlaybackService::class.java).apply { action = ACTION_PAUSE }
        val prevIntent = Intent(this, TtsPlaybackService::class.java).apply { action = ACTION_PREV }
        val nextIntent = Intent(this, TtsPlaybackService::class.java).apply { action = ACTION_NEXT }
        val prevChapterIntent = Intent(this, TtsPlaybackService::class.java).apply { action = ACTION_PREV_CHAPTER }
        val nextChapterIntent = Intent(this, TtsPlaybackService::class.java).apply { action = ACTION_NEXT_CHAPTER }
        val stopIntent = Intent(this, TtsPlaybackService::class.java).apply { action = ACTION_STOP }

        val playPendingIntent = PendingIntent.getService(this, 1, playIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val pausePendingIntent = PendingIntent.getService(this, 2, pauseIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val prevPendingIntent = PendingIntent.getService(this, 3, prevIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val nextPendingIntent = PendingIntent.getService(this, 4, nextIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val prevChapterPendingIntent = PendingIntent.getService(this, 6, prevChapterIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val nextChapterPendingIntent = PendingIntent.getService(this, 7, nextChapterIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stopPendingIntent = PendingIntent.getService(this, 5, stopIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

        val activePlayAction = if (isPlaying) {
            Notification.Action.Builder(
                android.R.drawable.ic_media_pause,
                "Pause",
                pausePendingIntent
            ).build()
        } else {
            Notification.Action.Builder(
                android.R.drawable.ic_media_play,
                "Play",
                playPendingIntent
            ).build()
        }

        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }

        // Generate a subtle text block summarizing active reading sentence
        val contentText = if (text.isNotEmpty()) text else "Reading..."
        val chapterDisplay = chapter.ifBlank { "Reading" }

        builder.setContentTitle(title) // Book Title as Title
            .setContentText(contentText) // Sentence text as content text
            .setSubText(chapterDisplay) // Displays Chapter Number / Name
            .setSmallIcon(R.drawable.ic_tts_notification) // Monochrome branded Lorelight glyph icon
            .setContentIntent(openAppPendingIntent)
            .setDeleteIntent(stopPendingIntent)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setShowWhen(false)

        if (coverBitmap != null) {
            builder.setLargeIcon(coverBitmap)
        }

        // Add 5 controls: Prev Chapter, Rewind Sentence, Play/Pause, Forward Sentence, Next Chapter
        builder.addAction(
            Notification.Action.Builder(
                android.R.drawable.ic_media_previous,
                "Prev Chapter",
                prevChapterPendingIntent
            ).build()
        )
        builder.addAction(
            Notification.Action.Builder(
                android.R.drawable.ic_media_rew,
                "Rewind",
                prevPendingIntent
            ).build()
        )
        builder.addAction(activePlayAction)
        builder.addAction(
            Notification.Action.Builder(
                android.R.drawable.ic_media_ff,
                "Forward",
                nextPendingIntent
            ).build()
        )
        builder.addAction(
            Notification.Action.Builder(
                android.R.drawable.ic_media_next,
                "Next Chapter",
                nextChapterPendingIntent
            ).build()
        )

        // Make it notification media style showing compact actions
        val mediaStyle = Notification.MediaStyle()
            .setMediaSession(session.sessionToken)
            .setShowActionsInCompactView(1, 2, 3) // Rewind, Play/Pause, Forward
        builder.setStyle(mediaStyle)

        return builder.build()
    }

    private fun stopPlayService() {
        Log.d(TAG, "stopPlayService")
        Log.d(TAG, "[ForegroundService] stopPlayService / stopForeground called")
        Log.d(TAG, "[Notification] Removed (service stopped)")
        releaseWakeLock()
        stopSilentPlayer()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        Log.d(TAG, "TtsPlaybackService Destroyed")
        Log.d(TAG, "[ForegroundService] Service destroyed and stopped")

        // FIX A1: the playback service dying is one of the most common ways a
        // listening session ends (system kill, swipe-away, stop button). Flush the
        // reading position synchronously here, otherwise the queued write can be
        // lost together with the process.
        try {
            com.lorelight.tts.TtsPlaybackManager.forceFlushProgress()
            com.lorelight.data.local.NovelPreferences.flushPendingWrites()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to flush reading progress on service destroy", e)
        }

        releaseWakeLock()
        stopSilentPlayer()
        try {
            unregisterReceiver(noisyReceiver)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to unregister noisyReceiver", e)
        }
        mediaSession?.isActive = false
        mediaSession?.release()
        mediaSession = null
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)

        // FIX A1: the user just swiped the app away. Persist the position before
        // deciding whether to keep running.
        try {
            com.lorelight.tts.TtsPlaybackManager.forceFlushProgress()
            com.lorelight.data.local.NovelPreferences.flushPendingWrites()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to flush reading progress on task removal", e)
        }

        if (!com.lorelight.tts.TtsPlaybackManager.isPlaying.value) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}
