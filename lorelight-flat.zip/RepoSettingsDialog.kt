package com.lorelight.browse.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import com.lorelight.ui.components.LorelightDialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lorelight.browse.repo.PluginRepositoryManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URI

private fun deriveRepoName(url: String): String {
    val clean = url.trim().removeSuffix("/")
    if (clean.contains("raw.githubusercontent.com/")) {
        val parts = clean.substringAfter("raw.githubusercontent.com/").split("/")
        if (parts.size >= 2) {
            return "${parts[0]}/${parts[1]}"
        }
    }
    return try {
        val uri = URI(clean)
        uri.host ?: clean
    } catch (e: Exception) {
        clean
    }
}

@Composable
fun RepoSettingsDialog(
    onDismiss: () -> Unit,
    onChanged: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var repoUrls by remember { mutableStateOf(PluginRepositoryManager.getRepoUrls(context)) }
    var showAddDialog by remember { mutableStateOf(false) }
    var repoToDelete by remember { mutableStateOf<String?>(null) }

    fun refreshRepos() {
        repoUrls = PluginRepositoryManager.getRepoUrls(context)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top App Bar / Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "Extension Repos",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Subheader row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "REPOSITORIES (${repoUrls.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )
                    TextButton(onClick = { showAddDialog = true }) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text("Add Repo")
                    }
                }

                if (repoUrls.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No repositories yet. Tap + to add one.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(repoUrls, key = { it }) { url ->
                            val displayName = deriveRepoName(url)
                            val isDefault = url == PluginRepositoryManager.DEFAULT_REPO

                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = displayName,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            text = url,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        if (isDefault) {
                                            Spacer(Modifier.height(2.dp))
                                            Text(
                                                text = "Default",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    IconButton(onClick = { repoToDelete = url }) {
                                        Icon(
                                            imageVector = Icons.Filled.Delete,
                                            contentDescription = "Remove repository",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    val urlToDelete = repoToDelete
    if (urlToDelete != null) {
        val name = deriveRepoName(urlToDelete)
        val isLast = repoUrls.size <= 1

        LorelightDialog(
            onDismissRequest = { repoToDelete = null },
            title = { Text("Remove repository?") },
            text = {
                val message = if (isLast) {
                    "$name\n\nThis is your last repository - the extension list will be empty."
                } else {
                    name
                }
                Text(message)
            },
            isDestructive = true,
            confirmButton = {
                TextButton(
                    onClick = {
                        val target = urlToDelete
                        repoToDelete = null
                        PluginRepositoryManager.removeRepo(context, target)
                        refreshRepos()
                        onChanged()
                    }
                ) {
                    Text("Remove", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { repoToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showAddDialog) {
        var inputUrl by remember { mutableStateOf("") }
        var isAdding by remember { mutableStateOf(false) }
        var errorMessage by remember { mutableStateOf<String?>(null) }

        LorelightDialog(
            onDismissRequest = { if (!isAdding) showAddDialog = false },
            title = { Text("Add Repository") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = inputUrl,
                        onValueChange = { inputUrl = it; errorMessage = null },
                        label = { Text("Repository URL") },
                        singleLine = true,
                        enabled = !isAdding,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (errorMessage != null) {
                        Text(
                            text = errorMessage!!,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !isAdding && inputUrl.isNotBlank(),
                    onClick = {
                        val url = inputUrl.trim()
                        scope.launch {
                            isAdding = true
                            errorMessage = null
                            val res = withContext(Dispatchers.IO) {
                                PluginRepositoryManager.addRepo(context, url)
                            }
                            isAdding = false
                            res.onSuccess { count ->
                                showAddDialog = false
                                Toast.makeText(context, "Added - $count extensions found", Toast.LENGTH_SHORT).show()
                                refreshRepos()
                                onChanged()
                            }.onFailure { err ->
                                errorMessage = err.message ?: "Could not read that repository"
                            }
                        }
                    }
                ) {
                    Text(if (isAdding) "Adding..." else "Add")
                }
            },
            dismissButton = {
                TextButton(enabled = !isAdding, onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
