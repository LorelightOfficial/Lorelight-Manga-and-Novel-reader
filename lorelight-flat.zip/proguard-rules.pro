# =============================================================================
#  Lorelight R8 configuration
# =============================================================================
#  STRATEGY (modelled on Mihon, whose own rules also open with -dontobfuscate):
#
#    SHRINK   : yes  - drop unreachable classes AND members, plus unused resources.
#    OPTIMIZE : yes  - inline, merge, devirtualise.
#    OBFUSCATE: NO   - every name is preserved.
#
#  Renaming is the ONLY part of R8 that breaks this app, and it would break it
#  badly, because four separate subsystems look things up by name at runtime:
#
#    * Injekt resolves singletons by reified generic type.
#    * Room loads its generated *_Impl classes by class name.
#    * kotlinx.serialization looks up `Companion` / `$$serializer` members.
#    * Manga extensions are dynamically loaded out of OTHER apps' APKs and
#      link against our copy of the Tachiyomi source API.
#
# -----------------------------------------------------------------------------
#  WHY MINIFICATION USED TO SAVE ALMOST NOTHING (40 MB -> 38 MB)
# -----------------------------------------------------------------------------
#  Nearly every keep rule in this file used to be written as:
#
#      -keep class some.package.** { *; }
#
#  The `{ *; }` is the problem. A bare `-keep class X` pins the class but still
#  lets R8 delete methods and fields that nobody calls. Adding `{ *; }` pins
#  every single member as a shrinking root.
#
#  The old rules applied `{ *; }` to com.lorelight.**, the entire ported Mihon
#  backend, kotlinx.serialization, Coil, SQLDelight, ML Kit AND Play Services.
#  Between them that is most of the app, so almost nothing was reachable-but-
#  unused from R8's point of view and there was nothing left to remove. Minify
#  was on, but it had been defused.
#
#  RULE OF THUMB FOR THIS FILE: use `{ *; }` only where something outside R8's
#  view calls the member - JNI, a foreign APK, or reflection by name. Everywhere
#  else keep the class, not its members.
# =============================================================================

-dontobfuscate

# Keep line numbers and file names so any future crash log stays readable.
-keepattributes SourceFile,LineNumberTable
-keepattributes Signature, InnerClasses, EnclosingMethod, *Annotation*
-keepattributes RuntimeVisibleAnnotations, AnnotationDefault

# Anything explicitly annotated @Keep is never touched.
-keep class androidx.annotation.Keep
-keep @androidx.annotation.Keep class * { *; }
-keepclassmembers class * {
    @androidx.annotation.Keep *;
}


# -----------------------------------------------------------------------------
#  Diagnostics (uncomment when you want to see what R8 actually did)
# -----------------------------------------------------------------------------
#  -printusage lists every member R8 deleted; -printconfiguration dumps the
#  fully merged rule set including every library's consumer rules, which is the
#  fastest way to spot a dependency quietly re-adding a blanket keep.
#-printconfiguration build/outputs/mapping/release/r8-merged-config.txt
#-printusage build/outputs/mapping/release/r8-removed-code.txt


# -----------------------------------------------------------------------------
#  Our own code
# -----------------------------------------------------------------------------
#  Classes are kept so every name survives for Injekt / Room / serialization,
#  but unused members are now fair game. `allowoptimization` additionally lets
#  R8 inline and devirtualise what remains.
-keep,allowoptimization class com.lorelight.**


# -----------------------------------------------------------------------------
#  Ported Mihon backend
# -----------------------------------------------------------------------------
-keep,allowoptimization class eu.kanade.**
-keep,allowoptimization class tachiyomi.**
-keep,allowoptimization class mihon.**
-dontwarn eu.kanade.tachiyomi.**

#  EXCEPTION: the extension API surface. Manga extensions are separate APKs, so
#  R8 cannot see those call sites and cannot prove any of it is unused. Every
#  member here must survive verbatim or dynamically loaded sources break with
#  NoSuchMethodError at runtime.
-keep class eu.kanade.tachiyomi.source.** { *; }
-keep interface eu.kanade.tachiyomi.source.** { *; }
-keep class eu.kanade.tachiyomi.network.** { *; }
-keep class eu.kanade.tachiyomi.util.** { *; }
-keep class * implements eu.kanade.tachiyomi.source.Source { *; }
-keep class * extends eu.kanade.tachiyomi.source.online.HttpSource { *; }


# -----------------------------------------------------------------------------
#  Android components (entry points - instantiated by the framework by name)
# -----------------------------------------------------------------------------
#  Members do not need `{ *; }` here: R8 always keeps methods that override a
#  library/framework method, and aapt2 auto-generates constructor keeps for
#  everything declared in AndroidManifest.xml.
-keep class com.lorelight.LorelightApplication
-keep class * extends android.app.Application
-keep class * extends android.app.Activity
-keep class * extends android.app.Service
-keep class * extends android.content.BroadcastReceiver
-keep class * extends android.content.ContentProvider

#  Workers are NOT in the manifest - WorkManager reflects on this exact
#  constructor signature, so it has to be kept explicitly.
-keep class * extends androidx.work.ListenableWorker
-keepclassmembers class * extends androidx.work.ListenableWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}

# WebView JS bridge used by the novel crawler.
-keepclassmembers class * { @android.webkit.JavascriptInterface <methods>; }
-keepclassmembers class com.lorelight.browse.js.** { *; }


# -----------------------------------------------------------------------------
#  Room - generated implementations are resolved by class name at runtime
# -----------------------------------------------------------------------------
-keep class * extends androidx.room.RoomDatabase { *; }
-keep class com.lorelight.data.db.**_Impl { *; }
-keep @androidx.room.Database class * { *; }
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao class * { *; }
-keepclassmembers @androidx.room.Dao class * { *; }
-dontwarn androidx.room.**


# -----------------------------------------------------------------------------
#  Injekt - generic-type reflection over singletons
# -----------------------------------------------------------------------------
-keep class uy.kohesive.injekt.** { *; }
-keepclassmembers class * { *** registerInjectables(...); }


# -----------------------------------------------------------------------------
#  kotlinx.serialization
# -----------------------------------------------------------------------------
#  DO NOT narrow the rule below.
#
#  It used to read `-keep,allowoptimization class kotlinx.serialization.**`.
#  That keeps class NAMES while leaving every member removable, and
#  `allowoptimization` additionally lets R8 move methods between the abstract
#  `Json` class and its implementation. The result was a release build that
#  shipped without `Json.parseToJsonElement`, so the app died with
#  "NoSuchMethodError: No virtual method parseToJsonElement ... in class
#  kotlinx/serialization/json/Json" on a background dispatcher the first time a
#  novel was opened.
#
#  The serialization runtime is small and is reached reflectively from generated
#  serializers, so its members have to be pinned wholesale. This costs a couple
#  hundred KB and is not negotiable.
-keep class kotlinx.serialization.** { *; }
-keep,includedescriptorclasses class com.lorelight.**$$serializer { *; }
-keep,includedescriptorclasses class eu.kanade.**$$serializer { *; }
-keepclassmembers class com.lorelight.** {
    *** Companion;
    kotlinx.serialization.KSerializer serializer(...);
}
-keepclasseswithmembers class com.lorelight.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keepclassmembers class eu.kanade.** {
    *** Companion;
}
-keepclasseswithmembers class eu.kanade.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-dontwarn kotlinx.serialization.**
-dontnote kotlinx.serialization.**


# -----------------------------------------------------------------------------
#  Kotlin runtime / coroutines
#  `public protected *` (Mihon's form) rather than `{ *; }`, because manga
#  extensions compile against these APIs.
# -----------------------------------------------------------------------------
-keep class kotlin.Metadata { *; }
-keep,allowoptimization class kotlin.** { public protected *; }
-keep,allowoptimization class kotlin.time.** { public protected *; }
-keep,allowoptimization class kotlinx.coroutines.** { public protected *; }
-keep,allowoptimization class kotlinx.datetime.** { public protected *; }
-dontwarn kotlinx.coroutines.**


# -----------------------------------------------------------------------------
#  Networking / parsing - also the API surface extensions compile against
# -----------------------------------------------------------------------------
-keep,allowoptimization class okhttp3.** { public protected *; }
-keep,allowoptimization class okio.** { public protected *; }
-keep,allowoptimization class org.jsoup.** { public protected *; }
-keep,allowoptimization class rx.** { public protected *; }
-keep,allowoptimization class com.squareup.zstd.** { public protected *; }
-keepclasseswithmembers class okhttp3.MultipartBody$Builder { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.jsoup.**
-dontwarn rx.**

# RxJava 1.x internals poke these fields via Unsafe.
-dontwarn sun.misc.**
-keepclassmembers class rx.internal.util.unsafe.*ArrayQueue*Field* {
    long producerIndex;
    long consumerIndex;
}
-keepclassmembers class rx.internal.util.unsafe.BaseLinkedQueueProducerNodeRef {
    rx.internal.util.atomic.LinkedQueueNode producerNode;
}
-keepclassmembers class rx.internal.util.unsafe.BaseLinkedQueueConsumerNodeRef {
    rx.internal.util.atomic.LinkedQueueNode consumerNode;
}
-dontnote rx.internal.util.PlatformDependent


# -----------------------------------------------------------------------------
#  Native (JNI) bridges - method names must survive exactly
# -----------------------------------------------------------------------------
-keepclasseswithmembernames,includedescriptorclasses class * { native <methods>; }
-keep class wang.harlon.quickjs.** { *; }
-keep class app.cash.quickjs.** { *; }
-keep class me.zhanghai.android.libarchive.** { *; }
-keep class tachiyomi.decoder.** { *; }
-dontwarn me.zhanghai.android.libarchive.**


# -----------------------------------------------------------------------------
#  Coil
# -----------------------------------------------------------------------------
#  Coil ships consumer rules for its own reflective bits. Our custom fetchers
#  and decoders live in com.lorelight.** and are registered in normal code that
#  R8 can follow, so they do not need a blanket keep.
-keep,allowoptimization class coil.**
-dontwarn coil.**


# -----------------------------------------------------------------------------
#  SQLDelight generated database
# -----------------------------------------------------------------------------
-keep,allowoptimization class app.cash.sqldelight.**
-dontwarn app.cash.sqldelight.**


# -----------------------------------------------------------------------------
#  UniFile / Shizuku / Preference
# -----------------------------------------------------------------------------
-keep class com.hippo.unifile.** { *; }
-dontwarn com.hippo.unifile.**
-keep class rikka.shizuku.** { *; }
-keep interface rikka.shizuku.** { *; }
-keep class mihon.app.shizuku.** { *; }
-keepclassmembers class mihon.app.shizuku.ShellInterface {
    public <init>();
    public void destroy();
}
-dontwarn rikka.shizuku.**
-keep,allowoptimization class androidx.preference.** { public protected *; }


# -----------------------------------------------------------------------------
#  ML Kit text recognition (bundled)
# -----------------------------------------------------------------------------
#  ML Kit and Play Services AARs ship consumer ProGuard rules and are designed
#  to be shrunk, so the blanket keeps that used to live here (com.google.mlkit,
#  gms.tasks, gms.common, odml, libraries.vision - all with `{ *; }`) were
#  redundant and expensive: gms.common alone is a large chunk of code that was
#  being pinned in full. Native entry points are still covered by the global
#  `native <methods>` rule above.
#
#  If on-device OCR ever fails in a release build, put ONE of these back rather
#  than all of them, and note which in a comment.
-keep,allowoptimization class com.google.mlkit.**
-keep,allowoptimization class com.google.android.gms.internal.mlkit_vision_text_common.**
-dontwarn com.google.mlkit.**
-dontwarn com.google.android.gms.internal.mlkit_vision_text_common.**
-dontwarn com.google.android.libraries.vision.**
-dontwarn com.google.android.odml.**


# -----------------------------------------------------------------------------
#  XmlUtil (manga extension-repo parsing)
# -----------------------------------------------------------------------------
-keep public enum nl.adaptivity.xmlutil.EventType { *; }
-dontwarn nl.adaptivity.xmlutil.**


# -----------------------------------------------------------------------------
#  Enums / Parcelable / Serializable - used across models and prefs
# -----------------------------------------------------------------------------
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
-keepclassmembers class * implements android.os.Parcelable {
    public static final ** CREATOR;
}
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
    private static final java.io.ObjectStreamField[] serialPersistentFields;
    private void writeObject(java.io.ObjectOutputStream);
    private void readObject(java.io.ObjectInputStream);
    java.lang.Object writeReplace();
    java.lang.Object readResolve();
}


# -----------------------------------------------------------------------------
#  Provided by the OEM at runtime when supported
# -----------------------------------------------------------------------------
-dontwarn androidx.window.extensions.**
-dontwarn androidx.window.sidecar.**
