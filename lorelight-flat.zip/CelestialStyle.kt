package com.lorelight.ui.theme.modeswitch.celestial

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

enum class CelestialStyle(
    val label: String,
    val emoji: String,
    val desc: String
) {
    DREAMY("Dreamy",  "✨", "Anime eyes · soft gradients"),
    CHIBI ("Chibi",   "🌸", "UwU kawaii · curved lashes"),
    MINIMAL("Minimal","☁️", "Clean simple shapes"),
    GLOWY ("Glowy",   "💫", "Ethereal glow & sparkles"),
    PIXEL ("Pixel",   "🎮", "Retro chunky pixel art")
}

/**
 * App-wide holder so the Canvas draw functions can pick the right design
 * without threading a parameter through every call-site.
 * Updated from LibraryScreen when the user changes the setting.
 */
object CelestialStyleStore {
    var current: CelestialStyle by mutableStateOf(CelestialStyle.DREAMY)
}
