package com.lorelight.data.model

import androidx.annotation.Keep

@Keep
data class LibraryItem(
    val novelId: String = "",
    val title: String = "",
    val coverUrl: String = "",
    val author: String = "",
    val status: String = "Reading", // Reading, Completed, On Hold, Dropped, Plan To Read
    val isFavorite: Boolean = false,
    val categories: List<String> = emptyList(),
    val dateAdded: Long = System.currentTimeMillis(),
    val lastModified: Long = System.currentTimeMillis()
)

@Keep
data class ReadingProgress(
    val novelId: String = "",
    val chapterId: String = "",
    val chapterNumber: Int = 0,
    val chapterTitle: String = "",
    val progressPercentage: Float = 0f,
    val scrollPosition: Int = 0,
    val lastReadTimestamp: Long = System.currentTimeMillis(),
    val lastModified: Long = System.currentTimeMillis()
)

@Keep
data class UserPreferences(
    val theme: String = "Dark", // Light, Dark, AMOLED
    val fontSize: Float = 18f,
    val fontFamily: String = "Default",
    val lineSpacing: Float = 1.5f,
    val paragraphSpacing: Float = 1.0f,
    val readingMode: String = "Vertical", // Vertical, Horizontal
    val brightness: Float = -1f, // -1 for system
    val keepScreenOn: Boolean = true,
    val lastModified: Long = System.currentTimeMillis()
)

@Keep
data class HistoryEntry(
    val novelId: String = "",
    val novelTitle: String = "",
    val chapterId: String = "",
    val chapterTitle: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val lastModified: Long = System.currentTimeMillis(),
    val novelJson: String = "",
    val chapterIndex: Int = -1
)
