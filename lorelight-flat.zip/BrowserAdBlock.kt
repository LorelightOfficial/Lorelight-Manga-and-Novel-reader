package com.lorelight.ui.library

/**
 * Ad/tracker blocking and title cleanup shared by the in-app browser
 * (see InAppBrowserDialog.kt). Extracted out of the old WebsiteScreen.kt so
 * it survives even though that screen's own URL-based "add a novel" UI is
 * gone -- these helpers are still used by the live in-app browser.
 *
 * CDN must never be broken by an ad rule. That is why there is no bare "ad."
 * fragment: the string "ad." appears inside "read.", and blocking every host
 * with "read" in it would take the whole app down. Anything ambiguous goes in
 * the script list, where it can only match an actual script.
 */
fun isAdOrTracker(host: String, url: String): Boolean {
    val h = host.lowercase()
    val u = url.lowercase()

    if (AD_HOST_FRAGMENTS.any { h.contains(it) }) return true
    if (AD_URL_FRAGMENTS.any { u.contains(it) }) return true

    val isScript = u.endsWith(".js") || u.contains(".js?")
    if (isScript && AD_SCRIPT_FRAGMENTS.any { u.contains(it) }) return true

    return false
}

/** Matched against the request host only. */
private val AD_HOST_FRAGMENTS = listOf(
    // ad exchanges and servers
    "ads.", "adserver", "adservice", "adsystem", "amazon-adsystem",
    "doubleclick", "googleads", "googleadservices", "googlesyndication",
    "googletagservices", "adsense", "adnxs", "adform", "adroll",
    "rubiconproject", "pubmatic", "openx", "smartadserver", "casalemedia",
    "indexexchange", "sovrn", "gumgum", "media.net", "criteo", "zedo",
    "yieldmo", "teads", "spotx", "triplelift", "sharethrough", "lijit",
    "33across", "adtelligent", "connatix", "primis", "aniview", "vidoomy",
    "2mdn.net", "serving-sys", "flashtalking", "moatads", "adsafeprotected",
    "doubleverify",
    // the popup, popunder and redirect networks that plague reader sites
    "popads", "popcash", "adcash", "exoclick", "juicyads", "trafficjunky",
    "hilltopads", "adsterra", "onclickads", "clickadu", "adskeeper",
    "bidvertiser", "infolinks", "chitika", "mgid", "revcontent",
    "propellerads", "poweradnetwork", "clktrkr",
    // content recommendation widgets
    "outbrain", "taboola", "ezoic", "monumetric", "mediavine", "adthrive",
    "playwire",
    // analytics and telemetry
    "analytics", "google-analytics", "googletagmanager", "app-measurement",
    "scorecardresearch", "quantserve", "hotjar", "mixpanel", "amplitude.com",
    "segment.io", "fullstory", "clarity.ms", "chartbeat", "newrelic",
    "nr-data.net", "browser-intake", "statcounter", "histats", "clicky",
    "crazyegg", "mouseflow", "luckyorange", "matomo", "piwik", "optimizely",
    "bugsnag", "sentry", "cloudflareinsights",
    // attribution and push spam
    "branch.io", "appsflyer", "adjust.com", "kochava", "onesignal",
    "pushwoosh", "pushnami", "notix",
    // mobile ad SDK endpoints
    "adcolony", "unityads", "vungle", "applovin",
    // social widgets and share bars
    "disqus", "addthis", "sharethis", "snapchat.com"
)

/** Matched against the whole URL, for adverts hosted on a normal domain. */
private val AD_URL_FRAGMENTS = listOf(
    "facebook.com/tr", "platform.twitter", "twitter.com/widgets",
    "/pagead/", "/adsbygoogle", "/gtag/js", "/gtm.js", "/piwik.php",
    "/matomo.php", "/analytics.js", "/collect?v=", "/ad-delivery"
)

/**
 * Matched only when the request is a script.
 *
 * Every word here is common enough to appear in a legitimate path, so none of
 * them may be trusted against images, stylesheets or documents.
 */
private val AD_SCRIPT_FRAGMENTS = listOf(
    "tracking", "analytics", "telemetry", "beacon", "pixel", "advert",
    "adsense", "adsbygoogle", "popunder", "prebid", "gpt.js", "gtm",
    "statcounter", "partner.googleadservices"
)

/**
 * Cosmetic filtering, injected once the page has settled.
 *
 * Network blocking removes the advert; it does not always remove the hole the
 * advert left, and some sites reserve a tall empty slot that then pushes the
 * chapter text off screen. This hides the containers themselves.
 *
 * Kept deliberately narrow. Every selector names an ad slot explicitly -- no
 * guessing at generic class names, because on a novel site a wrong guess hides
 * the chapter.
 */
const val AD_COSMETIC_JS = """
(function(){
  if (document.getElementById('lorelight-adblock')) { return; }
  var s = document.createElement('style');
  s.id = 'lorelight-adblock';
  s.textContent =
    'ins.adsbygoogle,' +
    '[id^="div-gpt-ad"],' +
    '[id*="google_ads"],' +
    '[class*="adsbygoogle"],' +
    'iframe[src*="doubleclick"],' +
    'iframe[src*="googlesyndication"],' +
    'iframe[src*="adservice"],' +
    'iframe[src*="amazon-adsystem"],' +
    '[id*="taboola"],' +
    '[id*="outbrain"],' +
    '[class*="trc_related"],' +
    '[class*="ad-container"],' +
    '[class*="ad-banner"],' +
    '[class*="ad-slot"],' +
    '[class*="ad-wrapper"],' +
    '[id*="banner-ad"]' +
    '{display:none !important;height:0 !important;min-height:0 !important;}';
  (document.head || document.documentElement).appendChild(s);
})();
"""

fun cleanBrowserTitle(title: String, url: String?): String {
    if (title.isBlank()) {
        if (!url.isNullOrEmpty()) {
            return try {
                val uri = android.net.Uri.parse(url)
                val domain = uri.host ?: url
                domain.removePrefix("www.").substringBeforeLast(".")
            } catch (e: Exception) {
                url
            }
        }
        return ""
    }

    var clean = title.trim()
    clean = clean.replace(" \u2014 ", " - ")
        .replace(" \u2015 ", " - ")
        .replace(" \u2013 ", " - ")
        .replace(" \u2012 ", " - ")
        .replace(" | ", " - ")
        .replace(" |", " - ")
        .replace("| ", " - ")
        .replace(" : ", " - ")

    if (clean.contains(" - ")) {
        val parts = clean.split(" - ")
        val p1 = parts[0].trim()
        val p2 = parts[1].trim()

        val isP1Slogan = isGenericSlogan(p1)
        val isP2Slogan = isGenericSlogan(p2)

        clean = when {
            isP1Slogan && !isP2Slogan -> p2
            !isP1Slogan && isP2Slogan -> p1
            !isP1Slogan && !isP2Slogan -> p1
            else -> if (p1.length < p2.length) p1 else p2
        }
    }

    clean = removeSloganGarbage(clean)

    if (clean.isBlank()) {
        if (!url.isNullOrEmpty()) {
            return try {
                val uri = android.net.Uri.parse(url)
                val domain = uri.host ?: url
                domain.removePrefix("www.").substringBeforeLast(".")
            } catch (e: Exception) {
                ""
            }
        }
    }
    return clean
}

fun isGenericSlogan(text: String): Boolean {
    val lower = text.lowercase()
    val slogans = listOf(
        "read novels online",
        "read novel online",
        "read books online",
        "read light novel",
        "read light novels",
        "free online novels",
        "free web novel",
        "free online books",
        "read web novel",
        "novel online",
        "light novel online",
        "read online free",
        "read for free",
        "read novels for free",
        "free novels online",
        "read free web novel"
    )
    for (slogan in slogans) {
        if (lower == slogan || lower.contains(slogan) || slogan.contains(lower)) {
            return true
        }
    }
    val keywords = listOf("read", "novel", "novels", "online", "free", "book", "books", "light", "web")
    var matchCount = 0
    for (kw in keywords) {
        if (lower.contains(kw)) {
            matchCount++
        }
    }
    return matchCount >= 3
}

fun removeSloganGarbage(text: String): String {
    var t = text
    val patternsToStrip = listOf(
        "(?i)^read\\s+novels\\s+online\\s+for\\s+free",
        "(?i)^read\\s+books\\s+online\\s+free",
        "(?i)^read\\s+novels\\s+online",
        "(?i)^read\\s+novel\\s+online",
        "(?i)^read\\s+light\\s+novel\\s+online",
        "(?i)^read\\s+light\\s+novel",
        "(?i)^read\\s+web\\s+novel",
        "(?i)^read\\s+",
        "(?i)\\s+online\\s+for\\s+free$",
        "(?i)\\s+online\\s+free$",
        "(?i)\\s+for\\s+free$",
        "(?i)\\s+free$",
        "(?i)webnovel$",
        "(?i)novelfull$",
        "(?i)royalroad$",
        "(?i)lightnovelpub$"
    )
    for (pat in patternsToStrip) {
        t = t.replace(Regex(pat), "")
    }
    return t.trim().trim('-', '|', ':', ' ')
}
