package com.lorelight.ui.theme.modeswitch.celestial

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** A top-down stone vessel. No bitmaps, resource textures, or frame-clock loop. */
@Composable
fun CelestialAltarArt(
    isLight: Boolean,
    modifier: Modifier = Modifier,
    openAmount: Float = 0f,
    themeId: String = "forest"
) {
    Canvas(modifier) {
        drawCelestialAltar(size, isLight, openAmount, 0f, themeId)
    }
}

/** Legacy decorative API retained for callers outside the bottom navigation. */
@Composable
fun CelestialAltarWell(isLight: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (size.minDimension <= 0f) return@Canvas
        drawCircle(
            Brush.radialGradient(listOf(Color.Black.copy(alpha = if (isLight) 0.1f else 0.25f), Color.Transparent)),
            radius = size.minDimension * 0.48f
        )
    }
}

private enum class StoneStory { FOREST, BLOOD, GOLD, ROSE, OBSIDIAN, OCEAN, CYAN, AMETHYST, PORCELAIN }
private data class StoneMaterial(val story: StoneStory, val base: Color, val light: Color, val dark: Color, val detail: Color)

private fun stoneMaterial(theme: String): StoneMaterial = when (theme) {
    "readerblood" -> StoneMaterial(StoneStory.BLOOD, Color(0xFF514B4D), Color(0xFF969092), Color(0xFF211E26), Color(0xFF701C23))
    "blackgold" -> StoneMaterial(StoneStory.GOLD, Color(0xFF38302B), Color(0xFF807567), Color(0xFF151416), Color(0xFFD8AE63))
    "Satin Pink" -> StoneMaterial(StoneStory.ROSE, Color(0xFF9A7C7B), Color(0xFFD4BBB2), Color(0xFF483840), Color(0xFFB96083))
    "readerblacknew" -> StoneMaterial(StoneStory.OBSIDIAN, Color(0xFF343540), Color(0xFF686B7C), Color(0xFF12131C), Color(0xFFA4A9B8))
    "Ocean Blue" -> StoneMaterial(StoneStory.OCEAN, Color(0xFF687B7B), Color(0xFFB0C2B7), Color(0xFF293B47), Color(0xFFB9D8D2))
    "cyne" -> StoneMaterial(StoneStory.CYAN, Color(0xFF485D61), Color(0xFF8BA8AB), Color(0xFF192D33), Color(0xFF62D5CC))
    "readerpurple" -> StoneMaterial(StoneStory.AMETHYST, Color(0xFF68606F), Color(0xFFA89BAD), Color(0xFF2C243D), Color(0xFFB295E3))
    "readerwhite" -> StoneMaterial(StoneStory.PORCELAIN, Color(0xFFC8BAA8), Color(0xFFF4E9D5), Color(0xFF70695E), Color(0xFFAA8654))
    else -> StoneMaterial(StoneStory.FOREST, Color(0xFF7C7B66), Color(0xFFBCB99A), Color(0xFF343E35), Color(0xFF638742))
}

private fun stonePoint(c: Offset, r: Float, degrees: Float): Offset {
    val a = degrees * PI.toFloat() / 180f
    return Offset(c.x + cos(a) * r, c.y + sin(a) * r)
}
private fun stoneNoise(i: Int): Float {
    val v = sin(i * 73.17f + 17.31f) * 4375.31f
    return v - kotlin.math.floor(v)
}
private fun rockyOutline(c: Offset, r: Float): Path = Path().apply {
    repeat(72) { i ->
        val p = stonePoint(c, r * (0.979f + 0.021f * stoneNoise(i)), i * 5f)
        if (i == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y)
    }
    close()
}

/**
 * Same entry point as the old altar, now a circular overhead bowl.
 * A 96 x 72 dp drawing box gives a ~71 dp stone body against 64 dp panels.
 * The 88 dp navigation gutter remains unchanged. Only the short necks touch
 * panel edges; the circle and all leaf/crystal details stay inside the gutter.
 */
@Suppress("UNUSED_PARAMETER")
fun DrawScope.drawCelestialAltar(
    size: Size,
    isLight: Boolean,
    openAmount: Float,
    timeSec: Float,
    themeId: String = "forest"
) {
    if (size.minDimension <= 0f) return
    val c = Offset(size.width * 0.5f, size.height * 0.5f)
    val r = minOf(size.height * 0.49f, size.width * 0.39f)
    val hole = r * 0.80f
    val m = stoneMaterial(themeId)
    val base = if (isLight) lerp(m.base, m.light, 0.15f) else m.base
    val rim = rockyOutline(c, r)
    val annulus = rockyOutline(c, r).apply {
        fillType = PathFillType.EvenOdd
        addOval(Rect(c.x - hole, c.y - hole, c.x + hole, c.y + hole))
    }
    // Soft cast shadow: broad enough for depth, not a giant decorative halo.
    drawCircle(
        Brush.radialGradient(0.6f to Color.Black.copy(alpha = 0.48f), 1f to Color.Transparent,
            center = c + Offset(0f, r * 0.09f), radius = r * 1.12f),
        radius = r * 1.12f, center = c + Offset(0f, r * 0.09f)
    )
    // Dark lower bevel followed by the upper rock surface.
    translate(top = r * 0.045f) { drawPath(rim, m.dark) }
    drawPath(rim, Brush.linearGradient(listOf(m.light, base, m.dark), c - Offset(r, r), c + Offset(r, r)))
    // Deliberate rough mineral grain, clipped to the rim rather than the face.
    clipPath(annulus) {
        repeat(100) { i ->
            val p = stonePoint(c, r * (0.79f + 0.2f * stoneNoise(i + 180)), stoneNoise(i + 260) * 360f)
            drawCircle(if (i % 2 == 0) m.light.copy(alpha = 0.32f) else m.dark.copy(alpha = 0.35f), r * (0.004f + 0.012f * stoneNoise(i + 80)), p)
        }
        repeat(9) { i ->
            val a = i * 39f + 12f
            val p = stonePoint(c, r * 0.99f, a)
            val q = stonePoint(c, r * 0.91f, a + 3f)
            val end = stonePoint(c, r * 0.82f, a - 1.5f)
            val crack = Path().apply { moveTo(p.x, p.y); lineTo(q.x, q.y); lineTo(end.x, end.y) }
            translate(left = r * 0.012f, top = r * 0.009f) { drawPath(crack, m.light.copy(alpha = 0.5f), style = Stroke(r * 0.025f)) }
            drawPath(crack, m.dark.copy(alpha = 0.82f), style = Stroke(r * 0.021f, cap = StrokeCap.Round))
            if (m.story == StoneStory.GOLD || m.story == StoneStory.PORCELAIN) {
                drawPath(crack, m.detail, style = Stroke(r * 0.013f, cap = StrokeCap.Round))
            }
        }
    }
    // Concave inner wall: upper inner edge is occluded, lower edge catches light.
    drawCircle(Brush.linearGradient(listOf(m.dark, lerp(base, m.dark, 0.55f), m.light), c - Offset(0f, hole), c + Offset(0f, hole)), hole, c)
    drawCircle(Brush.radialGradient(0f to m.dark, 0.76f to lerp(m.dark, Color.Black, 0.4f), 1f to m.dark,
        center = c - Offset(hole * 0.1f, hole * 0.1f), radius = hole), hole * 0.91f, c)
    drawArc(m.light.copy(alpha = 0.7f), 36f, 105f, false, c - Offset(hole, hole), Size(hole * 2, hole * 2), style = Stroke(r * 0.022f, cap = StrokeCap.Round))
    drawArc(m.light.copy(alpha = 0.7f), 190f, 110f, false, c - Offset(r * 0.974f, r * 0.974f), Size(r * 1.948f, r * 1.948f), style = Stroke(r * 0.024f, cap = StrokeCap.Round))

    when (m.story) {
        StoneStory.FOREST -> {
            // Moss grows locally from cracks; it is not a green stone tint.
            for (angle in listOf(218f, 296f, 64f)) {
                repeat(13) { i ->
                    val p = stonePoint(c, r * (0.88f + 0.09f * stoneNoise(i + 3)), angle + (stoneNoise(i + 60) - 0.5f) * 31f)
                    val mr = r * (0.028f + 0.023f * stoneNoise(i + 30))
                    drawCircle(Color(0xFF344A29), mr * 1.1f, p + Offset(0f, r * 0.014f))
                    drawCircle(lerp(Color(0xFF466231), Color(0xFF9EA966), stoneNoise(i + 20)), mr, p)
                }
            }
            leaf(stonePoint(c, r * 0.96f, 224f), r * 0.23f, -45f, Color(0xFF899951), Color(0xFF354727))
            leaf(stonePoint(c, r * 0.96f, 54f), r * 0.19f, 28f, Color(0xFFA1A763), Color(0xFF475232))
        }
        StoneStory.BLOOD -> clipPath(annulus) {
            for (a in listOf(205f, 316f, 65f)) {
                val stain = Path()
                repeat(10) { i ->
                    val p = stonePoint(c, r * (0.9f + 0.018f * sin(i * 2f)), a + i * 2.1f)
                    if (i == 0) stain.moveTo(p.x, p.y) else stain.lineTo(p.x, p.y)
                }
                drawPath(stain, m.detail.copy(alpha = 0.92f), style = Stroke(r * 0.075f, cap = StrokeCap.Round))
                repeat(4) { i -> drawCircle(Color(0xFF45171C), r * (0.013f + i * 0.004f), stonePoint(c, r * (0.83f + i * 0.038f), a - 7f)) }
            }
        }
        StoneStory.ROSE -> {
            for (i in 0..3) leaf(stonePoint(c, r * 0.93f, 220f + i * 8), r * 0.20f, i * 52f, m.detail, Color(0xFFF0B7BB))
            leaf(stonePoint(c, r * 0.93f, 42f), r * 0.17f, -20f, Color(0xFF7B8258), Color(0xFF444F37))
        }
        StoneStory.CYAN, StoneStory.AMETHYST -> {
            for (a in listOf(228f, 48f)) repeat(3) { i ->
                val p = stonePoint(c, r * 0.94f, a + i * 7)
                val tip = stonePoint(p, r * (0.13f + i * 0.015f), a - 30f)
                val facet = Path().apply { moveTo(p.x - r * 0.035f, p.y); lineTo(tip.x, tip.y); lineTo(p.x + r * 0.04f, p.y + r * 0.05f); close() }
                drawPath(facet, Brush.linearGradient(listOf(m.light, m.detail, m.dark), tip, p))
                drawLine(m.light, p, tip, r * 0.012f)
            }
        }
        StoneStory.OCEAN -> {
            // Water-worn pale rings and small shell-like deposits, not blue paint.
            for (a in listOf(216f, 224f, 46f)) {
                val p = stonePoint(c, r * 0.92f, a)
                drawCircle(m.detail, r * 0.065f, p)
                drawCircle(m.dark.copy(alpha = 0.8f), r * 0.036f, p)
                drawCircle(m.light, r * 0.017f, p + Offset(r * 0.009f, r * 0.013f))
            }
            drawArc(m.detail.copy(alpha = 0.5f), 273f, 34f, false, c - Offset(r * 0.9f, r * 0.9f), Size(r * 1.8f, r * 1.8f), style = Stroke(r * 0.02f))
        }
        StoneStory.OBSIDIAN -> {
            for (a in listOf(222f, 312f, 56f)) {
                val p = stonePoint(c, r * 0.96f, a)
                val q = stonePoint(c, r * 0.84f, a + 10f)
                drawLine(m.detail.copy(alpha = 0.75f), p, q, r * 0.024f)
            }
        }
        else -> Unit // GOLD / PORCELAIN tell their story through repair veins.
    }
    val awake = openAmount.coerceIn(0f, 1f)
    if (awake > 0.001f) {
        drawCircle(Brush.radialGradient(0.4f to Color.Transparent, 0.84f to m.light.copy(alpha = awake * 0.28f), 1f to Color.Transparent, center = c, radius = hole), hole, c)
    }
}

private fun DrawScope.leaf(c: Offset, length: Float, angle: Float, light: Color, dark: Color) {
    val tip = stonePoint(c, length, angle)
    val mid = Offset((c.x + tip.x) * 0.5f, (c.y + tip.y) * 0.5f)
    val normal = Offset(-(tip.y - c.y) * 0.32f, (tip.x - c.x) * 0.32f)
    val path = Path().apply {
        moveTo(c.x, c.y)
        quadraticBezierTo(mid.x + normal.x, mid.y + normal.y, tip.x, tip.y)
        quadraticBezierTo(mid.x - normal.x, mid.y - normal.y, c.x, c.y)
        close()
    }
    drawPath(path, Brush.linearGradient(listOf(light, dark), tip, c))
    drawLine(light.copy(alpha = 0.7f), c, tip, length * 0.055f, cap = StrokeCap.Round)
}
