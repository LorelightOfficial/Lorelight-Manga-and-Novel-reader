package com.lorelight.manga.reader

import eu.kanade.tachiyomi.source.model.Page

data class LoadedChapter(
    val chapterId: String,
    val chapterIndex: Int,
    val chapterName: String,
    val pages: List<Page>
)

sealed interface MangaFeedItem {
    data class Page(
        val chapterId: String,
        val chapterIndex: Int,
        val pageIndex: Int,
        val pageCount: Int,
        val imageUrl: String,
        val sourcePage: eu.kanade.tachiyomi.source.model.Page? = null
    ) : MangaFeedItem

    data class Transition(
        val kind: Kind,
        val fromChapterName: String?,
        val toChapterName: String?,     // null == no such chapter
        val toChapterIndex: Int?
    ) : MangaFeedItem {
        enum class Kind { PREV, NEXT }
    }
}

/**
 * Marks a feed key as belonging to a PAGE rather than a chapter transition.
 *
 * The viewer's position tracker identifies the row it is looking at by this key
 * instead of by its index in the feed, so the prefix has to be readable from
 * the key alone. Kept beside [feedItemKey] so the two can never disagree.
 */
internal const val PAGE_KEY_PREFIX = "p:"

internal fun feedItemKey(item: MangaFeedItem): String = when (item) {
    is MangaFeedItem.Page -> PAGE_KEY_PREFIX + item.chapterId + ":" + item.pageIndex
    is MangaFeedItem.Transition -> "t:" + item.kind.name + ":" + (item.toChapterIndex ?: -1)
}

internal fun buildFeedItems(
    prev: LoadedChapter?,      // null when there is no previous chapter
    curr: LoadedChapter,
    next: LoadedChapter?,      // null when there is no next chapter
    forceTransition: Boolean,
    hasNextChapter: Boolean = next != null,
    hasPrevChapter: Boolean = prev != null,
    nextChapterName: String? = next?.chapterName,
    prevChapterName: String? = prev?.chapterName,
    nextChapterIndex: Int? = next?.chapterIndex,
    prevChapterIndex: Int? = prev?.chapterIndex
): List<MangaFeedItem> {
    val result = mutableListOf<MangaFeedItem>()

    // 1. prev pages, if prev is loaded
    if (prev != null) {
        prev.pages.forEachIndexed { index, page ->
            result.add(
                MangaFeedItem.Page(
                    chapterId = prev.chapterId,
                    chapterIndex = prev.chapterIndex,
                    pageIndex = index,
                    pageCount = prev.pages.size,
                    imageUrl = page.imageUrl ?: page.url,
                    sourcePage = page
                )
            )
        }
    }

    // 2. Transition.PREV, added when forceTransition is true OR prev is null
    if (forceTransition || prev == null) {
        result.add(
            MangaFeedItem.Transition(
                kind = MangaFeedItem.Transition.Kind.PREV,
                fromChapterName = curr.chapterName,
                toChapterName = if (prev != null) prev.chapterName else if (hasPrevChapter) prevChapterName else null,
                toChapterIndex = if (prev != null) prev.chapterIndex else if (hasPrevChapter) prevChapterIndex else null
            )
        )
    }

    // 3. curr pages
    curr.pages.forEachIndexed { index, page ->
        result.add(
            MangaFeedItem.Page(
                chapterId = curr.chapterId,
                chapterIndex = curr.chapterIndex,
                pageIndex = index,
                pageCount = curr.pages.size,
                imageUrl = page.imageUrl ?: page.url,
                sourcePage = page
            )
        )
    }

    // 4. Transition.NEXT, added when forceTransition is true OR next is null
    if (forceTransition || next == null) {
        result.add(
            MangaFeedItem.Transition(
                kind = MangaFeedItem.Transition.Kind.NEXT,
                fromChapterName = curr.chapterName,
                toChapterName = if (next != null) next.chapterName else if (hasNextChapter) nextChapterName else null,
                toChapterIndex = if (next != null) next.chapterIndex else if (hasNextChapter) nextChapterIndex else null
            )
        )
    }

    // 5. next pages, if next is loaded
    if (next != null) {
        next.pages.forEachIndexed { index, page ->
            result.add(
                MangaFeedItem.Page(
                    chapterId = next.chapterId,
                    chapterIndex = next.chapterIndex,
                    pageIndex = index,
                    pageCount = next.pages.size,
                    imageUrl = page.imageUrl ?: page.url,
                    sourcePage = page
                )
            )
        }
    }

    return result
}
