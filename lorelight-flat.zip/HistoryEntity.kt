package com.lorelight.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

// FIX #28: getAll() is "ORDER BY timestamp DESC" on a previously unindexed
// column, forcing a full scan plus sort on every history load.
@Entity(
    tableName = "history",
    indices = [Index(value = ["timestamp"])]
)
data class HistoryEntity(
    @PrimaryKey val novelId: String,
    val novelTitle: String,
    val chapterId: String,
    val chapterTitle: String,
    val timestamp: Long,
    val lastModified: Long,
    val novelJson: String,
    // RESUME REDESIGN. chapterId/chapterTitle are both the same chapter NAME,
    // which is why the history card could not tell the player where to resume.
    // This is the real index. -1 = nothing recorded.
    val chapterIndex: Int = -1
)
