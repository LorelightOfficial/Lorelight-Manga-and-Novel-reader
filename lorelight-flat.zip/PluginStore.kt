package com.lorelight.browse.repo

import android.content.Context
import com.lorelight.browse.model.InstalledPlugin
import com.lorelight.browse.model.PluginInfo
import org.json.JSONArray
import org.json.JSONObject

object PluginStore {
    private const val PREFS = "lorelight_browse_prefs"
    private const val KEY_INSTALLED = "installed_plugins"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getInstalled(context: Context): List<InstalledPlugin> {
        val raw = prefs(context).getString(KEY_INSTALLED, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                fromJson(o)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(context: Context, plugin: InstalledPlugin) {
        val list = getInstalled(context).toMutableList()
        val idx = list.indexOfFirst { it.info.id == plugin.info.id }
        if (idx >= 0) list[idx] = plugin else list.add(plugin)
        persist(context, list)
    }

    fun remove(context: Context, id: String) {
        val list = getInstalled(context).filterNot { it.info.id == id }
        persist(context, list)
    }

    fun setPinned(context: Context, id: String, pinned: Boolean) {
        val list = getInstalled(context).map {
            if (it.info.id == id) it.copy(pinned = pinned) else it
        }
        persist(context, list)
    }

    private fun persist(context: Context, list: List<InstalledPlugin>) {
        val arr = JSONArray()
        list.forEach { arr.put(toJson(it)) }
        prefs(context).edit().putString(KEY_INSTALLED, arr.toString()).apply()
    }

    private fun toJson(p: InstalledPlugin): JSONObject {
        val info = JSONObject()
            .put("id", p.info.id)
            .put("name", p.info.name)
            .put("site", p.info.site)
            .put("lang", p.info.lang)
            .put("version", p.info.version)
            .put("url", p.info.url)
            .put("iconUrl", p.info.iconUrl)
            .put("hasSettings", p.info.hasSettings)
            .put("hasUpdate", p.info.hasUpdate)
            .put("repoUrl", p.info.repoUrl)
            .put("customJS", p.info.customJS ?: JSONObject.NULL)
            .put("customCSS", p.info.customCSS ?: JSONObject.NULL)
        return JSONObject()
            .put("info", info)
            .put("filePath", p.filePath)
            .put("installedVersion", p.installedVersion)
            .put("pinned", p.pinned)
    }

    private fun fromJson(o: JSONObject): InstalledPlugin {
        val i = o.getJSONObject("info")
        val info = PluginInfo(
            id = i.optString("id", ""),
            name = i.optString("name", ""),
            site = i.optString("site", ""),
            lang = i.optString("lang", "Unknown"),
            version = i.optString("version", "0.0.0"),
            url = i.optString("url", ""),
            iconUrl = i.optString("iconUrl", ""),
            hasSettings = i.optBoolean("hasSettings", false),
            hasUpdate = i.optBoolean("hasUpdate", false),
            repoUrl = i.optString("repoUrl", ""),
            customJS = i.optString("customJS", "").ifEmpty { null }.takeIf { it != "null" },
            customCSS = i.optString("customCSS", "").ifEmpty { null }.takeIf { it != "null" }
        )
        return InstalledPlugin(
            info = info,
            filePath = o.optString("filePath", ""),
            installedVersion = o.optString("installedVersion", info.version),
            pinned = o.optBoolean("pinned", false)
        )
    }
}
