package com.lorelight.manga.reader
import com.lorelight.R
import androidx.compose.ui.res.stringResource


import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

enum class MangaNavRegion(val label: String, val color: Color) {
    MENU("MENU", Color(0xCC95818D)),
    PREV("PREV", Color(0xCCFF7733)),
    NEXT("NEXT", Color(0xCC84E296)),
    LEFT("LEFT", Color(0xCC7D1128)),
    RIGHT("RIGHT", Color(0xCCA6CFD5))
}

@Composable
fun mangaNavRegionLabel(region: MangaNavRegion): String = when (region) {
    MangaNavRegion.MENU -> stringResource(R.string.manga_nav_region_menu)
    MangaNavRegion.PREV -> stringResource(R.string.manga_nav_region_prev)
    MangaNavRegion.NEXT -> stringResource(R.string.manga_nav_region_next)
    MangaNavRegion.LEFT -> stringResource(R.string.manga_nav_region_left)
    MangaNavRegion.RIGHT -> stringResource(R.string.manga_nav_region_right)
}

enum class MangaTapZoneLayout {
    DISABLED,
    L_SHAPE,
    KINDLISH,
    EDGE,
    RIGHT_AND_LEFT
}

enum class MangaTapInvert {
    NONE,
    HORIZONTAL,
    VERTICAL,
    BOTH
}

data class TapRegionRect(
    val region: MangaNavRegion,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
)

internal fun transformRect(
    rect: TapRegionRect,
    invert: MangaTapInvert
): TapRegionRect {
    val invertH = invert == MangaTapInvert.HORIZONTAL || invert == MangaTapInvert.BOTH
    val invertV = invert == MangaTapInvert.VERTICAL || invert == MangaTapInvert.BOTH

    val l = if (invertH) 1f - rect.right else rect.left
    val r = if (invertH) 1f - rect.left else rect.right
    val t = if (invertV) 1f - rect.bottom else rect.top
    val b = if (invertV) 1f - rect.top else rect.bottom

    return TapRegionRect(rect.region, l, t, r, b)
}

internal fun getLayoutRects(layout: MangaTapZoneLayout): List<TapRegionRect> {
    return when (layout) {
        MangaTapZoneLayout.DISABLED -> emptyList()
        MangaTapZoneLayout.L_SHAPE -> listOf(
            TapRegionRect(MangaNavRegion.PREV, 0f, 0f, 1f, 0.33f),
            TapRegionRect(MangaNavRegion.PREV, 0f, 0.33f, 0.33f, 0.66f),
            TapRegionRect(MangaNavRegion.NEXT, 0.66f, 0.33f, 1f, 0.66f),
            TapRegionRect(MangaNavRegion.NEXT, 0f, 0.66f, 1f, 1f)
        )
        MangaTapZoneLayout.KINDLISH -> listOf(
            TapRegionRect(MangaNavRegion.PREV, 0f, 0.33f, 0.33f, 1f),
            TapRegionRect(MangaNavRegion.NEXT, 0.33f, 0.33f, 1f, 1f)
        )
        MangaTapZoneLayout.EDGE -> listOf(
            TapRegionRect(MangaNavRegion.NEXT, 0f, 0f, 0.33f, 1f),
            TapRegionRect(MangaNavRegion.PREV, 0.33f, 0.66f, 0.66f, 1f),
            TapRegionRect(MangaNavRegion.NEXT, 0.66f, 0f, 1f, 1f)
        )
        MangaTapZoneLayout.RIGHT_AND_LEFT -> listOf(
            TapRegionRect(MangaNavRegion.LEFT, 0f, 0f, 0.33f, 1f),
            TapRegionRect(MangaNavRegion.RIGHT, 0.66f, 0f, 1f, 1f)
        )
    }
}

internal fun tapZoneFor(
    tapOffset: androidx.compose.ui.geometry.Offset,
    viewportSize: androidx.compose.ui.unit.IntSize,
    layout: MangaTapZoneLayout,
    invert: MangaTapInvert,
    tapZonesEnabled: Boolean = true
): MangaNavRegion {
    if (!tapZonesEnabled) return MangaNavRegion.MENU
    val xFrac = if (viewportSize.width > 0) tapOffset.x / viewportSize.width else 0f
    val yFrac = if (viewportSize.height > 0) tapOffset.y / viewportSize.height else 0f
    return tapZoneFor(xFrac, yFrac, layout, invert, tapZonesEnabled)
}

internal fun tapZoneFor(
    xFraction: Float,
    yFraction: Float,
    layout: MangaTapZoneLayout,
    invert: MangaTapInvert,
    tapZonesEnabled: Boolean = true
): MangaNavRegion {
    if (!tapZonesEnabled) return MangaNavRegion.MENU
    val x = xFraction.coerceIn(0f, 1f)
    val y = yFraction.coerceIn(0f, 1f)

    // Constant MENU strip (0, 0, 1, 0.05) always wins if y <= 0.05
    if (y <= 0.05f) return MangaNavRegion.MENU

    val rawRects = getLayoutRects(layout)
    for (rect in rawRects) {
        val tRect = transformRect(rect, invert)
        if (x in tRect.left..tRect.right && y in tRect.top..tRect.bottom) {
            return tRect.region
        }
    }

    return MangaNavRegion.MENU
}

internal fun computeRemainingDown(
    itemOffset: Int,
    itemSize: Int,
    viewportStart: Int
): Int = ((itemOffset + itemSize) - viewportStart).coerceAtLeast(1)

internal fun computeRemainingUp(
    itemOffset: Int,
    viewportEnd: Int
): Int = (viewportEnd - itemOffset).coerceAtLeast(1)

internal fun nextImageScroll(
    remainingPxInCurrentPage: Int,
    viewportHeightPx: Int
): Int = if (remainingPxInCurrentPage > viewportHeightPx) viewportHeightPx * 3 / 4
         else remainingPxInCurrentPage


@Composable
fun MangaTapZoneDemoOverlay(
    visible: Boolean,
    layout: MangaTapZoneLayout,
    invert: MangaTapInvert,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    LaunchedEffect(visible, layout, invert) {
        if (visible) {
            delay(1500)
            onDismiss()
        }
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = modifier
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    role = Role.Button,
                    onClickLabel = "Dismiss"
                ) { onDismiss() }
        ) {
            val rects = getLayoutRects(layout)
            
            // Constant menu strip
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.05f)
                    .background(MangaNavRegion.MENU.color),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = mangaNavRegionLabel(MangaNavRegion.MENU),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }

            rects.forEach { rect ->
                val tRect = transformRect(rect, invert)
                val leftPx = constraints.maxWidth * tRect.left
                val topPx = constraints.maxHeight * tRect.top
                val widthPx = constraints.maxWidth * (tRect.right - tRect.left)
                val heightPx = constraints.maxHeight * (tRect.bottom - tRect.top)

                Box(
                    modifier = Modifier
                        .offset(
                            x = with(androidx.compose.ui.platform.LocalDensity.current) { leftPx.toDp() },
                            y = with(androidx.compose.ui.platform.LocalDensity.current) { topPx.toDp() }
                        )
                        .size(
                            width = with(androidx.compose.ui.platform.LocalDensity.current) { widthPx.toDp() },
                            height = with(androidx.compose.ui.platform.LocalDensity.current) { heightPx.toDp() }
                        )
                        .background(rect.region.color),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = mangaNavRegionLabel(rect.region),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}
