package com.lorelight.ui.reader

import com.lorelight.R
import androidx.compose.ui.res.stringResource

import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.semantics.Role
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import com.lorelight.ui.components.LorelightDialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.zIndex
import com.lorelight.data.model.Novel
import com.lorelight.ui.components.FontManagerEngine
import com.lorelight.ui.components.resolveFontFamily
import com.lorelight.ui.components.readerSafeTopPadding
import com.lorelight.ui.theme.GoldOnGradient
import com.lorelight.ui.theme.RefinedGoldGradient
import com.lorelight.ui.theme.GlassPanel
import com.lorelight.utils.FilterRule
import com.lorelight.utils.TextFilter

private val SettingCardRadius = 14.dp
private val SettingCardPadding = 14.dp     // inner padding of a card
private val SettingRowMinHeight = 48.dp    // touch target
private val SettingGroupGap = 14.dp        // gap between cards
private val SettingInnerGap = 12.dp        // gap between rows inside a card

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun ReaderSettingsSheet(
    showSettingsDialog: Boolean,
    onDismissSettings: () -> Unit,
    showTextFilterPanel: Boolean,
    onSetTextFilterPanelVisible: (Boolean) -> Unit,
    viewModel: ReaderViewModel,
    activeNovel: Novel?,
    readerTextColor: Color,
    readerHighlightColor: Color,
    themeState: String,
    onOpenFontManager: () -> Unit,
    onResetSelection: () -> Unit
) {
    val context = LocalContext.current

    val readerMode by viewModel.readerMode.collectAsState()
    val fontSize by viewModel.readerFontSize.collectAsState()
    val lineSpacing by viewModel.readerLineSpacing.collectAsState()
    val paragraphSpacing by viewModel.readerParagraphSpacing.collectAsState()
    val textAlignment by viewModel.readerTextAlignment.collectAsState()
    val readerBackgroundType by viewModel.readerBackgroundType.collectAsState()
    val readerTextColorRaw by viewModel.readerTextColor.collectAsState()
    val readerBgColorRaw by viewModel.readerBgColor.collectAsState()
    val readerFontFamily by viewModel.readerFontFamily.collectAsState()
    val isDefaultHighlight by viewModel.isDefaultHighlight.collectAsState()
    val customHighlightColorRaw by viewModel.customHighlightColor.collectAsState()
    val textFilterRules by viewModel.textFilterRules.collectAsState()
    val isTapNavigationEnabled by viewModel.isTapNavigationEnabled.collectAsState()

    // Listen TTS specific settings
    val selectedAccent by viewModel.selectedAccent.collectAsState()
    val selectedVoice by viewModel.selectedVoice.collectAsState()
    val speechRate by viewModel.speechRate.collectAsState()
    val availableAccents by viewModel.availableAccents.collectAsState()
    val filteredVoices by viewModel.filteredVoices.collectAsState()

    // Local Display states for custom Dialog pickers
    var showFontSelectionDialog by remember { mutableStateOf(false) }
    var showColorWheelDialog by remember { mutableStateOf(false) }
    var showNovelTextColorPicker by remember { mutableStateOf(false) }
    var showBgColorPicker by remember { mutableStateOf(false) }
    var showDownloadedFontsDialog by remember { mutableStateOf(false) }

    var isFontLayoutExpanded by remember { mutableStateOf(true) }
    var isThemeOptionsExpanded by remember { mutableStateOf(false) }
    var isReadingModesExpanded by remember { mutableStateOf(false) }

    val defaultHighlightColor = remember(themeState) { getDefaultHighlightColor(themeState) }

    AnimatedVisibility(
        visible = showSettingsDialog,
        enter = slideInHorizontally(
            initialOffsetX = { it },
            animationSpec = tween(260, easing = FastOutSlowInEasing)
        ) + fadeIn(tween(200)),
        exit = slideOutHorizontally(
            targetOffsetX = { it },
            animationSpec = tween(240)
        ) + fadeOut(tween(180))
    ) {
        // S9: the scrim is a real control to a screen reader, so it needs to
        // announce what tapping it does. Without a label TalkBack reads it as
        // an unnamed button covering the whole screen.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(0.55f))
                .clickable(onClickLabel = stringResource(R.string.a11y_close_settings)) { onDismissSettings() }
        ) {
            GlassPanel(
                shape = RoundedCornerShape(topStart = 20.dp, bottomStart = 20.dp),
                tintAlpha = 0.88f,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .fillMaxWidth(0.85f)
                    .clickable(enabled = false) {}
            ) {
                Column(modifier = Modifier.fillMaxSize().padding(top = readerSafeTopPadding()).padding(horizontal = 20.dp, vertical = 20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.reader_settings_title), fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                        IconButton(onClick = onDismissSettings) { 
                            Icon(Icons.Default.Close, contentDescription = stringResource(R.string.reader_font_close), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)) 
                        }
                    }
                    
                    // Tab Selection Row for Read and Listen
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                            .height(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                            .padding(4.dp)
                    ) {
                        listOf("Read", "Listen").forEach { tab ->
                            val isSelected = readerMode == tab
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                    .then(
                                        if (isSelected) Modifier.border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp))
                                        else Modifier
                                    )
                                    // S9: Role.Tab + selected state, so this reads
                                    // as a selected tab instead of a bare button.
                                    .selectable(
                                        selected = isSelected,
                                        role = Role.Tab,
                                        onClick = { viewModel.readerMode.value = tab }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = if (tab == "Read") Icons.Default.MenuBook else Icons.Default.Headphones,
                                        contentDescription = null,
                                        tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = tab,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                    
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(SettingGroupGap),
                        contentPadding = PaddingValues(top = 4.dp, bottom = 80.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        if (readerMode == "Read") {
                            // ------------------ READ TAB SETTINGS ------------------
                            // Page Formatting / Manage Text Filter
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_page_formatting), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .clickable(
                                                onClickLabel = stringResource(R.string.a11y_open_text_filters),
                                                role = Role.Button
                                            ) {
                                                onDismissSettings()
                                                onSetTextFilterPanelVisible(true)
                                            }
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.defaultMinSize(minHeight = SettingRowMinHeight)
                                        ) {
                                            Icon(Icons.Default.FilterAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text(stringResource(R.string.reader_manage_text_filter), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                                            ) {
                                                Text("${textFilterRules.size} active", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Icon(Icons.Default.ArrowForwardIos, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(12.dp))
                                        }
                                    }
                                }
                            }
                            
                            // Typography / Downloaded Fonts
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_typography), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .clickable(
                                                onClickLabel = stringResource(R.string.a11y_choose_downloaded_font),
                                                role = Role.Button
                                            ) { showDownloadedFontsDialog = true }
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.defaultMinSize(minHeight = SettingRowMinHeight)
                                        ) {
                                            Icon(Icons.Default.FontDownload, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(stringResource(R.string.reader_font_selection), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                                                Text(readerFontFamily, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                            }
                                            Icon(Icons.Default.ArrowForwardIos, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(12.dp))
                                        }
                                    }
                                }
                            }

                            // Text Sliders Group Card
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_text), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding),
                                        verticalArrangement = Arrangement.spacedBy(SettingInnerGap)
                                    ) {
                                        // Text Size
                                        Column {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text(stringResource(R.string.reader_text_size), fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${fontSize.toInt()}sp", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = fontSize,
                                                onValueChange = { viewModel.readerFontSize.value = it },
                                                valueRange = 12f..32f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                        // Line Spacing
                                        Column {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text(stringResource(R.string.reader_line_spacing), fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${"%.1fx".format(lineSpacing)}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = lineSpacing,
                                                onValueChange = { viewModel.readerLineSpacing.value = it },
                                                valueRange = 1.0f..2.5f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                        // Paragraph Spacing
                                        Column {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text(stringResource(R.string.reader_paragraph_spacing), fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${paragraphSpacing.toInt()}dp", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = paragraphSpacing,
                                                onValueChange = { viewModel.readerParagraphSpacing.value = it },
                                                valueRange = 0f..40f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }
                                    }
                                }
                            }

                            // Text Alignment
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_text_alignment), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            val alignOptions = listOf(
                                                Triple("Left", Icons.Default.FormatAlignLeft, "Left"),
                                                Triple("Center", Icons.Default.FormatAlignCenter, "Center"),
                                                Triple("Right", Icons.Default.FormatAlignRight, "Right"),
                                                Triple("Justify", Icons.Default.FormatAlignJustify, "Justify")
                                            )
                                            alignOptions.forEach { (align, icon, label) ->
                                                val isSelected = textAlignment == align
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(SettingRowMinHeight)
                                                        .clip(RoundedCornerShape(10.dp))
                                                        .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                                        .border(
                                                            width = if (isSelected) 1.5.dp else 1.dp,
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                                            shape = RoundedCornerShape(10.dp)
                                                        )
                                                        // S9: one-of-many choice, so RadioButton
                                                        // rather than Button - that is the role
                                                        // that makes a screen reader announce
                                                        // selected state within the group.
                                                        .selectable(
                                                            selected = isSelected,
                                                            role = Role.RadioButton,
                                                            onClick = { viewModel.readerTextAlignment.value = align }
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Column(
                                                        horizontalAlignment = Alignment.CenterHorizontally,
                                                        verticalArrangement = Arrangement.Center
                                                    ) {
                                                        Icon(
                                                            imageVector = icon,
                                                            contentDescription = label,
                                                            tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                        Text(
                                                            text = label, 
                                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal, 
                                                            fontSize = 11.sp, 
                                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Background Style
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_background_style), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            listOf("Theme", "Choose").forEach { bgType ->
                                                val isSelected = if (bgType == "Choose") {
                                                    (readerBackgroundType == "Choose" || readerBackgroundType == "AMOLED Black")
                                                } else {
                                                    readerBackgroundType == bgType
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(SettingRowMinHeight)
                                                        .clip(RoundedCornerShape(10.dp))
                                                        .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                                        .border(
                                                            width = if (isSelected) 1.5.dp else 1.dp,
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                                            shape = RoundedCornerShape(10.dp)
                                                        )
                                                        .selectable(
                                                            selected = isSelected,
                                                            role = Role.RadioButton,
                                                            onClick = {
                                                                if (bgType == "Choose") {
                                                                    showBgColorPicker = true
                                                                } else {
                                                                    viewModel.readerBackgroundType.value = bgType
                                                                }
                                                            }
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = bgType,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                        fontSize = 13.sp,
                                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Novel Text Color
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_novel_text_color), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .clickable(
                                                onClickLabel = stringResource(R.string.a11y_choose_text_color),
                                                role = Role.Button
                                            ) { showNovelTextColorPicker = true }
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.defaultMinSize(minHeight = SettingRowMinHeight)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(readerTextColorRaw))
                                                    .border(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f), CircleShape)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text(
                                                text = "Choose custom text color...",
                                                fontSize = 14.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                fontWeight = FontWeight.Medium,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Icon(
                                                Icons.Default.ColorLens,
                                                contentDescription = "Text Color Picker",
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            // ------------------ LISTEN TAB SETTINGS ------------------
                            // Novel Text Color
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_novel_text_color), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .clickable(
                                                onClickLabel = stringResource(R.string.a11y_choose_text_color),
                                                role = Role.Button
                                            ) { showNovelTextColorPicker = true }
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.defaultMinSize(minHeight = SettingRowMinHeight)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(readerTextColorRaw))
                                                    .border(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f), CircleShape)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text(
                                                text = "Choose custom text color...",
                                                fontSize = 14.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                fontWeight = FontWeight.Medium,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Icon(
                                                Icons.Default.ColorLens,
                                                contentDescription = "Text Color Picker",
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            // Page Formatting / Manage Text Filter
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_page_formatting), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .clickable(
                                                onClickLabel = stringResource(R.string.a11y_open_text_filters),
                                                role = Role.Button
                                            ) {
                                                onDismissSettings()
                                                onSetTextFilterPanelVisible(true)
                                            }
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.defaultMinSize(minHeight = SettingRowMinHeight)
                                        ) {
                                            Icon(Icons.Default.FilterAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text(stringResource(R.string.reader_manage_text_filter), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                                            ) {
                                                Text("${textFilterRules.size} active", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Icon(Icons.Default.ArrowForwardIos, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(12.dp))
                                        }
                                    }
                                }
                            }

                            // Visual Aesthetics (Switches Card)
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_visual_aesthetics), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding),
                                        verticalArrangement = Arrangement.spacedBy(SettingInnerGap)
                                    ) {
                                        // Auto-Next Chapter
                                        Row(
                                            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = SettingRowMinHeight),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "Auto-Next Chapter",
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 14.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            val autoNextChapter by viewModel.autoNextChapter.collectAsState()
                                            Switch(
                                                checked = autoNextChapter,
                                                onCheckedChange = { viewModel.setAutoNextChapter(it) },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = MaterialTheme.colorScheme.primary,
                                                    checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                                                )
                                            )
                                        }

                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                                        // Immersive Mode
                                        Row(
                                            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = SettingRowMinHeight),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "Immersive Mode",
                                                    fontWeight = FontWeight.Medium,
                                                    fontSize = 14.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "Hide status and navigation bars while reading",
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                                )
                                            }
                                            val immersiveMode by viewModel.immersiveMode.collectAsState()
                                            Switch(
                                                checked = immersiveMode,
                                                onCheckedChange = { viewModel.setImmersiveMode(it) },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = MaterialTheme.colorScheme.primary,
                                                    checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                                                )
                                            )
                                        }

                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                                        // Volume Key Page Turn
                                        Row(
                                            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = SettingRowMinHeight),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "Volume Key Page Turn",
                                                    fontWeight = FontWeight.Medium,
                                                    fontSize = 14.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "Volume buttons scroll the page (off during narration)",
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                                )
                                            }
                                            val volumeKeysEnabled by viewModel.volumeKeysEnabled.collectAsState()
                                            Switch(
                                                checked = volumeKeysEnabled,
                                                onCheckedChange = { viewModel.setVolumeKeysEnabled(it) },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = MaterialTheme.colorScheme.primary,
                                                    checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                                                )
                                            )
                                        }
                                    }
                                }
                            }

                            // Speech Controls Card
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_speech_controls), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // Accent
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(stringResource(R.string.reader_speech_accent), fontWeight = FontWeight.Medium, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 4.dp))
                                                var accentDropdownVisible by remember { mutableStateOf(false) }
                                                Box(modifier = Modifier.fillMaxWidth()) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                                                            .clickable(
                                                                onClickLabel = stringResource(R.string.a11y_show_options),
                                                                role = Role.DropdownList
                                                            ) { accentDropdownVisible = true }.padding(horizontal = 8.dp, vertical = 10.dp)
                                                    ) {
                                                        Text(selectedAccent, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                                                    }
                                                    DropdownMenu(expanded = accentDropdownVisible, onDismissRequest = { accentDropdownVisible = false }) {
                                                        availableAccents.forEach { accent ->
                                                            DropdownMenuItem(
                                                                text = { Text(accent, fontSize = 13.sp) },
                                                                onClick = { viewModel.selectAccentAndApply(accent); accentDropdownVisible = false }
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                            // Voice
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(stringResource(R.string.reader_speech_voice), fontWeight = FontWeight.Medium, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 4.dp))
                                                var voiceDropdownVisible by remember { mutableStateOf(false) }
                                                Box(modifier = Modifier.fillMaxWidth()) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                                                            .clickable(
                                                                onClickLabel = stringResource(R.string.a11y_show_options),
                                                                role = Role.DropdownList
                                                            ) { voiceDropdownVisible = true }.padding(horizontal = 8.dp, vertical = 10.dp)
                                                    ) {
                                                        val voiceName = selectedVoice?.name?.replace("en-us-x-", "")?.replace("-local", "")
                                                        Text(if (voiceName != null) voiceName else "Default", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                                                    }
                                                    DropdownMenu(expanded = voiceDropdownVisible, onDismissRequest = { voiceDropdownVisible = false }) {
                                                        filteredVoices.forEach { voice ->
                                                            DropdownMenuItem(
                                                                text = { Text(voice.name, fontSize = 13.sp) },
                                                                onClick = { viewModel.selectVoiceAndApply(voice); voiceDropdownVisible = false }
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                            // Speed
                                            Column(modifier = Modifier.weight(0.7f)) {
                                                Text(stringResource(R.string.reader_speech_speed), fontWeight = FontWeight.Medium, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 4.dp))
                                                var rateDropdownVisible by remember { mutableStateOf(false) }
                                                Box(modifier = Modifier.fillMaxWidth()) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                                                            .clickable(
                                                                onClickLabel = stringResource(R.string.a11y_show_options),
                                                                role = Role.DropdownList
                                                            ) { rateDropdownVisible = true }.padding(horizontal = 8.dp, vertical = 10.dp)
                                                    ) {
                                                        Text("${"%.2fx".format(speechRate)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, color = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.weight(1f))
                                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                                    }
                                                    DropdownMenu(expanded = rateDropdownVisible, onDismissRequest = { rateDropdownVisible = false }) {
                                                        listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.50f, 1.75f, 2.0f, 2.5f, 3.0f).forEach { speedOption ->
                                                            DropdownMenuItem(text = { Text("${"%.2fx".format(speedOption)}") }, onClick = { viewModel.setSpeechRateAndApply(speedOption); rateDropdownVisible = false })
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Text Alignment
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_text_alignment), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            val alignOptions = listOf(
                                                Triple("Left", Icons.Default.FormatAlignLeft, "Left"),
                                                Triple("Center", Icons.Default.FormatAlignCenter, "Center"),
                                                Triple("Right", Icons.Default.FormatAlignRight, "Right"),
                                                Triple("Justify", Icons.Default.FormatAlignJustify, "Justify")
                                            )
                                            alignOptions.forEach { (align, icon, label) ->
                                                val isSelected = textAlignment == align
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(SettingRowMinHeight)
                                                        .clip(RoundedCornerShape(10.dp))
                                                        .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                                        .border(
                                                            width = if (isSelected) 1.5.dp else 1.dp,
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                                            shape = RoundedCornerShape(10.dp)
                                                        )
                                                        // S9: one-of-many choice, so RadioButton
                                                        // rather than Button - that is the role
                                                        // that makes a screen reader announce
                                                        // selected state within the group.
                                                        .selectable(
                                                            selected = isSelected,
                                                            role = Role.RadioButton,
                                                            onClick = { viewModel.readerTextAlignment.value = align }
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Column(
                                                        horizontalAlignment = Alignment.CenterHorizontally,
                                                        verticalArrangement = Arrangement.Center
                                                    ) {
                                                        Icon(
                                                            imageVector = icon,
                                                            contentDescription = label,
                                                            tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                        Text(
                                                            text = label, 
                                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal, 
                                                            fontSize = 11.sp, 
                                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Background Style
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_background_style), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            listOf("Theme", "Choose").forEach { bgType ->
                                                val isSelected = if (bgType == "Choose") {
                                                    (readerBackgroundType == "Choose" || readerBackgroundType == "AMOLED Black")
                                                } else {
                                                    readerBackgroundType == bgType
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(SettingRowMinHeight)
                                                        .clip(RoundedCornerShape(10.dp))
                                                        .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                                        .border(
                                                            width = if (isSelected) 1.5.dp else 1.dp,
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                                            shape = RoundedCornerShape(10.dp)
                                                        )
                                                        .selectable(
                                                            selected = isSelected,
                                                            role = Role.RadioButton,
                                                            onClick = {
                                                                if (bgType == "Choose") {
                                                                    showBgColorPicker = true
                                                                } else {
                                                                    viewModel.readerBackgroundType.value = bgType
                                                                }
                                                            }
                                                        ),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = bgType,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                        fontSize = 13.sp,
                                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Typography / Downloaded Fonts
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_typography), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .clickable(
                                                onClickLabel = stringResource(R.string.a11y_choose_downloaded_font),
                                                role = Role.Button
                                            ) { showDownloadedFontsDialog = true }
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.defaultMinSize(minHeight = SettingRowMinHeight)
                                        ) {
                                            Icon(Icons.Default.FontDownload, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(stringResource(R.string.reader_font_selection), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                                                Text(readerFontFamily, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                            }
                                            Icon(Icons.Default.ArrowForwardIos, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(12.dp))
                                        }
                                    }
                                }
                            }

                            // Text Sliders Group Card (Fix drift: same header "TEXT" and title "Text Size" as Read tab)
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_text), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding),
                                        verticalArrangement = Arrangement.spacedBy(SettingInnerGap)
                                    ) {
                                        // Text Size
                                        Column {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text(stringResource(R.string.reader_text_size), fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${fontSize.toInt()}sp", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = fontSize,
                                                onValueChange = { viewModel.readerFontSize.value = it },
                                                valueRange = 12f..32f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                        // Line Spacing
                                        Column {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text(stringResource(R.string.reader_line_spacing), fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${"%.1fx".format(lineSpacing)}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = lineSpacing,
                                                onValueChange = { viewModel.readerLineSpacing.value = it },
                                                valueRange = 1.0f..2.5f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                        // Paragraph Spacing
                                        Column {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text(stringResource(R.string.reader_paragraph_spacing), fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${paragraphSpacing.toInt()}dp", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = paragraphSpacing,
                                                onValueChange = { viewModel.readerParagraphSpacing.value = it },
                                                valueRange = 0f..40f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }
                                    }
                                }
                            }

                            // Text Highlights Accent
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_text_highlights_accent), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            // Default option
                                            Card(
                                                shape = RoundedCornerShape(10.dp),
                                                colors = CardDefaults.cardColors(containerColor = if (isDefaultHighlight) MaterialTheme.colorScheme.primaryContainer else Color.Transparent),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .selectable(
                                                        selected = isDefaultHighlight,
                                                        role = Role.RadioButton,
                                                        onClick = { viewModel.isDefaultHighlight.value = true }
                                                    )
                                                    .border(
                                                        width = if (isDefaultHighlight) 1.5.dp else 1.dp,
                                                        color = if (isDefaultHighlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                                        shape = RoundedCornerShape(10.dp)
                                                    )
                                            ) {
                                                val defaultHighlightName = if (themeState == "blackgold") "Amber Gold" else "Dim Glow Green"
                                                Row(
                                                    modifier = Modifier.padding(12.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(defaultHighlightColor))
                                                    Text(defaultHighlightName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isDefaultHighlight) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface)
                                                }
                                            }
                                            
                                            // Set Color / Custom picker option
                                            Card(
                                                shape = RoundedCornerShape(10.dp),
                                                colors = CardDefaults.cardColors(containerColor = if (!isDefaultHighlight) MaterialTheme.colorScheme.primaryContainer else Color.Transparent),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .selectable(
                                                        selected = !isDefaultHighlight,
                                                        role = Role.RadioButton,
                                                        onClick = { showColorWheelDialog = true }
                                                    )
                                                    .border(
                                                        width = if (!isDefaultHighlight) 1.5.dp else 1.dp,
                                                        color = if (!isDefaultHighlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                                        shape = RoundedCornerShape(10.dp)
                                                    )
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(12.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(if (!isDefaultHighlight) Color(customHighlightColorRaw) else Color.Gray))
                                                    Text(if (!isDefaultHighlight) "Custom Active" else "Set Custom", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (!isDefaultHighlight) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Speech Pauses
                            item {
                                Column {
                                    Text(stringResource(R.string.reader_section_speech_pauses), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding),
                                        verticalArrangement = Arrangement.spacedBy(SettingInnerGap)
                                    ) {
                                        // Pause between sentences
                                        val nextSentencePause by viewModel.nextSentencePauseMs.collectAsState()
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                                Text(stringResource(R.string.reader_pause_sentences), fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${nextSentencePause.toInt()} ms", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = nextSentencePause,
                                                onValueChange = { viewModel.nextSentencePauseMs.value = it },
                                                valueRange = 0f..800f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }

                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                                        // Pause between paragraphs
                                        val paragraphPause by viewModel.paragraphPauseMs.collectAsState()
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                                Text(stringResource(R.string.reader_pause_paragraphs), fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${paragraphPause.toInt()} ms", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = paragraphPause,
                                                onValueChange = { viewModel.paragraphPauseMs.value = it },
                                                valueRange = 0f..1500f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }

                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                                        // Punctuation pause intensity
                                        val punctuationScale by viewModel.punctuationPauseScale.collectAsState()
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                                Text(stringResource(R.string.reader_pause_punctuation), fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${"%.1fx".format(punctuationScale)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = punctuationScale,
                                                onValueChange = { viewModel.punctuationPauseScale.value = it },
                                                valueRange = 0f..2f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(2.dp))

                                        Text(
                                            text = "All pauses automatically shrink at faster speech speeds and grow at slower speeds.",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Normal,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal pickers display section
    if (showDownloadedFontsDialog) {
        DownloadedFontsDialog(
            viewModel = viewModel,
            onDismiss = { showDownloadedFontsDialog = false },
            onOpenFontManager = onOpenFontManager,
            context = context
        )
    }

    if (showBgColorPicker) {
        BgColorWheelPickerDialog(
            initialColorValue = viewModel.readerBgColor.collectAsState().value,
            isAmoledBlack = (readerBackgroundType == "AMOLED Black"),
            onAmoledChanged = { amoled ->
                if (amoled) {
                    viewModel.readerBackgroundType.value = "AMOLED Black"
                } else {
                    viewModel.readerBackgroundType.value = "Choose"
                }
            },
            onColorSelected = { color ->
                viewModel.readerBgColor.value = color
                viewModel.readerBackgroundType.value = "Choose"
            },
            onDismiss = { showBgColorPicker = false }
        )
    }

    if (showNovelTextColorPicker) {
        NovelTextColorWheelPickerDialog(
            initialColorValue = readerTextColorRaw,
            onColorSelected = { color ->
                viewModel.readerTextColor.value = color
            },
            onDismiss = { showNovelTextColorPicker = false }
        )
    }

    if (showColorWheelDialog) {
        ColorWheelPickerDialog(
            initialColorValue = customHighlightColorRaw.toInt(),
            onColorSelected = { color ->
                viewModel.customHighlightColor.value = color.toLong()
                viewModel.isDefaultHighlight.value = false
            },
            onDismiss = { showColorWheelDialog = false }
        )
    }

    // Slide-in Text Filter Settings Panel (rendered as full overlay when showTextFilterPanel is true)
    AnimatedVisibility(
        visible = showTextFilterPanel,
        enter = slideInHorizontally(initialOffsetX = { it }, animationSpec = tween(300)),
        exit = slideOutHorizontally(targetOffsetX = { it }, animationSpec = tween(250)),
        modifier = Modifier
            .fillMaxSize()
            .zIndex(1000f)
    ) {
        var activeTab by remember { mutableStateOf(0) }
        var editingRule by remember { mutableStateOf<FilterRule?>(null) }
        
        var manualOriginal by remember { mutableStateOf("") }
        var manualReplacement by remember { mutableStateOf("") }
        var manualAction by remember { mutableStateOf(TextFilter.ACTION_ERASE_TEXT) }
        var manualStrictMatch by remember { mutableStateOf(false) }
        var manualScope by remember { mutableStateOf("All Books") }
        
        Surface(
            // FIX: this is a settings screen for managing rules, not the
            // reading page itself. It used to inherit the reader's own page
            // background/text colors, which are commonly plain white/black
            // and do not follow the system light/dark mode -- that's why it
            // showed up as a flat white screen no matter the app's theme.
            // It should look like every other settings screen instead.
            color = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.fillMaxSize()
        ) {
            // Shadows the reader's page colors for the rest of this panel so
            // every row below (which already reads from readerTextColor /
            // readerHighlightColor) automatically follows the app theme.
            val readerTextColor = MaterialTheme.colorScheme.onSurface
            val readerHighlightColor = MaterialTheme.colorScheme.primary
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    IconButton(onClick = { onSetTextFilterPanelVisible(false) }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = readerTextColor)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.reader_manage_text_filter),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = readerTextColor
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                AdaptiveTabSwitch(
                    options = listOf(
                        "rules" to "Active Rules (${textFilterRules.size})",
                        "manual" to "Add Manual"
                    ),
                    selectedKey = if (activeTab == 0) "rules" else "manual",
                    onSelect = { activeTab = if (it == "rules") 0 else 1 },
                    accentColor = readerHighlightColor,
                    textColor = readerTextColor
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                if (activeTab == 0) {
                    Text(
                        text = "How it works: Long-press any word in the reader to select and create an active rule, replacing or hiding that word dynamically during reads.",
                        fontSize = 11.sp,
                        color = readerTextColor.copy(alpha = 0.6f),
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(bottom = 16.dp, start = 4.dp, end = 4.dp)
                    )
                    if (textFilterRules.isEmpty()) {
                        Box(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.Info,
                                    contentDescription = null,
                                    tint = readerTextColor.copy(alpha = 0.3f),
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No active filter rules",
                                    fontSize = 14.sp,
                                    color = readerTextColor.copy(alpha = 0.5f)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Long-press any word in the reader to select it and create a rule.",
                                    fontSize = 11.sp,
                                    textAlign = TextAlign.Center,
                                    color = readerTextColor.copy(alpha = 0.3f),
                                    modifier = Modifier.padding(horizontal = 32.dp)
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f).fillMaxWidth()
                        ) {
                            items(textFilterRules) { rule ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(readerTextColor.copy(alpha = 0.04f))
                                        .border(0.5.dp, readerTextColor.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                        .padding(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when (rule.action) {
                                                    TextFilter.ACTION_REPLACE -> Color(0xFF66BB6A).copy(alpha = 0.15f)
                                                    TextFilter.ACTION_ERASE_LINE -> Color(0xFFFF9800).copy(alpha = 0.15f)
                                                    else -> Color(0xFFEF5350).copy(alpha = 0.15f)
                                                }
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = when (rule.action) {
                                                TextFilter.ACTION_REPLACE -> "✏️"
                                                TextFilter.ACTION_ERASE_LINE -> "🗑️"
                                                else -> "🚫"
                                            },
                                            fontSize = 12.sp
                                        )
                                    }
                                    
                                    Spacer(modifier = Modifier.width(12.dp))
                                    
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = rule.original,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = readerTextColor
                                            )
                                            if (rule.action == TextFilter.ACTION_REPLACE || (!rule.isVanish && rule.action.isBlank())) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = readerTextColor.copy(alpha = 0.5f), modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = rule.replacement,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    color = readerHighlightColor
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        val actionLabel = when (rule.action) {
                                            TextFilter.ACTION_REPLACE -> "Replace"
                                            TextFilter.ACTION_ERASE_LINE -> "Erase line"
                                            else -> "Erase text"
                                        }
                                        val strictLabel = if (rule.strictMatch) " • Strict" else ""
                                        Text(
                                            text = "$actionLabel$strictLabel • ${if (rule.scope == "All Books") "All Books 🌍" else "This Book 📖"}",
                                            fontSize = 10.sp,
                                            color = readerTextColor.copy(alpha = 0.5f)
                                        )
                                    }
                                    
                                    IconButton(
                                        onClick = {
                                            editingRule = rule
                                        }
                                    ) {
                                        Icon(
                                            Icons.Default.Edit,
                                            contentDescription = "Edit rule",
                                            tint = readerTextColor.copy(alpha = 0.7f)
                                        )
                                    }
                                    
                                    IconButton(
                                        onClick = {
                                            onResetSelection()
                                            viewModel.saveRules(textFilterRules.filter { it.id != rule.id })
                                        }
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Delete rule",
                                            tint = Color(0xFFEF5350)
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Text(
                        text = "How it works: Enter the original word below to target it. Select 'Vanish' to hide it, or 'Replace' to swap it completely while reading.",
                        fontSize = 11.sp,
                        color = readerTextColor.copy(alpha = 0.6f),
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(bottom = 8.dp, start = 4.dp, end = 4.dp)
                    )
                    Column(
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    ) {
                        Column {
                            Text(stringResource(R.string.reader_filter_match_phrase), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = readerTextColor.copy(alpha = 0.7f), modifier = Modifier.padding(bottom = 6.dp))
                            OutlinedTextField(
                                value = manualOriginal,
                                onValueChange = { manualOriginal = it },
                                placeholder = { Text("E.g., forbidden word", fontSize = 13.sp, color = readerTextColor.copy(alpha = 0.4f)) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = readerHighlightColor,
                                    unfocusedBorderColor = readerTextColor.copy(alpha = 0.15f),
                                    focusedTextColor = readerTextColor,
                                    unfocusedTextColor = readerTextColor
                                ),
                                modifier = Modifier.fillMaxWidth().height(50.dp)
                            )
                        }
                        
                        Column {
                            Text(stringResource(R.string.reader_filter_when_found), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = readerTextColor.copy(alpha = 0.7f), modifier = Modifier.padding(bottom = 6.dp))
                            AdaptiveChoiceChips(
                                options = listOf(
                                    TextFilter.ACTION_REPLACE to "Replace",
                                    TextFilter.ACTION_ERASE_TEXT to "Erase text",
                                    TextFilter.ACTION_ERASE_LINE to "Erase line"
                                ),
                                selectedKey = manualAction,
                                onSelect = { manualAction = it },
                                accentColor = readerHighlightColor,
                                textColor = readerTextColor
                            )
                        }
                        
                        if (manualAction == TextFilter.ACTION_REPLACE) {
                            Column {
                                Text(stringResource(R.string.reader_filter_replacement_text), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = readerTextColor.copy(alpha = 0.7f), modifier = Modifier.padding(bottom = 6.dp))
                                OutlinedTextField(
                                    value = manualReplacement,
                                    onValueChange = { manualReplacement = it },
                                    placeholder = { Text("E.g., happy", fontSize = 13.sp, color = readerTextColor.copy(alpha = 0.4f)) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = readerHighlightColor,
                                        unfocusedBorderColor = readerTextColor.copy(alpha = 0.15f),
                                        focusedTextColor = readerTextColor,
                                        unfocusedTextColor = readerTextColor
                                    ),
                                    modifier = Modifier.fillMaxWidth().height(50.dp)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.reader_filter_ignore_lookalikes),
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 13.sp,
                                    color = readerTextColor
                                )
                                Text(
                                    text = "Also catches f.r.e.e, F R E E and fr33",
                                    fontSize = 11.sp,
                                    color = readerTextColor.copy(alpha = 0.5f)
                                )
                            }
                            Switch(
                                checked = manualStrictMatch,
                                onCheckedChange = { manualStrictMatch = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = MaterialTheme.colorScheme.primary,
                                    checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                                )
                            )
                        }
                        
                        Column {
                            Text(stringResource(R.string.reader_filter_scope), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = readerTextColor.copy(alpha = 0.7f), modifier = Modifier.padding(bottom = 6.dp))
                            AdaptiveChoiceChips(
                                options = listOf(
                                    "All Books" to "All Books 🌍",
                                    "This Book" to "This Book 📖"
                                ),
                                selectedKey = manualScope,
                                onSelect = { manualScope = it },
                                accentColor = readerHighlightColor,
                                textColor = readerTextColor
                            )
                        }
                        
                        Spacer(modifier = Modifier.weight(1f))
                        
                        Button(
                            onClick = {
                                val cleanedOriginal = manualOriginal.trim()
                                    .trim('"', '\u201C', '\u201D', ',', '.', ';', ':', '!', '?')
                                    .replace(Regex("\\s+"), " ")
                                if (cleanedOriginal.isNotBlank()) {
                                    val squashedNew = TextFilter.squash(cleanedOriginal)
                                    val existingRule = textFilterRules.firstOrNull { rule ->
                                        TextFilter.squash(rule.original) == squashedNew && rule.scope == manualScope
                                    }
                                    val bookIdVal = if (manualScope == "This Book") (activeNovel?.id ?: "") else ""
                                    if (existingRule != null) {
                                        val updatedRule = existingRule.copy(
                                            original = cleanedOriginal,
                                            replacement = if (manualAction == TextFilter.ACTION_REPLACE) manualReplacement.trim() else "",
                                            isVanish = (manualAction != TextFilter.ACTION_REPLACE),
                                            action = manualAction,
                                            strictMatch = manualStrictMatch,
                                            scope = manualScope,
                                            bookId = bookIdVal
                                        )
                                        val updatedList = textFilterRules.map { if (it.id == existingRule.id) updatedRule else it }
                                        viewModel.saveRules(updatedList)
                                        Toast.makeText(context, "Updated existing rule", Toast.LENGTH_SHORT).show()
                                    } else {
                                        val newRule = FilterRule(
                                            id = java.util.UUID.randomUUID().toString(),
                                            original = cleanedOriginal,
                                            replacement = if (manualAction == TextFilter.ACTION_REPLACE) manualReplacement.trim() else "",
                                            isVanish = (manualAction != TextFilter.ACTION_REPLACE),
                                            scope = manualScope,
                                            bookId = bookIdVal,
                                            action = manualAction,
                                            strictMatch = manualStrictMatch
                                        )
                                        viewModel.saveRules(textFilterRules + newRule)
                                    }
                                    onResetSelection()
                                    manualOriginal = ""
                                    manualReplacement = ""
                                    activeTab = 0
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (themeState == "blackgold") Color.Transparent else readerHighlightColor,
                                contentColor = if (themeState == "blackgold") GoldOnGradient else Color.Black
                            ),
                            enabled = manualOriginal.trim().trim('"', '\u201C', '\u201D', ',', '.', ';', ':', '!', '?').replace(Regex("\\s+"), " ").isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(42.dp)
                                .then(
                                    if (themeState == "blackgold") {
                                        Modifier.background(RefinedGoldGradient, RoundedCornerShape(8.dp))
                                    } else {
                                        Modifier
                                    }
                                ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(stringResource(R.string.reader_filter_save_rule), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // Edit Rule Dialog
        editingRule?.let { ruleToEdit ->
            var editOriginal by remember(ruleToEdit) { mutableStateOf(ruleToEdit.original) }
            var editReplacement by remember(ruleToEdit) { mutableStateOf(ruleToEdit.replacement) }
            var editAction by remember(ruleToEdit) { mutableStateOf(ruleToEdit.action) }
            var editStrictMatch by remember(ruleToEdit) { mutableStateOf(ruleToEdit.strictMatch) }
            var editScope by remember(ruleToEdit) { mutableStateOf(ruleToEdit.scope) }

            LorelightDialog(
                onDismissRequest = { editingRule = null },
                title = { Text(stringResource(R.string.reader_filter_edit_rule)) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = editOriginal,
                            onValueChange = { editOriginal = it },
                            label = { Text(stringResource(R.string.reader_filter_match_phrase)) },
                            modifier = Modifier.fillMaxWidth()
                        )
                        
                        Text(stringResource(R.string.reader_filter_action_label), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        AdaptiveChoiceChips(
                            options = listOf(
                                TextFilter.ACTION_REPLACE to "Replace",
                                TextFilter.ACTION_ERASE_TEXT to "Erase text",
                                TextFilter.ACTION_ERASE_LINE to "Erase line"
                            ),
                            selectedKey = editAction,
                            onSelect = { editAction = it },
                            accentColor = MaterialTheme.colorScheme.primary,
                            textColor = MaterialTheme.colorScheme.onSurface
                        )
                        
                        if (editAction == TextFilter.ACTION_REPLACE) {
                            OutlinedTextField(
                                value = editReplacement,
                                onValueChange = { editReplacement = it },
                                label = { Text(stringResource(R.string.reader_filter_replacement_text)) },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(stringResource(R.string.reader_filter_ignore_lookalikes), fontSize = 12.sp)
                            Switch(checked = editStrictMatch, onCheckedChange = { editStrictMatch = it })
                        }

                        Text(stringResource(R.string.reader_filter_scope_label), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        AdaptiveChoiceChips(
                            options = listOf("All Books" to "All Books 🌍", "This Book" to "This Book 📖"),
                            selectedKey = editScope,
                            onSelect = { editScope = it },
                            accentColor = MaterialTheme.colorScheme.primary,
                            textColor = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (editOriginal.isNotBlank()) {
                                val activeNovel = viewModel.activeNovel.value
                                val updatedRule = ruleToEdit.copy(
                                    original = editOriginal.trim(),
                                    replacement = if (editAction == TextFilter.ACTION_REPLACE) editReplacement.trim() else "",
                                    action = editAction,
                                    isVanish = (editAction != TextFilter.ACTION_REPLACE),
                                    strictMatch = editStrictMatch,
                                    scope = editScope,
                                    bookId = if (editScope == "This Book") (activeNovel?.id ?: "") else ""
                                )
                                val updatedList = textFilterRules.map { if (it.id == updatedRule.id) updatedRule else it }
                                viewModel.saveRules(updatedList)
                                editingRule = null
                            }
                        }
                    ) {
                        Text(stringResource(R.string.reader_save))
                    }
                },
                dismissButton = {
                    TextButton(onClick = { editingRule = null }) {
                        Text(stringResource(R.string.action_cancel))
                    }
                }
            )
        }
    }
}

