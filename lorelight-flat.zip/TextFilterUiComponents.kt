package com.lorelight.ui.reader

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.semantics.Role

/*
 * Shared, wrap-safe controls for every text-filter tab/segmented-choice used
 * across the "Manage Text Filter" panel and its Create/Edit Filter Rule
 * popups.
 *
 * The old pattern hard-coded a fixed-height Row of equal-weight boxes for
 * every one of these switches. That breaks the instant a label needs more
 * room than a single line gives it -- narrower phones, foldables/tablets,
 * split-screen/multi-window, or a bumped-up system font size all cause the
 * text to get clipped or to overlap the box below it. Both controls below
 * size themselves from their own content instead of a hard-coded dp value,
 * so a label always has room to breathe (wrapping to a second line if it
 * truly needs to) and nothing ever gets cut off.
 */

/**
 * A full-width, equal-weight tab switcher (e.g. "Active Rules" / "Add
 * Manual"). Height comes from [IntrinsicSize.Min] so it always grows to fit
 * whichever label is tallest, instead of clipping at a fixed dp height.
 */
@Composable
fun AdaptiveTabSwitch(
    options: List<Pair<String, String>>,
    selectedKey: String,
    onSelect: (String) -> Unit,
    accentColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier,
    minHeight: Dp = 44.dp,
    fontSize: TextUnit = 13.sp
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .heightIn(min = minHeight)
            .clip(RoundedCornerShape(10.dp))
            .background(textColor.copy(alpha = 0.06f))
    ) {
        options.forEach { (key, label) ->
            val selected = key == selectedKey
            val bgColor by animateColorAsState(
                targetValue = if (selected) accentColor.copy(alpha = 0.2f) else Color.Transparent,
                animationSpec = tween(180),
                label = "adaptiveTabBg"
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(10.dp))
                    .background(bgColor)
                    .clickable(role = Role.Button) { onSelect(key) }
                    .padding(horizontal = 6.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    fontSize = fontSize,
                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                    color = if (selected) accentColor else textColor.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    softWrap = true
                )
            }
        }
    }
}

/**
 * A wrap-safe group of choice chips (e.g. Replace/Erase text/Erase line, or
 * All Books/This Book). Every chip sizes to its own label -- never squeezed
 * into an equal-weight slot -- and the whole group reflows onto additional
 * rows if it doesn't fit on one line, so a label is never clipped or
 * overlapped no matter the screen width or font scale.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdaptiveChoiceChips(
    options: List<Pair<String, String>>,
    selectedKey: String,
    onSelect: (String) -> Unit,
    accentColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 12.sp
) {
    FlowRow(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { (key, label) ->
            val selected = key == selectedKey
            FilterChip(
                selected = selected,
                onClick = { onSelect(key) },
                label = {
                    Text(
                        text = label,
                        fontSize = fontSize,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 2,
                        softWrap = true
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = textColor.copy(alpha = 0.06f),
                    labelColor = textColor.copy(alpha = 0.8f),
                    selectedContainerColor = accentColor.copy(alpha = 0.2f),
                    selectedLabelColor = accentColor
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selected,
                    borderColor = textColor.copy(alpha = 0.15f),
                    selectedBorderColor = accentColor.copy(alpha = 0.5f)
                )
            )
        }
    }
}
