package com.lorelight.ui.library

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.R
import com.lorelight.ui.components.LorelightSegmentedControl
import com.lorelight.ui.theme.GlassDropdownMenu

/**
 * Reserve the trailing icon space before measuring the title. On a phone or
 * with larger text, place the compact media filter below instead of squeezing
 * three unrelated controls into one row. Use measured text, not a tablet flag.
 */
@Composable
internal fun LibraryBookshelfHeader(
    title: String,
    mediaOptions: List<Pair<String, String>>,
    selectedMedia: String,
    showMediaFilter: Boolean,
    onMediaSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit
) {
    val titleStyle = MaterialTheme.typography.titleMedium.copy(
        fontSize = 18.sp,
        lineHeight = 24.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = MaterialTheme.typography.headlineLarge.fontFamily
    )

    // Compact layout: [title + pill (share left weight)] [actions pinned right]
    Row(
        modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = title,
                style = titleStyle,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false)
            )
            if (showMediaFilter) {
                LibraryMediaFilter(mediaOptions, selectedMedia, onMediaSelected)
            }
        }
        Spacer(Modifier.width(8.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            content = actions
        )
    }
}

@Composable
private fun LibraryMediaFilter(
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit
) {
    // Compact pill: visually small so it sits comfortably next to the title.
    LorelightSegmentedControl(
        options = options,
        selected = selected,
        onSelect = onSelect,
        modifier = Modifier.wrapContentWidth(),
        height = 28.dp,
        cornerRadius = 14.dp,
        fontSize = 11.sp
    )
}

/**
 * One bounded line at any supported font scale. Keep selection controls visible;
 * use an overflow menu for destructive/editing actions when they do not fit.
 * No data operations are owned here: all callbacks come from LibraryScreen.
 */
@Composable
internal fun LibrarySelectionToolbar(
    selectedCount: Int,
    hasItems: Boolean,
    allSelected: Boolean,
    onClose: () -> Unit,
    onSelectAll: () -> Unit,
    onEdit: () -> Unit,
    onMigrate: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedLabel = stringResource(R.string.library_selection_count, selectedCount)
    val selectAllLabel = stringResource(
        if (allSelected) R.string.library_deselect_all else R.string.library_select_all
    )
    val countStyle = MaterialTheme.typography.titleSmall.copy(
        fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.Bold
    )
    val actionStyle = MaterialTheme.typography.labelLarge.copy(
        fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Bold
    )
    val textMeasurer = rememberTextMeasurer()
    val density = LocalDensity.current
    val countWidth = with(density) {
        textMeasurer.measure(
            text = AnnotatedString(selectedLabel), style = countStyle,
            softWrap = false, maxLines = 1
        ).size.width.toDp()
    }
    val selectAllWidth = if (hasItems) with(density) {
        // TextButton's horizontal content padding plus a small safety margin.
        maxOf(64.dp, textMeasurer.measure(
            text = AnnotatedString(selectAllLabel), style = actionStyle,
            softWrap = false, maxLines = 1
        ).size.width.toDp() + 32.dp)
    } else 0.dp
    val actionCount = when {
        selectedCount == 1 -> 3
        selectedCount > 1 -> 2
        else -> 0
    }
    var showActionsMenu by remember { mutableStateOf(false) }

    BoxWithConstraints(
        modifier.fillMaxWidth().padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        // Close + count + Select All + actions + gaps. Count is measured with
        // the current number, app font and system text scale, not an estimate.
        val gapCount = 1 + (if (hasItems) 1 else 0) + actionCount
        val inlineActions = 48.dp + countWidth + selectAllWidth +
            48.dp * actionCount + 4.dp * gapCount <= maxWidth

        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            LibraryActionIcon(Icons.Default.Close, stringResource(R.string.action_cancel), onClose)
            Text(
                text = selectedLabel,
                style = countStyle,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            if (hasItems) {
                if (inlineActions) {
                    TextButton(onClick = onSelectAll) {
                        Text(
                            selectAllLabel,
                            style = actionStyle,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                } else {
                    LibraryActionIcon(
                        icon = if (allSelected) Icons.Default.Deselect else Icons.Default.SelectAll,
                        label = selectAllLabel,
                        onClick = onSelectAll
                    )
                }
            }

            if (inlineActions) {
                if (selectedCount == 1) {
                    LibraryActionIcon(Icons.Default.Edit, stringResource(R.string.library_edit_novel_desc), onEdit)
                }
                if (selectedCount > 0) {
                    LibraryActionIcon(Icons.Default.SwapHoriz, stringResource(R.string.library_transfer_source_desc), onMigrate)
                    LibraryActionIcon(Icons.Default.Delete, stringResource(R.string.library_delete_novels_desc), onDelete, destructive = true)
                }
            } else if (selectedCount > 0) {
                Box {
                    LibraryActionIcon(
                        Icons.Default.MoreVert,
                        stringResource(R.string.library_selection_actions_desc),
                        onClick = { showActionsMenu = true }
                    )
                    GlassDropdownMenu(
                        expanded = showActionsMenu,
                        onDismissRequest = { showActionsMenu = false }
                    ) {
                        if (selectedCount == 1) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.library_edit_novel_desc)) },
                                leadingIcon = { Icon(Icons.Default.Edit, null) },
                                onClick = { showActionsMenu = false; onEdit() }
                            )
                        }
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.library_transfer_source_desc)) },
                            leadingIcon = { Icon(Icons.Default.SwapHoriz, null) },
                            onClick = { showActionsMenu = false; onMigrate() }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.library_delete_novels_desc), color = MaterialTheme.colorScheme.error) },
                            leadingIcon = { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) },
                            onClick = { showActionsMenu = false; onDelete() }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryActionIcon(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    destructive: Boolean = false
) {
    IconButton(onClick = onClick, modifier = Modifier.size(48.dp)) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(20.dp)
        )
    }
}
