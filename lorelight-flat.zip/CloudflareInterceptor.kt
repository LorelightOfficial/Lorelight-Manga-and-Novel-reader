package com.lorelight.network

import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.lorelight.crawler.CrawlerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class CloudflareSolveTimeout(message: String) : IOException(message)

/**
 * Pure function to detect if an OkHttp Response represents a Cloudflare challenge.
 */
fun isCloudflareChallenge(response: Response): Boolean {
    if (response.code != 403 && response.code != 503) {
        return false
    }
    // Check 1: cf-mitigated header
    if (response.header("cf-mitigated") != null) {
        return true
    }
    // Check 2: Set-Cookie containing cf_chl_ or __cf_bm
    val cookies = response.headers("Set-Cookie")
    for (cookie in cookies) {
        if (cookie.contains("cf_chl_") || cookie.contains("__cf_bm")) {
            return true
        }
    }
    // Check 3: Body snippet
    return try {
        val peek = response.peekBody(1024L * 64L).string()
        peek.contains("Just a moment") ||
            peek.contains("challenge-platform") ||
            peek.contains("/cdn-cgi/challenge-platform/")
    } catch (e: Exception) {
        false
    }
}

class CloudflareInterceptor(
    private val context: Context,
    private val customSolver: (suspend (url: String, userAgent: String) -> Boolean)? = null
) : Interceptor {

    private val activeSolves = ConcurrentHashMap<String, Deferred<Boolean>>()
    private val lastSolveTimestamp = ConcurrentHashMap<String, Long>()
    private val coroutineScope = CoroutineScope(Dispatchers.IO + kotlinx.coroutines.SupervisorJob())

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val originalResponse = chain.proceed(request)

        if (!isCloudflareChallenge(originalResponse)) {
            return originalResponse
        }

        val host = request.url.host
        val now = System.currentTimeMillis()
        val lastSolve = lastSolveTimestamp[host] ?: 0L

        if (now - lastSolve < 5 * 60 * 1000L) {
            // Cooldown active: close challenge response and retry request with existing cookies once first
            originalResponse.close()
            val retryResponse = chain.proceed(request)
            if (!isCloudflareChallenge(retryResponse)) {
                return retryResponse
            }
            retryResponse.close()
        } else {
            originalResponse.close()
        }

        val userAgent = request.header("User-Agent") ?: CrawlerEngine.MOBILE_UA

        // Deduplicate in-flight solve per host
        val solveDeferred = activeSolves.computeIfAbsent(host) {
            coroutineScope.async {
                val solverResult = if (customSolver != null) {
                    customSolver.invoke(request.url.toString(), userAgent)
                } else {
                    solveWithWebView(context, request.url.toString(), userAgent)
                }
                if (solverResult) {
                    lastSolveTimestamp[host] = System.currentTimeMillis()
                }
                solverResult
            }
        }

        val solved = runBlocking {
            try {
                solveDeferred.await()
            } finally {
                activeSolves.remove(host, solveDeferred)
            }
        }

        if (!solved) {
            throw CloudflareSolveTimeout("Cloudflare challenge solve timed out for $host")
        }

        return chain.proceed(request)
    }

    private suspend fun solveWithWebView(
        context: Context,
        url: String,
        userAgent: String
    ): Boolean = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine { continuation ->
            var webView: WebView? = null
            var isCompleted = false

            fun cleanup() {
                try {
                    webView?.stopLoading()
                    webView?.destroy()
                    webView = null
                } catch (e: Exception) {
                    // Ignore
                }
            }

            continuation.invokeOnCancellation {
                cleanup()
            }

            try {
                val wv = WebView(context)
                webView = wv
                wv.settings.javaScriptEnabled = true
                wv.settings.domStorageEnabled = true
                wv.settings.userAgentString = userAgent
                wv.layoutParams = android.view.ViewGroup.LayoutParams(1, 1)

                wv.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                        super.onPageFinished(view, finishedUrl)
                    }
                }

                wv.loadUrl(url)

                val mainScope = CoroutineScope(Dispatchers.Main + Job())
                mainScope.launch {
                    val startTime = System.currentTimeMillis()
                    val timeoutMs = 15000L
                    val pollIntervalMs = 500L

                    while (System.currentTimeMillis() - startTime < timeoutMs) {
                        delay(pollIntervalMs)
                        if (!continuation.isActive) break

                        val cookies = try { CookieManager.getInstance().getCookie(url) ?: "" } catch (e: Exception) { "" }
                        val title = wv.title ?: ""

                        val isSolved = cookies.contains("cf_clearance") ||
                            (title.isNotBlank() &&
                             !title.contains("Just a moment", ignoreCase = true) &&
                             !title.contains("Attention Required", ignoreCase = true) &&
                             !title.contains("Cloudflare", ignoreCase = true))

                        if (isSolved) {
                            if (!isCompleted && continuation.isActive) {
                                isCompleted = true
                                cleanup()
                                continuation.resume(true)
                            }
                            return@launch
                        }
                    }

                    if (!isCompleted && continuation.isActive) {
                        isCompleted = true
                        cleanup()
                        continuation.resume(false)
                    }
                }
            } catch (e: Exception) {
                if (!isCompleted && continuation.isActive) {
                    isCompleted = true
                    cleanup()
                    continuation.resumeWithException(e)
                }
            }
        }
    }
}
