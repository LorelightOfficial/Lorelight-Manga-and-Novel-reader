package com.lorelight.manga.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import com.lorelight.ui.components.InAppBrowserIconButton
import com.lorelight.ui.components.LorelightDialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import coil.compose.SubcomposeAsyncImage
import com.lorelight.manga.util.MangaLanguages
import eu.kanade.tachiyomi.extension.ExtensionManager
import eu.kanade.tachiyomi.extension.model.Extension
import tachiyomi.domain.source.service.SourceManager
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import com.lorelight.manga.util.MangaSourceGrouping
import eu.kanade.tachiyomi.source.CatalogueSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import androidx.compose.ui.semantics.Role

private const val PREFS = "lorelight_manga_prefs"
private const val KEY_PINNED = "manga_pinned_sources"

object MangaSourcesCache {
    var cachedSources: List<CatalogueSource>? = null
    var cachedExtMap: Map<Long, Extension.Installed>? = null

    fun clear() {
        cachedSources = null
        cachedExtMap = null
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun MangaSourcesScreen(
    onOpenSource: (sourceId: Long, isLatest: Boolean) -> Unit,
    onOpenExtensions: () -> Unit = {},
    hideHeader: Boolean = false,
    searchQuery: String = ""
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(MangaSourcesCache.cachedSources == null) }
    var sources by remember { mutableStateOf<List<CatalogueSource>>(MangaSourcesCache.cachedSources ?: emptyList()) }
    var extBySourceId by remember { mutableStateOf<Map<Long, Extension.Installed>>(MangaSourcesCache.cachedExtMap ?: emptyMap()) }
    var pinnedIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var searchActive by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var sourceToUninstall by remember { mutableStateOf<Pair<CatalogueSource, Extension.Installed?>?>(null) }

    // BACK ALIGNMENT: mirrors the in-app search toggle exactly
    // (`searchActive = !searchActive; if (!searchActive) query = ""`), so the
    // system/gesture Back collapses the search field instead of leaving the
    // screen with a live filter still applied. Only when this screen owns the
    // header - with hideHeader the search box belongs to the parent.
    androidx.activity.compose.BackHandler(enabled = searchActive && !hideHeader) {
        searchActive = false
        query = ""
    }

    val presentLangs = remember(sources) {
        sources.map { it.lang }.filter { it.isNotBlank() }.distinct().toSet()
    }
    val selectedLangs = remember(context, presentLangs) {
        MangaLanguages.effective(context, presentLangs)
    }

    suspend fun loadSourcesInternal() {
        withContext(Dispatchers.IO) {
            val sourceManager = Injekt.get<SourceManager>()
            sourceManager.isInitialized.first { it }
            val loaded = sourceManager.getOnlineSources()
            val extensionManager = Injekt.get<ExtensionManager>()
            val installed = extensionManager.installedExtensionsFlow.value
            val available = extensionManager.availableExtensionsFlow.value
            val availableByPkg = available.associateBy { it.pkgName }
            val mapping = installed.flatMap { ext ->
                val iconUrl = ext.iconUrl ?: availableByPkg[ext.pkgName]?.iconUrl
                val enriched = if (iconUrl != null && ext.iconUrl == null) ext.copy(iconUrl = iconUrl) else ext
                enriched.sources.map { s -> s.id to enriched }
            }.toMap()

            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val rawPinned = prefs.getString(KEY_PINNED, null)
            val pinned = if (!rawPinned.isNullOrEmpty()) {
                try {
                    val arr = JSONArray(rawPinned)
                    (0 until arr.length()).map { arr.getLong(it) }.toSet()
                } catch (e: Exception) {
                    emptySet()
                }
            } else emptySet()

            MangaSourcesCache.cachedSources = loaded
            MangaSourcesCache.cachedExtMap = mapping

            withContext(Dispatchers.Main) {
                sources = loaded
                extBySourceId = mapping
                pinnedIds = pinned
            }
        }
    }

    // React to install/uninstall changes immediately
    val settingsVersion by com.lorelight.data.local.AppSettingsSignal.version.collectAsState()
    LaunchedEffect(settingsVersion) {
        try {
            loadSourcesInternal()
        } catch (_: Exception) {}
    }

    // UNINSTALL-VISIBILITY FIX.
    //
    // This screen only ever reloaded on the settings signal or on ON_RESUME.
    // Neither fires when an extension is removed while the app is already in the
    // foreground: a private extension is torn down in-process, so there is no
    // trip out to the OS uninstaller and no resume to come back from. The row
    // stayed on screen until the tab was reopened or a website was loaded, which
    // is exactly the "deleted source does not visually vanish" report.
    //
    // Observe the installed-extensions flow directly, drop the memo cache so the
    // reload cannot serve the removed source straight back, and refresh.
    LaunchedEffect(Unit) {
        Injekt.get<ExtensionManager>().installedExtensionsFlow.collectLatest {
            MangaSourcesCache.clear()
            try {
                loadSourcesInternal()
            } catch (_: Exception) {}
        }
    }

    // React to resuming activity (e.g. after returning from OS uninstaller)
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                scope.launch {
                    try {
                        loadSourcesInternal()
                    } catch (_: Exception) {}
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LaunchedEffect(Unit) {
        if (MangaSourcesCache.cachedSources != null && MangaSourcesCache.cachedExtMap != null) {
            isLoading = false
            try {
                loadSourcesInternal()
            } catch (e: Exception) {
                // ignore background error if cache exists
            }
        } else {
            isLoading = true
            try {
                loadSourcesInternal()
            } finally {
                isLoading = false
            }
        }
    }

    fun togglePin(sourceId: Long) {
        val newPinned = if (pinnedIds.contains(sourceId)) pinnedIds - sourceId else pinnedIds + sourceId
        pinnedIds = newPinned
        val arr = JSONArray()
        newPinned.forEach { arr.put(it) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_PINNED, arr.toString())
            .apply()
    }

    val effectiveQuery = if (hideHeader) searchQuery else query
    val q = effectiveQuery.trim()

    val filteredSources = remember(sources, pinnedIds, q, selectedLangs, extBySourceId) {
        val entries = sources.map { s ->
            MangaSourceGrouping.Entry(
                id = s.id,
                pkg = extBySourceId[s.id]?.pkgName,
                name = s.name,
                lang = s.lang
            )
        }
        val keepIds = MangaSourceGrouping.collapseMultiLang(entries, selectedLangs)

        // UNINSTALL-VISIBILITY FIX (part 2). extBySourceId is rebuilt from
        // ExtensionManager.installedExtensionsFlow, which drops a removed
        // package immediately, but SourceManager keeps handing back the stale
        // CatalogueSource for a while longer. That mismatch is precisely the
        // reported symptom: the row survives with its icon blanked out and only
        // vanishes after a restart. A source whose owning extension is gone
        // should never be listed, so drop it here as well. Guarded on a
        // non-empty map so the first frame, before the map is built, cannot
        // blank the entire screen.
        val extMapReady = extBySourceId.isNotEmpty()
        sources
            .filter { s ->
                val stillInstalled = !extMapReady || extBySourceId.containsKey(s.id)
                val matchesKeep = s.id in keepIds
                val matchesQuery = q.isBlank() || s.name.contains(q, ignoreCase = true)
                val matchesLang = selectedLangs.isEmpty() || selectedLangs.contains(s.lang)
                stillInstalled && matchesKeep && matchesQuery && matchesLang
            }
            .sortedWith(
                compareByDescending<CatalogueSource> { pinnedIds.contains(it.id) }
                    .thenBy { MangaLanguages.displayName(it.lang).lowercase() }
                    .thenBy { it.name.lowercase() }
            )
    }

    Column(Modifier.fillMaxSize()) {
        if (!hideHeader) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Sources",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = { searchActive = !searchActive; if (!searchActive) query = "" }) {
                        Icon(
                            imageVector = if (searchActive) Icons.Filled.Close else Icons.Filled.Search,
                            contentDescription = if (searchActive) "Close search" else "Search sources"
                        )
                    }
                    IconButton(onClick = onOpenExtensions) {
                        Icon(
                            imageVector = Icons.Filled.Extension,
                            contentDescription = "Extensions"
                        )
                    }
                }
            }
        }

        if (searchActive && !hideHeader) {
            val focusRequester = remember { FocusRequester() }
            LaunchedEffect(Unit) { focusRequester.requestFocus() }

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) {
                            Text(
                                text = "Search installed sources...",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                            )
                        }
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyLarge.copy(
                                color = MaterialTheme.colorScheme.onSurface
                            ),
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .focusRequester(focusRequester)
                        )
                    }
                    if (query.isNotEmpty()) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Clear",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .size(18.dp)
                                .clickable(role = Role.Button) { query = "" }
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }

        if (isLoading) {
            // Shaped like the rows that are about to arrive, instead of a lone
            // spinner in the middle of an empty screen.
            com.lorelight.ui.components.LorelightLoading(
                shape = com.lorelight.ui.components.LoadingShape.LIST_ROWS,
                modifier = Modifier.fillMaxSize(),
                itemCount = 8
            )
        } else if (filteredSources.isEmpty()) {
            com.lorelight.ui.components.LorelightEmpty(
                modifier = Modifier.fillMaxSize(),
                icon = Icons.Filled.Language,
                title = if (sources.isEmpty()) "No manga sources yet"
                else "Nothing in your languages",
                message = if (sources.isEmpty())
                    "Install an extension from the Extensions tab and its sources appear here."
                else
                    "You have sources installed, but none for the languages you picked. Change them in Browse settings."
            )
        } else {
            val pinnedSources = remember(filteredSources, pinnedIds) {
                filteredSources.filter { pinnedIds.contains(it.id) }
            }
            val unpinnedSources = remember(filteredSources, pinnedIds) {
                filteredSources.filter { !pinnedIds.contains(it.id) }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (pinnedSources.isNotEmpty()) {
                    stickyHeader(key = "header_pinned") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.background)
                                .padding(vertical = 8.dp)
                        ) {
                            Text(
                                text = "PINNED (${pinnedSources.size})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                    items(pinnedSources, key = { "pin_${it.id}" }) { source ->
                        SourceListItem(
                            source = source,
                            ext = extBySourceId[source.id],
                            isPinned = true,
                            onTogglePin = { togglePin(source.id) },
                            onOpenPopular = { onOpenSource(source.id, false) },
                            onOpenInAppBrowser = sourceBrowserAction(source),
                            onUninstall = { src, ext -> sourceToUninstall = src to ext }
                        )
                    }

                    stickyHeader(key = "header_all") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.background)
                                .padding(vertical = 8.dp)
                        ) {
                            Text(
                                text = "ALL (${unpinnedSources.size})",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                    items(unpinnedSources, key = { "all_${it.id}" }) { source ->
                        SourceListItem(
                            source = source,
                            ext = extBySourceId[source.id],
                            isPinned = false,
                            onTogglePin = { togglePin(source.id) },
                            onOpenPopular = { onOpenSource(source.id, false) },
                            onOpenInAppBrowser = sourceBrowserAction(source),
                            onUninstall = { src, ext -> sourceToUninstall = src to ext }
                        )
                    }
                } else {
                    items(filteredSources, key = { "all_${it.id}" }) { source ->
                        val isPinned = pinnedIds.contains(source.id)
                        SourceListItem(
                            source = source,
                            ext = extBySourceId[source.id],
                            isPinned = isPinned,
                            onTogglePin = { togglePin(source.id) },
                            onOpenPopular = { onOpenSource(source.id, false) },
                            onOpenInAppBrowser = sourceBrowserAction(source),
                            onUninstall = { src, ext -> sourceToUninstall = src to ext }
                        )
                    }
                }
            }
        }
    }

    // In-app browser host for MANGA sources only.
    //
    // The novel half of Browse hosts the same dialog for its own origin, and
    // this screen is composed inside it. Gating on the origin is what stops a
    // single request opening two dialogs at once.
    val browserTarget = com.lorelight.browse.ui.SourceBrowserRequest.target
    if (browserTarget != null &&
        browserTarget.origin is com.lorelight.browse.ui.BrowserOrigin.Manga
    ) {
        com.lorelight.browse.ui.InAppBrowserDialog(
            startUrl = browserTarget.url,
            siteName = browserTarget.siteName,
            origin = browserTarget.origin,
            onAddNovel = { novel ->
                com.lorelight.browse.ui.addBrowserResultToLibrary(context, novel)
            },
            onDismiss = {
                com.lorelight.browse.ui.SourceBrowserRequest.target = null
            }
        )
    }

    val uninstallTarget = sourceToUninstall
    if (uninstallTarget != null) {
        val (targetSource, targetExt) = uninstallTarget
        val pkg = targetExt?.pkgName
        val displayName = targetExt?.name ?: targetSource.name

        LorelightDialog(
            onDismissRequest = { sourceToUninstall = null },
            title = { Text("Uninstall $displayName?") },
            text = { Text("Its sources will be removed from Browse.") },
            isDestructive = true,
            confirmButton = {
                TextButton(
                    onClick = {
                        sourceToUninstall = null
                        if (pkg != null && targetExt != null) {
                            scope.launch {
                                Injekt.get<ExtensionManager>().uninstallExtension(targetExt)
                                MangaSourcesCache.clear()
                                MangaFirstPageCache.clear()
                                try {
                                    loadSourcesInternal()
                                } catch (_: Exception) {}
                                Toast.makeText(context, "Removed $displayName", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Toast.makeText(context, "Extension package not found for ${targetSource.name}", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("Uninstall", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { sourceToUninstall = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

/**
 * A manga source only has a website if it is an HttpSource. Local sources and
 * offline stubs are not, so they get no globe button at all rather than a button
 * that opens a blank page.
 */
@Composable
private fun sourceBrowserAction(source: CatalogueSource): (() -> Unit)? {
    val http = source as? eu.kanade.tachiyomi.source.online.HttpSource ?: return null
    val base = http.baseUrl.trim()
    if (base.isEmpty()) return null
    return {
        com.lorelight.browse.ui.SourceBrowserRequest.target =
            com.lorelight.browse.ui.BrowserTarget(
                url = base,
                siteName = source.name,
                // The source id travels with the request, so an add resolves
                // through THIS extension and the manga stays bound to it.
                origin = com.lorelight.browse.ui.BrowserOrigin.Manga(
                    sourceId = source.id,
                    baseUrl = base
                )
            )
    }
}

@Composable
private fun SourceListItem(
    source: CatalogueSource,
    ext: Extension.Installed?,
    isPinned: Boolean,
    onTogglePin: () -> Unit,
    onOpenPopular: () -> Unit,
    onOpenInAppBrowser: (() -> Unit)? = null,
    onUninstall: ((CatalogueSource, Extension.Installed?) -> Unit)? = null
) {
    // ROUNDED-CORNER CLIP FIX. This was a Card, and a Card clips its whole
    // subtree to the 14dp shape - so on taller rows a long source name or a
    // two-line subtitle got sliced by the corner curve. Only the icon should
    // ever be clipped. The fill and the press ripple now sit on a clipped
    // backdrop layer stretched to the row, while the content above it stays
    // unclipped and ellipsises against its own bounds instead of a curve.
    Box(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .matchParentSize()
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                .clickable(onClick = onOpenPopular, role = Role.Button, onClickLabel = "Browse popular")
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                val extIcon = ext?.icon
                val iconUrl = ext?.iconUrl
                val fallbackInitial = source.name.firstOrNull()?.uppercase() ?: "?"

                if (extIcon != null) {
                    Image(
                        bitmap = remember(extIcon) { extIcon.toBitmap().asImageBitmap() },
                        contentDescription = source.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else if (!iconUrl.isNullOrBlank()) {
                    SubcomposeAsyncImage(
                        model = iconUrl,
                        contentDescription = source.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                        error = {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = fallbackInitial,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    )
                } else {
                    Text(
                        text = fallbackInitial,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(Modifier.width(12.dp))

            Column(Modifier.weight(1f)) {
                Text(
                    text = source.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val subtitle = buildString {
                    append(MangaLanguages.displayName(source.lang))
                    if (!ext?.versionName.isNullOrBlank()) {
                        append(" • v${ext.versionName}")
                    }
                }
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(onClick = onTogglePin) {
                Icon(
                    Icons.Filled.PushPin,
                    contentDescription = "Pin",
                    tint = if (isPinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                )
            }

            // Same in-app browser the novel sources get, sitting right after
            // the pin. Only offered for sources that actually expose a base
            // URL -- a local or offline source has no website to open.
            if (onOpenInAppBrowser != null) {
                InAppBrowserIconButton(onClick = onOpenInAppBrowser)
            }

            if (onUninstall != null) {
                var menuExpanded by remember { mutableStateOf(false) }
                Box {
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(
                            Icons.Filled.MoreVert,
                            contentDescription = "More options",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Uninstall") },
                            onClick = {
                                menuExpanded = false
                                onUninstall(source, ext)
                            }
                        )
                    }
                }
            }
        }
    }
}
