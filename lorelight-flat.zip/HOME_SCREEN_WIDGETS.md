# Lorelight home-screen widgets

This revision adds exactly two Android home-screen widgets: **Continue Reading** and **Mini Bookshelf**. There is no separate Current Read widget. The removed Resume/Search/Downloads launcher shortcuts remain removed. Earlier onboarding, library-layout and celestial changes are retained.

## Continue Reading — the complete mode-changing card

A launcher-compatible implementation of the in-app Continue Reading / Audio Controller card, not the previously proposed tiny resume button:

- Novel: cover, title, saved chapter, chapter-position progress, last-read time, Play and Continue.
- Manga: cover, saved chapter and page, progress, last-read time and Continue. The novel-TTS Play button is absent.
- Playing: Now Playing, title/chapter and previous chapter, previous sentence, pause, next sentence, next chapter and Stop.
- Paused audio: the same transport controls remain, with Play replacing Pause.
- Empty: a clear no-active-read state and Open Library action. Never invents a most-recent book when none has been read.

The normal card uses the most recently read library entry; an active listening session takes precedence. Position comes from the existing URL-keyed ChapterReadStore with the same novel-row fallback as the in-app card. Continue uses the normal reader paths without forcing a chapter index or resetting the saved paragraph/word/page position. Cold-start widget routes wait for the library and briefly await chapter-state loading.

Starting listening from reading mode opens the existing app reader and starts its TTS session. Once a live audio session exists, transport controls operate it from the widget through the existing serial command queue, without a new playback engine or notification service. Stop returns the widget to reading mode. The in-app Stop action also now records the non-listening mode for this shared state.

A stale audio widget after process death does NOT silently restart playback or control a different book. Its stale transport tap shows a short explanation and refreshes the card; use the refreshed Play button to resume. This deliberately avoids an Android-restricted broadcast-to-activity trampoline.

## Mini Bookshelf

- Recent titles, favourites, or explicitly chosen titles.
- Novels and manga together, novels only, or manga only.
- Separate settings for every widget instance.
- Selection order is retained for chosen titles; removed titles are ignored.
- A responsive cover grid, up to six covers per page, with page arrows for more entries.
- Tapping a title opens its existing details page. The header opens the Library.
- The gear opens configuration. Empty library and empty-filter states are distinct.

Recent mode sorts by last-read time, with recently added unread titles as a fallback for the shelf only. Unlike Continue Reading, the shelf can intentionally display books that have not been opened yet.

## Appearance, sizing and updates

Both widgets use native Android RemoteViews and the app's actual saved theme/display mode. They retain the flat card treatment, rounded corners and thin outline rather than adding glass, stone ornaments or animated decorations. Text stays native and accessible; covers and the theme-coloured surface/progress are bounded bitmaps.

Default placement is 4x2 cells; actual cell sizes depend on the launcher. Both are resizable, and taller sizes are recommended for large text. If the launcher allocates too little space for the full controls, the widget shows a resize message instead of intentionally clipping controls. Portrait and landscape layouts are supplied separately. Exact appearance and launcher sizing still require device validation.

Updates react to saved progress, chapter/page state, library/settings changes and playback state while the app process is alive. The platform also requests periodic widget refreshes at its supported 30-minute minimum; no per-second widget polling, decorative animation, extra foreground service, or new permission is added. Observers/render work stop when no Lorelight widgets are installed.

Covers prefer local/cached data; bounded connected-network work can fill missing thumbnails through the existing source-aware cover loader, including manga source headers. It does not download novel chapters or manga pages. Offline/missing images retain a book placeholder and readable title. Thumbnails are 80x112 pixels to limit launcher payload size.

## Add the widgets after building and installing

1. Long-press an empty area on the Android home screen.
2. Open the launcher's Widgets picker and find Lorelight.
3. Add Continue Reading and/or Mini Bookshelf.
4. Use the bookshelf gear to choose its contents.
5. Resize a widget if needed, especially with enlarged system text.

Some launchers may refresh their widget catalogue only after the updated app has been opened. The standard launcher Widgets/App info/Uninstall entries are system-controlled and are not the removed Lorelight shortcuts.

## Validation status — source project, not a tested APK

195 source/resource audit checks passed at packaging time. They cover resource/manifest references, supported RemoteViews classes, balanced Kotlin delimiters, mode and action wiring, stale-action identity checks, read-only use of the existing library stores, preservation of old source changes, and absence of launcher shortcut declarations.

Added `app/src/test/java/com/lorelight/widget/WidgetStateTest.kt` for the five card states, media/favourite/selection filtering, stable selected ordering, removed entries and grid sizing. These JUnit tests have NOT been executed here.

There is still no usable Android SDK/Gradle installation in this environment, and the original project lacks `gradle/wrapper/gradle-wrapper.jar`. The wrapper stops at that missing JAR. Consequently this revision has NOT been compiled, rendered as native Android UI, or tested in an Android launcher. Source audit success is not compilation or visual/device QA. Restore the wrapper from your trusted build setup and compile/test before distributing.

### Required device checks

- Build debug and run the widget tests plus the existing regression suite.
- Add both widgets on a phone and tablet; resize and rotate, and repeat at 100%, 150% and 200% text scaling. Inspect for clipping, overlap, readable contrast, and control reachability.
- Exercise all Continue Reading states: empty, novel, manga with a nonzero saved page, playing, paused, stopped and chapter boundaries.
- Test every transport button from the home screen and while the app is backgrounded; verify they operate the intended current title and that Stop returns to reading mode.
- Kill the process with the widget visible, then test the documented stale-action refresh and cold-start Play/Continue paths. Test saved novel scroll/word positions and manga page positions.
- Add two bookshelf instances with different modes/media/selections, page through them, remove/filter titles, rotate, reconfigure and delete widgets.
- Test offline covers, source-protected manga covers, library read failure, empty library and an empty favourites/selected filter.
- Confirm theme/System mode updates, the absence of the old app shortcuts, and the earlier library/onboarding/celestial behaviours.
