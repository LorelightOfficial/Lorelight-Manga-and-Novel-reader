# Lorelight onboarding update

> Revision note: the reading-choice page has since been removed. The final route is Welcome → Storage (when needed) → Theme → Updates → Sources → Finish. See LIBRARY_LAYOUT_CHANGES.md for the latest changes and validation status.

## Changes

- Welcome: the content area now scrolls vertically. All four highlight cards keep their natural height; long labels wrap instead of being squeezed. Progress indicators and navigation have their own measured layout space, outside the scroll area.
- Storage: StorageOnboardingScreen.kt is unchanged. The onboarding route now stays stable when the parent reports that a folder was selected, so the theme step is not accidentally skipped. Step index and basic choices survive activity recreation.
- Reading theme: onboarding now reuses AppearanceThemeControls, extracted from Settings > Appearance. It uses the exact existing palette selector (Forest, Gold, Satin Pink, Black, Ocean, Cyan, Purple, Blood Red) and System / Light / Dark control. Selection writes the same ReaderViewModel values, including the existing highlight-colour updates. No duplicate onboarding palette remains. Motion and mode-switch animation settings remain only in the full Appearance section.
- Stay up to date: added New chapter notifications, bound to the existing Settings > Library preference and periodic LibraryUpdateScheduler. Enabling schedules work, disabling cancels it. Existing library scan interval and charging constraints are preserved. Wi-Fi only stays visible and also controls the chapter-notification scheduler.
- Notification permission: Android 13+ requests permission when the new toggle is enabled on first run. Denial leaves the toggle off and explains how to allow notifications later. Older Android versions do not receive this runtime request. The existing startup permission request remains for users who have already completed onboarding.
- Gestures: removed the “A few gestures to know” page and its unused helper. Progress indicators follow the remaining steps automatically.

The new notification option is independent of the existing auto-download toggle. This patch retains the original auto-download onboarding preference handling; it does not redesign or validate the auto-download engine.

## Changed source files

- app/src/main/java/com/lorelight/ui/onboarding/OnboardingFlow.kt
- app/src/main/java/com/lorelight/ui/settings/AppearanceSettings.kt
- app/src/main/java/com/lorelight/MainActivity.kt

All other original project files are unchanged. Application ID, version, dependencies, and signing configuration are unchanged.

## Verification performed

Twelve source-level regression checks passed, covering: all four welcome highlights, body scrolling / separate navigation layout, shared appearance controls, original palette and mode bindings, three always-visible update options, notification preference / scheduler / permission wiring, removal of the gestures page, stable storage routing, preservation of unrelated files, and balanced Kotlin delimiters.

These checks are NOT Kotlin compilation, Android instrumentation tests, visual tests, or end-to-end notification tests.

### Build limitations

No APK was built. The environment has no Android SDK or installed Gradle distribution. The supplied archive is also missing gradle/wrapper/gradle-wrapper.jar: running `bash gradlew --version` stops with “Unable to access jarfile .../gradle-wrapper.jar”. This missing file was already absent in the original upload.

Build with your normal working Android setup, restoring the wrapper JAR from your trusted project setup or using a compatible installed Gradle distribution. The project pins its Android/Gradle dependencies in its existing configuration. Compile and test before distributing an APK.

## Phone / tablet testing checklist

Use a separate test install, or back up your library before resetting onboarding or clearing app data.

1. On a small phone (approximately 320–360 dp wide), scroll Welcome to the final “Fully offline once downloaded” card. Confirm its text is visible and Back / Next never cover the body. Repeat in landscape, on a tablet, and with larger system font/display sizes.
2. Choose storage and confirm the next step is “Pick your reading theme”. The reading-choice page has been removed. Finish onboarding and confirm normal startup. Existing folder selection should still be retained.
3. On “Pick your reading theme”, try each swatch and all three modes. Scroll to Display Mode on shorter screens. Confirm immediate appearance changes, persistence after reopening, and the same selected values under Settings > Appearance.
4. Confirm Stay up to date shows Auto-download new chapters, Wi-Fi only, and New chapter notifications. With auto-download off, the other two remain visible.
5. On Android 13+, enable notifications and grant permission. Confirm Settings > Library shows the same enabled setting. Repeat with permission denied: onboarding must continue, the toggle must remain off, and the explanation must appear. Test on Android 12 or earlier too.
6. Turn notifications on/off and change Wi-Fi only. Verify the corresponding library preferences and scheduled work, and test delivery using a followed title with an actual new chapter. Background checks use Android WorkManager constraints; notifications are not guaranteed immediately after enabling the toggle.
7. Use Back / Next / Skip, rotate the phone, and verify that the gestures page never appears and progress indicators stay consistent. Confirm the final Get Started button exits onboarding.
