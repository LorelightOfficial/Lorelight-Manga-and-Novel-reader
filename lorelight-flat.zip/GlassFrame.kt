package com.lorelight.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Uplifted 3D glass corners.
 *
 * Draws four short L-shaped brackets hugging a card's rounded corners rather
 * than a full outline, so the card reads as a lifted pane of glass instead of
 * something boxed in.
 *
 * Each bracket is stroked three times to give it real thickness:
 *
 *  1. an occlusion pass pushed down-right - the shadow the rail casts onto the
 *     panel beneath it;
 *  2. the body pass in the accent colour;
 *  3. a thin specular pass pulled up-left - the lit top edge of the rail.
 *
 * Offsetting the dark and light passes in opposite directions along the same
 * diagonal is what turns a flat stroke into a chamfered rail catching light
 * from above. Top corners are drawn stronger than bottom ones so the implied
 * light direction stays consistent with the panel's own shadow.
 *
 * Lives here rather than inside one card because both the continue-reading card
 * and the now-playing card need the identical treatment - previously only the
 * former had it, so the frame appeared to vanish whenever playback started and
 * the two cards swapped places.
 */
@Composable
fun Modifier.glassCornerFrame(
    cornerRadius: Dp,
    armLength: Dp = 22.dp,
    strokeWidth: Dp = 2.4.dp
): Modifier {
    val isLightTheme = MaterialTheme.colorScheme.background.luminance() > 0.5f
    // DARK MODE: draw nothing at all. These brackets were designed to read as
    // lit glass rails catching light off a bright surface. On a dark background
    // the same strokes turn into hard white corner marks that box the card in --
    // the exact opposite of the lifted-pane effect they exist for. Returning the
    // untouched Modifier also keeps the continue-reading card and the
    // now-playing card identical, so nothing appears or vanishes when playback
    // starts and the two swap places.
    if (!isLightTheme) return this
    val accent = MaterialTheme.colorScheme.primary
    return this.drawWithContent {
        drawContent()
        drawGlassCorners(
            isLightTheme = isLightTheme,
            accent = accent,
            cornerRadiusPx = cornerRadius.toPx(),
            armPx = armLength.toPx(),
            strokePx = strokeWidth.toPx()
        )
    }
}

private fun DrawScope.drawGlassCorners(
    isLightTheme: Boolean,
    accent: Color,
    cornerRadiusPx: Float,
    armPx: Float,
    strokePx: Float
) {
    // Inset by a full stroke beyond the usual half-stroke so the offset
    // occlusion pass still lands inside the layer and does not get cut off.
    val inset = strokePx * 1.5f
    val r = (cornerRadiusPx - inset).coerceAtLeast(0f)
    val d = r * 2f
    val left = inset
    val top = inset
    val right = size.width - inset
    val bottom = size.height - inset
    if (right <= left || bottom <= top) return

    // Light from the top-left: highlight rides up-left, occlusion falls
    // down-right.
    val lift = strokePx * 0.62f
    val shadowColor = Color.Black.copy(alpha = if (isLightTheme) 0.28f else 0.45f)
    val specColor = Color.White.copy(alpha = if (isLightTheme) 0.95f else 0.85f)
    val glowColor = accent.copy(alpha = if (isLightTheme) 0.18f else 0.22f)
    val topBody = accent.copy(alpha = if (isLightTheme) 1.0f else 0.85f)
    val bottomBody = accent.copy(alpha = if (isLightTheme) 0.55f else 0.42f)

    fun pass(
        arcTopLeft: Offset,
        startAngle: Float,
        armAStart: Offset,
        armAEnd: Offset,
        armBStart: Offset,
        armBEnd: Offset,
        color: Color,
        width: Float,
        dx: Float,
        dy: Float
    ) {
        drawArc(
            color = color,
            startAngle = startAngle,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(arcTopLeft.x + dx, arcTopLeft.y + dy),
            size = Size(d, d),
            style = Stroke(width = width, cap = StrokeCap.Round)
        )
        drawLine(
            color,
            Offset(armAStart.x + dx, armAStart.y + dy),
            Offset(armAEnd.x + dx, armAEnd.y + dy),
            width,
            StrokeCap.Round
        )
        drawLine(
            color,
            Offset(armBStart.x + dx, armBStart.y + dy),
            Offset(armBEnd.x + dx, armBEnd.y + dy),
            width,
            StrokeCap.Round
        )
    }

    fun corner(
        arcTopLeft: Offset,
        startAngle: Float,
        armAStart: Offset,
        armAEnd: Offset,
        armBStart: Offset,
        armBEnd: Offset,
        body: Color,
        specStrength: Float
    ) {
        // 0. soft halo bleed - a wide, faint accent pass beneath everything
        // that lifts the rail off the glass and makes it read at a glance.
        pass(
            arcTopLeft, startAngle, armAStart, armAEnd, armBStart, armBEnd,
            glowColor.copy(alpha = glowColor.alpha * specStrength.coerceAtLeast(0.6f)),
            strokePx * 2.6f, 0f, 0f
        )
        // 1. cast shadow
        pass(
            arcTopLeft, startAngle, armAStart, armAEnd, armBStart, armBEnd,
            shadowColor, strokePx, lift, lift
        )
        // 2. body
        pass(
            arcTopLeft, startAngle, armAStart, armAEnd, armBStart, armBEnd,
            body, strokePx, 0f, 0f
        )
        // 3. specular top edge, thinner and pulled the other way
        pass(
            arcTopLeft, startAngle, armAStart, armAEnd, armBStart, armBEnd,
            specColor.copy(alpha = specColor.alpha * specStrength),
            strokePx * 0.45f, -lift * 0.7f, -lift * 0.7f
        )
    }

    // Top-left
    corner(
        Offset(left, top), 180f,
        Offset(left + r, top), Offset(left + r + armPx, top),
        Offset(left, top + r), Offset(left, top + r + armPx),
        topBody, 1f
    )
    // Top-right
    corner(
        Offset(right - d, top), 270f,
        Offset(right - r, top), Offset(right - r - armPx, top),
        Offset(right, top + r), Offset(right, top + r + armPx),
        topBody, 1f
    )
    // Bottom-left
    corner(
        Offset(left, bottom - d), 90f,
        Offset(left, bottom - r), Offset(left, bottom - r - armPx),
        Offset(left + r, bottom), Offset(left + r + armPx, bottom),
        bottomBody, 0.45f
    )
    // Bottom-right
    corner(
        Offset(right - d, bottom - d), 0f,
        Offset(right - r, bottom), Offset(right - r - armPx, bottom),
        Offset(right, bottom - r), Offset(right, bottom - r - armPx),
        bottomBody, 0.45f
    )
}
