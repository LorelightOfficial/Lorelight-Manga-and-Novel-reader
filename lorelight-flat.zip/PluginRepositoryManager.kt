package com.lorelight.browse.repo

import android.content.Context
import com.lorelight.browse.model.PluginInfo
import com.lorelight.crawler.CrawlerEngine
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.TimeUnit

object PluginRepositoryManager {
    private const val PREFS = "lorelight_browse_prefs"
    private const val KEY_REPOS = "repo_urls"
    const val DEFAULT_REPO =
        "https://raw.githubusercontent.com/LNReader/lnreader-plugins/plugins/v3.0.0/.dist/plugins.min.json"

    // FIX B11 + C17: shared, Cloudflare-aware, pooled client instead of a
    // private per-object OkHttpClient.
    private val client: OkHttpClient
        get() = com.lorelight.network.HttpClients.shared()

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getRepoUrls(context: Context?): List<String> {
        if (context == null) return listOf(DEFAULT_REPO)
        val raw = prefs(context).getString(KEY_REPOS, null)
        if (raw.isNullOrEmpty()) {
            val seeded = listOf(DEFAULT_REPO)
            saveRepoUrls(context, seeded)
            return seeded
        }
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: Exception) {
            listOf(DEFAULT_REPO)
        }
    }

    private fun saveRepoUrls(context: Context, urls: List<String>) {
        val arr = JSONArray()
        urls.forEach { arr.put(it) }
        prefs(context).edit().putString(KEY_REPOS, arr.toString()).apply()
    }

    // Fetches + validates a repo index. Returns plugin count on success.
    fun addRepo(context: Context, url: String): Result<Int> {
        return try {
            val body = fetch(url) ?: return Result.failure(Exception("Empty response"))
            val arr = JSONArray(body) // must be a JSON array of plugin objects
            val current = getRepoUrls(context).toMutableList()
            if (!current.contains(url)) {
                current.add(url)
                saveRepoUrls(context, current)
            }
            Result.success(arr.length())
        } catch (e: Exception) {
            Result.failure(Exception("Not a valid plugin repository"))
        }
    }

    fun removeRepo(context: Context, url: String) {
        val current = getRepoUrls(context).toMutableList()
        current.remove(url)
        saveRepoUrls(context, current)
    }

    // Fetch every repo index, parse, tag repoUrl, dedupe by id (first repo wins),
    // sort by lang then name.
    fun fetchAllPlugins(context: Context?): List<PluginInfo> {
        val seen = LinkedHashMap<String, PluginInfo>()
        for (repoUrl in getRepoUrls(context)) {
            val body = try { fetch(repoUrl) } catch (e: Exception) { null } ?: continue
            val arr = try { JSONArray(body) } catch (e: Exception) { continue }
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("id", "")
                if (id.isEmpty() || seen.containsKey(id)) continue
                seen[id] = PluginInfo(
                    id = id,
                    name = o.optString("name", id),
                    site = o.optString("site", ""),
                    lang = o.optString("lang", "Unknown"),
                    version = o.optString("version", "0.0.0"),
                    url = o.optString("url", ""),
                    iconUrl = o.optString("iconUrl", ""),
                    hasSettings = o.optBoolean("hasSettings", false),
                    hasUpdate = o.optBoolean("hasUpdate", false),
                    repoUrl = repoUrl,
                    customJS = o.optString("customJS", "").ifEmpty { null },
                    customCSS = o.optString("customCSS", "").ifEmpty { null }
                )
            }
        }
        return seen.values.sortedWith(compareBy({ it.lang }, { it.name.lowercase() }))
    }

    private fun fetch(url: String): String? {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", CrawlerEngine.MOBILE_UA)
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw Exception("HTTP ${resp.code}")
            return resp.body?.string()
        }
    }
}
