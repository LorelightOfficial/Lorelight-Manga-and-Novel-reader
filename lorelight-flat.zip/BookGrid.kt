package com.lorelight.ui.library

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.data.model.Novel
import com.lorelight.ui.animation.StaggeredItem
import com.lorelight.ui.components.LibraryCoverImage
import com.lorelight.ui.components.NovelCoverImage

// Must match the LazyHorizontalGrid geometry below so shelf planks line up.
private val GridVerticalPadding = 3.dp
private val GridRowSpacing = 14.dp
// Books' feet must land exactly on the plank's lit top face:
private val BookStandInset = ShelfPlankHeight - ShelfTopFaceHeight

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BookGrid(
    importedNovels: List<Novel>,
    currentNovel: Novel?,
    isManageMode: Boolean,
    selectedNovelTitles: Set<String>,
    bookshelfCoverScale: Float,
    bookshelfRows: Int,
    bookDesign: Boolean = true,
    shelfDesign: Boolean = true,
    gridState: LazyGridState,
    onNovelSelect: (Novel) -> Unit,
    onNovelLongPress: (Novel) -> Unit = {},
    libraryLoaded: Boolean = true,
    modifier: Modifier = Modifier
) {
    if (!libraryLoaded) {
        com.lorelight.ui.animation.BookGridSkeleton(modifier = modifier)
    } else if (importedNovels.isEmpty()) {
        // Was a one-off empty block with its own sizes and alphas. Now the
        // shared empty surface, so every empty screen in the app matches.
        com.lorelight.ui.components.LorelightEmpty(
            modifier = modifier.fillMaxWidth(),
            icon = Icons.Filled.MenuBook,
            title = "Your shelf is empty",
            message = "Tap Import at the top to add an EPUB, or open Browse to " +
                "find something from a source."
        )
    } else {
        BoxWithConstraints(
            modifier = modifier.fillMaxWidth().fillMaxHeight()
        ) {
            val rows = bookshelfRows.coerceIn(1, 3)
            val plankReserve = if (shelfDesign) BookStandInset else 0.dp

            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.TopCenter
            ) {
                if (shelfDesign) {
                    // ── LAYER 1: one shelf compartment per row. Plank sits INSIDE the row at its bottom ──
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(vertical = GridVerticalPadding),
                        verticalArrangement = Arrangement.spacedBy(GridRowSpacing)
                    ) {
                        repeat(rows) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth(),
                                contentAlignment = Alignment.BottomCenter
                            ) {
                                WoodenShelf(modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                }

                // ── LAYER 2 (front): books standing on each row ──
                LazyHorizontalGrid(
                    rows = GridCells.Fixed(rows),
                    state = gridState,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = GridVerticalPadding),
                    horizontalArrangement = Arrangement.spacedBy(18.dp),
                    verticalArrangement = Arrangement.spacedBy(GridRowSpacing),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(items = importedNovels, key = { _, novel -> novel.id }) { index, novel ->
                        val isSelected = if (isManageMode) novel.title in selectedNovelTitles else currentNovel?.title == novel.title
                        val importingIds by com.lorelight.service.NovelImportManager.importing.collectAsState()
                        val isImporting = importingIds.contains(novel.id) || novel.status == "Importing"
                        val alphaAnim by animateFloatAsState(
                            targetValue = if (isImporting) 1f else 0f,
                            animationSpec = tween(durationMillis = 400),
                            label = "importAlphaFlat"
                        )

                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .padding(bottom = plankReserve),
                            contentAlignment = Alignment.BottomCenter
                        ) {
                            StaggeredItem(index = index, key = novel.id) {
                                if (bookDesign) {
                                    Book3DItem(
                                        novel = novel,
                                        isSelected = isSelected,
                                        isManageMode = isManageMode,
                                        modifier = Modifier.fillMaxHeight(bookshelfCoverScale),
                                        enabledDesigns = ALL_BOOK_DESIGNS,
                                        onClick = { onNovelSelect(novel) },
                                        onLongClick = { onNovelLongPress(novel) }
                                    )
                                } else {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxHeight(bookshelfCoverScale)
                                            .aspectRatio(0.7f)
                                            .clip(RoundedCornerShape(6.dp))
                                            .border(
                                                width = if (isSelected && isManageMode) 2.dp else 0.dp,
                                                color = if (isSelected && isManageMode) MaterialTheme.colorScheme.primary else Color.Transparent,
                                                shape = RoundedCornerShape(6.dp)
                                            )
                                            .combinedClickable(
                                                onLongClick = { onNovelLongPress(novel) },
                                                onClick = { onNovelSelect(novel) }
                                            )
                                    ) {
                                        LibraryCoverImage(
                                            novel = novel,
                                            modifier = Modifier.fillMaxSize()
                                        )

                                        if (alphaAnim > 0f) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .background(Color.Black.copy(alpha = 0.45f * alphaAnim)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(24.dp),
                                                    strokeWidth = 2.dp,
                                                    color = MaterialTheme.colorScheme.primary
                                                )
                                            }
                                        }

                                        if (isManageMode) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .background(if (isSelected) Color.Black.copy(alpha = 0.3f) else Color.Transparent)
                                            )
                                            Box(
                                                modifier = Modifier
                                                    .align(Alignment.TopEnd)
                                                    .padding(8.dp)
                                                    .size(24.dp)
                                                    .clip(CircleShape)
                                                    .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.5f))
                                                    .border(
                                                        1.5.dp,
                                                        if (isSelected) MaterialTheme.colorScheme.primary
                                                        else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                                        CircleShape
                                                    ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                if (isSelected) {
                                                    Icon(
                                                        imageVector = Icons.Filled.Check,
                                                        contentDescription = "Selected",
                                                        tint = MaterialTheme.colorScheme.background,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
