__registerModule('qs', function(module){
  function stringify(obj, opts){
    opts = opts || {};
    var pairs = [];
    function add(key, value){
      if (value === null || value === undefined) value = '';
      if (typeof value === 'boolean') value = value ? 'true' : 'false';
      pairs.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
    }
    function build(prefix, val){
      if (Array.isArray(val)){
        for (var i = 0; i < val.length; i++){ build(prefix + '[' + i + ']', val[i]); }
      } else if (val !== null && typeof val === 'object'){
        for (var k in val){ if (val.hasOwnProperty(k)) build(prefix ? prefix + '[' + k + ']' : k, val[k]); }
      } else {
        add(prefix, val);
      }
    }
    if (obj && typeof obj === 'object'){ for (var key in obj){ if (obj.hasOwnProperty(key)) build(key, obj[key]); } }
    return pairs.join('&');
  }
  function parse(str){
    var out = {};
    if (!str) return out;
    str = String(str).replace(/^\?/, '');
    var parts = str.split('&');
    for (var i = 0; i < parts.length; i++){
      if (!parts[i]) continue;
      var kv = parts[i].split('=');
      out[decodeURIComponent(kv[0])] = decodeURIComponent(kv[1] || '');
    }
    return out;
  }
  module.exports = { stringify: stringify, parse: parse };
});
