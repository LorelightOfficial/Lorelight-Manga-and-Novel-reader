/*
 * =============================================================================
 * CompanionSpeechBox.kt - the little bubble above the altar.
 * Package: com.lorelight.companion
 *
 * SHAPE
 *   Rounded box with a small tail pointing down at the puck. Max 240dp wide,
 *   two lines, never more. The tail is drawn, not an asset - like everything
 *   else in this app.
 *
 * LIFE OF ONE BUBBLE
 *   enter -> reveal character by character -> hold -> exit.
 *
 *   The reveal is modelled on JRPG dialogue boxes - Pokemon above all. Three
 *   rules are taken straight from that model:
 *
 *     1. CHARACTERS, not words. Word-by-word makes text arrive in lumps and
 *        reads as a UI element refreshing. Character-by-character reads as
 *        someone speaking, and it is what every game in the genre does.
 *
 *     2. ONE SPEED, always. Pokemon's text speed is a single global setting.
 *        It is not slower at night and it does not change per character.
 *        Mood still drives the ENTRANCE and the MOUTH - that is personality -
 *        but the words themselves always arrive at the same rate, because a
 *        reading speed that shifts under you feels broken rather than moody.
 *
 *     3. FAST. CHAR_REVEAL_MS is set near Pokemon's FAST setting. Slow text
 *        is the single most common complaint about dialogue boxes, and the
 *        user finishes reading long before a slow reveal finishes drawing.
 *
 *   Punctuation gets a short extra beat, which is what stops a constant-rate
 *   reveal from sounding like a dot-matrix printer.
 *
 *   TOTAL_REVEAL_CAP_MS is a safety net: however long the line, the reveal
 *   speeds up so it can never outstay its welcome.
 *
 * HOLD
 *   revealDuration + a clamped tail. The clamp applies to the TAIL only -
 *   clamping the total would cut a long line off mid-reveal.
 *
 * TAP
 *   Tapping the puck is the theme toggle and it is sacred: it must stay
 *   instant. So the bubble never intercepts touches, and a tap simply makes
 *   it vanish in 80ms with no drift and no scale.
 *
 * ACCESSIBILITY
 *   The text size is clamped against the system font scale so a 2x font
 *   setting cannot push a two-line bubble into a five-line one. Line height
 *   is clamped with it - clamping only the size still grows the box.
 * =============================================================================
 */
package com.lorelight.companion

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/* --- timing ------------------------------------------------------------- */

/**
 * Milliseconds per character. The one knob that controls talking speed.
 *
 * ~25ms is 40 chars/sec, which sits at Pokemon's FAST setting. Raise it to
 * slow him down; 40L is roughly the genre's MEDIUM. Deliberately NOT split
 * per mood - see rule 2 in the header.
 */
internal const val CHAR_REVEAL_MS = 25L

/** Extra beat after sentence-enders and commas, so it breathes. */
private const val PAUSE_SENTENCE_MS = 110L
private const val PAUSE_CLAUSE_MS = 50L

/**
 * However long the line, the whole reveal finishes within this. Long lines
 * simply draw faster instead of dragging.
 */
private const val TOTAL_REVEAL_CAP_MS = 2_000L

/** Reading grace before the clamped tail starts counting. */
private const val READ_GRACE_MS = 1_600L
private const val PER_CHAR_MS = 52L
private const val HOLD_MIN_MS = 3_000L
private const val HOLD_MAX_MS = 9_000L

/** The mouth keeps moving a touch past the last character. */
internal const val MOUTH_TAIL_MS = 260L

private const val ENTER_ALPHA_MS = 180
private const val EXIT_MS = 220
private const val TAP_FADE_MS = 80

private const val SUN_ENTER_MS = 260
private const val MOON_ENTER_MS = 320

/* --- easings ------------------------------------------------------------ */

/** A touch of overshoot: the sun arrives eagerly. */
private val SunEnterEasing = CubicBezierEasing(0.34f, 1.20f, 0.64f, 1.00f)

/** The moon does not bounce. Ever. */
private val MoonEnterEasing = CubicBezierEasing(0f, 0f, 0.20f, 1f)

private val EaseInQuad = CubicBezierEasing(0.55f, 0.09f, 0.68f, 0.53f)

/* --- geometry ----------------------------------------------------------- */

private val BUBBLE_MAX_WIDTH = 240.dp
private val BUBBLE_RADIUS = 14.dp
private val BUBBLE_PAD_H = 10.dp
private val BUBBLE_PAD_V = 7.dp
private val TAIL_WIDTH = 14.dp
private val TAIL_HEIGHT = 7.dp

/**
 * Shows one line, then reports that it is done.
 *
 * @param text          the line to speak, or null for nothing / dismiss now.
 * @param mood          decides cadence and whether the entrance overshoots.
 * @param reduceMotion  honours the system "remove animations" setting.
 * @param onAppeared    fired once the bubble is actually on screen. This is
 *                      what should count against the daily cap - not the
 *                      decision to speak, which may still be thrown away.
 * @param onDone        fired after the bubble has fully gone. The caller
 *                      should set text back to null.
 */
@Composable
fun CompanionSpeechBox(
    text: String?,
    mood: Mood,
    reduceMotion: Boolean,
    onAppeared: () -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    // What is actually painted. Survives `text` going null so the exit
    // animation has something to show while it fades.
    var shown by remember { mutableStateOf<String?>(null) }
    var revealed by remember { mutableIntStateOf(0) }

    val alpha = remember { Animatable(0f) }
    val scale = remember { Animatable(0.85f) }
    val drift = remember { Animatable(0f) }

    LaunchedEffect(text) {
        // --- dismissed (tap, or the caller clearing after onDone) ---------
        if (text == null) {
            if (shown != null) {
                alpha.animateTo(0f, tween(TAP_FADE_MS, easing = LinearEasing))
                shown = null
            }
            return@LaunchedEffect
        }

        // --- a new line ---------------------------------------------------
        shown = text
        revealed = 0
        alpha.snapTo(0f)
        drift.snapTo(0f)
        scale.snapTo(if (reduceMotion) 1f else 0.85f)

        if (reduceMotion) {
            // No entrance, no reveal - the whole line at once, still timed.
            revealed = text.length
            alpha.animateTo(1f, tween(120, easing = LinearEasing))
            onAppeared()
            delay(holdTailMs(text.length))
            alpha.animateTo(0f, tween(140, easing = LinearEasing))
            shown = null
            onDone()
            return@LaunchedEffect
        }

        // Enter: breathed out from the puck.
        val enterMs = if (mood == Mood.SUN) SUN_ENTER_MS else MOON_ENTER_MS
        val enterEasing = if (mood == Mood.SUN) SunEnterEasing else MoonEnterEasing
        launch { scale.animateTo(1f, tween(enterMs, easing = enterEasing)) }
        alpha.animateTo(1f, tween(ENTER_ALPHA_MS, easing = LinearEasing))
        onAppeared()

        // Reveal: the whole line at once.
        //
        // The per-character typewriter reveal read as the app being slow
        // rather than as the character thinking, so there is no reveal
        // animation left -- the text is simply there the moment the bubble is.
        revealed = text.length

        // Hold: the clamped tail only. The reveal already took its own time.
        delay(holdTailMs(text.length))

        // Exit: sinks and fades, like a breath let out.
        launch { drift.animateTo(1f, tween(EXIT_MS, easing = EaseInQuad)) }
        launch { scale.animateTo(0.92f, tween(EXIT_MS, easing = EaseInQuad)) }
        alpha.animateTo(0f, tween(EXIT_MS, easing = EaseInQuad))

        shown = null
        onDone()
    }

    val full = shown
    if (full.isNullOrEmpty()) return

    val scheme = MaterialTheme.colorScheme
    val isDark = scheme.background.luminance2() <= 0.5f

    // Dark mode gets a softer, dimmer bubble: a bright panel at 1am is a
    // flashbang, and this character is supposed to be restful at night.
    val fill = if (isDark) scheme.surface.copy(alpha = 0.92f) else scheme.surfaceVariant
    val ink = if (isDark) scheme.onSurfaceVariant.copy(alpha = 0.90f) else scheme.onSurfaceVariant
    val edge = if (isDark) scheme.outlineVariant.copy(alpha = 0.60f) else scheme.outlineVariant

    // Clamp against the user's font scale so two lines stay two lines.
    val fontScale = LocalDensity.current.fontScale.coerceAtLeast(0.5f)
    val textSize = (12f / fontScale).sp
    val lineHeight = (16f / fontScale).sp

    // The unrevealed remainder is drawn fully transparent rather than omitted.
    // That keeps the line breaks and the box size identical from the first
    // frame, so nothing reflows or jumps while he is talking.
    val shaped = buildAnnotatedString {
        val n = revealed.coerceIn(0, full.length)
        if (n > 0) {
            withStyle(SpanStyle(color = ink)) { append(full.substring(0, n)) }
        }
        if (n < full.length) {
            withStyle(SpanStyle(color = ink.copy(alpha = 0f))) { append(full.substring(n)) }
        }
    }

    Column(
        modifier = modifier.graphicsLayer {
            this.alpha = alpha.value
            scaleX = scale.value
            scaleY = scale.value
            translationY = drift.value * 6.dp.toPx()
            // Grows out of the puck, which sits below the bubble.
            transformOrigin = TransformOrigin(0.5f, 1f)
        },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = BUBBLE_MAX_WIDTH)
                .drawBehind {
                    val r = BUBBLE_RADIUS.toPx()
                    drawRoundRect(
                        color = fill,
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(r, r)
                    )
                    drawRoundRect(
                        color = edge,
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(r, r),
                        style = Stroke(width = 1.dp.toPx())
                    )
                }
                .padding(horizontal = BUBBLE_PAD_H, vertical = BUBBLE_PAD_V)
        ) {
            Text(
                text = shaped,
                fontSize = textSize,
                // Three, not two. At two, a longer line had its tail clipped
                // and never drawn - yet the reveal loop still spent a beat on
                // every invisible character, so the bubble sat frozen for
                // seconds with nothing changing. That was the "buggy" pause.
                lineHeight = lineHeight,
                maxLines = 3,
                color = ink,
                style = MaterialTheme.typography.bodySmall
            )
        }

        // The tail, pointing down at the character who is talking.
        Box(
            modifier = Modifier
                .size(width = TAIL_WIDTH, height = TAIL_HEIGHT)
                .drawBehind {
                    tailPath.reset()
                    tailPath.moveTo(0f, 0f)
                    tailPath.lineTo(size.width, 0f)
                    tailPath.lineTo(size.width * 0.5f, size.height)
                    tailPath.close()
                    drawPath(tailPath, color = fill)
                }
        )
    }
}

/**
 * How long the finished line lingers AFTER the last word lands.
 *
 * Only this tail is clamped. The reveal duration is separate and must never
 * be clamped away, or long lines get cut off while still being spoken.
 */
private fun holdTailMs(chars: Int): Long =
    (READ_GRACE_MS + chars * PER_CHAR_MS).coerceIn(HOLD_MIN_MS, HOLD_MAX_MS)

/** The extra beat a character earns after it lands. */
private fun pauseAfter(c: Char): Long = when (c) {
    '.', '!', '?', '\u2026' -> PAUSE_SENTENCE_MS
    ',', ';', ':', '\u2014' -> PAUSE_CLAUSE_MS
    else -> 0L
}

/**
 * Per-character delay for this line, squeezed down if the line is long
 * enough that the natural rate would blow past TOTAL_REVEAL_CAP_MS.
 */
private fun perCharMs(text: String): Long {
    if (text.isEmpty()) return CHAR_REVEAL_MS
    val pauses = text.sumOf { pauseAfter(it) }
    val budget = (TOTAL_REVEAL_CAP_MS - pauses).coerceAtLeast(text.length.toLong())
    return minOf(CHAR_REVEAL_MS, budget / text.length).coerceAtLeast(1L)
}

/**
 * How long the whole reveal takes. Shared with CompanionController so the
 * mouth stops when the words stop - if these two ever drift, the illusion
 * dies, which is why there is exactly one function for it.
 */
internal fun companionRevealDurationMs(text: String): Long {
    if (text.isEmpty()) return 0L
    val perChar = perCharMs(text)
    var total = 0L
    for (i in text.indices) {
        if (i == text.lastIndex) break
        total += perChar + pauseAfter(text[i])
    }
    return total
}

/** Hoisted so the draw pass allocates nothing. */
private val tailPath = Path()

/** Local luminance helper - avoids importing a graphics extension. */
private fun androidx.compose.ui.graphics.Color.luminance2(): Float =
    0.299f * red + 0.587f * green + 0.114f * blue
