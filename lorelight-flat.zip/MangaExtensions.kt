package com.lorelight.data.model

import android.net.Uri
import eu.kanade.tachiyomi.source.Source
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga

const val MANGA_PLUGIN_PREFIX = "manga:"
const val MANGA_CHAPTER_SCHEME = "mangaext://"

val Novel.isManga: Boolean
    get() = pluginId?.startsWith(MANGA_PLUGIN_PREFIX) == true

val Novel.mangaSourceId: Long?
    get() = pluginId?.removePrefix(MANGA_PLUGIN_PREFIX)?.toLongOrNull()

suspend fun Source.getMangaDetails(manga: SManga): SManga =
    getMangaUpdate(manga, emptyList(), fetchDetails = true, fetchChapters = false).manga

suspend fun Source.getChapterList(manga: SManga): List<SChapter> =
    getMangaUpdate(manga, emptyList(), fetchDetails = false, fetchChapters = true).chapters

fun encodeMangaChapterUrl(sourceId: Long, chapterUrl: String): String =
    MANGA_CHAPTER_SCHEME + sourceId + "/" + Uri.encode(chapterUrl, "")

fun decodeMangaChapterUrl(encoded: String): Pair<Long, String>? {
    return try {
        if (!encoded.startsWith(MANGA_CHAPTER_SCHEME)) return null
        val rest = encoded.substring(MANGA_CHAPTER_SCHEME.length)
        val slashIndex = rest.indexOf('/')
        if (slashIndex <= 0) return null
        val sourceId = rest.substring(0, slashIndex).toLongOrNull() ?: return null
        val rawChapterUrl = rest.substring(slashIndex + 1)
        val chapterUrl = Uri.decode(rawChapterUrl)
        Pair(sourceId, chapterUrl)
    } catch (e: Exception) {
        null
    }
}
