package com.lorelight.ui.theme.modeswitch.celestial

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

const val CELESTIAL_BODY_RADIUS_FRACTION = 0.38f

// Crater data: [normalizedX, normalizedY, radiusFraction] * N
private val craters = floatArrayOf(
    -0.50f, -0.60f, 0.14f,
     0.19f, -0.72f, 0.09f,
     0.70f, -0.26f, 0.08f,
     0.64f,  0.40f, 0.12f,
    -0.63f,  0.40f, 0.10f,
    -0.20f,  0.74f, 0.07f
)

/**
 * Design 1 — DREAMY
 *
 * Anime-style with soft radial gradients.  The sun has NO spikes or rays in
 * the normal state.  Instead, a ring of soft ambient dots decorates the body
 * interior so it reads as "sunny" without any external geometry.
 *
 * All facial animation driven by [face]; [timeSec] is accepted but ignored so
 * the signature stays forward-compatible.
 */
@Suppress("UNUSED_PARAMETER")
internal fun DrawScope.drawAnimeCelestial(
    c: Offset, radius: Float, form: Float,
    face: CelestialFaceSnapshot, timeSec: Float, alpha: Float
) {
    if (radius <= 0f || alpha <= 0f) return
    val r = radius
    val f = form.coerceIn(0f, 1f)
    val a = alpha.coerceIn(0f, 1f)
    fun pt(x: Float, y: Float) = Offset(c.x + r * x, c.y + r * y)

    val ink    = lerp(Color(0xFF222E50), Color(0xFF573027), f)
    val core   = lerp(Color(0xFFFFF8EF), Color(0xFFFFF1B5), f)
    val middle = lerp(Color(0xFFCBD7DF), Color(0xFFFFCD59), f)
    val edge   = lerp(Color(0xFF788DA8), Color(0xFFDF813A), f)

    // ---- Body sphere ----
    drawCircle(
        Brush.radialGradient(
            0f to core, 0.52f to middle, 1f to edge,
            center = pt(-0.34f, -0.40f), radius = r * 1.55f
        ), r, c, alpha = a
    )

    // ---- Interior effects clipped to the body disc ----
    val disc = Path().apply { addOval(Rect(c.x - r, c.y - r, c.x + r, c.y + r)) }
    clipPath(disc) {
        // Soft terminator shadow
        drawCircle(
            Brush.radialGradient(
                0.42f to Color.Transparent, 1f to ink.copy(alpha = 0.24f * a),
                center = pt(-0.35f, -0.45f), radius = r * 1.70f
            ), r, c
        )
        // Top highlight arc
        drawOval(core.copy(alpha = 0.28f * a), pt(-0.64f, -0.76f), Size(r * 0.72f, r * 0.33f))

        // Moon craters
        if (f < 1f) {
            for (i in craters.indices step 3) {
                val cp = pt(craters[i], craters[i + 1]); val cr = craters[i + 2] * r
                drawCircle(Color(0xFF617594).copy(alpha = 0.34f * a * (1f - f)), cr, cp)
                drawCircle(core.copy(alpha = 0.64f * a * (1f - f)), cr * 0.79f, cp + Offset(cr * 0.14f, cr * 0.22f))
                drawCircle(edge.copy(alpha = 0.42f * a * (1f - f)), cr * 0.61f, cp - Offset(cr * 0.13f, cr * 0.16f))
            }
        }

        // Sun: soft golden ambient dots inside the body — NO external spikes
        if (f > 0f) {
            repeat(24) { i ->
                val t = i * 15f * PI.toFloat() / 180f
                val dist = 0.48f + (i % 4) * 0.10f
                val sz   = r * (0.012f + (i % 3) * 0.008f)
                drawCircle(
                    Color(0xFFD98139).copy(alpha = (0.14f + (i % 2) * 0.10f) * a * f),
                    sz, pt(cos(t) * dist, sin(t) * dist)
                )
            }
        }

        // Gloss arc strokes
        drawArc(
            core.copy(alpha = 0.70f * a), 190f, 98f, false,
            pt(-0.95f, -0.95f), Size(r * 1.90f, r * 1.90f),
            style = Stroke(r * 0.037f, cap = StrokeCap.Round)
        )
        drawArc(
            lerp(Color(0xFFCBEBF1), Color(0xFFFFDF8C), f).copy(alpha = 0.50f * a),
            18f, 76f, false,
            pt(-0.95f, -0.95f), Size(r * 1.90f, r * 1.90f),
            style = Stroke(r * 0.025f, cap = StrokeCap.Round)
        )
    }

    // Outer rim stroke
    drawCircle(ink.copy(alpha = 0.26f * a), r, c, style = Stroke(r * 0.020f))

    // ---- Cheeks ----
    val cheekColor = lerp(Color(0xFFB684A4), Color(0xFFE77569), f)
    val blush = (0.18f + face.cheekGlow.coerceIn(0f, 1f) * 0.45f) * a
    for (side in listOf(-1f, 1f)) {
        val p = pt(side * 0.52f, 0.32f)
        drawOval(
            Brush.radialGradient(listOf(cheekColor.copy(alpha = blush), Color.Transparent), p, r * 0.19f),
            p - Offset(r * 0.20f, r * 0.10f), Size(r * 0.40f, r * 0.20f)
        )
    }

    // ---- Brows ----
    for (side in listOf(-1f, 1f)) {
        val brow = if (side < 0f) face.browLeft else face.browRight
        val bx = c.x + side * r * 0.38f
        val by = c.y - r * (0.43f + brow.coerceAtLeast(0f) * 0.12f)
        val sad = (face.mouthSmile < -0.3f && brow > 0f)
        val slope = when { brow < 0f -> -brow * 0.16f; sad -> -0.10f; else -> 0f }
        val inner = Offset(bx - side * r * 0.20f, by + r * slope)
        val outer = Offset(bx + side * r * 0.19f, by - r * 0.025f)
        val bp = Path().apply {
            moveTo(inner.x, inner.y)
            quadraticBezierTo(bx, by - r * 0.065f, outer.x, outer.y)
        }
        drawPath(bp, ink.copy(alpha = 0.78f * a), style = Stroke(r * 0.055f, cap = StrokeCap.Round))
    }

    // ---- Eyes ----
    dreamyAnimeEye(pt(-0.38f, -0.06f), r * 0.255f, r * 0.295f, face.lidLeft,  face, ink, f, a)
    dreamyAnimeEye(pt( 0.38f, -0.06f), r * 0.255f, r * 0.295f, face.lidRight, face, ink, f, a)

    // ---- Tiny shaded nose ----
    drawOval(edge.copy(alpha = 0.25f * a), pt(-0.045f, 0.19f), Size(r * 0.09f, r * 0.045f))

    // ---- Mouth ----
    val smile   = face.mouthSmile.coerceIn(-1f, 1f)
    val opening = face.mouthOpen.coerceIn(0f, 1f)
    val my = c.y + r * 0.46f
    val mw = r * (0.15f + 0.10f * abs(smile))
    val mouth = Path()
    if (opening < 0.09f) {
        mouth.moveTo(c.x - mw, my - r * 0.035f * smile)
        mouth.quadraticBezierTo(c.x, my + r * 0.19f * smile, c.x + mw, my - r * 0.035f * smile)
        drawPath(mouth, ink.copy(alpha = a), style = Stroke(r * 0.045f, cap = StrokeCap.Round))
    } else {
        val mh   = r * (0.07f + 0.27f * opening)
        val wide = mw * if (smile < 0.2f) 0.68f else 1.12f
        mouth.moveTo(c.x - wide, my)
        mouth.cubicTo(c.x - wide, my - mh * 0.6f, c.x + wide, my - mh * 0.6f, c.x + wide, my)
        mouth.cubicTo(c.x + wide, my + mh, c.x - wide, my + mh, c.x - wide, my)
        mouth.close()
        drawPath(mouth, ink.copy(alpha = a))
        clipPath(mouth) {
            if (smile > 0.4f) drawOval(core.copy(alpha = 0.95f * a), Offset(c.x - wide, my - mh * 0.45f), Size(wide * 2f, mh * 0.33f))
            drawOval(Color(0xFFD58B91).copy(alpha = 0.95f * a), Offset(c.x - wide * 0.62f, my + mh * 0.35f), Size(wide * 1.30f, mh * 0.50f))
        }
    }

    // ---- Tears ----
    if (face.tears > 0.01f) for (side in listOf(-1f, 1f)) {
        val tx = c.x + side * r * 0.55f; val ty = c.y + r * 0.17f
        val t  = face.tears.coerceIn(0f, 1f)
        val tp = Path().apply {
            moveTo(tx, ty)
            cubicTo(tx - r * 0.09f, ty + r * 0.20f * t, tx - r * 0.07f, ty + r * 0.43f * t, tx, ty + r * 0.43f * t)
            cubicTo(tx + r * 0.09f, ty + r * 0.43f * t, tx + r * 0.09f, ty + r * 0.20f * t, tx, ty)
            close()
        }
        drawPath(tp, Brush.verticalGradient(listOf(Color(0xFFCAE9FF), Color(0xFF6EADDB)), ty, ty + r * 0.50f), alpha = a * t)
        drawLine(Color.White.copy(alpha = 0.85f * a * t), Offset(tx - r * 0.015f, ty + r * 0.10f), Offset(tx - r * 0.020f, ty + r * 0.28f * t), r * 0.015f, cap = StrokeCap.Round)
    }
}

private fun DrawScope.dreamyAnimeEye(
    c: Offset, w: Float, h: Float, lid: Float,
    face: CelestialFaceSnapshot, ink: Color, form: Float, a: Float
) {
    val openness = (1f - lid).coerceIn(0f, 1f)
    if (openness < 0.08f) {
        val arc = Path().apply {
            moveTo(c.x - w, c.y)
            quadraticBezierTo(c.x, c.y + (if (face.mouthSmile > 0.65f) -1f else 1f) * h * 0.34f, c.x + w, c.y)
        }
        drawPath(arc, ink.copy(alpha = a), style = Stroke(w * 0.22f, cap = StrokeCap.Round))
        return
    }
    val hh = h * openness
    val shape = Path().apply {
        moveTo(c.x - w, c.y)
        cubicTo(c.x - w * 0.88f, c.y - hh * 1.25f, c.x + w * 0.85f, c.y - hh * 1.25f, c.x + w, c.y)
        cubicTo(c.x + w * 0.70f, c.y + hh * 0.90f, c.x - w * 0.70f, c.y + hh * 0.90f, c.x - w, c.y)
        close()
    }
    drawPath(shape, Color(0xFFFFFAF1).copy(alpha = a))
    clipPath(shape) {
        val iris = Offset(
            c.x + face.pupilX.coerceIn(-1f, 1f) * w * 0.24f,
            c.y + face.pupilY.coerceIn(-1f, 1f) * h * 0.16f
        )
        val ir  = w * 0.74f * face.pupilScale.coerceIn(0.45f, 1.30f)
        val hue = lerp(Color(0xFF6684BD), Color(0xFFAF672E), form)
        drawOval(
            Brush.verticalGradient(
                listOf(ink, hue, lerp(Color(0xFFB0D8EE), Color(0xFFFFD678), form)),
                iris.y - h, iris.y + h
            ),
            iris - Offset(ir, h * 0.85f), Size(ir * 2f, h * 1.70f), alpha = a
        )
        drawOval(ink.copy(alpha = a), iris - Offset(ir * 0.42f, h * 0.60f), Size(ir * 0.84f, h * 1.18f))
        drawPath(shape, Brush.verticalGradient(listOf(ink.copy(alpha = 0.45f * a), Color.Transparent), c.y - hh, c.y))
        drawCircle(Color.White.copy(alpha = 0.96f * a), w * 0.25f, iris - Offset(w * 0.23f, h * 0.32f))
        drawCircle(Color.White.copy(alpha = 0.72f * a), w * 0.12f, iris + Offset(w * 0.25f, h * 0.26f))
    }
    val upper = Path().apply {
        moveTo(c.x - w, c.y)
        cubicTo(c.x - w * 0.88f, c.y - hh * 1.25f, c.x + w * 0.85f, c.y - hh * 1.25f, c.x + w, c.y)
    }
    drawPath(upper, ink.copy(alpha = a), style = Stroke(w * 0.19f, cap = StrokeCap.Round))
    drawPath(shape, ink.copy(alpha = 0.32f * a), style = Stroke(w * 0.07f))
}
