package com.lorelight.ui.reader

/*
 * ReaderStyleDialogs.kt - font/colour picker dialogs and the floating
 * style panel pulled out of ReaderSettingsSheet.kt (S4, pure move, no
 * logic changes).
 *
 * These were already separate top-level @Composable functions in the
 * same file, just placed after the giant ReaderSettingsSheet composable,
 * so this is a pure cut-and-paste. Kept in the same package
 * (com.lorelight.ui.reader) so the one external caller
 * (ReaderScreen.kt calling FloatingStylePanel) needs zero import
 * changes - same precedent as navigation/ScreenDestination.kt (v26),
 * ui/library/components/LibraryVisualEffects.kt (v30), and
 * ui/settings/SettingsDataOps.kt (v39).
 */

import com.lorelight.R
import androidx.compose.ui.res.stringResource
import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import com.lorelight.ui.components.LorelightDialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.zIndex
import com.lorelight.data.model.Novel
import com.lorelight.ui.components.FontManagerEngine
import com.lorelight.ui.components.resolveFontFamily
import com.lorelight.ui.components.readerSafeTopPadding
import com.lorelight.ui.theme.GoldOnGradient
import com.lorelight.ui.theme.RefinedGoldGradient
import com.lorelight.ui.theme.GlassPanel
import com.lorelight.utils.FilterRule
import com.lorelight.utils.TextFilter
import androidx.compose.ui.semantics.Role

@Composable
fun FontSelectionDialog(
    showFontSelectionDialog: Boolean,
    onDismiss: () -> Unit
) {
    // Left as stub if required or if defined. Wait! FontSelectionDialog was defined inside ReaderScreen.kt.
    // Let's bring in the original FontSelectionDialog code under line 3210!
}

@Composable
fun FontItemRow() {
    // Stub or helper
}

@Composable
fun FontDownloadProgressDialog() {
    // Stub or helper
}

@Composable
fun ColorWheelPickerDialog(
    initialColorValue: Int,
    onColorSelected: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedColorCode by remember { mutableStateOf(initialColorValue.toLong() and 0xFFFFFFFFL) }
    var sliderVal by remember { mutableStateOf(0f) }
    
    val finalColor = remember(selectedColorCode, sliderVal) {
        val wheelColor = Color(selectedColorCode)
        if (sliderVal < 0f) {
            blendColors(wheelColor, Color.White, -sliderVal)
        } else {
            blendColors(wheelColor, Color.Black, sliderVal)
        }
    }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth(0.95f)
        ) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.ColorLens, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(stringResource(R.string.reader_color_select_accent), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.reader_font_close), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 12.dp))
                
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .clip(CircleShape)
                        .pointerInput(Unit) {
                            detectDragGestures { change, _ ->
                                val position = change.position
                                val radius = size.width / 2f
                                val dx = position.x - radius
                                val dy = position.y - radius
                                val distance = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                if (distance <= radius) {
                                    val angle = Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
                                    val normalizedAngle = if (angle < 0) angle + 360f else angle
                                    val hsvColor = android.graphics.Color.HSVToColor(floatArrayOf(normalizedAngle, 0.85f, 0.95f))
                                    selectedColorCode = hsvColor.toLong() and 0xFFFFFFFFL
                                }
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val canvasSize = size
                        val radius = canvasSize.width / 2f
                        
                        for (angleDegrees in 0 until 360 step 2) {
                            val hsvColor = android.graphics.Color.HSVToColor(floatArrayOf(angleDegrees.toFloat(), 0.85f, 0.95f))
                            drawArc(
                                color = Color(hsvColor),
                                startAngle = angleDegrees.toFloat(),
                                sweepAngle = 3f,
                                useCenter = true
                            )
                        }
                        
                        drawCircle(
                            color = Color.White,
                            radius = radius,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx())
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "Luminance: Light to Dark (White -> Selected -> Black)",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Slider(
                    value = sliderVal,
                    onValueChange = { sliderVal = it },
                    valueRange = -1f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = finalColor,
                        activeTrackColor = finalColor.copy(alpha = 0.6f),
                        inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(stringResource(R.string.reader_color_white), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                    Text(stringResource(R.string.reader_color_selected), fontSize = 10.sp, color = finalColor, fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.reader_color_black), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                ) {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(
                            text = buildAnnotatedString {
                                append("This is ")
                                withStyle(
                                    style = SpanStyle(
                                        color = finalColor,
                                        background = finalColor.copy(alpha = 0.15f),
                                        fontWeight = FontWeight.Bold
                                    )
                                ) {
                                    append("highlighted text")
                                }
                                append(" in the reader.")
                            },
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(16.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Button(
                    onClick = { onColorSelected(finalColor.toArgb()); onDismiss() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(stringResource(R.string.reader_apply_accent_color), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun NovelTextColorWheelPickerDialog(
    initialColorValue: Long,
    onColorSelected: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedColorCode by remember { mutableStateOf(initialColorValue) }
    var sliderVal by remember { mutableStateOf(0f) }
    
    val finalColor = remember(selectedColorCode, sliderVal) {
        val wheelColor = Color(selectedColorCode)
        if (sliderVal < 0f) {
            blendColors(wheelColor, Color.White, -sliderVal)
        } else {
            blendColors(wheelColor, Color.Black, sliderVal)
        }
    }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth(0.95f)
        ) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.ColorLens, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(stringResource(R.string.reader_color_select_novel_text), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.reader_font_close), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 12.dp))
                
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .clip(CircleShape)
                        .pointerInput(Unit) {
                            detectDragGestures { change, _ ->
                                val position = change.position
                                val radius = size.width / 2f
                                val dx = position.x - radius
                                val dy = position.y - radius
                                val distance = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                if (distance <= radius) {
                                    val angle = Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
                                    val normalizedAngle = if (angle < 0) angle + 360f else angle
                                    val hsvColor = android.graphics.Color.HSVToColor(floatArrayOf(normalizedAngle, 0.85f, 0.95f))
                                    selectedColorCode = hsvColor.toLong() and 0xFFFFFFFFL
                                }
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val canvasSize = size
                        val radius = canvasSize.width / 2f
                        
                        for (angleDegrees in 0 until 360 step 2) {
                            val hsvColor = android.graphics.Color.HSVToColor(floatArrayOf(angleDegrees.toFloat(), 0.85f, 0.95f))
                            drawArc(
                                color = Color(hsvColor),
                                startAngle = angleDegrees.toFloat(),
                                sweepAngle = 3f,
                                useCenter = true
                            )
                        }
                        
                        drawCircle(
                            color = Color.White,
                            radius = radius,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx())
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "Luminance: Light to Dark (White -> Selected -> Black)",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Slider(
                    value = sliderVal,
                    onValueChange = { sliderVal = it },
                    valueRange = -1f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = finalColor,
                        activeTrackColor = finalColor.copy(alpha = 0.6f),
                        inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(stringResource(R.string.reader_color_white), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                    Text(stringResource(R.string.reader_color_selected), fontSize = 10.sp, color = finalColor, fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.reader_color_black), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = finalColor.copy(alpha = 0.15f)),
                    modifier = Modifier.fillMaxWidth().border(1.dp, finalColor.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                ) {
                    Text(
                        text = "The quick brown fox jumps over the lazy dog.",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = finalColor,
                        modifier = Modifier.padding(12.dp),
                        textAlign = TextAlign.Center
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Button(
                    onClick = { onColorSelected(finalColor.toArgb().toLong() and 0xFFFFFFFFL); onDismiss() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(stringResource(R.string.reader_apply_novel_text_color), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun BgColorWheelPickerDialog(
    initialColorValue: Long,
    isAmoledBlack: Boolean,
    onAmoledChanged: (Boolean) -> Unit,
    onColorSelected: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedColorCode by remember { mutableStateOf(initialColorValue) }
    var useAmoled by remember { mutableStateOf(isAmoledBlack) }
    var sliderVal by remember { mutableStateOf(0f) }
    
    val finalColor = remember(selectedColorCode, sliderVal, useAmoled) {
        if (useAmoled) {
            Color.Black
        } else {
            val wheelColor = Color(selectedColorCode)
            if (sliderVal < 0f) {
                blendColors(wheelColor, Color.White, -sliderVal)
            } else {
                blendColors(wheelColor, Color.Black, sliderVal)
            }
        }
    }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth(0.95f)
        ) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.ColorLens, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(stringResource(R.string.reader_color_background_wheel), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.reader_font_close), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 12.dp))
                
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .clickable(role = Role.Button) { 
                            useAmoled = !useAmoled
                        },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (useAmoled) Color.Black else MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(
                        width = 1.5.dp,
                        color = if (useAmoled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Brightness2,
                                contentDescription = null,
                                tint = if (useAmoled) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "AMOLED Black Mode",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (useAmoled) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = useAmoled,
                            onCheckedChange = { useAmoled = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MaterialTheme.colorScheme.primary,
                                checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    }
                }
                
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .clip(CircleShape)
                        .pointerInput(useAmoled) {
                            if (!useAmoled) {
                                detectDragGestures { change, _ ->
                                    val position = change.position
                                    val radius = size.width / 2f
                                    val dx = position.x - radius
                                    val dy = position.y - radius
                                    val distance = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                    if (distance <= radius) {
                                        val angle = Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
                                        val normalizedAngle = if (angle < 0) angle + 360f else angle
                                        val hsvColor = android.graphics.Color.HSVToColor(floatArrayOf(normalizedAngle, 0.85f, 0.95f))
                                        selectedColorCode = hsvColor.toLong() and 0xFFFFFFFFL
                                    }
                                }
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val canvasSize = size
                        val radius = canvasSize.width / 2f
                        
                        for (angleDegrees in 0 until 360 step 2) {
                            val hsvColor = android.graphics.Color.HSVToColor(floatArrayOf(angleDegrees.toFloat(), 0.85f, 0.95f))
                            drawArc(
                                color = if (useAmoled) Color.Gray.copy(alpha = 0.3f) else Color(hsvColor),
                                startAngle = angleDegrees.toFloat(),
                                sweepAngle = 3f,
                                useCenter = true
                            )
                        }
                        
                        drawCircle(
                            color = if (useAmoled) Color.White.copy(alpha = 0.5f) else Color.White,
                            radius = radius,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx())
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                if (useAmoled) {
                    Text(
                        text = "AMOLED mode overrides background with standard pure black.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center
                    )
                } else {
                    Text(
                        text = "Luminance: Light to Dark (White -> Selected -> Black)",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Slider(
                        value = sliderVal,
                        onValueChange = { sliderVal = it },
                        valueRange = -1f..1f,
                        colors = SliderDefaults.colors(
                            thumbColor = finalColor,
                            activeTrackColor = finalColor.copy(alpha = 0.6f),
                            inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(stringResource(R.string.reader_color_white), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                        Text(stringResource(R.string.reader_color_selected), fontSize = 10.sp, color = finalColor, fontWeight = FontWeight.Bold)
                        Text(stringResource(R.string.reader_color_black), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Button(
                    onClick = {
                        if (useAmoled) {
                            onAmoledChanged(true)
                        } else {
                            onAmoledChanged(false)
                            onColorSelected(finalColor.toArgb().toLong() and 0xFFFFFFFFL)
                        }
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(stringResource(R.string.reader_apply_background_config), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun FontItemCard(
    fontName: String,
    isSelected: Boolean,
    readerFontSize: Float,
    onClick: () -> Unit,
    context: android.content.Context,
    modifier: Modifier = Modifier
) {
    val fontFamily = remember(fontName) { resolveFontFamily(fontName, context) }
    val animatedBg by animateColorAsState(
        targetValue = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
        animationSpec = tween(200),
        label = "fontItemBg"
    )
    val animatedBorderColor by animateColorAsState(
        targetValue = if (isSelected) MaterialTheme.colorScheme.primary
        else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f),
        animationSpec = tween(200),
        label = "fontItemBorder"
    )
    val animatedBorderWidth by animateDpAsState(
        targetValue = if (isSelected) 1.5.dp else 1.dp,
        animationSpec = tween(200),
        label = "fontItemBorderWidth"
    )

    Card(
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(animatedBorderWidth, animatedBorderColor),
        colors = CardDefaults.cardColors(containerColor = animatedBg),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick, role = Role.Button)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = fontName,
                    fontFamily = fontFamily,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (isSelected) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = stringResource(R.string.reader_color_selected),
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "The quick brown fox jumps over the lazy dog.",
                fontFamily = fontFamily,
                fontSize = readerFontSize.coerceIn(12f, 24f).sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun AlignmentIcon(align: String, tint: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.size(16.dp)) {
        val width = size.width
        val height = size.height
        val lineSpacing = height / 4
        
        when (align) {
            "Left" -> {
                drawLine(color = tint, start = Offset(0f, lineSpacing * 1), end = Offset(width * 0.9f, lineSpacing * 1), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(0f, lineSpacing * 2), end = Offset(width * 0.6f, lineSpacing * 2), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(0f, lineSpacing * 3), end = Offset(width * 0.8f, lineSpacing * 3), strokeWidth = 2.dp.toPx())
            }
            "Center" -> {
                drawLine(color = tint, start = Offset(width * 0.1f, lineSpacing * 1), end = Offset(width * 0.9f, lineSpacing * 1), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(width * 0.25f, lineSpacing * 2), end = Offset(width * 0.75f, lineSpacing * 2), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(width * 0.15f, lineSpacing * 3), end = Offset(width * 0.85f, lineSpacing * 3), strokeWidth = 2.dp.toPx())
            }
            "Right" -> {
                drawLine(color = tint, start = Offset(width * 0.1f, lineSpacing * 1), end = Offset(width, lineSpacing * 1), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(width * 0.4f, lineSpacing * 2), end = Offset(width, lineSpacing * 2), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(width * 0.2f, lineSpacing * 3), end = Offset(width, lineSpacing * 3), strokeWidth = 2.dp.toPx())
            }
            "Justify" -> {
                drawLine(color = tint, start = Offset(0f, lineSpacing * 1), end = Offset(width, lineSpacing * 1), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(0f, lineSpacing * 2), end = Offset(width, lineSpacing * 2), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(0f, lineSpacing * 3), end = Offset(width * 0.7f, lineSpacing * 3), strokeWidth = 2.dp.toPx())
            }
        }
    }
}

@Composable
fun FloatingStylePanel(
    fontSize: Float,
    lineSpacing: Float,
    paragraphSpacing: Float,
    textAlignment: String,
    onClose: () -> Unit,
    onFontSizeChange: (Float) -> Unit,
    onLineSpacingChange: (Float) -> Unit,
    onParagraphSpacingChange: (Float) -> Unit,
    onAlignmentChange: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
        modifier = Modifier.fillMaxWidth().wrapContentHeight()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Box(
                modifier = Modifier
                    .width(40.dp)
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f))
                    .align(Alignment.CenterHorizontally)
            )
            
            Spacer(modifier = Modifier.height(12.dp))

            // HEADER
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.FontDownload,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Customize Typography",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Adjust reading layout & spacing",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                }
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Panel",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant,
                modifier = Modifier.padding(vertical = 12.dp)
            )

            // SLIDERS & CONTROLS SECTION
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Left Column: Font Size & Line Spacing
                Column(modifier = Modifier.weight(1.1f)) {
                    // Size
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Size",
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${fontSize.toInt()}sp",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Slider(
                        value = fontSize,
                        onValueChange = onFontSizeChange,
                        valueRange = 12f..32f,
                        colors = SliderDefaults.colors(
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier.height(28.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Line Spacing
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.reader_line_spacing),
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${"%.1fx".format(lineSpacing)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Slider(
                        value = lineSpacing,
                        onValueChange = onLineSpacingChange,
                        valueRange = 1.0f..2.5f,
                        colors = SliderDefaults.colors(
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier.height(28.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Paragraph Spacing
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.reader_paragraph_spacing),
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${paragraphSpacing.toInt()}dp",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Slider(
                        value = paragraphSpacing,
                        onValueChange = onParagraphSpacingChange,
                        valueRange = 0f..40f,
                        colors = SliderDefaults.colors(
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier.height(28.dp)
                    )
                }

                // Right Column: Text Alignment Options
                Column(modifier = Modifier.weight(0.9f)) {
                    Text(
                        text = "Alignment",
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Column(
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("Left", "Center", "Right", "Justify").forEach { align ->
                            val isSelected = textAlignment == align
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(32.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (isSelected) MaterialTheme.colorScheme.primaryContainer 
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable(role = Role.Button) { onAlignmentChange(align) },
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                ) {
                                    AlignmentIcon(
                                        align = align,
                                        tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = align,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 10.sp,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DownloadedFontsDialog(
    viewModel: ReaderViewModel,
    onDismiss: () -> Unit,
    onOpenFontManager: () -> Unit,
    context: android.content.Context
) {
    val currentReaderFont by viewModel.readerFontFamily.collectAsState()
    val currentFontSize by viewModel.readerFontSize.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val systemFonts = remember {
        listOf("System Default", "System Serif", "System Monospace", "System Cursive")
    }

    val downloadedFonts = remember(context) {
        val df = FontManagerEngine.getDownloadedFonts(context)
        df.map { it.family }.distinct().filter { font ->
            font !in systemFonts && font != "Serif" && font != "Monospace" && font != "Cursive"
        }
    }

    val filteredSystemFonts = remember(searchQuery, systemFonts) {
        if (searchQuery.isBlank()) systemFonts
        else systemFonts.filter { it.contains(searchQuery, ignoreCase = true) }
    }

    val filteredDownloadedFonts = remember(searchQuery, downloadedFonts) {
        if (searchQuery.isBlank()) downloadedFonts
        else downloadedFonts.filter { it.contains(searchQuery, ignoreCase = true) }
    }

    LorelightDialog(
        onDismissRequest = onDismiss,
        titleContent = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.FontDownload,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Text(
                        text = stringResource(R.string.reader_font_selection),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                TextButton(
                    onClick = {
                        onDismiss()
                        onOpenFontManager()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Browse Fonts",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(stringResource(R.string.reader_font_browse), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.reader_font_close), fontWeight = FontWeight.Bold)
            }
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 480.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text(stringResource(R.string.reader_font_search_placeholder), fontSize = 13.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        modifier = Modifier.size(18.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (filteredSystemFonts.isNotEmpty()) {
                    item {
                        Text(
                            text = "SYSTEM FONTS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(start = 4.dp, top = 4.dp, bottom = 4.dp)
                        )
                    }

                    items(filteredSystemFonts, key = { "sys_$it" }) { fontName ->
                        FontItemCard(
                            fontName = fontName,
                            isSelected = fontName == currentReaderFont,
                            readerFontSize = currentFontSize,
                            onClick = {
                                viewModel.readerFontFamily.value = fontName
                                onDismiss()
                            },
                            context = context
                        )
                    }
                }

                if (filteredDownloadedFonts.isNotEmpty() || searchQuery.isBlank()) {
                    item {
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "DOWNLOADED FONTS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (downloadedFonts.isNotEmpty()) {
                                Text(
                                    text = "${downloadedFonts.size} installed",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }

                    if (filteredDownloadedFonts.isEmpty() && searchQuery.isBlank()) {
                        item {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
                                ),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                                ) {
                                    Text(
                                        text = "No custom fonts downloaded yet.",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Button(
                                        onClick = {
                                            onDismiss()
                                            onOpenFontManager()
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                                            contentColor = MaterialTheme.colorScheme.primary
                                        ),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(36.dp),
                                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Download,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(stringResource(R.string.reader_font_download), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    } else {
                        items(filteredDownloadedFonts, key = { "dl_$it" }) { fontName ->
                            FontItemCard(
                                fontName = fontName,
                                isSelected = fontName == currentReaderFont,
                                readerFontSize = currentFontSize,
                                onClick = {
                                    viewModel.readerFontFamily.value = fontName
                                    onDismiss()
                                },
                                context = context
                            )
                        }
                    }
                }

                if (filteredSystemFonts.isEmpty() && filteredDownloadedFonts.isEmpty() && searchQuery.isNotBlank()) {
                    item {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No fonts match \"$searchQuery\"",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

private val fontFamilyCache = mutableMapOf<String, FontFamily>()

fun getFontFamily(fontName: String): FontFamily {
    return fontFamilyCache.getOrPut(fontName) {
        when (fontName) {
            "System Serif", "Serif" -> FontFamily.Serif
            "System Monospace", "Monospace" -> FontFamily.Monospace
            "System Cursive", "Cursive" -> FontFamily.Cursive
            else -> FontFamily.Default
        }
    }
}

@Composable
fun GlassCollapsibleSection(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isExpanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    GlassPanel(
        modifier = Modifier.fillMaxWidth(),
        cornerRadius = 16.dp,
        tintAlpha = 0.35f
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(role = Role.Button) { onToggle() }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "Collapse" else "Expand",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    modifier = Modifier.size(20.dp)
                )
            }
            
            if (isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    content()
                }
            }
        }
    }
}
