package com.lorelight.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY timestamp DESC")
    fun getAll(): List<HistoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsertOne(entry: HistoryEntity)

    @Query("SELECT * FROM history WHERE novelId = :novelId LIMIT 1")
    fun getById(novelId: String): HistoryEntity?

    /**
     * Trims the table to the newest :max rows. Uses a subquery so it binds
     * exactly ONE variable, regardless of how many rows exist - unlike the old
     * "NOT IN (:ids)" pattern which could exceed SQLite's 999-variable limit.
     */
    @Query("DELETE FROM history WHERE novelId NOT IN (SELECT novelId FROM history ORDER BY timestamp DESC LIMIT :max)")
    fun trimToLimit(max: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsertAll(entries: List<HistoryEntity>)

    @Query("SELECT novelId FROM history")
    fun allIds(): List<String>

    @Query("DELETE FROM history WHERE novelId IN (:ids)")
    fun deleteByIds(ids: List<String>)

    /**
     * Chunked so the bound-variable count can never exceed SQLite's limit
     * (999 on API <= 29). Computes the doomed ids in Kotlin, then deletes them
     * in batches, instead of binding the entire keep-list in one statement.
     */
    fun deleteAllExcept(ids: List<String>) {
        val keep = ids.toHashSet()
        val doomed = allIds().filter { it !in keep }
        doomed.chunked(500).forEach { deleteByIds(it) }
    }

    @Query("DELETE FROM history")
    fun deleteAll()

    @Transaction
    fun replaceAll(entries: List<HistoryEntity>) {
        // SAFETY: an empty list is treated as "no data to write", never as
        // "delete the user's entire library". Explicit wipes must call
        // replaceAllAllowEmpty() or deleteAll() directly.
        if (entries.isEmpty()) return
        entries.chunked(500).forEach { upsertAll(it) }
        deleteAllExcept(entries.map { it.novelId })
    }

    @Transaction
    fun replaceAllAllowEmpty(entries: List<HistoryEntity>) {
        if (entries.isEmpty()) {
            deleteAll()
        } else {
            entries.chunked(500).forEach { upsertAll(it) }
            deleteAllExcept(entries.map { it.novelId })
        }
    }
}
