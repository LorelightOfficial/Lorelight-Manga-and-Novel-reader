package com.lorelight.browse.repo

import android.content.Context
import com.lorelight.browse.js.JSPluginEngine
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/**
 * Chapter counts are NOT part of a plugin's listing response: SourceNovelItem only
 * carries name, path and cover. They exist only on SourceNovelDetails, which costs
 * one parseNovel() network call per novel. This cache makes that affordable:
 *  - every result is remembered for the session, successes and failures alike
 *  - at most MAX_PARALLEL fetches run at once, so a source site is never hammered
 *  - a failure is stored as UNKNOWN so it is never retried in a loop
 */
object SourceChapterCountCache {

    const val UNKNOWN = -1

    // Raise MAX_PARALLEL for speed, lower it if a site starts rejecting requests.
    private const val MAX_PARALLEL = 2
    private const val MAX_CACHE = 600

    private val gate = Semaphore(MAX_PARALLEL)

    private val cache = object : LinkedHashMap<String, Int>(128, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Int>?): Boolean =
            size > MAX_CACHE
    }

    private fun key(pluginId: String, path: String) = pluginId + "|" + path

    @Synchronized
    fun peek(pluginId: String, path: String): Int? = cache[key(pluginId, path)]

    @Synchronized
    private fun put(pluginId: String, path: String, value: Int) {
        cache[key(pluginId, path)] = value
    }

    suspend fun fetch(appContext: Context, pluginId: String, path: String): Int {
        peek(pluginId, path)?.let { return it }
        return gate.withPermit {
            val cached = peek(pluginId, path)
            if (cached != null) {
                cached
            } else {
                val count = try {
                    JSPluginEngine.parseNovel(appContext, pluginId, path).chapters.size
                } catch (e: Exception) {
                    UNKNOWN
                }
                put(pluginId, path, count)
                count
            }
        }
    }
}
