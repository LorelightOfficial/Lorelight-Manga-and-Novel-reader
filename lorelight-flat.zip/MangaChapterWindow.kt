package com.lorelight.manga.reader

import eu.kanade.tachiyomi.source.model.Page
import kotlinx.coroutines.Job
import java.util.concurrent.atomic.AtomicInteger

data class MangaReaderPage(
    val index: Int,
    val page: Page
)

sealed interface MangaChapterState {
    data object Wait : MangaChapterState
    data object Loading : MangaChapterState
    data class Error(val error: Throwable) : MangaChapterState
    data class Loaded(val pages: List<MangaReaderPage>) : MangaChapterState
}

class MangaChapter(
    val chapterId: String,
    val chapterIndex: Int,
    val chapterName: String,
    val chapterUrl: String
) {
    private val refCount = AtomicInteger(0)

    var state: MangaChapterState = MangaChapterState.Wait
        internal set

    var loadJob: Job? = null
        internal set

    val isReady: Boolean
        get() = state is MangaChapterState.Loaded && loadJob != null

    fun ref() {
        refCount.incrementAndGet()
    }

    fun unref(onRelease: (MangaChapter) -> Unit) {
        if (refCount.decrementAndGet() <= 0) {
            refCount.set(0)
            loadJob?.cancel()
            loadJob = null
            state = MangaChapterState.Wait
            onRelease(this)
        }
    }

    val currentRefCount: Int get() = refCount.get()
}

internal data class MangaWindow(
    val prev2Index: Int?,
    val prevIndex: Int?,
    val currIndex: Int,
    val nextIndex: Int?,
    val next2Index: Int?
) {
    fun allIndices(): List<Int> = listOfNotNull(prev2Index, prevIndex, currIndex, nextIndex, next2Index).distinct()
}

internal fun computeWindow(chapterCount: Int, currIndex: Int): MangaWindow {
    if (chapterCount <= 0) return MangaWindow(null, null, 0, null, null)
    val clampedCurr = currIndex.coerceIn(0, chapterCount - 1)
    val prev1 = if (clampedCurr > 0) clampedCurr - 1 else null
    val prev2 = if (clampedCurr > 1) clampedCurr - 2 else null
    val next1 = if (clampedCurr < chapterCount - 1) clampedCurr + 1 else null
    val next2 = if (clampedCurr < chapterCount - 2) clampedCurr + 2 else null
    return MangaWindow(prev2, prev1, clampedCurr, next1, next2)
}

internal fun canDropChapter(
    chapterId: String,
    visibleChapterIds: Set<String>
): Boolean {
    return !visibleChapterIds.contains(chapterId)
}

internal data class VisibleSpan(val index: Int, val offset: Int, val size: Int)

internal fun lastEndVisibleIndex(
    items: List<VisibleSpan>,
    viewportStart: Int,
    viewportEnd: Int
): Int {
    for (i in items.indices.reversed()) {
        val item = items[i]
        val childStart = item.offset
        val childEnd = item.offset + item.size
        if (childEnd <= viewportEnd || childStart < viewportStart) {
            return item.index
        }
    }
    return -1
}

internal fun shouldPreloadNext(pageIndex: Int, pageCount: Int): Boolean =
    pageCount - (pageIndex + 1) < 5
