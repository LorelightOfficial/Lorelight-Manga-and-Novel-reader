package com.lorelight.manga.model

import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga

/**
 * Null-safe accessors and list sanitizers for source models.
 *
 * `SMangaImpl`/`SChapterImpl` declare `url`, `title` and `name` as `lateinit`,
 * so a source that returns a partially-built model can leave them unset.
 * Reading such a property directly throws
 * [UninitializedPropertyAccessException]; these helpers turn that into a null
 * (or a sensible fallback) so the reader/browse UI never crashes on a
 * malformed source response.
 */

fun SManga.safeUrl(): String? =
    try { url.ifBlank { null } } catch (_: UninitializedPropertyAccessException) { null }

fun SManga.safeTitle(): String? =
    try { title.ifBlank { null } } catch (_: UninitializedPropertyAccessException) { null }

fun SChapter.safeUrl(): String? =
    try { url.ifBlank { null } } catch (_: UninitializedPropertyAccessException) { null }

fun SChapter.safeName(): String =
    try { name.ifBlank { "Chapter" } } catch (_: UninitializedPropertyAccessException) { "Chapter" }

/** Initializes the (lateinit) url and title on a freshly created manga. */
fun SManga.seedFrom(url: String, title: String): SManga {
    if (safeUrl() == null) this.url = url
    if (safeTitle() == null) this.title = title
    return this
}

/**
 * Drops chapters without a usable url and removes duplicates, keeping the first
 * occurrence of each url (source order preserved).
 */
fun List<SChapter>.sanitizedChapters(): List<SChapter> {
    val seen = HashSet<String>()
    return filter { chapter ->
        val u = chapter.safeUrl() ?: return@filter false
        seen.add(u)
    }
}

/**
 * Drops mangas without a usable url, removes duplicates (first url wins), and
 * guarantees every remaining entry has a title, defaulting to "Unknown".
 */
fun List<SManga>.sanitizedMangas(): List<SManga> {
    val seen = HashSet<String>()
    return filter { manga ->
        val u = manga.safeUrl() ?: return@filter false
        seen.add(u)
    }.onEach { manga ->
        if (manga.safeTitle() == null) manga.title = "Unknown"
    }
}
