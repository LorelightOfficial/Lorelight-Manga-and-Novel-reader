package com.lorelight.ui.reader

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.lorelight.ui.theme.GlassPanel

@Composable
fun ReaderBottomControls(
    isPlaying: Boolean,
    readerBgColor: Color,
    readerTextColor: Color,
    readerHighlightColor: Color,
    themeState: String,
    activeChapterIndex: Int,
    chaptersCount: Int,
    onPrevChapter: () -> Unit,
    onNextChapter: () -> Unit,
    onSkipBackward: () -> Unit,
    onSkipForward: () -> Unit,
    onTogglePlayPause: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = Color.Transparent,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // ALWAYS-DARK READER PANEL FIX: GlassPanel looks at the ambient
            // MaterialTheme.colorScheme to decide whether to render its light
            // or dark glass treatment. The reader's own reading surface is
            // always dark regardless of the app's light/dark mode setting, so
            // this bottom controls bar must not inherit the app-wide scheme -
            // otherwise it flips to a light glass panel whenever the app is in
            // light mode. Forcing a dark background/surface here (derived from
            // the reader's own colors) makes GlassPanel's isLight check always
            // resolve to false for this panel.
            val forcedDarkScheme = MaterialTheme.colorScheme.copy(
                background = readerBgColor,
                surface = readerBgColor,
                onSurface = readerTextColor,
                onSurfaceVariant = readerTextColor.copy(alpha = 0.75f),
                primary = readerHighlightColor
            )
            MaterialTheme(colorScheme = forcedDarkScheme) {
            // Same frosted panel the rest of the app uses, rather than a
            // flat translucent card. GlassPanel draws its own hairline
            // edge, so the hand-rolled border is gone with it.
            GlassPanel(
                shape = RoundedCornerShape(32.dp),
                tintAlpha = 0.78f,
                modifier = Modifier
                    .padding(start = 24.dp, end = 24.dp, top = 8.dp, bottom = 12.dp)
                    .widthIn(max = 280.dp)
                    .height(52.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onPrevChapter,
                        enabled = activeChapterIndex > 0,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastRewind,
                            contentDescription = "Prev chapter",
                            modifier = Modifier.size(18.dp),
                            tint = if (activeChapterIndex > 0) readerTextColor else readerTextColor.copy(alpha = 0.35f)
                        )
                    }
                    IconButton(
                        onClick = onSkipBackward,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipPrevious,
                            contentDescription = "Prev sentence",
                            modifier = Modifier.size(18.dp),
                            tint = readerTextColor
                        )
                    }
                    FilledIconButton(
                        onClick = onTogglePlayPause,
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = readerHighlightColor,
                            contentColor = if (themeState == "blackgold") Color(0xFF2E1901) else Color.White
                        ),
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play/Pause",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = onSkipForward,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Next sentence",
                            modifier = Modifier.size(18.dp),
                            tint = readerTextColor
                        )
                    }
                    IconButton(
                        onClick = onNextChapter,
                        enabled = activeChapterIndex < chaptersCount - 1,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastForward,
                            contentDescription = "Next chapter",
                            modifier = Modifier.size(18.dp),
                            tint = if (activeChapterIndex < chaptersCount - 1) readerTextColor else readerTextColor.copy(alpha = 0.35f)
                        )
                    }
                }
            }
            } // end forcedDarkScheme MaterialTheme
        }
    }
}
