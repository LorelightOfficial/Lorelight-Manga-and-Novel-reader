package com.lorelight.data.db

import android.content.Context
import com.lorelight.data.model.Novel

/**
 * Phase 1B of the storage rearchitecture.
 *
 * THE BUG THIS FIXES
 * ------------------
 * Reading progress (currentChapter / currentParagraphIndex / currentScrollOffset
 * / currentWordIndex / lastReadTimestamp) used to live only on the `novels` row.
 * Those fields change constantly while reading, and the only way to persist them
 * was NovelDao.replaceAll(), which upserts EVERY row in the library and then runs
 * a delete pass over every id.
 *
 * So a single page turn rewrote the entire library table. On a slower device, or
 * when Android killed the process during the write, the table could be left
 * holding an older generation of the data - which is exactly the "my library went
 * back to how it was days ago" symptom.
 *
 * Progress now lives in its own one-row-per-novel `reading_progress` table. A
 * progress tick writes a single small row and touches nothing else.
 *
 * SAFETY / REVERSIBILITY
 * ----------------------
 * The `novels` row still carries the legacy progress columns and is still written
 * on full saves, so nothing that reads Novel.currentParagraphIndex breaks and this
 * change can be reverted by simply not calling into here. On read, reading_progress
 * is layered on top (see overlay()) because it is the fresher of the two.
 *
 * Every write is guarded so progress can only ever move FORWARD in time. A stale
 * in-memory copy of the library can never roll a newer position backwards.
 */
object ProgressStore {

    private const val PREFS = "lorelight_storage_flags"
    private const val KEY_BACKFILL_V1 = "progress_backfill_v1_done"

    private fun flags(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun toProgressEntity(novel: Novel, now: Long = System.currentTimeMillis()) =
        ReadingProgressEntity(
            novelId = novel.id,
            currentChapter = novel.currentChapter,
            currentChapterIndex = novel.currentChapterIndex,
            currentParagraphIndex = novel.currentParagraphIndex,
            currentScrollOffset = novel.currentScrollOffset,
            currentWordIndex = novel.currentWordIndex,
            lastReadTimestamp = novel.lastReadTimestamp,
            updatedAt = now
        )

    /**
     * THE HOT PATH. Writes exactly one row.
     *
     * This is what replaces a full-library rewrite on every page turn and every
     * TTS flush. Returns true if the row was written.
     */
    fun saveProgress(context: Context, novel: Novel): Boolean {
        if (novel.id.isEmpty()) return false
        return try {
            val dao = LorelightDatabase.get(context.applicationContext).readingProgressDao()

            // FIX A1: the old version blindly upserted. The class comment claimed
            // "every write is guarded so progress can only ever move FORWARD", but
            // only syncAll() actually did that - the hot path did not. A stale
            // Novel copy (e.g. one captured by a screen before a TTS tick) could
            // therefore overwrite a newer stored position. Now the stored row wins
            // whenever it is genuinely newer.
            val prev = try { dao.get(novel.id) } catch (e: Exception) { null }
            if (prev != null && prev.lastReadTimestamp > novel.lastReadTimestamp) {
                android.util.Log.w(
                    "ProgressStore",
                    "Ignored stale progress write for ${novel.id}: stored=${prev.lastReadTimestamp} > incoming=${novel.lastReadTimestamp}"
                )
                return false
            }

            dao.upsert(toProgressEntity(novel))
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /** Stored position for one novel, or null when nothing has been recorded. */
    fun loadProgress(context: Context, novelId: String): ReadingProgressEntity? {
        if (novelId.isEmpty()) return null
        return try {
            LorelightDatabase.get(context.applicationContext).readingProgressDao().get(novelId)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * FIX C16: single place that applies a stored position to a Novel, so the
     * three position systems (reading_progress row, ReadingPositionStore prefs and
     * the legacy Novel columns) can no longer disagree about which is authoritative.
     */
    fun applyStoredProgress(context: Context, novel: Novel): Novel {
        val row = loadProgress(context, novel.id) ?: return novel
        if (row.lastReadTimestamp < novel.lastReadTimestamp) return novel
        return novel.copy(
            currentChapter = row.currentChapter,
            // Rows that existed before the index column was added carry -1. A
            // newer row must not be allowed to erase a good index that the
            // novels row still holds, so -1 means "no opinion", not "chapter
            // unknown".
            currentChapterIndex = if (row.currentChapterIndex >= 0) {
                row.currentChapterIndex
            } else {
                novel.currentChapterIndex
            },
            currentParagraphIndex = row.currentParagraphIndex,
            currentScrollOffset = row.currentScrollOffset,
            currentWordIndex = row.currentWordIndex,
            lastReadTimestamp = row.lastReadTimestamp
        )
    }

    /**
     * Keeps reading_progress in step whenever the whole library is saved.
     *
     * A full save may be driven by an in-memory list that predates the most
     * recent progress-only write, so any row whose stored lastReadTimestamp is
     * NEWER than the incoming one is skipped rather than overwritten.
     */
    fun syncAll(context: Context, novels: List<Novel>) {
        if (novels.isEmpty()) return
        try {
            val dao = LorelightDatabase.get(context.applicationContext).readingProgressDao()
            val existing = dao.getAll().associateBy { it.novelId }
            val now = System.currentTimeMillis()
            val rows = novels.mapNotNull { n ->
                if (n.id.isEmpty()) return@mapNotNull null
                val prev = existing[n.id]
                if (prev != null && prev.lastReadTimestamp > n.lastReadTimestamp) return@mapNotNull null
                toProgressEntity(n, now)
            }
            if (rows.isNotEmpty()) rows.chunked(500).forEach { dao.upsertAll(it) }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Layers stored progress over freshly loaded novels. reading_progress wins,
     * but only when it is genuinely newer, so a partially written row can never
     * drag a novel's position backwards.
     */
    fun overlay(context: Context, novels: List<Novel>): List<Novel> {
        if (novels.isEmpty()) return novels
        return try {
            val rows = LorelightDatabase.get(context.applicationContext)
                .readingProgressDao()
                .getAll()
                .associateBy { it.novelId }
            if (rows.isEmpty()) return novels
            novels.map { n ->
                val p = rows[n.id] ?: return@map n
                if (p.lastReadTimestamp < n.lastReadTimestamp) return@map n
                n.copy(
                    currentChapter = p.currentChapter,
                    // -1 means "no opinion" -- see applyStoredProgress.
                    currentChapterIndex = if (p.currentChapterIndex >= 0) {
                        p.currentChapterIndex
                    } else {
                        n.currentChapterIndex
                    },
                    currentParagraphIndex = p.currentParagraphIndex,
                    currentScrollOffset = p.currentScrollOffset,
                    currentWordIndex = p.currentWordIndex,
                    lastReadTimestamp = p.lastReadTimestamp
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            novels
        }
    }

    /**
     * One-time seed of reading_progress from the existing novel rows.
     *
     * Deliberately does NOT backfill the `chapters` table. That table stays empty
     * until a later phase moves the chapter reads over: a library of 8 novels with
     * 1000 chapters each would be 8000 inserts, and because the database still
     * runs with allowMainThreadQueries() this is reachable from the main thread.
     * reading_progress is one row per novel, so seeding it is trivially cheap.
     */
    fun backfillIfNeeded(context: Context, novels: List<Novel>) {
        val f = flags(context)
        if (f.getBoolean(KEY_BACKFILL_V1, false)) return
        if (novels.isEmpty()) return
        try {
            val dao = LorelightDatabase.get(context.applicationContext).readingProgressDao()
            val now = System.currentTimeMillis()
            val rows = novels.filter { it.id.isNotEmpty() }.map { toProgressEntity(it, now) }
            if (rows.isNotEmpty()) rows.chunked(500).forEach { dao.upsertAll(it) }
            f.edit().putBoolean(KEY_BACKFILL_V1, true).apply()
            android.util.Log.i("ProgressStore", "Seeded reading_progress with ${rows.size} rows.")
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /** Drops the progress row for a novel that is being removed from the library. */
    fun deleteProgress(context: Context, novelId: String) {
        if (novelId.isEmpty()) return
        try {
            LorelightDatabase.get(context.applicationContext).readingProgressDao().delete(novelId)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
