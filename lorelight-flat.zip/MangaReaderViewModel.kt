package com.lorelight.manga.reader

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lorelight.data.model.Novel
import com.lorelight.data.model.isManga
import com.lorelight.data.model.decodeMangaChapterUrl
import com.lorelight.data.model.mangaSourceId
import com.lorelight.service.NovelImportManager
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import tachiyomi.domain.source.service.SourceManager
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import java.io.File
import org.json.JSONArray
import org.json.JSONObject

/**
 * Short-lived in-memory cache of already-resolved chapter page lists, keyed by
 * source + chapter URL. Keeps page lists cached for the active session (with a
 * 1-hour TTL window) so re-opening the reader or flipping chapters is instant
 * without extra network round trips, while avoiding persistent-forever stale page orders.
 */
internal object MangaPageListCache {
    private const val MEMORY_TTL_MS = 60 * 60 * 1000L // 1 hour
    private const val DISK_TTL_MS = 30L * 24 * 60 * 60 * 1000L // 30 days
    private const val DIR_NAME = "manga_page_lists"

    private data class Entry(
        val pages: List<Page>,
        val timestamp: Long = System.currentTimeMillis()
    )

    private val map = ConcurrentHashMap<String, Entry>()

    @Volatile
    private var appContext: android.content.Context? = null

    /** Called once from Application.onCreate. Disk backing is inert until then. */
    fun init(context: android.content.Context) {
        appContext = context.applicationContext
    }

    private fun key(sourceId: Long?, chapterUrl: String): String =
        (sourceId ?: 0L).toString() + "|" + chapterUrl

    private fun fileFor(k: String): File? {
        val ctx = appContext ?: return null
        val dir = File(ctx.cacheDir, DIR_NAME)
        if (!dir.exists() && !dir.mkdirs()) return null
        val hash = java.security.MessageDigest.getInstance("SHA-256")
            .digest(k.toByteArray())
            .joinToString("") { "%02x".format(it) }
        return File(dir, "$hash.json")
    }

    fun get(sourceId: Long?, chapterUrl: String): List<Page>? {
        val k = key(sourceId, chapterUrl)
        val entry = map[k]
        if (entry != null) {
            if (System.currentTimeMillis() - entry.timestamp <= MEMORY_TTL_MS) return entry.pages
            map.remove(k)
        }
        return readFromDisk(k)?.also { map[k] = Entry(it) }
    }

    fun put(sourceId: Long?, chapterUrl: String, pages: List<Page>) {
        if (pages.isEmpty()) return
        val k = key(sourceId, chapterUrl)
        map[k] = Entry(pages)
        writeToDisk(k, pages)
    }

    fun invalidate(sourceId: Long?, chapterUrl: String) {
        val k = key(sourceId, chapterUrl)
        map.remove(k)
        try {
            fileFor(k)?.delete()
        } catch (_: Throwable) {
        }
    }

    fun clear() {
        map.clear()
        try {
            val ctx = appContext ?: return
            File(ctx.cacheDir, DIR_NAME).listFiles()?.forEach { it.delete() }
        } catch (_: Throwable) {
        }
    }

    private fun readFromDisk(k: String): List<Page>? {
        return try {
            val f = fileFor(k) ?: return null
            if (!f.exists()) return null
            if (System.currentTimeMillis() - f.lastModified() > DISK_TTL_MS) {
                f.delete()
                return null
            }
            val arr = JSONArray(f.readText())
            val out = ArrayList<Page>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Page(
                        o.optInt("i", i),
                        o.optString("u", ""),
                        o.optString("iu", "").takeIf { it.isNotBlank() }
                    )
                )
            }
            out.takeIf { it.isNotEmpty() }
        } catch (_: Throwable) {
            null
        }
    }

    private fun writeToDisk(k: String, pages: List<Page>) {
        try {
            val f = fileFor(k) ?: return
            val arr = JSONArray()
            for (p in pages) {
                arr.put(
                    JSONObject()
                        .put("i", p.index)
                        .put("u", p.url)
                        .put("iu", p.imageUrl ?: "")
                )
            }
            f.writeText(arr.toString())
        } catch (_: Throwable) {
        }
    }
}

data class MangaReaderUiState(
    val novel: Novel? = null,
    val sourceId: Long? = null,
    val chapterNames: List<String> = emptyList(),
    val chapterUrls: List<String> = emptyList(),
    val currentChapterIndex: Int = 0,
    val activeChapterIndex: Int = 0,
    val pages: List<Page> = emptyList(),
    val feedItems: List<MangaFeedItem> = emptyList(),
    val currentPageIndex: Int = 0,
    val isLoading: Boolean = false,
    val error: String? = null,
    val toastMessage: String? = null,
    /**
     * Incremented ONLY by [MangaReaderViewModel.loadChapter], i.e. only on an
     * explicit jump: opening the reader, tapping a chapter in the list, or the
     * next/previous chapter buttons.
     *
     * Reading organically from chapter 4 into chapter 5 does NOT change it. The
     * reader keys its one-shot "anchor the scroll position" effect on this, so
     * ordinary scrolling can no longer be mistaken for a jump and re-anchored
     * mid-gesture.
     */
    val jumpToken: Int = 0
)

class MangaReaderViewModel(application: Application) : AndroidViewModel(application) {
    private val appContext = application.applicationContext

    private val _uiState = MutableStateFlow(MangaReaderUiState())
    val uiState: StateFlow<MangaReaderUiState> = _uiState.asStateFlow()

    private var saveJob: Job? = null
    private var windowFetchJob: Job? = null
    internal val chapterCache = mutableMapOf<Int, MangaChapter>()
    internal var currentWindow = MangaWindow(null, null, 0, null, null)
    internal val visibleChapterIds = mutableSetOf<String>()
    private var currentNovelId: String? = null

    fun init(novel: Novel, forceChapterIndex: Int? = null, forceChapterName: String? = null) {
        if (currentNovelId == novel.id && chapterCache.isNotEmpty()) {
            // Same novel is already open. If the user explicitly picked a
            // chapter from the details list, jump to that chapter at page 1;
            // otherwise keep the live position so re-opening stays instant.
            if (forceChapterIndex != null && forceChapterIndex in _uiState.value.chapterUrls.indices) {
                loadChapter(forceChapterIndex, targetPageIndex = 0)
            } else if (forceChapterName != null) {
                val idx = _uiState.value.chapterNames.indexOf(forceChapterName)
                if (idx >= 0) loadChapter(idx, targetPageIndex = 0)
            }
            return
        }

        saveJob?.cancel()
        saveJob = null
        for (ch in chapterCache.values) {
            ch.loadJob?.cancel()
        }
        chapterCache.clear()
        currentWindow = MangaWindow(null, null, 0, null, null)
        visibleChapterIds.clear()

        currentNovelId = novel.id

        val sourceId = novel.mangaSourceId
        val chapterNames = novel.chapters
        val chapterUrls = novel.chapterUrls

        // RESUME FIX. A plain open resolved its chapter from the mutable
        // `novel.currentChapter` NAME string and fell back to chapter 1 whenever
        // indexOf missed. That is why closing the app on chapter 23 could reopen
        // on chapter 12: the novel row had been overwritten by an unrelated
        // library save, while the chapters table -- which stamps lastReadAt on
        // every page turn -- was never consulted. resumeTarget now decides both
        // the chapter AND the page for a plain open, so the two cannot disagree.
        val plainOpen = forceChapterIndex == null && forceChapterName == null
        val resume = if (plainOpen && chapterNames.isNotEmpty()) {
            com.lorelight.manga.progress.MangaReadProgress.resumeTarget(appContext, novel)
        } else {
            null
        }

        val startingChapterIndex = if (forceChapterIndex != null && forceChapterIndex in chapterUrls.indices) {
            forceChapterIndex
        } else if (resume != null && resume.chapterIndex in chapterNames.indices) {
            resume.chapterIndex
        } else if (chapterNames.isNotEmpty()) {
            val targetName = forceChapterName ?: novel.currentChapter
            val idx = chapterNames.indexOf(targetName)
            if (idx >= 0) idx else 0
        } else {
            0
        }

        // An explicit chapter pick always starts at page 1; a plain open
        // (Continue) resumes at the saved page.
        // mihon parity: a chapter remembers its OWN page, so re-opening chapter 3
        // resumes where you left chapter 3 - not page 1, and not the page you
        // happen to be on in chapter 40. A chapter already read to the end
        // restarts from the top, exactly like mihon.
        val perChapter = com.lorelight.manga.progress.MangaReadProgress
            .load(appContext, novel.id, chapterNames.size)
        val startingPageIndex = if (forceChapterIndex != null || forceChapterName != null) {
            if (perChapter.isRead(startingChapterIndex)) {
                0
            } else {
                perChapter.lastPageRead(startingChapterIndex).coerceAtLeast(0)
            }
        } else {
            val stored = perChapter.lastPageRead(startingChapterIndex)
            if (stored > 0 && !perChapter.isRead(startingChapterIndex)) {
                stored
            } else if (resume != null && resume.chapterIndex == startingChapterIndex) {
                // resumeTarget already worked out the page for this chapter, and
                // it knows to restart one that was finished.
                resume.pageIndex.coerceAtLeast(0)
            } else {
                // Legacy fallback for novels saved before per-chapter progress.
                val savedPage = if (novel.currentMangaPageIndex > 0) novel.currentMangaPageIndex else novel.currentParagraphIndex
                savedPage.coerceAtLeast(0)
            }
        }

        // RESUME SELF-HEAL. If the chapters table disagreed with the novel row's
        // currentChapter, that row was stale -- write the truth back so the
        // library card and the Continue button stop advertising an old chapter.
        val resolvedName = chapterNames.getOrNull(startingChapterIndex)
        if (resolvedName != null && resolvedName != novel.currentChapter) {
            viewModelScope.launch(Dispatchers.IO) {
                NovelImportManager.updateNovelProgress(appContext, novel.id) { current ->
                    current.copy(
                        currentChapter = resolvedName,
                        currentChapterIndex = startingChapterIndex,
                        lastReadTimestamp = System.currentTimeMillis()
                    )
                }
            }
        }

        _uiState.value = MangaReaderUiState(
            novel = novel,
            sourceId = sourceId,
            chapterNames = chapterNames,
            chapterUrls = chapterUrls,
            currentChapterIndex = startingChapterIndex,
            activeChapterIndex = startingChapterIndex,
            currentPageIndex = startingPageIndex,
            isLoading = true,
            error = null
        )

        // Give every chapter somewhere to store its read state, and fold in any
        // completions recorded by the old novel-side list on first open.
        com.lorelight.manga.progress.MangaReadProgress.ensureRows(appContext, novel)
        com.lorelight.manga.progress.MangaReadProgress.migrateLegacyCompleted(appContext, novel)

        loadChapter(startingChapterIndex, targetPageIndex = startingPageIndex)
    }

    fun prewarm(novel: Novel, forceChapterIndex: Int? = null, forceChapterName: String? = null) {
        if (!novel.isManga) return
        val sourceId = novel.mangaSourceId
        val chapterNames = novel.chapters
        val chapterUrls = novel.chapterUrls
        if (chapterUrls.isEmpty()) return

        val targetIdx = when {
            forceChapterIndex != null && forceChapterIndex in chapterUrls.indices -> forceChapterIndex
            forceChapterName != null -> chapterNames.indexOf(forceChapterName).let { if (it >= 0) it else 0 }
            else -> chapterNames.indexOf(novel.currentChapter).let { if (it >= 0) it else 0 }
        }
        val chapterUrl = chapterUrls.getOrNull(targetIdx) ?: return

        if (MangaPageListCache.get(sourceId, chapterUrl) != null) return

        viewModelScope.launch(Dispatchers.IO) {
            val sourceManager = Injekt.get<SourceManager>()
            sourceManager.isInitialized.first { it }
            val source = sourceId?.let { sourceManager.get(it) } ?: return@launch
            try {
                val decodedPair = decodeMangaChapterUrl(chapterUrl)
                val rawUrl = decodedPair?.second ?: chapterUrl
                val sChapter = SChapter.create().apply {
                    url = rawUrl
                    name = chapterNames.getOrNull(targetIdx) ?: "Chapter ${targetIdx + 1}"
                }
                val rawPageList = source.getPageList(sChapter)
                val pageList = rawPageList.mapIndexed { i, p -> Page(i, p.url, p.imageUrl) }
                MangaPageListCache.put(sourceId, chapterUrl, pageList)
            } catch (_: Throwable) {
                // Best-effort prewarm
            }
        }
    }

    fun loadChapter(chapterIndex: Int, targetPageIndex: Int = 0) {
        val currentState = _uiState.value
        val urls = currentState.chapterUrls

        if (chapterIndex !in urls.indices) {
            _uiState.value = currentState.copy(
                isLoading = false,
                error = "Chapter not found"
            )
            com.lorelight.companion.CompanionBus.onLoadFailed()
            return
        }

        _uiState.value = currentState.copy(
            currentChapterIndex = chapterIndex,
            activeChapterIndex = chapterIndex,
            currentPageIndex = targetPageIndex,
            isLoading = true,
            error = null,
            // Deliberate jump: let the reader re-anchor the scroll position once.
            jumpToken = currentState.jumpToken + 1
        )

        // Opening the SAME chapter again and again usually means the reader
        // lost your place. The bus counts it; he reacts on the fourth.
        com.lorelight.companion.CompanionBus.noteChapterOpened(
            currentState.novel?.id,
            chapterIndex
        )

        shiftWindowTo(chapterIndex)
    }

    private fun shiftWindowTo(centerIndex: Int) {
        val urls = _uiState.value.chapterUrls
        if (urls.isEmpty()) return
        val newWindow = computeWindow(urls.size, centerIndex)

        val newIndices = newWindow.allIndices()
        val oldIndices = currentWindow.allIndices()

        // Ordering rule: create every chapter of the new window BEFORE any
        // unref() on dropped chapters, so a chapter present in both windows can
        // never be released mid-shift.
        //
        // REF-COUNT LEAK FIX. This used to call ref() on all five window members
        // on EVERY shift, while unref() only ever ran once per chapter, when it
        // was dropped. refCount therefore climbed with every window move and
        // could never fall back to zero, so chapterCache released nothing and
        // every 250-page list stayed in memory for the whole session. One
        // reference is now taken at creation and released once on drop, which is
        // the rule ensureNextChapterLoading() already follows.
        for (idx in newIndices) {
            var created = false
            val ch = chapterCache.getOrPut(idx) {
                created = true
                MangaChapter(
                    chapterId = "ch_$idx",
                    chapterIndex = idx,
                    chapterName = _uiState.value.chapterNames.getOrElse(idx) { "Chapter ${idx + 1}" },
                    chapterUrl = urls[idx]
                )
            }
            if (created) ch.ref()
        }

        val droppedIndices = oldIndices.filter { it !in newIndices }
        for (idx in droppedIndices) {
            val oldCh = chapterCache[idx]
            if (oldCh != null &&
                oldCh.chapterIndex != centerIndex &&
                oldCh.chapterIndex != centerIndex + 1 &&
                oldCh.chapterIndex != centerIndex - 1 &&
                canDropChapter(oldCh.chapterId, visibleChapterIds)
            ) {
                oldCh.unref { releasedCh ->
                    chapterCache.remove(releasedCh.chapterIndex)
                }
            }
        }

        currentWindow = newWindow

        startWindowFetch(newWindow)

        updateFeedAndState()
    }

    /**
     * Resolve the window's page lists in strict reading priority instead of
     * firing all five at once.
     *
     * The old code looped over the whole window and called fetchChapterContent()
     * on every member, so opening chapter 67 immediately issued FIVE concurrent
     * getPageList() calls -- 65, 66, 67, 68, 69 -- which then fought each other
     * for the same OkHttp dispatcher and the same per-source rate limiter. The
     * one chapter actually on screen had no priority over the four invisible
     * ones, and since updateFeedAndState() renders nothing until the CURRENT
     * chapter is loaded, the reader sat on a spinner while bandwidth went to
     * chapters the reader could not even see. That is the "jump to a later
     * chapter takes hella time" report.
     *
     * Now the current chapter is fetched and awaited first, and the neighbours
     * queue up behind it in the order they are likely to be needed. This mirrors
     * mihon's HttpPageLoader, which explicitly ranks adjacent prefetch BELOW the
     * pages being read.
     */
    private fun startWindowFetch(window: MangaWindow) {
        windowFetchJob?.cancel()
        windowFetchJob = viewModelScope.launch {
            val ordered = listOfNotNull(
                window.currIndex,
                window.nextIndex,
                window.prevIndex,
                window.next2Index,
                window.prev2Index
            )
            for ((rank, idx) in ordered.withIndex()) {
                val ch = chapterCache[idx] ?: continue
                val alreadyLoaded = ch.state is MangaChapterState.Loaded
                if (!alreadyLoaded && ch.loadJob?.isActive != true) {
                    fetchChapterContent(ch)
                }
                // Gate the queue on the chapter being read. Everything after
                // rank 0 is speculative and must not compete with it.
                if (rank == 0) {
                    ch.loadJob?.join()
                }
            }
        }
    }

    private fun fetchChapterContent(ch: MangaChapter) {
        val sourceId = _uiState.value.sourceId

        // INSTANT OPEN: if this chapter's page list was already resolved
        // this session, reuse it synchronously -- no network, no Loading
        // state -- so re-opening the reader shows pages immediately with no
        // transient loading screen.
        val cachedPages = MangaPageListCache.get(sourceId, ch.chapterUrl)
        if (cachedPages != null) {
            ch.state = MangaChapterState.Loaded(cachedPages.map { MangaReaderPage(it.index, it) })
            updateFeedAndState()
            return
        }

        ch.state = MangaChapterState.Loading

        ch.loadJob = viewModelScope.launch(Dispatchers.IO) {
            val sourceManager = Injekt.get<SourceManager>()
            sourceManager.isInitialized.first { it }
            val source = if (sourceId != null) sourceManager.get(sourceId) else null

            if (source == null) {
                withContext(Dispatchers.Main) {
                    ch.state = MangaChapterState.Error(Exception("Extension not installed"))
                    updateFeedAndState()
                }
                return@launch
            }

            try {
                val encodedUrl = ch.chapterUrl
                val decodedPair = decodeMangaChapterUrl(encodedUrl)
                val rawUrl = decodedPair?.second ?: encodedUrl

                val sChapter = SChapter.create().apply {
                    url = rawUrl
                    name = ch.chapterName
                }

                val rawPageList = source.getPageList(sChapter)
                val pageList = rawPageList.mapIndexed { index, page ->
                    Page(index, page.url, page.imageUrl)
                }
                MangaPageListCache.put(sourceId, ch.chapterUrl, pageList)
                val readerPages = pageList.map { MangaReaderPage(it.index, it) }

                withContext(Dispatchers.Main) {
                    ch.state = MangaChapterState.Loaded(readerPages)
                    updateFeedAndState()
                }
            } catch (t: Throwable) {
                if (t is kotlinx.coroutines.CancellationException) throw t
                withContext(Dispatchers.Main) {
                    ch.state = MangaChapterState.Error(t)
                    updateFeedAndState()
                }
            }
        }
    }

    private fun updateFeedAndState() {
        val currIdx = currentWindow.currIndex
        val currCh = chapterCache[currIdx]
        val currState = currCh?.state

        if (currState is MangaChapterState.Error && currentWindow.prevIndex == null && currentWindow.nextIndex == null) {
            _uiState.value = _uiState.value.copy(
                isLoading = false,
                error = currState.error.localizedMessage ?: "Failed to load chapter"
            )
            com.lorelight.companion.CompanionBus.onLoadFailed()
            return
        }

        val currLoaded = (currState as? MangaChapterState.Loaded)?.let {
            LoadedChapter(currCh.chapterId, currCh.chapterIndex, currCh.chapterName, it.pages.map { p -> p.page })
        }

        if (currLoaded != null) {
            val prevCh = currentWindow.prevIndex?.let { chapterCache[it] }
            val prevLoaded = (prevCh?.state as? MangaChapterState.Loaded)?.let {
                LoadedChapter(prevCh.chapterId, prevCh.chapterIndex, prevCh.chapterName, it.pages.map { p -> p.page })
            }

            val nextCh = currentWindow.nextIndex?.let { chapterCache[it] }
            val nextLoaded = (nextCh?.state as? MangaChapterState.Loaded)?.let {
                LoadedChapter(nextCh.chapterId, nextCh.chapterIndex, nextCh.chapterName, it.pages.map { p -> p.page })
            }

            val totalChapters = _uiState.value.chapterUrls.size
            val hasNext = currIdx < totalChapters - 1
            val hasPrev = currIdx > 0
            val nextIdx = if (hasNext) currIdx + 1 else null
            val prevIdx = if (hasPrev) currIdx - 1 else null
            val nextName = nextIdx?.let { _uiState.value.chapterNames.getOrNull(it) }
            val prevName = prevIdx?.let { _uiState.value.chapterNames.getOrNull(it) }

            val feed = buildFeedItems(
                prev = prevLoaded,
                curr = currLoaded,
                next = nextLoaded,
                forceTransition = true,
                hasNextChapter = hasNext,
                hasPrevChapter = hasPrev,
                nextChapterName = nextName,
                prevChapterName = prevName,
                nextChapterIndex = nextIdx,
                prevChapterIndex = prevIdx
            )

            val currentPages = currLoaded.pages
            val clampedPageIndex = if (currentPages.isNotEmpty()) {
                _uiState.value.currentPageIndex.coerceIn(0, currentPages.size - 1)
            } else {
                0
            }

            _uiState.value = _uiState.value.copy(
                feedItems = feed,
                pages = currentPages,
                currentPageIndex = clampedPageIndex,
                isLoading = false,
                error = null
            )
        }
    }

    fun onActivePageChanged(chapterIndex: Int, pageIndex: Int) {
        val state = _uiState.value

        // TELEPORT GUARD.
        //
        // Organic scrolling can only ever cross into the chapter immediately
        // before or after the one being read: the feed holds prev/curr/next and
        // nothing else, so no scroll can legitimately report a chapter three or
        // eight positions away. A report like that only happens when a tracked
        // position was resolved against a feed that had already been rebuilt
        // underneath it. Acting on it re-centres the window, drops the chapter
        // the reader is actually on, and throws them somewhere else entirely --
        // the "I was on 5 and suddenly I am on 8" jump.
        //
        // Deliberate jumps never arrive here: loadChapter() sets
        // activeChapterIndex itself before any tracking runs.
        val active = state.activeChapterIndex
        if (active >= 0 && chapterIndex >= 0) {
            val distance = if (chapterIndex > active) chapterIndex - active else active - chapterIndex
            if (distance > 1) return
        }

        if (state.activeChapterIndex == chapterIndex && state.currentPageIndex == pageIndex) {
            // Even if active page index is unchanged, ensure next chapter is loading
            ensureNextChapterLoading(chapterIndex)
            return
        }

        val chapterChanged = state.activeChapterIndex != chapterIndex
        _uiState.value = state.copy(
            activeChapterIndex = chapterIndex,
            currentChapterIndex = chapterIndex,
            currentPageIndex = pageIndex
        )

        if (chapterChanged) {
            // Reading organically forward (continuous/webtoon mode) means the
            // chapter you just left was finished. mihon marks it read at that
            // point rather than waiting for the final page to be the "active"
            // one, which in a continuous scroll it often never is.
            val previousIndex = state.activeChapterIndex
            if (chapterIndex > previousIndex && previousIndex >= 0) {
                state.novel?.let { n ->
                    com.lorelight.manga.progress.MangaReadProgress.markRead(appContext, n, previousIndex)
                    // New backend, same moment: you read it to the end and
                    // scrolled on past it, so it is finished.
                    com.lorelight.data.chapters.ChapterReadStore.markCompleted(appContext, n, previousIndex)
                    // This is the honest "you finished a chapter" moment: you
                    // read it to the end and scrolled on past it. The bus also
                    // works out whether that was the last chapter in the book.
                    com.lorelight.companion.CompanionBus.onChapterFinished(n, previousIndex)
                }
            }
            state.novel?.let { n ->
                com.lorelight.data.chapters.ChapterReadStore.setCurrent(appContext, n, chapterIndex)
            }
            shiftWindowTo(chapterIndex)
        }

        // mihon only preloads the next chapter once you are near the end of
        // this one. This used to run on EVERY page change, so landing on page 1
        // of a 50-page chapter immediately fired a getPageList for the next
        // chapter -- a wasted round trip competing with the images actually
        // being waited on.
        val pageCount = _uiState.value.pages.size
        if (pageCount <= 0 || shouldPreloadNext(pageIndex, pageCount)) {
            ensureNextChapterLoading(chapterIndex)
        }

        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(500)
            saveProgress()
        }
    }

    fun ensureNextChapterLoading(currentIdx: Int? = null) {
        val curr = currentIdx ?: _uiState.value.activeChapterIndex
        val nextIdx = curr + 1
        val urls = _uiState.value.chapterUrls
        if (nextIdx in urls.indices) {
            var created = false
            val nextCh = chapterCache.getOrPut(nextIdx) {
                created = true
                MangaChapter(
                    chapterId = "ch_$nextIdx",
                    chapterIndex = nextIdx,
                    chapterName = _uiState.value.chapterNames.getOrElse(nextIdx) { "Chapter ${nextIdx + 1}" },
                    chapterUrl = urls[nextIdx]
                )
            }
            // Only the creating call takes a reference. This used to ref() on
            // EVERY page change, so refCount grew without bound and unref() could
            // never reach zero -- chapters were never released and memory climbed
            // the longer you read.
            if (created) nextCh.ref()
            if (nextCh.state !is MangaChapterState.Loaded && (nextCh.state is MangaChapterState.Wait || nextCh.loadJob == null || nextCh.loadJob?.isActive != true || nextCh.state is MangaChapterState.Error)) {
                fetchChapterContent(nextCh)
            }
        }
    }

    fun updateVisibleChapterIds(visibleIds: Set<String>) {
        // Called on every tracked page change; skip the churn when the set
        // on screen has not actually moved.
        if (visibleChapterIds == visibleIds) return
        visibleChapterIds.clear()
        visibleChapterIds.addAll(visibleIds)
    }

    fun onPageChanged(pageIndex: Int) {
        onActivePageChanged(_uiState.value.activeChapterIndex, pageIndex)
    }

    fun nextChapter() {
        val state = _uiState.value
        if (state.activeChapterIndex < state.chapterUrls.size - 1) {
            loadChapter(state.activeChapterIndex + 1, targetPageIndex = 0)
        } else {
            _uiState.value = state.copy(toastMessage = "Already at the last chapter")
        }
    }

    fun previousChapter() {
        val state = _uiState.value
        if (state.activeChapterIndex > 0) {
            loadChapter(state.activeChapterIndex - 1, targetPageIndex = 0)
        } else {
            _uiState.value = state.copy(toastMessage = "Already at the first chapter")
        }
    }

    fun clearToast() {
        _uiState.value = _uiState.value.copy(toastMessage = null)
    }

    fun saveProgress() {
        val state = _uiState.value
        val novel = state.novel ?: return
        val currentChapterName = state.chapterNames.getOrNull(state.currentChapterIndex) ?: novel.currentChapter
        val pageIdx = state.currentPageIndex

        // Per-chapter position + auto-complete on the last page (mihon parity).
        // This writes ONLY this chapter's read-state columns, so it stays off the
        // library-rewrite path that ProgressStore exists to avoid.
        com.lorelight.manga.progress.MangaReadProgress.setPageProgress(
            context = appContext,
            novel = novel,
            chapterIndex = state.currentChapterIndex,
            pageIndex = pageIdx,
            pageCount = state.pages.size
        )
        // The list's own backend. Keyed by chapter URL, so a new chapter
        // arriving at the top of the source list cannot move this mark.
        com.lorelight.data.chapters.ChapterReadStore.notePage(
            context = appContext,
            novel = novel,
            chapterIndex = state.currentChapterIndex,
            pageIndex = pageIdx,
            pageCount = state.pages.size
        )

        viewModelScope.launch(Dispatchers.IO) {
            // Phase 1B: was updateNovel(), which rewrote every row in the library
            // on EVERY page turn. Now writes a single reading_progress row.
            NovelImportManager.updateNovelProgress(appContext, novel.id) { current ->
                current.copy(
                    currentChapter = currentChapterName,
                    currentChapterIndex = state.currentChapterIndex,
                    currentParagraphIndex = pageIdx,
                    currentMangaPageIndex = pageIdx,
                    lastReadTimestamp = System.currentTimeMillis()
                )
            }
        }
    }

    /** Explicit "mark this chapter read" for the reader's chapter menu. */
    fun markChapterRead(chapterIndex: Int, read: Boolean = true) {
        val novel = _uiState.value.novel ?: return
        com.lorelight.manga.progress.MangaReadProgress.setRead(
            appContext,
            novel,
            listOf(chapterIndex),
            read
        )
        com.lorelight.data.chapters.ChapterReadStore.setCompleted(
            appContext,
            novel,
            listOf(chapterIndex),
            read
        )
    }

    fun onDismiss() {
        saveJob?.cancel()
        saveProgress()
    }
}
