package com.lorelight.ui.reader

import com.lorelight.R
import androidx.compose.ui.res.stringResource

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.data.model.Novel

@Composable
fun ReaderToolbar(
    activeNovel: Novel?,
    chapters: List<String>,
    activeChapterIndex: Int,
    readerMode: String,
    sleepTimerMinutes: Int?,
    isAutoScrollActive: Boolean,
    readerHighlightColor: Color,
    onClose: () -> Unit,
    onSetSleepTimer: (Int?) -> Unit,
    onToggleChapters: () -> Unit,
    onToggleAutoScroll: () -> Unit,
    onOpenSettings: () -> Unit
) {
    var showSleepTimerMenu by remember { mutableStateOf(false) }

    // REVERTED to the original bar, by request: a solid black slab that runs
    // all the way up behind the status bar. Because the slab is always black,
    // the ink is pinned back to white rather than following the theme.
    //
    // The inset lives on the ROW, not on the slab. That is the whole trick:
    // the black fills the status-bar strip, while the icons and the title sit
    // below the clock instead of under it.
    val barInk = Color.White

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Black)
    ) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(start = 8.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        IconButton(
            onClick = onClose,
            modifier = Modifier.size(36.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Close",
                tint = barInk,
                modifier = Modifier.size(20.dp)
            )
        }
        
        Box(
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 0.dp)
        ) {
            val activeChapterName = chapters.getOrNull(activeChapterIndex) ?: (activeNovel?.title ?: "Reading")
            Text(
                text = activeChapterName,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = barInk
            )
        }

        Row(
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconButton(
                onClick = onToggleChapters,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MenuBook,
                    contentDescription = "Contents",
                    tint = barInk,
                    modifier = Modifier.size(20.dp)
                )
            }
            if (readerMode == "Read") {
                IconButton(
                    onClick = onToggleAutoScroll,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Autoscroll Panel",
                        tint = if (isAutoScrollActive) readerHighlightColor else barInk,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            if (readerMode == "Listen") {
                Box {
                    IconButton(
                        onClick = { showSleepTimerMenu = true },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccessTime,
                                contentDescription = "Sleep timer",
                                tint = if (sleepTimerMinutes != null) readerHighlightColor else barInk,
                                modifier = Modifier.size(18.dp)
                            )
                            if (sleepTimerMinutes != null) {
                                Text(
                                    text = "${sleepTimerMinutes}m",
                                    color = readerHighlightColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                    DropdownMenu(
                        expanded = showSleepTimerMenu,
                        onDismissRequest = { showSleepTimerMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.reader_timer_off)) },
                            onClick = {
                                onSetSleepTimer(null)
                                showSleepTimerMenu = false
                            },
                            trailingIcon = { if (sleepTimerMinutes == null) Icon(Icons.Default.Check, null) }
                        )
                        listOf(15, 30, 45, 60).forEach { mins ->
                            DropdownMenuItem(
                                text = { Text("$mins minutes") },
                                onClick = {
                                    onSetSleepTimer(mins)
                                    showSleepTimerMenu = false
                                },
                                trailingIcon = { if (sleepTimerMinutes == mins) Icon(Icons.Default.Check, null) }
                            )
                        }
                    }
                }
            }
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = barInk,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
    }
}
