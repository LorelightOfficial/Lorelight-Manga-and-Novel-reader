package com.lorelight.data.model

/**
 * A saved text highlight.
 *
 * This used to live in com.lorelight.ui.reader, which meant NovelPreferences -
 * a storage object in the data layer - declared
 * List<com.lorelight.ui.reader.Highlight> and reached UP into the ui layer for
 * a type it persists. That inversion is the whole reason the highlight call
 * sites could not be routed through LibraryRepository: wrapping them would
 * have dragged a ui type into the new surface's signatures.
 *
 * Nothing here is Compose or Android - it is a plain data class - so the move
 * costs nothing. The Offset import that sat beside it in ReaderState.kt
 * belongs to WordPosition, not to this.
 *
 * chapterTitle, not a chapter index, is the identity on purpose. An index
 * shifts whenever a source reorders or inserts chapters, which is the same
 * reason ChapterReadStore keys on chapter URL rather than on position.
 */
data class Highlight(
    val id: String = java.util.UUID.randomUUID().toString(),
    val novelId: String,
    val chapterTitle: String,
    val startWordIdx: Int,
    val endWordIdx: Int,
    val colorHex: String,
    val createdTimestamp: Long = System.currentTimeMillis()
)
