package com.lorelight.manga.ui

import coil.key.Keyer
import coil.request.Options
import tachiyomi.domain.manga.model.MangaCover

class MangaCoverKeyer : Keyer<MangaCover> {
    override fun key(data: MangaCover, options: Options): String? {
        val url = data.url ?: return null
        return "$url;${data.lastModified}"
    }
}
