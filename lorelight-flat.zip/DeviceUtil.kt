package eu.kanade.tachiyomi.util.system

import android.os.Build

object DeviceUtil {

    val isMiui: Boolean by lazy {
        !getSystemProperty("ro.miui.ui.version.name").isNullOrEmpty()
    }

    val isSamsung: Boolean by lazy {
        Build.MANUFACTURER.equals("samsung", ignoreCase = true)
    }

    /**
     * Package names of "browsers" that should not be treated as a usable default
     * browser when resolving the user's default browser.
     */
    val invalidDefaultBrowsers = listOf(
        "android",
        "com.huawei.android.internal.app",
        "com.zui.resolver",
    )

    private fun getSystemProperty(key: String?): String? {
        return try {
            Class.forName("android.os.SystemProperties")
                .getDeclaredMethod("get", String::class.java)
                .invoke(null, key) as? String
        } catch (e: Exception) {
            null
        }
    }
}
