/*
 * =============================================================================
 * CompanionGovernor.kt - decides whether he speaks at all, and about what.
 * Package: com.lorelight.companion
 *
 * This is the file that protects the user from the character.
 *
 * Several things can be true at the same moment: you came back after a week,
 * AND you finished a chapter, AND it is 1am. He gets ONE line. So candidates
 * are ranked, the best one is taken, and every other candidate is DISCARDED -
 * never queued, never saved for later. A queue is what turns a companion into
 * a backlog of notifications.
 *
 * ORDER OF OPERATIONS (deliberate, and the reason this file is small):
 *
 *   1. Drop candidates that are structurally blocked - the daily cap, the
 *      global cooldown, their own cooldown, their once-per-day slot, or a
 *      surface they are not allowed to speak on.
 *   2. Take the single best-ranked survivor.
 *   3. Roll its dice ONCE.
 *   4. If the roll fails, he says nothing at all this moment. We do NOT fall
 *      through to a lower-ranked candidate - if the big news did not make him
 *      speak, small talk should not either.
 *
 * WHAT CONSUMES WHAT (this distinction matters, and is easy to get wrong):
 *
 *   - Being discarded at step 1 consumes NOTHING. An event that lost on rank
 *     must not be punished for it, or a busy day would silently burn every
 *     once-per-day slot and the app would go quiet for no visible reason.
 *   - Running the roll at step 3 consumes the event's own cooldown and its
 *     once-per-day slot, win or lose. It got its turn.
 *   - Only a line that actually REACHES THE SCREEN consumes the daily cap and
 *     resets the global cooldown. A grant thrown away by the stillness gate
 *     was never heard, so it must not count against the day.
 * =============================================================================
 */
package com.lorelight.companion

import java.util.Calendar
import kotlin.random.Random

/** Where the user is right now. Some lines are only allowed while browsing. */
enum class CompanionSurface { BROWSE, READING }

/** One thing the detector noticed, with whatever values its line may need. */
class Candidate(
    val event: CompanionEvent,
    val params: LineParams = LineParams()
)

class CompanionGovernor(
    private val store: CompanionStore,
    private val random: Random = Random.Default
) {

    /**
     * Picks at most one event to speak about.
     *
     * @param now      current wall clock.
     * @param surface  where the user is, for browse-only rules.
     * @return the winning candidate, or null for silence.
     */
    fun choose(
        candidates: List<Candidate>,
        now: Long,
        surface: CompanionSurface
    ): Candidate? {
        if (candidates.isEmpty()) return null

        rolloverDayIfNeeded(now)

        // Global gates first: if he cannot speak at all, nothing is consumed.
        if (spokenToday(now) >= CompanionPolicy.effectiveDailyCap) return null
        if (!globalCooldownElapsed(now)) return null

        // Step 1 + 2: best-ranked structurally allowed candidate.
        val winner = candidates
            .filter { allowed(it.event, now, surface) }
            .minByOrNull { it.event.rank }
            ?: return null

        // Step 3: its one and only roll. Consumed either way.
        noteRolled(winner.event, now)

        val chance = CompanionPolicy.effectiveChance(winner.event)
        if (random.nextFloat() > chance) return null

        return winner
    }

    /**
     * Called ONLY once a line has actually appeared on screen. This is what
     * starts the global cooldown and counts against the daily cap.
     */
    fun noteSpoken(now: Long) {
        rolloverDayIfNeeded(now)
        store.putLong(LAST_SPOKEN_AT, now)
        store.putInt(SPOKEN_TODAY, spokenToday(now) + 1)
    }

    /* --- structural gates ------------------------------------------------- */

    private fun allowed(event: CompanionEvent, now: Long, surface: CompanionSurface): Boolean {
        val rule = CompanionPolicy.ruleFor(event)

        if (rule.browseOnly && surface != CompanionSurface.BROWSE) return false

        val cooldown = CompanionPolicy.effectiveCooldown(event)
        if (cooldown > 0L) {
            val last = store.getLong(rolledAtKey(event), 0L)
            if (last > 0L && now - last < cooldown) return false
        }

        if (rule.oncePerDay && rolledToday(event, now)) return false

        // The five arrival events share ONE slot between them: coming back
        // after a week and coming back the same day are the same moment
        // described two ways, so only one of them may ever speak in a day.
        if (event.isArrival && CompanionPolicy.ARRIVAL_ONCE_PER_DAY) {
            if (store.getInt(ARRIVAL_DAY, -1) == dayIndex(now)) return false
        }

        return true
    }

    private fun globalCooldownElapsed(now: Long): Boolean {
        val last = store.getLong(LAST_SPOKEN_AT, 0L)
        if (last <= 0L) return true
        return now - last >= CompanionPolicy.effectiveGlobalCooldown
    }

    /* --- bookkeeping ------------------------------------------------------ */

    private fun noteRolled(event: CompanionEvent, now: Long) {
        store.putLong(rolledAtKey(event), now)
        store.putInt(rolledDayKey(event), dayIndex(now))
        if (event.isArrival) store.putInt(ARRIVAL_DAY, dayIndex(now))
    }

    private fun rolledToday(event: CompanionEvent, now: Long): Boolean =
        store.getInt(rolledDayKey(event), -1) == dayIndex(now)

    fun spokenToday(now: Long): Int {
        rolloverDayIfNeeded(now)
        return store.getInt(SPOKEN_TODAY, 0)
    }

    /** Resets the day counter when the calendar day changes. */
    private fun rolloverDayIfNeeded(now: Long) {
        val today = dayIndex(now)
        if (store.getInt(COUNTER_DAY, -1) != today) {
            store.putInt(COUNTER_DAY, today)
            store.putInt(SPOKEN_TODAY, 0)
        }
    }

    /**
     * A stable local-calendar day number.
     *
     * Wall-clock division would roll over at UTC midnight, which for this
     * user is the middle of the evening - so "once per day" has to be the
     * user's day, in the user's timezone.
     */
    private fun dayIndex(now: Long): Int {
        val cal = Calendar.getInstance()
        cal.timeInMillis = now
        return cal.get(Calendar.YEAR) * 1000 + cal.get(Calendar.DAY_OF_YEAR)
    }

    private fun rolledAtKey(event: CompanionEvent) = "rolled.at.${event.key}"
    private fun rolledDayKey(event: CompanionEvent) = "rolled.day.${event.key}"

    companion object {
        private const val LAST_SPOKEN_AT = "spoken.at"
        private const val SPOKEN_TODAY = "spoken.count"
        private const val COUNTER_DAY = "spoken.day"
        private const val ARRIVAL_DAY = "arrival.day"
    }
}
