/*
 * =============================================================================
 * CompanionStore.kt - the companion's only memory.
 * Package: com.lorelight.companion
 *
 * A tiny key/value contract so every other companion file can be tested
 * without Android. The real implementation is SharedPreferences.
 *
 * DataStore is deliberately NOT used: this app has no DataStore dependency
 * and the companion must not add one.
 *
 * Every key is written with the "companion." prefix so companion state can
 * never collide with app settings, and can be wiped in one sweep.
 * =============================================================================
 */
package com.lorelight.companion

import android.content.Context
import android.content.SharedPreferences

interface CompanionStore {
    fun getString(key: String, default: String? = null): String?
    fun putString(key: String, value: String?)
    fun getLong(key: String, default: Long = 0L): Long
    fun putLong(key: String, value: Long)
    fun getInt(key: String, default: Int = 0): Int
    fun putInt(key: String, value: Int)
    fun getBoolean(key: String, default: Boolean = false): Boolean
    fun putBoolean(key: String, value: Boolean)
}

/** SharedPreferences-backed store. Cheap: one file, small values only. */
class PrefsCompanionStore(context: Context) : CompanionStore {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun k(key: String) = PREFIX + key

    override fun getString(key: String, default: String?): String? =
        prefs.getString(k(key), default)

    override fun putString(key: String, value: String?) {
        prefs.edit().putString(k(key), value).apply()
    }

    override fun getLong(key: String, default: Long): Long =
        prefs.getLong(k(key), default)

    override fun putLong(key: String, value: Long) {
        prefs.edit().putLong(k(key), value).apply()
    }

    override fun getInt(key: String, default: Int): Int =
        prefs.getInt(k(key), default)

    override fun putInt(key: String, value: Int) {
        prefs.edit().putInt(k(key), value).apply()
    }

    override fun getBoolean(key: String, default: Boolean): Boolean =
        prefs.getBoolean(k(key), default)

    override fun putBoolean(key: String, value: Boolean) {
        prefs.edit().putBoolean(k(key), value).apply()
    }

    companion object {
        const val FILE = "companion_prefs"
        const val PREFIX = "companion."
    }
}

/** In-memory store. Used by unit tests and by previews. */
class MemoryCompanionStore : CompanionStore {
    private val map = HashMap<String, Any?>()

    override fun getString(key: String, default: String?): String? =
        map[key] as? String ?: default

    override fun putString(key: String, value: String?) {
        if (value == null) map.remove(key) else map[key] = value
    }

    override fun getLong(key: String, default: Long): Long =
        map[key] as? Long ?: default

    override fun putLong(key: String, value: Long) {
        map[key] = value
    }

    override fun getInt(key: String, default: Int): Int =
        map[key] as? Int ?: default

    override fun putInt(key: String, value: Int) {
        map[key] = value
    }

    override fun getBoolean(key: String, default: Boolean): Boolean =
        map[key] as? Boolean ?: default

    override fun putBoolean(key: String, value: Boolean) {
        map[key] = value
    }
}
