package com.lorelight.ui.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.DeleteSweep
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.data.download.DownloadJobState
import com.lorelight.data.download.DownloadProgressBus
import kotlinx.coroutines.launch

// ───────────────────────── Filter enum ─────────────────────────

private enum class QueueFilter(val label: String) {
    ALL("All"), ACTIVE("Active"), COMPLETED("Done"), PAUSED("Paused"), FAILED("Failed")
}

private fun DownloadJobState.matches(f: QueueFilter) = when (f) {
    QueueFilter.ALL       -> true
    QueueFilter.ACTIVE    -> !isDone && !isPaused && !isFailed
    QueueFilter.COMPLETED -> isDone
    QueueFilter.PAUSED    -> isPaused && !isDone
    QueueFilter.FAILED    -> isFailed
}

// ───────────────────────── Entry point ─────────────────────────

/**
 * Download Manager — full redesign from scratch.
 *
 * [onOpenDetails] is called with the job's novelId when a completed
 * entry is tapped. Pass an empty lambda (the default) to disable navigation.
 * All DownloadProgressBus wiring is preserved.
 */
@Composable
fun DownloadsQueueScreen(
    onBack: () -> Unit,
    onOpenDetails: (novelId: String) -> Unit = {}
) {
    val queue = DownloadProgressBus.queue
    val scope   = rememberCoroutineScope()
    var filter  by remember { mutableStateOf(QueueFilter.ALL) }

    val visible by remember(queue, filter) { derivedStateOf { queue.filter { it.matches(filter) } } }
    val running by remember(queue) { derivedStateOf { queue.count { !it.isDone && !it.isPaused && !it.isFailed } } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        // ───────────────────────── Header ─────────────────────────
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.38f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(start = 8.dp, end = 8.dp, top = 10.dp, bottom = 10.dp)) {
                // Title row
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Close, "Close", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(20.dp))
                    }
                    Spacer(Modifier.width(4.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "Download Manager",
                                fontSize = 19.sp, fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (running > 0) LiveIndicator()
                        }
                        val total = queue.size
                        Text(
                            when {
                                total == 0   -> "No jobs queued"
                                running > 0  -> "$running running · $total total"
                                else         -> "$total job${if (total == 1) "" else "s"}"
                            },
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f)
                        )
                    }
                    // Global controls
                    if (queue.any { !it.isDone && !it.isFailed }) {
                        IconButton(onClick = { scope.launch { DownloadProgressBus.pauseAll() } }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.Pause, "Pause all", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
                        }
                    }
                    if (queue.isNotEmpty()) {
                        IconButton(onClick = { scope.launch { DownloadProgressBus.cancelAll() } }, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Outlined.DeleteSweep, "Cancel all", tint = MaterialTheme.colorScheme.error.copy(alpha = 0.68f), modifier = Modifier.size(20.dp))
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Filter pills
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(QueueFilter.entries) { f ->
                        val active = filter == f
                        val count  = if (f == QueueFilter.ALL) queue.size else queue.count { it.matches(f) }
                        val bg by animateColorAsState(
                            if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                            else MaterialTheme.colorScheme.surface.copy(alpha = 0.55f),
                            label = "fBg"
                        )
                        val bd by animateColorAsState(
                            if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
                            else MaterialTheme.colorScheme.outline.copy(alpha = 0.20f),
                            label = "fBd"
                        )
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(bg)
                                .border(1.dp, bd, CircleShape)
                                .clickable(role = Role.Button) { filter = f }
                                .padding(horizontal = 14.dp, vertical = 7.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text(
                                    f.label,
                                    fontSize = 12.sp,
                                    fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                                    color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (count > 0) {
                                    Text(
                                        "$count",
                                        fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                        color = if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.75f)
                                               else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.50f)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // ───────────────────────── Job list ─────────────────────────
        if (visible.isEmpty()) {
            EmptyQueueState(
                filter = filter,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.navigationBars),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(visible, key = { it.id }) { job ->
                    JobCard(
                        job           = job,
                        onPause       = { scope.launch { DownloadProgressBus.pauseJob(job.id) } },
                        onResume      = { scope.launch { DownloadProgressBus.resumeJob(job.id) } },
                        onCancel      = { scope.launch { DownloadProgressBus.cancelJob(job.id) } },
                        onRetry       = { scope.launch { DownloadProgressBus.retryJob(job.id) } },
                        onOpenDetails = onOpenDetails
                    )
                }
            }
        }
    }
}

// ───────────────────────── Job card ─────────────────────────

@Composable
private fun JobCard(
    job: DownloadJobState,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
    onOpenDetails: (novelId: String) -> Unit
) {
    val isActive    = !job.isDone && !job.isPaused && !job.isFailed
    val canNavigate = job.isDone && job.novelId.isNotEmpty()

    val cardBg = when {
        job.isDone   -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.20f)
        job.isFailed -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.16f)
        else         -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.34f)
    }
    val cardBd = when {
        job.isDone   -> MaterialTheme.colorScheme.outline.copy(alpha = 0.10f)
        job.isFailed -> MaterialTheme.colorScheme.error.copy(alpha = 0.25f)
        isActive     -> MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
        else         -> MaterialTheme.colorScheme.outline.copy(alpha = 0.14f)
    }

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = cardBg,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, cardBd, RoundedCornerShape(18.dp))
            .then(
                if (canNavigate) Modifier.clickable(role = Role.Button) { onOpenDetails(job.novelId) }
                else Modifier
            )
    ) {
        Column(Modifier.padding(14.dp)) {
            // Top row
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // Status icon
                Box(
                    modifier = Modifier.size(38.dp).clip(CircleShape).background(
                        when {
                            job.isDone   -> MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
                            job.isFailed -> MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
                            job.isPaused -> MaterialTheme.colorScheme.surfaceVariant
                            else         -> MaterialTheme.colorScheme.primary.copy(alpha = 0.13f)
                        }
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when {
                            job.isDone   -> Icons.Default.CheckCircle
                            job.isFailed -> Icons.Default.Error
                            job.isPaused -> Icons.Default.PauseCircle
                            else         -> Icons.Default.Downloading
                        },
                        contentDescription = null,
                        tint = when {
                            job.isDone   -> MaterialTheme.colorScheme.primary
                            job.isFailed -> MaterialTheme.colorScheme.error
                            job.isPaused -> MaterialTheme.colorScheme.onSurfaceVariant
                            else         -> MaterialTheme.colorScheme.primary
                        },
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Title + kind badge
                Column(Modifier.weight(1f)) {
                    Text(
                        job.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        // Kind badge
                        Text(
                            job.kind,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f))
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                        // Chapter count / item count
                        val doneItems  = job.items.count { it.isDone }
                        val totalItems = job.items.size
                        if (totalItems > 0) {
                            Text(
                                "$doneItems / $totalItems",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f)
                            )
                        }
                    }
                }

                // Navigate arrow for completed
                if (canNavigate) {
                    Icon(
                        Icons.Default.ChevronRight, null,
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.55f),
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Action buttons for non-done
                if (!job.isDone) {
                    if (job.isFailed) {
                        SmallIconBtn(Icons.Default.Refresh, "Retry", MaterialTheme.colorScheme.primary, onRetry)
                    } else if (job.isPaused) {
                        SmallIconBtn(Icons.Default.PlayArrow, "Resume", MaterialTheme.colorScheme.primary, onResume)
                    } else {
                        SmallIconBtn(Icons.Default.Pause, "Pause", MaterialTheme.colorScheme.onSurfaceVariant, onPause)
                    }
                    SmallIconBtn(Icons.Default.Cancel, "Cancel", MaterialTheme.colorScheme.error.copy(alpha = 0.70f), onCancel)
                }
            }

            // Progress bar for active / paused jobs
            if (!job.isDone && !job.isFailed) {
                val totalItems = job.items.size
                val doneItems  = job.items.count { it.isDone }
                val rawProg    = if (totalItems > 0) doneItems.toFloat() / totalItems else job.overallProgress
                val progress   by animateFloatAsState(rawProg.coerceIn(0f, 1f),
                    animationSpec = spring(stiffness = Spring.StiffnessLow), label = "prog")

                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress    = { progress },
                    modifier    = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                    color       = if (job.isPaused) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.40f)
                                  else MaterialTheme.colorScheme.primary,
                    trackColor  = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
                    strokeCap   = StrokeCap.Round
                )

                // Current item label
                val current = job.items.firstOrNull { !it.isDone && it.isDownloading }
                if (current != null) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        current.label, fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f),
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Error message
            if (job.isFailed && !job.errorMessage.isNullOrBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    job.errorMessage!!, fontSize = 11.sp, lineHeight = 15.sp,
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.80f)
                )
            }
        }
    }
}

// ───────────────────────── Empty state ─────────────────────────

@Composable
private fun EmptyQueueState(filter: QueueFilter, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = when (filter) {
                QueueFilter.FAILED    -> Icons.Default.Error
                QueueFilter.PAUSED    -> Icons.Default.PauseCircle
                QueueFilter.COMPLETED -> Icons.Default.CheckCircle
                else                  -> Icons.Default.CloudDownload
            },
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.28f),
            modifier = Modifier.size(56.dp)
        )
        Spacer(Modifier.height(14.dp))
        Text(
            when (filter) {
                QueueFilter.ALL       -> "No downloads yet"
                QueueFilter.ACTIVE    -> "Nothing downloading right now"
                QueueFilter.COMPLETED -> "No completed downloads"
                QueueFilter.PAUSED    -> "Nothing paused"
                QueueFilter.FAILED    -> "No failed jobs"
            },
            fontSize = 15.sp, fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f)
        )
        Spacer(Modifier.height(6.dp))
        Text(
            when (filter) {
                QueueFilter.ALL    -> "Start a download from a novel or manga page."
                QueueFilter.ACTIVE -> "Your active downloads appear here."
                else               -> "Change the filter above to see other jobs."
            },
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.38f)
        )
    }
}

// ───────────────────────── Small helpers ─────────────────────────

@Composable
private fun SmallIconBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, tint: androidx.compose.ui.graphics.Color, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(32.dp)) {
        Icon(icon, desc, tint = tint, modifier = Modifier.size(18.dp))
    }
}

/** Animated pulsing live indicator dot shown while downloads are running. */
@Composable
private fun LiveIndicator() {
    val pulse = rememberInfiniteTransition(label = "live")
    val alpha by pulse.animateFloat(
        0.4f, 1f,
        animationSpec = infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "a"
    )
    Box(
        modifier = Modifier.size(7.dp).clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary.copy(alpha = alpha))
    )
}
