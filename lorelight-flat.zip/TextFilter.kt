package com.lorelight.utils

import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject

data class Token(
    val raw: String,
    val isWord: Boolean,
    val wordIdx: Int
)

data class FilterRule(
    val id: String,
    val original: String,
    val replacement: String,
    val isVanish: Boolean,
    val scope: String, // "This Book" or "All Books"
    val bookId: String,
    val action: String = if (isVanish) TextFilter.ACTION_ERASE_TEXT else TextFilter.ACTION_REPLACE,
    val strictMatch: Boolean = false
)

object TextFilter {
    const val ACTION_REPLACE = "replace"
    const val ACTION_ERASE_TEXT = "erase_text"
    const val ACTION_ERASE_LINE = "erase_line"

    fun looksObfuscated(text: String): Boolean {
        val t = text.trim()
        if (t.isBlank()) return false
        val standardLowerDigits = t.lowercase(Locale.ROOT).filter { it.isLetterOrDigit() }
        val squashed = squash(t)
        if (squashed != standardLowerDigits) return true
        if (Regex("""\w[._\-,*\s]\w[._\-,*\s]\w""").containsMatchIn(t)) return true
        if (Regex("""(https?://|www\.|\.(com|net|org|co|io|me)\b|@\w)""", RegexOption.IGNORE_CASE).containsMatchIn(t)) return true
        return false
    }

    // Collapses separator tricks and lookalike characters so that
    // "F.r_e-e W e b N0vel" and "freewebnovel" become identical.
    fun squash(text: String): String {
        val sb = StringBuilder(text.length)
        for (ch in text) {
            // Drop invisible / zero-width characters outright
            if (ch == '\u200B' || ch == '\u200C' || ch == '\u200D' || ch == '\uFEFF' || ch == '\u00AD') continue
            val lower = ch.lowercaseChar()
            val mapped = when (lower) {
                '0' -> 'o'
                '1', '!', '|' -> 'l'
                '3' -> 'e'
                '4', '@' -> 'a'
                '5', '$' -> 's'
                '7' -> 't'
                '8' -> 'b'
                'à', 'á', 'â', 'ã', 'ä', 'å' -> 'a'
                'è', 'é', 'ê', 'ë' -> 'e'
                'ì', 'í', 'î', 'ï' -> 'i'
                'ò', 'ó', 'ô', 'õ', 'ö' -> 'o'
                'ù', 'ú', 'û', 'ü' -> 'u'
                else -> lower
            }
            if (mapped.isLetterOrDigit()) sb.append(mapped)
        }
        return sb.toString()
    }

    // True when this rule matches anywhere in the given line.
    // strictMatch rules compare squashed forms; normal rules stay case-insensitive literal.
    fun ruleMatchesLine(rule: FilterRule, line: String): Boolean {
        if (rule.original.isBlank()) return false
        return if (rule.strictMatch) {
            val needle = squash(rule.original)
            needle.isNotEmpty() && squash(line).contains(needle)
        } else {
            line.lowercase(Locale.ROOT)
                .contains(rule.original.lowercase(Locale.ROOT))
        }
    }

    fun activeRulesFor(
        rules: List<FilterRule>,
        currentBookId: String,
        currentBookTitle: String = ""
    ): List<FilterRule> {
        return rules.filter { rule ->
            rule.scope == "All Books" || (
                rule.scope == "This Book" && (
                    rule.bookId.isBlank() ||
                    currentBookId.isBlank() ||
                    rule.bookId.trim() == currentBookId.trim() ||
                    rule.bookId.trim().equals(currentBookTitle.trim(), ignoreCase = true)
                )
            )
        }
    }

    // Returns the indices of lines that should be erased entirely.
    // SAFETY BRAKE: if erase_line rules would remove more than 25% of the lines,
    // return an empty set instead — a rule that aggressive is almost certainly a mistake,
    // and silently gutting a chapter is far worse than leaving a promo line in.
    fun linesToErase(
        lines: List<String>,
        rules: List<FilterRule>,
        currentBookId: String,
        currentBookTitle: String = ""
    ): Set<Int> {
        val eraseRules = activeRulesFor(rules, currentBookId, currentBookTitle)
            .filter { it.action == ACTION_ERASE_LINE && it.original.isNotBlank() }
        if (eraseRules.isEmpty() || lines.isEmpty()) return emptySet()

        val hits = mutableSetOf<Int>()
        lines.forEachIndexed { idx, line ->
            if (line.isNotBlank() && eraseRules.any { ruleMatchesLine(it, line) }) hits.add(idx)
        }
        val limit = maxOf(1, (lines.size * 0.25).toInt())
        return if (hits.size > limit) emptySet() else hits
    }

    private fun buildStrictRegex(needle: String): Regex? {
        val squashed = squash(needle)
        if (squashed.isEmpty()) return null
        val sep = "[\\s\\._\\-\\u200B\\u200C\\u200D\\uFEFF\\u00AD]*"
        val sb = java.lang.StringBuilder()
        for (i in squashed.indices) {
            if (i > 0) sb.append(sep)
            val ch = squashed[i]
            val charClass = when (ch) {
                'a' -> "[aA4@àáâãäå]"
                'b' -> "[bB8]"
                'e' -> "[eE3èéêë]"
                'i' -> "[iI1!|ìíîï]"
                'l' -> "[lL1!|]"
                'o' -> "[oO0òóôõö]"
                's' -> "[sS5$]"
                't' -> "[tT7]"
                else -> Regex.escape(ch.toString())
            }
            sb.append(charClass)
        }
        return try {
            Regex(sb.toString(), RegexOption.IGNORE_CASE)
        } catch (e: Exception) {
            null
        }
    }

    fun applyRawStringRules(
        text: String,
        rules: List<FilterRule>,
        currentBookId: String,
        currentBookTitle: String = ""
    ): String {
        val activeRules = activeRulesFor(rules, currentBookId, currentBookTitle)
        if (activeRules.isEmpty()) return text

        // Sort rules by original text length descending so we replace longer phrases first!
        val sortedRules = activeRules.sortedByDescending { it.original.length }

        var result = text
        for (rule in sortedRules) {
            val originalNeedle = rule.original
            if (originalNeedle.isEmpty()) continue
            
            val replacement = when (rule.action) {
                ACTION_ERASE_LINE -> continue // handled at line level
                ACTION_ERASE_TEXT -> ""
                else -> rule.replacement
            }

            if (rule.strictMatch) {
                val regex = buildStrictRegex(originalNeedle)
                if (regex != null) {
                    result = regex.replace(result, replacement)
                } else {
                    result = replaceCaseInsensitive(result, originalNeedle, replacement)
                }
            } else {
                result = replaceCaseInsensitive(result, originalNeedle, replacement)
            }
        }
        return result
    }

    private fun replaceCaseInsensitive(source: String, target: String, replacement: String): String {
        if (source.isEmpty() || target.isEmpty()) return source
        val sb = StringBuilder()
        var lastIdx = 0
        val targetLower = target.lowercase(Locale.ROOT)
        val sourceLower = source.lowercase(Locale.ROOT)
        
        while (true) {
            val idx = sourceLower.indexOf(targetLower, lastIdx)
            if (idx == -1) {
                sb.append(source.substring(lastIdx))
                break
            }
            sb.append(source.substring(lastIdx, idx))
            sb.append(replacement)
            lastIdx = idx + target.length
        }
        return sb.toString()
    }

    fun tokenize(text: String, startWordIdx: Int): Pair<List<Token>, Int> {
        val tokens = mutableListOf<Token>()
        var currentWordIdx = startWordIdx
        var i = 0
        val len = text.length
        while (i < len) {
            val char = text[i]
            if (char.isLetterOrDigit()) {
                val start = i
                while (i < len && text[i].isLetterOrDigit()) {
                    i++
                }
                val word = text.substring(start, i)
                tokens.add(Token(raw = word, isWord = true, wordIdx = currentWordIdx))
                currentWordIdx++
            } else if (char.isWhitespace()) {
                val start = i
                while (i < len && text[i].isWhitespace()) {
                    i++
                }
                val space = text.substring(start, i)
                tokens.add(Token(raw = space, isWord = false, wordIdx = -1))
            } else {
                // Treats punctuations, symbols, and special characters as individual, fully selectable blocks
                val start = i
                while (i < len && !text[i].isLetterOrDigit() && !text[i].isWhitespace()) {
                    i++
                }
                val symbolGroup = text.substring(start, i)
                tokens.add(Token(raw = symbolGroup, isWord = true, wordIdx = currentWordIdx))
                currentWordIdx++
            }
        }
        return Pair(tokens, currentWordIdx)
    }

    fun applyRules(
        tokens: List<Token>,
        rules: List<FilterRule>,
        currentBookId: String,
        currentBookTitle: String = ""
    ): List<Token> {
        val activeRules = activeRulesFor(rules, currentBookId, currentBookTitle)
            .filter { it.action != ACTION_ERASE_LINE && it.original.isNotBlank() }
        if (activeRules.isEmpty()) return tokens

        // Helper to strip non-alphanumeric and lowercase
        fun standardize(word: String): String {
            return word.filter { it.isLetterOrDigit() }.lowercase(Locale.ROOT)
        }

        data class RulePhrase(
            val rule: FilterRule,
            val words: List<String>
        )

        val parsedRules = activeRules.map { rule ->
            // Tokenize rule's original string to support multi-word phrase matching!
            val ruleWords = rule.original.split(Regex("\\s+"))
                .map { standardize(it) }
                .filter { it.isNotEmpty() }
            RulePhrase(rule, ruleWords)
        }.filter { it.words.isNotEmpty() }

        // Sort by longest match phrase first for greedy correctness
        val sortedRules = parsedRules.sortedByDescending { it.words.size }

        val overriddenText = Array<String?>(tokens.size) { null }
        val hidden = BooleanArray(tokens.size) { false }

        var tIdx = 0
        while (tIdx < tokens.size) {
            var matchedRule: RulePhrase? = null
            var matchedTokenCount = 0

            for (rp in sortedRules) {
                val ruleWords = rp.words
                var wMatchCount = 0
                var tempTIdx = tIdx
                var ruleWordsIdx = 0

                while (tempTIdx < tokens.size && ruleWordsIdx < ruleWords.size) {
                    val tok = tokens[tempTIdx]
                    if (tok.isWord) {
                        val standTok = standardize(tok.raw)
                        if (standTok == ruleWords[ruleWordsIdx]) {
                            ruleWordsIdx++
                            wMatchCount++
                        } else {
                            break
                        }
                    }
                    tempTIdx++
                }

                if (ruleWordsIdx == ruleWords.size && wMatchCount == ruleWords.size) {
                    matchedRule = rp
                    matchedTokenCount = tempTIdx - tIdx
                    break
                }
            }

            if (matchedRule != null && matchedTokenCount > 0) {
                val rule = matchedRule.rule
                val isVanishAction = rule.action == ACTION_ERASE_TEXT || (rule.action.isBlank() && rule.isVanish)
                if (isVanishAction) {
                    for (i in tIdx until (tIdx + matchedTokenCount)) {
                        hidden[i] = true
                    }
                } else {
                    var firstWordTokLoc = -1
                    for (i in tIdx until (tIdx + matchedTokenCount)) {
                        if (tokens[i].isWord) {
                            if (firstWordTokLoc == -1) {
                                firstWordTokLoc = i
                            } else {
                                hidden[i] = true
                            }
                        } else {
                            if (firstWordTokLoc != -1) {
                                hidden[i] = true
                            }
                        }
                    }
                    if (firstWordTokLoc != -1) {
                        overriddenText[firstWordTokLoc] = rule.replacement
                    }
                }
                tIdx += matchedTokenCount
            } else {
                tIdx++
            }
        }

        val result = mutableListOf<Token>()
        for (i in tokens.indices) {
            val tok = tokens[i]
            if (hidden[i]) {
                result.add(tok.copy(raw = "", isWord = false, wordIdx = -1))
            } else {
                val over = overriddenText[i]
                if (over != null) {
                    result.add(tok.copy(raw = over))
                } else {
                    result.add(tok)
                }
            }
        }
        return result
    }
}
