package com.lorelight.browse.js

import android.content.Context
import android.webkit.CookieManager
import com.lorelight.crawler.CrawlerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Capabilities the QuickJS engine (JSPluginEngine) provides to the bridge.
 * All "post*" methods MUST hop onto the context's single JS thread, invoke the
 * matching JS global, and pump pending promise jobs. Implemented in JSPluginEngine.
 */
interface JsRuntimeHost {
    val scope: CoroutineScope
    fun postFetchResult(token: Int, rawJson: String)
    fun postFetchError(token: Int, message: String)
    fun postTimeout(id: Int)
}

/**
 * Kotlin functions exposed to JS as __native.* (fetch, storage, log, timers).
 * One instance per QuickJS context. Cheerio ops are wired separately (CheerioBridge).
 */
/**
 * Namespace for a plugin's private key/value storage.
 *
 * FIX A5: shared by JSBridge and PluginManager so install, use and uninstall
 * always agree on the file name, and so a hostile id cannot escape it.
 */
internal fun pluginStoragePrefsName(pluginId: String): String =
    "lorelight_plugin_storage_" + sanitizePluginId(pluginId)

/** Reduces a repo-supplied plugin id to a safe single file-name component. */
internal fun sanitizePluginId(pluginId: String): String {
    val cleaned = pluginId.filter { it.isLetterOrDigit() || it == '.' || it == '_' || it == '-' }
        .replace("..", "")
    return if (cleaned.isEmpty()) "unknown_plugin" else cleaned.take(100)
}

class JSBridge(
    private val appContext: Context,
    private val host: JsRuntimeHost,
    // FIX A5: the plugin that owns this bridge. Storage calls are pinned to it
    // instead of trusting the id supplied by the running script.
    private val ownerPluginId: String? = null
) {
    companion object {
        private val lastRequestAt = java.util.concurrent.ConcurrentHashMap<String, Long>()
        private val hostLocks = java.util.concurrent.ConcurrentHashMap<String, Mutex>()
        private const val MIN_HOST_INTERVAL_MS = 1200L // ~1 request / 1.2s per host

        private fun lockFor(host: String): Mutex = hostLocks.getOrPut(host) { Mutex() }
    }

    // FIX B11 + C17: keeps this bridge's WebView-backed cookie jar, but now
    // reuses the shared connection pool and the Cloudflare interceptor instead
    // of building a private client.
    private val client: OkHttpClient by lazy {
        com.lorelight.network.HttpClients.sharedBuilder()
            .cookieJar(WebViewCookieJar())
            .build()
    }

    fun log(msg: String) { BrowseDebugLog.log(msg) }

    private fun isSafeFetchUrl(urlStr: String): Boolean {
        return try {
            val uri = android.net.Uri.parse(urlStr) ?: return false
            val scheme = uri.scheme?.lowercase() ?: return false
            if (scheme != "http" && scheme != "https") return false
            val host = uri.host?.lowercase() ?: return false
            if (host == "localhost" || host == "127.0.0.1" || host == "::1" || host == "0.0.0.0") return false
            if (host.startsWith("10.") || host.startsWith("192.168.") || host.startsWith("169.254.")) return false
            if (host.matches(Regex("^172\\.(1[6-9]|2[0-9]|3[0-1])\\..*"))) return false
            true
        } catch (_: Exception) {
            false
        }
    }

    /** Called from the JS thread. Runs HTTP off-thread, delivers back via host. */
    fun fetch(url: String, initJson: String, token: Int) {
        if (!isSafeFetchUrl(url)) {
            host.postFetchError(token, "Security error: URL scheme or target host disallowed ($url)")
            return
        }
        host.scope.launch(Dispatchers.IO) {
            try {
                val init = try { JSONObject(initJson) } catch (e: Exception) { JSONObject() }
                val method = init.optString("method", "GET").uppercase()
                val builder = Request.Builder().url(url)

                var hasUA = false
                val headers = init.optJSONObject("headers")
                if (headers != null) {
                    val keys = headers.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        builder.header(k, headers.optString(k))
                        if (k.equals("User-Agent", true)) hasUA = true
                    }
                }
                if (!hasUA) builder.header("User-Agent", CrawlerEngine.MOBILE_UA)

                val bodyStr = if (init.has("body") && !init.isNull("body")) init.optString("body") else null
                val reqBody = if (method != "GET" && method != "HEAD") {
                    val ctRaw = headers?.optString("Content-Type")
                    val ct = if (ctRaw.isNullOrEmpty()) "text/plain; charset=utf-8" else ctRaw
                    (bodyStr ?: "").toRequestBody(ct.toMediaTypeOrNull())
                } else null
                builder.method(method, reqBody)

                val reqHost = builder.build().url.host
                lockFor(reqHost).withLock {
                    val now = System.currentTimeMillis()
                    val waitMs = (lastRequestAt[reqHost] ?: 0L) + MIN_HOST_INTERVAL_MS - now
                    if (waitMs > 0) delay(waitMs)
                    lastRequestAt[reqHost] = System.currentTimeMillis()
                }

                var attempts = 0
                val maxRetries = if (method == "GET" || method == "HEAD") 2 else 0
                var finalResp: okhttp3.Response? = null

                while (attempts <= maxRetries) {
                    val request = builder.build()
                    val response = client.newCall(request).execute()
                    if (response.code == 429 && attempts < maxRetries) {
                        val retryAfterHeader = response.header("Retry-After")
                        val retryAfterSeconds = retryAfterHeader?.toLongOrNull() ?: 5L
                        val sleepSeconds = retryAfterSeconds.coerceIn(1L, 20L)
                        response.close()
                        attempts++
                        BrowseDebugLog.log("HTTP 429 rate limited for $reqHost. Retrying attempt $attempts/$maxRetries after ${sleepSeconds}s...")
                        delay(sleepSeconds * 1000L)
                        lastRequestAt[reqHost] = System.currentTimeMillis()
                    } else {
                        finalResp = response
                        break
                    }
                }

                finalResp?.use { resp ->
                    val body = resp.body?.string() ?: ""
                    val headersObj = JSONObject()
                    for (name in resp.headers.names()) headersObj.put(name, resp.header(name) ?: "")
                    val raw = JSONObject()
                        .put("status", resp.code)
                        .put("url", resp.request.url.toString())
                        .put("headers", headersObj)
                        .put("body", body)
                    host.postFetchResult(token, raw.toString())
                }
            } catch (e: Exception) {
                host.postFetchError(token, e.message ?: e.toString())
            }
        }
    }

    fun setTimeoutNative(id: Int, delayMs: Long) {
        host.scope.launch {
            if (delayMs > 0) delay(delayMs)
            host.postTimeout(id)
        }
    }

    // ---- storage: namespaced SharedPreferences per plugin ----
    // FIX A5: every storage call used to take the plugin id straight from the
    // JS caller. A plugin could therefore read, overwrite or wipe ANY other
    // plugin's stored data (including its session cookies or tokens) simply by
    // passing a different id, and an id containing path characters escaped the
    // namespace altogether. The namespace is now pinned to the plugin that owns
    // this bridge, and sanitised in every case.
    private fun resolveNamespace(requested: String): String {
        val owner = ownerPluginId
        if (owner != null) {
            if (requested.isNotEmpty() && requested != owner) {
                log("storage: ignoring cross-plugin id '$requested' (owner=$owner)")
            }
            return pluginStoragePrefsName(owner)
        }
        return pluginStoragePrefsName(requested)
    }

    private fun storagePrefs(pluginId: String) =
        appContext.getSharedPreferences(resolveNamespace(pluginId), Context.MODE_PRIVATE)

    fun storageGet(pluginId: String, key: String): String? = storagePrefs(pluginId).getString(key, null)
    fun storageSet(pluginId: String, key: String, value: String) { storagePrefs(pluginId).edit().putString(key, value).apply() }
    fun storageDelete(pluginId: String, key: String) { storagePrefs(pluginId).edit().remove(key).apply() }
    fun storageClear(pluginId: String) { storagePrefs(pluginId).edit().clear().apply() }
    fun storageKeys(pluginId: String): String {
        val arr = JSONArray()
        storagePrefs(pluginId).all.keys.forEach { arr.put(it) }
        return arr.toString()
    }
}

/**
 * Bridges OkHttp cookies to android.webkit.CookieManager so cookies obtained by
 * "Open in WebView" (e.g. Cloudflare clearance) flow into plugin HTTP requests.
 */
private class WebViewCookieJar : CookieJar {
    private val cm: CookieManager? = try { CookieManager.getInstance() } catch (e: Exception) { null }

    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        val manager = cm ?: return
        if (cookies.isEmpty()) return
        val u = url.toString()
        for (c in cookies) manager.setCookie(u, c.toString())
        // Without an explicit flush, freshly-set cookies (e.g. Cloudflare
        // clearance from "Open in WebView") can be lost if the process dies
        // before Android's own periodic flush runs.
        try { manager.flush() } catch (_: Exception) {}
    }

    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        val manager = cm ?: return emptyList()
        val header = manager.getCookie(url.toString()) ?: return emptyList()
        val out = ArrayList<Cookie>()
        for (part in header.split(";")) {
            val c = Cookie.parse(url, part.trim())
            if (c != null) out.add(c)
        }
        return out
    }
}

/** Optional on-screen sink for JS logs (used by the temporary Gate 2 screen). Harmless in production (sink stays null). */
object BrowseDebugLog {
    @Volatile var sink: ((String) -> Unit)? = null
    fun log(msg: String) { android.util.Log.d("LorelightJS", msg); sink?.invoke(msg) }
}
