/*
 * =============================================================================
 * ShuffleBag.kt - draws lines without ever feeling like a random generator.
 * Package: com.lorelight.companion
 *
 * WHY THIS EXISTS
 *
 * Pure random repeats. With 8 lines in a pool, random picking gives you the
 * same line twice in a row about one time in eight - and that single repeat
 * is the exact moment the character stops feeling alive and starts feeling
 * like a string array. A shuffle bag makes that impossible: every line in a
 * pool is spoken once before any line is spoken again.
 *
 * The bag survives app restarts (it lives in CompanionStore), so closing and
 * reopening the app cannot be used - accidentally or deliberately - to replay
 * the same greeting.
 *
 * Across a refill it also refuses to hand back the line it just gave, so the
 * end of one cycle and the start of the next can never collide. That rule is
 * enforced from persisted state only, so it survives the process being killed.
 * =============================================================================
 */
package com.lorelight.companion

import kotlin.random.Random

class ShuffleBag(
    private val store: CompanionStore,
    private val random: Random = Random.Default
) {

    /**
     * Draws the next index in [0, size).
     *
     * @return the chosen index, or -1 when size <= 0.
     */
    fun draw(key: String, size: Int): Int {
        if (size <= 0) return -1

        val lastDrawn = store.getInt(lastKey(key), -1)

        if (size == 1) {
            store.putInt(lastKey(key), 0)
            return 0
        }

        var remaining = readRemaining(key, size)

        // Bag empty (or was never started, or the corpus changed size):
        // start a fresh cycle containing every index exactly once.
        if (remaining.isEmpty()) {
            remaining = ArrayList(size)
            for (i in 0 until size) remaining.add(i)
        }

        val index = pick(remaining, avoid = if (isFreshCycle(remaining, size)) lastDrawn else -1)
        remaining.remove(index)

        writeRemaining(key, remaining)
        store.putInt(lastKey(key), index)
        return index
    }

    /** Empties the bag so the next draw starts a fresh cycle. */
    fun reset(key: String) {
        store.putString(bagKey(key), null)
        store.putInt(lastKey(key), -1)
    }

    /* --- internals -------------------------------------------------------- */

    /** A cycle that still holds every index has not been drawn from yet. */
    private fun isFreshCycle(remaining: List<Int>, size: Int) = remaining.size == size

    /**
     * Uniform pick, optionally refusing one index.
     *
     * Refusing is only possible when something else is available; with a
     * single candidate we must return it rather than fail.
     */
    private fun pick(from: List<Int>, avoid: Int): Int {
        if (from.size == 1 || avoid < 0) return from[random.nextInt(from.size)]

        val avoidAt = from.indexOf(avoid)
        if (avoidAt < 0) return from[random.nextInt(from.size)]

        // Choose among size-1 candidates, then skip over the avoided slot.
        var slot = random.nextInt(from.size - 1)
        if (slot >= avoidAt) slot += 1
        return from[slot]
    }

    private fun readRemaining(key: String, size: Int): MutableList<Int> {
        val raw = store.getString(bagKey(key), null)
        val out = ArrayList<Int>(size)
        if (raw.isNullOrEmpty()) return out

        for (piece in raw.split(',')) {
            val n = piece.toIntOrNull() ?: continue
            // Guard against a corpus that grew or shrank since the last run,
            // and against duplicates from a partially written value.
            if (n in 0 until size && !out.contains(n)) out.add(n)
        }
        return out
    }

    private fun writeRemaining(key: String, remaining: List<Int>) {
        if (remaining.isEmpty()) {
            store.putString(bagKey(key), null)
            return
        }
        val sb = StringBuilder(remaining.size * 3)
        for ((i, n) in remaining.withIndex()) {
            if (i > 0) sb.append(',')
            sb.append(n)
        }
        store.putString(bagKey(key), sb.toString())
    }

    private fun bagKey(key: String) = "bag.$key"
    private fun lastKey(key: String) = "bag.$key.last"
}
