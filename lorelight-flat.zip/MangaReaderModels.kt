package com.lorelight.manga.reader

enum class MangaReadingMode { LONG_STRIP, PAGED_LTR, PAGED_RTL, PAGED_VERTICAL }
