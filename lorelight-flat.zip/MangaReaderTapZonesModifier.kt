package com.lorelight.manga.reader

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput

/**
 * Detects single-tap navigation zones over the reader content.
 *
 * A confirmed, unconsumed single tap is mapped to a [MangaNavRegion] via
 * [tapZoneFor] using the current [layout]/[invert]; the MENU region routes to
 * [onMenuTap] and every other region to [onRegionTap]. Taps are ignored while
 * a fling/scroll is still settling ([isScrollSettling]) and when the child
 * (e.g. a zoomed webtoon or a pinch) already consumed the gesture, so page
 * turns never fire mid-scroll or mid-zoom.
 */
fun Modifier.readerTapZones(
    enabled: Boolean,
    isScrollSettling: () -> Boolean,
    layout: MangaTapZoneLayout,
    invert: MangaTapInvert,
    onMenuTap: () -> Unit,
    onRegionTap: (MangaNavRegion) -> Unit,
): Modifier = this.pointerInput(enabled, layout, invert) {
    if (!enabled) return@pointerInput
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false)
        val up = waitForUpOrCancellation()
        if (up != null && !up.isConsumed) {
            if (isScrollSettling()) return@awaitEachGesture
            val region = tapZoneFor(up.position, size, layout, invert, enabled)
            if (region == MangaNavRegion.MENU) onMenuTap() else onRegionTap(region)
            up.consume()
        }
    }
}
