package com.lorelight.data.db

import com.lorelight.data.model.HistoryEntry
import com.lorelight.data.model.Novel
import org.json.JSONArray

private fun List<String>.toJsonString(): String {
    val arr = JSONArray()
    forEach { arr.put(it) }
    return arr.toString()
}

private fun String.toStringList(): List<String> {
    return try {
        val arr = JSONArray(this)
        val list = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val v = arr.optString(i)
            if (!v.isNullOrEmpty()) list.add(v)
        }
        list
    } catch (e: Exception) {
        emptyList()
    }
}

fun Novel.toEntity(): NovelEntity = NovelEntity(
    id = id,
    title = title,
    currentChapter = currentChapter,
    lastReadTimestamp = lastReadTimestamp,
    author = author,
    status = status,
    totalChapters = totalChapters,
    language = language,
    genresJson = genres.toJsonString(),
    description = description,
    chaptersJson = chapters.toJsonString(),
    coverImageBase64 = coverImageBase64,
    isOnline = isOnline,
    sourceUrl = sourceUrl,
    chapterUrlsJson = chapterUrls.toJsonString(),
    currentParagraphIndex = currentParagraphIndex,
    completedChaptersJson = completedChapters.toJsonString(),
    currentScrollOffset = currentScrollOffset,
    currentWordIndex = currentWordIndex,
    isFavorite = isFavorite,
    categoriesJson = categories.toJsonString(),
    readingStatus = readingStatus,
    dateAdded = dateAdded,
    dateModified = dateModified,
    lastCheckedTimestamp = lastCheckedTimestamp,
    pluginId = pluginId,
    pluginNovelPath = pluginNovelPath,
    currentChapterIndex = currentChapterIndex
)

fun NovelEntity.toNovel(): Novel = Novel(
    title = title,
    currentChapter = currentChapter,
    lastReadTimestamp = lastReadTimestamp,
    author = author,
    status = status,
    totalChapters = totalChapters,
    language = language,
    genres = genresJson.toStringList(),
    description = description,
    chapters = chaptersJson.toStringList(),
    coverImageBase64 = coverImageBase64,
    isOnline = isOnline,
    sourceUrl = sourceUrl,
    chapterUrls = chapterUrlsJson.toStringList(),
    currentParagraphIndex = currentParagraphIndex,
    completedChapters = completedChaptersJson.toStringList(),
    currentScrollOffset = currentScrollOffset,
    currentWordIndex = currentWordIndex,
    isFavorite = isFavorite,
    categories = categoriesJson.toStringList(),
    readingStatus = readingStatus,
    dateAdded = dateAdded,
    dateModified = dateModified,
    lastCheckedTimestamp = lastCheckedTimestamp,
    pluginId = pluginId,
    pluginNovelPath = pluginNovelPath,
    id = id,
    currentChapterIndex = currentChapterIndex
)

fun HistoryEntry.toEntity(): HistoryEntity = HistoryEntity(
    novelId = novelId,
    novelTitle = novelTitle,
    chapterId = chapterId,
    chapterTitle = chapterTitle,
    timestamp = timestamp,
    lastModified = lastModified,
    novelJson = novelJson,
    chapterIndex = chapterIndex
)

fun HistoryEntity.toHistoryEntry(): HistoryEntry = HistoryEntry(
    novelId = novelId,
    novelTitle = novelTitle,
    chapterId = chapterId,
    chapterTitle = chapterTitle,
    timestamp = timestamp,
    lastModified = lastModified,
    novelJson = novelJson,
    chapterIndex = chapterIndex
)
