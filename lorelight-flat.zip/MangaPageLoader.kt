package com.lorelight.manga.reader

import android.content.Context
import coil.ImageLoader
import coil.decode.DataSource
import coil.decode.ImageSource
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.fetch.SourceResult
import coil.request.CachePolicy
import coil.request.Options
import coil.disk.DiskCache
import coil.memory.MemoryCache
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.online.HttpSource
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import okhttp3.Response
import okio.ByteString.Companion.encodeUtf8
import okio.Path.Companion.toOkioPath
import tachiyomi.domain.source.service.SourceManager
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

fun mangaPageCacheKey(sourceId: Long, page: Page, cropBorders: Boolean = false): String {
    val pageIdentity = page.imageUrl?.takeIf { it.isNotBlank() }
        ?: page.url.takeIf { it.isNotBlank() }?.let { "$it#${page.index}" }
        ?: "page_${page.index}"
    return "mp:$sourceId:$pageIdentity:${if (cropBorders) "c" else "n"}"
}

/**
 * Page bytes live in their OWN directory, separate from Coil's disk cache.
 *
 * They used to share "manga_pages" with Coil's DiskCache, which keeps a
 * journal in that directory and assumes it owns every file in it. Because the
 * fetcher hands Coil a finished file it bypasses that journal entirely, so
 * Coil neither counted these files against its 512 MB budget nor ever evicted
 * them -- the directory grew without any limit at all. Separating the two
 * makes both caches honest and lets pruneMangaPageCache bound this one
 * without risking Coil's journal.
 */
internal const val MANGA_PAGE_FILE_DIR = "manga_page_files"

/** Progress is tracked per page, independent of the crop-borders setting. */
fun mangaPageProgressKey(sourceId: Long, page: Page): String =
    mangaPageCacheKey(sourceId, page, cropBorders = false)

/**
 * Per-page download progress in 0f..1f, or -1f when the server sent no
 * Content-Length. mihon drives a real determinate ring from Page.progressFlow;
 * this is the equivalent for the Compose reader, which previously showed an
 * indeterminate spinner that looked identical whether a page was arriving
 * briskly or had stalled completely.
 */
object MangaPageProgress {
    private val flows = ConcurrentHashMap<String, MutableStateFlow<Float>>()

    private fun flowFor(key: String): MutableStateFlow<Float> =
        flows.getOrPut(key) { MutableStateFlow(0f) }

    fun observe(key: String): StateFlow<Float> = flowFor(key)

    fun set(key: String, value: Float) {
        flowFor(key).value = value
    }

    fun clear(key: String) {
        flows.remove(key)
    }
}

/**
 * Global "start every unfinished page again" signal.
 *
 * On a weak connection a page download stalls with a part-written .tmp_ file on
 * disk and a request that never completes. Coil hands that same dead result
 * back on every recomposition, so the page keeps its spinner for as long as the
 * reader stays open -- and because the chapter fetch usually stalled for the
 * same reason, moving somewhere with better signal did not help either. There
 * was no way to ask for any of it again short of leaving the chapter.
 *
 * Bumping [version] tells every mounted page item to throw away what it has and
 * issue a fresh request. Observers skip pages that already finished, so a reset
 * costs nothing for the parts of the chapter that worked.
 */
object MangaPageRetryBus {
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> get() = _version

    /**
     * Deletes every partially downloaded page file, then bumps [version].
     *
     * Cheap enough for the main thread: the directory holds only this app's
     * page cache and the filter touches names, not contents.
     */
    fun resetStalled(context: Context) {
        try {
            val dir = context.applicationContext.cacheDir.resolve(MANGA_PAGE_FILE_DIR)
            if (dir.isDirectory) {
                dir.listFiles { f -> f.isFile && f.name.contains(".tmp_") }
                    ?.forEach { it.delete() }
            }
        } catch (_: Throwable) {
        }
        // Also clear the download gate accounting. Deleting temp files alone
        // could never fix a wedged queue, which is why this used to need a
        // force stop.
        resetAllDownloadGates()
        _version.value = _version.value + 1
    }
}

/**
 * Clears every per-source download gate: zeroes the in-flight count and drops
 * anything queued.
 */
internal fun resetAllDownloadGates() {
    sourceGates.values.forEach { it.forceReset() }
}

internal fun getMangaPageDiskCacheFile(context: Context, sourceId: Long, page: Page): File {
    val dir = context.applicationContext.cacheDir.resolve(MANGA_PAGE_FILE_DIR)
    if (!dir.exists()) dir.mkdirs()
    val baseKey = mangaPageCacheKey(sourceId, page, cropBorders = false)
    val hash = baseKey.encodeUtf8().sha256().hex()
    return File(dir, "$hash.0")
}

fun clearMangaPageTempFiles(context: Context, sourceId: Long, page: Page) {
    try {
        val cacheDir = context.applicationContext.cacheDir.resolve(MANGA_PAGE_FILE_DIR)
        if (!cacheDir.exists()) return
        val cacheFile = getMangaPageDiskCacheFile(context, sourceId, page)
        val prefix = "${cacheFile.name}.tmp_"
        cacheDir.listFiles { f -> f.name.startsWith(prefix) }?.forEach { it.delete() }
        if (cacheFile.exists()) {
            cacheFile.delete()
        }
    } catch (_: Throwable) {
    }
}

/**
 * Bounds the page-file directory, oldest first. Nothing evicted these files
 * before, so on a heavy reader they accumulated until the device ran out of
 * storage. Runs once at startup, off the main thread.
 */
fun pruneMangaPageCache(context: Context, maxBytes: Long = 512L * 1024 * 1024) {
    try {
        val dir = context.applicationContext.cacheDir.resolve(MANGA_PAGE_FILE_DIR)
        if (!dir.isDirectory) return
        val files = dir.listFiles()?.filter { it.isFile } ?: return
        var total = files.sumOf { it.length() }
        if (total <= maxBytes) return
        for (f in files.sortedBy { it.lastModified() }) {
            if (total <= maxBytes) break
            val len = f.length()
            if (f.delete()) total -= len
        }
    } catch (_: Throwable) {
    }
}

data class MangaPageKey(val sourceId: Long, val page: Page) {
    // Page does not override equals, so default data class equality here is
    // identity based and every new instance is treated as a cache miss.
    override fun equals(other: Any?): Boolean =
        other is MangaPageKey &&
            other.sourceId == sourceId &&
            other.page.index == page.index &&
            other.page.url == page.url &&
            other.page.imageUrl == page.imageUrl

    override fun hashCode(): Int {
        var result = sourceId.hashCode()
        result = 31 * result + page.index
        result = 31 * result + page.url.hashCode()
        result = 31 * result + (page.imageUrl?.hashCode() ?: 0)
        return result
    }
}

// ===================== Prioritised per-source page queue =====================
// The queue below is still mihon's model -- a priority queue where the visible
// page outranks preloaded neighbours and ties break strictly FIFO, so page 1
// always starts before page 2. What changed is the DEPTH of the queue.
//
// It used to be pinned at one download per source, on the theory that a single
// download owns the whole pipe and therefore finishes soonest. That reasoning
// only holds when bandwidth is the limit. On a phone it usually is not: most of
// the wall-clock time for a manga page is round-trip latency -- DNS, TLS, the
// server thinking, and Cloudflare -- during which the connection is sitting
// completely idle. Serialising meant paying that dead time once per page, back
// to back, and never overlapping it with anything.
//
// Three in flight overlaps that latency without starving the page on screen:
// the priority queue still hands the visible page the next free slot ahead of
// any preload, and three parallel streams do not meaningfully split bandwidth
// on a connection that spends most of its time waiting rather than transferring.
//
// Kept deliberately modest: this is per source, sources throttle aggressively,
// and every finished download turns into a decode.
private const val MAX_CONCURRENT_DOWNLOADS = 3

// Priority is assigned when a request is ENQUEUED (mirroring mihon's
// PriorityPage) and never recomputed. Higher wins; ties break strictly FIFO.
const val MANGA_PRIORITY_RETRY = 3
const val MANGA_PRIORITY_VISIBLE = 2
const val MANGA_PRIORITY_ADJACENT = 1

// Below every other rank: the background top-up that keeps filling the
// chapter while nobody is scrolling. It only ever gets a download slot that
// no visible page, retry or preload wants, so it cannot slow the page you
// are actually looking at.
const val MANGA_PRIORITY_IDLE = 0

/** Coil request parameter carrying one of the MANGA_PRIORITY_* values. */
const val MANGA_PRIORITY_PARAM = "mp_priority"

/** Default preload depth, matching mihon's HttpPageLoader.preloadSize. */
const val MANGA_PRELOAD_SIZE = 4

// Concurrency and preload depth are deliberately NOT settings. In mihon both
// are fixed constants, and the whole point of matching it is to stop guessing
// at these numbers.

/**
 * Thread-safe tracker for the currently visible page index per source.
 * Allows image loaders to prioritize pages closest to the user's viewport.
 */
object MangaViewerPositionTracker {
    private val positions = ConcurrentHashMap<Long, Int>()
    @Volatile private var globalActivePosition: Int = 0

    fun updateVisiblePage(sourceId: Long, pageIndex: Int) {
        positions[sourceId] = pageIndex
        globalActivePosition = pageIndex
    }

    fun getVisiblePage(sourceId: Long): Int {
        return positions[sourceId] ?: globalActivePosition
    }
}

private val sourceGates = ConcurrentHashMap<Long, PriorityAdaptiveGate>()
private fun gateFor(sourceId: Long): PriorityAdaptiveGate =
    sourceGates.getOrPut(sourceId) { PriorityAdaptiveGate() }

private class PriorityAdaptiveGate {
    private val lock = Any()
    private var activeCount = 0
    // Fixed at one, like mihon's single-worker queue. Not adjustable.
    private val target: Int = MAX_CONCURRENT_DOWNLOADS
    private var seq = 0L

    private val waitQueue = java.util.PriorityQueue<WaitEntry>()

    private class WaitEntry(
        val priority: Int,
        val seq: Long,
        val continuation: kotlinx.coroutines.CancellableContinuation<Unit>
    ) : Comparable<WaitEntry> {
        override fun compareTo(other: WaitEntry): Int {
            // Higher rank first, then strict FIFO within a rank. That FIFO
            // tiebreak is what guarantees page 1 downloads before page 2: the
            // viewer composes pages top-down, so page 1's request always
            // carries the lower sequence number.
            //
            // The old comparator sorted ASCENDING, which was correct for the
            // scheme it served -- priority was a DISTANCE there, so smallest
            // meant nearest meant first. The flip is required by mihon's
            // semantics, where priority is a RANK and larger means more
            // urgent. This is not a fix to a pre-existing ordering bug.
            val p = other.priority.compareTo(priority)
            return if (p != 0) p else seq.compareTo(other.seq)
        }
    }

    suspend fun <T> withPriorityPermit(priority: Int, action: suspend () -> T): T {
        acquire(priority)
        try {
            return action()
        } finally {
            release()
        }
    }

    private suspend fun acquire(priority: Int) {
        val needsWait = synchronized(lock) {
            if (activeCount < target && waitQueue.isEmpty()) {
                activeCount++
                false
            } else {
                true
            }
        }
        if (needsWait) {
            kotlinx.coroutines.suspendCancellableCoroutine<Unit> { cont ->
                var entry: WaitEntry? = null
                synchronized(lock) {
                    if (activeCount < target && waitQueue.isEmpty()) {
                        activeCount++
                        cont.resume(Unit) { returnPermit() }
                    } else {
                        val e = WaitEntry(priority, seq++, cont)
                        waitQueue.add(e)
                        entry = e
                    }
                }
                entry?.let { e ->
                    cont.invokeOnCancellation {
                        synchronized(lock) {
                            waitQueue.remove(e)
                            resumeNextLocked()
                        }
                    }
                }
            }
        }
    }

    private fun release() {
        synchronized(lock) {
            // Clamped: forceReset() can zero the count while downloads are still
            // in flight, and without this their release() would drive it negative
            // and the ceiling would stop meaning anything.
            activeCount = (activeCount - 1).coerceAtLeast(0)
            resumeNextLocked()
        }
    }

    private fun resumeNextLocked() {
        while (activeCount < target && waitQueue.isNotEmpty()) {
            val next = waitQueue.poll() ?: break
            if (next.continuation.isActive) {
                activeCount++
                // THE STALL FIX. isActive is only a hint: the waiter can be
                // cancelled between that check and this resume, and then the
                // resumed value is discarded, action() never runs, and the
                // finally-block that would hand this permit back never executes.
                // The permit had already been counted, so it was gone for the
                // life of the process. Cancellation here is constant -- every
                // scroll away from a page cancels its request -- and with the
                // old ceiling of one download in flight, losing a single permit
                // meant no page ever loaded again until the app was force
                // stopped. Returning the permit makes that impossible.
                next.continuation.resume(Unit) { returnPermit() }
            }
            // A waiter that died while queued is dropped and the loop moves on to
            // the next one. The old code also stopped after waking a single
            // waiter, which left slots idle whenever more than one freed up.
        }
    }

    /** Hands back a permit granted to a waiter that never actually woke. */
    private fun returnPermit() {
        synchronized(lock) {
            activeCount = (activeCount - 1).coerceAtLeast(0)
            resumeNextLocked()
        }
    }

    /**
     * Drops all queued waiters and zeroes the in-flight count.
     *
     * Recovery hatch: if the accounting is ever wrong the queue never drains
     * again, and no amount of retrying individual pages helps. This lets the
     * reader recover from inside the app instead of needing a force stop.
     */
    fun forceReset() {
        val stranded = synchronized(lock) {
            val copy = waitQueue.toList()
            waitQueue.clear()
            activeCount = 0
            copy
        }
        stranded.forEach { it.continuation.cancel() }
    }

    // No retune hook: the ceiling is a constant now, so it can never rise.
    // No throttle hooks either -- mihon does not react to 429/503 at all.
}

/**
 * Downloads one page's bytes into its cache file and returns the response
 * content type, or null when the server sent none.
 *
 * Written to a temp file and renamed into place atomically, so an abort
 * halfway through can never leave a truncated file behind that later looks
 * like a valid cache hit. Progress is published per page so the viewer can
 * draw a real ring.
 *
 * Shared by the Coil fetcher and by [prefetchMangaPageFile] so both write
 * byte-identical files to the same place -- whichever one gets there first,
 * the other finds a finished file and skips the network entirely.
 */
private suspend fun downloadPageToFile(
    context: Context,
    source: HttpSource,
    sourceId: Long,
    page: Page,
    cacheFile: File
): String? {
    val response = source.getImage(page)
    try {
        val body = response.body
            ?: throw IllegalStateException("Response body is null")

        val contentType = body.contentType()?.toString()
        if (contentType != null &&
            (contentType.startsWith("text/") || contentType.contains("html"))
        ) {
            throw IllegalStateException(
                "Expected an image for page ${page.index + 1} but received " +
                    "$contentType. The page URL was used instead of the image URL."
            )
        }

        val cacheDir = context.applicationContext.cacheDir.resolve(MANGA_PAGE_FILE_DIR)
        if (!cacheDir.exists()) cacheDir.mkdirs()
        val tempFile = File(cacheDir, "${cacheFile.name}.tmp_${System.currentTimeMillis()}_${java.util.UUID.randomUUID()}")

        val progressKey = mangaPageProgressKey(sourceId, page)
        try {
            // Copied by hand rather than with copyTo so the byte count can
            // drive a real progress ring. -1f means the server sent no
            // Content-Length, so the viewer stays indeterminate.
            val expected = body.contentLength()
            MangaPageProgress.set(progressKey, if (expected > 0L) 0f else -1f)
            var written = 0L
            tempFile.outputStream().use { fos ->
                body.byteStream().use { input ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val read = input.read(buf)
                        if (read <= 0) break
                        fos.write(buf, 0, read)
                        written += read
                        if (expected > 0L) {
                            MangaPageProgress.set(
                                progressKey,
                                (written.toFloat() / expected.toFloat()).coerceIn(0f, 1f)
                            )
                        }
                    }
                }
            }
            if (cacheFile.exists()) cacheFile.delete()
            if (!tempFile.renameTo(cacheFile)) {
                tempFile.copyTo(cacheFile, overwrite = true)
                tempFile.delete()
            }
        } catch (t: Throwable) {
            if (tempFile.exists()) tempFile.delete()
            throw t
        } finally {
            MangaPageProgress.clear(progressKey)
        }
        return contentType
    } finally {
        response.close()
    }
}

/**
 * Puts one page's bytes on disk WITHOUT decoding it. Returns true when the
 * file is there afterwards.
 *
 * This is the difference between it and a Coil prefetch, and the reason it
 * exists: enqueueing an ImageRequest also decodes the page into the bitmap
 * cache, and that cache is deliberately small (15% of the heap), so a
 * background pass over a whole chapter would evict the very page being
 * looked at and could hold 48 MB per long strip while decoding. Downloading
 * only means the expensive half never happens until the page is actually
 * shown, and by then the bytes are already local.
 *
 * Runs at [MANGA_PRIORITY_IDLE], below every preload, so it always yields
 * its slot the moment the reader wants a page.
 */
suspend fun prefetchMangaPageFile(context: Context, sourceId: Long, page: Page): Boolean {
    val cacheFile = getMangaPageDiskCacheFile(context, sourceId, page)
    if (cacheFile.exists() && cacheFile.length() > 0L) return true
    return try {
        val sourceManager = Injekt.get<SourceManager>()
        sourceManager.isInitialized.first { it }
        val source = sourceManager.get(sourceId) as? HttpSource ?: return false
        if (page.imageUrl.isNullOrBlank()) {
            page.imageUrl = source.getImageUrl(page)
        }
        gateFor(sourceId).withPriorityPermit(MANGA_PRIORITY_IDLE) {
            if (cacheFile.exists() && cacheFile.length() > 0L) {
                return@withPriorityPermit true
            }
            downloadPageToFile(context, source, sourceId, page, cacheFile)
            cacheFile.exists() && cacheFile.length() > 0L
        }
    } catch (t: Throwable) {
        // Best effort by definition. Nothing is waiting on this page yet, so
        // a failure is simply retried the next time round the loop, or paid
        // for normally if the reader gets there first.
        false
    }
}

class MangaPageFetcher(
    private val key: MangaPageKey,
    private val options: Options,
    private val context: Context
) : Fetcher {
    override suspend fun fetch(): FetchResult {
        val retryVal = (options.parameters.value("retry") as? Int) ?: 0
        val isRetry = retryVal > 0
        val cacheFile = getMangaPageDiskCacheFile(context, key.sourceId, key.page)

        // Fast disk path: if cached file exists and not retrying, return immediately without gate/network
        if (!isRetry && cacheFile.exists() && cacheFile.length() > 0) {
            return SourceResult(
                source = ImageSource(file = cacheFile.toOkioPath()),
                mimeType = null,
                dataSource = DataSource.DISK
            )
        }

        if (isRetry) {
            clearMangaPageTempFiles(context, key.sourceId, key.page)
        }

        val sourceManager = Injekt.get<SourceManager>()
        sourceManager.isInitialized.first { it }
        val source = sourceManager.get(key.sourceId) as? HttpSource
            ?: throw IllegalStateException("Extension not installed or source unavailable")

        val page = key.page
        if (page.imageUrl.isNullOrBlank()) {
            page.imageUrl = source.getImageUrl(page)
        }

        val gate = gateFor(key.sourceId)
        // Priority now travels WITH the request, fixed at the moment it was
        // enqueued, the way mihon tags a PriorityPage. The old code recomputed
        // it here from a mutable global "currently visible page", so a request
        // that waited in the queue was ranked against wherever the user had
        // scrolled to by the time it finally ran. Worse, abs() ranked a page
        // already behind the reader as urgently as the one just ahead.
        val priority = if (isRetry) {
            MANGA_PRIORITY_RETRY
        } else {
            (options.parameters.value(MANGA_PRIORITY_PARAM) as? Int) ?: MANGA_PRIORITY_VISIBLE
        }
        return gate.withPriorityPermit(priority) {
            // Check once more in case concurrent request completed while waiting in queue
            if (!isRetry && cacheFile.exists() && cacheFile.length() > 0) {
                return@withPriorityPermit SourceResult(
                    source = ImageSource(file = cacheFile.toOkioPath()),
                    mimeType = null,
                    dataSource = DataSource.DISK
                )
            }

            // One request per attempt, exactly like mihon's internalLoadPage.
            // A failure becomes a failed page the viewer can retry, instead of
            // this request sitting in a backoff loop and holding the queue.
            val contentType = downloadPageToFile(context, source, key.sourceId, page, cacheFile)
            SourceResult(
                source = ImageSource(file = cacheFile.toOkioPath()),
                mimeType = contentType,
                dataSource = DataSource.NETWORK
            )
        }
    }

}

class MangaPageFetcherFactory(private val context: Context) : Fetcher.Factory<MangaPageKey> {
    override fun create(data: MangaPageKey, options: Options, imageLoader: ImageLoader): Fetcher {
        return MangaPageFetcher(data, options, context)
    }
}

/**
 * Decoding runs on its own fixed two-thread pool instead of Coil's default
 * Dispatchers.IO.
 *
 * Downloads are now allowed three at a time, so three pages can finish within
 * milliseconds of each other. On Dispatchers.IO that would start three decodes
 * at once, and a single colour strip can hold up to 48 MB while decoding -- the
 * exact shape of allocation that ends as an OS low-memory kill rather than a
 * catchable OutOfMemoryError.
 *
 * Two threads keep the decode pipeline full (decoding is the CPU-bound half of
 * page loading, so one thread would now be the new bottleneck) while capping
 * how much decode memory can ever be live at once. Slightly below-normal
 * priority so decoding a preloaded page never competes with the UI thread that
 * is drawing the page already on screen.
 */
private val mangaDecodeDispatcher by lazy {
    Executors.newFixedThreadPool(2) { runnable ->
        Thread(runnable, "manga-decode").apply {
            priority = (Thread.NORM_PRIORITY - 1).coerceAtLeast(Thread.MIN_PRIORITY)
        }
    }.asCoroutineDispatcher()
}

object MangaImageLoaderProvider {
    /**
     * Fixed preload depth, the same value and the same reasoning as mihon's
     * HttpPageLoader.preloadSize. It is a constant there, so it is a constant
     * here.
     */
    fun prefetchWindow(): Int = MANGA_PRELOAD_SIZE

    @Volatile
    private var pageImageLoader: ImageLoader? = null

    @Volatile
    private var coverImageLoader: ImageLoader? = null

    fun getImageLoader(context: Context): ImageLoader {
        val app = context.applicationContext
        return pageImageLoader ?: synchronized(this) {
            pageImageLoader ?: ImageLoader.Builder(app)
                .okHttpClient { com.lorelight.network.HttpClients.shared() }
                .components {
                    add(MangaPageFetcherFactory(app))
                    add(MangaTallImageDecoder.Factory())
                }
                // Manga pages, and manhwa strips above all, are very tall. A
                // HARDWARE bitmap taller than the GPU max texture size decodes
                // fine but silently draws nothing: onSuccess fires, the spinner
                // clears, and the page renders as empty background. Software
                // bitmaps have no such limit.
                .allowHardware(false)
                // Bounded decode pool -- see mangaDecodeDispatcher.
                .decoderDispatcher(mangaDecodeDispatcher)
                .memoryCache {
                    MemoryCache.Builder(app)
                        // Manga pages are enormous -- a single uncropped colour
                        // strip can be 30-40 MB by itself. Holding a quarter of
                        // the heap in those is what pushed the process into an
                        // OS low-memory kill, which produces no Java exception
                        // and so never reached the crash file.
                        .maxSizePercent(0.15)
                        .build()
                }
                .diskCache {
                    DiskCache.Builder()
                        .directory(app.cacheDir.resolve("manga_pages"))
                        // 512 MB so a fully-read chapter stays on disk and never
                        // needs a network re-download.
                        .maxSizeBytes(512L * 1024 * 1024)
                        .build()
                }
                // Always read/write both caches, regardless of server headers.
                .memoryCachePolicy(CachePolicy.ENABLED)
                .diskCachePolicy(CachePolicy.ENABLED)
                .respectCacheHeaders(false)
                .build()
                .also { pageImageLoader = it }
        }
    }

    /**
     * Dedicated loader for manga covers.
     * Keeps cover thumbnails isolated in `manga_covers` so full reader pages
     * never evict covers from disk or RAM cache. Allows hardware bitmaps for speed.
     */
    fun getCoverImageLoader(context: Context): ImageLoader {
        val app = context.applicationContext
        return coverImageLoader ?: synchronized(this) {
            coverImageLoader ?: ImageLoader.Builder(app)
                .okHttpClient { com.lorelight.network.HttpClients.shared() }
                .components {
                    add(com.lorelight.manga.ui.MangaCoverFetcher.Factory(app))
                    add(com.lorelight.manga.ui.MangaCoverKeyer())
                }
                .memoryCache {
                    MemoryCache.Builder(app)
                        .maxSizePercent(0.15)
                        .build()
                }
                .diskCache {
                    DiskCache.Builder()
                        .directory(app.cacheDir.resolve("manga_covers"))
                        .maxSizeBytes(128L * 1024 * 1024)
                        .build()
                }
                .memoryCachePolicy(CachePolicy.ENABLED)
                .diskCachePolicy(CachePolicy.ENABLED)
                .respectCacheHeaders(false)
                .build()
                .also { coverImageLoader = it }
        }
    }
}
