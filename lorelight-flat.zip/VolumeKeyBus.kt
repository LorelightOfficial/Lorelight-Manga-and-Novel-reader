package com.lorelight.ui.reader

import kotlinx.coroutines.flow.MutableSharedFlow

object VolumeKeyBus {
    // true only while the reader is open AND the user has enabled the feature
    @Volatile var active: Boolean = false

    val events = MutableSharedFlow<Int>(
        replay = 0,
        extraBufferCapacity = 4,
        onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST
    )

    // direction: +1 = page down (volume down), -1 = page up (volume up)
    fun emit(direction: Int) {
        events.tryEmit(direction)
    }
}
