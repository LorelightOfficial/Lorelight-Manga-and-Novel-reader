package com.lorelight.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

@Composable
fun VerticalFastScroller(
    listState: LazyListState,
    modifier: Modifier = Modifier,
    thumbColor: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = thumbColor.copy(alpha = 0.15f),
    thumbMinHeight: Dp = 48.dp,
    hideDelayMs: Long = 1500L,
    content: @Composable BoxScope.() -> Unit
) {
    val density = LocalDensity.current
    val coroutineScope = rememberCoroutineScope()
    val thumbMinHeightPx = with(density) { thumbMinHeight.toPx() }

    var containerHeightPx by remember { mutableFloatStateOf(0f) }
    var isDragging by remember { mutableStateOf(false) }

    val info = listState.layoutInfo
    val totalItems = info.totalItemsCount
    val visibleItemsInfo = info.visibleItemsInfo
    val visibleItemsCount = visibleItemsInfo.size

    val viewportHeightPx = if (info.viewportSize.height > 0) info.viewportSize.height.toFloat() else containerHeightPx

    val scrollProgress by remember(info, totalItems, visibleItemsCount) {
        derivedStateOf {
            if (totalItems <= 1 || visibleItemsCount == 0) return@derivedStateOf 0f
            val firstIdx = listState.firstVisibleItemIndex
            val firstOffset = listState.firstVisibleItemScrollOffset
            val avgItemSize = visibleItemsInfo.sumOf { it.size }.toFloat() / visibleItemsCount
            val maxIndex = (totalItems - visibleItemsCount).coerceAtLeast(1)
            val currentPos = firstIdx + (if (avgItemSize > 0f) firstOffset / avgItemSize else 0f)
            (currentPos / maxIndex).coerceIn(0f, 1f)
        }
    }

    val thumbHeightPx by remember(totalItems, visibleItemsCount, viewportHeightPx, thumbMinHeightPx) {
        derivedStateOf {
            if (viewportHeightPx <= 0f || totalItems <= 0) return@derivedStateOf thumbMinHeightPx
            val fraction = (visibleItemsCount.toFloat() / totalItems.toFloat()).coerceIn(0.05f, 1f)
            (viewportHeightPx * fraction).coerceAtLeast(thumbMinHeightPx)
        }
    }

    val maxThumbOffsetY by remember(viewportHeightPx, thumbHeightPx) {
        derivedStateOf {
            (viewportHeightPx - thumbHeightPx).coerceAtLeast(0f)
        }
    }

    val thumbOffsetY by remember(scrollProgress, maxThumbOffsetY) {
        derivedStateOf {
            scrollProgress * maxThumbOffsetY
        }
    }

    val isScrollInProgress = listState.isScrollInProgress
    val isActive = isScrollInProgress || isDragging
    var isVisible by remember { mutableStateOf(false) }

    LaunchedEffect(isActive, totalItems, visibleItemsCount) {
        if (isActive) {
            isVisible = true
        } else {
            delay(hideDelayMs)
            isVisible = false
        }
    }

    val alpha by animateFloatAsState(
        targetValue = if (isVisible && totalItems > visibleItemsCount) 1f else 0f,
        animationSpec = tween(150),
        label = "FastScrollerAlpha"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .onGloballyPositioned {
                containerHeightPx = it.size.height.toFloat()
            }
    ) {
        content()

        if (alpha > 0f && totalItems > visibleItemsCount) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .fillMaxHeight()
                    .width(32.dp)
                    .alpha(alpha)
                    .pointerInput(totalItems, maxThumbOffsetY) {
                        detectTapGestures { tapOffset ->
                            if (maxThumbOffsetY > 0f) {
                                val targetProgress = ((tapOffset.y - thumbHeightPx / 2f) / maxThumbOffsetY).coerceIn(0f, 1f)
                                val targetIndex = (targetProgress * (totalItems - 1)).roundToInt().coerceIn(0, (totalItems - 1).coerceAtLeast(0))
                                coroutineScope.launch {
                                    listState.animateScrollToItem(targetIndex)
                                }
                            }
                        }
                    }
                    .pointerInput(totalItems, maxThumbOffsetY) {
                        detectVerticalDragGestures(
                            onDragStart = { startOffset ->
                                isDragging = true
                                if (maxThumbOffsetY > 0f) {
                                    val targetProgress = ((startOffset.y - thumbHeightPx / 2f) / maxThumbOffsetY).coerceIn(0f, 1f)
                                    val targetIndex = (targetProgress * (totalItems - 1)).roundToInt().coerceIn(0, (totalItems - 1).coerceAtLeast(0))
                                    coroutineScope.launch {
                                        listState.scrollToItem(targetIndex)
                                    }
                                }
                            },
                            onDragEnd = { isDragging = false },
                            onDragCancel = { isDragging = false },
                            onVerticalDrag = { change, _ ->
                                change.consume()
                                if (maxThumbOffsetY > 0f) {
                                    val newThumbTop = (change.position.y - thumbHeightPx / 2f).coerceIn(0f, maxThumbOffsetY)
                                    val targetProgress = (newThumbTop / maxThumbOffsetY).coerceIn(0f, 1f)
                                    val targetIndex = (targetProgress * (totalItems - 1)).roundToInt().coerceIn(0, (totalItems - 1).coerceAtLeast(0))
                                    coroutineScope.launch {
                                        listState.scrollToItem(targetIndex)
                                    }
                                }
                            }
                        )
                    }
            ) {
                // Track line (subtle background)
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 4.dp)
                        .width(2.dp)
                        .fillMaxHeight()
                        .background(trackColor, CircleShape)
                )

                // Draggable Thumb
                val thumbHeightDp = with(density) { thumbHeightPx.toDp() }
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(end = 2.dp)
                        .offset { IntOffset(0, thumbOffsetY.roundToInt()) }
                        .width(6.dp)
                        .height(thumbHeightDp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(thumbColor)
                )
            }
        }
    }
}
