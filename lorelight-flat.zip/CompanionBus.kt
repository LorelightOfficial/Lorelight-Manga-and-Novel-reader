/*
 * =============================================================================
 * CompanionBus.kt - how the rest of the app reaches the companion.
 * Package: com.lorelight.companion
 *
 * THE PROBLEM THIS SOLVES
 *
 * The companion is created inside MainActivity's composable, so it is a local
 * val. But the moments worth reacting to happen far away from there: a chapter
 * finishing inside MangaReaderViewModel, a page failing to load inside a
 * coroutine, a novel being added from a browser dialog three screens deep.
 *
 * Threading those callbacks down through every screen signature would mean
 * touching a dozen files and adding a parameter to functions that have no
 * business knowing a companion exists.
 *
 * So he is published on a small bus instead. This is the same pattern already
 * used by AppSettingsSignal and SourceBrowserRequest in this codebase.
 *
 * TWO THINGS THIS FILE GUARANTEES
 *
 * 1. Nothing crashes when he does not exist. If the corpus failed to load,
 *    `state` is null and every method here is a no-op. Call sites do not need
 *    a null check, an import of CompanionState, or a try/catch.
 *
 * 2. Compose state is only ever touched on the main thread. Call sites include
 *    view models and DbWriter callbacks, so every call is marshalled. A call
 *    site does not have to know or care which thread it is on.
 *
 * It also holds the small amount of counting that no single call site could do
 * on its own: noticing the SAME chapter being reopened over and over, and
 * noticing the unread pile crossing a line.
 * =============================================================================
 */
package com.lorelight.companion

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.lorelight.data.model.Novel
import com.lorelight.data.model.isManga

object CompanionBus {

    /** Fire onRepeatedReopen when the same chapter is opened this many times. */
    private const val REOPEN_TRIGGER = 4

    /**
     * A broken chapter can fail many times in a row as pages retry. He should
     * wince once, not become a klaxon.
     */
    private const val FAIL_COOLDOWN_MS = 60_000L

    /** Unread chapters across the whole library that count as "a pile". */
    private const val UNREAD_THRESHOLD = 50

    /** Drop back under this before the pile can be remarked upon again. */
    private const val UNREAD_RESET = 40

    private const val DAY_MS = 86_400_000L

    /** Only offer a drifted-away book once it has been idle this long. */
    private const val UNFINISHED_MIN_IDLE_DAYS = 7

    private const val KEY_STREAK_DAY = "streak.day"
    private const val KEY_STREAK_LEN = "streak.len"

    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var state: CompanionState? = null

    /* --- counters no single call site could keep ------------------------ */
    private var lastChapterKey: String? = null
    private var reopenCount = 0
    private var lastFailAt = 0L
    private var unreadAnnounced = false
    private val finishedNovels = HashSet<String>()
    private var streakDays = 0

    /** When this app run began. Drives his "you've been at this a while". */
    private val sessionStartAt = System.currentTimeMillis()

    /**
     * Publishes the companion, or clears him on dispose. Called from
     * MainActivity only.
     */
    fun attach(companion: CompanionState?) {
        state = companion
    }

    /**
     * Whether the tab shell is the thing on screen. Called from MainActivity
     * on every navigation.
     *
     * He lives on the altar in that shell, so this is what stops him talking
     * to an empty room while a reader or a details page is up. Lines earned
     * off screen are held by the companion, not dropped here.
     */
    fun setOnScreen(visible: Boolean) = post { companion ->
        companion.setOnScreen(visible)
    }

    /**
     * Runs [body] against the live companion on the main thread, or does
     * nothing at all if he does not exist.
     *
     * The main-thread hop is not optional. Several call sites are view models
     * and background writers, and CompanionState holds Compose state.
     */
    private fun post(body: (CompanionState) -> Unit) {
        val live = state ?: return
        if (Looper.myLooper() == Looper.getMainLooper()) {
            body(live)
        } else {
            // Re-read state inside the post: he may have gone away in between.
            main.post { state?.let(body) }
        }
    }

    /* =====================================================================
     * LIBRARY
     * ===================================================================*/

    /**
     * Something was added to the library. Picks the right line for the kind of
     * thing it is, since a manga and a novel are not the same event to him.
     */
    fun onLibraryAdd(novel: Novel) = post { companion ->
        if (novel.isManga) {
            companion.onMangaAdded(novel.title)
        } else {
            companion.onNovelAdded(novel.title)
        }
    }

    /**
     * Re-counts the unread pile. Cheap: this walks the in-memory library list
     * and touches no database.
     *
     * Has hysteresis on purpose. Without it, hovering either side of the line
     * would let him comment every single time the count wobbled by one.
     */
    fun noteLibrary(novels: List<Novel>) {
        var unread = 0
        for (novel in novels) {
            val total = novel.chapters.size
            if (total <= 0) continue
            unread += (total - novel.completedChapters.size).coerceAtLeast(0)
        }

        if (unread >= UNREAD_THRESHOLD) {
            if (!unreadAnnounced) {
                unreadAnnounced = true
                post { it.onUnreadPiledUp() }
            }
        } else if (unread <= UNREAD_RESET) {
            unreadAnnounced = false
        }
    }

    /* =====================================================================
     * READING
     * ===================================================================*/

    /**
     * A chapter was read to the end and left behind.
     *
     * @param chapterIndex zero-based; he is told the human chapter NUMBER.
     */
    fun onChapterFinished(novel: Novel?, chapterIndex: Int) {
        post { it.onChapterFinished(chapterIndex + 1) }
        if (novel != null) checkNovelFinished(novel)
    }

    /**
     * The whole novel is done. Fires at most once per novel per app run.
     *
     * Counts the chapter that just finished by hand, because the read is
     * written to the database asynchronously and may not be visible yet.
     */
    private fun checkNovelFinished(novel: Novel) {
        val total = novel.chapters.size
        if (total <= 0) return
        if (novel.completedChapters.size + 1 < total) return
        if (novel.id.isEmpty()) return
        if (!finishedNovels.add(novel.id)) return
        post { it.onNovelFinished() }
    }

    /**
     * A chapter was opened. Used only to notice the same one being opened over
     * and over, which usually means the reader lost the place.
     */
    fun noteChapterOpened(novelId: String?, chapterIndex: Int) {
        val key = (novelId ?: return) + "#" + chapterIndex
        if (key == lastChapterKey) {
            reopenCount++
            // Only on the exact trigger count, so holding at five does not
            // repeat the reaction.
            if (reopenCount == REOPEN_TRIGGER) post { it.onRepeatedReopen() }
        } else {
            lastChapterKey = key
            reopenCount = 1
        }
    }

    /** A chapter or page would not load. Rate limited hard. */
    fun onLoadFailed() {
        val now = System.currentTimeMillis()
        if (now - lastFailAt < FAIL_COOLDOWN_MS) return
        lastFailAt = now
        post { it.onLoadFailed() }
    }

    /**
     * The screen is moving under the user's finger.
     *
     * This is what keeps him polite: the governor waits for a still screen
     * before letting a bubble appear, so a line never lands mid-scroll.
     */
    fun noteMotion() {
        post { it.noteMotion() }
    }

    /* =====================================================================
     * WHAT HE IS ALLOWED TO KNOW
     *
     * Without this, three whole corpus events can never fire: STREAK has no
     * day count, LONG_SESSION has no session start, and UNFINISHED_WAITING
     * has no book. The lines exist; nothing was feeding them.
     * ===================================================================*/

    /**
     * Rolls the day-streak counter. Safe to call repeatedly: within one
     * calendar day it is idempotent.
     *
     * Nothing else in the app tracks consecutive days, so it is tracked here,
     * in the companion's own prefs file.
     */
    fun noteLaunch(context: Context) {
        val store = PrefsCompanionStore(context)
        val today = localDayNumber(System.currentTimeMillis())
        val lastDay = store.getLong(KEY_STREAK_DAY, 0L)
        val stored = store.getInt(KEY_STREAK_LEN, 0)

        val next = when {
            // Already counted today.
            lastDay == today -> if (stored <= 0) 1 else stored
            // Yesterday, so the run continues.
            lastDay == today - 1L -> stored + 1
            // Gap, or first ever. Today is day one.
            else -> 1
        }

        streakDays = next
        if (lastDay != today) {
            store.putLong(KEY_STREAK_DAY, today)
            store.putInt(KEY_STREAK_LEN, next)
        } else if (stored != next) {
            store.putInt(KEY_STREAK_LEN, next)
        }
    }

    /**
     * Publishes the current facts. Call whenever the library or the screen
     * changes; it is cheap and does no I/O.
     */
    fun publishSignals(novels: List<Novel>, reading: Boolean) = post { companion ->
        val where = if (reading) CompanionSurface.READING else CompanionSurface.BROWSE
        companion.surface = where
        companion.signals = CompanionSignals(
            libraryCount = novels.size,
            streakDays = streakDays,
            sessionStartAt = sessionStartAt,
            surface = where,
            unfinished = pickUnfinished(novels)
        )
    }

    /**
     * The book left hanging the longest.
     *
     * Deliberately does NOT apply the 20-80% progress window or the idle-day
     * policy beyond a coarse floor -- CompanionDetector owns those rules, and
     * duplicating them here would mean two places to keep in step.
     */
    private fun pickUnfinished(novels: List<Novel>): UnfinishedTitle? {
        val now = System.currentTimeMillis()
        var best: UnfinishedTitle? = null
        for (novel in novels) {
            val total = novel.chapters.size
            if (total <= 0) continue
            if (novel.lastReadTimestamp <= 0L) continue

            val idleDays = ((now - novel.lastReadTimestamp) / DAY_MS).toInt()
            if (idleDays < UNFINISHED_MIN_IDLE_DAYS) continue

            val progress = novel.completedChapters.size.toFloat() / total
            // Never started, or already finished: not a book left hanging.
            if (progress <= 0f || progress >= 1f) continue

            val current = best
            if (current == null || idleDays > current.idleDays) {
                best = UnfinishedTitle(novel.title, progress, idleDays)
            }
        }
        return best
    }

    /** Days since the epoch in LOCAL time, so a streak breaks at midnight. */
    private fun localDayNumber(millis: Long): Long {
        val zone = java.util.TimeZone.getDefault()
        return (millis + zone.getOffset(millis)) / DAY_MS
    }
}
