package com.lorelight.manga.reader

import android.graphics.Bitmap
import android.graphics.Color
import coil.size.Size
import coil.transform.Transformation
import kotlin.math.abs

/**
 * Trims the flat margins scanlators leave around a page so pages sit flush
 * against each other in long strip mode.
 *
 * Deliberately conservative: it only crops when all four corners agree on a
 * background colour, and it refuses to crop away more than three quarters of
 * the page. A near-blank page would otherwise collapse to nothing.
 */
class CropBordersTransformation(
    private val threshold: Int = 18
) : Transformation {

    override val cacheKey: String = "com.lorelight.cropBorders-$threshold"

    override suspend fun transform(input: Bitmap, size: Size): Bitmap {
        val w = input.width
        val h = input.height
        if (w < 8 || h < 8) return input

        val pixels = IntArray(w * h)
        input.getPixels(pixels, 0, w, 0, 0, w, h)

        val bg = pixels[0]
        // If the corners disagree there is real art at the edge; leave it alone.
        if (!similar(bg, pixels[w - 1]) ||
            !similar(bg, pixels[(h - 1) * w]) ||
            !similar(bg, pixels[h * w - 1])
        ) {
            return input
        }

        val xStep = (w / 64).coerceAtLeast(1)
        val yStep = (h / 64).coerceAtLeast(1)

        var top = 0
        while (top < h - 1 && rowIsFlat(pixels, w, top, bg, xStep)) top++
        var bottom = h - 1
        while (bottom > top + 1 && rowIsFlat(pixels, w, bottom, bg, xStep)) bottom--
        var left = 0
        while (left < w - 1 && colIsFlat(pixels, w, h, left, bg, yStep)) left++
        var right = w - 1
        while (right > left + 1 && colIsFlat(pixels, w, h, right, bg, yStep)) right--

        val newW = right - left + 1
        val newH = bottom - top + 1
        if (newW <= 0 || newH <= 0) return input
        // Nothing worth trimming.
        if (newW >= w && newH >= h) return input
        // Runaway crop guard.
        if (newW < w / 4 || newH < h / 4) return input

        return Bitmap.createBitmap(input, left, top, newW, newH)
    }

    private fun rowIsFlat(px: IntArray, w: Int, y: Int, bg: Int, step: Int): Boolean {
        val base = y * w
        var x = 0
        while (x < w) {
            if (!similar(px[base + x], bg)) return false
            x += step
        }
        return true
    }

    private fun colIsFlat(px: IntArray, w: Int, h: Int, x: Int, bg: Int, step: Int): Boolean {
        var y = 0
        while (y < h) {
            if (!similar(px[y * w + x], bg)) return false
            y += step
        }
        return true
    }

    private fun similar(a: Int, b: Int): Boolean =
        abs(Color.red(a) - Color.red(b)) <= threshold &&
            abs(Color.green(a) - Color.green(b)) <= threshold &&
            abs(Color.blue(a) - Color.blue(b)) <= threshold

    override fun equals(other: Any?): Boolean =
        other is CropBordersTransformation && other.threshold == threshold

    override fun hashCode(): Int = cacheKey.hashCode()
}
