package com.lorelight.manga.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.*
import com.lorelight.ui.components.LorelightDialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import eu.kanade.tachiyomi.extension.ExtensionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import mihon.domain.extension.interactor.AddExtensionStore
import mihon.domain.extension.interactor.GetExtensionStores
import mihon.domain.extension.interactor.RemoveExtensionStore
import mihon.domain.extension.model.ExtensionStore
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import java.net.URI

private fun deriveRepoName(url: String): String {
    val clean = url.trim().removeSuffix("/")
    if (clean.contains("raw.githubusercontent.com/")) {
        val parts = clean.substringAfter("raw.githubusercontent.com/").split("/")
        if (parts.size >= 2) {
            return "${parts[0]}/${parts[1]}"
        }
    }
    return try {
        val uri = URI(clean)
        uri.host ?: clean
    } catch (e: Exception) {
        clean
    }
}

@Composable
fun RepoListBody(onChanged: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()

    val getExtensionStores = remember { Injekt.get<GetExtensionStores>() }
    val addExtensionStore = remember { Injekt.get<AddExtensionStore>() }
    val removeExtensionStore = remember { Injekt.get<RemoveExtensionStore>() }
    val extensionManager = remember { Injekt.get<ExtensionManager>() }

    var stores by remember { mutableStateOf<List<ExtensionStore>>(emptyList()) }

    LaunchedEffect(Unit) {
        getExtensionStores.subscribe().collectLatest { stores = it }
    }

    var showAddDialog by remember { mutableStateOf(false) }
    var repoToDelete by remember { mutableStateOf<String?>(null) }

    // Per-repo on/off. Which repos exist lives in the extension_store table;
    // which of them are actually fetched is a separate, reversible preference.
    // That way a repo can be parked without losing its metadata or having to be
    // re-added by hand later.
    val repoToggleVersion by com.lorelight.manga.repo.MangaRepoToggles.version.collectAsState()

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "REPOSITORIES (${stores.size})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
                TextButton(onClick = { showAddDialog = true }) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Add Repo")
                }
            }

            if (stores.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No repositories yet. Tap + to add one.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(stores, key = { it.indexUrl }) { store ->
                        val displayName = store.name.ifBlank { deriveRepoName(store.indexUrl) }
                        val repoEnabled = remember(store.indexUrl, repoToggleVersion) {
                            com.lorelight.manga.repo.MangaRepoToggles.isEnabled(store.indexUrl)
                        }

                        ElevatedCard(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // Title row: repo icon + name (Mihon-style header)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 16.dp, top = 14.dp, end = 16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Extension,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Column(
                                    modifier = Modifier
                                        .padding(start = 12.dp)
                                        .weight(1f)
                                ) {
                                    Text(
                                        text = displayName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    val subtitle = if (!repoEnabled) {
                                        "Off - extensions from this repo are hidden"
                                    } else {
                                        store.badgeLabel
                                    }
                                    if (subtitle.isNotBlank()) {
                                        Text(
                                            text = subtitle,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Switch(
                                    checked = repoEnabled,
                                    onCheckedChange = { on ->
                                        com.lorelight.manga.repo.MangaRepoToggles
                                            .setEnabled(store.indexUrl, on)
                                        scope.launch {
                                            runCatching { extensionManager.findAvailableExtensions() }
                                        }
                                        onChanged()
                                    }
                                )
                            }

                            // Action row: website, discord, copy, delete (Mihon-style)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                if (store.contact.website.isNotBlank()) {
                                    IconButton(onClick = {
                                        runCatching {
                                            context.startActivity(
                                                Intent(Intent.ACTION_VIEW, Uri.parse(store.contact.website))
                                            )
                                        }
                                    }) {
                                        Icon(
                                            imageVector = Icons.Filled.Public,
                                            contentDescription = "Open website"
                                        )
                                    }
                                }

                                val discord = store.contact.discord
                                if (!discord.isNullOrBlank()) {
                                    IconButton(onClick = {
                                        runCatching {
                                            context.startActivity(
                                                Intent(Intent.ACTION_VIEW, Uri.parse(discord))
                                            )
                                        }
                                    }) {
                                        Icon(
                                            imageVector = Icons.Filled.Forum,
                                            contentDescription = "Open Discord"
                                        )
                                    }
                                }

                                IconButton(onClick = {
                                    clipboard.setText(AnnotatedString(store.indexUrl))
                                    Toast.makeText(context, "Link copied", Toast.LENGTH_SHORT).show()
                                }) {
                                    Icon(
                                        imageVector = Icons.Filled.ContentCopy,
                                        contentDescription = "Copy repository URL"
                                    )
                                }

                                IconButton(onClick = { repoToDelete = store.indexUrl }) {
                                    Icon(
                                        imageVector = Icons.Filled.Delete,
                                        contentDescription = "Remove repository"
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    val urlToDelete = repoToDelete
    if (urlToDelete != null) {
        val name = stores.find { it.indexUrl == urlToDelete }?.name?.ifBlank { null } ?: deriveRepoName(urlToDelete)
        val isLast = stores.size <= 1

        LorelightDialog(
            onDismissRequest = { repoToDelete = null },
            title = { Text("Remove repository?") },
            text = {
                val message = if (isLast) {
                    "$name\n\nThis is your last repository - the extension list will be empty."
                } else {
                    name
                }
                Text(message)
            },
            isDestructive = true,
            confirmButton = {
                TextButton(
                    onClick = {
                        val target = urlToDelete
                        repoToDelete = null
                        scope.launch {
                            removeExtensionStore(target)
                            extensionManager.findAvailableExtensions()
                        }
                        onChanged()
                    }
                ) {
                    Text("Remove", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { repoToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showAddDialog) {
        var inputUrl by remember { mutableStateOf("") }
        var isAdding by remember { mutableStateOf(false) }
        var errorMessage by remember { mutableStateOf<String?>(null) }

        LorelightDialog(
            onDismissRequest = { if (!isAdding) showAddDialog = false },
            title = { Text("Add Repository") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = inputUrl,
                        onValueChange = { inputUrl = it; errorMessage = null },
                        label = { Text("Repository URL") },
                        singleLine = true,
                        enabled = !isAdding,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (errorMessage != null) {
                        Text(
                            text = errorMessage!!,
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 12.sp
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !isAdding && inputUrl.isNotBlank(),
                    onClick = {
                        val url = inputUrl.trim()
                        scope.launch {
                            isAdding = true
                            errorMessage = null
                            val res = withContext(Dispatchers.IO) {
                                addExtensionStore(url)
                            }
                            isAdding = false
                            res.onSuccess {
                                showAddDialog = false
                                Toast.makeText(context, "Repository added", Toast.LENGTH_SHORT).show()
                                extensionManager.findAvailableExtensions()
                                onChanged()
                            }.onFailure { throwable ->
                                errorMessage = throwable.message ?: "Could not add repository"
                            }
                        }
                    }
                ) {
                    Text(if (isAdding) "Adding..." else "Add")
                }
            },
            dismissButton = {
                TextButton(enabled = !isAdding, onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun MangaRepoScreen(
    onBack: () -> Unit,
    onChanged: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back"
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Extension Repos",
                fontSize = 28.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
        }

        RepoListBody(onChanged = onChanged, modifier = Modifier.weight(1f))
    }
}
