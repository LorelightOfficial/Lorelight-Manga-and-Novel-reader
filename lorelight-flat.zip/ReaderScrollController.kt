package com.lorelight.ui.reader

import androidx.compose.runtime.Composable
import androidx.compose.foundation.gestures.FlingBehavior
import androidx.compose.foundation.gestures.ScrollableDefaults

@Composable
fun rememberPremiumKineticFlingBehavior(): FlingBehavior {
    return ScrollableDefaults.flingBehavior()
}
