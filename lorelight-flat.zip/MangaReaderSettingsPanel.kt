package com.lorelight.manga.reader
import com.lorelight.R
import androidx.compose.ui.res.stringResource


import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.*
import com.lorelight.ui.components.LorelightDialog
import com.lorelight.ui.components.readerSafeTopPadding
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.ui.theme.GlassPanel
import com.lorelight.utils.FilterRule
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.compose.ui.semantics.Role

private val SettingCardRadius = 14.dp
private val SettingCardPadding = 14.dp
private val SettingRowMinHeight = 48.dp
private val SettingGroupGap = 14.dp
private val SettingInnerGap = 12.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun mangaOcrLevelLabel(level: MangaOcrCorrectionLevel): String = when (level) {
    MangaOcrCorrectionLevel.OFF -> stringResource(R.string.manga_ocr_level_off)
    MangaOcrCorrectionLevel.SAFE -> stringResource(R.string.manga_ocr_level_safe)
    MangaOcrCorrectionLevel.BALANCED -> stringResource(R.string.manga_ocr_level_balanced)
    MangaOcrCorrectionLevel.AGGRESSIVE -> stringResource(R.string.manga_ocr_level_aggressive)
}

@Composable
fun mangaOcrLevelSummary(level: MangaOcrCorrectionLevel): String = when (level) {
    MangaOcrCorrectionLevel.OFF -> stringResource(R.string.manga_ocr_summary_off)
    MangaOcrCorrectionLevel.SAFE -> stringResource(R.string.manga_ocr_summary_safe)
    MangaOcrCorrectionLevel.BALANCED -> stringResource(R.string.manga_ocr_summary_balanced)
    MangaOcrCorrectionLevel.AGGRESSIVE -> stringResource(R.string.manga_ocr_summary_aggressive)
}

@Composable
fun MangaReaderSettingsPanel(
    show: Boolean,
    mangaKey: String,
    onDismiss: () -> Unit,
    onShowDemoOverlay: () -> Unit,
    onSettingsChanged: () -> Unit,
    modifier: Modifier = Modifier,
    settingsVersion: Int = 0,
    activeReadingMode: MangaReadingMode = MangaReadingMode.LONG_STRIP
) {
    val context = LocalContext.current
    var showResetDialog by remember { mutableStateOf(false) }
    var resetCounter by remember { mutableIntStateOf(0) }

    var dimTriggerKey by remember { mutableIntStateOf(0) }
    var isDimmed by remember { mutableStateOf(false) }

    LaunchedEffect(dimTriggerKey) {
        if (dimTriggerKey > 0) {
            isDimmed = true
            kotlinx.coroutines.delay(1500)
            isDimmed = false
        }
    }

    val panelAlpha by animateFloatAsState(
        targetValue = if (isDimmed) 0f else 1f,
        animationSpec = tween(durationMillis = 200),
        label = "panelAlpha"
    )

    AnimatedVisibility(
        visible = show,
        enter = slideInHorizontally(
            initialOffsetX = { it },
            animationSpec = tween(260, easing = FastOutSlowInEasing)
        ) + fadeIn(tween(200)),
        exit = slideOutHorizontally(
            targetOffsetX = { it },
            animationSpec = tween(240)
        ) + fadeOut(tween(180)),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(0.55f * panelAlpha))
                .clickable(role = Role.Button) { onDismiss() }
        ) {
            GlassPanel(
                shape = RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp),
                tintAlpha = 0.88f,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .fillMaxWidth(0.88f)
                    .graphicsLayer { alpha = panelAlpha }
                    .clickable(enabled = false) {}
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = readerSafeTopPadding())
                        .padding(horizontal = 20.dp, vertical = 20.dp)
                ) {
                        // Header
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .graphicsLayer { alpha = panelAlpha }
                        ) {
                            Text(
                                text = "Manga Reader Settings",
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = onDismiss) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = stringResource(R.string.reader_font_close),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Scrollable Content
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(SettingGroupGap)
                        ) {
                            // 0. EXPERIMENTAL
                            MangaSettingSection(
                                title = "EXPERIMENTAL",
                                modifier = Modifier.graphicsLayer { alpha = panelAlpha }
                            ) {
                                var experimentalTts by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getExperimentalTts(context)) }
                                var showOcrBoxes by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getShowOcrBoxes(context)) }

                                Column(verticalArrangement = Arrangement.spacedBy(SettingInnerGap)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(stringResource(R.string.manga_reader_tts_toggle), fontSize = 13.sp)
                                            Text(
                                                "Adds a voice button to the reader controls. Reads text off the page and stops when the screen turns off.",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Switch(
                                            checked = experimentalTts,
                                            onCheckedChange = {
                                                experimentalTts = it
                                                MangaReaderPrefs.setExperimentalTts(context, it)
                                                onSettingsChanged()
                                            }
                                        )
                                    }

                                    if (experimentalTts) {
                                        // Voice options, mirroring the novel reader.
                                        MangaTtsVoiceControls()

                                        var ocrLookahead by remember(show, resetCounter) { mutableIntStateOf(MangaReaderPrefs.getOcrLookahead(context)) }

                                        Column {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(stringResource(R.string.manga_reader_ocr_lookahead, ocrLookahead.toString()), fontSize = 13.sp)
                                                    Text(
                                                        "Number of upcoming pages to background OCR concurrently.",
                                                        fontSize = 11.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                            Slider(
                                                value = ocrLookahead.toFloat(),
                                                onValueChange = {
                                                    val newValue = it.toInt().coerceIn(0, 5)
                                                    ocrLookahead = newValue
                                                    MangaReaderPrefs.setOcrLookahead(context, newValue)
                                                    onSettingsChanged()
                                                },
                                                valueRange = 0f..5f,
                                                steps = 4
                                            )
                                        }

                                        var followVoiceTts by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getFollowVoiceTts(context)) }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(stringResource(R.string.manga_reader_follow_voice), fontSize = 13.sp)
                                                Text(
                                                    "Automatically scrolls to center speech bubble when spoken.",
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Switch(
                                                checked = followVoiceTts,
                                                onCheckedChange = {
                                                    followVoiceTts = it
                                                    MangaReaderPrefs.setFollowVoiceTts(context, it)
                                                    onSettingsChanged()
                                                }
                                            )
                                        }

                                        var autocorrectLevel by remember(show, resetCounter) {
                                            mutableStateOf(MangaReaderPrefs.getOcrAutocorrectLevel(context))
                                        }

                                        Column {
                                            Text(stringResource(R.string.manga_reader_fix_misread_words), fontSize = 13.sp)
                                            Text(
                                                "Stylised lettering can be misread, turning \"body\" into \"boby\". Only tokens that are not words get repaired, and the rest of the sentence decides which word fits. Swearing counts as real words and is never swapped out. The page itself and the detected-text overlay are never changed.",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            MangaOcrCorrectionLevel.values().forEach { level ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clickable(role = Role.Button) {
                                                            autocorrectLevel = level
                                                            MangaReaderPrefs.setOcrAutocorrectLevel(context, level)
                                                            onSettingsChanged()
                                                        }
                                                        .padding(vertical = 2.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    RadioButton(
                                                        selected = autocorrectLevel == level,
                                                        onClick = null
                                                    )
                                                    Spacer(modifier = Modifier.width(4.dp))
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(mangaOcrLevelLabel(level), fontSize = 13.sp)
                                                        Text(
                                                            mangaOcrLevelSummary(level),
                                                            fontSize = 11.sp,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        var filterEnabled by remember(show, resetCounter) {
                                            mutableStateOf(MangaReaderPrefs.getTtsFilterEnabled(context))
                                        }
                                        var skipWeb by remember(show, resetCounter) {
                                            mutableStateOf(MangaReaderPrefs.getTtsFilterSkipWebAddresses(context))
                                        }
                                        var filterRules by remember(show, resetCounter) {
                                            mutableStateOf(MangaTtsTextFilter.loadRules(context))
                                        }
                                        var newPhrase by remember(show, resetCounter) { mutableStateOf("") }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(stringResource(R.string.manga_reader_skip_some_text), fontSize = 13.sp)
                                                Text(
                                                    "Leaves chosen words out of the voice, like a site name stamped across the page. The page itself and the detected-text overlay are never changed.",
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Switch(
                                                checked = filterEnabled,
                                                onCheckedChange = {
                                                    filterEnabled = it
                                                    MangaReaderPrefs.setTtsFilterEnabled(context, it)
                                                    onSettingsChanged()
                                                }
                                            )
                                        }

                                        if (filterEnabled) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(stringResource(R.string.manga_reader_skip_links_sites), fontSize = 13.sp)
                                                    Text(
                                                        "Drops things like www.example.com on sight, so you do not have to add a rule for every site.",
                                                        fontSize = 11.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                Switch(
                                                    checked = skipWeb,
                                                    onCheckedChange = {
                                                        skipWeb = it
                                                        MangaReaderPrefs.setTtsFilterSkipWebAddresses(context, it)
                                                        onSettingsChanged()
                                                    }
                                                )
                                            }

                                            Column {
                                                Text(stringResource(R.string.manga_reader_words_to_skip), fontSize = 13.sp)
                                                Text(
                                                    "Manga only. The novel reader keeps its own separate list. Spacing and lookalike characters are ignored when matching.",
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    OutlinedTextField(
                                                        value = newPhrase,
                                                        onValueChange = { newPhrase = it },
                                                        singleLine = true,
                                                        placeholder = {
                                                            Text(stringResource(R.string.manga_reader_words_to_skip_placeholder), fontSize = 12.sp)
                                                        },
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Button(
                                                        onClick = {
                                                            filterRules =
                                                                MangaTtsTextFilter.addRule(context, newPhrase)
                                                            newPhrase = ""
                                                            onSettingsChanged()
                                                        },
                                                        enabled = newPhrase.isNotBlank()
                                                    ) {
                                                        Text(stringResource(R.string.manga_reader_add))
                                                    }
                                                }
                                                if (filterRules.isEmpty()) {
                                                    Text(
                                                        "Nothing added yet.",
                                                        fontSize = 11.sp,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                } else {
                                                    filterRules.forEach { rule: FilterRule ->
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.SpaceBetween,
                                                            verticalAlignment = Alignment.CenterVertically
                                                        ) {
                                                            Text(
                                                                rule.original,
                                                                fontSize = 12.sp,
                                                                modifier = Modifier.weight(1f)
                                                            )
                                                            IconButton(
                                                                onClick = {
                                                                    filterRules = MangaTtsTextFilter
                                                                        .deleteRule(context, rule.id)
                                                                    onSettingsChanged()
                                                                }
                                                            ) {
                                                                Icon(
                                                                    imageVector = Icons.Filled.Close,
                                                                    contentDescription = stringResource(R.string.manga_reader_remove),
                                                                    modifier = Modifier.size(16.dp)
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(stringResource(R.string.manga_reader_show_detected_text), fontSize = 13.sp)
                                                Text(
                                                    "Debug overlay listing what was detected and the order it will be read in.",
                                                    fontSize = 11.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Switch(
                                                checked = showOcrBoxes,
                                                onCheckedChange = {
                                                    showOcrBoxes = it
                                                    MangaReaderPrefs.setShowOcrBoxes(context, it)
                                                    onSettingsChanged()
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            // 1. AUTOSCROLL
                            MangaSettingSection(
                                title = "AUTOSCROLL",
                                modifier = Modifier.graphicsLayer { alpha = panelAlpha }
                            ) {
                                var speed by remember(show, resetCounter) { mutableIntStateOf(MangaReaderPrefs.getAutoscrollSpeed(context)) }
                                var pauseOnTap by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getAutoscrollPauseOnTap(context)) }
                                var resumeDelay by remember(show, resetCounter) { mutableIntStateOf(MangaReaderPrefs.getAutoscrollResumeDelay(context)) }
                                val isLongStrip = activeReadingMode == MangaReadingMode.LONG_STRIP

                                Column(verticalArrangement = Arrangement.spacedBy(SettingInnerGap)) {
                                    if (!isLongStrip) {
                                        Text(
                                            "Autoscroll is only active in Long Strip (Webtoon) mode.",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.outline
                                        )
                                    }

                                    Column {
                                        Text(
                                            "Speed: ${speed} px/s",
                                            fontSize = 13.sp,
                                            color = if (isLongStrip) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                                        )
                                        Text(
                                            "Used for both normal autoscroll and read-aloud.",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.outline
                                        )
                                        Slider(
                                            value = speed.toFloat(),
                                            onValueChange = {
                                                speed = it.toInt()
                                                MangaReaderPrefs.setAutoscrollSpeed(context, it.toInt())
                                                onSettingsChanged()
                                            },
                                            valueRange = 20f..400f,
                                            enabled = isLongStrip
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "Pause on tap",
                                            fontSize = 13.sp,
                                            color = if (isLongStrip) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                                        )
                                        Switch(
                                            checked = pauseOnTap,
                                            onCheckedChange = {
                                                pauseOnTap = it
                                                MangaReaderPrefs.setAutoscrollPauseOnTap(context, it)
                                                onSettingsChanged()
                                            },
                                            enabled = isLongStrip
                                        )
                                    }

                                    Column {
                                        Text(
                                            if (resumeDelay <= 0) "Resume after touch: instantly"
                                            else "Resume after touch: %.1fs".format(resumeDelay / 1000f),
                                            fontSize = 13.sp,
                                            color = if (isLongStrip && !pauseOnTap) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                                        )
                                        Text(
                                            "How long autoscroll waits after you scroll by hand. Each new touch restarts the wait.",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.outline
                                        )
                                        Slider(
                                            value = resumeDelay.toFloat(),
                                            onValueChange = {
                                                resumeDelay = it.toInt()
                                                MangaReaderPrefs.setAutoscrollResumeDelay(context, it.toInt())
                                                onSettingsChanged()
                                            },
                                            valueRange = 0f..10000f,
                                            steps = 19,
                                            enabled = isLongStrip && !pauseOnTap
                                        )
                                    }
                                }
                            }

                            // 2. READING MODE
                            MangaSettingSection(
                                title = "READING MODE",
                                modifier = Modifier.graphicsLayer { alpha = panelAlpha }
                            ) {
                                var currentMode by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getReadingMode(context)) }
                                var isOverride by remember(show, resetCounter, mangaKey) {
                                    mutableStateOf(
                                        if (mangaKey.isNotBlank()) MangaReaderPrefs.getModeOverride(context, mangaKey) != null else false
                                    )
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(SettingInnerGap)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        val modes = listOf(
                                            MangaReadingMode.LONG_STRIP to "Webtoon",
                                            MangaReadingMode.PAGED_LTR to "LTR",
                                            MangaReadingMode.PAGED_RTL to "RTL",
                                            MangaReadingMode.PAGED_VERTICAL to "Vertical"
                                        )
                                        modes.forEach { (mode, label) ->
                                            FilterChip(
                                                selected = (currentMode == mode),
                                                onClick = {
                                                    currentMode = mode
                                                    MangaReaderPrefs.setReadingMode(context, mode)
                                                    if (isOverride && mangaKey.isNotBlank()) {
                                                        MangaReaderPrefs.setModeOverride(context, mangaKey, mode)
                                                    }
                                                    onSettingsChanged()
                                                },
                                                label = { Text(label, fontSize = 11.sp) },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }

                                    if (mangaKey.isNotBlank()) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(stringResource(R.string.manga_reader_use_for_this_manga_only), fontSize = 13.sp)
                                            Switch(
                                                checked = isOverride,
                                                onCheckedChange = { checked ->
                                                    isOverride = checked
                                                    if (checked) {
                                                        MangaReaderPrefs.setModeOverride(context, mangaKey, currentMode)
                                                    } else {
                                                        MangaReaderPrefs.setModeOverride(context, mangaKey, null)
                                                    }
                                                    onSettingsChanged()
                                                }
                                            )
                                        }
                                    }
                                }
                            }

                            // 3. ORIENTATION
                            MangaSettingSection(
                                title = "ORIENTATION",
                                modifier = Modifier.graphicsLayer { alpha = panelAlpha }
                            ) {
                                var orient by remember(show, resetCounter) { mutableIntStateOf(MangaReaderPrefs.getOrientation(context)) }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    val orients = listOf(0 to "Free", 1 to "Portrait", 2 to "Landscape")
                                    orients.forEach { (code, label) ->
                                        FilterChip(
                                            selected = (orient == code),
                                            onClick = {
                                                orient = code
                                                MangaReaderPrefs.setOrientation(context, code)
                                                (context as? Activity)?.requestedOrientation = when (code) {
                                                    1 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                                    2 -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                                    else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                                                }
                                                onSettingsChanged()
                                            },
                                            label = { Text(label, fontSize = 12.sp) },
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }

                            // 4. ZOOM
                            MangaSettingSection(
                                title = "ZOOM",
                                modifier = Modifier.graphicsLayer { alpha = panelAlpha }
                            ) {
                                var disableZoomOut by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getDisableZoomOut(context)) }
                                var doubleTapZoom by remember(show, resetCounter) { mutableIntStateOf(MangaReaderPrefs.getDoubleTapZoom(context)) }
                                var maxZoom by remember(show, resetCounter) { mutableFloatStateOf(MangaReaderPrefs.getMaxZoom(context)) }
                                var scaleType by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getScaleType(context)) }

                                Column(verticalArrangement = Arrangement.spacedBy(SettingInnerGap)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(stringResource(R.string.manga_reader_disable_zoom_out), fontSize = 13.sp)
                                        Switch(
                                            checked = disableZoomOut,
                                            onCheckedChange = {
                                                disableZoomOut = it
                                                MangaReaderPrefs.setDisableZoomOut(context, it)
                                                onSettingsChanged()
                                            }
                                        )
                                    }

                                    Column {
                                        Text(stringResource(R.string.manga_reader_double_tap_zoom), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            listOf(0 to "Off", 2 to "2x", 3 to "3x").forEach { (valCode, label) ->
                                                FilterChip(
                                                    selected = (doubleTapZoom == valCode),
                                                    onClick = {
                                                        doubleTapZoom = valCode
                                                        MangaReaderPrefs.setDoubleTapZoom(context, valCode)
                                                        onSettingsChanged()
                                                    },
                                                    label = { Text(label, fontSize = 12.sp) },
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }
                                        }
                                    }

                                    Column {
                                        Text(stringResource(R.string.manga_reader_max_pinch_zoom, "%.1f".format(maxZoom)), fontSize = 13.sp)
                                        Slider(
                                            value = maxZoom,
                                            onValueChange = {
                                                maxZoom = it
                                                MangaReaderPrefs.setMaxZoom(context, it)
                                                onSettingsChanged()
                                            },
                                            valueRange = 2f..5f,
                                            steps = 5
                                        )
                                    }

                                    Column {
                                        Text(stringResource(R.string.manga_reader_scale_type), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            listOf("Fit width", "Fit height", "Fit screen").forEach { type ->
                                                FilterChip(
                                                    selected = (scaleType == type),
                                                    onClick = {
                                                        scaleType = type
                                                        MangaReaderPrefs.setScaleType(context, type)
                                                        onSettingsChanged()
                                                    },
                                                    label = { Text(type, fontSize = 11.sp) },
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // 5. LAYOUT
                            MangaSettingSection(
                                title = "LAYOUT",
                                modifier = Modifier.graphicsLayer { alpha = panelAlpha }
                            ) {
                                var sidePadding by remember(show, resetCounter) { mutableIntStateOf(MangaReaderPrefs.getSidePadding(context)) }
                                var pageGap by remember(show, resetCounter) { mutableIntStateOf(MangaReaderPrefs.getPageGap(context)) }

                                Column(verticalArrangement = Arrangement.spacedBy(SettingInnerGap)) {
                                    Column {
                                        Text(stringResource(R.string.manga_reader_side_padding, sidePadding.toString()), fontSize = 13.sp)
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            listOf(0, 5, 10, 15, 20, 25).forEach { percent ->
                                                FilterChip(
                                                    selected = (sidePadding == percent),
                                                    onClick = {
                                                        sidePadding = percent
                                                        MangaReaderPrefs.setSidePadding(context, percent)
                                                        onSettingsChanged()
                                                    },
                                                    label = { Text(stringResource(R.string.manga_reader_percent_label, percent.toString()), fontSize = 10.sp) }
                                                )
                                            }
                                        }
                                    }

                                    Column {
                                        Text(stringResource(R.string.manga_reader_page_gap, pageGap.toString()), fontSize = 13.sp)
                                        Slider(
                                            value = pageGap.toFloat(),
                                            onValueChange = {
                                                pageGap = it.toInt()
                                                MangaReaderPrefs.setPageGap(context, it.toInt())
                                                onSettingsChanged()
                                            },
                                            valueRange = 0f..24f,
                                            steps = 23
                                        )
                                    }
                                }
                            }

                            // 6. TAP ZONES
                            MangaSettingSection(
                                title = "TAP ZONES",
                                modifier = Modifier.graphicsLayer { alpha = 1f }
                            ) {
                                var zoneLayout by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getTapZoneLayout(context)) }
                                var zoneInvert by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getTapZoneInvert(context)) }
                                var showOverlayOnOpen by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getShowZoneOverlayOnOpen(context)) }
                                var volumeKeyNav by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getVolumeKeyNav(context)) }
                                var invertVolumeKeys by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getInvertVolumeKeys(context)) }

                                Column(verticalArrangement = Arrangement.spacedBy(SettingInnerGap)) {
                                    Column {
                                        Text(stringResource(R.string.manga_reader_tap_zone_layout), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        val layouts = listOf(
                                            MangaTapZoneLayout.DISABLED to "Disabled",
                                            MangaTapZoneLayout.L_SHAPE to "L-shape",
                                            MangaTapZoneLayout.KINDLISH to "Kindle-ish",
                                            MangaTapZoneLayout.EDGE to "Edge",
                                            MangaTapZoneLayout.RIGHT_AND_LEFT to "Right & Left"
                                        )
                                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                            layouts.chunked(3).forEach { chunk ->
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                                ) {
                                                    chunk.forEach { (layout, label) ->
                                                        FilterChip(
                                                            selected = (zoneLayout == layout),
                                                            onClick = {
                                                                zoneLayout = layout
                                                                MangaReaderPrefs.setTapZoneLayout(context, layout)
                                                                onSettingsChanged()
                                                                dimTriggerKey++
                                                                onShowDemoOverlay()
                                                            },
                                                            label = { Text(label, fontSize = 11.sp) },
                                                            modifier = Modifier.weight(1f)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    Column {
                                        Text(stringResource(R.string.manga_reader_invert_tap_zones), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            val inverts = listOf(
                                                MangaTapInvert.NONE to "None",
                                                MangaTapInvert.HORIZONTAL to "Horiz",
                                                MangaTapInvert.VERTICAL to "Vert",
                                                MangaTapInvert.BOTH to "Both"
                                            )
                                            inverts.forEach { (inv, label) ->
                                                FilterChip(
                                                    selected = (zoneInvert == inv),
                                                    onClick = {
                                                        zoneInvert = inv
                                                        MangaReaderPrefs.setTapZoneInvert(context, inv)
                                                        onSettingsChanged()
                                                        dimTriggerKey++
                                                        onShowDemoOverlay()
                                                    },
                                                    label = { Text(label, fontSize = 11.sp) },
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(stringResource(R.string.manga_reader_show_zone_overlay), fontSize = 13.sp)
                                        Switch(
                                            checked = showOverlayOnOpen,
                                            onCheckedChange = {
                                                showOverlayOnOpen = it
                                                MangaReaderPrefs.setShowZoneOverlayOnOpen(context, it)
                                                onSettingsChanged()
                                            }
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(stringResource(R.string.manga_reader_volume_keys_turn_page), fontSize = 13.sp)
                                        Switch(
                                            checked = volumeKeyNav,
                                            onCheckedChange = {
                                                volumeKeyNav = it
                                                MangaReaderPrefs.setVolumeKeyNav(context, it)
                                                onSettingsChanged()
                                            }
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(stringResource(R.string.manga_reader_invert_volume_keys), fontSize = 13.sp)
                                        Switch(
                                            checked = invertVolumeKeys,
                                            onCheckedChange = {
                                                invertVolumeKeys = it
                                                MangaReaderPrefs.setInvertVolumeKeys(context, it)
                                                onSettingsChanged()
                                            }
                                        )
                                    }
                                }
                            }

                            // 7. APPEARANCE
                            MangaSettingSection(
                                title = "APPEARANCE",
                                modifier = Modifier.graphicsLayer { alpha = panelAlpha }
                            ) {
                                var bgType by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getReaderBackgroundType(context)) }
                                var brightnessOverlay by remember(show, resetCounter) { mutableIntStateOf(MangaReaderPrefs.getBrightnessOverlay(context)) }
                                var grayscale by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getGrayscale(context)) }
                                var invertColors by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getInvertColors(context)) }
                                var keepScreenOn by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getKeepScreenOn(context)) }
                                var fullscreen by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getFullscreen(context)) }
                                var showPageNumber by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getShowPageNumber(context)) }
                                var showPageSlider by remember(show, resetCounter) { mutableStateOf(MangaReaderPrefs.getShowPageSlider(context)) }

                                Column(verticalArrangement = Arrangement.spacedBy(SettingInnerGap)) {
                                    Column {
                                        Text(stringResource(R.string.manga_reader_background), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            listOf("Theme", "AMOLED Black").forEach { bType ->
                                                FilterChip(
                                                    selected = (bgType == bType),
                                                    onClick = {
                                                        bgType = bType
                                                        MangaReaderPrefs.setReaderBackgroundType(context, bType)
                                                        onSettingsChanged()
                                                    },
                                                    label = { Text(bType, fontSize = 12.sp) },
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }
                                        }
                                    }

                                    Column {
                                        Text(stringResource(R.string.manga_reader_brightness_overlay, if (brightnessOverlay > 0) "+$brightnessOverlay%" else "$brightnessOverlay%"), fontSize = 13.sp)
                                        Slider(
                                            value = brightnessOverlay.toFloat(),
                                            onValueChange = {
                                                brightnessOverlay = it.toInt()
                                                MangaReaderPrefs.setBrightnessOverlay(context, it.toInt())
                                                onSettingsChanged()
                                            },
                                            valueRange = -75f..25f
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(stringResource(R.string.manga_reader_grayscale), fontSize = 13.sp)
                                        Switch(
                                            checked = grayscale,
                                            onCheckedChange = {
                                                grayscale = it
                                                MangaReaderPrefs.setGrayscale(context, it)
                                                onSettingsChanged()
                                            }
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(stringResource(R.string.manga_reader_invert_colors), fontSize = 13.sp)
                                        Switch(
                                            checked = invertColors,
                                            onCheckedChange = {
                                                invertColors = it
                                                MangaReaderPrefs.setInvertColors(context, it)
                                                onSettingsChanged()
                                            }
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(stringResource(R.string.manga_reader_keep_screen_on), fontSize = 13.sp)
                                        Switch(
                                            checked = keepScreenOn,
                                            onCheckedChange = {
                                                keepScreenOn = it
                                                MangaReaderPrefs.setKeepScreenOn(context, it)
                                                onSettingsChanged()
                                            }
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(stringResource(R.string.manga_reader_fullscreen_hide_bars), fontSize = 13.sp)
                                        Switch(
                                            checked = fullscreen,
                                            onCheckedChange = {
                                                fullscreen = it
                                                MangaReaderPrefs.setFullscreen(context, it)
                                                (context as? Activity)?.window?.let { window ->
                                                    val controller = WindowCompat.getInsetsController(window, window.decorView)
                                                    if (it) {
                                                        controller.hide(WindowInsetsCompat.Type.systemBars())
                                                        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                                                    } else {
                                                        controller.show(WindowInsetsCompat.Type.systemBars())
                                                    }
                                                }
                                                onSettingsChanged()
                                            }
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(stringResource(R.string.manga_reader_show_page_number), fontSize = 13.sp)
                                        Switch(
                                            checked = showPageNumber,
                                            onCheckedChange = {
                                                showPageNumber = it
                                                MangaReaderPrefs.setShowPageNumber(context, it)
                                                onSettingsChanged()
                                            }
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(stringResource(R.string.manga_reader_show_page_slider), fontSize = 13.sp)
                                        Switch(
                                            checked = showPageSlider,
                                            onCheckedChange = {
                                                showPageSlider = it
                                                MangaReaderPrefs.setShowPageSlider(context, it)
                                                onSettingsChanged()
                                            }
                                        )
                                    }
                                }
                            }

                            // 8. ADVANCED
                            MangaSettingSection(
                                title = "ADVANCED",
                                modifier = Modifier.graphicsLayer { alpha = panelAlpha }
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(SettingInnerGap)) {
                                    // The "Pages to load ahead" and "Pages at the
                                    // same time" sliders were removed. Mihon has
                                    // neither: preload depth is a constant and
                                    // downloads are always serial. Exposing them
                                    // only made it possible to make loading worse.
                                    Column {
                                        Text(stringResource(R.string.manga_reader_restart_stuck_loads), fontSize = 13.sp)
                                        Text(
                                            "Throws away every half-finished page download and asks for those pages again, and gives the next chapter another try. Pages that already loaded are kept. Use this when the reader is stuck on a weak connection.",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.outline
                                        )
                                        Spacer(Modifier.height(6.dp))
                                        Button(
                                            onClick = {
                                                MangaPageRetryBus.resetStalled(context)
                                                // Close the panel so the pages
                                                // being retried are visible.
                                                onDismiss()
                                            },
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(stringResource(R.string.manga_reader_restart_stuck_loads))
                                        }
                                    }

                                    Button(
                                        onClick = { showResetDialog = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(stringResource(R.string.manga_reader_reset_all_settings))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

    if (showResetDialog) {
        LorelightDialog(
            onDismissRequest = { showResetDialog = false },
            title = { Text(stringResource(R.string.manga_reader_reset_settings_title)) },
            text = { Text(stringResource(R.string.manga_reader_reset_settings_body)) },
            isDestructive = true,
            confirmButton = {
                TextButton(
                    onClick = {
                        MangaReaderPrefs.resetToDefaults(context)
                        resetCounter++
                        showResetDialog = false
                        onSettingsChanged()
                    }
                ) {
                    Text(stringResource(R.string.manga_reader_reset_confirm))
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetDialog = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }
}

@Composable
private fun MangaSettingSection(
    title: String,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = title,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.8.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
        )
        Surface(
            shape = RoundedCornerShape(SettingCardRadius),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(SettingCardPadding)
            ) {
                content()
            }
        }
    }
}
