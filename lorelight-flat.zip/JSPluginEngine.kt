package com.lorelight.browse.js

// ================= WRAPPER API CONTRACT (verify against quickjs-wrapper 3.2.3) =================
// Package:              com.whl.quickjs.wrapper
// QuickJSContext.create(): QuickJSContext
// ctx.getGlobalObject(): JSObject
// ctx.createNewJSObject(): JSObject
// ctx.evaluate(String): Any?      // MUST drain the pending promise-job queue afterward
// ctx.destroy()
// JSObject.setProperty(String, JSCallFunction)
// JSObject.setProperty(String, String)
// JSObject.setProperty(String, JSObject)
// JSCallFunction: functional interface -> Any? call(Array<out Any?> args)  [Java: Object call(Object... args)]
// If the base API differs, adjust ONLY the marked calls. pump() is the one README-dependent spot.
// ==============================================================================================

import android.content.Context
import android.util.Log
import android.util.LruCache
import com.lorelight.browse.model.FilterDef
import com.lorelight.browse.model.SourceChapter
import com.lorelight.browse.model.SourceNovelDetails
import com.lorelight.browse.model.SourceNovelItem
import com.lorelight.browse.repo.PluginManager
import com.whl.quickjs.wrapper.JSCallFunction
import com.whl.quickjs.wrapper.QuickJSContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExecutorCoroutineDispatcher
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

class PluginException(pluginId: String, message: String) : Exception("[$pluginId] $message")

data class PluginMeta(val id: String, val name: String, val site: String, val version: String, val hasFilters: Boolean)

private fun aStr(a: Array<out Any?>?, i: Int): String = a?.getOrNull(i)?.toString() ?: ""
private fun aInt(a: Array<out Any?>?, i: Int): Int = (a?.getOrNull(i) as? Number)?.toInt() ?: 0
private fun aLong(a: Array<out Any?>?, i: Int): Long = (a?.getOrNull(i) as? Number)?.toLong() ?: 0L

object JSPluginEngine {

    private val cache = object : LruCache<String, PluginContext>(5) {
        override fun entryRemoved(evicted: Boolean, key: String, oldValue: PluginContext, newValue: PluginContext?) {
            if (oldValue !== newValue) oldValue.destroy()
        }
    }
    private val cacheLock = Any()
    private val creationLocks = java.util.concurrent.ConcurrentHashMap<String, Mutex>()

    fun evict(pluginId: String) { synchronized(cacheLock) { cache.remove(pluginId) } }

    private suspend fun getOrCreate(appContext: Context, pluginId: String): PluginContext {
        synchronized(cacheLock) { cache.get(pluginId) }?.let { return it }
        val lock = creationLocks.getOrPut(pluginId) { Mutex() }
        return lock.withLock {
            // Another caller may have finished building it while we were
            // waiting for the lock — reuse it instead of building a second one.
            synchronized(cacheLock) { cache.get(pluginId) }?.let { return@withLock it }
            val dispatcher = Executors.newSingleThreadExecutor { r -> Thread(r, "lorelight-js-$pluginId") }.asCoroutineDispatcher()
            val app = appContext.applicationContext
            val pc = withContext(dispatcher) {
                try {
                    com.whl.quickjs.android.QuickJSLoader.init()
                } catch (e: Throwable) {
                    try {
                        System.loadLibrary("quickjs")
                    } catch (e2: Throwable) {
                        Log.w("JSPluginEngine", "QuickJS native library load warning: ${e.message} | ${e2.message}")
                    }
                }
                val ctx = QuickJSContext.create()          // WRAPPER
                val pcx = PluginContext(pluginId, ctx, dispatcher, CheerioBridge())
                // FIX A5: tell the bridge which plugin owns it, so storage
                // access cannot be redirected to another plugin's namespace.
                pcx.jsBridge = JSBridge(app, pcx, pluginId)
                pcx.install(app, pluginId)
                pcx
            }
            synchronized(cacheLock) { cache.put(pluginId, pc) }
            pc
        }
    }

    private fun errWrap(token: Int) =
        ".catch(function(e){__native.deliverError($token,__errStr(e));});}" +
        "catch(e){__native.deliverError($token,__errStr(e));}})();"

    suspend fun popularNovels(appContext: Context, pluginId: String, page: Int, showLatest: Boolean, filterValuesJson: String? = null): List<SourceNovelItem> {
        val pc = getOrCreate(appContext, pluginId)
        val site = try { pc.evalString("__plugin.site||''") } catch (e: Exception) { "" }
        val filters = filterValuesJson ?: "{}"
        val json = try {
            pc.invokeAsync { t ->
                "(function(){try{var __fv=$filters;" +
                "var __o={showLatestNovels:$showLatest,filters:(__fv&&Object.keys(__fv).length)?__fv:__defaultFilters()};" +
                "Promise.resolve(__plugin.popularNovels($page,__o))" +
                ".then(function(r){__native.deliver($t,JSON.stringify(r));})" + errWrap(t)
            }
        } finally {
            pc.disposeCheerio()
        }
        return parseItems(json, site)
    }

    suspend fun searchNovels(appContext: Context, pluginId: String, query: String, page: Int): List<SourceNovelItem> {
        val pc = getOrCreate(appContext, pluginId)
        val site = try { pc.evalString("__plugin.site||''") } catch (e: Exception) { "" }
        val q = JSONObject.quote(query)
        val json = try {
            pc.invokeAsync { t ->
                "(function(){try{Promise.resolve(__plugin.searchNovels($q,$page))" +
                ".then(function(r){__native.deliver($t,JSON.stringify(r));})" + errWrap(t)
            }
        } finally {
            pc.disposeCheerio()
        }
        return parseItems(json, site)
    }

    suspend fun parseNovel(appContext: Context, pluginId: String, path: String): SourceNovelDetails {
        val pc = getOrCreate(appContext, pluginId)
        val site = try { pc.evalString("__plugin.site||''") } catch (e: Exception) { "" }
        val p = JSONObject.quote(path)
        val json = try {
            pc.invokeAsync { t ->
                "(function(){try{Promise.resolve(__plugin.parseNovel($p))" +
                ".then(function(r){__native.deliver($t,JSON.stringify(r));})" + errWrap(t)
            }
        } finally {
            pc.disposeCheerio()
        }
        return parseDetails(json, path, site)
    }

    suspend fun parseChapter(appContext: Context, pluginId: String, path: String): String {
        val pc = getOrCreate(appContext, pluginId)
        val p = JSONObject.quote(path)
        val json = try {
            pc.invokeAsync { t ->
                "(function(){try{Promise.resolve(__plugin.parseChapter($p))" +
                ".then(function(r){__native.deliver($t,JSON.stringify(r));})" + errWrap(t)
            }
        } finally {
            pc.disposeCheerio()
        }
        return decodeString(json)
    }

    suspend fun getFilters(appContext: Context, pluginId: String): List<FilterDef> {
        val pc = getOrCreate(appContext, pluginId)
        return parseFilters(pc.evalString("JSON.stringify(__plugin.filters||{})"))
    }

    suspend fun resolveUrl(appContext: Context, pluginId: String, path: String, isNovel: Boolean): String {
        val pc = getOrCreate(appContext, pluginId)
        val p = JSONObject.quote(path)
        val js = "(function(){var p=$p;return (typeof __plugin.resolveUrl==='function')?String(__plugin.resolveUrl(p,$isNovel)):String((__plugin.site||'')+p);})()"
        return pc.evalString(js).ifEmpty { path }
    }

    suspend fun getMeta(appContext: Context, pluginId: String): PluginMeta {
        val pc = getOrCreate(appContext, pluginId)
        val s = pc.evalString("JSON.stringify({id:__plugin.id,name:__plugin.name,site:__plugin.site,version:__plugin.version,hasFilters:!!(__plugin.filters&&Object.keys(__plugin.filters).length)})")
        val o = try { JSONObject(s) } catch (e: Exception) { JSONObject() }
        return PluginMeta(o.optString("id", pluginId), o.optString("name", pluginId), o.optString("site", ""), o.optString("version", ""), o.optBoolean("hasFilters", false))
    }

    // ---------- result parsing ----------
    private fun parseItems(json: String, site: String = ""): List<SourceNovelItem> {
        val arr = try { JSONArray(json) } catch (e: Exception) { return emptyList() }
        val out = ArrayList<SourceNovelItem>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val name = o.optString("name", "")
            val path = o.optString("path", "")
            if (name.isEmpty() || path.isEmpty()) continue
            var cover = o.optString("cover", "").ifEmpty { null }
            if (cover != null) {
                if (cover.startsWith("//")) {
                    cover = "https:$cover"
                } else if (cover.startsWith("/") && site.isNotBlank()) {
                    cover = "${site.trimEnd('/')}/$cover"
                }
            }
            out.add(SourceNovelItem(name, path, cover))
        }
        return out
    }

    private fun parseDetails(json: String, fallbackPath: String, site: String = ""): SourceNovelDetails {
        val o = try { JSONObject(json) } catch (e: Exception) { JSONObject() }
        val chapters = ArrayList<SourceChapter>()
        val chArr = o.optJSONArray("chapters")
        if (chArr != null) {
            for (i in 0 until chArr.length()) {
                val c = chArr.optJSONObject(i) ?: continue
                val path = c.optString("path", "")
                if (path.isEmpty()) continue
                val num = if (c.has("chapterNumber") && !c.isNull("chapterNumber")) c.optInt("chapterNumber") else null
                chapters.add(SourceChapter(c.optString("name", ""), path, c.optString("releaseTime", "").ifEmpty { null }, num))
            }
        }
        var cover = o.optString("cover", "").ifEmpty { null }
        if (cover != null) {
            if (cover.startsWith("//")) {
                cover = "https:$cover"
            } else if (cover.startsWith("/") && site.isNotBlank()) {
                cover = "${site.trimEnd('/')}/$cover"
            }
        }
        return SourceNovelDetails(
            path = o.optString("path", fallbackPath).ifEmpty { fallbackPath },
            name = o.optString("name", ""),
            cover = cover,
            genres = o.optString("genres", "").ifEmpty { null },
            summary = o.optString("summary", "").ifEmpty { null },
            author = o.optString("author", "").ifEmpty { null },
            status = o.optString("status", "").ifEmpty { null },
            chapters = chapters
        )
    }

    private fun decodeString(json: String): String =
        try { JSONTokener(json).nextValue()?.toString() ?: "" } catch (e: Exception) { "" }

    private fun parseOptions(arr: JSONArray?): List<Pair<String, String>> {
        if (arr == null) return emptyList()
        val out = ArrayList<Pair<String, String>>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i)
            if (o != null) out.add(o.optString("label", o.optString("value", "")) to o.optString("value", ""))
            else { val s = arr.optString(i, ""); if (s.isNotEmpty()) out.add(s to s) }
        }
        return out
    }

    private fun jsonStrList(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { arr.optString(it, "") }.filter { it.isNotEmpty() }
    }

    private fun parseFilters(json: String): List<FilterDef> {
        val root = try { JSONObject(json) } catch (e: Exception) { return emptyList() }
        val out = ArrayList<FilterDef>()
        val keys = root.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val f = root.optJSONObject(key) ?: continue
            val label = f.optString("label", key)
            val options = parseOptions(f.optJSONArray("options"))
            when (f.optString("type", "")) {
                "Text" -> out.add(FilterDef.TextInput(key, label, f.optString("value", "")))
                "Picker" -> out.add(FilterDef.Picker(key, label, options, f.optString("value", options.firstOrNull()?.second ?: "")))
                "Checkbox" -> out.add(FilterDef.CheckboxGroup(key, label, options, jsonStrList(f.optJSONArray("value"))))
                "Switch" -> out.add(FilterDef.Switch(key, label, f.optBoolean("value", false)))
                "XCheckbox" -> {
                    val v = f.optJSONObject("value")
                    out.add(FilterDef.ExcludableCheckboxGroup(key, label, options, jsonStrList(v?.optJSONArray("include")), jsonStrList(v?.optJSONArray("exclude"))))
                }
            }
        }
        return out
    }

    // ================= per-plugin QuickJS context =================
    private class PluginContext(
        val pluginId: String,
        val ctx: QuickJSContext,
        val dispatcher: ExecutorCoroutineDispatcher,
        val cheerio: CheerioBridge
    ) : JsRuntimeHost {

        private val supervisor = SupervisorJob()
        override val scope: CoroutineScope = CoroutineScope(dispatcher + supervisor)

        lateinit var jsBridge: JSBridge
        private val deferreds = ConcurrentHashMap<Int, CompletableDeferred<String>>()
        private var tokenSeq = 1

        fun install(appContext: Context, pluginId: String) {
            val global = ctx.getGlobalObject()          // WRAPPER
            val n = ctx.createNewJSObject()             // WRAPPER
            n.setProperty("log", JSCallFunction { a -> jsBridge.log(aStr(a, 0)); null })
            n.setProperty("fetch", JSCallFunction { a -> jsBridge.fetch(aStr(a, 0), aStr(a, 1), aInt(a, 2)); null })
            n.setProperty("setTimeoutNative", JSCallFunction { a -> jsBridge.setTimeoutNative(aInt(a, 0), aLong(a, 1)); null })
            n.setProperty("storageGet", JSCallFunction { a -> jsBridge.storageGet(aStr(a, 0), aStr(a, 1)) })
            n.setProperty("storageSet", JSCallFunction { a -> jsBridge.storageSet(aStr(a, 0), aStr(a, 1), aStr(a, 2)); null })
            n.setProperty("storageDelete", JSCallFunction { a -> jsBridge.storageDelete(aStr(a, 0), aStr(a, 1)); null })
            n.setProperty("storageKeys", JSCallFunction { a -> jsBridge.storageKeys(aStr(a, 0)) })
            n.setProperty("storageClear", JSCallFunction { a -> jsBridge.storageClear(aStr(a, 0)); null })
            n.setProperty("deliver", JSCallFunction { a -> deliver(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("deliverError", JSCallFunction { a -> deliverError(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioParse", JSCallFunction { a -> cheerio.parse(aStr(a, 0)) })
            n.setProperty("htmlparse", com.whl.quickjs.wrapper.JSCallFunction { args ->
                htmlToEvents(if (args.isNotEmpty() && args[0] != null) args[0].toString() else "")
            })
            n.setProperty("cheerioSelect", JSCallFunction { a -> cheerio.select(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioChildren", JSCallFunction { a -> cheerio.children(aInt(a, 0)) })
            n.setProperty("cheerioChildrenSelector", JSCallFunction { a -> cheerio.childrenSelector(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioContents", JSCallFunction { a -> cheerio.contents(aInt(a, 0)) })
            n.setProperty("cheerioText", JSCallFunction { a -> cheerio.text(aInt(a, 0)) })
            n.setProperty("cheerioHtml", JSCallFunction { a -> cheerio.html(aInt(a, 0)) })
            n.setProperty("cheerioOuterHtml", JSCallFunction { a -> cheerio.outerHtml(aInt(a, 0)) })
            n.setProperty("cheerioAttr", JSCallFunction { a -> cheerio.attr(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioSetAttr", JSCallFunction { a -> cheerio.setAttr(aInt(a, 0), aStr(a, 1), aStr(a, 2)); null })
            n.setProperty("cheerioProp", JSCallFunction { a -> cheerio.prop(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioData", JSCallFunction { a -> cheerio.data(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioVal", JSCallFunction { a -> cheerio.value(aInt(a, 0)) })
            n.setProperty("cheerioHasClass", JSCallFunction { a -> cheerio.hasClass(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioAddClass", JSCallFunction { a -> cheerio.addClass(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioRemoveClass", JSCallFunction { a -> cheerio.removeClass(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioRemove", JSCallFunction { a -> cheerio.remove(aInt(a, 0)); null })
            n.setProperty("cheerioParent", JSCallFunction { a -> cheerio.parent(aInt(a, 0)) })
            n.setProperty("cheerioParents", JSCallFunction { a -> cheerio.parents(aInt(a, 0)) })
            n.setProperty("cheerioClosest", JSCallFunction { a -> cheerio.closest(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioNext", JSCallFunction { a -> cheerio.next(aInt(a, 0)) })
            n.setProperty("cheerioNextAll", JSCallFunction { a -> cheerio.nextAll(aInt(a, 0)) })
            n.setProperty("cheerioPrev", JSCallFunction { a -> cheerio.prev(aInt(a, 0)) })
            n.setProperty("cheerioPrevAll", JSCallFunction { a -> cheerio.prevAll(aInt(a, 0)) })
            n.setProperty("cheerioSiblings", JSCallFunction { a -> cheerio.siblings(aInt(a, 0)) })
            n.setProperty("cheerioIs", JSCallFunction { a -> cheerio.isMatch(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioReplaceWith", JSCallFunction { a -> cheerio.replaceWith(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioBefore", JSCallFunction { a -> cheerio.before(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioAfter", JSCallFunction { a -> cheerio.after(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioAppend", JSCallFunction { a -> cheerio.append(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioPrepend", JSCallFunction { a -> cheerio.prepend(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioEmpty", JSCallFunction { a -> cheerio.empty(aInt(a, 0)); null })
            n.setProperty("cheerioCss", JSCallFunction { a -> cheerio.css(aInt(a, 0), aStr(a, 1)) })
            global.setProperty("__native", n)

            ctx.evaluate(
                "globalThis.__errStr=function(e){try{var n=(e&&e.name)?e.name:'Error';" +
                "var m=(e&&e.message!==undefined&&e.message!==null)?String(e.message):String(e);" +
                "var s=(e&&e.stack)?('\\n'+e.stack):'';return n+': '+m+s;}catch(_){return String(e);}};",
                "errstr.js"
            )

            ctx.evaluate(
                "globalThis.__defaultFilters=function(){var out={};" +
                "var f=(typeof __plugin!=='undefined'&&__plugin)?__plugin.filters:null;" +
                "if(f){for(var k in f){if(f.hasOwnProperty(k)){out[k]={value:f[k].value,type:f[k].type};}}}" +
                "return out;};",
                "deffilters.js"
            )

            evalAsset(appContext, "polyfill.js")
            evalAsset(appContext, "url-polyfill.js")
            evalAsset(appContext, "require.js")
            evalAsset(appContext, "cheerio-shim.js")
            evalAsset(appContext, "libs-shims.js")
            evalAsset(appContext, "htmlparser2-shim.js")
            evalAsset(appContext, "dayjs.min.js")
            ctx.evaluate("if (typeof dayjs !== 'undefined') { __registerModule('dayjs', function(m){ m.exports = dayjs; }); }")
            evalAsset(appContext, "urlencode.js")
            evalAsset(appContext, "qs-shim.js")

            global.setProperty("__pluginId", pluginId)

            val src = PluginManager.pluginFile(appContext, pluginId).readText()
            val wrapper = "var module={exports:{}};var exports=module.exports;\n" +
                "(function(module,exports,require){\n" + src + "\n})(module,exports,require);\n" +
                "globalThis.__plugin=module.exports.default||module.exports;"
            ctx.evaluate(wrapper, "plugin_" + pluginId + ".js")
        }

        private fun evalAsset(appContext: Context, name: String) {
            val js = appContext.assets.open("browse-js/$name").bufferedReader().use { it.readText() }
            ctx.evaluate(js, name)   // WRAPPER
        }

        // README-DEPENDENT: assumes ctx.evaluate drains the promise-job queue.
        // If 3.2.3 exposes an explicit pending-job executor, loop it here instead.
        private fun pump() {
            try { ctx.evaluate("void 0") } catch (e: Exception) { Log.d("LorelightJS", "pump: ${e.message}") }
        }

        fun deliver(token: Int, json: String) { deferreds.remove(token)?.complete(json) }
        fun deliverError(token: Int, message: String) { deferreds.remove(token)?.completeExceptionally(PluginException(pluginId, message)) }

        @Volatile private var destroyed = false

        override fun postFetchResult(token: Int, rawJson: String) {
            scope.launch {
                if (destroyed) return@launch
                try {
                    // Passing the body as a global property avoids making QuickJS
                    // lex and parse the entire (potentially huge) response as
                    // source text on every single fetch.
                    ctx.getGlobalObject().setProperty("__pendingFetchJson", rawJson)
                    ctx.evaluate("globalThis.__fetchResolve($token,globalThis.__pendingFetchJson);")
                    pump()
                } catch (e: Exception) { deliverError(token, e.message ?: e.toString()) }
            }
        }
        override fun postFetchError(token: Int, message: String) {
            scope.launch { if (destroyed) return@launch; try { ctx.evaluate("globalThis.__fetchReject($token,${JSONObject.quote(message)});"); pump() } catch (e: Exception) { deliverError(token, message) } }
        }
        override fun postTimeout(id: Int) {
            scope.launch { if (destroyed) return@launch; try { ctx.evaluate("globalThis.__timeoutFire($id);"); pump() } catch (e: Exception) { Log.d("LorelightJS", "timeout: ${e.message}") } }
        }

        suspend fun invokeAsync(build: (Int) -> String): String = withContext(dispatcher) {
            val token = tokenSeq++
            val d = CompletableDeferred<String>()
            deferreds[token] = d
            try { ctx.evaluate(build(token)); pump() }
            catch (e: Exception) { deferreds.remove(token); throw PluginException(pluginId, e.message ?: e.toString()) }
            // A single fetch can legitimately need rate-limit wait + connect/read
            // timeout + 429 backoff, and some plugins fetch more than once per
            // call. 30s was below that worst case and produced false timeouts.
            try { withTimeout(75_000) { d.await() } } finally { deferreds.remove(token) }
        }

        suspend fun evalString(js: String): String = withContext(dispatcher) { (ctx.evaluate(js) as? String) ?: "" }

        suspend fun disposeCheerio() = withContext(dispatcher) { cheerio.disposeAll() }

        private fun htmlToEvents(html: String): String {
            return try {
                val doc = org.jsoup.Jsoup.parse(html)
                val arr = org.json.JSONArray()
                val visitor = object : org.jsoup.select.NodeVisitor {
                    override fun head(node: org.jsoup.nodes.Node, depth: Int) {
                        when (node) {
                            is org.jsoup.nodes.Document -> {}
                            is org.jsoup.nodes.Element -> {
                                val o = org.json.JSONObject()
                                o.put("t", 0); o.put("n", node.normalName())
                                val a = org.json.JSONObject()
                                for (attr in node.attributes()) a.put(attr.key, attr.value)
                                o.put("a", a)
                                arr.put(o)
                            }
                            is org.jsoup.nodes.TextNode -> {
                                val o = org.json.JSONObject(); o.put("t", 1); o.put("x", node.wholeText); arr.put(o)
                            }
                            is org.jsoup.nodes.Comment -> {
                                val o = org.json.JSONObject(); o.put("t", 3); o.put("x", node.data); arr.put(o)
                            }
                            else -> {}
                        }
                    }
                    override fun tail(node: org.jsoup.nodes.Node, depth: Int) {
                        if (node is org.jsoup.nodes.Element && node !is org.jsoup.nodes.Document) {
                            val o = org.json.JSONObject(); o.put("t", 2); o.put("n", node.normalName()); arr.put(o)
                        }
                    }
                }
                org.jsoup.select.NodeTraversor.traverse(visitor, doc)
                arr.toString()
            } catch (e: Exception) { "[]" }
        }

        fun destroy() {
            destroyed = true
            scope.launch { try { cheerio.disposeAll(); ctx.destroy() } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError("JSPluginEngine.destroy", e) } }
                .invokeOnCompletion {
                    try { dispatcher.close() } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError("JSPluginEngine.destroyDispatcher", e) }
                    scope.cancel()
                }
        }
    }
}
