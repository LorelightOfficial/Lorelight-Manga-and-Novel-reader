package com.lorelight

/**
 * Every full-screen place the app can be.
 *
 * The whole navigation tree is ONE ordered stack of these. Crawler, New
 * Chapters and Font Manager used to be loose `Boolean` flags living beside the
 * stack, which meant back ordering between them and Details/Reader was
 * undefined, they could stack on top of each other, and switching tabs left
 * them floating over the new tab. They are real destinations now.
 *
 * Entries store IDENTITY (a novel id), never a whole `Novel`. A Novel is a
 * large mutable record; embedding one in a stack entry made the entry go stale
 * the moment the library changed and made the stack impossible to persist.
 * Novels are resolved through `novelRegistry` at render time.
 *
 * Moved out of MainActivity.kt, which had grown past 2,000 lines and mixed the
 * Activity, the app shell, the navigation contract and the bottom bar in one
 * file. The package is deliberately unchanged (`com.lorelight`), so this is a
 * pure move: not one call site or import had to change.
 */
sealed class ScreenDestination {
    data class Tab(val tabIndex: Int) : ScreenDestination()
    data class Details(val novelId: String) : ScreenDestination()
    data class Reader(val novelId: String?) : ScreenDestination()
    object Crawler : ScreenDestination()
    object NewChapters : ScreenDestination()
    object FontManager : ScreenDestination()
    object Downloads : ScreenDestination()

    /** Compact form used to persist the stack across rotation / process death. */
    fun encode(): String = when (this) {
        is Tab -> "T:$tabIndex"
        is Details -> "D:$novelId"
        is Reader -> "R:${novelId ?: ""}"
        Crawler -> "C:"
        NewChapters -> "N:"
        FontManager -> "F:"
        Downloads -> "Q:"
    }

    companion object {
        fun decode(raw: String): ScreenDestination? {
            val tag = raw.substringBefore(':')
            val arg = raw.substringAfter(':', "")
            return when (tag) {
                "T" -> Tab(arg.toIntOrNull() ?: 0)
                "D" -> if (arg.isBlank()) null else Details(arg)
                "R" -> Reader(arg.ifBlank { null })
                "C" -> Crawler
                "N" -> NewChapters
                "F" -> FontManager
                "Q" -> Downloads
                else -> null
            }
        }

        /** Hard ceiling so Details -> Reader -> Details -> ... cannot grow forever. */
        const val MAX_DEPTH = 12
    }
}
