package com.lorelight.data.local

import android.content.Context
import android.util.Base64
import java.io.File

object CoverStorage {
    const val FILE_PREFIX = "file://"

    private fun coversDir(context: Context): File =
        File(context.filesDir, "covers").apply { if (!exists()) mkdirs() }

    fun coverFile(context: Context, novelId: String): File =
        File(coversDir(context), "$novelId.img")

    /** Saves cover bytes (converted to WebP when possible) and returns a "file://" path to store in the Novel. */
    fun saveCoverBytes(context: Context, novelId: String, bytes: ByteArray): String? {
        return try {
            val f = coverFile(context, novelId)
            f.writeBytes(toWebP(bytes) ?: bytes)
            FILE_PREFIX + f.absolutePath
        } catch (e: Exception) { null }
    }

    /** Converts image bytes to WebP (smaller + same visual quality). Returns null if the bytes aren't a decodable bitmap. */
    private fun toWebP(bytes: ByteArray): ByteArray? {
        return try {
            val bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            val out = java.io.ByteArrayOutputStream()
            val format = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                android.graphics.Bitmap.CompressFormat.WEBP_LOSSY
            } else {
                @Suppress("DEPRECATION")
                android.graphics.Bitmap.CompressFormat.WEBP
            }
            bitmap.compress(format, 90, out)
            out.toByteArray().takeIf { it.isNotEmpty() }
        } catch (e: Exception) { null }
    }

    /**
     * Re-encodes cover bytes to WebP, downscaling so the longest edge is at
     * most [maxDim]. Backup covers only ever render as small grid thumbnails,
     * so full-resolution art would just bloat the backup JSON.
     */
    private fun toBackupWebP(bytes: ByteArray, maxDim: Int = 720): ByteArray? {
        return try {
            val src = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            val longest = maxOf(src.width, src.height)
            val bitmap = if (longest > maxDim && longest > 0) {
                val scale = maxDim.toFloat() / longest.toFloat()
                val w = (src.width * scale).toInt().coerceAtLeast(1)
                val h = (src.height * scale).toInt().coerceAtLeast(1)
                android.graphics.Bitmap.createScaledBitmap(src, w, h, true)
            } else {
                src
            }
            val out = java.io.ByteArrayOutputStream()
            val format = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                android.graphics.Bitmap.CompressFormat.WEBP_LOSSY
            } else {
                @Suppress("DEPRECATION")
                android.graphics.Bitmap.CompressFormat.WEBP
            }
            bitmap.compress(format, 80, out)
            if (bitmap !== src) bitmap.recycle()
            out.toByteArray().takeIf { it.isNotEmpty() }
        } catch (e: Exception) { null }
    }

    /** Reads the novel's locally stored cover (file or legacy base64) and returns it as a base64 WebP payload for backups, or null if there is no local cover to embed. */
    fun encodeCoverForBackup(context: Context, novelId: String, coverValue: String?): String? {
        return try {
            val raw: ByteArray = when {
                coverFile(context, novelId).let { it.exists() && it.length() > 0 } ->
                    coverFile(context, novelId).readBytes()
                isFilePath(coverValue) ->
                    File(coverValue!!.removePrefix(FILE_PREFIX)).takeIf { it.exists() }?.readBytes()
                isBase64Payload(coverValue) ->
                    Base64.decode(coverValue, Base64.DEFAULT)
                else -> null
            } ?: return null
            val webp = toBackupWebP(raw) ?: toWebP(raw) ?: raw
            Base64.encodeToString(webp, Base64.NO_WRAP)
        } catch (e: Exception) { null }
    }

    /** Restores a cover embedded in a backup: decodes it, saves it locally, and returns the "file://" path to store on the Novel. */
    fun restoreCoverFromBackup(context: Context, novelId: String, base64Data: String): String? {
        return try {
            val bytes = Base64.decode(base64Data, Base64.DEFAULT)
            saveCoverBytes(context, novelId, bytes)
        } catch (e: Exception) { null }
    }

    /** Decodes a Base64 string, saves it as a file, returns "file://" path. */
    fun migrateBase64ToFile(context: Context, novelId: String, base64: String): String? {
        return try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            saveCoverBytes(context, novelId, bytes)
        } catch (e: Exception) { null }
    }

    /** Downloads a remote cover URL and saves it locally. */
    suspend fun downloadAndSaveCover(
        context: Context,
        novelId: String,
        coverUrl: String,
        headers: Map<String, String>? = null
    ): String? = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        try {
            val reqBuilder = okhttp3.Request.Builder()
                .url(coverUrl)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
            headers?.forEach { (k, v) -> reqBuilder.header(k, v) }
            val client = okhttp3.OkHttpClient.Builder()
                .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                .build()
            client.newCall(reqBuilder.build()).execute().use { resp ->
                if (resp.isSuccessful) {
                    val bytes = resp.body?.bytes()
                    if (bytes != null && bytes.isNotEmpty()) {
                        return@withContext saveCoverBytes(context, novelId, bytes)
                    }
                }
            }
        } catch (e: Exception) {
            // best effort
        }
        null
    }

    fun deleteCover(context: Context, novelId: String) {
        try { coverFile(context, novelId).delete() } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError(context, "CoverStorage.deleteCover", e) }
    }

    fun isFilePath(value: String?): Boolean = value?.startsWith(FILE_PREFIX) == true
    fun isBase64Payload(value: String?): Boolean =
        !value.isNullOrEmpty() &&
        !value.startsWith("http://") && !value.startsWith("https://") &&
        !value.startsWith(FILE_PREFIX) && value.length > 256
}
