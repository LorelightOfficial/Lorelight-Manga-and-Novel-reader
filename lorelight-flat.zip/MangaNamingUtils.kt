package com.lorelight.manga.util

import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

object MangaNamingUtils {
    fun toPluginId(sourceId: Long): String = "manga:$sourceId"

    fun toSourceId(pluginId: String): Long? {
        if (!pluginId.startsWith("manga:")) return null
        return pluginId.substringAfter("manga:").toLongOrNull()
    }

    fun isMangaPluginId(pluginId: String): Boolean = pluginId.startsWith("manga:")

    fun formatChapterUrl(sourceId: Long, chapterUrl: String): String {
        val encodedUrl = URLEncoder.encode(chapterUrl, StandardCharsets.UTF_8.name())
        return "manga:$sourceId:$encodedUrl"
    }

    fun parseChapterUrl(formatted: String): Pair<Long, String>? {
        if (!formatted.startsWith("manga:")) return null
        val parts = formatted.substringAfter("manga:").split(":", limit = 2)
        if (parts.size != 2) return null
        val sourceId = parts[0].toLongOrNull() ?: return null
        val rawUrl = parts[1]
        val decodedUrl = URLDecoder.decode(rawUrl, StandardCharsets.UTF_8.name())
        return Pair(sourceId, decodedUrl)
    }
}
