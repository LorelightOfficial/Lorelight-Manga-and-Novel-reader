package eu.kanade.tachiyomi.data.cache

import android.content.Context
import android.text.format.Formatter
import com.jakewharton.disklrucache.DiskLruCache
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.util.storage.DiskUtil
import eu.kanade.tachiyomi.util.storage.saveTo
import kotlinx.serialization.json.Json
import logcat.LogPriority
import okhttp3.Response
import okio.buffer
import okio.sink
import tachiyomi.core.common.util.system.logcat
import tachiyomi.domain.chapter.model.Chapter
import java.io.File
import java.io.IOException

/**
 * Class used to create chapter cache
 * For each image in a chapter a file is created
 * For each chapter a Json list is created and converted to a file.
 * The files are in format *md5key*.0
 *
 * @param context the application context.
 */
class ChapterCache(
    private val context: Context,
    private val json: Json,
) {

    /** Cache class used for cache management (nullable for graceful degradation). */
    private val diskCache: DiskLruCache? = openDiskCache()

    private fun openDiskCache(): DiskLruCache? {
        val dir = File(context.cacheDir, "chapter_disk_cache")
        dir.mkdirs()

        return try {
            DiskLruCache.open(
                dir,
                PARAMETER_APP_VERSION,
                PARAMETER_VALUE_COUNT,
                PARAMETER_CACHE_SIZE,
            )
        } catch (e: IOException) {
            logcat(LogPriority.WARN, e) { "Failed to open ChapterCache DiskLruCache, wiping directory and retrying..." }
            try {
                dir.deleteRecursively()
                dir.mkdirs()
                DiskLruCache.open(
                    dir,
                    PARAMETER_APP_VERSION,
                    PARAMETER_VALUE_COUNT,
                    PARAMETER_CACHE_SIZE,
                )
            } catch (e2: Throwable) {
                logcat(LogPriority.ERROR, e2) { "Failed to open ChapterCache DiskLruCache after wipe" }
                com.lorelight.core.DevLogStore.append(
                    context,
                    "CACHE",
                    "ChapterCache DiskLruCache open failed after wipe: ${e2.message}",
                )
                null
            }
        } catch (e: Throwable) {
            logcat(LogPriority.ERROR, e) { "Unexpected error opening ChapterCache DiskLruCache" }
            com.lorelight.core.DevLogStore.append(
                context,
                "CACHE",
                "ChapterCache DiskLruCache unexpected error: ${e.message}",
            )
            null
        }
    }

    /**
     * Returns directory of cache.
     */
    private val cacheDir: File = File(context.cacheDir, "chapter_disk_cache")

    /**
     * Returns real size of directory.
     */
    private val realSize: Long
        get() = if (diskCache != null) DiskUtil.getDirectorySize(cacheDir) else 0L

    /**
     * Returns real size of directory in human readable format.
     */
    val readableSize: String
        get() = Formatter.formatFileSize(context, realSize)

    /**
     * Get page list from cache.
     *
     * @param chapter the chapter.
     * @return the list of pages.
     */
    fun getPageListFromCache(chapter: Chapter): List<Page> {
        val cache = diskCache ?: return emptyList()
        val key = DiskUtil.hashKeyForDisk(getKey(chapter))

        return try {
            cache.get(key)?.use {
                json.decodeFromString<List<Page>>(it.getString(0))
            } ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Add page list to disk cache.
     *
     * @param chapter the chapter.
     * @param pages list of pages.
     */
    fun putPageListToCache(chapter: Chapter, pages: List<Page>) {
        val cache = diskCache ?: return
        val cachedValue = json.encodeToString(pages)

        var editor: DiskLruCache.Editor? = null

        try {
            val key = DiskUtil.hashKeyForDisk(getKey(chapter))
            editor = cache.edit(key) ?: return

            editor.newOutputStream(0).sink().buffer().use {
                it.write(cachedValue.toByteArray())
                it.flush()
            }

            cache.flush()
            editor.commit()
        } catch (e: Exception) {
            logcat(LogPriority.WARN, e) { "Failed to put page list to cache" }
        } finally {
            editor?.abortUnlessCommitted()
        }
    }

    /**
     * Returns true if image is in cache.
     *
     * @param imageUrl url of image.
     * @return true if in cache otherwise false.
     */
    fun isImageInCache(imageUrl: String): Boolean {
        val cache = diskCache ?: return false
        return try {
            val key = DiskUtil.hashKeyForDisk(imageUrl)
            val snapshot = cache.get(key)
            val inJournal = snapshot != null
            snapshot?.close()
            val fileExists = getImageFile(imageUrl).exists()
            if (inJournal && !fileExists) {
                logcat(LogPriority.WARN) { "Image is in journal but file is missing: $imageUrl" }
            }
            inJournal && fileExists
        } catch (_: IOException) {
            false
        }
    }

    /**
     * Get image file from url.
     *
     * @param imageUrl url of image.
     * @return path of image.
     */
    fun getImageFile(imageUrl: String): File {
        val imageName = DiskUtil.hashKeyForDisk(imageUrl) + ".0"
        return File(cacheDir, imageName)
    }

    /**
     * Add image to cache.
     *
     * @param imageUrl url of image.
     * @param response http response from page.
     * @throws IOException image error.
     */
    @Throws(IOException::class)
    fun putImageToCache(imageUrl: String, response: Response) {
        val cache = diskCache ?: run {
            response.body.close()
            return
        }

        var editor: DiskLruCache.Editor? = null

        try {
            val key = DiskUtil.hashKeyForDisk(imageUrl)
            editor = cache.edit(key) ?: return

            response.body.source().saveTo(editor.newOutputStream(0))

            cache.flush()
            editor.commit()
        } finally {
            response.body.close()
            editor?.abortUnlessCommitted()
        }
    }

    fun clear(): Int {
        var deletedFiles = 0
        cacheDir.listFiles()?.forEach {
            if (removeFileFromCache(it.name)) {
                deletedFiles++
            }
        }
        return deletedFiles
    }

    /**
     * Remove file from cache.
     *
     * @param file name of file "md5.0".
     * @return status of deletion for the file.
     */
    private fun removeFileFromCache(file: String): Boolean {
        if (file == "journal" || file.startsWith("journal.")) {
            return false
        }

        val cache = diskCache ?: return false

        return try {
            val key = file.substringBeforeLast(".")
            cache.remove(key)
        } catch (e: Exception) {
            logcat(LogPriority.WARN, e) { "Failed to remove file from cache" }
            false
        }
    }

    private fun getKey(chapter: Chapter): String {
        return "${chapter.mangaId}${chapter.url}"
    }
}

/** Application cache version.  */
private const val PARAMETER_APP_VERSION = 1

/** The number of values per cache entry. Must be positive.  */
private const val PARAMETER_VALUE_COUNT = 1

/** The maximum number of bytes this cache should use to store.  */
private const val PARAMETER_CACHE_SIZE = 100L * 1024 * 1024
