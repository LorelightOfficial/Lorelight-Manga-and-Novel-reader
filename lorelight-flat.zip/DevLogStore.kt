package com.lorelight.core

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Rolling developer log backing the hidden developer panel (About -> tap the
 * info icon 5 times). Entries older than 24 hours are wiped automatically on
 * every read and write, and the log is capped at [MAX_LINES] lines, so it can
 * never grow unbounded or waste storage.
 *
 * Line format on disk: "<epochMillis>\t<MM-dd HH:mm:ss>\t<TAG>: <message>".
 * The epoch prefix is stripped again for display.
 */
object DevLogStore {
    private const val LOG_FILE = "dev_logs.txt"
    private const val PREFS = "lorelight_dev_mode"
    private const val KEY_UNLOCKED = "dev_mode_unlocked"
    private const val MAX_AGE_MS = 24L * 60 * 60 * 1000 // wipe everything older than 1 day
    private const val MAX_LINES = 1500 // hard cap as extra safety
    private val TIME_FMT = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US)
    // Visual break between entries when the panel shows the raw combined
    // (app log + system log) view, so scrolling long output stays readable.
    const val LINE_BREAK = "--------------------------------------------"

    private fun logFile(context: Context): File = File(context.filesDir, LOG_FILE)

    @Synchronized
    fun append(context: Context, tag: String, message: String) {
        try {
            val now = System.currentTimeMillis()
            val lines = prunedLines(context, now).toMutableList()
            // Preserve multi-line detail (e.g. full crash stack traces). Newlines
            // are encoded as U+2028 so each entry stays one physical line on disk
            // (readLines() does not split on U+2028); read() decodes them back.
            val cleanMessage = message.replace("\r\n", "\n").replace('\r', '\n')
                .replace('\t', ' ').replace('\n', '\u2028').take(6000)
            lines.add("$now\t${TIME_FMT.format(Date(now))}\t$tag: $cleanMessage")
            val capped = if (lines.size > MAX_LINES) lines.takeLast(MAX_LINES) else lines
            logFile(context).writeText(capped.joinToString("\n"))
            // Mirror to Logcat too. The in-app log is capped and pruned for
            // storage; `adb logcat` during a live debugging session should
            // still see every line as it happens.
            android.util.Log.i("Lorelight-$tag", cleanMessage.replace('\u2028', '\n'))
        } catch (_: Exception) {
            // logging must never crash the app
        }
    }

    /** Returns the pruned log for display (epoch prefixes stripped), newest at the bottom. */
    @Synchronized
    fun read(context: Context): String {
        return try {
            val now = System.currentTimeMillis()
            val lines = prunedLines(context, now)
            if (lines.isEmpty()) {
                logFile(context).delete()
                ""
            } else {
                // persist the pruned list so stale data is wiped even on read
                logFile(context).writeText(lines.joinToString("\n"))
                lines.joinToString("\n") { line ->
                    line.substringAfter('\t').replaceFirst('\t', ' ').replace('\u2028', '\n')
                }
            }
        } catch (_: Exception) {
            ""
        }
    }

    @Synchronized
    fun clear(context: Context) {
        try {
            logFile(context).delete()
        } catch (_: Exception) {
        }
    }

    fun isDevModeUnlocked(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_UNLOCKED, false)

    fun setDevModeUnlocked(context: Context, unlocked: Boolean) {
        if (!unlocked) {
            com.lorelight.network.NetworkThrottle.setThrottleKbps(context, com.lorelight.network.NetworkThrottle.SPEED_OFF)
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_UNLOCKED, unlocked).apply()
    }

    private fun prunedLines(context: Context, now: Long): List<String> {
        val f = logFile(context)
        if (!f.exists()) return emptyList()
        return f.readLines().filter { line ->
            val epoch = line.substringBefore('\t').toLongOrNull() ?: return@filter false
            (now - epoch) in 0..MAX_AGE_MS
        }
    }

    /**
     * Full raw system log via `logcat`, filtered to this process only. This is
     * the actual command output verbatim -- unlike [read], which only shows
     * what the app explicitly chose to record through [append], this captures
     * everything the OS and every library print, including lines the app
     * itself never wrapped in a DevLogStore.append call.
     */
    fun readSystemLog(context: Context, maxLines: Int = 4000): String {
        return try {
            val pid = android.os.Process.myPid()
            val output = runLogcat(listOf("logcat", "-d", "-v", "threadtime", "--pid=$pid"))
                ?: runLogcat(listOf("logcat", "-d", "-v", "threadtime"))
                ?: return "(system log unavailable on this device)"
            val lines = output.lines()
            if (lines.size > maxLines) lines.takeLast(maxLines).joinToString("\n") else output
        } catch (e: Exception) {
            "(failed to read system log: ${e.message})"
        }
    }

    private fun runLogcat(command: List<String>): String? {
        return try {
            val process = ProcessBuilder(command).redirectErrorStream(true).start()
            val text = process.inputStream.bufferedReader().readText()
            process.waitFor()
            text.ifBlank { null }
        } catch (_: Exception) {
            null
        }
    }
}
