package com.lorelight.data.download

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import com.lorelight.crawler.CrawlerEngine
import com.lorelight.crawler.NovelRangeDownloader
import com.lorelight.data.model.Novel
import com.lorelight.tts.TtsPlaybackManager
import java.util.concurrent.atomic.AtomicInteger

/**
 * S5 - SMART OFFLINE DOWNLOADS: the part that decides what to fetch, and when.
 *
 * THE ONE RULE THIS FILE OBEYS
 * It is NOT a downloader. PLAN_S.txt is explicit: "Policies enqueue, they do
 * not become a second downloader." So every decision here ends in a call to
 * [NovelRangeDownloader.start], which already owns queueing, parallelism,
 * politeness delays, retries, the speed ceiling and the progress bus. A second
 * fetch loop would double the load on sources, race the first one for the same
 * cache files, and report progress nobody could reconcile.
 *
 * WHY IT ASKS BEFORE IT ACTS
 * A policy fires with nobody watching, which makes it the one place in the app
 * where being wrong is expensive: it can eat a data allowance, a battery, or
 * the free space on a phone. So the order is always
 *   1. is the reader busy - if so, do nothing at all,
 *   2. do the conditions hold - Wi-Fi, charging,
 *   3. is anything actually missing,
 * and only then enqueue. Each step can only ever REDUCE what gets fetched.
 */
object DownloadPolicyScheduler {

    // -------------------------------------------------------------- yielding

    /**
     * Depth counter for "the user is doing something we must not slow down".
     *
     * A counter rather than a boolean because the things that claim it nest and
     * overlap - the reader is open while OCR runs on a page - and a boolean
     * would let whichever finished first clear the flag while the other was
     * still going.
     *
     * Held with [withUserActivity] so an early return or a thrown exception
     * cannot leak a permanent claim, which would silently disable policy
     * downloads until the app restarted.
     */
    private val userActivityDepth = AtomicInteger(0)

    fun enterUserActivity() {
        userActivityDepth.incrementAndGet()
    }

    fun exitUserActivity() {
        userActivityDepth.updateAndGet { if (it > 0) it - 1 else 0 }
    }

    inline fun <T> withUserActivity(block: () -> T): T {
        enterUserActivity()
        return try {
            block()
        } finally {
            exitUserActivity()
        }
    }

    /**
     * True while the user is reading, or TTS is speaking.
     *
     * TTS is read straight from its own state rather than expecting the player
     * to remember to claim the counter: it is the longest-running foreground
     * activity in the app, and the one most obviously ruined by competing
     * network work.
     */
    fun isUserBusy(): Boolean =
        userActivityDepth.get() > 0 || TtsPlaybackManager.isPlaying.value

    // ------------------------------------------------------------ conditions

    /**
     * True when the phone is on power.
     *
     * Reads the sticky ACTION_BATTERY_CHANGED broadcast, which needs no
     * permission and no registered receiver. Defaults to TRUE on failure: the
     * failure mode of a wrong "yes" is one download on battery, while a wrong
     * "no" is a feature that never runs and cannot be debugged from the UI.
     */
    fun isCharging(context: Context): Boolean {
        return try {
            val intent: Intent? = context.applicationContext.registerReceiver(
                null,
                IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            )
            val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
            if (plugged == -1) return true
            plugged != 0
        } catch (t: Throwable) {
            true
        }
    }

    /**
     * Null when this title's policy may run right now, otherwise a short reason
     * fit to show in the UI. The order matters: the most temporary and most
     * user-visible reason wins, so the Downloads screen explains the thing the
     * reader can most easily act on.
     */
    fun blockedReason(context: Context, rules: DownloadPolicy.Rules): String? {
        if (!rules.active) return "Off for this title"
        if (isUserBusy()) return "Paused while you are reading"
        if (rules.wifiOnly && !DownloadTuning.isUnmetered(context)) return "Waiting for Wi-Fi"
        if (rules.chargingOnly && !isCharging(context)) return "Waiting for charging"
        return null
    }

    // --------------------------------------------------------------- reading

    /**
     * Where the reader actually is, as an index into the chapter list.
     *
     * Prefers `currentChapterIndex`, which the RESUME REDESIGN added precisely
     * because chapter NAMES are not identities - sources retitle chapters and
     * insert new ones at the top, so indexOf(currentChapter) drifts. Falls back
     * to a name lookup only for library entries saved before that field
     * existed, and to 0 if even that misses.
     */
    fun currentIndexOf(novel: Novel): Int {
        val recorded = novel.currentChapterIndex
        if (recorded >= 0 && recorded <= novel.chapters.lastIndex) return recorded
        val byName = novel.chapters.indexOf(novel.currentChapter)
        return if (byName >= 0) byName else 0
    }

    /** How many chapters sit after the current one. */
    fun unreadAheadOf(novel: Novel): Int {
        val last = novel.chapterUrls.size.coerceAtMost(novel.chapters.size) - 1
        if (last < 0) return 0
        return (last - currentIndexOf(novel)).coerceAtLeast(0)
    }

    /**
     * The window this title wants held offline: the chapter being read, plus
     * however many the policy says to keep ahead.
     *
     * The current chapter is included on purpose. "Keep next 5 ahead" is asked
     * for so the series survives aeroplane mode, and a window that started at
     * the NEXT chapter would leave the one actually open unreadable.
     *
     * Returns an empty range when there is nothing to hold.
     */
    fun desiredWindow(novel: Novel, rules: DownloadPolicy.Rules): IntRange {
        val lastAvailable = novel.chapterUrls.size.coerceAtMost(novel.chapters.size) - 1
        if (lastAvailable < 0) return IntRange.EMPTY
        val target = rules.targetAhead(unreadAheadOf(novel))
        if (target <= 0 && !rules.autoNewChapters) return IntRange.EMPTY
        val from = currentIndexOf(novel).coerceIn(0, lastAvailable)
        val to = (from + target).coerceAtMost(lastAvailable)
        return from..to
    }

    /** Chapter indices inside the window that are not cached yet. */
    fun missingIn(context: Context, novel: Novel, window: IntRange): List<Int> {
        if (window.isEmpty()) return emptyList()
        val app = context.applicationContext
        val missing = ArrayList<Int>()
        for (i in window) {
            val url = novel.chapterUrls.getOrNull(i)?.trim().orEmpty()
            if (url.isEmpty()) continue
            if (!CrawlerEngine.isChapterCached(app, url)) missing.add(i)
        }
        return missing
    }

    /** How many chapters of the wanted window are already readable offline. */
    fun readyCount(context: Context, novel: Novel, window: IntRange): Int {
        if (window.isEmpty()) return 0
        val app = context.applicationContext
        var ready = 0
        for (i in window) {
            val url = novel.chapterUrls.getOrNull(i)?.trim().orEmpty()
            if (url.isNotEmpty() && CrawlerEngine.isChapterCached(app, url)) ready++
        }
        return ready
    }

    // ------------------------------------------------------------- the sweep

    /** What one pass decided, for the UI and for logging. */
    data class Outcome(
        val novelId: String,
        val title: String,
        val ready: Int,
        val wanted: Int,
        val queued: Int,
        val blockedReason: String?
    ) {
        val didQueue: Boolean get() = queued > 0
    }

    /**
     * Brings one title up to its policy. Safe to call often - it is a no-op
     * once the window is fully cached, and it never enqueues a range that is
     * already running, because [NovelRangeDownloader] refuses duplicate job ids.
     */
    fun sweepOne(context: Context, novel: Novel): Outcome {
        val rules = DownloadPolicy.rulesFor(context, novel.id)
        val window = desiredWindow(novel, rules)
        val ready = readyCount(context, novel, window)
        val wanted = if (window.isEmpty()) 0 else window.count()

        val blocked = blockedReason(context, rules)
        if (blocked != null || window.isEmpty()) {
            return Outcome(novel.id, novel.title, ready, wanted, 0, blocked)
        }

        // S5 - per-title storage quota. Checked before computing missing so we
        // never enqueue a range we'd immediately block anyway.
        if (rules.quotaMb > DownloadPolicy.QUOTA_UNLIMITED) {
            val usedBytes = CrawlerEngine.cachedSizeBytesFor(context, novel.chapterUrls)
            val usedMb = (usedBytes / (1024L * 1024L)).toInt()
            if (usedMb >= rules.quotaMb) {
                return Outcome(novel.id, novel.title, ready, wanted, 0, "Quota: ${usedMb}MB / ${rules.quotaMb}MB")
            }
        }
        // S5 - whole-library budget. Single check that blocks all titles once
        // the combined cache fills the user's ceiling.
        val libraryBudgetMb = DownloadPolicy.getLibraryBudgetMb(context)
        if (libraryBudgetMb > DownloadPolicy.QUOTA_UNLIMITED) {
            val totalBytes = CrawlerEngine.totalCacheSizeBytes(context)
            val totalMb = (totalBytes / (1024L * 1024L)).toInt()
            if (totalMb >= libraryBudgetMb) {
                return Outcome(novel.id, novel.title, ready, wanted, 0, "Library full: ${totalMb}MB / ${libraryBudgetMb}MB")
            }
        }

        val missing = missingIn(context, novel, window)
        if (missing.isEmpty()) {
            return Outcome(novel.id, novel.title, ready, wanted, 0, null)
        }

        // Enqueue the contiguous span covering what is missing and let the
        // downloader skip what is already cached - it marks cached items DONE
        // up front, so the queue still shows honest totals. One range per title
        // per sweep keeps the job list readable instead of littering it with a
        // separate job per gap.
        val startChapter = missing.first() + 1
        val endChapter = missing.last() + 1
        val outcome = NovelRangeDownloader.start(
            context = context,
            novel = novel,
            startChapter = startChapter,
            endChapter = endChapter
        )
        val queued = when (outcome) {
            is NovelRangeDownloader.StartOutcome.NothingToDo -> 0
            is NovelRangeDownloader.StartOutcome.AlreadyRunning -> 0
            else -> missing.size
        }
        return Outcome(novel.id, novel.title, ready, wanted, queued, null)
    }

    /**
     * Brings the whole library up to policy.
     *
     * Bails out entirely the moment the reader is busy rather than checking per
     * title, so a sweep started just before someone opened the reader stops
     * immediately instead of grinding through the remaining titles.
     */
    fun sweepAll(context: Context, novels: List<Novel>): List<Outcome> {
        val out = ArrayList<Outcome>()
        for (novel in novels) {
            if (isUserBusy()) break
            if (novel.chapterUrls.isEmpty()) continue
            val rules = DownloadPolicy.rulesFor(context, novel.id)
            if (!rules.active) continue
            out.add(sweepOne(context, novel))
        }
        return out
    }

    /**
     * The Details-screen line: "5 chapters ready, next 5 queued".
     * Null when this title has no policy, so the row can stay hidden.
     */
    fun offlineSummary(context: Context, novel: Novel): String? {
        val rules = DownloadPolicy.rulesFor(context, novel.id)
        if (!rules.active) return null
        val window = desiredWindow(novel, rules)
        if (window.isEmpty()) return null
        val ready = readyCount(context, novel, window)
        val total = window.count()
        val pending = (total - ready).coerceAtLeast(0)
        val head = if (ready == 1) "1 chapter ready" else "$ready chapters ready"
        return when {
            pending == 0 -> head
            else -> "$head, next $pending queued"
        }
    }

    // ----------------------------------------------------------- cleanup

    /**
     * S5 - Deletes cached chapters for one novel according to its cleanup policy.
     *
     * CLEANUP_AFTER_READING  — evicts every chapter that the reader has already
     *   passed (index < currentIndex). Those chapters are behind the user and
     *   won't be served by the window logic again, so they're just dead weight.
     *
     * CLEANUP_KEEP_LAST — keeps the most recent [Rules.keepLast] chapters before
     *   the current reading position and evicts anything older. This is the
     *   "last N chapters" mode: you can always go back a little, but not forever.
     *
     * Neither mode touches chapters AT or AHEAD of the current position, because
     * those are exactly what the download window is there to serve.
     *
     * If [Rules.protectMarked] is true the whole cleanup is skipped: the user
     * has said they want to keep annotated chapters, and without loading all
     * highlights into memory here we can't reliably tell which files carry
     * annotations. Skipping is safer than accidentally wiping someone's notes.
     *
     * Safe to call on any background thread. Returns the number of URLs evicted.
     */
    fun cleanupOne(context: Context, novel: Novel): Int {
        val rules = DownloadPolicy.rulesFor(context, novel.id)
        if (rules.cleanupMode == DownloadPolicy.CLEANUP_NEVER) return 0
        if (rules.protectMarked) return 0   // can't distinguish annotated files here; skip
        if (novel.chapterUrls.isEmpty()) return 0

        val current = currentIndexOf(novel).coerceAtLeast(0)
        if (current == 0) return 0  // nothing behind the reader yet

        val toDelete = mutableListOf<String>()

        when (rules.cleanupMode) {
            DownloadPolicy.CLEANUP_AFTER_READING -> {
                // Every cached chapter the reader has passed.
                for (i in 0 until current) {
                    val url = novel.chapterUrls.getOrNull(i)?.trim().orEmpty()
                    if (url.isNotEmpty() && CrawlerEngine.isChapterCached(context, url)) {
                        toDelete.add(url)
                    }
                }
            }
            DownloadPolicy.CLEANUP_KEEP_LAST -> {
                // Keep the last [keepLast] chapters behind current; evict older ones.
                val keepFrom = (current - rules.keepLast).coerceAtLeast(0)
                for (i in 0 until keepFrom) {
                    val url = novel.chapterUrls.getOrNull(i)?.trim().orEmpty()
                    if (url.isNotEmpty() && CrawlerEngine.isChapterCached(context, url)) {
                        toDelete.add(url)
                    }
                }
            }
        }

        if (toDelete.isEmpty()) return 0
        CrawlerEngine.clearCacheForUrls(context, toDelete)
        return toDelete.size
    }

    /**
     * S5 - Runs [cleanupOne] for every novel in the library.
     * Intended to be called after [sweepAll] so that downloads and cleanup
     * happen in one background pass rather than two separate wakeups.
     * Returns the total number of chapter files evicted across all titles.
     */
    fun cleanupAll(context: Context, novels: List<Novel>): Int {
        var total = 0
        for (novel in novels) {
            if (novel.chapterUrls.isEmpty()) continue
            total += cleanupOne(context, novel)
        }
        return total
    }
}
