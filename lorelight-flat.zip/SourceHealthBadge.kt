package com.lorelight.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * O3 - Source reliability badge.
 *
 * Displayed beside a source name in Browse source lists and search results to
 * give users an at-a-glance signal before they try to use that source.
 *
 * [reliability] is a 0.0..1.0 success rate derived from recent fetch attempts
 * (e.g. from MonitoringSettings / SelfHealingEngine diagnostics). Pass null
 * when no data is available — the badge is suppressed entirely.
 */
@Composable
fun SourceHealthBadge(
    reliability: Float?,         // 0..1 success rate, null = unknown
    modifier: Modifier = Modifier,
    compact: Boolean = false      // true = icon only, no label text
) {
    if (reliability == null) return

    val tier = SourceHealthTier.from(reliability)

    Row(
        modifier = modifier
            .background(
                color = tier.chipColor.copy(alpha = 0.13f),
                shape = RoundedCornerShape(6.dp)
            )
            .padding(horizontal = if (compact) 4.dp else 6.dp, vertical = 2.dp)
            .semantics(mergeDescendants = true) { },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = tier.icon,
            contentDescription = tier.label,
            tint = tier.chipColor,
            modifier = Modifier.size(12.dp)
        )
        if (!compact) {
            Spacer(Modifier.width(3.dp))
            Text(
                text = tier.label,
                fontSize = 10.sp,
                color = tier.chipColor,
                style = MaterialTheme.typography.labelSmall
            )
        }
    }
}

/** Three-tier reliability classification. */
@Stable
enum class SourceHealthTier(
    val label: String,
    val icon: ImageVector,
    val chipColor: Color
) {
    HEALTHY(
        label = "Reliable",
        icon = Icons.Filled.CheckCircle,
        chipColor = Color(0xFF2E7D32)  // green-800
    ),
    DEGRADED(
        label = "Intermittent",
        icon = Icons.Filled.Warning,
        chipColor = Color(0xFFF57F17)  // amber-900
    ),
    DOWN(
        label = "Down",
        icon = Icons.Filled.Error,
        chipColor = Color(0xFFC62828)  // red-800
    );

    companion object {
        fun from(rate: Float): SourceHealthTier = when {
            rate >= 0.85f -> HEALTHY
            rate >= 0.40f -> DEGRADED
            else          -> DOWN
        }
    }
}

/**
 * Inline "needs attention" blurb used on the Browse screen's attention card.
 * Returns null when the source looks healthy — caller decides whether to show
 * anything at all.
 */
fun sourceAttentionMessage(pluginName: String, reliability: Float?): String? {
    if (reliability == null) return null
    return when (SourceHealthTier.from(reliability)) {
        SourceHealthTier.HEALTHY  -> null
        SourceHealthTier.DEGRADED -> "$pluginName is intermittent — some fetches are failing"
        SourceHealthTier.DOWN     -> "$pluginName appears to be down"
    }
}
