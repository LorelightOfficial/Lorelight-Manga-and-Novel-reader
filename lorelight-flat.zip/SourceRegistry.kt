package com.lorelight.crawler

/**
 * Central registry of all crawler sources.
 *
 * This is the single source of truth for "which source owns which domain".
 * CrawlerEngine routes ALL source detection through SourceRegistry.resolve(url).
 *
 * Any URL that does not match a known, enabled source resolves to
 * SourceId.UNIVERSAL — the generic best-effort fallback. That guarantees an
 * unknown / user-added website never gets handled by another source's code.
 *
 * Phase 2 will flip `enabled = true` on NOVELFULL / ROYALROAD / READWN and give
 * each its own dedicated parsing + search/browse logic.
 */
enum class SourceId {
    NOVELFULL,
    ROYALROAD,
    READWN,
    UNIVERSAL
}

data class SourceInfo(
    val id: SourceId,
    val name: String,
    val domains: List<String>,
    val supportsSearch: Boolean = false,
    val supportsBrowse: Boolean = false,
    val enabled: Boolean = true
)

object SourceRegistry {

    // Order matters: first match wins. UNIVERSAL is implicit (no entry needed).
    val sources: List<SourceInfo> = listOf(
        SourceInfo(
            id = SourceId.UNIVERSAL,
            name = "Universal (any site)",
            domains = emptyList(), // catch-all; resolve() already falls back to UNIVERSAL for unknown hosts
            supportsSearch = false,
            supportsBrowse = false,
            enabled = true
        )
        // --- Phase 2 (disabled for now; do not enable in this task) ---
        // SourceInfo(SourceId.NOVELFULL, "NovelFull", listOf("novelfull.com"), enabled = false),
        // SourceInfo(SourceId.ROYALROAD, "Royal Road", listOf("royalroad.com"), enabled = false),
        // SourceInfo(SourceId.READWN, "ReadWN", listOf("readwn.com"), enabled = false),
    )

    /** Resolve a URL to its owning source, or UNIVERSAL if none matches. */
    fun resolve(url: String): SourceId {
        val raw = url.trim().lowercase()
        val host = try {
            (java.net.URI(raw).host ?: raw).removePrefix("www.")
        } catch (_: Exception) {
            raw
        }
        for (s in sources) {
            if (!s.enabled) continue
            val hit = s.domains.any { d ->
                host == d || host.endsWith(".$d") || raw.contains(d)
            }
            if (hit) return s.id
        }
        return SourceId.UNIVERSAL
    }
}
