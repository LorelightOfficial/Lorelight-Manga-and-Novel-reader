package com.lorelight.manga.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.ui.settings.MangaInstalledExtensionsSection
import com.lorelight.ui.settings.MangaSourcesSettingsSection

@Composable
fun MangaBrowseSettingsScreen(
    onBack: () -> Unit,
    onChanged: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var currentNsfwMode by remember { mutableStateOf(readNsfwMode(context)) }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back"
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Browse Settings",
                fontSize = 28.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
        }

        // Was three separately styled chips with an instant colour swap; now
        // the shared animated control used everywhere else in the app.
        com.lorelight.ui.components.LorelightSegmentedControl(
            options = listOf("Languages", "Extensions", "Repositories"),
            selectedIndex = selectedTab,
            onSelectIndex = { index -> selectedTab = index },
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            height = 44.dp,
            cornerRadius = 14.dp,
            fontSize = 13.sp
        )

        Spacer(Modifier.height(8.dp))

        when (selectedTab) {
            0 -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    MangaSourcesSettingsSection()

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Show 18+ sources first",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "Sorts mature sources to the top of the list. It does not hide them. Tap the 18+ button in Browse to cycle default order, 18+ first, then 18+ last.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Switch(
                                checked = currentNsfwMode == NsfwFilterMode.NSFW_TOP,
                                onCheckedChange = { isChecked ->
                                    val newMode = if (isChecked) NsfwFilterMode.NSFW_TOP else NsfwFilterMode.NORMAL
                                    currentNsfwMode = newMode
                                    writeNsfwMode(context, newMode)
                                    onChanged()
                                }
                            )
                        }
                    }
                }
            }
            1 -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    MangaInstalledExtensionsSection(onChanged = onChanged)
                }
            }
            2 -> {
                RepoListBody(onChanged = onChanged, modifier = Modifier.fillMaxSize())
            }
        }
    }
}

