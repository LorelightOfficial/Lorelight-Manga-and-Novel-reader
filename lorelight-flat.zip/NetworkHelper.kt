package eu.kanade.tachiyomi.network

import android.content.Context
import eu.kanade.tachiyomi.network.interceptor.CloudflareInterceptor
import eu.kanade.tachiyomi.network.interceptor.UncaughtExceptionInterceptor
import eu.kanade.tachiyomi.network.interceptor.UserAgentInterceptor
import okhttp3.Cache
import okhttp3.OkHttpClient
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * ADAPTED FOR LORELIGHT — not a verbatim copy of Mihon.
 *
 * Upstream Mihon's NetworkHelper depends on `NetworkPreferences` (its own preference store)
 * and a twelve-provider DNS-over-HTTPS list. Lorelight has a simplified implementation, now with
 * a WebView-based `CloudflareInterceptor` integrated.
 *
 * Every PUBLIC MEMBER that extension APKs link against is preserved exactly:
 *   - `client: OkHttpClient`
 *   - `cloudflareClient: OkHttpClient`  (deprecated alias of `client`, as upstream)
 *   - `cookieJar: AndroidCookieJar`
 *   - `defaultUserAgentProvider(): String`
 */
class NetworkHelper(context: Context) {

    val cookieJar = AndroidCookieJar()

    val client: OkHttpClient = OkHttpClient.Builder()
        .cookieJar(cookieJar)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .callTimeout(2, TimeUnit.MINUTES)
        .cache(
            Cache(
                File(context.cacheDir, "network_cache"),
                5L * 1024 * 1024, // 5 MiB
            ),
        )
        .addInterceptor(UncaughtExceptionInterceptor())
        .addInterceptor(UserAgentInterceptor(::defaultUserAgentProvider))
        .addInterceptor(CloudflareInterceptor(context, cookieJar, ::defaultUserAgentProvider))
        // Manga pages are fetched by the extension through THIS client, not
        // through HttpClients.shared(), so without this the developer-mode
        // network throttle silently did nothing to page loading -- the one
        // place it was most useful for testing.
        .addNetworkInterceptor(com.lorelight.network.NetworkThrottle.createNetworkInterceptor())
        .build()

    /**
     * @deprecated Since extension-lib 1.5
     */
    @Deprecated("The regular client handles Cloudflare by default")
    @Suppress("UNUSED")
    val cloudflareClient: OkHttpClient = client

    fun defaultUserAgentProvider(): String = DEFAULT_USER_AGENT

    companion object {
        const val DEFAULT_USER_AGENT: String =
            "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/131.0.0.0 Mobile Safari/537.36"
    }
}
