package com.lorelight.manga.progress

import android.content.Context
import com.lorelight.data.db.ChapterEntity
import com.lorelight.data.db.DbWriter
import com.lorelight.data.db.LorelightDatabase
import com.lorelight.data.model.Novel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Per-chapter reading progress and read-state management for the manga side.
 *
 * WHY THIS EXISTS
 * ---------------
 * The manga reader only ever wrote `Novel.currentChapter` + a single page index
 * onto the one-row-per-novel `reading_progress` table. That is enough to resume
 * the LAST chapter you touched and nothing else, so:
 *  - no chapter was ever marked read, so nothing dulled out anywhere;
 *  - the details screen had no read state to show at all;
 *  - re-opening an older chapter always restarted it from page 1;
 *  - there was no way to mark chapters read/unread by hand.
 *
 * MIHON PARITY
 * ------------
 * This is modelled directly on mihon's design, where read state lives on the
 * chapter row rather than on the manga row:
 *  - mihon `Chapter.read`         -> ChapterEntity.completed
 *  - mihon `Chapter.lastPageRead` -> ChapterEntity.lastPageRead
 *  - mihon `Chapter.bookmark`     -> ChapterEntity.bookmark
 *  - mihon `SetReadStatus`        -> [setRead] (incl. the "marking unread resets
 *                                   lastPageRead to 0" rule)
 *  - mihon `GetNextChapters`      -> [nextUnreadIndex] / [resumeTarget]
 *  - mihon "Mark previous as read"-> [markPreviousAsRead]
 *
 * WRITE DISCIPLINE
 * ----------------
 * Every write goes through [DbWriter] so it is ordered against library and
 * progress writes on the single writer thread - a page turn can never race a
 * library save. Writes touch ONLY read-state columns of ONE novel's chapter
 * rows, so the "a page turn rewrote the whole library" class of bug that
 * ProgressStore was created to fix cannot come back through this path.
 *
 * `Novel.completedChapters` is still kept in sync (by chapter NAME) because the
 * in-reader chapter list, NovelSourceMigrator and NewChaptersManager already
 * read it. The chapters table is authoritative; that list is a mirror.
 */
object MangaReadProgress {

    private const val TAG = "MangaReadProgress"

    /**
     * Bumped after every successful write. Compose screens observe this so a
     * chapter dulls out the moment it is marked read, without polling.
     */
    private val _revision = MutableStateFlow(0)
    val revision: StateFlow<Int> = _revision.asStateFlow()

    private fun bump() {
        _revision.value = _revision.value + 1
    }

    /** Immutable snapshot of one novel's chapter read state. */
    data class ChapterProgress(
        val idx: Int,
        val completed: Boolean,
        val lastPageRead: Int,
        val bookmark: Boolean,
        val lastReadAt: Long
    )

    data class ReadState(
        val byIndex: Map<Int, ChapterProgress> = emptyMap(),
        val totalChapters: Int = 0
    ) {
        fun isRead(index: Int): Boolean = byIndex[index]?.completed == true

        /** 0 when nothing was recorded, so callers can treat it as "page 1". */
        fun lastPageRead(index: Int): Int = byIndex[index]?.lastPageRead ?: 0

        fun isBookmarked(index: Int): Boolean = byIndex[index]?.bookmark == true

        /** True when the chapter was started but not finished - mihon's "resume". */
        fun isInProgress(index: Int): Boolean {
            val p = byIndex[index] ?: return false
            return !p.completed && p.lastPageRead > 0
        }

        val readCount: Int get() = byIndex.values.count { it.completed }

        val unreadCount: Int get() = (totalChapters - readCount).coerceAtLeast(0)

        val isFullyRead: Boolean get() = totalChapters > 0 && readCount >= totalChapters

        companion object {
            val EMPTY = ReadState()
        }
    }

    // -----------------------------------------------------------------
    // Reads
    // -----------------------------------------------------------------

    /**
     * Loads read state for one novel. Safe to call off the main thread; the DB
     * runs with allowMainThreadQueries() but callers should still use IO.
     */
    fun load(context: Context, novelId: String, totalChapters: Int = 0): ReadState {
        if (novelId.isEmpty()) return ReadState.EMPTY
        return try {
            val rows = LorelightDatabase.get(context.applicationContext)
                .chapterDao()
                .getForNovel(novelId)
            ReadState(
                byIndex = rows.associate { r ->
                    r.idx to ChapterProgress(
                        idx = r.idx,
                        completed = r.completed,
                        lastPageRead = r.lastPageRead,
                        bookmark = r.bookmark,
                        lastReadAt = r.lastReadAt
                    )
                },
                totalChapters = if (totalChapters > 0) totalChapters else rows.size
            )
        } catch (e: Exception) {
            e.printStackTrace()
            ReadState.EMPTY
        }
    }

    /** Convenience overload that takes the total from the novel itself. */
    fun load(context: Context, novel: Novel): ReadState =
        load(context, novel.id, novel.chapters.size)

    /**
     * mihon GetNextChapters parity: the first chapter that is not finished.
     * Returns -1 when everything has been read.
     */
    fun nextUnreadIndex(context: Context, novel: Novel): Int {
        if (novel.id.isEmpty()) return -1
        return try {
            val dao = LorelightDatabase.get(context.applicationContext).chapterDao()
            val idx = dao.firstUnreadIndex(novel.id)
            when {
                idx != null -> idx
                // No rows yet (never opened) -> start at the beginning.
                dao.countForNovel(novel.id) == 0 -> 0
                else -> -1
            }
        } catch (e: Exception) {
            e.printStackTrace()
            -1
        }
    }

    /**
     * The most recently read chapter, straight from the chapters table.
     *
     * Exists because the resume path used to trust `novel.currentChapter`, a
     * mutable NAME string on the novel row. That row can be rewritten by an
     * unrelated library save carrying a fresher timestamp, and the name stops
     * matching altogether if the source re-titles its chapter list -- at which
     * point indexOf returned -1 and the reader silently fell back to the very
     * first chapter. Returns -1 when nothing has ever been read.
     */
    fun lastReadIndex(context: Context, novelId: String): Int {
        if (novelId.isEmpty()) return -1
        return try {
            LorelightDatabase.get(context.applicationContext)
                .chapterDao()
                .lastReadIndex(novelId) ?: -1
        } catch (e: Exception) {
            e.printStackTrace()
            -1
        }
    }

    /**
     * Where a "Continue" tap should land: chapter index + page to resume on.
     *
     * Mirrors mihon's rule - resume the current chapter when it is unfinished,
     * otherwise move on to the next unread one (page 1).
     */
    data class ResumeTarget(val chapterIndex: Int, val pageIndex: Int)

    fun resumeTarget(context: Context, novel: Novel): ResumeTarget {
        val state = load(context, novel)
        // RESUME FIX. Prefer the chapters table over the novel row's chapter
        // NAME, which is the field that goes stale and sends Continue back to an
        // old chapter. The name lookup stays as a fallback for series whose rows
        // predate per-chapter progress.
        val recorded = lastReadIndex(context, novel.id)
        val currentIdx = if (recorded in novel.chapters.indices) {
            recorded
        } else if (novel.currentChapterIndex in novel.chapters.indices) {
            // RESUME REDESIGN. The durable index beats the chapter NAME.
            novel.currentChapterIndex
        } else {
            novel.chapters.indexOf(novel.currentChapter).takeIf { it >= 0 } ?: 0
        }
        val current = state.byIndex[currentIdx]
        if (current != null && !current.completed) {
            return ResumeTarget(currentIdx, current.lastPageRead.coerceAtLeast(0))
        }
        val next = state.byIndex.keys
            .filter { it > currentIdx && !state.isRead(it) }
            .minOrNull()
            ?: novel.chapters.indices.firstOrNull { !state.isRead(it) }
            ?: currentIdx
        return ResumeTarget(next, state.lastPageRead(next))
    }

    // -----------------------------------------------------------------
    // Seeding
    // -----------------------------------------------------------------

    /**
     * Makes sure a row exists for every chapter of [novel] so read state has
     * somewhere to live. Insert-only for rows we already have, so this is safe
     * to call on every reader open and on every chapter-list refresh.
     */
    fun ensureRows(context: Context, novel: Novel) {
        if (novel.id.isEmpty() || novel.chapters.isEmpty()) return
        val appContext = context.applicationContext
        val rows = novel.chapters.mapIndexed { index, name ->
            ChapterEntity(
                novelId = novel.id,
                idx = index,
                title = name,
                url = novel.chapterUrls.getOrNull(index) ?: "",
                completed = false,
                lastPageRead = 0,
                bookmark = false,
                lastReadAt = 0L
            )
        }
        DbWriter.submit("mangaEnsureRows(${novel.id})") {
            try {
                LorelightDatabase.get(appContext).chapterDao().syncChapterList(novel.id, rows)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /**
     * One-time import of the legacy `Novel.completedChapters` name list into the
     * chapters table, so users who already finished chapters on the novel side
     * do not appear to lose that history when this system takes over.
     */
    fun migrateLegacyCompleted(context: Context, novel: Novel) {
        if (novel.id.isEmpty() || novel.completedChapters.isEmpty()) return
        val appContext = context.applicationContext
        val done = novel.completedChapters.toHashSet()
        val indices = novel.chapters.withIndex()
            .filter { (_, name) -> name in done }
            .map { it.index }
        if (indices.isEmpty()) return
        DbWriter.submit("mangaMigrateLegacy(${novel.id})") {
            try {
                val dao = LorelightDatabase.get(appContext).chapterDao()
                // Only fill in gaps; never un-read something already recorded.
                val alreadyRead = dao.completedIndicesForNovel(novel.id).toHashSet()
                val toMark = indices.filter { it !in alreadyRead }
                if (toMark.isNotEmpty()) {
                    dao.setReadChunked(novel.id, toMark, true, System.currentTimeMillis())
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        bump()
    }

    // -----------------------------------------------------------------
    // Writes
    // -----------------------------------------------------------------

    /**
     * THE HOT PATH. Called on every page turn.
     *
     * Records the page the reader is on and, when the last page is reached,
     * marks the chapter read - mihon's behaviour, where finishing the final page
     * completes the chapter rather than requiring a manual tap.
     *
     * [pageCount] of 0 means "page count not known yet"; the position is still
     * saved but completion is not inferred.
     */
    fun setPageProgress(
        context: Context,
        novel: Novel,
        chapterIndex: Int,
        pageIndex: Int,
        pageCount: Int
    ) {
        if (novel.id.isEmpty() || chapterIndex < 0) return
        val appContext = context.applicationContext
        val page = pageIndex.coerceAtLeast(0)
        val finished = pageCount > 0 && page >= pageCount - 1
        val now = System.currentTimeMillis()
        val chapterName = novel.chapters.getOrNull(chapterIndex)

        DbWriter.submit("mangaPageProgress(${novel.id}:$chapterIndex)") {
            try {
                val dao = LorelightDatabase.get(appContext).chapterDao()
                // The row may not exist yet if the chapter list changed under us.
                if (chapterName != null) {
                    dao.insertMissing(
                        listOf(
                            ChapterEntity(
                                novelId = novel.id,
                                idx = chapterIndex,
                                title = chapterName,
                                url = novel.chapterUrls.getOrNull(chapterIndex) ?: "",
                                completed = false
                            )
                        )
                    )
                }
                // Never let the resume page walk backwards within a chapter that
                // is still in progress; a stale tick must not undo real reading.
                val existing = dao.getForNovel(novel.id).firstOrNull { it.idx == chapterIndex }
                val target = if (existing != null && existing.lastPageRead > page && !finished) {
                    existing.lastPageRead
                } else {
                    page
                }
                dao.setLastPageRead(novel.id, chapterIndex, target, now)
                if (finished) {
                    dao.setReadChunked(novel.id, listOf(chapterIndex), true, now)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        if (finished) syncCompletedMirror(appContext, novel.id)
        bump()
    }

    /**
     * mihon SetReadStatus parity. Marking unread also clears the saved page, so
     * an "unread" chapter really does restart from page 1.
     */
    fun setRead(context: Context, novel: Novel, chapterIndices: List<Int>, read: Boolean) {
        if (novel.id.isEmpty() || chapterIndices.isEmpty()) return
        val appContext = context.applicationContext
        val indices = chapterIndices.filter { it >= 0 }
        if (indices.isEmpty()) return
        val rows = indices.mapNotNull { index ->
            val name = novel.chapters.getOrNull(index) ?: return@mapNotNull null
            ChapterEntity(
                novelId = novel.id,
                idx = index,
                title = name,
                url = novel.chapterUrls.getOrNull(index) ?: "",
                completed = false
            )
        }
        DbWriter.submit("mangaSetRead(${novel.id}:${indices.size}:$read)") {
            try {
                val dao = LorelightDatabase.get(appContext).chapterDao()
                if (rows.isNotEmpty()) dao.insertMissing(rows)
                dao.setReadChunked(novel.id, indices, read, System.currentTimeMillis())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        syncCompletedMirror(appContext, novel.id)
        bump()
    }

    fun markRead(context: Context, novel: Novel, chapterIndex: Int) =
        setRead(context, novel, listOf(chapterIndex), true)

    fun markUnread(context: Context, novel: Novel, chapterIndex: Int) =
        setRead(context, novel, listOf(chapterIndex), false)

    /** mihon: "Mark previous as read". Everything strictly before [chapterIndex]. */
    fun markPreviousAsRead(context: Context, novel: Novel, chapterIndex: Int) {
        if (novel.id.isEmpty() || chapterIndex <= 0) return
        val appContext = context.applicationContext
        ensureRows(appContext, novel)
        DbWriter.submit("mangaMarkPrevious(${novel.id}:$chapterIndex)") {
            try {
                LorelightDatabase.get(appContext)
                    .chapterDao()
                    .markPreviousAsRead(novel.id, chapterIndex, System.currentTimeMillis())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        syncCompletedMirror(appContext, novel.id)
        bump()
    }

    /** Whole-novel mark read / unread, as offered by mihon's selection toolbar. */
    fun setAllRead(context: Context, novel: Novel, read: Boolean) {
        if (novel.id.isEmpty()) return
        val appContext = context.applicationContext
        ensureRows(appContext, novel)
        DbWriter.submit("mangaSetAllRead(${novel.id}:$read)") {
            try {
                LorelightDatabase.get(appContext)
                    .chapterDao()
                    .setReadForNovel(novel.id, read, System.currentTimeMillis())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        syncCompletedMirror(appContext, novel.id)
        bump()
    }

    fun setBookmark(context: Context, novel: Novel, chapterIndex: Int, bookmark: Boolean) {
        if (novel.id.isEmpty() || chapterIndex < 0) return
        val appContext = context.applicationContext
        ensureRows(appContext, novel)
        DbWriter.submit("mangaBookmark(${novel.id}:$chapterIndex)") {
            try {
                LorelightDatabase.get(appContext)
                    .chapterDao()
                    .setBookmark(novel.id, chapterIndex, bookmark)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        bump()
    }

    /** Drops all chapter rows for a novel leaving the library. */
    fun clear(context: Context, novelId: String) {
        if (novelId.isEmpty()) return
        val appContext = context.applicationContext
        DbWriter.submit("mangaClearProgress($novelId)") {
            try {
                LorelightDatabase.get(appContext).chapterDao().deleteForNovel(novelId)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        bump()
    }

    // -----------------------------------------------------------------
    // Legacy mirror
    // -----------------------------------------------------------------

    /**
     * Mirrors the authoritative chapters table back onto
     * `Novel.completedChapters`, which the in-reader chapter list and the
     * "finished this series" check in NewChaptersManager still read.
     *
     * Queued AFTER the read-state write on the same single writer thread, so it
     * always observes the value that was just committed.
     */
    private fun syncCompletedMirror(appContext: Context, novelId: String) {
        DbWriter.submit("mangaMirrorCompleted($novelId)") {
            try {
                val dao = LorelightDatabase.get(appContext).chapterDao()
                val readIndices = dao.completedIndicesForNovel(novelId).toHashSet()
                com.lorelight.service.NovelImportManager.updateNovel(appContext, novelId) { current ->
                    val names = current.chapters.withIndex()
                        .filter { (index, _) -> index in readIndices }
                        .map { it.value }
                    if (names.toSet() == current.completedChapters.toSet()) {
                        current
                    } else {
                        current.copy(completedChapters = names)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
