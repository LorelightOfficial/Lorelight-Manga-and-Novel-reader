package com.lorelight.manga.reader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.core.graphics.drawable.toDrawable
import coil.ImageLoader
import coil.decode.DecodeResult
import coil.decode.Decoder
import coil.decode.ImageSource
import coil.fetch.SourceResult
import coil.request.Options

/**
 * Decoder for oversized manga / manhwa pages.
 *
 * WHY THIS CLASS EXISTS
 * ---------------------
 * Webtoon sources serve single vertical strips 10,000-20,000 px tall. Coil's
 * stock decoder sizes from the layout width only, so for an 800 x 20,000 strip
 * it decodes the whole thing at ARGB_8888 -- 64 MB for ONE page -- which evicts
 * the memory cache and then throws OutOfMemoryError. Something has to impose a
 * budget.
 *
 * WHAT CHANGED, AND WHY THE OLD VERSION LOOKED WORSE THAN MIHON
 * -------------------------------------------------------------
 * The previous implementation defended memory with two blunt instruments, both
 * applied to EVERY tall page:
 *
 *   1. inPreferredConfig = RGB_565, unconditionally. 16-bit colour (5-6-5) is
 *      genuinely lossless for black-and-white line art, which is what the old
 *      comment claimed. But long strip mode is precisely where COLOURED manhwa
 *      lives, and 5 bits of red across a skin-tone or sky gradient bands
 *      visibly.
 *
 *   2. A flat 8,000,000-pixel budget with power-of-two downsampling. A very
 *      ordinary 800 x 12,000 strip is 9.6M pixels, so it tripped the budget and
 *      was sampled to 400 x 6,000 -- then stretched back up to fill a 1080 px
 *      wide screen. A 2.7x upscale of a half-resolution image is exactly the
 *      softness being compared against mihon.
 *
 * Mihon does neither. It keeps full resolution and lets SubsamplingScaleImageView
 * tile the strip, decoding only the region actually on screen. Real tiling is a
 * much larger change; this decoder closes most of the gap by inverting the two
 * decisions above:
 *
 *   1. RESOLUTION FLOOR. Never sample below the physical screen width. A
 *      720-900 px wide source on a 1080 px screen now decodes 1:1 instead of
 *      being halved.
 *
 *   2. FULL COLOUR FIRST. ARGB_8888 is the default. RGB_565 is the FIRST memory
 *      fallback, tried before any resolution is thrown away. Downsampling is
 *      the last resort rather than the first.
 *
 *   3. REAL BUDGET. The limit is bytes derived from the actual heap, not a fixed
 *      pixel count, so a device with headroom gets full quality instead of being
 *      held to the same ceiling as a 2 GB phone.
 *
 * Net effect on a typical 800 x 12,000 colour strip:
 *   before -> 400 x 6,000 @ RGB_565  (quarter resolution, 16-bit colour)
 *   after  -> 800 x 12,000 @ ARGB_8888 on a roomy device,
 *             800 x 12,000 @ RGB_565 on a tight one (full resolution either way)
 */
class MangaTallImageDecoder(
    private val source: ImageSource,
    private val options: Options,
    private val sampleSize: Int,
    private val preferredConfig: Bitmap.Config
) : Decoder {

    override suspend fun decode(): DecodeResult {
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = preferredConfig
            inMutable = false
        }
        val bitmap = source.source().inputStream().use { stream ->
            BitmapFactory.decodeStream(stream, null, opts)
        } ?: throw IllegalStateException("Could not decode manga page image")

        return DecodeResult(
            drawable = bitmap.toDrawable(options.context.resources),
            isSampled = sampleSize > 1
        )
    }

    class Factory : Decoder.Factory {
        override fun create(
            result: SourceResult,
            options: Options,
            imageLoader: ImageLoader
        ): Decoder? {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            try {
                // Peek the source to read image bounds without closing or consuming the underlying ImageSource.
                // Do NOT call .use {} or close the peeked stream, as that can close the underlying okio source.
                val stream = result.source.source().peek().inputStream()
                BitmapFactory.decodeStream(stream, null, bounds)
            } catch (t: Throwable) {
                return null
            }

            val width = bounds.outWidth
            val height = bounds.outHeight
            if (width <= 0 || height <= 0) return null

            val budget = decodeByteBudget()

            // An ordinary page that fits comfortably at full colour is handed
            // back to Coil's own decoder, which already sizes from the layout.
            if (height <= TALL_THRESHOLD_PX &&
                estimatedBytes(width, height, 1, Bitmap.Config.ARGB_8888) <= budget
            ) {
                return null
            }

            // 1. Resolution floor. Halve only while the result would still be at
            //    least as wide as the screen, so the reader never upscales.
            val screenWidth = screenWidthPx(options.context)
            var sample = 1
            while (sample < MAX_SAMPLE && (width / (sample * 2)) >= screenWidth) {
                sample *= 2
            }

            // 2. Memory fallbacks, least visible first: full colour, then 16-bit
            //    colour, and only then start discarding resolution.
            var config = Bitmap.Config.ARGB_8888
            while (estimatedBytes(width, height, sample, config) > budget) {
                if (config == Bitmap.Config.ARGB_8888) {
                    config = Bitmap.Config.RGB_565
                    continue
                }
                if (sample >= MAX_SAMPLE) break
                sample *= 2
            }

            return MangaTallImageDecoder(result.source, options, sample, config)
        }
    }

    companion object {
        /** Above this height a page is treated as a strip and budgeted explicitly. */
        const val TALL_THRESHOLD_PX = 4000

        /** Hard floor on quality: never sample more aggressively than 1/8. */
        private const val MAX_SAMPLE = 8

        /** Used only if display metrics are unavailable for some reason. */
        private const val FALLBACK_SCREEN_WIDTH_PX = 1080

        private const val MIN_BUDGET_BYTES = 24L * 1024 * 1024

        /**
         * A heap this big means largeHeap was honoured and the device has room
         * to spare. Anything below it gets the old conservative ceiling.
         */
        private const val ROOMY_HEAP_BYTES = 384L * 1024 * 1024

        /** Per-page ceiling on a roomy heap. See decodeByteBudget. */
        private const val ROOMY_MAX_BUDGET_BYTES = 72L * 1024 * 1024

        /**
         * Lowered from 96 MB. This is a PER-PAGE ceiling, and several pages
         * are alive at once (the visible one, its preloaded neighbours, and
         * whatever the memory cache is still holding). At 96 MB a handful of
         * colour strips could reserve more than the entire heap, which ends
         * as an OS low-memory kill rather than a catchable OutOfMemoryError.
         */
        private const val MAX_BUDGET_BYTES = 48L * 1024 * 1024

        private fun screenWidthPx(context: Context): Int {
            val w = try {
                context.resources.displayMetrics.widthPixels
            } catch (t: Throwable) {
                0
            }
            return if (w > 0) w else FALLBACK_SCREEN_WIDTH_PX
        }

        private fun bytesPerPixel(config: Bitmap.Config): Int =
            if (config == Bitmap.Config.RGB_565) 2 else 4

        private fun estimatedBytes(
            width: Int,
            height: Int,
            sample: Int,
            config: Bitmap.Config
        ): Long {
            val w = (width / sample).coerceAtLeast(1).toLong()
            val h = (height / sample).coerceAtLeast(1).toLong()
            return w * h * bytesPerPixel(config)
        }

        /**
         * Per-page decode budget in bytes, derived from the real heap rather
         * than a fixed pixel count. Roughly an eighth of max heap, clamped so
         * small devices stay safe and large ones actually benefit.
         */
        private fun decodeByteBudget(): Long {
            val maxHeap = try {
                Runtime.getRuntime().maxMemory()
            } catch (t: Throwable) {
                0L
            }
            if (maxHeap <= 0L) return MIN_BUDGET_BYTES

            // This number decides picture quality, not just memory. Every page
            // that does not fit inside it is decoded at 16-bit colour, and a
            // page that does not fit even then loses resolution. So on a phone
            // with a 512 MB heap the old flat eighth-of-heap ceiling was the
            // single biggest reason colour strips came out banded and soft: it
            // capped one page at 48 MB while hundreds of megabytes sat unused.
            //
            // largeHeap is on in the manifest, so a modern device reports
            // 384-512 MB here and gets a sixth of it, up to 72 MB -- enough for
            // a full-resolution ARGB_8888 colour strip around 1200 x 15000.
            // Small devices keep the old conservative numbers untouched, which
            // is where the low-memory kills came from in the first place.
            val roomy = maxHeap >= ROOMY_HEAP_BYTES
            val divisor = if (roomy) 6L else 8L
            val cap = if (roomy) ROOMY_MAX_BUDGET_BYTES else MAX_BUDGET_BYTES
            return (maxHeap / divisor).coerceIn(MIN_BUDGET_BYTES, cap)
        }
    }
}
