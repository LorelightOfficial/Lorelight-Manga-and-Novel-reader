package com.lorelight.browse.migrate

import android.content.Context
import com.lorelight.browse.js.JSPluginEngine
import com.lorelight.browse.model.InstalledPlugin
import com.lorelight.browse.model.SourceNovelDetails
import com.lorelight.browse.model.pluginChapterUrl
import com.lorelight.browse.repo.PluginStore
import com.lorelight.data.model.Novel
import com.lorelight.util.ChapterNumbering

/**
 * Source transfer / migration.
 *
 * When a site dies its novels can no longer fetch chapter text. This moves a
 * novel to a different installed source: the extraction link (pluginId,
 * pluginNovelPath, sourceUrl, chapterUrls) is replaced while reading progress
 * and history are carried over.
 *
 * THE TRAP THIS FILE EXISTS TO AVOID:
 * Novel.currentChapter and Novel.completedChapters are chapter NAME strings and
 * the reader resolves them with chapters.indexOf(name). Chapter names are NOT
 * stable between sites ("Chapter 67" vs "Ch. 67 - The Duel"), so simply
 * swapping the chapter list makes indexOf() return -1 and silently drops the
 * reader back to chapter 1. Progress is therefore re-anchored by PARSED
 * CHAPTER NUMBER, with same-index as a fallback.
 */

/** One possible match for a novel on a target source. */
data class MigrationCandidate(
    val pluginId: String,
    val pluginName: String,
    val name: String,
    val path: String,
    val cover: String? = null
)

/** How the reading position was carried across. */
enum class AnchorMethod {
    EXACT_NUMBER,
    NEAREST_NUMBER,
    SAME_INDEX,
    RESET
}

/** Outcome of a migration, used to render a confirmation summary. */
data class MigrationResult(
    val novel: Novel,
    val oldChapterCount: Int,
    val newChapterCount: Int,
    val oldChapterName: String,
    val newChapterName: String,
    val anchorMethod: AnchorMethod,
    val completedCarried: Int,
    val completedTotal: Int
)

object NovelSourceMigrator {

    /** Installed sources that can be migration targets, current source excluded. */
    fun installedTargets(context: Context, excludePluginId: String?): List<InstalledPlugin> =
        PluginStore.getInstalled(context)
            .filter { it.info.id.isNotBlank() && it.info.id != excludePluginId }
            .sortedBy { it.info.name.lowercase() }

    /**
     * Progressively looser search terms. Sites rarely index the exact stored
     * title, so a failed full-title search is retried with a trimmed form.
     */
    fun searchQueries(title: String): List<String> {
        val base = title.trim()
        if (base.isEmpty()) return emptyList()
        val out = LinkedHashSet<String>()
        out.add(base)
        val noBrackets = base
            .replace(Regex("""[\(\[\{].*?[\)\]\}]"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
        if (noBrackets.isNotEmpty()) out.add(noBrackets)
        val beforeSep = noBrackets.split(":", " - ", "|").firstOrNull()?.trim().orEmpty()
        if (beforeSep.length >= 4) out.add(beforeSep)
        val words = noBrackets.split(" ").filter { it.isNotBlank() }
        if (words.size > 4) out.add(words.take(4).joinToString(" "))
        return out.filter { it.length >= 2 }.toList()
    }

    /**
     * Searches one target source for a novel, trying looser queries until
     * something comes back. Never auto-picks: the caller always confirms.
     */
    suspend fun searchCandidates(
        context: Context,
        pluginId: String,
        pluginName: String,
        title: String
    ): List<MigrationCandidate> {
        val appContext = context.applicationContext
        for (q in searchQueries(title)) {
            val items = try {
                JSPluginEngine.searchNovels(appContext, pluginId, q, 1)
            } catch (e: Exception) {
                emptyList()
            }
            val mapped = items
                .filter { it.path.isNotBlank() }
                .map {
                    MigrationCandidate(
                        pluginId = pluginId,
                        pluginName = pluginName,
                        name = it.name.ifBlank { q },
                        path = it.path,
                        cover = it.cover
                    )
                }
            if (mapped.isNotEmpty()) return mapped.distinctBy { it.path }
        }
        return emptyList()
    }

    /**
     * Numeric value per chapter on the new source. Source-provided numbers win,
     * otherwise the number is parsed out of the chapter name. -1f = unknown.
     */
    private fun numbersFor(details: SourceNovelDetails, names: List<String>): List<Float> =
        names.mapIndexed { index, name ->
            val provided = details.chapters.getOrNull(index)?.chapterNumber
            val fromSource = if (provided != null && provided >= 0) provided.toFloat() else null
            fromSource ?: ChapterNumbering.parseChapterNumberFromName(name) ?: -1f
        }

    /** Index of the chapter whose number equals [target], or -1. */
    private fun exactIndexOf(numbers: List<Float>, target: Float): Int =
        numbers.indexOfFirst { it >= 0f && it == target }

    /**
     * Closest chapter at or below [target] so the reader never skips forward
     * past unread content; falls back to the closest number either way.
     */
    private fun nearestIndexOf(numbers: List<Float>, target: Float): Int {
        var bestBelow = -1
        var bestBelowVal = -1f
        var bestAny = -1
        var bestAnyDist = Float.MAX_VALUE
        numbers.forEachIndexed { index, value ->
            if (value >= 0f) {
                if (value <= target && value > bestBelowVal) {
                    bestBelowVal = value
                    bestBelow = index
                }
                val dist = kotlin.math.abs(value - target)
                if (dist < bestAnyDist) {
                    bestAnyDist = dist
                    bestAny = index
                }
            }
        }
        return if (bestBelow >= 0) bestBelow else bestAny
    }

    /**
     * Performs the transfer. Returns the rewritten Novel plus a summary of how
     * the reading position was carried across. Throws if the target entry has
     * no chapters, so the caller can keep the old source untouched.
     */
    suspend fun migrate(
        context: Context,
        novel: Novel,
        candidate: MigrationCandidate
    ): MigrationResult {
        val appContext = context.applicationContext
        val details = JSPluginEngine.parseNovel(appContext, candidate.pluginId, candidate.path)

        val newNames = details.chapters.mapIndexed { index, ch ->
            ch.name.takeIf { it.isNotBlank() } ?: "Chapter ${index + 1}"
        }
        if (newNames.isEmpty()) {
            throw IllegalStateException("That entry has no chapters on the new source.")
        }
        val newUrls = details.chapters.map { pluginChapterUrl(candidate.pluginId, it.path) }
        val newNumbers = numbersFor(details, newNames)

        val oldNames = novel.chapters
        val rawOldIndex = oldNames.indexOf(novel.currentChapter)
        val oldIndex = if (rawOldIndex >= 0) rawOldIndex else 0
        val oldNumber = ChapterNumbering.resolveChapterNumber(novel, oldIndex, novel.currentChapter)

        var method = AnchorMethod.RESET
        var newIndex = 0
        if (oldNumber != null && oldNumber >= 0f) {
            val exact = exactIndexOf(newNumbers, oldNumber)
            if (exact >= 0) {
                newIndex = exact
                method = AnchorMethod.EXACT_NUMBER
            } else {
                val near = nearestIndexOf(newNumbers, oldNumber)
                if (near >= 0) {
                    newIndex = near
                    method = AnchorMethod.NEAREST_NUMBER
                }
            }
        }
        if (method == AnchorMethod.RESET && oldIndex >= 0 && oldIndex < newNames.size) {
            newIndex = oldIndex
            method = AnchorMethod.SAME_INDEX
        }
        newIndex = newIndex.coerceIn(0, newNames.size - 1)

        // Carry finished chapters across by number, not by name.
        val numberToIndex = HashMap<Float, Int>()
        newNumbers.forEachIndexed { index, value ->
            if (value >= 0f && !numberToIndex.containsKey(value)) {
                numberToIndex[value] = index
            }
        }
        val carried = ArrayList<String>()
        for (done in novel.completedChapters) {
            val doneIndex = oldNames.indexOf(done)
            val doneNumber = if (doneIndex >= 0) {
                ChapterNumbering.resolveChapterNumber(novel, doneIndex, done)
            } else {
                ChapterNumbering.parseChapterNumberFromName(done)
            }
            val target = if (doneNumber != null && doneNumber >= 0f) numberToIndex[doneNumber] else null
            if (target != null) {
                val name = newNames[target]
                if (!carried.contains(name)) carried.add(name)
            }
        }

        // Keep the cover the user already sees; only fall back to the new site.
        val cover = novel.coverImageBase64 ?: details.cover ?: candidate.cover

        val migrated = novel.copy(
            pluginId = candidate.pluginId,
            pluginNovelPath = candidate.path,
            sourceUrl = candidate.path,
            isOnline = true,
            chapters = newNames,
            chapterUrls = newUrls,
            chapterNumbers = newNumbers,
            totalChapters = newNames.size,
            coverImageBase64 = cover,
            currentChapter = newNames[newIndex],
            completedChapters = carried
        )

        return MigrationResult(
            novel = migrated,
            oldChapterCount = oldNames.size,
            newChapterCount = newNames.size,
            oldChapterName = novel.currentChapter,
            newChapterName = newNames[newIndex],
            anchorMethod = method,
            completedCarried = carried.size,
            completedTotal = novel.completedChapters.size
        )
    }
}
