/*
 * =============================================================================
 * CompanionDetector.kt - notices things worth mentioning.
 * Package: com.lorelight.companion
 *
 * The detector knows NOTHING about Room, view models, or navigation. The app
 * hands it a small snapshot of facts (CompanionSignals) and it hands back a
 * list of candidate events. That keeps the character testable and keeps the
 * app free to change how it stores things.
 *
 * It also owns the "how long were you gone" memory, because that is the one
 * fact nobody else in the app tracks.
 *
 * Nothing here decides whether he SPEAKS - it only decides what is true.
 * CompanionGovernor makes every frequency decision.
 * =============================================================================
 */
package com.lorelight.companion

import java.util.Calendar

/** A book the user started and drifted away from. */
class UnfinishedTitle(
    val title: String,
    /** 0f..1f through the book. */
    val progress: Float,
    val idleDays: Int
)

/**
 * Everything the character is allowed to know about the app right now.
 * All fields are optional - unknown facts simply produce no candidates.
 */
class CompanionSignals(
    val libraryCount: Int = 0,
    val streakDays: Int = 0,
    val sessionStartAt: Long = 0L,
    val surface: CompanionSurface = CompanionSurface.BROWSE,
    val unfinished: UnfinishedTitle? = null
)

class CompanionDetector(private val store: CompanionStore) {

    /* --- arrival ---------------------------------------------------------- */

    /**
     * Which "you're back" event applies, based on the gap since the app was
     * last seen. Exactly one of the five, or none.
     *
     * Call BEFORE noteSeen() for the current launch, or the gap is always 0.
     */
    fun arrivalCandidate(now: Long): Candidate? {
        val last = store.getLong(LAST_SEEN, 0L)

        if (last <= 0L) return Candidate(CompanionEvent.FIRST_EVER)

        val gapMs = now - last
        if (gapMs < 0L) return null   // clock moved backwards; say nothing

        val hours = gapMs / HOUR_MS
        val days = (gapMs / DAY_MS).toInt()

        val event = when {
            days >= CompanionPolicy.AWAY_AGES_MIN_DAYS -> CompanionEvent.BACK_AFTER_AGES
            days >= CompanionPolicy.AWAY_WEEK_MIN_DAYS -> CompanionEvent.BACK_AFTER_WEEK
            hours >= CompanionPolicy.AWAY_SAME_DAY_MAX_H -> CompanionEvent.BACK_AFTER_DAY
            else -> CompanionEvent.BACK_SAME_DAY
        }

        // Only the "after a week / after ages" lines actually say a number.
        return Candidate(event, LineParams(days = if (days > 0) days else null))
    }

    /** Remembers this visit. Call once the arrival check is done. */
    fun noteSeen(now: Long) {
        store.putLong(LAST_SEEN, now)
    }

    /** True when enough time has passed to call this a fresh session. */
    fun isNewSession(now: Long): Boolean {
        val last = store.getLong(LAST_SEEN, 0L)
        if (last <= 0L) return true
        return now - last >= CompanionPolicy.SESSION_GAP_MS
    }

    /* --- ambient ---------------------------------------------------------- */

    /**
     * Everything quietly true right now: the hour, the streak, how long this
     * sitting has lasted, a book gathering dust.
     *
     * IDLE_MUSING is always included as the last resort so a long silence
     * still occasionally produces something - it is ranked last, so it only
     * ever wins when nothing else is true.
     */
    fun ambientCandidates(now: Long, signals: CompanionSignals): List<Candidate> {
        val out = ArrayList<Candidate>(6)

        libraryMilestone(signals.libraryCount)?.let {
            out.add(Candidate(CompanionEvent.LIBRARY_GROWING, LineParams(n = it)))
        }

        if (signals.streakDays >= CompanionPolicy.STREAK_MIN_DAYS) {
            out.add(Candidate(CompanionEvent.STREAK, LineParams(n = signals.streakDays)))
        }

        if (signals.sessionStartAt > 0L &&
            now - signals.sessionStartAt >= CompanionPolicy.LONG_SESSION_MS
        ) {
            val minutes = ((now - signals.sessionStartAt) / 60_000L).toInt()
            out.add(Candidate(CompanionEvent.LONG_SESSION, LineParams(n = minutes)))
        }

        signals.unfinished?.let { book ->
            if (book.progress in CompanionPolicy.UNFINISHED_MIN_PROGRESS..
                CompanionPolicy.UNFINISHED_MAX_PROGRESS &&
                book.idleDays >= CompanionPolicy.UNFINISHED_MIN_IDLE_DAYS &&
                perTitleCooldownPassed(book.title, now)
            ) {
                out.add(
                    Candidate(
                        CompanionEvent.UNFINISHED_WAITING,
                        LineParams(title = book.title, days = book.idleDays)
                    )
                )
            }
        }

        timeOfDayCandidate(now)?.let { out.add(it) }

        out.add(Candidate(CompanionEvent.IDLE_MUSING))
        return out
    }

    /**
     * Late night and early morning, in the user's own timezone.
     * Deliberately narrow windows - these lines are a small surprise, and a
     * surprise available for eight hours is just a schedule.
     */
    private fun timeOfDayCandidate(now: Long): Candidate? {
        val cal = Calendar.getInstance()
        cal.timeInMillis = now
        val hour = cal.get(Calendar.HOUR_OF_DAY)

        return when (hour) {
            in CompanionPolicy.LATE_NIGHT_START_H until CompanionPolicy.LATE_NIGHT_END_H ->
                Candidate(CompanionEvent.LATE_NIGHT)
            in CompanionPolicy.EARLY_MORNING_START_H until CompanionPolicy.EARLY_MORNING_END_H ->
                Candidate(CompanionEvent.EARLY_MORNING)
            else -> null
        }
    }

    /**
     * Returns the milestone just crossed, once ever.
     *
     * Passing 25 books is a moment exactly one time. Re-crossing it after
     * deleting something is not a moment.
     */
    private fun libraryMilestone(count: Int): Int? {
        if (count <= 0) return null
        val highest = store.getInt(MILESTONE_DONE, 0)

        var crossed: Int? = null
        for (m in CompanionPolicy.LIBRARY_MILESTONES) {
            if (count >= m && m > highest) crossed = m
        }
        return crossed
    }

    /** Call when a LIBRARY_GROWING line really was spoken. */
    fun noteMilestoneSpoken(milestone: Int) {
        if (milestone > store.getInt(MILESTONE_DONE, 0)) {
            store.putInt(MILESTONE_DONE, milestone)
        }
    }

    /**
     * He must not badger you about the same abandoned book every day, so each
     * title gets its own multi-day cooldown.
     */
    private fun perTitleCooldownPassed(title: String, now: Long): Boolean {
        val key = titleKey(title)
        val last = store.getLong(key, 0L)
        if (last <= 0L) return true
        val waitMs = CompanionPolicy.UNFINISHED_PER_TITLE_COOLDOWN_DAYS * DAY_MS
        return now - last >= waitMs
    }

    /** Call when an UNFINISHED_WAITING line really was spoken about a title. */
    fun noteTitleNagged(title: String, now: Long) {
        store.putLong(titleKey(title), now)
    }

    /**
     * Titles are long and arbitrary, so the key is a hash. A collision would
     * only mean one book's nag cooldown is shared with another - harmless.
     */
    private fun titleKey(title: String) = "nagged." + title.lowercase().trim().hashCode()

    companion object {
        private const val HOUR_MS = 3_600_000L
        private const val DAY_MS = 86_400_000L

        private const val LAST_SEEN = "lastSeen"
        private const val MILESTONE_DONE = "milestone.done"
    }
}
