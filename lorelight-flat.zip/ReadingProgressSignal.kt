package com.lorelight.data.local

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * App-wide "the reading position moved" signal.
 *
 * WHY THIS EXISTS
 *
 * Manga was always live and novels never were, and the reason was a single
 * missing line. Manga progress is written through
 * NovelImportManager.updateNovelProgress, which ends in bump() -> tick, and
 * MainActivity collects tick and reloads the library. Novel progress is written
 * through NovelPreferences.saveProgressOnly, which notified nobody at all.
 *
 * So the novel row on disk was correct within milliseconds while every screen
 * kept rendering the copy it had loaded at app start. That is what produced the
 * whole cluster of "not updating" symptoms:
 *
 *  - the chapter-list highlight in Details stayed on an old chapter
 *  - the Continue Reading card read its number from that same stale novel
 *  - History showed whatever it was given when it was first built
 *
 * They were never three bugs. They were one stale list rendered three times.
 *
 * Bumping this is deliberately cheap: it sets an Int. The listener in
 * MainActivity is what debounces and does the actual reload, because a TTS
 * session flushes roughly every five sentences and reloading the library that
 * often would be wasteful.
 */
object ReadingProgressSignal {
    private val _version = MutableStateFlow(0)

    /** Increments every time any reading position is persisted. */
    val version: StateFlow<Int> = _version.asStateFlow()

    fun notifyChanged() {
        _version.update { it + 1 }
    }
}
