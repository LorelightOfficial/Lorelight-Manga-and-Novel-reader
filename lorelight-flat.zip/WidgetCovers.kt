package com.lorelight.widget

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import android.util.LruCache
import androidx.core.graphics.drawable.toBitmap
import coil.request.CachePolicy
import coil.request.ImageRequest
import coil.request.SuccessResult
import coil.size.Scale
import com.lorelight.data.local.CoverStorage
import com.lorelight.data.model.Novel
import com.lorelight.data.model.isManga
import com.lorelight.data.model.mangaSourceId
import com.lorelight.manga.reader.MangaImageLoaderProvider
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import tachiyomi.domain.manga.model.MangaCover
import java.io.File

/** Small bitmaps bound RemoteViews memory; remote manga uses its source-aware loader. */
internal object WidgetCovers {
    private val cache = LruCache<String, Bitmap>(32)
    fun clear() { cache.evictAll() }
    suspend fun get(context: Context, novel: Novel, network: Boolean = false): Bitmap? {
        val local = CoverStorage.coverFile(context, novel.id)
        val raw = novel.coverImageBase64
        val key = "${novel.id}:${raw?.hashCode()}:${local.lastModified()}"
        cache.get(key)?.let { return it }
        return withTimeoutOrNull(if (network) 3000L else 900L) {
            val data: Any = when {
                local.exists() && local.length() > 0 -> local
                raw.isNullOrBlank() -> return@withTimeoutOrNull null
                raw.startsWith("file://") -> File(android.net.Uri.parse(raw).path ?: return@withTimeoutOrNull null)
                raw.startsWith("/") -> File(raw)
                raw.startsWith("content://") -> android.net.Uri.parse(raw)
                raw.startsWith("http", true) -> if (novel.isManga) MangaCover(
                    mangaId = -1L, sourceId = novel.mangaSourceId ?: -1L,
                    isMangaFavorite = false, url = raw, lastModified = 0L) else raw
                else -> runCatching { Base64.decode(raw.substringAfter("base64,", raw), Base64.DEFAULT) }.getOrNull()
                    ?: return@withTimeoutOrNull null
            }
            val result = MangaImageLoaderProvider.getCoverImageLoader(context).execute(
                ImageRequest.Builder(context).data(data).size(80,112).scale(Scale.FILL)
                    .allowHardware(false).networkCachePolicy(if (network) CachePolicy.ENABLED else CachePolicy.DISABLED).build())
            (result as? SuccessResult)?.drawable?.toBitmap(80,112,Bitmap.Config.ARGB_8888)?.also { cache.put(key,it) }
        }
    }
    suspend fun prefetch(context: Context, novels: List<Novel>) = coroutineScope {
        val limit = Semaphore(3)
        novels.map { n -> async { limit.withPermit {
            try { get(context,n,true) } catch (e: CancellationException) { throw e } catch (_: Exception) { null }
        } } }.awaitAll()
    }
}
