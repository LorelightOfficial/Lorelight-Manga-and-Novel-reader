package com.lorelight.companion

import com.lorelight.ui.theme.modeswitch.celestial.CelestialExpression
import com.lorelight.ui.theme.modeswitch.celestial.CelestialFaceState

/** App event vocabulary retained; all performances use the NEW emotion engine.
 * HOP and BREATHE no longer translate, bob or scale the seated character. */
enum class CompanionGesture(val sunMs: Long) {
    GLANCE_LEFT(980L),
    GLANCE_RIGHT(1040L),
    GLANCE_DOWN(1100L),
    TILT_CURIOUS(1450L),
    NOD(1500L),
    HOP(1400L),
    WINCE(1400L),
    DOZE(2200L),
    WAKE(1000L),
    SLEEPY_SQUINT(1500L),
    LOOK_AWAY(1500L),
    EYE_ROLL(1400L),
    DOUBLE_TAKE(1100L),
    BREATHE(1700L);
    fun durationMs(mood: Mood): Long = if (mood == Mood.SUN) sunMs else (sunMs * 1.18f).toLong()
}

suspend fun CelestialFaceState.playGesture(gesture: CompanionGesture, mood: Mood, reduceMotion: Boolean = false) {
    val expressions = when (gesture) {
        CompanionGesture.GLANCE_LEFT -> listOf(CelestialExpression.LOOK_AROUND)
        CompanionGesture.GLANCE_RIGHT -> listOf(CelestialExpression.CURIOUS)
        CompanionGesture.GLANCE_DOWN -> listOf(CelestialExpression.THINKING)
        CompanionGesture.TILT_CURIOUS -> listOf(CelestialExpression.CURIOUS, CelestialExpression.CONFUSED, CelestialExpression.THINKING)
        CompanionGesture.NOD -> listOf(CelestialExpression.GRATEFUL, CelestialExpression.RELIEVED, CelestialExpression.HOPEFUL, CelestialExpression.CONTENT)
        CompanionGesture.HOP -> listOf(CelestialExpression.JOY, CelestialExpression.LAUGH, CelestialExpression.DELIGHTED, CelestialExpression.EXCITED, CelestialExpression.PROUD)
        CompanionGesture.WINCE -> listOf(CelestialExpression.ANNOYED, CelestialExpression.FRUSTRATED, CelestialExpression.DISAPPOINTED, CelestialExpression.WORRIED, CelestialExpression.SAD)
        CompanionGesture.DOZE -> listOf(CelestialExpression.DOZING)
        CompanionGesture.WAKE -> listOf(CelestialExpression.AWAKENING, CelestialExpression.FOCUSED, CelestialExpression.DETERMINED)
        CompanionGesture.SLEEPY_SQUINT -> listOf(CelestialExpression.SLEEPY, CelestialExpression.YAWN, CelestialExpression.TIRED)
        CompanionGesture.LOOK_AWAY -> listOf(CelestialExpression.SHY, CelestialExpression.EMBARRASSED, CelestialExpression.AFFECTIONATE)
        CompanionGesture.EYE_ROLL -> listOf(CelestialExpression.BORED, CelestialExpression.SKEPTICAL, CelestialExpression.SMUG)
        CompanionGesture.DOUBLE_TAKE -> listOf(CelestialExpression.SURPRISE, CelestialExpression.SHOCKED, CelestialExpression.AFRAID)
        CompanionGesture.BREATHE -> listOf(CelestialExpression.CONTENT, CelestialExpression.PLAYFUL, CelestialExpression.WINK)
    }
    perform(expressions.random(), timeScale = if (mood == Mood.SUN) 1f else 1.18f, reduced = reduceMotion)
}
