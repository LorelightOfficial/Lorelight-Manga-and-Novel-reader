package com.lorelight.manga.reader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.graphics.drawable.toBitmap
import coil.request.CachePolicy
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.lorelight.tts.TtsPlaybackManager
import eu.kanade.tachiyomi.source.model.Page
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale

/**
 * Screen-based TTS for the manga reader.
 *
 * Deliberately standalone: this does NOT go through TtsPlaybackManager or
 * TtsPlaybackService. It owns its own TextToSpeech instance, runs no
 * foreground service and holds no wake lock, so it stops when the screen
 * turns off. Voice, rate and pitch come from MangaReaderPrefs -- the manga
 * reader's own store -- so nothing chosen for manga can change novel playback.
 * It never writes session state either, which is what keeps the Continue
 * Reading card free of a play button for manga.
 */
data class MangaTextBlock(
    val text: String,
    val left: Int,
    val top: Int,
    val right: Int,
    val bottom: Int,
    val pageWidth: Int,
    val pageHeight: Int
) {
    val centerX: Int get() = (left + right) / 2
    val centerY: Int get() = (top + bottom) / 2
    val blockWidth: Int get() = (right - left).coerceAtLeast(1)
    val blockHeight: Int get() = (bottom - top).coerceAtLeast(1)

    /** Vertical position of this bubble within its page, 0f..1f. */
    val verticalFraction: Float
        get() = if (pageHeight > 0) (centerY.toFloat() / pageHeight.toFloat()).coerceIn(0f, 1f) else 0f
}

/**
 * Structured outcome of an OCR pass to strictly separate genuine zero-text pages
 * from image loading failures, recognizer crashes, and cancellations.
 */
sealed interface MangaPageOcrResult {
    data class Success(
        val blocks: List<MangaTextBlock>,
        val durationMs: Long = 0L,
        val fromCache: Boolean = false
    ) : MangaPageOcrResult {
        val isZeroText: Boolean get() = blocks.isEmpty()
    }

    data class ImageLoadError(
        val message: String,
        val durationMs: Long = 0L
    ) : MangaPageOcrResult

    data class RecognizerError(
        val message: String,
        val cause: Throwable? = null,
        val durationMs: Long = 0L
    ) : MangaPageOcrResult

    data object Cancelled : MangaPageOcrResult
}

/**
 * Loads a manga page through the exact same Coil path the viewer uses
 * (MangaPageKey -> MangaPageFetcher -> Tachiyomi HttpSource) so that headers,
 * cookies and the memory/disk cache are all shared. Loading by bare URL would
 * bypass the source and fail on most extensions.
 */
object MangaPageOcr {

    private const val TAG = "LorelightOCR"

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private val creditRegex = Regex(
        "translat|scanlat|typeset|proofread|redraw|clean(er|ing)|raw provider|uploader|" +
            "discord|patreon|reddit|tumblr|facebook|instagram|twitter|www\\.|https?://|" +
            "\\.com|\\.net|\\.org",
        RegexOption.IGNORE_CASE
    )

    private data class TileConfig(
        val tileHeight: Int,
        val overlap: Int,
        val maxTileWidth: Int = 2560
    )

    private data class TiledOcrOutcome(
        val blocks: List<MangaTextBlock>,
        val hasTimeoutOrError: Boolean,
        val failureMessage: String? = null
    )

    private data class OcrRetryResult(
        val blocks: List<MangaTextBlock>,
        val hasErrors: Boolean
    )

    // -- Seam stitching across image boundaries ----------------------------
    // Webtoon chapters arrive pre-sliced into consecutive image files, and the
    // slicer does not care about speech bubbles: one line of dialogue is
    // routinely cut in half, its top on page N and its bottom on page N+1.
    // ML Kit then sees two mutilated fragments, so read-aloud drops the line,
    // reads only half of it, or mispronounces both halves.
    //
    // Fix: when OCR finds a block hugging a page edge, physically splice the
    // tail of page N onto the head of page N+1, OCR that narrow strip, and
    // look for a text block that CROSSES the join. If one exists the line
    // really was cut, and that block holds the whole sentence: page N speaks
    // the repaired line and page N+1 drops the duplicate fragment. If nothing
    // crosses the join the slice was clean and neither page is touched, so
    // this can never corrupt a correctly-sliced chapter.

    /** Same-chapter neighbours of the page being scanned. */
    data class SeamNeighbors(val prev: Page? = null, val next: Page? = null)

    private const val SEAM_PREFIX = "lorelight_seam_v1::"
    private const val SEAM_EDGE_TOL_FRAC = 0.025f
    private const val SEAM_EDGE_TOL_MIN_PX = 8
    private const val SEAM_EDGE_TOL_MAX_PX = 140
    private const val SEAM_STRIP_FRAC = 0.12f
    private const val SEAM_STRIP_MAX_PX = 600
    private const val SEAM_STRIP_MIN_PX = 64
    private const val SEAM_CROSS_MIN_PX = 6

    /** Disk-cache key for a page. Shared by the OCR cache and the seam keys. */
    fun pageKeyOf(page: Page): String =
        page.imageUrl?.takeIf { it.isNotBlank() }
            ?: page.url.takeIf { it.isNotBlank() }?.let { "$it#${page.index}" }
            ?: "page_${page.index}"

    private fun edgeTolerance(pageHeight: Int): Int =
        (pageHeight * SEAM_EDGE_TOL_FRAC).toInt()
            .coerceIn(SEAM_EDGE_TOL_MIN_PX, SEAM_EDGE_TOL_MAX_PX)

    private fun bottomEdgeBlock(blocks: List<MangaTextBlock>): MangaTextBlock? {
        val h = blocks.firstOrNull()?.pageHeight ?: return null
        if (h <= 0) return null
        val tol = edgeTolerance(h)
        return blocks.filter { it.bottom >= h - tol }.maxByOrNull { it.bottom }
    }

    private fun topEdgeBlock(blocks: List<MangaTextBlock>): MangaTextBlock? {
        val h = blocks.firstOrNull()?.pageHeight ?: return null
        if (h <= 0) return null
        val tol = edgeTolerance(h)
        return blocks.filter { it.top <= tol }.minByOrNull { it.top }
    }

    /** Same-chapter previous/next pages of [target]. */
    fun seamNeighbors(
        items: List<MangaFeedItem.Page>,
        target: MangaFeedItem.Page
    ): SeamNeighbors {
        val sameChapter = items.filter { it.chapterIndex == target.chapterIndex }
        val i = sameChapter.indexOfFirst { it.pageIndex == target.pageIndex }
        if (i < 0) return SeamNeighbors()
        val toPage: (MangaFeedItem.Page?) -> Page? = { p ->
            p?.let { it.sourcePage ?: Page(it.pageIndex, it.imageUrl, it.imageUrl) }
        }
        return SeamNeighbors(
            prev = toPage(sameChapter.getOrNull(i - 1)),
            next = toPage(sameChapter.getOrNull(i + 1))
        )
    }

    /**
     * Text of the single line that crosses the join between [pageA] and
     * [pageB], or null when that join is clean.
     *
     * Cached on disk under a synthetic seam key, so each boundary is spliced
     * exactly once no matter which of the two pages the reader reaches first.
     * One cached block carrying pageWidth == -1 is the "evaluated, clean join"
     * sentinel; without it every clean boundary would be re-spliced on every
     * session.
     */
    private suspend fun seamText(
        context: Context,
        sourceId: Long,
        pageA: Page,
        pageB: Page
    ): String? = withContext(Dispatchers.IO) {
        val seamKey = SEAM_PREFIX + pageKeyOf(pageA) + "::" + pageKeyOf(pageB)
        com.lorelight.manga.download.MangaOcrCache.load(context, sourceId, seamKey)?.let { cached ->
            val first = cached.firstOrNull()
            return@withContext if (first == null || first.pageWidth == -1 || first.text.isBlank()) {
                null
            } else {
                first.text
            }
        }

        val bmpA = loadBitmap(context, sourceId, pageA) ?: return@withContext null
        val bmpB = loadBitmap(context, sourceId, pageB) ?: return@withContext null

        val sliceA = (bmpA.height * SEAM_STRIP_FRAC).toInt()
            .coerceIn(SEAM_STRIP_MIN_PX, SEAM_STRIP_MAX_PX)
            .coerceAtMost(bmpA.height)
        val sliceB = (bmpB.height * SEAM_STRIP_FRAC).toInt()
            .coerceIn(SEAM_STRIP_MIN_PX, SEAM_STRIP_MAX_PX)
            .coerceAtMost(bmpB.height)
        val stripW = maxOf(bmpA.width, bmpB.width)
        val stripH = sliceA + sliceB
        if (stripW < 32 || stripH < 32) return@withContext null

        var strip: Bitmap? = null
        try {
            strip = Bitmap.createBitmap(stripW, stripH, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(strip)
            canvas.drawColor(android.graphics.Color.WHITE)
            val offA = (stripW - bmpA.width) / 2
            val offB = (stripW - bmpB.width) / 2
            canvas.drawBitmap(
                bmpA,
                android.graphics.Rect(0, bmpA.height - sliceA, bmpA.width, bmpA.height),
                android.graphics.Rect(offA, 0, offA + bmpA.width, sliceA),
                null
            )
            canvas.drawBitmap(
                bmpB,
                android.graphics.Rect(0, 0, bmpB.width, sliceB),
                android.graphics.Rect(offB, sliceA, offB + bmpB.width, stripH),
                null
            )

            val recognized = try {
                runRecognizer(strip, timeoutMs = 12_000L)
            } catch (t: Throwable) {
                Log.w(TAG, "[LorelightOCR] Seam OCR failed for $seamKey: ${t.message}")
                return@withContext null
            }

            val stripBlocks = recognized.textBlocks.mapNotNull { block ->
                val box = block.boundingBox ?: return@mapNotNull null
                val joined = joinLines(block.lines.map { it.text })
                if (joined.isBlank()) return@mapNotNull null
                MangaTextBlock(
                    text = joined,
                    left = box.left.coerceIn(0, stripW),
                    top = box.top.coerceIn(0, stripH),
                    right = box.right.coerceIn(0, stripW),
                    bottom = box.bottom.coerceIn(0, stripH),
                    pageWidth = stripW,
                    pageHeight = stripH
                )
            }

            // A block only counts as severed if it starts clearly above the
            // join and ends clearly below it. A few pixels of slop on either
            // side is antialiasing, not a cut line.
            val crossing = stripBlocks.firstOrNull {
                it.top <= sliceA - SEAM_CROSS_MIN_PX && it.bottom >= sliceA + SEAM_CROSS_MIN_PX
            }

            if (crossing == null || crossing.text.isBlank()) {
                com.lorelight.manga.download.MangaOcrCache.save(
                    context, sourceId, seamKey,
                    listOf(MangaTextBlock("", 0, 0, 0, 0, -1, 0))
                )
                return@withContext null
            }

            com.lorelight.manga.download.MangaOcrCache.save(context, sourceId, seamKey, listOf(crossing))
            com.lorelight.core.DevLogStore.append(
                context,
                "MangaOCR",
                "Seam repaired across image boundary (${crossing.text.length} chars): ${crossing.text.take(60)}"
            )
            return@withContext crossing.text
        } catch (t: Throwable) {
            Log.w(TAG, "[LorelightOCR] Seam splice failed for $seamKey: ${t.message}")
            return@withContext null
        } finally {
            strip?.let { if (!it.isRecycled) it.recycle() }
        }
    }

    /**
     * Repairs lines severed by the image slicer, using the page's same-chapter
     * neighbours. Deliberately applied on the way OUT of [processPageOcr] and
     * never before the per-page result is saved, so the page cache always
     * holds pristine per-page OCR and stays reusable.
     */
    private suspend fun applySeams(
        context: Context,
        sourceId: Long,
        page: Page,
        blocks: List<MangaTextBlock>,
        neighbors: SeamNeighbors?
    ): List<MangaTextBlock> {
        if (neighbors == null || blocks.isEmpty()) return blocks
        var out = blocks

        // Backward: this page's first block may be the tail of a line already
        // repaired and spoken as part of the previous page. Drop the duplicate.
        val prev = neighbors.prev
        if (prev != null) {
            val mergedFromPrev = seamText(context, sourceId, prev, page)
            if (mergedFromPrev != null) {
                // The previous page already spoke the repaired whole sentence,
                // so our fragment of it must go. Geometry alone is not enough:
                // a fragment's bounding box starts at its first inked pixel,
                // which is routinely well below the page edge, so the old
                // top-edge-only test silently kept the duplicate and the line
                // was read out twice. Confirm by text instead, which also
                // stops an unrelated first bubble from being dropped.
                val head = topEdgeBlock(out) ?: out.minByOrNull { it.top }
                if (head != null && tokenContainment(mergedFromPrev, head.text) >= 0.60f) {
                    out = out.filter { it !== head }
                }
            }
        }

        // Forward: this page's last block may be only the head of a line whose
        // remainder lives on the next page. Speak the repaired whole instead.
        val next = neighbors.next
        if (next != null && out.isNotEmpty()) {
            val tail = bottomEdgeBlock(out)
            if (tail != null) {
                val merged = seamText(context, sourceId, page, next)
                if (merged != null) {
                    out = out.map { if (it === tail) it.copy(text = merged) else it }
                }
            }
        }
        return out
    }

    /** Calculate adaptive timeout based on tile megapixels and retry rung. */
    private fun calculateAdaptiveTimeout(width: Int, height: Int, rung: Int): Long {
        val megapixels = (width.toLong() * height.toLong()) / 1_000_000f
        val baseMs = 10_000L
        val scaledMs = (baseMs + megapixels * 3_000L).toLong()
        val multiplier = when (rung) {
            1 -> 1.0f
            2 -> 1.3f
            3 -> 1.5f
            else -> 1.8f
        }
        return (scaledMs * multiplier).toLong().coerceIn(10_000L, 25_000L)
    }

    /** Preprocess tile for low-contrast or stylized manga lettering. */
    private fun enhanceTileForOcr(bitmap: Bitmap): Bitmap {
        return try {
            val out = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(out)
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)

            val cm = android.graphics.ColorMatrix()
            cm.setSaturation(0f)

            val contrast = 1.6f
            val translate = (-0.5f * contrast + 0.5f) * 255f
            val contrastMatrix = android.graphics.ColorMatrix(
                floatArrayOf(
                    contrast, 0f, 0f, 0f, translate,
                    0f, contrast, 0f, 0f, translate,
                    0f, 0f, contrast, 0f, translate,
                    0f, 0f, 0f, 1f, 0f
                )
            )
            cm.postConcat(contrastMatrix)

            paint.colorFilter = android.graphics.ColorMatrixColorFilter(cm)
            canvas.drawBitmap(bitmap, 0f, 0f, paint)
            out
        } catch (t: Throwable) {
            bitmap
        }
    }

    // -- Resolution: the single biggest accuracy lever ---------------------
    // The recognizer needs roughly 16px of glyph height to read a character
    // reliably. English manhwa and manhua arrive as webtoon strips that are
    // typically only 720-900px wide, so their lettering lands at 11-16px --
    // right on the failure threshold. Every scaling path here used to
    // DOWNSCALE only, throwing away the little detail there was. Enlarging a
    // small page before recognition costs nothing but memory and is what
    // actually fixes English accuracy, so narrow pages are now scaled UP to a
    // comfortable reading width before the recognizer ever sees them.

    /** Width, in px, that puts normal comic lettering safely above ~16px tall. */
    private const val OCR_COMFORT_WIDTH = 1800

    /** Hard ceiling so an upscale can never OOM on a huge webtoon strip. */
    private const val OCR_MAX_PIXELS = 26_000_000L

    /**
     * Enlargement applied before recognition. [detail] comes from
     * MangaReaderPrefs.getOcrDetail: 0 = Auto, 1 = Standard, 2 = High,
     * 3 = Maximum. Auto enlarges only what is genuinely too small, which is
     * the right default for English manhwa and is a no-op on large raws.
     */
    private fun ocrDetailFactor(detail: Int, width: Int, height: Int): Float {
        if (width <= 0 || height <= 0) return 1.0f
        val wanted = when (detail) {
            1 -> 1.0f
            2 -> 1.5f
            3 -> 2.0f
            else -> if (width >= OCR_COMFORT_WIDTH) {
                1.0f
            } else {
                (OCR_COMFORT_WIDTH.toFloat() / width.toFloat()).coerceAtMost(2.5f)
            }
        }
        if (wanted <= 1.0f) return 1.0f
        val budget = OCR_MAX_PIXELS.toFloat() / (width.toFloat() * height.toFloat())
        if (budget <= 1.0f) return 1.0f
        return minOf(wanted, kotlin.math.sqrt(budget))
    }

    /**
     * Aspect-ratio aware scaling for single standard pages (aspect ratio < 2.0).
     * Small pages are now enlarged; oversized ones are still capped.
     */
    private fun scaleBitmapIfNeeded(bitmap: Bitmap, detail: Int = 0): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return bitmap

        val up = ocrDetailFactor(detail, w, h)
        if (up > 1.0f) {
            val upW = (w * up).toInt().coerceAtLeast(1)
            val upH = (h * up).toInt().coerceAtLeast(1)
            return Bitmap.createScaledBitmap(bitmap, upW, upH, true)
        }

        val maxDim = maxOf(w, h)
        val targetMax = 3072
        if (maxDim <= targetMax) return bitmap
        val scale = targetMax.toFloat() / maxDim.toFloat()
        val newW = (w * scale).toInt().coerceAtLeast(1)
        val newH = (h * scale).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }

    /**
     * Controlled high-resolution fallback scaling for single standard pages:
     * Bounded to a maximum dimension of 2560px and 8 Megapixels total.
     */
    private fun scaleBitmapForFallback(bitmap: Bitmap): Bitmap {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return bitmap

        val maxDimensionBudget = 2560
        val maxPixelBudget = 8_000_000L

        // Second chance: when the first pass found nothing, a page that is
        // simply too small is by far the most likely reason, so escalate
        // straight to the Maximum enlargement instead of shrinking again.
        val up = ocrDetailFactor(3, w, h)
        if (up > 1.0f) {
            val upW = (w * up).toInt().coerceAtLeast(1)
            val upH = (h * up).toInt().coerceAtLeast(1)
            return Bitmap.createScaledBitmap(bitmap, upW, upH, true)
        }

        val maxDim = maxOf(w, h)
        val currentPixels = w.toLong() * h.toLong()

        if (maxDim <= maxDimensionBudget && currentPixels <= maxPixelBudget) {
            return bitmap
        }

        val dimScale = if (maxDim > maxDimensionBudget) maxDimensionBudget.toFloat() / maxDim.toFloat() else 1.0f
        val pixelScale = if (currentPixels > maxPixelBudget) Math.sqrt(maxPixelBudget.toDouble() / currentPixels.toDouble()).toFloat() else 1.0f
        val finalScale = minOf(dimScale, pixelScale)

        val newW = (w * finalScale).toInt().coerceAtLeast(1)
        val newH = (h * finalScale).toInt().coerceAtLeast(1)

        return if (newW == w && newH == h) bitmap else Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }

    fun warmRecognizer() {
        try {
            val rec = recognizer
            val dummy = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888)
            val image = InputImage.fromBitmap(dummy, 0)
            rec.process(image)
            Log.d(TAG, "[LorelightOCR] TextRecognizer pre-warmed successfully")
        } catch (t: Throwable) {
            Log.w(TAG, "[LorelightOCR] Recognizer warmup ignored: ${t.message}")
        }
    }

    private suspend fun loadBitmap(context: Context, sourceId: Long, page: Page): Bitmap? =
        withContext(Dispatchers.IO) {
            val pageCacheKey = mangaPageCacheKey(sourceId, page)
            val startTime = System.currentTimeMillis()
            val delays = listOf(0L, 400L, 1000L, 2500L)

            for (attempt in delays.indices) {
                if (attempt > 0) {
                    delay(delays[attempt])
                }
                try {
                    val loader = MangaImageLoaderProvider.getImageLoader(context)
                    val request = ImageRequest.Builder(context)
                        .data(MangaPageKey(sourceId, page))
                        .memoryCacheKey(pageCacheKey)
                        .diskCacheKey(pageCacheKey)
                        .memoryCachePolicy(CachePolicy.ENABLED)
                        .diskCachePolicy(CachePolicy.ENABLED)
                        // ML Kit cannot read HARDWARE bitmaps.
                        .allowHardware(false)
                        .build()
                    val result = loader.execute(request)
                    if (result is SuccessResult) {
                        val rawBitmap = when (val drawable = result.drawable) {
                            is BitmapDrawable -> drawable.bitmap
                            else -> {
                                try {
                                    drawable.toBitmap(config = Bitmap.Config.ARGB_8888)
                                } catch (e: Exception) {
                                    null
                                }
                            }
                        }
                        if (rawBitmap != null && !rawBitmap.isRecycled) {
                            if (rawBitmap.width < 32 || rawBitmap.height < 32) {
                                Log.w(TAG, "[LorelightOCR] Bitmap suspiciously small (${rawBitmap.width}x${rawBitmap.height}), rejecting as placeholder on attempt $attempt")
                                continue
                            }
                            val argbBitmap = if (rawBitmap.config != Bitmap.Config.ARGB_8888) {
                                rawBitmap.copy(Bitmap.Config.ARGB_8888, false) ?: rawBitmap
                            } else {
                                rawBitmap
                            }
                            val duration = System.currentTimeMillis() - startTime
                            Log.d(
                                TAG,
                                "[LorelightOCR] Loaded bitmap in ${duration}ms (orig: ${rawBitmap.width}x${rawBitmap.height}, config: ${rawBitmap.config} -> ${argbBitmap.config}) for sourceId=$sourceId page=${page.index}"
                            )
                            return@withContext argbBitmap
                        }
                    }
                } catch (t: Throwable) {
                    Log.w(TAG, "[LorelightOCR] Bitmap load attempt $attempt failed for sourceId=$sourceId page=${page.index}: ${t.message}")
                }
            }
            Log.w(TAG, "[LorelightOCR] Failed to load bitmap after 4 attempts for sourceId=$sourceId page=${page.index}")
            null
        }

    private suspend fun runRecognizer(bitmap: Bitmap, timeoutMs: Long = 10000L): com.google.mlkit.vision.text.Text {
        val deferred = CompletableDeferred<com.google.mlkit.vision.text.Text>()
        val image = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(image)
            .addOnSuccessListener { text -> deferred.complete(text) }
            .addOnFailureListener { ex -> deferred.completeExceptionally(ex) }

        return withTimeoutOrNull(timeoutMs) {
            deferred.await()
        } ?: throw java.util.concurrent.TimeoutException("ML Kit TextRecognizer timed out after ${timeoutMs}ms")
    }

    private suspend fun processTallImageTiled(
        context: Context,
        rawBitmap: Bitmap,
        config: TileConfig,
        rung: Int,
        applyContrastEnhance: Boolean = false
    ): TiledOcrOutcome {
        val totalW = rawBitmap.width
        val totalH = rawBitmap.height
        val allBlocks = mutableListOf<MangaTextBlock>()
        var hasTimeoutOrError = false
        var failureMsg: String? = null

        val step = maxOf(100, config.tileHeight - config.overlap)
        var y = 0
        val maxTileWidth = config.maxTileWidth.coerceAtLeast(2560)
        val detailPref = MangaReaderPrefs.getOcrDetail(context)
        val tileUpscale = ocrDetailFactor(detailPref, totalW, config.tileHeight)
        // An enlarged tile is a bigger tile, so the timeout has to grow with it.
        val adaptiveTimeout = calculateAdaptiveTimeout(
            (minOf(totalW, maxTileWidth) * tileUpscale).toInt().coerceAtLeast(1),
            (config.tileHeight * tileUpscale).toInt().coerceAtLeast(1),
            rung
        )

        while (y < totalH) {
            val tileTop = y
            val tileBottom = minOf(totalH, tileTop + config.tileHeight)
            val currentTileH = tileBottom - tileTop

            val tileBitmap = Bitmap.createBitmap(rawBitmap, 0, tileTop, totalW, currentTileH)
            val scale = if (totalW > maxTileWidth) {
                maxTileWidth.toFloat() / totalW.toFloat()
            } else {
                ocrDetailFactor(detailPref, totalW, currentTileH)
            }
            val scaledTile = if (scale != 1.0f) {
                val sw = (totalW * scale).toInt().coerceAtLeast(1)
                val sh = (currentTileH * scale).toInt().coerceAtLeast(1)
                Bitmap.createScaledBitmap(tileBitmap, sw, sh, true)
            } else {
                tileBitmap
            }

            val finalTileToProcess = if (applyContrastEnhance) {
                enhanceTileForOcr(scaledTile)
            } else {
                scaledTile
            }

            try {
                var textResult: com.google.mlkit.vision.text.Text? = null
                try {
                    textResult = runRecognizer(finalTileToProcess, timeoutMs = adaptiveTimeout)
                } catch (t: Throwable) {
                    Log.w(TAG, "[LorelightOCR] Tile at y=$y failed on initial attempt (${t.message}), retrying individually with extended timeout...")
                    val extendedTimeout = (adaptiveTimeout * 1.5f).toLong().coerceAtMost(30_000L)
                    try {
                        textResult = runRecognizer(finalTileToProcess, timeoutMs = extendedTimeout)
                        Log.d(TAG, "[LorelightOCR] Tile at y=$y succeeded on extended timeout retry")
                    } catch (t2: Throwable) {
                        hasTimeoutOrError = true
                        failureMsg = t2.message ?: "Tile timeout at y=$y"
                        Log.e(TAG, "[LorelightOCR] Tile at y=$y permanently failed: ${t2.message}")
                    }
                }

                if (textResult != null) {
                    val scaleX = finalTileToProcess.width.toFloat() / totalW.toFloat()
                    val scaleY = finalTileToProcess.height.toFloat() / currentTileH.toFloat()

                    for (block in textResult.textBlocks) {
                        val box = block.boundingBox ?: continue
                        val joined = joinLines(block.lines.map { it.text })
                        if (joined.isBlank()) continue

                        val left = (box.left / scaleX).toInt().coerceIn(0, totalW)
                        val right = (box.right / scaleX).toInt().coerceIn(0, totalW)
                        val top = (tileTop + (box.top / scaleY)).toInt().coerceIn(0, totalH)
                        val bottom = (tileTop + (box.bottom / scaleY)).toInt().coerceIn(0, totalH)

                        val newBlock = MangaTextBlock(
                            text = joined,
                            left = left,
                            top = top,
                            right = right,
                            bottom = bottom,
                            pageWidth = totalW,
                            pageHeight = totalH
                        )

                        var isDup = false
                        for (i in allBlocks.indices) {
                            val existing = allBlocks[i]
                            if (isDuplicateBlock(existing, newBlock)) {
                                isDup = true
                                if ((newBlock.blockWidth * newBlock.blockHeight) > (existing.blockWidth * existing.blockHeight)) {
                                    allBlocks[i] = newBlock
                                }
                                break
                            }
                        }
                        if (!isDup) {
                            allBlocks.add(newBlock)
                        }
                    }
                }
            } finally {
                if (finalTileToProcess !== scaledTile && !finalTileToProcess.isRecycled) {
                    finalTileToProcess.recycle()
                }
                if (scaledTile !== tileBitmap && !scaledTile.isRecycled) {
                    scaledTile.recycle()
                }
                if (tileBitmap !== rawBitmap && !tileBitmap.isRecycled) {
                    tileBitmap.recycle()
                }
            }

            if (tileBottom >= totalH) break
            y += step
        }

        return TiledOcrOutcome(
            blocks = allBlocks,
            hasTimeoutOrError = hasTimeoutOrError,
            failureMessage = failureMsg
        )
    }

    private fun isDuplicateBlock(a: MangaTextBlock, b: MangaTextBlock): Boolean {
        val interTop = maxOf(a.top, b.top)
        val interBottom = minOf(a.bottom, b.bottom)
        if (interTop >= interBottom) return false

        val interLeft = maxOf(a.left, b.left)
        val interRight = minOf(a.right, b.right)
        val interW = maxOf(0, interRight - interLeft)
        val interH = maxOf(0, interBottom - interTop)
        val interArea = interW.toLong() * interH.toLong()

        val areaA = maxOf(1, a.blockWidth * a.blockHeight).toLong()
        val areaB = maxOf(1, b.blockWidth * b.blockHeight).toLong()
        val minArea = minOf(areaA, areaB)
        val overlapRatio = if (minArea <= 0L) 0f else interArea.toFloat() / minArea.toFloat()

        val normA = normalizeForDedup(a.text)
        val normB = normalizeForDedup(b.text)
        if (normA.isEmpty() || normB.isEmpty()) return overlapRatio >= 0.75f

        // Exact or containment match: the original test, kept as the cheap fast path.
        if (normA == normB || normA.contains(normB) || normB.contains(normA)) {
            if (overlapRatio >= 0.20f) return true
        }

        // Fuzzy match. Overlapping tiles read the SAME bubble twice and often
        // disagree on a letter or two, so a single wrong character must not
        // defeat de-duplication and leave the line to be spoken twice.
        val lo = minOf(normA.length, normB.length)
        val hi = maxOf(normA.length, normB.length)
        if (hi > 0 && lo.toFloat() / hi.toFloat() >= 0.70f) {
            if (similarity(normA, normB) >= 0.82f && overlapRatio >= 0.15f) return true
        }

        // One reading is a clipped fragment of the other: nearly all of the
        // shorter block's words reappear in the longer one.
        val shortT = if (normA.length <= normB.length) normA else normB
        val longT = if (normA.length <= normB.length) normB else normA
        if (shortT.length >= 6 && overlapRatio >= 0.30f &&
            tokenContainment(longT, shortT) >= 0.80f
        ) {
            return true
        }

        // Same rectangle, unrelated text: still one bubble, keep the bigger.
        return overlapRatio >= 0.75f
    }

    private fun normalizeForDedup(s: String): String =
        s.lowercase().filter { it.isLetterOrDigit() }

    /** Lower-cased alphanumeric words of [s], 2 chars or longer. */
    private fun wordsOf(s: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        for (ch in s) {
            if (ch.isLetterOrDigit()) {
                sb.append(ch.lowercaseChar())
            } else if (sb.isNotEmpty()) {
                if (sb.length >= 2) out.add(sb.toString())
                sb.setLength(0)
            }
        }
        if (sb.length >= 2) out.add(sb.toString())
        return out
    }

    /** Levenshtein edit distance. Bounded by the caller to keep this cheap. */
    private fun editDistance(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            val ca = a[i - 1]
            for (j in 1..b.length) {
                val cost = if (ca == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val swap = prev
            prev = cur
            cur = swap
        }
        return prev[b.length]
    }

    /** 1f = identical, 0f = nothing shared. Expects normalized text. */
    private fun similarity(a: String, b: String): Float {
        if (a == b) return 1f
        val longer = maxOf(a.length, b.length)
        if (longer == 0) return 1f
        // Guard against quadratic cost on pathologically long merged strips.
        if (longer > 400) return 0f
        return 1f - (editDistance(a, b).toFloat() / longer.toFloat())
    }

    /**
     * Fraction of [needle]'s words that also appear in [haystack], tolerating
     * one-character OCR slips so "you" still matches a misread "vou".
     */
    private fun tokenContainment(haystack: String, needle: String): Float {
        val hw = wordsOf(haystack)
        val nw = wordsOf(needle)
        if (nw.isEmpty() || hw.isEmpty()) return 0f
        var hits = 0
        for (w in nw) {
            val found = hw.any { h ->
                h == w || (kotlin.math.abs(h.length - w.length) <= 1 && similarity(h, w) >= 0.75f)
            }
            if (found) hits++
        }
        return hits.toFloat() / nw.size.toFloat()
    }

    /**
     * Quality of an OCR pass. Raw block count is a bad score because duplicated
     * bubbles inflate it, letting a messy pass beat a clean one. Count distinct
     * spoken characters instead, ignoring near-duplicates.
     */
    private fun outcomeScore(outcome: TiledOcrOutcome): Int {
        if (outcome.blocks.isEmpty()) return 0
        var score = 0
        val seen = ArrayList<String>()
        for (b in outcome.blocks) {
            val norm = normalizeForDedup(b.text)
            if (norm.isEmpty()) continue
            val dup = seen.any { s ->
                val lo = minOf(s.length, norm.length)
                val hi = maxOf(s.length, norm.length)
                hi > 0 && lo.toFloat() / hi.toFloat() >= 0.75f && similarity(s, norm) >= 0.82f
            }
            if (dup) continue
            seen.add(norm)
            score += norm.length
        }
        return score
    }

    private fun shouldRetryTallImage(height: Int, blocks: List<MangaTextBlock>): Boolean {
        if (blocks.isEmpty()) return true
        if (height < 3000) return false

        val bandCount = ((height + 1999) / 2000).coerceAtLeast(2)
        val occupiedBands = blocks.map { (it.centerY / 2000).coerceIn(0, bandCount - 1) }.toSet().size
        val coverageRatio = occupiedBands.toFloat() / bandCount.toFloat()

        if (height >= 5000 && (coverageRatio < 0.25f || blocks.size <= 2)) {
            return true
        }
        return false
    }

    /**
     * Four-stage bounded OCR retry ladder:
     * Rung 1: Standard Tiled Pass (Native Width up to 2560px, ~2048px tiles with ~384px overlap).
     * Rung 2: Fine Tiled Pass (~1280px tiles with 320px overlap = 25% overlap).
     * Rung 3: Preprocessed Contrast / Grayscale Pass for faint/stylized lettering.
     * Rung 4: Banded Fallback Pass.
     */
    private suspend fun processOcrWithRetry(
        context: Context,
        rawBitmap: Bitmap
    ): OcrRetryResult {
        val w = rawBitmap.width
        val h = rawBitmap.height
        val aspectRatio = h.toFloat() / w.toFloat()

        if (aspectRatio >= 2.0f || h >= 2500) {
            val startTime = System.currentTimeMillis()

            // Rung 1: Standard Tiled Pass
            val config1 = TileConfig(tileHeight = 2048, overlap = 384, maxTileWidth = 2560)
            val outcome1 = processTallImageTiled(context, rawBitmap, config1, rung = 1)
            val duration1 = System.currentTimeMillis() - startTime
            com.lorelight.core.DevLogStore.append(
                context,
                "MangaOCR",
                "Rung 1 (Native Tiled) completed in ${duration1}ms with ${outcome1.blocks.size} blocks for ${w}x${h} image (hasErrors=${outcome1.hasTimeoutOrError})"
            )

            val needsRetry1 = outcome1.hasTimeoutOrError || shouldRetryTallImage(h, outcome1.blocks)
            if (!needsRetry1 && outcome1.blocks.isNotEmpty()) {
                return OcrRetryResult(outcome1.blocks, hasErrors = false)
            }

            // Rung 2: Fine Tiled Pass
            com.lorelight.core.DevLogStore.append(context, "MangaOCR", "Escalating to Rung 2 (Fine Tiled pass)...")
            val startTime2 = System.currentTimeMillis()
            val config2 = TileConfig(tileHeight = 1280, overlap = 320, maxTileWidth = 2560)
            val outcome2 = processTallImageTiled(context, rawBitmap, config2, rung = 2)
            val duration2 = System.currentTimeMillis() - startTime2
            com.lorelight.core.DevLogStore.append(
                context,
                "MangaOCR",
                "Rung 2 (Fine Tiled) completed in ${duration2}ms with ${outcome2.blocks.size} blocks"
            )

            val bestOutcome2 = if (outcomeScore(outcome2) >= outcomeScore(outcome1)) outcome2 else outcome1
            val needsRetry2 = bestOutcome2.hasTimeoutOrError || shouldRetryTallImage(h, bestOutcome2.blocks)
            if (!needsRetry2 && bestOutcome2.blocks.isNotEmpty()) {
                return OcrRetryResult(bestOutcome2.blocks, hasErrors = false)
            }

            // Rung 3: Preprocessed Contrast / Grayscale Pass
            com.lorelight.core.DevLogStore.append(context, "MangaOCR", "Escalating to Rung 3 (Contrast Enhanced pass)...")
            val startTime3 = System.currentTimeMillis()
            val config3 = TileConfig(tileHeight = 1600, overlap = 320, maxTileWidth = 2560)
            val outcome3 = processTallImageTiled(context, rawBitmap, config3, rung = 3, applyContrastEnhance = true)
            val duration3 = System.currentTimeMillis() - startTime3
            com.lorelight.core.DevLogStore.append(
                context,
                "MangaOCR",
                "Rung 3 (Contrast Enhanced) completed in ${duration3}ms with ${outcome3.blocks.size} blocks"
            )

            var bestOutcome = bestOutcome2
            if (outcomeScore(outcome3) > outcomeScore(bestOutcome)) {
                bestOutcome = outcome3
            }

            if (bestOutcome.blocks.isNotEmpty() && !bestOutcome.hasTimeoutOrError) {
                return OcrRetryResult(bestOutcome.blocks, hasErrors = false)
            }

            // Rung 4: Banded Fallback Pass
            com.lorelight.core.DevLogStore.append(context, "MangaOCR", "Escalating to Rung 4 (Banded Fallback pass)...")
            val config4 = TileConfig(tileHeight = 1800, overlap = 300, maxTileWidth = 2560)
            val outcome4 = processTallImageTiled(context, rawBitmap, config4, rung = 4)
            com.lorelight.core.DevLogStore.append(
                context,
                "MangaOCR",
                "Rung 4 (Banded Fallback) completed with ${outcome4.blocks.size} blocks"
            )

            if (outcomeScore(outcome4) > outcomeScore(bestOutcome)) {
                bestOutcome = outcome4
            }

            if (bestOutcome.blocks.isEmpty() && (outcome1.hasTimeoutOrError || outcome2.hasTimeoutOrError || outcome3.hasTimeoutOrError || outcome4.hasTimeoutOrError)) {
                throw java.util.concurrent.TimeoutException(bestOutcome.failureMessage ?: "OCR timed out across all processing passes")
            }

            return OcrRetryResult(bestOutcome.blocks, hasErrors = bestOutcome.hasTimeoutOrError)
        } else {
            // Standard single-page OCR
            val scaledBitmap = scaleBitmapIfNeeded(rawBitmap, MangaReaderPrefs.getOcrDetail(context))
            val adaptiveTimeout = calculateAdaptiveTimeout(scaledBitmap.width, scaledBitmap.height, rung = 1)
            var hasErrors = false

            val result1 = try {
                val text = runRecognizer(scaledBitmap, timeoutMs = adaptiveTimeout)
                val scaleX = scaledBitmap.width.toFloat() / w.toFloat()
                val scaleY = scaledBitmap.height.toFloat() / h.toFloat()
                text.textBlocks.mapNotNull { block ->
                    val box = block.boundingBox ?: return@mapNotNull null
                    val joined = joinLines(block.lines.map { it.text })
                    if (joined.isBlank()) return@mapNotNull null
                    MangaTextBlock(
                        text = joined,
                        left = (box.left / scaleX).toInt().coerceIn(0, w),
                        top = (box.top / scaleY).toInt().coerceIn(0, h),
                        right = (box.right / scaleX).toInt().coerceIn(0, w),
                        bottom = (box.bottom / scaleY).toInt().coerceIn(0, h),
                        pageWidth = w,
                        pageHeight = h
                    )
                }
            } catch (t: Throwable) {
                hasErrors = true
                Log.w(TAG, "[LorelightOCR] Standard attempt 1 failed: ${t.message}")
                emptyList()
            } finally {
                if (scaledBitmap !== rawBitmap && !scaledBitmap.isRecycled) {
                    scaledBitmap.recycle()
                }
            }

            if (result1.isNotEmpty()) {
                return OcrRetryResult(result1, hasErrors = false)
            }

            val fallbackBitmap = scaleBitmapForFallback(rawBitmap)
            val fallbackTimeout = calculateAdaptiveTimeout(fallbackBitmap.width, fallbackBitmap.height, rung = 2)
            val result2 = try {
                val text = runRecognizer(fallbackBitmap, timeoutMs = fallbackTimeout)
                val scaleX = fallbackBitmap.width.toFloat() / w.toFloat()
                val scaleY = fallbackBitmap.height.toFloat() / h.toFloat()
                text.textBlocks.mapNotNull { block ->
                    val box = block.boundingBox ?: return@mapNotNull null
                    val joined = joinLines(block.lines.map { it.text })
                    if (joined.isBlank()) return@mapNotNull null
                    MangaTextBlock(
                        text = joined,
                        left = (box.left / scaleX).toInt().coerceIn(0, w),
                        top = (box.top / scaleY).toInt().coerceIn(0, h),
                        right = (box.right / scaleX).toInt().coerceIn(0, w),
                        bottom = (box.bottom / scaleY).toInt().coerceIn(0, h),
                        pageWidth = w,
                        pageHeight = h
                    )
                }
            } catch (t: Throwable) {
                hasErrors = true
                Log.w(TAG, "[LorelightOCR] Standard attempt 2 failed: ${t.message}")
                emptyList()
            } finally {
                if (fallbackBitmap !== rawBitmap && !fallbackBitmap.isRecycled) {
                    fallbackBitmap.recycle()
                }
            }

            if (result2.isEmpty() && hasErrors) {
                throw java.util.concurrent.TimeoutException("OCR timed out or failed on page image")
            }

            return OcrRetryResult(if (result2.isNotEmpty()) result2 else result1, hasErrors = hasErrors)
        }
    }

    /**
     * Primary OCR entry point returning a structured [MangaPageOcrResult].
     */
    suspend fun processPageOcr(
        context: Context,
        sourceId: Long,
        page: Page,
        rightToLeft: Boolean,
        neighbors: SeamNeighbors? = null
    ): MangaPageOcrResult = withContext(Dispatchers.IO) {
        val overallStartTime = System.currentTimeMillis()
        val ocrPageKey = pageKeyOf(page)

        // 1. Check persistent disk OCR cache
        com.lorelight.manga.download.MangaOcrCache.load(context, sourceId, ocrPageKey)?.let { cached ->
            val stitched = applySeams(context, sourceId, page, cached, neighbors)
            val duration = System.currentTimeMillis() - overallStartTime
            Log.d(TAG, "[LorelightOCR] Disk cache HIT for page=$ocrPageKey (blocks: ${stitched.size}) in ${duration}ms")
            return@withContext MangaPageOcrResult.Success(
                blocks = stitched,
                durationMs = duration,
                fromCache = true
            )
        }

        // 2. Load and decode bitmap
        val rawBitmap = loadBitmap(context, sourceId, page)
        if (rawBitmap == null || rawBitmap.isRecycled) {
            val duration = System.currentTimeMillis() - overallStartTime
            Log.w(TAG, "[LorelightOCR] ImageLoadError for page=$ocrPageKey in ${duration}ms")
            com.lorelight.core.DevLogStore.append(context, "MangaOCR", "ImageLoadError for page=$ocrPageKey: Could not load bitmap")
            return@withContext MangaPageOcrResult.ImageLoadError(
                message = "Could not load or decode page image",
                durationMs = duration
            )
        }

        // 3. Run OCR with 4-rung retry ladder and tiling
        val retryResult = try {
            processOcrWithRetry(context, rawBitmap)
        } catch (t: Throwable) {
            val duration = System.currentTimeMillis() - overallStartTime
            Log.e(TAG, "[LorelightOCR] RecognizerError for page=$ocrPageKey: ${t.message}", t)
            com.lorelight.core.DevLogStore.append(context, "MangaOCR", "RecognizerError for page=$ocrPageKey: ${t.message}")
            return@withContext MangaPageOcrResult.RecognizerError(
                message = t.message ?: "OCR Recognition error",
                cause = t,
                durationMs = duration
            )
        }

        val filtered = filterBlocks(retryResult.blocks)
        val ordered = orderBlocks(filtered, rightToLeft)
        val totalDuration = System.currentTimeMillis() - overallStartTime
        val totalChars = ordered.sumOf { it.text.length }
        Log.d(
            TAG,
            "[LorelightOCR] OCR pass finished for page=$ocrPageKey in ${totalDuration}ms: ${ordered.size} blocks, $totalChars chars (hasErrors=${retryResult.hasErrors})"
        )

        // Populate persistent disk cache ONLY if blocks were found AND pass had no errors/timeouts
        if (ordered.isNotEmpty() && !retryResult.hasErrors) {
            com.lorelight.manga.download.MangaOcrCache.save(context, sourceId, ocrPageKey, ordered)
        } else if (retryResult.hasErrors && ordered.isEmpty()) {
            com.lorelight.core.DevLogStore.append(context, "MangaOCR", "OCR pass for page=$ocrPageKey encountered errors/timeouts and found 0 blocks. Not caching.")
            return@withContext MangaPageOcrResult.RecognizerError(
                message = "OCR timed out during page scan",
                durationMs = totalDuration
            )
        }

        return@withContext MangaPageOcrResult.Success(
            blocks = applySeams(context, sourceId, page, ordered, neighbors),
            durationMs = totalDuration,
            fromCache = false
        )
    }

    /** OCR one page and return speakable bubbles already in reading order (legacy helper). */
    suspend fun extractBlocks(
        context: Context,
        sourceId: Long,
        page: Page,
        rightToLeft: Boolean
    ): List<MangaTextBlock>? {
        return when (val res = processPageOcr(context, sourceId, page, rightToLeft)) {
            is MangaPageOcrResult.Success -> res.blocks
            else -> null
        }
    }

    /**
     * Bubbles arrive as separate lines. Join them, stitching hyphenated words
     * back together ("dis-" + "covered" -> "discovered").
     */
    private fun joinLines(lines: List<String>): String {
        val sb = StringBuilder()
        var lastNorm = ""
        for (line in lines) {
            val t = line.trim()
            if (t.isEmpty()) continue
            // ML Kit occasionally emits the same physical line twice. Only
            // collapse substantial lines, so deliberate beats like "No!" /
            // "No!" on separate lines survive untouched.
            val norm = normalizeForDedup(t)
            if (norm.length >= 6 && norm == lastNorm) continue
            lastNorm = norm
            if (sb.isEmpty()) {
                sb.append(t)
                continue
            }
            if (sb.last() == '-') {
                sb.deleteCharAt(sb.length - 1)
                sb.append(t)
            } else {
                sb.append(' ').append(t)
            }
        }
        return sb.toString().trim()
    }

    /** Drop sound effects, scanlation credits and page furniture. */
    private fun filterBlocks(blocks: List<MangaTextBlock>): List<MangaTextBlock> {
        if (blocks.isEmpty()) return blocks
        val pageH = blocks.firstOrNull()?.pageHeight ?: 1

        if (pageH <= 3000) {
            val heights = blocks.map { it.blockHeight }.sorted()
            val median = heights[heights.size / 2].coerceAtLeast(1)

            return blocks.filter { b ->
                val letters = b.text.count { it.isLetter() }
                when {
                    letters < 2 -> false
                    creditRegex.containsMatchIn(b.text) -> false
                    // Huge stylised lettering with little text == SFX ("KRAKOOM").
                    b.blockHeight > median * 3 && b.text.length <= 18 -> false
                    // Short text pinned to the very top/bottom edge == credits, page numbers.
                    (b.top < b.pageHeight * 0.02f || b.bottom > b.pageHeight * 0.98f) && letters <= 12 -> false
                    else -> true
                }
            }
        } else {
            // Merged strip: partition blocks into vertical panel bands of ~2000px so local font sizes dictate the median
            val bandHeight = 2000
            val numBands = ((pageH + bandHeight - 1) / bandHeight).coerceAtLeast(1)
            val bandBlocks = Array(numBands) { mutableListOf<MangaTextBlock>() }
            for (b in blocks) {
                val bandIdx = (b.centerY / bandHeight).coerceIn(0, numBands - 1)
                bandBlocks[bandIdx].add(b)
            }

            val filtered = mutableListOf<MangaTextBlock>()
            for (bandList in bandBlocks) {
                if (bandList.isEmpty()) continue
                val heights = bandList.map { it.blockHeight }.sorted()
                val localMedian = heights[heights.size / 2].coerceAtLeast(1)
                for (b in bandList) {
                    val letters = b.text.count { it.isLetter() }
                    val keep = when {
                        letters < 2 -> false
                        creditRegex.containsMatchIn(b.text) -> false
                        // Local SFX heuristic within this panel band
                        b.blockHeight > localMedian * 3 && b.text.length <= 18 -> false
                        // Short text pinned to the very top/bottom edge of the whole strip == credits, page numbers.
                        (b.top < b.pageHeight * 0.01f || b.bottom > b.pageHeight * 0.99f) && letters <= 12 -> false
                        else -> true
                    }
                    if (keep) {
                        filtered.add(b)
                    }
                }
            }
            return filtered
        }
    }

    /**
     * Order bubbles into natural manga/comic reading order using a recursive
     * XY-cut. Comics read row by row, so we first look for a horizontal gutter
     * (a full-width empty band) and read the upper half before the lower half.
     * Only when there is no horizontal gutter do we split on a vertical gutter
     * into columns, reading the leading column first -- the right-hand column
     * for right-to-left titles.
     */
    private fun orderBlocks(
        blocks: List<MangaTextBlock>,
        rightToLeft: Boolean
    ): List<MangaTextBlock> {
        if (blocks.size <= 1) return blocks
        val pageH = blocks.firstOrNull()?.pageHeight ?: 1

        if (pageH > 3000) {
            // For tall webtoon strips, cluster into vertical bands / panel rows first
            // to strictly maintain top-to-bottom reading order across panels
            val sortedByTop = blocks.sortedBy { it.top }
            val clusters = mutableListOf<MutableList<MangaTextBlock>>()
            var currentCluster = mutableListOf<MangaTextBlock>()

            for (b in sortedByTop) {
                if (currentCluster.isEmpty()) {
                    currentCluster.add(b)
                } else {
                    val maxBottomInCluster = currentCluster.maxOf { it.bottom }
                    val heights = currentCluster.map { it.blockHeight }
                    val clusterMedH = heights[heights.size / 2].coerceAtLeast(20)
                    val breakThreshold = maxOf(40, clusterMedH)
                    if (b.top >= maxBottomInCluster + breakThreshold) {
                        clusters.add(currentCluster)
                        currentCluster = mutableListOf(b)
                    } else {
                        currentCluster.add(b)
                    }
                }
            }
            if (currentCluster.isNotEmpty()) {
                clusters.add(currentCluster)
            }

            return clusters.flatMap { cluster ->
                val heights = cluster.map { it.blockHeight }.sorted()
                val medianH = heights[heights.size / 2].coerceAtLeast(1)
                val minGap = maxOf(3, medianH / 5)
                xyCut(cluster, rightToLeft, minGap, 0)
            }
        } else {
            val heights = blocks.map { it.blockHeight }.sorted()
            val medianH = heights[heights.size / 2].coerceAtLeast(1)
            val minGap = maxOf(3, medianH / 5)
            return xyCut(blocks, rightToLeft, minGap, 0)
        }
    }

    private fun xyCut(
        blocks: List<MangaTextBlock>,
        rightToLeft: Boolean,
        minGap: Int,
        depth: Int
    ): List<MangaTextBlock> {
        if (blocks.size <= 1 || depth >= 25) return baseReadingSort(blocks, rightToLeft)

        // Prefer a horizontal gutter (row boundary): read top rows first.
        val hGap = widestGutter(blocks.map { it.top to it.bottom })
        if (hGap != null && hGap.second >= minGap) {
            val mid = hGap.first
            val upper = blocks.filter { it.centerY < mid }
            val lower = blocks.filter { it.centerY >= mid }
            if (upper.isNotEmpty() && lower.isNotEmpty()) {
                return xyCut(upper, rightToLeft, minGap, depth + 1) +
                    xyCut(lower, rightToLeft, minGap, depth + 1)
            }
        }

        // Otherwise a vertical gutter (column boundary): read the leading
        // column first (right column for right-to-left titles).
        val vGap = widestGutter(blocks.map { it.left to it.right })
        if (vGap != null && vGap.second >= minGap) {
            val mid = vGap.first
            val leftGroup = blocks.filter { it.centerX < mid }
            val rightGroup = blocks.filter { it.centerX >= mid }
            if (leftGroup.isNotEmpty() && rightGroup.isNotEmpty()) {
                val first = if (rightToLeft) rightGroup else leftGroup
                val second = if (rightToLeft) leftGroup else rightGroup
                return xyCut(first, rightToLeft, minGap, depth + 1) +
                    xyCut(second, rightToLeft, minGap, depth + 1)
            }
        }

        // No clean gutter: fall back to top-to-bottom, then reading direction.
        return baseReadingSort(blocks, rightToLeft)
    }

    private fun baseReadingSort(
        blocks: List<MangaTextBlock>,
        rightToLeft: Boolean
    ): List<MangaTextBlock> =
        blocks.sortedWith(
            compareBy({ it.top }, { if (rightToLeft) -it.centerX else it.centerX })
        )

    /**
     * Widest empty band across a set of 1-D [start, end] intervals. Returns the
     * band's midpoint and width, or null when the intervals leave no gap.
     */
    private fun widestGutter(intervals: List<Pair<Int, Int>>): Pair<Int, Int>? {
        if (intervals.size < 2) return null
        val sorted = intervals.sortedBy { it.first }
        var runningEnd = sorted.first().second
        var bestMid = 0
        var bestWidth = 0
        for (i in 1 until sorted.size) {
            val start = sorted[i].first
            val end = sorted[i].second
            val gap = start - runningEnd
            if (gap > bestWidth) {
                bestWidth = gap
                bestMid = runningEnd + gap / 2
            }
            if (end > runningEnd) runningEnd = end
        }
        return if (bestWidth > 0) bestMid to bestWidth else null
    }

    /**
     * Comic lettering is almost always ALL CAPS, and TTS engines spell short
     * all-caps tokens out letter by letter. Normalise to sentence case.
     */
    fun speakableText(raw: String, isContinuation: Boolean = false): String {
        var s = raw.replace(Regex("\\s+"), " ").trim()
        if (s.isEmpty()) return ""

        // Same normalisation the novel reader applies in
        // TtsPlaybackManager.cleanSentenceForTts, so both voices treat
        // punctuation, pauses and junk symbols identically.
        s = s.replace("\u2026", "...")
        s = s.replace(Regex("\\.{3,}"), "...")
        s = s.replace(Regex("\\.\\."), "...")
        s = s.replace(Regex("[-\u2013\u2014]{2,}"), ", ")
        s = s.replace(Regex("_{2,}"), " ")
        s = s.replace(Regex("\\*{2,}"), " ")
        s = s.replace(Regex("={2,}"), " ")
        // Strip symbols TTS spells out oddly, but KEEP . , ; : ? ! ' " and -
        s = s.replace(Regex("[~`^|<>{}\\[\\]]+"), " ")
        s = s.replace(Regex("\\\\+"), " ")
        s = s.replace(Regex("(?<!\\w)/(?!\\w)"), " ")
        s = s.replace(Regex("[ \\t]{2,}"), " ")
        s = s.trim()

        // Nothing readable left. Return empty so the caller skips this block
        // rather than speaking punctuation.
        if (s.none { it.isLetterOrDigit() }) return ""

        val letters = s.filter { it.isLetter() }
        if (letters.length >= 3) {
            val upper = letters.count { it.isUpperCase() }
            if (upper.toFloat() / letters.length.toFloat() > 0.7f) {
                return toSentenceCase(s.lowercase(Locale.getDefault()), isContinuation)
            }
        }
        return s
    }

    private fun toSentenceCase(text: String, isContinuation: Boolean = false): String {
        val sb = StringBuilder(text)
        var capitalize = !isContinuation
        for (i in sb.indices) {
            val c = sb[i]
            if (capitalize && c.isLetter()) {
                sb[i] = c.uppercaseChar()
                capitalize = false
            } else if (c == '.' || c == '!' || c == '?') {
                capitalize = true
            }
        }
        return sb.toString().replace(Regex("\\bi\\b"), "I")
    }

    /**
     * Determines whether raw or normalized text ends a sentence.
     * Sentence ends are marked by '.', '!', '?', or ellipsis ('…', '...').
     * Text ending with no punctuation, commas, hyphens/dashes, etc. returns false (continuation).
     */
    fun endsSentence(rawText: String): Boolean {
        val t = rawText.trim()
        if (t.isEmpty()) return false

        var idx = t.length - 1
        while (idx >= 0) {
            val c = t[idx]
            if (c == '"' || c == '\'' || c == '”' || c == '’' || c == ')' || c == ']' || c == '}') {
                idx--
            } else {
                break
            }
        }
        if (idx < 0) return false

        val lastChar = t[idx]
        return lastChar == '.' || lastChar == '!' || lastChar == '?' || lastChar == '…'
    }

    /**
     * Merges multiple MangaTextBlocks into a single spoken string.
     * Joins with single space, or concatenates with no space if earlier block ends with a hyphen/dash.
     * Preserves trailing punctuation (such as commas) and case.
     */
    fun joinGroupTexts(blocks: List<MangaTextBlock>): String {
        if (blocks.isEmpty()) return ""
        if (blocks.size == 1) return speakableText(blocks[0].text, isContinuation = false)

        val sb = StringBuilder()
        for ((index, b) in blocks.withIndex()) {
            val isContinuation = index > 0
            val text = speakableText(b.text, isContinuation = isContinuation)
            if (text.isBlank()) continue

            if (sb.isEmpty()) {
                sb.append(text)
            } else {
                if (sb.endsWith("-") || sb.endsWith("–") || sb.endsWith("—")) {
                    sb.deleteCharAt(sb.length - 1)
                    sb.append(text)
                } else {
                    sb.append(' ').append(text)
                }
            }
        }
        return sb.toString().trim()
    }
}

enum class MangaTtsStatusCategory {
    NONE,
    WORKING,
    ERROR,
    INFORMATIONAL
}

/**
 * Holds one screen-based reading session. Created with remember() inside the
 * manga reader; the reader drives the actual scrolling because that is where
 * the LazyListState lives.
 */
class MangaTtsController {

    var sessionOn by mutableStateOf(false)
        private set
    var isPaused by mutableStateOf(false)
        private set
    var isSpeaking by mutableStateOf(false)
        private set

    var blocks by mutableStateOf<List<MangaTextBlock>>(emptyList())
    var blockIndex by mutableIntStateOf(0)
    var loadedPageKey by mutableStateOf<String?>(null)
    var statusText by mutableStateOf<String?>(null)
    var statusCategory by mutableStateOf(MangaTtsStatusCategory.NONE)

    fun updateStatus(text: String?, category: MangaTtsStatusCategory = MangaTtsStatusCategory.NONE) {
        statusText = text
        statusCategory = if (text == null) MangaTtsStatusCategory.NONE else category
    }

    fun clearStatus() {
        updateStatus(null, MangaTtsStatusCategory.NONE)
    }

    /** Consumed by the reader loop: -1 previous bubble, +1 next bubble. */
    var pendingSkip by mutableIntStateOf(0)

    /** Consumed by the reader loop: -1 previous page, +1 next page. */
    var pendingPageDelta by mutableIntStateOf(0)

    /**
     * Paged modes only. The pager state lives in a narrower composable scope,
     * so the session posts a target page here and the pager consumes it.
     */
    var pageFlipTarget by mutableStateOf<Int?>(null)

    /** True while read-aloud is driving the scroll itself. */
    var autoScrolling by mutableStateOf(false)

    /** Page read-aloud is working on, independent of what the user scrolls to. */
    var ttsPageKey: String? = null

    /**
     * Set when the reader should land on the LAST bubble after the next OCR
     * pass -- i.e. the user pressed "previous line" on the first bubble of a
     * page and the session stepped back one page.
     */
    var startAtLastBlock: Boolean = false

    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: CompletableDeferred<Boolean>? = null
    private val coroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var watchdogJob: Job? = null
    private var lastContext: Context? = null

    // Remembered when the engine is built so applyVoiceSettings can read the
    // manga-only voice prefs, including when speak() re-applies them mid-session.
    private var appContext: Context? = null
    private var isDucked = false

    // --- OCR result cache -------------------------------------------------
    // Re-running ML Kit every time the user steps back a page (or the loop
    // revisits one) is slow and wasteful; results for a static page never
    // change. Thread-safe LRU keyed by feed-item key.
    private val ocrCache = object : LinkedHashMap<String, List<MangaTextBlock>>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, List<MangaTextBlock>>?): Boolean {
            return size > 32
        }
    }

    @Synchronized
    fun cachedBlocks(key: String): List<MangaTextBlock>? = ocrCache[key]

    @Synchronized
    fun cacheBlocks(key: String, value: List<MangaTextBlock>) {
        ocrCache[key] = value
    }

    @Synchronized
    fun uncacheBlocks(key: String) {
        ocrCache.remove(key)
    }

    suspend fun rescanPage(
        context: Context,
        sourceId: Long,
        page: Page,
        key: String,
        rightToLeft: Boolean
    ): MangaPageOcrResult = withContext(Dispatchers.IO) {
        uncacheBlocks(key)
        val ocrPageKey = page.imageUrl?.takeIf { it.isNotBlank() }
            ?: page.url.takeIf { it.isNotBlank() }?.let { "$it#${page.index}" }
            ?: "page_${page.index}"
        com.lorelight.manga.download.MangaOcrCache.delete(context, sourceId, ocrPageKey)

        withContext(Dispatchers.Main) {
            updateStatus("Rescanning page...", MangaTtsStatusCategory.WORKING)
        }
        com.lorelight.core.DevLogStore.append(context, "MangaOCR", "Manual re-scan requested for page index=${page.index} key=$key")

        val result = MangaPageOcr.processPageOcr(context, sourceId, page, rightToLeft)
        withContext(Dispatchers.Main) {
            when (result) {
                is MangaPageOcrResult.Success -> {
                    cacheBlocks(key, result.blocks)
                    if (loadedPageKey == key) {
                        blocks = result.blocks
                        blockIndex = 0
                    }
                    clearStatus()
                }
                is MangaPageOcrResult.RecognizerError -> {
                    updateStatus("OCR error: ${result.message}", MangaTtsStatusCategory.ERROR)
                }
                is MangaPageOcrResult.ImageLoadError -> {
                    updateStatus("Image load error: ${result.message}", MangaTtsStatusCategory.ERROR)
                }
                is MangaPageOcrResult.Cancelled -> {
                    clearStatus()
                }
            }
        }
        result
    }

    // --- Audio focus -------------------------------------------------------
    // A professional read-aloud must not talk over the user's music. We take
    // transient-may-duck focus for the session and give it back on stop. If
    // something else grabs focus (a call, another player), we auto-pause and
    // auto-resume only if WE were the ones who paused.
    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null
    private var hasAudioFocus = false
    var autoPausedByFocusLoss by mutableStateOf(false)
        private set

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                // Incidental short sounds (touch feedback, notification blip) request ducking.
                // Do NOT pause -- simply continue with ducked volume.
                isDucked = true
            }
            AudioManager.AUDIOFOCUS_LOSS,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                if (sessionOn && !isPaused) {
                    autoPausedByFocusLoss = true
                    isPaused = true
                    stopSpeaking()
                    updateStatus("Paused - audio focus lost", MangaTtsStatusCategory.ERROR)
                    scheduleFocusRecoveryWatchdog()
                }
            }
            AudioManager.AUDIOFOCUS_GAIN -> {
                isDucked = false
                watchdogJob?.cancel()
                watchdogJob = null
                if (sessionOn && isPaused && autoPausedByFocusLoss) {
                    autoPausedByFocusLoss = false
                    isPaused = false
                    clearStatus()
                }
            }
        }
    }

    private fun scheduleFocusRecoveryWatchdog() {
        watchdogJob?.cancel()
        watchdogJob = coroutineScope.launch {
            delay(3500)
            if (sessionOn && isPaused && autoPausedByFocusLoss) {
                val ctx = lastContext
                if (ctx != null) {
                    requestAudioFocus(ctx)
                }
                if (hasAudioFocus || sessionOn) {
                    autoPausedByFocusLoss = false
                    isPaused = false
                    clearStatus()
                }
            }
        }
    }

    private fun requestAudioFocus(context: Context) {
        if (hasAudioFocus) return
        try {
            val am = audioManager
                ?: (context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager)
                    ?.also { audioManager = it }
                ?: return
            val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setOnAudioFocusChangeListener(focusListener)
                    .build()
                focusRequest = req
                am.requestAudioFocus(req)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(
                    focusListener,
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                )
            }
            hasAudioFocus = granted == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } catch (t: Throwable) {
            // Focus is best-effort; never let it take the session down.
            hasAudioFocus = false
        }
    }

    // --- Headphone unplug ---------------------------------------------------
    // Unplugging headphones (or a Bluetooth device dropping) reroutes audio to
    // the loudspeaker. A professional read-aloud pauses instead of suddenly
    // reading manga dialogue out loud on the speaker. Standard media-app
    // behaviour, driven by ACTION_AUDIO_BECOMING_NOISY.
    private var noisyReceiver: android.content.BroadcastReceiver? = null

    private fun registerNoisyReceiver(context: Context) {
        if (noisyReceiver != null) return
        try {
            val appContext = context.applicationContext
            val receiver = object : android.content.BroadcastReceiver() {
                override fun onReceive(c: Context?, intent: android.content.Intent?) {
                    if (intent?.action == AudioManager.ACTION_AUDIO_BECOMING_NOISY &&
                        sessionOn && !isPaused
                    ) {
                        isPaused = true
                        stopSpeaking()
                        updateStatus("Paused - headphones disconnected", MangaTtsStatusCategory.ERROR)
                    }
                }
            }
            // Same registration pattern the novel TtsPlaybackService uses.
            androidx.core.content.ContextCompat.registerReceiver(
                appContext,
                receiver,
                android.content.IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),
                androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
            )
            noisyReceiver = receiver
            noisyReceiverContext = appContext
        } catch (t: Throwable) {
            // Best-effort; never let it take the session down.
            noisyReceiver = null
            noisyReceiverContext = null
        }
    }

    private var noisyReceiverContext: Context? = null

    private fun unregisterNoisyReceiver() {
        val receiver = noisyReceiver ?: return
        try {
            noisyReceiverContext?.unregisterReceiver(receiver)
        } catch (t: Throwable) {
            // ignored
        } finally {
            noisyReceiver = null
            noisyReceiverContext = null
        }
    }

    private var screenOffReceiver: android.content.BroadcastReceiver? = null
    private var screenOffReceiverContext: Context? = null

    private fun registerScreenOffReceiver(context: Context) {
        if (screenOffReceiver != null) return
        try {
            val appContext = context.applicationContext
            val receiver = object : android.content.BroadcastReceiver() {
                override fun onReceive(c: Context?, intent: android.content.Intent?) {
                    if (intent?.action == android.content.Intent.ACTION_SCREEN_OFF) {
                        stop()
                    }
                }
            }
            androidx.core.content.ContextCompat.registerReceiver(
                appContext,
                receiver,
                android.content.IntentFilter(android.content.Intent.ACTION_SCREEN_OFF),
                androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
            )
            screenOffReceiver = receiver
            screenOffReceiverContext = appContext
        } catch (t: Throwable) {
            screenOffReceiver = null
            screenOffReceiverContext = null
        }
    }

    private fun unregisterScreenOffReceiver() {
        val receiver = screenOffReceiver ?: return
        try {
            screenOffReceiverContext?.unregisterReceiver(receiver)
        } catch (t: Throwable) {
            // ignored
        } finally {
            screenOffReceiver = null
            screenOffReceiverContext = null
        }
    }

    private fun abandonAudioFocus() {
        if (!hasAudioFocus) {
            focusRequest = null
            return
        }
        try {
            val am = audioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                focusRequest?.let { am.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(focusListener)
            }
        } catch (t: Throwable) {
            // ignored
        } finally {
            hasAudioFocus = false
            focusRequest = null
        }
    }

    fun start(context: Context? = null) {
        sessionOn = true
        isPaused = false
        autoPausedByFocusLoss = false
        isDucked = false
        watchdogJob?.cancel()
        watchdogJob = null
        ttsPageKey = null
        startAtLastBlock = false
        context?.let {
            lastContext = it.applicationContext
            requestAudioFocus(it)
            registerNoisyReceiver(it)
            registerScreenOffReceiver(it)
        }
    }

    /** Called by the reader loop once the engine is up, so focus is held even
     *  when start() was invoked without a context. */
    fun ensureAudioFocus(context: Context) {
        lastContext = context.applicationContext
        if (sessionOn) {
            requestAudioFocus(context)
            registerNoisyReceiver(context)
            registerScreenOffReceiver(context)
        }
    }

    fun stop() {
        sessionOn = false
        isPaused = false
        autoPausedByFocusLoss = false
        isDucked = false
        watchdogJob?.cancel()
        watchdogJob = null
        stopSpeaking()
        abandonAudioFocus()
        unregisterNoisyReceiver()
        unregisterScreenOffReceiver()
        blocks = emptyList()
        blockIndex = 0
        loadedPageKey = null
        clearStatus()
        pendingSkip = 0
        pendingPageDelta = 0
        pageFlipTarget = null
        ttsPageKey = null
        startAtLastBlock = false
        autoScrolling = false
        synchronized(this) { ocrCache.clear() }
    }

    fun pause() {
        isPaused = true
        autoPausedByFocusLoss = false
        stopSpeaking()
    }

    fun togglePause() {
        isPaused = !isPaused
        autoPausedByFocusLoss = false
        if (isPaused) stopSpeaking() else clearStatus()
    }

    fun requestNextBlock() {
        pendingSkip = 1
        stopSpeaking()
    }

    fun requestPrevBlock() {
        pendingSkip = -1
        stopSpeaking()
    }

    fun requestNextPage() {
        pendingPageDelta = 1
        stopSpeaking()
    }

    fun requestPrevPage() {
        pendingPageDelta = -1
        stopSpeaking()
    }

    suspend fun ensureEngine(context: Context): Boolean {
        if (ready && tts != null) return true
        val initialized = CompletableDeferred<Boolean>()
        val engine = TextToSpeech(context.applicationContext) { status ->
            initialized.complete(status == TextToSpeech.SUCCESS)
        }
        val ok = try {
            initialized.await()
        } catch (t: Throwable) {
            false
        }
        if (!ok) {
            try {
                engine.shutdown()
            } catch (t: Throwable) {
                // ignored
            }
            return false
        }
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}

            override fun onDone(utteranceId: String?) {
                pending?.complete(true)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                pending?.complete(false)
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                pending?.complete(false)
            }
        })
        tts = engine
        ready = true
        appContext = context.applicationContext
        applyVoiceSettings()
        return true
    }

    /**
     * Applies the manga reader's OWN voice settings.
     *
     * This used to read TtsPlaybackManager, which is the novel reader's live
     * session state. Reading it was harmless on its own, but it meant the manga
     * voice controls had to write that same shared state to have any effect --
     * and that is what leaked manga choices into novel playback. Both sides now
     * go through MangaReaderPrefs instead.
     */
    fun applyVoiceSettings() {
        val engine = tts ?: return
        val ctx = appContext ?: lastContext ?: return
        try {
            engine.setSpeechRate(MangaReaderPrefs.getTtsRate(ctx))
            engine.setPitch(MangaReaderPrefs.getTtsPitch(ctx))
            val wantedName = MangaReaderPrefs.getTtsVoiceName(ctx)
            if (!wantedName.isNullOrBlank()) {
                val match = engine.voices?.firstOrNull { it.name == wantedName }
                if (match != null) engine.voice = match
            }
        } catch (t: Throwable) {
            // A missing voice must never take the session down.
        }
    }

    /** Speaks and suspends until the utterance finishes or is stopped. Returns true if completed, false if interrupted. */
    suspend fun speak(text: String): Boolean {
        val engine = tts ?: return false
        // Pick up any Accent/Voice/Speed the user changed in reader settings
        // while a read-aloud session is already running.
        applyVoiceSettings()
        val deferred = CompletableDeferred<Boolean>()
        pending = deferred
        isSpeaking = true
        try {
            val params = Bundle().apply {
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, if (isDucked) 0.3f else 1.0f)
            }
            val utteranceId = "manga_tts_" + System.nanoTime()
            val result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
            if (result != TextToSpeech.SUCCESS) {
                return false
            }
            return deferred.await()
        } catch (c: CancellationException) {
            return false
        } finally {
            pending = null
            isSpeaking = false
        }
    }

    fun stopSpeaking() {
        try {
            tts?.stop()
        } catch (t: Throwable) {
            // ignored
        }
        pending?.complete(false)
        pending = null
        isSpeaking = false
    }

    fun shutdown() {
        watchdogJob?.cancel()
        watchdogJob = null
        coroutineScope.cancel()
        stopSpeaking()
        // Navigating away disposes the composable without an ON_STOP, so this
        // must release everything stop() would: audio focus and the
        // becoming-noisy receiver would otherwise leak. Both are idempotent.
        abandonAudioFocus()
        unregisterNoisyReceiver()
        unregisterScreenOffReceiver()
        try {
            tts?.shutdown()
        } catch (t: Throwable) {
            // ignored
        }
        tts = null
        ready = false
    }
}
