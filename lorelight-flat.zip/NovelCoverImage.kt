package com.lorelight.ui.components

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Bounded LRU cache of decoded cover bitmaps, keyed by their Base64 source.
 *
 * S10: this used to be a plain unbounded ConcurrentHashMap. Nothing ever
 * evicted from it, so every distinct cover the user scrolled past stayed
 * decoded in RAM for the entire foreground session - a 500-cover library kept
 * 500 bitmaps alive at once, and the ONLY thing that ever freed them was
 * MemoryManager.releaseHeavyMemory() on background or low-memory. An
 * unbounded image cache that is only trimmed once the system is already in
 * trouble is exactly the kind of allocation android:largeHeap was hiding.
 *
 * Bounded by approximate decoded BYTES rather than by entry count, because
 * cover dimensions vary enormously: 60 shelf thumbnails and 60 full-page
 * scans are the same number of entries and two wildly different amounts of
 * memory. Least-recently-USED is evicted first (accessOrder = true, not
 * insertion order), so the covers currently on screen survive a scroll
 * through the rest of the shelf instead of being evicted by it.
 */
private object base64ImageCache {
    /**
     * Deliberately a fraction of even a modest heap rather than a percentage:
     * this is a convenience cache in front of a cheap re-decode, so it should
     * lose to the manga page cache and the reader under pressure, not compete.
     */
    private const val MAX_BYTES = 24L * 1024 * 1024

    private val map =
        LinkedHashMap<String, androidx.compose.ui.graphics.ImageBitmap>(16, 0.75f, true)
    private var bytes = 0L

    @Synchronized
    operator fun get(key: String): androidx.compose.ui.graphics.ImageBitmap? = map[key]

    @Synchronized
    operator fun set(key: String, value: androidx.compose.ui.graphics.ImageBitmap) {
        map.put(key, value)?.let { bytes -= sizeOf(it) }
        bytes += sizeOf(value)
        val iterator = map.entries.iterator()
        while (bytes > MAX_BYTES && iterator.hasNext()) {
            bytes -= sizeOf(iterator.next().value)
            iterator.remove()
        }
    }

    @Synchronized
    fun clear() {
        map.clear()
        bytes = 0L
    }

    private fun sizeOf(bitmap: androidx.compose.ui.graphics.ImageBitmap): Long =
        bitmap.width.toLong() * bitmap.height.toLong() * 4L
}

/**
 * Largest edge a decoded cover is allowed to keep.
 *
 * Deliberately generous enough for the full-screen Details header rather than
 * sized to the shelf grid, because the same decoded bitmap is shared by both
 * and sizing it to the smaller consumer would visibly soften the larger one.
 */
private const val COVER_MAX_DIMENSION = 1280

/**
 * Power-of-two subsample that keeps a cover under [COVER_MAX_DIMENSION].
 * BitmapFactory only honours powers of two, so returning anything else would
 * silently round anyway.
 */
private fun coverSampleSize(width: Int, height: Int): Int {
    if (width <= 0 || height <= 0) return 1
    var sample = 1
    while (width / sample > COVER_MAX_DIMENSION || height / sample > COVER_MAX_DIMENSION) {
        sample *= 2
    }
    return sample
}

/**
 * Clears the in-memory decoded Base64 / EPUB cover bitmaps. Called by
 * MemoryManager when the app is backgrounded or the system is low on memory.
 * The bitmaps are re-decoded lazily on next display, so this is safe.
 */
fun clearBase64ImageCache() {
    base64ImageCache.clear()
}

@Composable
fun NovelCoverImage(
    coverBase64: String?,
    title: String = "Novel",
    modifier: Modifier = Modifier,
    placeholderKey: String? = null
) {
    if (coverBase64 == null) {
        Box(
            modifier = modifier.background(Color.Transparent),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.MenuBook,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = title.split(" ").firstOrNull() ?: "Novel",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        return
    }

    if (coverBase64.startsWith("http://") || coverBase64.startsWith("https://")) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(coverBase64)
                .memoryCacheKey(coverBase64)
                .diskCacheKey(coverBase64)
                .placeholderMemoryCacheKey(coverBase64)
                // A short fade still hides the pop-in but does not make a
                // cached cover look slow. The default (~200 ms) reads as lag
                // when you are scrolling a shelf.
                .crossfade(100)
                .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .build(),
            contentDescription = "Novel Cover",
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
        return
    }

    if (coverBase64.startsWith("file://")) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(java.io.File(coverBase64.removePrefix("file://")))
                .memoryCacheKey(coverBase64)
                .diskCacheKey(coverBase64)
                .placeholderMemoryCacheKey(placeholderKey ?: coverBase64)
                .crossfade(false)
                .build(),
            contentDescription = "Novel Cover",
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
        return
    }

    // Check high-speed cache first!
    val cachedBitmap = base64ImageCache[coverBase64]
    if (cachedBitmap != null) {
        Image(
            bitmap = cachedBitmap,
            contentDescription = "Novel Cover",
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
        return
    }

    var imageBitmap by remember(coverBase64) { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var isLoading by remember(coverBase64) { mutableStateOf(true) }

    LaunchedEffect(coverBase64) {
        withContext(Dispatchers.IO) {
            try {
                val decodedString = Base64.decode(coverBase64, Base64.DEFAULT)
                // S10: two-pass decode. The previous single-pass call
                // allocated the cover at its full source resolution no matter
                // how small it was actually drawn, so one 8-megapixel cover
                // embedded in an EPUB became a ~32 MB bitmap just to fill a
                // shelf thumbnail. Measuring the bounds first costs no pixel
                // memory at all, and lets the real decode subsample so
                // nothing far larger than it can ever be displayed reaches
                // the heap in the first place.
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size, bounds)
                val decodeOptions = BitmapFactory.Options().apply {
                    inSampleSize = coverSampleSize(bounds.outWidth, bounds.outHeight)
                }
                val bitmap =
                    BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size, decodeOptions)
                val imgBmp = bitmap?.asImageBitmap()
                if (imgBmp != null) {
                    base64ImageCache[coverBase64] = imgBmp
                }
                withContext(Dispatchers.Main) {
                    imageBitmap = imgBmp
                    isLoading = false
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    isLoading = false
                }
            }
        }
    }

    if (isLoading) {
        Box(
            modifier = modifier.background(Color.White.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.MenuBook,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                modifier = Modifier.size(24.dp)
            )
        }
    } else {
        val bitmap = imageBitmap
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = "Novel Cover",
                contentScale = ContentScale.Crop,
                modifier = modifier
            )
        } else {
            Box(
                modifier = modifier.background(Color.Transparent),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(8.dp)
                ) {
                    Icon(
                    imageVector = Icons.Filled.MenuBook,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = title.split(" ").firstOrNull() ?: "Novel",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                }
            }
        }
    }
}
