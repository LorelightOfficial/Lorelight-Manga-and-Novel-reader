package com.lorelight.service

import android.content.Context
import android.net.Uri
import com.lorelight.data.local.NovelPreferences
import com.lorelight.data.model.Novel
import com.lorelight.data.model.isManga
import com.lorelight.data.model.mangaSourceId
import com.lorelight.data.model.encodeMangaChapterUrl
import com.lorelight.data.model.getChapterList
import kotlinx.coroutines.flow.first
import tachiyomi.domain.source.service.SourceManager
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import com.lorelight.browse.model.toNovel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

sealed class EpubImportResult {
    data class Success(val novel: Novel, val isNew: Boolean) : EpubImportResult()
    data class Error(val message: String) : EpubImportResult()
}

object NovelImportManager {
    private val _tick = MutableStateFlow(0L)
    val tick: StateFlow<Long> = _tick

    private val _importing = MutableStateFlow<Set<String>>(emptySet())
    val importing: StateFlow<Set<String>> = _importing

    private fun bump() { _tick.value = _tick.value + 1 }

    private val importMutex = Mutex()

    /**
     * Public entry point, serialised: the in-app picker and an "Open with"
     * hand-off can never import concurrently and clobber each other's
     * extracted epub file or the saved novel list.
     */
    suspend fun importEpub(context: Context, uri: Uri): EpubImportResult =
        importMutex.withLock { importEpubInternal(context, uri) }

    /**
     * Import an EPUB from a Uri into the library storage and database.
     * Deduplicates against existing novels by ID or title+author.
     */
    private suspend fun importEpubInternal(context: Context, uri: Uri): EpubImportResult = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        try {
            if (uri.scheme == "content") {
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri,
                        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {}
            }

            val parsedJson = com.lorelight.utils.EpubExtractor.extract(context, uri)
            val extractError = parsedJson.optString("error", "")
            if (extractError.isNotEmpty() || !parsedJson.has("novelId")) {
                return@withContext EpubImportResult.Error(
                    if (extractError.isNotEmpty()) extractError else "Could not read this EPUB file."
                )
            }

            val novelId = parsedJson.optString("novelId") ?: "unknown_id"
            val metadata = parsedJson.optJSONObject("metadata")
            val cover = parsedJson.optJSONObject("cover")
            val chaptersArray = parsedJson.optJSONArray("chapters")

            val extractedChapters = mutableListOf<String>()
            val virtualUrls = mutableListOf<String>()
            if (chaptersArray != null && chaptersArray.length() > 0) {
                for (i in 0 until chaptersArray.length()) {
                    val chObj = chaptersArray.optJSONObject(i)
                    if (chObj != null) {
                        val chTitle = chObj.optString("title", "Chapter ${i + 1}")
                        val chPath = chObj.optString("file_path", "")
                        val vUrl = "epubfile://${novelId}/${chPath}"
                        extractedChapters.add(chTitle)
                        virtualUrls.add(vUrl)
                    }
                }
            } else {
                extractedChapters.add("Chapter 1")
                virtualUrls.add("epubfile://${novelId}/unknown_chapter_0")
            }

            val title = metadata?.optString("title")?.takeIf { it.isNotBlank() } ?: "Unknown Title"
            val author = metadata?.optJSONArray("author")?.let { if (it.length() > 0) it.optString(0) else "Unknown Author" }
                ?: metadata?.optString("author")?.takeIf { it.isNotBlank() } ?: "Unknown Author"
            val language = metadata?.optString("language")?.takeIf { it.isNotBlank() } ?: "English"
            val description = metadata?.optString("description")?.takeIf { it.isNotBlank() } ?: "EPUB imported."
            val coverImage = cover?.optString("image_base64")

            val newNovel = Novel(
                id = novelId,
                title = title,
                currentChapter = extractedChapters.firstOrNull() ?: "Chapter 1",
                currentParagraphIndex = 0,
                lastReadTimestamp = System.currentTimeMillis(),
                author = author,
                status = "Imported",
                totalChapters = extractedChapters.size,
                language = language,
                genres = listOf("EPUB", "Imported"),
                description = description,
                chapters = extractedChapters,
                chapterUrls = virtualUrls,
                coverImageBase64 = coverImage
            )

            com.lorelight.crawler.CrawlerEngine.clearCacheForUrls(context, virtualUrls)

            val existingNovels = NovelPreferences.loadNovelsFromPrefs(context).toMutableList()
            val existingIndex = existingNovels.indexOfFirst { 
                it.id == newNovel.id || (it.title.equals(newNovel.title, ignoreCase = true) && it.author.equals(newNovel.author, ignoreCase = true))
            }

            if (existingIndex >= 0) {
                val existing = existingNovels[existingIndex]
                val updated = existing.copy(
                    chapters = newNovel.chapters,
                    chapterUrls = newNovel.chapterUrls,
                    totalChapters = newNovel.totalChapters,
                    coverImageBase64 = existing.coverImageBase64 ?: newNovel.coverImageBase64,
                    lastReadTimestamp = System.currentTimeMillis()
                )
                existingNovels[existingIndex] = updated
                NovelPreferences.saveNovelsToPrefsSync(context, existingNovels)
                bump()
                return@withContext EpubImportResult.Success(updated, isNew = false)
            } else {
                existingNovels.add(0, newNovel)
                NovelPreferences.saveNovelsToPrefsSync(context, existingNovels)
                bump()
                return@withContext EpubImportResult.Success(newNovel, isNew = true)
            }
        } catch (e: Exception) {
            com.lorelight.core.DiagnosticLogger.log("EPUB_IMPORT", "Failed to import EPUB: ${e.message}")
            return@withContext EpubImportResult.Error("Failed to import EPUB: ${e.localizedMessage ?: e.message}")
        }
    }

    @Synchronized
    fun ensureHuskSaved(context: Context, husk: Novel) {
        val novels = NovelPreferences.loadNovelsFromPrefs(context).toMutableList()
        val idx = novels.indexOfFirst { it.id == husk.id }
        if (idx >= 0) {
            // re-import: restart from chapter 1 and show the importing state
            val existing = novels[idx]
            novels[idx] = existing.copy(
                status = "Importing",
                currentChapter = "Chapter 1",
                currentParagraphIndex = 0
            )
        } else {
            novels.add(husk.copy(status = "Importing"))
        }
        NovelPreferences.saveNovelsToPrefsSync(context, novels)
        _importing.value = _importing.value + husk.id
        bump()
    }

    /**
     * Saves a novel whose chapter list is ALREADY complete, straight into the
     * library. Used by the in-app browser, where a manga extension or a novel
     * plugin hands over every chapter up front.
     *
     * Deliberately not ensureHuskSaved(): that marks the row "Importing" and
     * hands it to the text crawler, which for a source-linked title would
     * replace real source chapters with scraped text.
     *
     * Returns false when the title is already in the library.
     */
    @Synchronized
    fun addSourcedNovel(context: Context, novel: Novel): Boolean {
        val novels = NovelPreferences.loadNovelsFromPrefs(context).toMutableList()
        val already = novels.any { existing ->
            val samePluginTitle = !existing.pluginId.isNullOrBlank() &&
                existing.pluginId == novel.pluginId &&
                !existing.pluginNovelPath.isNullOrBlank() &&
                existing.pluginNovelPath == novel.pluginNovelPath
            val sameSourceUrl = !existing.sourceUrl.isNullOrBlank() &&
                existing.sourceUrl == novel.sourceUrl
            samePluginTitle || sameSourceUrl
        }
        if (already) return false

        novels.add(novel)
        NovelPreferences.saveNovelsToPrefsSync(context, novels)
        bump()
        return true
    }

    // Called after each streamed batch. Merge new chapters into the saved novel by id.
    @Synchronized
    fun applyChapters(
        context: Context,
        novelId: String,
        chapters: List<com.lorelight.crawler.CrawledChapter>,
        siteTotal: Int
    ) {
        val novels = NovelPreferences.loadNovelsFromPrefs(context).toMutableList()
        val idx = novels.indexOfFirst { it.id == novelId }
        if (idx < 0) return
        val existing = novels[idx]
        
        // Build Novel.chapters + chapterUrls:
        val builtChapters = chapters.map { it.title }
        val builtUrls = chapters.map { it.url }
        // Anchor reading position to the first available chapter unless the user
        // already has real progress that still exists in the list.
        val resolvedCurrentChapter =
            if (existing.currentChapter.isBlank() ||
                existing.currentChapter == "Chapter 1" ||
                !builtChapters.contains(existing.currentChapter)
            ) {
                builtChapters.firstOrNull() ?: existing.currentChapter
            } else {
                existing.currentChapter
            }
        novels[idx] = existing.copy(
            chapters = builtChapters,
            chapterUrls = builtUrls,
            currentChapter = resolvedCurrentChapter,
            totalChapters = maxOf(siteTotal, builtChapters.size),
            status = "Importing",
            dateModified = System.currentTimeMillis()
        )
        NovelPreferences.saveNovelsToPrefsSync(context, novels)
        bump()
    }

    @Synchronized
    fun markDone(context: Context, novelId: String, finalStatus: String) {
        val novels = NovelPreferences.loadNovelsFromPrefs(context).toMutableList()
        val idx = novels.indexOfFirst { it.id == novelId }
        if (idx >= 0) {
            val existing = novels[idx]
            novels[idx] = existing.copy(
                status = finalStatus,
                totalChapters = maxOf(existing.totalChapters, existing.chapters.size),
                dateModified = System.currentTimeMillis()
            )
            NovelPreferences.saveNovelsToPrefsSync(context, novels)
        }
        _importing.value = _importing.value - novelId
        bump()
    }

    @Synchronized
    fun updateNovel(context: Context, novelId: String, transform: (Novel) -> Novel) {
        val novels = NovelPreferences.loadNovelsFromPrefs(context).toMutableList()
        val idx = novels.indexOfFirst { it.id == novelId }
        if (idx < 0) return
        novels[idx] = transform(novels[idx])
        NovelPreferences.saveNovelsToPrefsSync(context, novels)
        bump()
    }

    /**
     * Phase 1B: the progress-only sibling of updateNovel().
     *
     * updateNovel() rewrites the ENTIRE library table (upsert every row, then a
     * delete pass over every id). That is wildly disproportionate for a page turn,
     * and it is the write the library-reversion bug happens inside of. This
     * persists only the reading_progress row for the one novel that moved.
     *
     * Use this when the transform touches nothing but reading position. If it
     * changes chapters, title, cover, favourite state or anything else structural,
     * call updateNovel() instead.
     */
    fun updateNovelProgress(context: Context, novelId: String, transform: (Novel) -> Novel) {
        val target = NovelPreferences.loadNovelsFromPrefs(context)
            .firstOrNull { it.id == novelId } ?: return
        NovelPreferences.saveProgressOnly(context, transform(target))
        bump()
    }

    private const val THREE_DAYS_MS = 3L * 24 * 60 * 60 * 1000

    /**
     * Re-scan a novel's source for new chapters and append any whose URL we don't
     * already have. Uses the fast FWN tail-fetch, falling back to a full scan for
     * other sites. Stamps the check time and returns how many new chapters were added.
     */
    suspend fun checkForNewChapters(context: Context, novelId: String): Int {
        val target = NovelPreferences.loadNovelsFromPrefs(context).firstOrNull { it.id == novelId } ?: return 0

        // Plugin-backed novels can't be crawled by URL; re-parse them through the JS plugin engine.
        if (target.pluginId != null) {
            return checkForNewPluginChapters(context, target)
        }

        val url = target.sourceUrl
        if (url.isNullOrBlank()) return 0
        val existingUrls = target.chapterUrls.toSet()

        var latest: List<com.lorelight.crawler.CrawledChapter> = emptyList()
        com.lorelight.crawler.CrawlerEngine.streamChapters(url, context) { chapters, _ ->
            latest = chapters
        }

        // Keep only chapters whose URL we don't already have, preserving order.
        val newOnes = latest.filter { it.url !in existingUrls }

        val novels = NovelPreferences.loadNovelsFromPrefs(context).toMutableList()
        val idx = novels.indexOfFirst { it.id == novelId }
        if (idx < 0) return 0
        val existing = novels[idx]
        novels[idx] = if (newOnes.isNotEmpty()) {
            existing.copy(
                chapters = existing.chapters + newOnes.map { it.title },
                chapterUrls = existing.chapterUrls + newOnes.map { it.url },
                totalChapters = maxOf(existing.totalChapters, existing.chapterUrls.size + newOnes.size),
                lastCheckedTimestamp = System.currentTimeMillis(),
                dateModified = System.currentTimeMillis()
            )
        } else {
            existing.copy(lastCheckedTimestamp = System.currentTimeMillis())
        }
        NovelPreferences.saveNovelsToPrefsSync(context, novels)
        bump()
        return newOnes.size
    }

    suspend fun checkForNewMangaChapters(context: Context, target: Novel): Int {
        val sourceId = target.mangaSourceId ?: return 0
        val path = target.pluginNovelPath ?: target.sourceUrl ?: return 0
        val sourceManager = Injekt.get<SourceManager>()
        sourceManager.isInitialized.first { it }
        val source = sourceManager.get(sourceId) ?: return 0
        val reqManga = eu.kanade.tachiyomi.source.model.SManga.create().apply { url = path }
        val freshChapters = try {
            source.getChapterList(reqManga)
        } catch (e: Exception) {
            return 0
        }
        val reversedChapters = freshChapters.reversed()
        val reversedUrls = reversedChapters.map { encodeMangaChapterUrl(sourceId, it.url) }
        val reversedNumbers = reversedChapters.map { it.chapter_number }
        val existingUrls = target.chapterUrls.toSet()
        val newTitles = mutableListOf<String>()
        val newUrls = mutableListOf<String>()
        val newNumbers = mutableListOf<Float>()
        reversedUrls.forEachIndexed { i, u ->
            if (u !in existingUrls) {
                newUrls.add(u)
                val rawName = reversedChapters.getOrNull(i)?.name
                val fallbackNum = existingUrls.size + newUrls.size
                val title = if (!rawName.isNullOrBlank()) rawName else "Chapter $fallbackNum"
                newTitles.add(title)
                newNumbers.add(reversedNumbers.getOrNull(i) ?: -1f)
            }
        }
        val novels = NovelPreferences.loadNovelsFromPrefs(context).toMutableList()
        val idx = novels.indexOfFirst { it.id == target.id }
        if (idx < 0) return 0
        val existing = novels[idx]
        novels[idx] = if (newUrls.isNotEmpty()) {
            existing.copy(
                chapters = existing.chapters + newTitles,
                chapterUrls = existing.chapterUrls + newUrls,
                chapterNumbers = existing.chapterNumbers + newNumbers,
                totalChapters = maxOf(existing.totalChapters, existing.chapterUrls.size + newUrls.size),
                lastCheckedTimestamp = System.currentTimeMillis(),
                dateModified = System.currentTimeMillis()
            )
        } else {
            existing.copy(lastCheckedTimestamp = System.currentTimeMillis())
        }
        NovelPreferences.saveNovelsToPrefsSync(context, novels)
        bump()
        return newUrls.size
    }

    // Plugin variant of checkForNewChapters: re-parse the novel via its plugin and
    // append any chapters whose lnplugin:// URL we don't already have.
    private suspend fun checkForNewPluginChapters(context: Context, target: Novel): Int {
        if (target.isManga) {
            return checkForNewMangaChapters(context, target)
        }

        val pluginId = target.pluginId ?: return 0
        val path = target.pluginNovelPath ?: target.sourceUrl ?: return 0
        val fresh = try {
            com.lorelight.browse.js.JSPluginEngine.parseNovel(context, pluginId, path).toNovel(pluginId)
        } catch (e: Exception) {
            return 0
        }
        val existingUrls = target.chapterUrls.toSet()
        val newTitles = mutableListOf<String>()
        val newUrls = mutableListOf<String>()
        fresh.chapterUrls.forEachIndexed { i, u ->
            if (u !in existingUrls) {
                newUrls.add(u)
                newTitles.add(fresh.chapters.getOrNull(i) ?: "Chapter ${existingUrls.size + newUrls.size}")
            }
        }
        val novels = NovelPreferences.loadNovelsFromPrefs(context).toMutableList()
        val idx = novels.indexOfFirst { it.id == target.id }
        if (idx < 0) return 0
        val existing = novels[idx]
        novels[idx] = if (newUrls.isNotEmpty()) {
            existing.copy(
                chapters = existing.chapters + newTitles,
                chapterUrls = existing.chapterUrls + newUrls,
                totalChapters = maxOf(existing.totalChapters, existing.chapterUrls.size + newUrls.size),
                lastCheckedTimestamp = System.currentTimeMillis(),
                dateModified = System.currentTimeMillis()
            )
        } else {
            existing.copy(lastCheckedTimestamp = System.currentTimeMillis())
        }
        NovelPreferences.saveNovelsToPrefsSync(context, novels)
        bump()
        return newUrls.size
    }

    /**
     * Auto-check (on app open): re-scan every online novel that has not been
     * checked in 3+ days. Freshly added novels are skipped until 3 days after add.
     */
    suspend fun autoCheckStaleNovels(context: Context) {
        val now = System.currentTimeMillis()
        val candidates = NovelPreferences.loadNovelsFromPrefs(context).filter {
            it.isOnline &&
                !it.sourceUrl.isNullOrBlank() &&
                it.status != "Importing" &&
                (now - maxOf(it.lastCheckedTimestamp, it.dateAdded)) >= THREE_DAYS_MS
        }
        for (n in candidates) {
            try {
                checkForNewChapters(context, n.id)
            } catch (e: Exception) {
                com.lorelight.core.DiagnosticLogger.log("AUTO_CHECK", "Failed for '${n.title}': ${e.message}")
            }
        }
    }

    /**
     * Manual "refetch details" for a single novel.
     *
     * Re-reads everything the Details page shows - cover art, genres,
     * description, author, status and the full chapter list - straight from the
     * source, then writes it back over the stored copy.
     *
     * Reading state is deliberately inherited from the existing row and never
     * overwritten: currentChapter, lastReadTimestamp, currentParagraphIndex,
     * currentScrollOffset, currentWordIndex, completedChapters, isFavorite,
     * categories, readingStatus, dateAdded and the novel id all survive.
     *
     * Returns true when fresh data was written.
     */
    suspend fun refetchNovelDetails(context: Context, novelId: String): Boolean {
        val target = NovelPreferences.loadNovelsFromPrefs(context).firstOrNull { it.id == novelId } ?: return false

        val fresh: Novel = try {
            val pluginId = target.pluginId
            if (pluginId != null) {
                // Plugin-backed novel: re-parse through the JS plugin engine.
                val path = target.pluginNovelPath ?: target.sourceUrl ?: return false
                com.lorelight.browse.js.JSPluginEngine.parseNovel(context, pluginId, path).toNovel(pluginId)
            } else {
                // Crawler-backed novel: re-analyze the source URL.
                val url = target.sourceUrl
                if (url.isNullOrBlank()) return false
                val crawled = com.lorelight.crawler.CrawlerEngine.analyzeUrl(url, context)
                Novel(
                    title = crawled.title,
                    currentChapter = "",
                    lastReadTimestamp = 0L,
                    author = crawled.author,
                    status = crawled.status,
                    totalChapters = crawled.chapters.size,
                    genres = crawled.genres,
                    description = crawled.description,
                    chapters = crawled.chapters.map { it.title },
                    coverImageBase64 = crawled.coverUrl,
                    isOnline = true,
                    sourceUrl = url,
                    chapterUrls = crawled.chapters.map { it.url }
                )
            }
        } catch (e: Exception) {
            com.lorelight.core.DiagnosticLogger.log("REFETCH", "Failed for '${target.title}': ${e.message}")
            return false
        }

        // Refresh the on-disk cover file so the Details page shows the new image.
        var coverValue = target.coverImageBase64
        val remoteCover = fresh.coverImageBase64
        if (!remoteCover.isNullOrBlank()) {
            if (remoteCover.startsWith("http://", ignoreCase = true) || remoteCover.startsWith("https://", ignoreCase = true)) {
                val saved = com.lorelight.data.local.CoverStorage.downloadAndSaveCover(context, target.id, remoteCover)
                coverValue = saved ?: remoteCover
            } else {
                coverValue = remoteCover
            }
        }

        val novels = NovelPreferences.loadNovelsFromPrefs(context).toMutableList()
        val idx = novels.indexOfFirst { it.id == novelId }
        if (idx < 0) return false
        val existing = novels[idx]

        novels[idx] = existing.copy(
            title = fresh.title.ifBlank { existing.title },
            author = fresh.author.ifBlank { existing.author },
            status = fresh.status.ifBlank { existing.status },
            genres = if (fresh.genres.isNotEmpty()) fresh.genres else existing.genres,
            description = if (fresh.description.isNotBlank()) fresh.description else existing.description,
            coverImageBase64 = coverValue,
            chapters = if (fresh.chapters.isNotEmpty()) fresh.chapters else existing.chapters,
            chapterUrls = if (fresh.chapterUrls.isNotEmpty()) fresh.chapterUrls else existing.chapterUrls,
            chapterNumbers = if (fresh.chapterNumbers.isNotEmpty()) fresh.chapterNumbers else existing.chapterNumbers,
            totalChapters = if (fresh.chapters.isNotEmpty()) fresh.chapters.size else existing.totalChapters,
            lastCheckedTimestamp = System.currentTimeMillis(),
            dateModified = System.currentTimeMillis()
        )
        NovelPreferences.saveNovelsToPrefsSync(context, novels)
        bump()
        return true
    }

    /**
     * Refetch details for every online novel in the library.
     * Reports (done, total) so the settings UI can show a live counter.
     * Returns how many novels were refreshed successfully.
     */
    suspend fun refetchAllNovelDetails(
        context: Context,
        onProgress: (Int, Int) -> Unit = { _, _ -> }
    ): Int {
        val targets = NovelPreferences.loadNovelsFromPrefs(context).filter {
            (!it.sourceUrl.isNullOrBlank() || it.pluginId != null) && it.status != "Importing"
        }
        var done = 0
        var refreshed = 0
        onProgress(0, targets.size)
        for (n in targets) {
            try {
                if (refetchNovelDetails(context, n.id)) refreshed++
            } catch (e: Exception) {
                com.lorelight.core.DiagnosticLogger.log("REFETCH", "Failed for '${n.title}': ${e.message}")
            }
            done++
            onProgress(done, targets.size)
        }
        return refreshed
    }
}
