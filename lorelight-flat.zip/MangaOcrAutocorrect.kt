package com.lorelight.manga.reader

import android.content.Context
import android.util.Log

/**
 * How hard the OCR autocorrect is allowed to try.
 *
 * The reader speaks whatever ML Kit returns, and ML Kit does no dictionary
 * checking at all. Stylised manga lettering therefore produces predictable
 * letter mix-ups: `b`, `d`, `p`, `q`, `h` and `g` are all a circle plus a
 * stick, so "body" becomes "boby" and "done" becomes "pone".
 *
 * Every level only ever touches tokens that are NOT words. Anything the
 * dictionary knows -- including every curse in the protected list -- is spoken
 * exactly as it was read. The levels differ only in how far the search may
 * reach and how much support the sentence must give before a swap is accepted.
 */
enum class MangaOcrCorrectionLevel {
    OFF,
    SAFE,
    BALANCED,
    AGGRESSIVE;

    val label: String
        get() = when (this) {
            OFF -> "Off"
            SAFE -> "Safe"
            BALANCED -> "Balanced"
            AGGRESSIVE -> "Aggressive"
        }

    val summary: String
        get() = when (this) {
            OFF -> "Speak exactly what OCR returned."
            SAFE -> "Repair non-words with one letter mix-up, and only when the sentence agrees."
            BALANCED -> "Repair non-words with up to two letter mix-ups, letting the sentence pick the word. Recommended."
            AGGRESSIVE -> "Also repair non-words when the sentence gives no hint, falling back to the best fit."
        }

    companion object {
        fun fromName(name: String?): MangaOcrCorrectionLevel =
            values().firstOrNull { it.name == name } ?: BALANCED
    }
}

/**
 * Dictionary-backed, confusion-aware, sentence-aware autocorrect for OCR output.
 *
 * Applied on the way OUT to the voice only. The OCR disk cache and the
 * on-screen debug boxes keep the pristine recognizer text, so nothing here can
 * corrupt a stored page or be re-applied twice to the same text.
 *
 * Two rules drive everything:
 *
 *  1. Only non-words are candidates for repair. If the dictionary knows the
 *     token, it is spoken as-is. A real word is never "upgraded" into a more
 *     common one, because that is how a correct line quietly turns into a
 *     different line.
 *  2. The sentence decides. Given "bo", frequency alone offers "be", "do",
 *     "go" and "so" with nearly equal enthusiasm. Reading the neighbouring
 *     words is what makes "do" win in "I can't let you bo that" while "go"
 *     wins in "let's bo home".
 */
object MangaOcrAutocorrect {

    private const val TAG = "LorelightOCR"
    private const val ASSET = "ocr_words_en.txt"

    /** Rank ceiling for a replacement at SAFE. Only very common words qualify. */
    private const val SAFE_MAX_RANK = 1200

    /**
     * Synthetic frequency rank given to the protected words below: common
     * enough to be offered as the repair for a misread curse, not so common
     * that it outranks ordinary vocabulary.
     */
    private const val PROTECTED_RANK = 900

    @Volatile
    private var loaded = false
    private val lock = Any()

    /** Every known word, including generated inflections. Membership only. */
    private val words = HashSet<String>(20_000)

    /** Frequency rank of the common words. Lower index == more common. */
    private val ranks = HashMap<String, Int>(4096)
    private var commonCount = 0

    /**
     * Swearing is dialogue, not a mistake.
     *
     * General-purpose word lists leave profanity out on purpose, which means
     * that without this list every curse looks like a non-word to the pass
     * below -- and the repair would quietly repaint it as something polite.
     * That is censorship by accident, and it is not this feature's job.
     *
     * Loading them as real words means they are never replaced. Giving them a
     * rank as well means the repair can land ON them, so a curse the recognizer
     * mangled is restored rather than neutered.
     */
    private val protectedWords: List<String> = listOf(
        "fuck", "fucks", "fucked", "fucking", "fuckin", "fucker", "fuckers", "fucked",
        "motherfucker", "motherfuckers", "motherfucking", "clusterfuck",
        "shit", "shits", "shitty", "shitting", "shithead", "bullshit", "dogshit",
        "bitch", "bitches", "bitching", "bitchy",
        "bastard", "bastards",
        "ass", "asses", "asshole", "assholes", "dumbass", "jackass", "badass",
        "arse", "arsehole",
        "damn", "damned", "damnit", "dammit", "goddamn", "goddamned", "goddamnit",
        "hell", "crap", "crappy",
        "piss", "pissed", "pissing",
        "dick", "dickhead", "prick", "cock", "cunt", "twat",
        "wank", "wanker", "bollocks", "bloody", "bugger", "sod",
        "slut", "sluts", "whore", "whores", "skank",
        "screwed", "freaking", "frickin", "friggin", "frigging",
        "jerk", "moron", "idiot", "scum", "scumbag", "swine", "filth", "punk"
    )

    /**
     * Word pairs common enough in dialogue to count as evidence.
     *
     * This is deliberately small and hand-picked rather than a statistical
     * model: it only needs to break ties between candidates that frequency
     * alone cannot separate, and a short list of pairs that genuinely appear in
     * speech does that without shipping a language model in the APK.
     */
    private val bigrams: Set<String> by lazy {
        hashSetOf(
            // first person
            "i am", "i was", "i will", "i have", "i had", "i can", "i cant", "i could",
            "i would", "i should", "i do", "i dont", "i did", "i know", "i think",
            "i want", "i need", "i see", "i said", "i got", "i just", "i love",
            "i hate", "i feel", "i thought", "i guess", "i mean", "i wish", "i wonder",
            "i swear", "i promise", "i believe", "i remember", "i forgot", "i told",
            // second person
            "you are", "you were", "you will", "you have", "you had", "you can",
            "you cant", "you could", "you would", "you should", "you do", "you dont",
            "you did", "you know", "you think", "you want", "you need", "you must",
            "you got", "you said", "you look", "you like", "you mean", "you idiot",
            // third person and copulas
            "he is", "he was", "he will", "he did", "she is", "she was", "she will",
            "she did", "they are", "they were", "they will", "we are", "we were",
            "we will", "we can", "we have", "we should", "it is", "it was", "it will",
            "that is", "that was", "this is", "this was", "there is", "there was",
            "there are", "here is", "here comes", "who is", "what is",
            // questions
            "do you", "did you", "are you", "were you", "have you", "can you",
            "will you", "would you", "could you", "should you", "what are", "what do",
            "what did", "what happened", "what the", "who are", "who did", "where are",
            "where is", "where did", "when did", "when you", "why did", "why are",
            "why you", "how did", "how are", "how do", "how many", "how much",
            // imperatives that fill speech bubbles
            "do that", "do this", "do it", "do something", "do anything", "did that",
            "let me", "let go", "let us", "come on", "come here", "come back",
            "get out", "get up", "get back", "get away", "go away", "go back",
            "go home", "hold on", "shut up", "wake up", "calm down", "look out",
            "look at", "watch out", "stay back", "stay here", "stop it", "move it",
            "take care", "take this", "take it", "give me", "give up", "tell me",
            "help me", "leave me", "follow me", "trust me", "forgive me", "kill me",
            "save me", "listen to", "shut it", "back off", "run away", "hurry up",
            // determiners
            "the same", "the end", "the first", "the last", "the only", "the other",
            "the whole", "the world", "the truth", "the enemy", "the king", "the master",
            "the power", "the door", "the fight", "the hell", "the way", "the time",
            "a little", "a lot", "a moment", "a second", "a minute", "a chance",
            "a problem", "a good", "a bad", "a new", "a man", "a woman", "a monster",
            "an hour", "an idea", "an enemy", "an answer", "an eye", "an old",
            // prepositions and connectives
            "of course", "of the", "in the", "on the", "at the", "to the", "for the",
            "with the", "from the", "into the", "out of", "because of", "kind of",
            "sort of", "one of", "all of", "most of", "part of", "instead of",
            "and then", "but i", "but you", "if you", "if i", "so much", "too much",
            "not much", "as well", "at all", "in time", "on time",
            // negations
            "is not", "was not", "are not", "were not", "do not", "does not",
            "did not", "will not", "would not", "should not", "have not", "has not",
            "can not", "no way", "no one", "not yet", "not now", "never again",
            // common dialogue tails
            "right now", "right here", "right there", "over there", "over here",
            "back then", "this time", "next time", "last time", "that guy",
            "that girl", "this guy", "my friend", "my brother", "my sister",
            "my father", "my mother", "my name", "my fault", "your name",
            "your fault", "for you", "for me", "to you", "to me", "with me",
            "with you", "about it", "about you", "about me", "from here",
            "up there", "down there", "thank you", "excuse me", "what now"
        )
    }

    /**
     * Bidirectional letter mix-ups OCR genuinely makes on stylised lettering.
     * Restricting candidates to these is what keeps false corrections rare:
     * an ordinary word almost never has a common neighbour under this table.
     */
    private val confusions: List<Pair<String, String>> by lazy {
        val seeds = listOf(
            // circle-plus-stick family, the dominant manga failure
            "b" to "h", "b" to "d", "b" to "p", "d" to "p", "d" to "q",
            "p" to "q", "g" to "q", "g" to "y", "h" to "k", "n" to "h",
            // stroke-count confusions
            "n" to "r", "m" to "n", "u" to "v", "u" to "n", "y" to "v",
            "w" to "v", "k" to "x", "t" to "i", "l" to "t", "f" to "t",
            // rounded glyphs
            "c" to "e", "c" to "o", "e" to "o", "a" to "o", "a" to "e",
            "i" to "l", "i" to "j", "s" to "g", "z" to "s",
            // digit / letter lookalikes
            "o" to "0", "l" to "1", "i" to "1", "s" to "5", "b" to "8",
            "g" to "6", "z" to "2", "g" to "9",
            // ligature splits and merges
            "rn" to "m", "cl" to "d", "li" to "h", "vv" to "w",
            "ii" to "u", "nn" to "m", "ri" to "n"
        )
        val out = ArrayList<Pair<String, String>>(seeds.size * 2)
        for ((a, b) in seeds) {
            out.add(a to b)
            out.add(b to a)
        }
        out
    }

    /** Loads the bundled word list once. Failure degrades to passthrough. */
    fun ensureLoaded(context: Context) {
        if (loaded) return
        synchronized(lock) {
            if (loaded) return
            try {
                context.assets.open(ASSET).bufferedReader().use { reader ->
                    var index = 0
                    reader.forEachLine { raw ->
                        val line = raw.trim()
                        if (line.isEmpty()) return@forEachLine
                        if (line.startsWith("#")) {
                            val eq = line.indexOf('=')
                            if (eq > 0) {
                                commonCount = line.substring(eq + 1).trim().toIntOrNull() ?: 0
                            }
                            return@forEachLine
                        }
                        words.add(line)
                        if (index < commonCount) ranks[line] = index
                        index++
                    }
                }
                // Protected vocabulary goes in last so it can never be shadowed
                // by, or displaced from, the bundled list.
                for (w in protectedWords) {
                    words.add(w)
                    if (!ranks.containsKey(w)) ranks[w] = PROTECTED_RANK
                }
                Log.d(TAG, "[LorelightOCR] autocorrect dictionary: ${words.size} words, ${ranks.size} ranked")
            } catch (t: Throwable) {
                Log.w(TAG, "[LorelightOCR] autocorrect dictionary unavailable: ${t.message}")
            } finally {
                // Set regardless, so a missing asset can never cause a retry storm.
                loaded = true
            }
        }
    }

    /** True once a usable dictionary is in memory. */
    fun isReady(context: Context): Boolean {
        ensureLoaded(context)
        return words.isNotEmpty() && commonCount > 0
    }

    private fun isApostrophe(c: Char): Boolean = c == '\'' || c == '\u2019'

    private fun isSentenceBreak(c: Char): Boolean =
        c == '.' || c == '!' || c == '?' || c == ';' || c == '\n' || c == '\u2026'

    /**
     * One word of OCR output, with where it sits in the original string and
     * which sentence it belongs to.
     */
    private class Token(
        val start: Int,
        val end: Int,
        val raw: String,
        val sentence: Int,
        val firstInSentence: Boolean
    ) {
        val lower: String = raw.lowercase().replace('\u2019', '\'')
    }

    /**
     * Splits into words while tracking sentence boundaries.
     *
     * Apostrophes stay inside the word. Splitting on them would leave an orphan
     * "DON" from "DON'T", which then "repairs" into "CLAN".
     */
    private fun tokenize(text: String): List<Token> {
        val out = ArrayList<Token>()
        val n = text.length
        var sentence = 0
        var firstInSentence = true
        var i = 0
        while (i < n) {
            val ch = text[i]
            if (!ch.isLetter()) {
                if (isSentenceBreak(ch)) {
                    sentence++
                    firstInSentence = true
                }
                i++
                continue
            }
            var j = i
            while (j < n) {
                if (text[j].isLetter()) {
                    j++
                } else if (isApostrophe(text[j]) && j + 1 < n && text[j + 1].isLetter()) {
                    j += 2
                } else {
                    break
                }
            }
            out.add(Token(i, j, text.substring(i, j), sentence, firstInSentence))
            firstInSentence = false
            i = j
        }
        return out
    }

    private class Candidate(val word: String, val depth: Int)

    private fun expand(word: String, out: MutableSet<String>, cap: Int) {
        for ((from, to) in confusions) {
            var idx = word.indexOf(from)
            while (idx >= 0) {
                val cand = word.substring(0, idx) + to + word.substring(idx + from.length)
                if (cand.length in 2..24) out.add(cand)
                if (out.size >= cap) return
                idx = word.indexOf(from, idx + 1)
            }
        }
    }

    /** Words reachable from [word] through one or two OCR mix-ups. */
    private fun candidatesFor(word: String, maxDepth: Int): List<Candidate> {
        val first = LinkedHashSet<String>()
        expand(word, first, 300)
        val out = ArrayList<Candidate>(first.size + 16)
        for (w in first) {
            if (w != word) out.add(Candidate(w, 1))
        }
        if (maxDepth <= 1) return out
        val second = LinkedHashSet<String>()
        for (w in first) {
            expand(w, second, 1500)
            if (second.size >= 1500) break
        }
        for (w in second) {
            if (w != word && w !in first) out.add(Candidate(w, 2))
        }
        return out
    }

    private class Scored(val word: String, val score: Double, val hasContext: Boolean)

    /**
     * Scores one candidate against the sentence around the misread word.
     *
     * Frequency is only the baseline. What actually decides close calls is
     * whether the candidate forms a phrase people say with the word before or
     * after it, whether the sentence already used that word correctly, and
     * whether it agrees with a preceding "a" / "an".
     */
    private fun scoreCandidate(
        cand: Candidate,
        prev: String?,
        next: String?,
        sentenceWords: Set<String>
    ): Scored? {
        val rank = ranks[cand.word] ?: return null
        val firstChar = cand.word.firstOrNull() ?: return null

        // 1.0 for the most common word in the list, approaching 0 at the tail.
        var score = 1.0 - (rank.toDouble() / commonCount.coerceAtLeast(1).toDouble())
        // One mix-up is a likelier misread than two.
        if (cand.depth == 1) score += 0.35

        var hasContext = false
        if (prev != null && bigrams.contains(prev + " " + cand.word)) {
            score += 1.5
            hasContext = true
        }
        if (next != null && bigrams.contains(cand.word + " " + next)) {
            score += 1.5
            hasContext = true
        }
        // The same word used correctly elsewhere in the same sentence.
        if (sentenceWords.contains(cand.word)) {
            score += 0.5
            hasContext = true
        }
        if (prev == "a" || prev == "an") {
            val startsVowel = firstChar == 'a' || firstChar == 'e' || firstChar == 'i' ||
                firstChar == 'o' || firstChar == 'u'
            if ((prev == "an") == startsVowel) {
                score += 0.4
                hasContext = true
            } else {
                score -= 1.2
            }
        }
        return Scored(cand.word, score, hasContext)
    }

    /**
     * Returns the repaired lower-case word, or null to leave it alone.
     *
     * A token the dictionary knows is returned untouched, always. That single
     * rule is what keeps names, slang and swearing intact.
     */
    private fun repairToken(
        lower: String,
        level: MangaOcrCorrectionLevel,
        prev: String?,
        next: String?,
        sentenceWords: Set<String>
    ): String? {
        if (level == MangaOcrCorrectionLevel.OFF) return null
        // Very short words are ambiguous under this table ("be"/"he"/"de") and
        // very long ones are almost always names or compounds.
        if (lower.length < 3 || lower.length > 18) return null
        // Page numbers, chapter numbers and mixed alphanumerics are never words.
        if (lower.any { it.isDigit() }) return null
        // Known word -- including every protected curse -- is spoken as read.
        if (words.contains(lower)) return null

        val maxDepth = if (level == MangaOcrCorrectionLevel.SAFE) 1 else 2
        val maxRank = if (level == MangaOcrCorrectionLevel.SAFE) SAFE_MAX_RANK else commonCount

        var bestWord: String? = null
        var bestScore = Double.NEGATIVE_INFINITY
        var bestContext = false
        var secondScore = Double.NEGATIVE_INFINITY
        var considered = 0

        for (cand in candidatesFor(lower, maxDepth)) {
            val rank = ranks[cand.word] ?: continue
            if (rank >= maxRank) continue
            val scored = scoreCandidate(cand, prev, next, sentenceWords) ?: continue
            considered++
            if (scored.score > bestScore) {
                secondScore = bestScore
                bestScore = scored.score
                bestWord = scored.word
                bestContext = scored.hasContext
            } else if (scored.score > secondScore) {
                secondScore = scored.score
            }
        }

        val winner = bestWord ?: return null
        // With a single survivor there is nothing to be ambiguous against.
        val margin = if (considered <= 1) 1.0 else bestScore - secondScore

        return when (level) {
            // Sentence support required. Frequency on its own is not evidence.
            MangaOcrCorrectionLevel.SAFE ->
                if ((bestContext || considered <= 1) && margin >= 0.35) winner else null
            // Either the sentence backs it, or one candidate is a clear winner.
            MangaOcrCorrectionLevel.BALANCED ->
                if (bestContext || margin >= 0.5) winner else null
            // Will guess, but still refuses a coin flip between two candidates.
            MangaOcrCorrectionLevel.AGGRESSIVE ->
                if (margin >= 0.15) winner else null
            MangaOcrCorrectionLevel.OFF -> null
        }
    }

    /**
     * Reapplies the original capitalisation, so ALL-CAPS manga dialogue stays
     * shouty. Majority rather than strict all-caps, because the misread letter
     * itself is often the odd lower-case one ("MOVc" is still a shout).
     */
    private fun matchCase(original: String, replacement: String): String {
        val uppers = original.count { it.isUpperCase() }
        val lowers = original.count { it.isLowerCase() }
        return when {
            uppers > lowers -> replacement.uppercase()
            original.isNotEmpty() && original[0].isUpperCase() ->
                replacement.replaceFirstChar { it.uppercaseChar() }
            else -> replacement
        }
    }

    /**
     * Repairs [text] for read-aloud. Punctuation, spacing and capitalisation are
     * preserved; only whole non-words are swapped, and only when the sentence
     * they sit in supports the swap.
     */
    fun correct(context: Context, text: String, level: MangaOcrCorrectionLevel): String {
        if (level == MangaOcrCorrectionLevel.OFF || text.isBlank()) return text
        ensureLoaded(context)
        if (words.isEmpty() || commonCount <= 0) return text

        val tokens = tokenize(text)
        if (tokens.isEmpty()) return text

        // The real words of each sentence, so a repair can be backed by the rest
        // of the line instead of by frequency alone.
        val sentenceWords = HashMap<Int, MutableSet<String>>()
        for (t in tokens) {
            if (words.contains(t.lower)) {
                sentenceWords.getOrPut(t.sentence) { HashSet() }.add(t.lower)
            }
        }

        val sb = StringBuilder(text.length)
        var cursor = 0
        for ((idx, token) in tokens.withIndex()) {
            sb.append(text, cursor, token.start)
            cursor = token.end

            // A capitalised word in the MIDDLE of a sentence is usually a
            // character name, and names are exactly what must not be "fixed".
            // At the start of a sentence the capital says nothing, so that
            // position stays eligible.
            val looksProper = !token.firstInSentence &&
                token.raw.length > 1 &&
                token.raw[0].isUpperCase() &&
                token.raw.drop(1).any { it.isLowerCase() }

            var fixed: String? = null
            if (!(looksProper && level != MangaOcrCorrectionLevel.AGGRESSIVE)) {
                val prev = tokens.getOrNull(idx - 1)
                    ?.takeIf { it.sentence == token.sentence }?.lower
                val next = tokens.getOrNull(idx + 1)
                    ?.takeIf { it.sentence == token.sentence }?.lower
                val ctx: Set<String> = sentenceWords[token.sentence] ?: emptySet()

                fixed = repairToken(token.lower, level, prev, next, ctx)
                if (fixed == null && token.lower.contains('\'') && !words.contains(token.lower)) {
                    // Possessive or contraction whose stem is the misread part.
                    val cut = token.lower.lastIndexOf('\'')
                    val head = token.lower.substring(0, cut)
                    val tail = token.lower.substring(cut)
                    if (head.length >= 3 && !words.contains(head)) {
                        val repaired = repairToken(head, level, prev, next, ctx)
                        if (repaired != null) fixed = repaired + tail
                    }
                }
            }

            if (fixed == null) sb.append(token.raw) else sb.append(matchCase(token.raw, fixed))
        }
        sb.append(text, cursor, text.length)
        return sb.toString()
    }
}
