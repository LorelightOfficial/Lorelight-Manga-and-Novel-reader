package com.lorelight.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.lorelight.ui.theme.rememberGlassPalette

/**
 * An icon button cut from the same glass as [com.lorelight.ui.theme.GlassPanel].
 *
 * The app's panels, sheets and bars are all glass, but its icon buttons were
 * bare Material [androidx.compose.material3.IconButton]s: a transparent hit
 * target with an icon in it and nothing else. Against a glass surface that
 * reads as unfinished, because the button has no body of its own.
 *
 * This gives a button a real pane: the same tinted container, the same top
 * refraction bloom, the same bottom thickness shading and the same lit top
 * edge that the large panels use, scaled down to a control.
 *
 * ## Why not just reuse GlassPanel
 *
 * GlassPanel casts a 10.dp shadow and is built for surfaces that hold content.
 * At 40.dp that shadow is heavier than the button itself and a row of them
 * turns into a row of dark smudges. This draws the same optics with no shadow
 * and a single hairline instead.
 *
 * ## Cost
 *
 * Two gradient rects per button per draw. [Brush] instances are created inside
 * `drawBehind`, which runs in the draw phase only -- these never sit on a
 * scroll or animation path, so that is acceptable here. Do not use this inside
 * a list item that scrolls at speed; use a plain icon there.
 */
@Composable
fun GlassIconButton(
    onClick: () -> Unit,
    icon: ImageVector,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    buttonSize: Dp = 40.dp,
    iconSize: Dp = 20.dp,
    tint: Color = MaterialTheme.colorScheme.onSurface,
    enabled: Boolean = true,
    shape: Shape = CircleShape,
    containerTint: Color? = null
) {
    GlassIconSurface(
        onClick = onClick,
        modifier = modifier,
        buttonSize = buttonSize,
        shape = shape,
        enabled = enabled,
        containerTint = containerTint
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            // A disabled control has to look disabled. 0.38 is Material's
            // own disabled-content alpha, so this matches the rest of the app.
            tint = if (enabled) tint else tint.copy(alpha = 0.38f),
            modifier = Modifier.size(iconSize)
        )
    }
}

/**
 * The bare glass pane behind [GlassIconButton], exposed for the cases that
 * need something other than a single icon inside it -- a badge, a count, an
 * icon with a dot on it.
 */
@Composable
fun GlassIconSurface(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    buttonSize: Dp = 40.dp,
    shape: Shape = CircleShape,
    enabled: Boolean = true,
    /**
     * Optional colour laid over the glass container, for buttons that carry an
     * on/off or multi-state meaning and have to stay loud while active. The
     * bloom and shading are drawn over it, so a tinted button still reads as
     * the same pane rather than as a flat coloured square.
     */
    containerTint: Color? = null,
    content: @Composable () -> Unit
) {
    val palette = rememberGlassPalette()
    val isLight = MaterialTheme.colorScheme.background.luminance() > 0.5f

    Box(
        modifier = modifier
            .size(buttonSize)
            .clip(shape)
            .background(palette.container)
            .drawBehind {
                // 0. State tint, under the glass optics.
                containerTint?.let { drawRect(color = it) }

                // 1. Top refraction bloom. Light catches where the pane bends
                // toward it, so the upper half is brighter than the lower.
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(
                                alpha = if (isLight) 0.34f else 0.10f
                            ),
                            Color.Transparent
                        ),
                        startY = 0f,
                        endY = size.height * 0.55f
                    )
                )

                // 2. Bottom thickness shading. The pane's own depth turns
                // light away from the eye along its lower edge.
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.Black.copy(
                                alpha = if (isLight) 0.05f else 0.16f
                            )
                        ),
                        startY = size.height * 0.45f,
                        endY = size.height
                    )
                )
            }
            // The cut edge, brightest on the lit side. borderTop is already
            // theme-aware, so this stays correct in both light and dark.
            .border(1.dp, palette.borderTop, shape)
            // S9: role = Role.Button so TalkBack announces these as buttons,
            // not generic clickable regions. GlassIconButton is used app-wide
            // so one fix here covers every call site.
            .clickable(role = Role.Button, enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}
