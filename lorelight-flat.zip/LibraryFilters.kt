package com.lorelight.ui.library
import com.lorelight.R
import androidx.compose.ui.res.stringResource
import com.lorelight.ui.theme.modeswitch.celestial.CelestialStyle

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.lorelight.ui.theme.GlassDialog
import com.lorelight.ui.theme.getThemedButtonProps

@Composable
fun BookshelfDisplaySettingsDialog(
    showDialog: Boolean,
    bookshelfCoverScale: Float,
    onBookshelfCoverScaleChange: (Float) -> Unit,
    bookshelfRows: Int,
    onBookshelfRowsChange: (Int) -> Unit,
    bookDesignEnabled: Boolean = true,
    onBookDesignChange: (Boolean) -> Unit = {},
    shelfDesignEnabled: Boolean = true,
    onShelfDesignChange: (Boolean) -> Unit = {},
    mixMangaAndNovels: Boolean = false,
    onMixMangaAndNovelsChange: (Boolean) -> Unit = {},
    celestialStyle: CelestialStyle = CelestialStyle.DREAMY,
    onCelestialStyleChange: (CelestialStyle) -> Unit = {},
    onDismissRequest: () -> Unit
) {
    if (!showDialog) return
    Dialog(onDismissRequest = onDismissRequest) {
        GlassDialog(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(androidx.compose.foundation.rememberScrollState())
            ) {
                // ---- Title ----
                Text(
                    text = stringResource(R.string.library_filters_display_settings_title),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    fontFamily = MaterialTheme.typography.headlineLarge.fontFamily,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(Modifier.height(20.dp))

                // ---- Cover image size ----
                Text(
                    text = stringResource(R.string.library_filters_cover_image_size),
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Slider(
                        value = bookshelfCoverScale,
                        onValueChange = onBookshelfCoverScaleChange,
                        valueRange = 0.5f..1.2f,
                        colors = SliderDefaults.colors(
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = "${(bookshelfCoverScale * 100).toInt()}%",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(42.dp),
                        textAlign = TextAlign.End
                    )
                }

                Spacer(Modifier.height(16.dp))

                // ---- Number of rows ----
                Text(
                    text = stringResource(R.string.library_filters_number_of_rows),
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Slider(
                        value = bookshelfRows.toFloat(),
                        onValueChange = { onBookshelfRowsChange(it.toInt().coerceIn(1, 3)) },
                        valueRange = 1f..3f,
                        steps = 1,
                        colors = SliderDefaults.colors(
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = "$bookshelfRows",
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(42.dp),
                        textAlign = TextAlign.End
                    )
                }

                Spacer(Modifier.height(16.dp))

                // ---- 3D book design ----
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "3D book design",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        fontWeight = FontWeight.SemiBold
                    )
                    Switch(
                        checked = bookDesignEnabled,
                        onCheckedChange = onBookDesignChange,
                        colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary)
                    )
                }

                Spacer(Modifier.height(12.dp))

                // ---- Wooden shelf ----
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.library_filters_wooden_shelf),
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        fontWeight = FontWeight.SemiBold
                    )
                    Switch(
                        checked = shelfDesignEnabled,
                        onCheckedChange = onShelfDesignChange,
                        colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary)
                    )
                }

                Spacer(Modifier.height(16.dp))

                // ---- Mix manga and novels ----
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.library_filters_mix_media),
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = stringResource(R.string.library_filters_show_both_shelf),
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                        )
                    }
                    Switch(
                        checked = mixMangaAndNovels,
                        onCheckedChange = onMixMangaAndNovelsChange,
                        colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary)
                    )
                }

                Spacer(Modifier.height(20.dp))

                // ================================================================
                // Celestial character design selector
                // ================================================================
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f),
                    thickness = 1.dp
                )
                Spacer(Modifier.height(16.dp))

                Text(
                    text = "Sun & Moon style",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "Pick a look — finalize later",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.50f)
                )
                Spacer(Modifier.height(10.dp))

                // 5 style cards in a wrapped 2+3 layout
                val styles = CelestialStyle.entries
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Row 1: first two styles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        styles.take(2).forEach { style ->
                            CelestialStyleCard(
                                style = style,
                                selected = style == celestialStyle,
                                onSelect = { onCelestialStyleChange(style) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    // Row 2: remaining three styles
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        styles.drop(2).forEach { style ->
                            CelestialStyleCard(
                                style = style,
                                selected = style == celestialStyle,
                                onSelect = { onCelestialStyleChange(style) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                Spacer(Modifier.height(24.dp))

                // ---- Apply button ----
                val primaryColor = MaterialTheme.colorScheme.primary
                val (isPremiumBtn, btnGrad, btnContent) = getThemedButtonProps(primaryColor, MaterialTheme.colorScheme.background)
                Button(
                    onClick = onDismissRequest,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isPremiumBtn) Color.Transparent else primaryColor,
                        contentColor = btnContent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(
                            if (isPremiumBtn) Modifier.background(btnGrad, RoundedCornerShape(10.dp))
                            else Modifier
                        ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(stringResource(R.string.library_filters_apply_layout), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * A single selectable card for one [CelestialStyle].
 * Shows the style emoji, name, and a one-line description.
 * A primary-coloured border + checkmark highlights the selected state.
 */
@Composable
private fun CelestialStyleCard(
    style: CelestialStyle,
    selected: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    val primary = MaterialTheme.colorScheme.primary
    val surface = MaterialTheme.colorScheme.surface
    val onSurf  = MaterialTheme.colorScheme.onSurface

    val borderColor = if (selected) primary else onSurf.copy(alpha = 0.12f)
    val bgColor     = if (selected) primary.copy(alpha = 0.08f) else surface.copy(alpha = 0.50f)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(bgColor)
            .border(BorderStroke(if (selected) 2.dp else 1.dp, borderColor), RoundedCornerShape(10.dp))
            .clickable(onClick = onSelect)
            .padding(horizontal = 8.dp, vertical = 10.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Emoji badge
            Text(text = style.emoji, fontSize = 22.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(4.dp))
            // Style name
            Text(
                text = style.label,
                fontSize = 12.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.SemiBold,
                color = if (selected) primary else onSurf.copy(alpha = 0.85f),
                textAlign = TextAlign.Center,
                maxLines = 1
            )
            // One-line description
            Text(
                text = style.desc,
                fontSize = 9.sp,
                color = onSurf.copy(alpha = 0.48f),
                textAlign = TextAlign.Center,
                maxLines = 2,
                lineHeight = 12.sp
            )
        }
        // Checkmark badge
        if (selected) {
            Icon(
                imageVector = Icons.Filled.Check,
                contentDescription = null,
                tint = primary,
                modifier = Modifier
                    .size(14.dp)
                    .align(Alignment.TopEnd)
            )
        }
    }
}
