package com.lorelight.manga.util

object MangaSourceGrouping {

    data class Entry(
        val id: Long,
        val pkg: String?,
        val name: String,
        val lang: String
    )

    /**
     * Returns the ids that should remain visible after collapsing
     * multi-language duplicates. Pure - no Android, no Context.
     */
    fun collapseMultiLang(entries: List<Entry>, selectedLangs: Set<String>): Set<Long> {
        val hasAllSelected = selectedLangs.any { it.equals("all", ignoreCase = true) }
        if (!hasAllSelected) {
            return entries.map { it.id }.toSet()
        }

        val grouped = entries.groupBy { Pair(it.pkg ?: "", it.name.trim().lowercase()) }
        val result = mutableSetOf<Long>()

        for ((_, group) in grouped) {
            val allMembers = group.filter { it.lang.equals("all", ignoreCase = true) }
            if (allMembers.isNotEmpty()) {
                val kept = allMembers.minByOrNull { it.id }!!
                result.add(kept.id)
            } else {
                group.forEach { result.add(it.id) }
            }
        }

        return result
    }
}
