package com.lorelight.crawler

import android.content.Context
import android.util.Log
import android.widget.Toast
import com.lorelight.data.download.DownloadItemState
import com.lorelight.data.download.DownloadProgressBus
import com.lorelight.data.download.DownloadStatus
import com.lorelight.data.model.Novel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * BACKGROUND CHAPTER-RANGE DOWNLOADER.
 *
 * WHY THIS EXISTS
 * ---------------
 * "Select chapters" used to run the entire download inside the dialog that
 * started it. The dialog set isProcessing, which both swapped its body for a
 * progress bar AND blocked onDismissRequest, and the download loop itself lived
 * in that composable's rememberCoroutineScope. Those two facts together made the
 * popup unclosable BY DESIGN: it could not be dismissed while working, and
 * dismissing it would have cancelled the very work it was reporting. Ask for 300
 * chapters and you got a screen you could not leave for however long that took.
 *
 * The work belongs to the app, not to a piece of UI. This object owns an
 * application-lifetime scope, so the download outlives the dialog, the details
 * page, and anything else the user navigates away from. It reports exclusively
 * to DownloadProgressBus, which is what the Download queue renders - so the
 * queue is the single place progress is shown, exactly as it is for
 * "Download whole".
 *
 * The dialog is now only a range picker: collect two numbers, call start(),
 * close.
 */
object NovelRangeDownloader {

    private const val TAG = "NovelRangeDownloader"

    /**
     * Pacing, width and retry counts come from DownloadTuning now (Settings ->
     * Storage & downloads -> Download tuning) instead of being fixed here.
     *
     * Only the pause-poll interval stays a constant: it controls how quickly a
     * paused job notices Resume, which is an implementation detail rather than
     * something worth a slider.
     */
    private const val PAUSE_POLL_MS = 400L

    /** The verification sweep waits longer: these hosts already said no once. */
    private const val VERIFY_DELAY_MULTIPLIER = 2L

    /**
     * SupervisorJob: one chapter range blowing up must not take the others with
     * it. This scope is deliberately never cancelled - it is tied to the process,
     * which is the whole point.
     */
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val jobs = ConcurrentHashMap<String, Job>()
    private val pauseFlags = ConcurrentHashMap<String, AtomicBoolean>()

    /** What start() decided to do, so the caller can say something useful. */
    sealed class StartOutcome {
        data class Started(val chapterCount: Int) : StartOutcome()
        object AlreadyRunning : StartOutcome()
        object NothingToDo : StartOutcome()
    }

    private data class Target(
        val number: Int,
        val title: String,
        val url: String
    )

    fun jobIdFor(novel: Novel, startChapter: Int, endChapter: Int): String =
        "novel_${novel.id}_ch${startChapter}_$endChapter"

    fun isRunning(jobId: String): Boolean = jobs[jobId]?.isActive == true

    /**
     * Queues a chapter range and returns immediately. Never blocks, never needs
     * a UI to stay alive.
     */
    fun start(
        context: Context,
        novel: Novel,
        startChapter: Int,
        endChapter: Int
    ): StartOutcome {
        val app = context.applicationContext

        val firstIndex = (startChapter - 1).coerceAtLeast(0)
        val lastIndex = (endChapter - 1).coerceAtMost(novel.chapters.lastIndex)
        if (lastIndex < firstIndex) return StartOutcome.NothingToDo

        val targets = ArrayList<Target>()
        for (i in firstIndex..lastIndex) {
            val url = novel.chapterUrls.getOrNull(i)?.trim().orEmpty()
            if (url.isEmpty()) continue
            targets.add(
                Target(
                    number = i + 1,
                    title = novel.chapters.getOrNull(i) ?: "Chapter ${i + 1}",
                    url = url
                )
            )
        }
        if (targets.isEmpty()) return StartOutcome.NothingToDo

        val jobId = jobIdFor(novel, startChapter, endChapter)
        if (isRunning(jobId)) return StartOutcome.AlreadyRunning

        // Anything already cached starts life DONE, so the queue shows the true
        // amount of work instead of counting chapters we will skip.
        val items = targets.map { t ->
            val cached = CrawlerEngine.isChapterCached(app, t.url)
            DownloadItemState(
                id = t.url,
                name = t.title,
                status = if (cached) DownloadStatus.DONE else DownloadStatus.QUEUED,
                current = if (cached) 1L else 0L,
                total = 1L
            )
        }
        val pending = items.count { it.status != DownloadStatus.DONE }
        if (pending == 0) return StartOutcome.NothingToDo

        DownloadProgressBus.start(
            id = jobId,
            title = "${novel.title} (Ch $startChapter-$endChapter)",
            kind = "Novel",
            total = targets.size,
            novelId = novel.id,
            items = items
        )

        val paused = pauseFlags.getOrPut(jobId) { AtomicBoolean(false) }
        paused.set(false)
        armControllers(app, jobId, targets, paused)
        launchRun(app, jobId, targets, paused)

        return StartOutcome.Started(pending)
    }

    /**
     * Wires the queue's Pause / Cancel / Retry buttons to this job.
     *
     * Re-armed after finish() on purpose: DownloadProgressBus.finish() calls
     * unregisterCanceller(), which drops the pause and retry callbacks too. Without
     * re-arming, tapping Retry on a completed job with failures would flip its
     * items back to QUEUED and then sit there forever, because nothing was left
     * listening.
     */
    private fun armControllers(
        app: Context,
        jobId: String,
        targets: List<Target>,
        paused: AtomicBoolean
    ) {
        DownloadProgressBus.registerPauseController(jobId) { isPaused ->
            paused.set(isPaused)
        }
        DownloadProgressBus.registerCanceller(jobId) {
            jobs.remove(jobId)?.cancel()
        }
        DownloadProgressBus.registerRetryController(jobId) { itemIds ->
            if (isRunning(jobId)) return@registerRetryController
            val retryTargets = if (itemIds.isNullOrEmpty()) {
                targets
            } else {
                targets.filter { itemIds.contains(it.url) }
            }
            if (retryTargets.isNotEmpty()) {
                paused.set(false)
                launchRun(app, jobId, retryTargets, paused)
            }
        }
    }

    private fun launchRun(
        app: Context,
        jobId: String,
        targets: List<Target>,
        paused: AtomicBoolean
    ) {
        if (targets.isEmpty()) return
        val job = scope.launch {
            try {
                runPasses(app, jobId, targets, paused)
            } catch (ce: CancellationException) {
                throw ce
            } catch (e: Exception) {
                Log.e(TAG, "range download failed for $jobId", e)
                DownloadProgressBus.fail(jobId, "Download error: ${e.message ?: e.toString()}")
            }
        }
        jobs[jobId] = job
        job.invokeOnCompletion { jobs.remove(jobId, job) }
    }

    private suspend fun runPasses(
        app: Context,
        jobId: String,
        targets: List<Target>,
        paused: AtomicBoolean
    ) {
        // Taken ONCE per run, for the same reason the manga downloader does it:
        // a slider moved mid-job must not reshape work already in flight.
        val tuning = com.lorelight.data.download.DownloadTuning.snapshot(app)

        // Wi-Fi only is enforced here rather than in start() so the reason lands
        // in the download queue, where the user is already looking, instead of
        // needing a new StartOutcome that every caller would have to handle.
        val blockedReason = com.lorelight.data.download.DownloadTuning.blockedReason(app, tuning)
        if (blockedReason != null) {
            DownloadProgressBus.fail(jobId, blockedReason)
            return
        }

        // FIRST PASS: fetch everything that isn't already on disk.
        runPass(
            app = app,
            jobId = jobId,
            targets = targets,
            paused = paused,
            tuning = tuning,
            gapMs = tuning.chapterDelayMs,
            markCachedDone = true,
            failLabel = "Failed to download chapter"
        )

        // SECOND PASS: one slower sweep over whatever is still missing. Flaky
        // sources routinely hand back a block page on the first ask and the real
        // chapter thirty seconds later. Optional now, because on a healthy source
        // it is pure overhead.
        if (tuning.verifyPass) {
            runPass(
                app = app,
                jobId = jobId,
                targets = targets,
                paused = paused,
                tuning = tuning,
                gapMs = tuning.chapterDelayMs * VERIFY_DELAY_MULTIPLIER,
                markCachedDone = false,
                failLabel = "Retry failed"
            )
        }

        if (DownloadProgressBus.isCancelled(jobId)) return

        // Count what is genuinely on disk rather than what we think we did.
        val cached = targets.count { CrawlerEngine.isChapterCached(app, it.url) }
        val total = targets.size
        val missing = total - cached

        com.lorelight.tts.TtsPlaybackManager.recomputeCachedChapters()

        val summary = if (missing <= 0) {
            "Downloaded all $total chapters."
        } else {
            "Downloaded $cached of $total. $missing couldn't be fetched."
        }
        DownloadProgressBus.finish(jobId, summary)
        armControllers(app, jobId, targets, paused)

        withContext(Dispatchers.Main) {
            Toast.makeText(app, summary, Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * One sweep over [targets], fetching up to tuning.parallelChapters at a time.
     *
     * A novel chapter is a single request, so width is what actually shortens a
     * 300 chapter job: while one chapter waits on the server, others are already
     * asking. Both passes share this, differing only in their gap and in whether
     * an already-cached chapter is reported as finished.
     */
    private suspend fun runPass(
        app: Context,
        jobId: String,
        targets: List<Target>,
        paused: AtomicBoolean,
        tuning: com.lorelight.data.download.DownloadTuning.Snapshot,
        gapMs: Long,
        markCachedDone: Boolean,
        failLabel: String
    ) {
        val gate = kotlinx.coroutines.sync.Semaphore(tuning.parallelChapters)
        val stopped = AtomicBoolean(false)

        kotlinx.coroutines.coroutineScope {
            val chapterJobs = targets.map { t ->
                launch {
                    gate.acquire()
                    try {
                        if (stopped.get()) return@launch
                        if (!awaitResume(jobId, paused)) {
                            stopped.set(true)
                            return@launch
                        }
                        if (CrawlerEngine.isChapterCached(app, t.url)) {
                            if (markCachedDone) DownloadProgressBus.finishItem(jobId, t.url)
                            return@launch
                        }
                        DownloadProgressBus.startItem(jobId, t.url)
                        if (fetchWithRetry(app, t.url, tuning.retryAttempts)) {
                            DownloadProgressBus.finishItem(jobId, t.url)
                        } else {
                            DownloadProgressBus.failItem(jobId, t.url, failLabel)
                        }
                        // Held inside the permit so the gap actually paces the
                        // source instead of being skipped by the next chapter.
                        if (gapMs > 0L) delay(gapMs)
                    } finally {
                        gate.release()
                    }
                }
            }
            chapterJobs.forEach { it.join() }
        }
    }

    /**
     * Blocks while the queue has this job paused. Returns false if the job was
     * cancelled, which is the caller's signal to stop.
     */
    private suspend fun awaitResume(jobId: String, paused: AtomicBoolean): Boolean {
        while (paused.get()) {
            if (DownloadProgressBus.isCancelled(jobId)) return false
            delay(PAUSE_POLL_MS)
        }
        return !DownloadProgressBus.isCancelled(jobId)
    }

    /**
     * [attempts] tries with a widening backoff. A chapter only counts as fetched
     * when it is actually in the cache: a non-blank body that the engine flags as
     * a failure page must not be mistaken for success.
     */
    private suspend fun fetchWithRetry(app: Context, url: String, attempts: Int): Boolean {
        if (CrawlerEngine.isChapterCached(app, url)) return true
        var attempt = 0
        while (attempt < attempts) {
            try {
                val text = CrawlerEngine.extractChapterText(app, url)
                if (text.isNotBlank() &&
                    !CrawlerEngine.isFailureText(text) &&
                    CrawlerEngine.isChapterCached(app, url)
                ) {
                    return true
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (e: Exception) {
                Log.e(TAG, "chapter fetch failed (try ${attempt + 1})", e)
            }
            attempt++
            delay(1_500L * attempt)
        }
        return false
    }
}
