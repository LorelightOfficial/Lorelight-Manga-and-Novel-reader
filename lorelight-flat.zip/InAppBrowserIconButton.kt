package com.lorelight.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// One travelling arc plus a faint trailing arc orbit the globe, and the
// globe itself breathes. Nothing here is a bitmap or a Lottie file - it is
// two drawArc calls and a graphicsLayer, so the loop costs almost nothing.
private const val ORBIT_MS = 3600
private const val BREATH_MS = 2400
private const val HEAD_ARC_DEG = 66f
private const val TAIL_ARC_DEG = 30f
private const val TAIL_OFFSET_DEG = 186f
private const val RING_ALPHA = 0.55f
private const val RING_STROKE_DP = 1.5f

/**
 * The in-app browser action, shown as its own button rather than hidden
 * inside an overflow menu. The looping orbit marks it as a live action and
 * makes it easy to find in a dense source row.
 *
 * All colour comes from the caller or from the theme, so it follows light
 * and dark mode with no hardcoded values.
 */
@Composable
fun InAppBrowserIconButton(
	onClick: () -> Unit,
	modifier: Modifier = Modifier,
	buttonSize: Dp = 48.dp,
	iconSize: Dp = 24.dp,
	ringSize: Dp = 34.dp,
	tint: Color = MaterialTheme.colorScheme.primary,
	contentDescription: String = "Open website in app"
) {
	// The orbit/breath loop never ends by design, which is exactly what the
	// shared motion policy calls out as the first thing to drop under
	// Reduced/Battery saver. Freeze both at a calm resting frame instead of
	// inventing a separate on/off switch for this one icon.
	val motionLevel = com.lorelight.ui.theme.LocalMotionLevel.current
	val loop = rememberInfiniteTransition(label = "browserIconLoop")
	val orbit by if (motionLevel.allowsLoopingAnimation) {
		loop.animateFloat(
			initialValue = 0f,
			targetValue = 360f,
			animationSpec = infiniteRepeatable(
				animation = tween(durationMillis = ORBIT_MS, easing = LinearEasing),
				repeatMode = RepeatMode.Restart
			),
			label = "browserIconOrbit"
		)
	} else {
		remember { mutableStateOf(0f) }
	}
	val breath by if (motionLevel.allowsLoopingAnimation) {
		loop.animateFloat(
			initialValue = 0f,
			targetValue = 1f,
			animationSpec = infiniteRepeatable(
				animation = tween(durationMillis = BREATH_MS, easing = FastOutSlowInEasing),
				repeatMode = RepeatMode.Reverse
			),
			label = "browserIconBreath"
		)
	} else {
		remember { mutableStateOf(0.5f) }
	}

	// Hoisted so the draw pass allocates nothing per frame. Offset and Size
	// are value classes, so those two stay off the heap on their own.
	val density = LocalDensity.current
	val ringStroke = remember(density) {
		Stroke(
			width = with(density) { RING_STROKE_DP.dp.toPx() },
			cap = StrokeCap.Round
		)
	}

	IconButton(onClick = onClick, modifier = modifier.size(buttonSize)) {
		Box(contentAlignment = Alignment.Center) {
			Canvas(modifier = Modifier.size(ringSize)) {
				val inset = ringStroke.width / 2f
				val topLeft = Offset(inset, inset)
				val arcSize = Size(
					size.width - inset * 2f,
					size.height - inset * 2f
				)
				val pulse = 0.45f + 0.55f * breath
				drawArc(
					color = tint,
					startAngle = orbit,
					sweepAngle = HEAD_ARC_DEG,
					useCenter = false,
					topLeft = topLeft,
					size = arcSize,
					alpha = RING_ALPHA * pulse,
					style = ringStroke
				)
				drawArc(
					color = tint,
					startAngle = orbit + TAIL_OFFSET_DEG,
					sweepAngle = TAIL_ARC_DEG,
					useCenter = false,
					topLeft = topLeft,
					size = arcSize,
					alpha = RING_ALPHA * 0.45f * pulse,
					style = ringStroke
				)
			}
			Icon(
				Icons.Filled.Public,
				contentDescription = contentDescription,
				tint = tint,
				modifier = Modifier
					.size(iconSize)
					.graphicsLayer {
						val scale = 0.94f + 0.06f * breath
						scaleX = scale
						scaleY = scale
						alpha = 0.82f + 0.18f * breath
					}
			)
		}
	}
}
