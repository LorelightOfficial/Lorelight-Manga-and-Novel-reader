package com.lorelight.manga.repo

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray

/**
 * Per-repository on/off switches for the manga extension repos, plus the
 * one-time seeding of the default Keiyoushi repository.
 *
 * The repo list itself lives in Mihon's `extension_store` SQLDelight table.
 * Rather than migrate that schema just to carry one boolean - a migration is a
 * one-way door on a table users already have rows in - the enabled state is
 * kept alongside it in SharedPreferences and applied as a filter at the point
 * where extensions are fetched. A disabled repo therefore stays in the list,
 * keeps its name, badge and contact links, and simply contributes no extensions
 * until it is switched back on.
 *
 * [init] must be called once from Application.onCreate, because the repository
 * layer that reads these flags is built by Injekt without a Context.
 */
object MangaRepoToggles {
    private const val PREFS = "lorelight_manga_repos"
    private const val KEY_DISABLED = "disabled_repo_urls"
    private const val KEY_SEEDED = "seeded_default_repos_v1"

    /** Keiyoushi's protobuf index - the compact format Mihon prefers. */
    const val KEIYOUSHI_PB =
        "https://raw.githubusercontent.com/keiyoushi/extensions/repo/index.min.pb"

    /** The same repo in the older JSON form, used only if the .pb index fails. */
    const val KEIYOUSHI_JSON =
        "https://raw.githubusercontent.com/keiyoushi/extensions/repo/index.min.json"

    @Volatile
    private var appContext: Context? = null

    /**
     * Bumped on every toggle so Compose screens can recompose and the extension
     * list can be refetched without polling SharedPreferences.
     */
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    private fun prefs(context: Context? = appContext) =
        context?.applicationContext?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun disabledUrls(): Set<String> {
        val raw = prefs()?.getString(KEY_DISABLED, null) ?: return emptySet()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length())
                .map { arr.optString(it) }
                .filter { it.isNotBlank() }
                .toSet()
        } catch (e: Exception) {
            emptySet()
        }
    }

    /**
     * Unknown repos default to enabled, so adding a repo switches it on without
     * needing a write, and a failure to read prefs can never silently disable
     * everything.
     */
    fun isEnabled(indexUrl: String): Boolean = !disabledUrls().contains(indexUrl)

    fun setEnabled(indexUrl: String, enabled: Boolean) {
        val p = prefs() ?: return
        val next = disabledUrls().toMutableSet()
        if (enabled) next.remove(indexUrl) else next.add(indexUrl)
        val arr = JSONArray()
        next.forEach { arr.put(it) }
        p.edit().putString(KEY_DISABLED, arr.toString()).apply()
        _version.value = _version.value + 1
    }

    fun hasSeededDefaults(context: Context): Boolean =
        prefs(context)?.getBoolean(KEY_SEEDED, false) ?: false

    fun markDefaultsSeeded(context: Context) {
        prefs(context)?.edit()?.putBoolean(KEY_SEEDED, true)?.apply()
    }
}
