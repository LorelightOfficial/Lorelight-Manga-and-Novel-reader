package com.lorelight.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface NovelDao {
    @Query("SELECT * FROM novels")
    fun getAll(): List<NovelEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsertAll(novels: List<NovelEntity>)

    @Query("SELECT id FROM novels")
    fun allIds(): List<String>

    @Query("DELETE FROM novels WHERE id IN (:ids)")
    fun deleteByIds(ids: List<String>)

    /** See HistoryDao.deleteAllExcept - same SQLite variable-limit fix. */
    fun deleteAllExcept(ids: List<String>) {
        val keep = ids.toHashSet()
        val doomed = allIds().filter { it !in keep }
        doomed.chunked(500).forEach { deleteByIds(it) }
    }

    @Query("DELETE FROM novels")
    fun deleteAll()

    @Query("SELECT COUNT(*) FROM novels")
    fun count(): Int

    /**
     * FIX D1: ADDITIVE write. Upserts every incoming row and deletes NOTHING.
     *
     * replaceAll() below finishes with deleteAllExcept(), so ANY caller holding a
     * list that is merely incomplete - not wrong, just stale - silently deletes
     * every novel missing from it. That is how newly added novels vanished after
     * a background/foreground cycle. Routine saves must use this; replaceAll() is
     * reserved for the deliberate delete/replace flows.
     */
    @Query("SELECT dateModified FROM novels WHERE id = :id")
    fun modifiedAt(id: String): Long?

    @Transaction
    fun mergeAll(novels: List<NovelEntity>) {
        if (novels.isEmpty()) return
        // LIBRARY-RESET FIX: the library jumping back to an earlier point every
        // time the app is closed.
        //
        // FIX D1 stopped mergeAll from DELETING rows, but it still upserted with
        // REPLACE, so a merely stale list still overwrote good data field by
        // field. The ON_STOP save writes the Compose library list, which was
        // built when the screen was first composed. Anything a background worker
        // wrote after that - new chapter counts, downloads, imports - was
        // silently rolled back to the launch-time values on every single
        // backgrounding. Devices that kill and restart the process aggressively,
        // like OxygenOS and ColorOS, hit this constantly, which is why it looked
        // device-specific rather than universal.
        //
        // Skip rows the database already holds a NEWER copy of. Using >= keeps
        // the previous behaviour whenever the timestamps match, so a save that
        // genuinely needs to land is never dropped.
        val fresh = novels.filter { incoming ->
            val stored = modifiedAt(incoming.id) ?: return@filter true
            incoming.dateModified >= stored
        }
        if (fresh.isEmpty()) return
        fresh.chunked(500).forEach { upsertAll(it) }
    }

    @Transaction
    fun replaceAll(novels: List<NovelEntity>) {
        // SAFETY: an empty list is treated as "no data to write", never as
        // "delete the user's entire library". Explicit wipes must call
        // replaceAllAllowEmpty() or deleteAll() directly.
        if (novels.isEmpty()) return
        novels.chunked(500).forEach { upsertAll(it) }
        deleteAllExcept(novels.map { it.id })
    }

    @Transaction
    fun replaceAllAllowEmpty(novels: List<NovelEntity>) {
        if (novels.isEmpty()) {
            deleteAll()
        } else {
            novels.chunked(500).forEach { upsertAll(it) }
            deleteAllExcept(novels.map { it.id })
        }
    }
}
