/*
 * =============================================================================
 * CompanionPolicy.kt - every number that decides HOW OFTEN he speaks.
 * Package: com.lorelight.companion
 *
 * All of it lives here, named, in one file. Nothing about frequency is
 * hardcoded anywhere else in the companion, because the single hardest thing
 * to get right about a character like this is not what he says - it is how
 * often. Too rare and he is forgettable; one line too many and he is
 * annoying, and annoying is unforgivable in something that cannot be turned
 * off from the screen it appears on.
 *
 * SO: tune this file, live with it for three evenings, tune it again.
 *
 * The DEBUG_CHATTINESS multiplier exists for exactly that. Set it to 8f and
 * an evening of testing takes ten minutes. It must ship as 1f.
 *
 * TWO GLOBAL LAWS, both enforced in CompanionGovernor:
 *
 *   DAILY_CAP          he never speaks more than this many times a day.
 *   GLOBAL_COOLDOWN_MS after any line, total silence for this long.
 *
 * Those two alone do most of the work. Everything below only decides which
 * line wins the rare moment when speaking is allowed at all.
 * =============================================================================
 */
package com.lorelight.companion

object CompanionPolicy {

    /* --- the hidden test dial --------------------------------------------- */

    /**
     * Multiplies every chance and divides every cooldown.
     *
     * 1f  = shipping behaviour.
     * 8f  = a whole day of chatter compressed into a short test session.
     *
     * MUST be 1f in a release build.
     */
    const val DEBUG_CHATTINESS = 1f

    /* --- the two global laws ---------------------------------------------- */

    /** Hard ceiling on lines spoken in one calendar day. */
    const val DAILY_CAP = 40

    /** Silence after any spoken line, regardless of what happens. 45 s. */
    const val GLOBAL_COOLDOWN_MS = 45_000L

    /* --- arrival ---------------------------------------------------------- */

    /**
     * He does not speak the instant the app opens. The user came here to
     * read, not to be greeted, so he waits until the screen has settled.
     */
    const val ARRIVAL_DELAY_MS = 3_500L

    /**
     * Even a greeting is not guaranteed - a companion who greets you every
     * single launch is a notification. The very first launch ever is the
     * exception and is always taken (see FIRST_EVER below).
     */
    const val ARRIVAL_CHANCE = 0.90f

    /**
     * Arrival is capped once per DAY, not once per session. Bouncing in and
     * out of the app all evening must not produce a greeting each time.
     */
    const val ARRIVAL_ONCE_PER_DAY = true

    /* --- what counts as a new session ------------------------------------ */

    /**
     * Gap after which returning counts as a fresh session. Without this
     * constant "once per session" cannot be implemented at all, because a
     * session has no other boundary - the process can be killed and restored
     * at any moment by the system.
     */
    const val SESSION_GAP_MS = 1_800_000L   // 30 min

    /* --- ambient --------------------------------------------------------- */

    /** How long the app must be quiet before an ambient musing is allowed. */
    const val AMBIENT_SILENCE_MS = 1_800_000L   // 30 min

    /** And even then, usually he just stays quiet. */
    const val AMBIENT_CHANCE = 0.25f

    /* --- the stillness gate ---------------------------------------------- */

    /**
     * He never speaks over a moving screen. A bubble that appears mid-scroll
     * is unreadable and feels like an interruption, so a granted line waits
     * for the list to be still.
     */
    const val STILLNESS_MS = 1_200L

    /**
     * How long a granted line waits for that stillness before it is thrown
     * away. It is NOT re-rolled and NOT queued - if the user was busy, the
     * moment has simply passed.
     */
    const val STILLNESS_RETRY_WINDOW_MS = 30_000L

    /* --- the theme toggle ------------------------------------------------ */

    /**
     * He comments on a theme switch only sometimes. Once per day would still
     * be a predictable pattern the user learns; a flat 30% never resolves
     * into a rule.
     */
    const val MODE_SWITCH_CHANCE = 0.75f

    /* --- time of day ----------------------------------------------------- */

    const val LATE_NIGHT_START_H = 0
    const val LATE_NIGHT_END_H = 4
    const val EARLY_MORNING_START_H = 4
    const val EARLY_MORNING_END_H = 7

    /* --- library size milestones ----------------------------------------- */

    /** Each crossed once, ever. Passing 25 books is only a moment one time. */
    val LIBRARY_MILESTONES = intArrayOf(25, 50, 100, 200)

    /* --- streaks --------------------------------------------------------- */

    const val STREAK_MIN_DAYS = 3

    /* --- long session ---------------------------------------------------- */

    const val LONG_SESSION_MS = 5_400_000L   // 90 min

    /* --- unfinished books ------------------------------------------------ */

    const val UNFINISHED_MIN_PROGRESS = 0.20f
    const val UNFINISHED_MAX_PROGRESS = 0.80f
    const val UNFINISHED_MIN_IDLE_DAYS = 7
    const val UNFINISHED_PER_TITLE_COOLDOWN_DAYS = 3

    /* --- how far back "you were away" bands reach ------------------------ */

    const val AWAY_SAME_DAY_MAX_H = 5L
    const val AWAY_WEEK_MIN_DAYS = 5L
    const val AWAY_AGES_MIN_DAYS = 21L

    /* =====================================================================
     * PER-EVENT RULES
     *
     * chance      probability the event speaks when it wins its moment.
     * cooldownMs  silence for this event specifically, on top of the global
     *             cooldown.
     * oncePerDay  at most one of these per calendar day.
     * browseOnly  only ever spoken on a browse/library surface, never while
     *             the user is actually reading a page.
     * ===================================================================*/

    class Rule(
        val chance: Float,
        val cooldownMs: Long = 0L,
        val oncePerDay: Boolean = false,
        val browseOnly: Boolean = false
    )

    private val rules: Map<CompanionEvent, Rule> = mapOf(
        // Arrival. Always taken the first time ever - that one moment is the
        // whole introduction, and rolling dice on it would be absurd.
        CompanionEvent.FIRST_EVER to Rule(chance = 1f, oncePerDay = false),
        CompanionEvent.BACK_AFTER_AGES to Rule(ARRIVAL_CHANCE, oncePerDay = ARRIVAL_ONCE_PER_DAY),
        CompanionEvent.BACK_AFTER_WEEK to Rule(ARRIVAL_CHANCE, oncePerDay = ARRIVAL_ONCE_PER_DAY),
        CompanionEvent.BACK_AFTER_DAY to Rule(ARRIVAL_CHANCE, oncePerDay = ARRIVAL_ONCE_PER_DAY),
        CompanionEvent.BACK_SAME_DAY to Rule(ARRIVAL_CHANCE, oncePerDay = ARRIVAL_ONCE_PER_DAY),

        // Milestones.
        CompanionEvent.CHAPTER_DONE to Rule(chance = 1f, cooldownMs = 120_000L),
        CompanionEvent.MODE_SWITCHED to Rule(chance = MODE_SWITCH_CHANCE),
        CompanionEvent.STREAK to Rule(chance = 0.80f, oncePerDay = true),
        CompanionEvent.NOVEL_ADDED to Rule(chance = 1f, cooldownMs = 20_000L),
        CompanionEvent.MANGA_ADDED to Rule(chance = 1f, cooldownMs = 20_000L),

        // Ambient.
        CompanionEvent.LONG_SESSION to Rule(chance = 0.70f, oncePerDay = true),
        CompanionEvent.UNFINISHED_WAITING to Rule(
            chance = 0.40f,
            oncePerDay = true,
            browseOnly = true
        ),
        CompanionEvent.LIBRARY_GROWING to Rule(chance = 0.60f),
        CompanionEvent.LATE_NIGHT to Rule(chance = 0.50f, cooldownMs = 14_400_000L),
        CompanionEvent.EARLY_MORNING to Rule(chance = 0.50f, cooldownMs = 14_400_000L),
        CompanionEvent.IDLE_MUSING to Rule(chance = AMBIENT_CHANCE)
    )

    fun ruleFor(event: CompanionEvent): Rule = rules[event] ?: Rule(chance = 0.5f)

    /** Chance with the debug dial applied, clamped to a real probability. */
    fun effectiveChance(event: CompanionEvent): Float =
        (ruleFor(event).chance * DEBUG_CHATTINESS).coerceIn(0f, 1f)

    /** Cooldown with the debug dial applied. */
    fun effectiveCooldown(event: CompanionEvent): Long =
        if (DEBUG_CHATTINESS <= 0f) ruleFor(event).cooldownMs
        else (ruleFor(event).cooldownMs / DEBUG_CHATTINESS).toLong()

    val effectiveGlobalCooldown: Long
        get() = if (DEBUG_CHATTINESS <= 0f) GLOBAL_COOLDOWN_MS
        else (GLOBAL_COOLDOWN_MS / DEBUG_CHATTINESS).toLong()

    val effectiveDailyCap: Int
        get() = (DAILY_CAP * DEBUG_CHATTINESS).toInt().coerceAtLeast(1)
}
