package com.lorelight.ui.library

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import coil.request.ImageRequest
import com.lorelight.data.model.Novel
import com.lorelight.ui.components.LibraryCoverImage
import com.lorelight.ui.components.NovelCoverImage
import kotlin.math.abs
import kotlin.random.Random
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext


// ── Physical-book palette ───────────────────────────────────────────────
private val PaperHi   = Color(0xFFF6F3EA)   // brightest paper (catches light)
private val PaperMid  = Color(0xFFE9E3D2)
private val PaperLo   = Color(0xFFBDB49C)   // shadowed paper
private val AgedHi    = Color(0xFFEADFBB)   // old, yellowed paper
private val AgedMid   = Color(0xFFD8C89A)
private val AgedLo    = Color(0xFF9F8E64)
private val GoldLine  = Color(0xFFCBA65B)   // single restrained gold fillet

// -- Sci-fi palette (Hologram / Data Core) --------------------------------

// ── Shared shelf geometry (BookGrid.kt uses these — do not make private) ──
val ShelfPlankHeight = 14.dp // total plank height
val ShelfTopFaceHeight = 4.dp // lit top surface the books stand on

// ── Book design styles (multi-select, persisted as "bookshelf_book_design_styles") ──
const val BOOK_DESIGN_MODERN = 0  // Clean matte hardcover, crisp white pages
const val BOOK_DESIGN_ANCIENT = 1 // Aged yellowed page edges, tooled gold frame

val ALL_BOOK_DESIGNS = setOf(BOOK_DESIGN_MODERN, BOOK_DESIGN_ANCIENT)

/**
 * Deterministically picks one of the enabled designs for a given novel, so
 * the same book always wears the same design but a shelf full of books mixes
 * all enabled designs — like a real library.
 */
fun designForNovel(novelId: String, enabledDesigns: Set<Int>): Int {
    val pool = enabledDesigns.intersect(ALL_BOOK_DESIGNS).sorted()
    if (pool.isEmpty()) return BOOK_DESIGN_MODERN
    if (pool.size == 1) return pool.first()
    return pool[abs(novelId.hashCode()) % pool.size]
}

/**
 * Averages the cover image down to an 8x8 thumbnail and returns the mean
 * color — used to derive believable page-edge and cover tints.
 */
private val coverAverageColorCache = java.util.concurrent.ConcurrentHashMap<String, Color>()

/**
 * Clears the cached average cover colours. Paired with clearBase64ImageCache()
 * so MemoryManager can drop both together.
 */
fun clearCoverAverageColorCache() {
    coverAverageColorCache.clear()
}

@Composable
private fun rememberCoverAverageColor(coverBase64: String?): Color {
    val context = androidx.compose.ui.platform.LocalContext.current
    // Seed straight from the process cache. Without this every book that
    // scrolls back into view snaps to the fallback grey and only pops to its
    // real colour once the IO round trip finishes -- a visible flicker on a
    // fast shelf scroll.
    val avgColorState = remember(coverBase64) {
        mutableStateOf(
            coverBase64?.let { coverAverageColorCache[it] } ?: Color(0xFF3A3A40)
        )
    }

    LaunchedEffect(coverBase64) {
        if (coverBase64.isNullOrEmpty()) return@LaunchedEffect
        val hit = coverAverageColorCache[coverBase64]
        if (hit != null) {
            avgColorState.value = hit
            return@LaunchedEffect
        }
        withContext(Dispatchers.IO) {
            var resolvedColor = Color(0xFF3A3A40)
            try {
                if (!coverBase64.isNullOrEmpty()) {
                    val bmp: Bitmap? = if (coverBase64.startsWith("http://") || coverBase64.startsWith("https://")) {
                        // Share the app's cover loader instead of building a
                        // throwaway ImageLoader per book. A fresh ImageLoader
                        // carries its own memory cache, disk cache and OkHttp
                        // client, so every shelf item re-downloaded a cover the
                        // grid had already fetched -- and threw the bytes away
                        // the moment this coroutine ended.
                        val loader = com.lorelight.manga.reader.MangaImageLoaderProvider
                            .getCoverImageLoader(context)
                        val req = ImageRequest.Builder(context)
                            .data(coverBase64)
                            .allowHardware(false)
                            .size(24)
                            .build()
                        (loader.execute(req).drawable as? android.graphics.drawable.BitmapDrawable)?.bitmap
                    } else {
                        val decodedBytes = Base64.decode(coverBase64, Base64.DEFAULT)
                        // Downsample during decode. The old path decoded the
                        // full-size cover purely to average it down to a
                        // single colour: megabytes of garbage per book, per
                        // scroll pass, which is what turned a shelf scroll
                        // into a GC storm while TTS was running.
                        val opts = BitmapFactory.Options().apply { inSampleSize = 8 }
                        BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size, opts)
                    }

                    if (bmp != null) {
                        val scaled = Bitmap.createScaledBitmap(bmp, 8, 8, true)
                        val pixelCount = scaled.width * scaled.height
                        if (pixelCount > 0) {
                            val pixels = IntArray(pixelCount)
                            scaled.getPixels(pixels, 0, scaled.width, 0, 0, scaled.width, scaled.height)
                            var sumR = 0L; var sumG = 0L; var sumB = 0L
                            for (colorVal in pixels) {
                                sumR += android.graphics.Color.red(colorVal)
                                sumG += android.graphics.Color.green(colorVal)
                                sumB += android.graphics.Color.blue(colorVal)
                            }
                            resolvedColor = Color(
                                (sumR / pixelCount).toInt(),
                                (sumG / pixelCount).toInt(),
                                (sumB / pixelCount).toInt()
                            )
                        }
                        if (scaled != bmp) scaled.recycle()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            if (coverAverageColorCache.size > 600) coverAverageColorCache.clear()
            coverAverageColorCache[coverBase64] = resolvedColor
            avgColorState.value = resolvedColor
        }
    }
    return avgColorState.value
}

/**
 * A single library book rendered as a slim, realistic 3D volume.
 * The design is picked deterministically per book from the set of designs
 * enabled in the Bookshelf Display Settings dialog, so the shelf naturally
 * mixes different bindings like a real library.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Book3DItem(
    novel: Novel,
    isSelected: Boolean,
    isManageMode: Boolean = false,
    modifier: Modifier = Modifier,
    enabledDesigns: Set<Int> = ALL_BOOK_DESIGNS,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    val importingIds by com.lorelight.service.NovelImportManager.importing.collectAsState()
    val isImporting = importingIds.contains(novel.id) || novel.status == "Importing"
    val alphaAnim by animateFloatAsState(
        targetValue = if (isImporting) 1f else 0f,
        animationSpec = tween(durationMillis = 400),
        label = "importAlpha3D"
    )

    val avgColor = rememberCoverAverageColor(novel.coverImageBase64)
    val designStyle = remember(novel.id, enabledDesigns) { designForNovel(novel.id, enabledDesigns) }

    Box(
        modifier = modifier
            .aspectRatio(0.72f)
            .combinedClickable(onLongClick = onLongClick, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        val cover: @Composable (Modifier) -> Unit = { m ->
            LibraryCoverImage(
                novel = novel,
                modifier = m
            )
        }

        when (designStyle) {
            BOOK_DESIGN_ANCIENT -> AncientBook(avgColor = avgColor, cover = cover)
            else -> ModernBook(avgColor = avgColor, cover = cover)
        }

        // ── Selection ring in manage mode ──
        if (isSelected && isManageMode) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
            )
        }

        // ── Import progress overlay ──
        if (alphaAnim > 0f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.45f * alphaAnim)),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        // ── Manage-mode overlay + checkbox ──
        if (isManageMode) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) Color.Black.copy(alpha = 0.3f) else Color.Transparent)
            )
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.5f))
                    .border(
                        1.5.dp,
                        if (isSelected) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Filled.Check,
                        contentDescription = "Selected",
                        tint = MaterialTheme.colorScheme.background,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}

/**
 * Live 3D preview of a book design, used by the Bookshelf Display Settings
 * dialog. Renders the REAL design composables with a themed placeholder
 * cover, so the preview is exactly what the library will draw.
 */
@Composable
fun Book3DDesignPreview(designStyle: Int, modifier: Modifier = Modifier) {
    val primary = MaterialTheme.colorScheme.primary
    val avg = lerp(primary, Color(0xFF34303C), 0.45f)

    val fakeCover: @Composable (Modifier) -> Unit = { m ->
        Box(
            modifier = m.background(
                Brush.verticalGradient(
                    colors = listOf(
                        lerp(primary, Color.White, 0.20f),
                        lerp(primary, Color.Black, 0.15f),
                        lerp(primary, Color.Black, 0.55f)
                    )
                )
            )
        ) {
            // Faux title / author bars so the preview reads as a real cover
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val bar = Color.White.copy(alpha = 0.85f)
                drawRoundRect(
                    color = bar,
                    topLeft = Offset(w * 0.16f, h * 0.16f),
                    size = Size(w * 0.68f, h * 0.055f),
                    cornerRadius = CornerRadius(4f)
                )
                drawRoundRect(
                    color = bar.copy(alpha = 0.6f),
                    topLeft = Offset(w * 0.26f, h * 0.26f),
                    size = Size(w * 0.48f, h * 0.04f),
                    cornerRadius = CornerRadius(4f)
                )
                drawRoundRect(
                    color = bar.copy(alpha = 0.4f),
                    topLeft = Offset(w * 0.30f, h * 0.82f),
                    size = Size(w * 0.40f, h * 0.035f),
                    cornerRadius = CornerRadius(4f)
                )
            }
        }
    }

    Box(
        modifier = modifier.aspectRatio(0.72f),
        contentAlignment = Alignment.Center
    ) {
        when (designStyle) {
            BOOK_DESIGN_ANCIENT -> AncientBook(avgColor = avg, cover = fakeCover)
            else -> ModernBook(avgColor = avg, cover = fakeCover)
        }
    }
}

// ═════════════════════════════════════════════════════════════════════════
// SHARED SCAFFOLD
// All three designs share the same slim, believable book geometry:
// a narrow spine on the left, the cover front-and-center, and a thin
// page block on the right. A gentle Y rotation with a long camera
// distance keeps the perspective subtle — no fisheye bulk.
// ═════════════════════════════════════════════════════════════════════════
@Composable
private fun BookScaffold(
    spineW: Float,
    pagesW: Float,
    lean: Float,
    cornerRadius: androidx.compose.ui.unit.Dp,
    shadowAlpha: Float,
    modifier: Modifier = Modifier,
    drawBody: androidx.compose.ui.graphics.drawscope.DrawScope.(spinePx: Float, pagesPx: Float) -> Unit,
    coverOverlay: androidx.compose.ui.graphics.drawscope.DrawScope.() -> Unit,
    cover: @Composable (Modifier) -> Unit
) {
    val coverW = 1f - spineW - pagesW

    BoxWithConstraints(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val wDp = maxWidth

        // Tight contact shadow where the book meets the shelf
        Canvas(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = 3.dp)
                .fillMaxWidth(0.92f)
                .height(8.dp)
        ) {
            drawOval(
                brush = Brush.radialGradient(
                    0.0f to Color.Black.copy(alpha = shadowAlpha),
                    0.55f to Color.Black.copy(alpha = shadowAlpha * 0.4f),
                    1.0f to Color.Transparent,
                    center = Offset(size.width / 2f, size.height / 2f),
                    radius = (size.width / 2f).coerceAtLeast(1f)
                ),
                size = size
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    rotationY = lean
                    cameraDistance = 2400f // long lens = subtle, non-bulky perspective
                    transformOrigin = TransformOrigin(0.3f, 0.5f)
                }
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(
                        RoundedCornerShape(
                            topStart = cornerRadius, bottomStart = cornerRadius,
                            topEnd = 1.5.dp, bottomEnd = 1.5.dp
                        )
                    )
            ) {
                // Spine + page block (design-specific)
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawBody(size.width * spineW, size.width * pagesW)
                }

                // Front cover board
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .offset(x = wDp * spineW)
                        .fillMaxWidth(coverW)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(topEnd = 1.5.dp, bottomEnd = 1.5.dp))
                ) {
                    cover(Modifier.fillMaxSize())
                    Canvas(modifier = Modifier.fillMaxSize()) { coverOverlay() }
                }
            }
        }
    }
}

// Shared: lit board edge + soft base shadow drawn over the cover art.
//
// STRIP REMOVAL. This used to paint a dark "hinge valley" across the first 12%
// of every cover so it read as a groove lying beside the spine. With the spine
// gone that gradient was nothing but a black band down the left of the artwork
// -- the strip that had to go. What replaces it is the opposite: a narrow LIT
// roll where the cover board turns, so the edge still has real thickness
// without any darkness sitting on top of the art.
private fun androidx.compose.ui.graphics.drawscope.DrawScope.commonCoverShading(
    hingeAlpha: Float = 0.30f
) {
    val w = size.width
    val h = size.height
    // hingeAlpha now scales a highlight instead of a shadow.
    val edge = (hingeAlpha * 1.6f).coerceIn(0.18f, 0.55f)
    drawRect(
        brush = Brush.horizontalGradient(
            0.000f to Color.White.copy(alpha = edge),
            0.018f to Color.White.copy(alpha = edge * 0.45f),
            0.060f to Color.Transparent,
            1.000f to Color.Transparent
        ),
        size = size
    )
    drawLine(
        Color.White.copy(alpha = (edge * 1.3f).coerceAtMost(0.75f)),
        Offset(0.7f, 0f),
        Offset(0.7f, h),
        1.4f
    )
    // Ambient occlusion at the base
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.16f)),
            startY = h * 0.88f, endY = h
        ),
        topLeft = Offset(0f, h * 0.88f),
        size = Size(w, h * 0.12f)
    )
}

// Shared: a clean vertical page block with fine page lines.
private fun androidx.compose.ui.graphics.drawscope.DrawScope.pageBlock(
    pagesPx: Float,
    hi: Color,
    mid: Color,
    lo: Color,
    lines: Int = 5
) {
    val w = size.width
    val h = size.height
    val px = w - pagesPx
    val inset = (h * 0.012f).coerceAtLeast(1.5f)

    // Slight board overhang: pages are inset from the top and bottom
    drawRect(
        brush = Brush.horizontalGradient(
            colors = listOf(mid, hi, lo),
            startX = px, endX = w
        ),
        topLeft = Offset(px, inset),
        size = Size(pagesPx, h - inset * 2f)
    )
    for (i in 1..lines) {
        val lx = px + pagesPx * i / (lines + 1f)
        drawLine(lo.copy(alpha = 0.5f), Offset(lx, inset + 1f), Offset(lx, h - inset - 1f), 0.9f)
    }
    // Overhang shadows at the top and bottom of the block
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(Color.Black.copy(alpha = 0.3f), Color.Transparent),
            startY = inset, endY = inset + 4f
        ),
        topLeft = Offset(px, inset),
        size = Size(pagesPx, 4f)
    )
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.3f)),
            startY = h - inset - 4f, endY = h - inset
        ),
        topLeft = Offset(px, h - inset - 4f),
        size = Size(pagesPx, 4f)
    )
    // Back board edge line
    drawLine(Color.Black.copy(alpha = 0.55f), Offset(w - 0.8f, 0f), Offset(w - 0.8f, h), 1.6f)
}

// ═════════════════════════════════════════════════════════════════════════
// DESIGN 1 — MODERN
// A clean contemporary matte hardcover: crisp white page block, a whisper of
// sheen, cover art running full-bleed. Quiet and bookstore-new.
// ═════════════════════════════════════════════════════════════════════════
@Composable
private fun ModernBook(
    avgColor: Color,
    modifier: Modifier = Modifier,
    cover: @Composable (Modifier) -> Unit
) {
    BookScaffold(
        spineW = 0f,
        pagesW = 0.05f,
        lean = -5f,
        cornerRadius = 2.dp,
        shadowAlpha = 0.42f,
        modifier = modifier,
        drawBody = { _, pagesPx ->
            // Bright white page block, and nothing else. No spine band: the cover
            // art runs full-bleed to the left edge now, and the book gets its
            // depth from the page edges, the lean and the contact shadow.
            pageBlock(pagesPx, hi = PaperHi, mid = PaperMid, lo = PaperLo)
        },
        coverOverlay = {
            commonCoverShading(hingeAlpha = 0.26f)
            val w = size.width
            val h = size.height
            // Top rim light — matte board catching the room light
            drawLine(Color.White.copy(alpha = 0.35f), Offset(0f, 0.5f), Offset(w, 0.5f), 1f)
            // Very subtle diagonal sheen, barely there
            drawRect(
                brush = Brush.linearGradient(
                    0.0f to Color.Transparent,
                    0.42f to Color.Transparent,
                    0.52f to Color.White.copy(alpha = 0.05f),
                    0.62f to Color.Transparent,
                    1.0f to Color.Transparent,
                    start = Offset(0f, 0f),
                    end = Offset(w * 1.2f, h)
                ),
                size = size
            )
        },
        cover = cover
    )
}

// ═════════════════════════════════════════════════════════════════════════
// DESIGN 2 — ANCIENT
// A well-read old volume: yellowed aged page edges, a blind-tooled gold frame
// and a soft aged vignette lit by a warm candle wash. Worn, but still a slim
// believable book.
// ═════════════════════════════════════════════════════════════════════════
@Composable
private fun AncientBook(
    avgColor: Color,
    modifier: Modifier = Modifier,
    cover: @Composable (Modifier) -> Unit
) {
    BookScaffold(
        spineW = 0f,
        pagesW = 0.055f,
        lean = -5.5f,
        cornerRadius = 2.5.dp,
        shadowAlpha = 0.5f,
        modifier = modifier,
        drawBody = { _, pagesPx ->
            // Yellowed, aged page block. The leather spine, its raised bands and
            // its gold fillets went out with the strip, so this design now
            // carries its age entirely on the cover: aged vignette, blind-tooled
            // gold frame and a warm candle wash.
            pageBlock(pagesPx, hi = AgedHi, mid = AgedMid, lo = AgedLo, lines = 6)
        },
        coverOverlay = {
            commonCoverShading(hingeAlpha = 0.34f)
            val w = size.width
            val h = size.height
            // Aged vignette pressing in from the corners
            drawRect(
                brush = Brush.radialGradient(
                    0.0f to Color.Transparent,
                    0.72f to Color.Transparent,
                    1.0f to Color(0xFF2A1708).copy(alpha = 0.4f),
                    center = Offset(w * 0.45f, h * 0.42f),
                    radius = (w.coerceAtLeast(h)) * 0.85f
                ),
                size = size
            )
            // Single blind-tooled frame line, slightly worn
            val inset = w * 0.06f
            drawRoundRect(
                color = GoldLine.copy(alpha = 0.45f),
                topLeft = Offset(inset, inset),
                size = Size(w - inset * 2f, h - inset * 2f),
                cornerRadius = CornerRadius(4f),
                style = Stroke(width = 1.2f)
            )
            // Warm candle-light wash from the upper left
            drawRect(
                brush = Brush.linearGradient(
                    0.0f to Color(0xFFF3D9A8).copy(alpha = 0.08f),
                    0.5f to Color.Transparent,
                    1.0f to Color.Transparent,
                    start = Offset(0f, 0f),
                    end = Offset(w, h)
                ),
                size = size
            )
        },
        cover = cover
    )
}

/**
Adaptive shelf plank that matches the current theme colors (light or dark mode) beautifully.
*/
@Composable
fun AdaptiveShelf(modifier: Modifier = Modifier) {
    val colorScheme = MaterialTheme.colorScheme
    val isDark = colorScheme.background.red < 0.5f

    // Define colors dynamically based on the current theme colors for an elegant integrated look
    val topFaceColorStart = colorScheme.surfaceVariant
    val topFaceColorEnd = colorScheme.secondaryContainer
    val lipColor = colorScheme.primary.copy(alpha = 0.85f)
    val frontFaceStart = colorScheme.secondaryContainer
    val frontFaceEnd = if (isDark) {
        lerp(colorScheme.surface, Color.Black, 0.45f)
    } else {
        lerp(colorScheme.surface, Color.Black, 0.15f)
    }

    Canvas(modifier = modifier.fillMaxWidth().height(ShelfPlankHeight)) {
        val w = size.width
        val h = size.height
        val topH = ShelfTopFaceHeight.toPx()

        // 1. Top surface (where the books stand)
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(topFaceColorStart, topFaceColorEnd),
                startY = 0f, endY = topH
            ),
            size = Size(w, topH)
        )
        // Vignette shadows at the ends of the shelf
        drawRect(
            brush = Brush.horizontalGradient(
                colors = listOf(Color.Black.copy(alpha = 0.20f), Color.Transparent, Color.Transparent, Color.Black.copy(alpha = 0.20f))
            ),
            size = Size(w, topH)
        )

        // 2. Bright beveled front lip
        drawLine(
            color = lipColor,
            start = Offset(0f, topH),
            end = Offset(w, topH),
            strokeWidth = 2.5f
        )

        // 3. Front face with vertical depth falloff
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(frontFaceStart, frontFaceEnd),
                startY = topH, endY = h
            ),
            topLeft = Offset(0f, topH),
            size = Size(w, h - topH)
        )

        // Subtle shadow/depth line at the very bottom edge of the shelf
        drawLine(
            color = Color.Black.copy(alpha = 0.35f),
            start = Offset(0f, h - 1f),
            end = Offset(w, h - 1f),
            strokeWidth = 1.5f
        )
    }
}

/**
Realistic shelf plank. Top ShelfTopFaceHeight = varnished lit surface books stand on,
the rest is the wood front face with bevel, grain, and knots.
*/
@Composable
fun WoodenShelf(modifier: Modifier = Modifier) {
val lightThemeColor = MaterialTheme.colorScheme.primaryContainer
Canvas(modifier = modifier.fillMaxWidth().height(ShelfPlankHeight)) {
val w = size.width
val h = size.height
val topH = ShelfTopFaceHeight.toPx()

// Blend wood base lit color with the light theme color
val blendColor1 = lerp(Color(0xFFCFA774), lightThemeColor, 0.28f)
val blendColor2 = lerp(Color(0xFF9A744C), lightThemeColor, 0.14f)

// 1. Lit top surface — books stand on this strip (tinted with theme)
 drawRect(
     brush = Brush.verticalGradient(
         colors = listOf(blendColor1, blendColor2),
         startY = 0f, endY = topH
     ),
     size = Size(w, topH)
 )

 // Varnish sheen — soft specular streaks along the polished top face
 drawRect(
     brush = Brush.horizontalGradient(
         0.00f to Color.Transparent,
         0.18f to Color.White.copy(alpha = 0.16f),
         0.38f to Color.Transparent,
         0.62f to Color.Transparent,
         0.78f to Color.White.copy(alpha = 0.09f),
         1.00f to Color.Transparent
     ),
     size = Size(w, topH)
 )

 // Fine grain lines running along the top face
 val topRnd = Random(21)
 repeat(6) {
     val gy = 0.5f + topRnd.nextFloat() * (topH - 1f)
     val startX = topRnd.nextFloat() * w * 0.5f
     val len = w * (0.25f + topRnd.nextFloat() * 0.5f)
     drawLine(
         color = Color(0xFF7A5A3A).copy(alpha = 0.08f + topRnd.nextFloat() * 0.08f),
         start = Offset(startX, gy),
         end = Offset((startX + len).coerceAtMost(w), gy),
         strokeWidth = 1f
     )
 }

 // End vignettes on the top face
 drawRect(
     brush = Brush.horizontalGradient(
         colors = listOf(Color.Black.copy(alpha = 0.30f), Color.Transparent, Color.Transparent, Color.Black.copy(alpha = 0.30f))
     ),
     size = Size(w, topH)
 )

 // 2. Beveled front lip — bright catch-light with a dark undercut below it
 val shelfLipColor = lerp(Color(0xFFE8C693), lightThemeColor, 0.40f)
 drawLine(shelfLipColor.copy(alpha = 0.95f), Offset(0f, topH), Offset(w, topH), 2f)
 drawLine(Color.Black.copy(alpha = 0.30f), Offset(0f, topH + 2f), Offset(w, topH + 2f), 1.2f)

 // 3. Front face — richer wood with 4-stop vertical falloff
 drawRect(
     brush = Brush.verticalGradient(
         colors = listOf(Color(0xFF7A5539), Color(0xFF5A3F28), Color(0xFF3B2A1A), Color(0xFF221710)),
         startY = topH, endY = h
     ),
     topLeft = Offset(0f, topH),
     size = Size(w, h - topH)
 )

 // 4. Deterministic grain streaks on the front face
 val rnd = Random(42)
 repeat(18) {
     val gy = topH + 2f + rnd.nextFloat() * (h - topH - 4f)
     val startX = rnd.nextFloat() * w * 0.4f
     val len = w * (0.3f + rnd.nextFloat() * 0.65f)
     drawLine(
         color = if (rnd.nextBoolean()) Color(0xFF8A6547).copy(alpha = 0.10f + rnd.nextFloat() * 0.10f)
                 else Color.Black.copy(alpha = 0.10f + rnd.nextFloat() * 0.12f),
         start = Offset(startX, gy),
         end = Offset((startX + len).coerceAtMost(w), gy + (rnd.nextFloat() - 0.5f) * 3f),
         strokeWidth = 1f + rnd.nextFloat() * 1.2f
     )
 }

 // 5. Two knots with grain rings around them
 repeat(2) { k ->
     val kx = w * (0.24f + k * 0.47f)
     val ky = topH + (h - topH) * 0.52f
     drawOval(Color.Black.copy(alpha = 0.28f), topLeft = Offset(kx - 1f, ky - 3f), size = Size(11f, 6f))
     drawOval(Color(0xFF8A6547).copy(alpha = 0.35f), topLeft = Offset(kx + 1.5f, ky - 1.8f), size = Size(6f, 3.2f))
     drawOval(Color.Black.copy(alpha = 0.30f), topLeft = Offset(kx + 3.2f, ky - 0.8f), size = Size(2.6f, 1.4f))
 }

 // 6. Plank ends fade into the cabinet side walls
 drawRect(
     brush = Brush.horizontalGradient(colors = listOf(Color.Black.copy(alpha = 0.50f), Color.Transparent), startX = 0f, endX = w * 0.07f),
     size = Size(w * 0.07f, h)
 )
 drawRect(
     brush = Brush.horizontalGradient(colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.50f)), startX = w * 0.93f, endX = w),
     topLeft = Offset(w * 0.93f, 0f),
     size = Size(w * 0.07f, h)
 )

 // 7. Soft under-plank shadow fading in toward the bottom edge
 drawRect(
     brush = Brush.verticalGradient(
         colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f)),
         startY = h - 4f, endY = h
     ),
     topLeft = Offset(0f, h - 4f),
     size = Size(w, 4f)
 )
 drawLine(Color.Black.copy(alpha = 0.65f), Offset(0f, h - 1f), Offset(w, h - 1f), 1.5f)
}
}
