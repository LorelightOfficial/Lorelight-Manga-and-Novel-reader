package com.lorelight.core

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import com.lorelight.ui.settings.generateBackupJson
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BackupManager {
    private const val TAG = "BackupManager"
    private const val PREFS_NAME = "lorelight_backup_prefs"
    private const val KEY_LAST_BACKUP = "last_auto_backup_time"
    
    const val KEY_LOCATION_TYPE = "backup_location_type" // Always "custom" now
    const val KEY_CUSTOM_URI = "backup_custom_uri"
    const val KEY_CUSTOM_PATH_NAME = "backup_custom_path_name"
    
    const val BACKUP_FILENAME = "lorelight_backup.json"

    fun init(context: Context) {
        // Trigger auto backup check in a background thread to keep startup completely fast
        Thread {
            try {
                performAutoBackupIfNeeded(context)
            } catch (e: Exception) {
                Log.e(TAG, "Error in automatic daily backup check", e)
            }
        }.start()
    }

    fun initializeDirectories(context: Context, treeUri: Uri): Boolean {
        return try {
            val treeFile = DocumentFile.fromTreeUri(context, treeUri)
            if (treeFile != null && treeFile.exists() && treeFile.isDirectory) {
                // Ensure the 3 subdirectories exist
                treeFile.findFile("local_storage") ?: treeFile.createDirectory("local_storage")
                treeFile.findFile("backup") ?: treeFile.createDirectory("backup")
                treeFile.findFile("crash_reports") ?: treeFile.createDirectory("crash_reports")
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing custom directories", e)
            false
        }
    }

    private fun performAutoBackupIfNeeded(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val lastBackupTime = prefs.getLong(KEY_LAST_BACKUP, 0L)
        val currentTime = System.currentTimeMillis()
        
        // 6 hours in milliseconds
        val sixHoursMillis = 21600000L
        if (currentTime - lastBackupTime >= sixHoursMillis) {
            Log.d(TAG, "Triggering automatic backup check...")
            val success = createBackup(context)
            if (success) {
                prefs.edit().putLong(KEY_LAST_BACKUP, currentTime).commit()
                Log.d(TAG, "Automatic backup generated successfully.")
            } else {
                Log.e(TAG, "Automatic backup failed.")
            }
        } else {
            val minsDiff = (currentTime - lastBackupTime) / 60000
            Log.d(TAG, "Auto-backup skipped: Last auto-backup was $minsDiff minutes ago (less than 6 hours).")
        }
    }

    private fun countNovels(json: String): Int {
        return try {
            org.json.JSONArray(org.json.JSONObject(json).optString("saved_novels", "[]")).length()
        } catch (e: Exception) { -1 }
    }

    fun createBackup(context: Context): Boolean {
        return try {
            // Uses generateBackupJson defined in SettingsScreen
            val backupJson = generateBackupJson(context)
            if (backupJson.isEmpty()) {
                Log.e(TAG, "Generated backup JSON is empty.")
                return false
            }

            if (com.lorelight.data.db.LorelightDatabase.lastOpenFailed) {
                Log.e(TAG, "ABORT: Database open previously failed. Refusing backup.")
                return false
            }

            if (!com.lorelight.data.local.NovelPreferences.isLibraryHealthy()) {
                Log.e(TAG, "ABORT: Library was not read successfully this session. Refusing backup.")
                return false
            }

            // ── BACKUP EXPORT FIX ────────────────────────────────────────────
            // Previously this method wrote ONLY to a user-picked SAF folder and
            // returned false if none was configured, so "Backup Now" failed for
            // every user who never opened the folder picker.
            //
            // Worse, SelfHealingEngine.findLatestStableBackup() looks for a
            // backup in getExternalFilesDir("AutoBackups") and in filesDir --
            // two locations nothing ever wrote to. Automatic recovery therefore
            // could never find a backup either.
            //
            // Local copies now always get written, to exactly the paths the
            // self-healing engine already probes. Neither needs a permission.
            val localOk = writeLocalFallbacks(context, backupJson)

            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val uriStr = prefs.getString(KEY_CUSTOM_URI, null)
            if (!uriStr.isNullOrEmpty()) {
                try {
                    val treeUri = Uri.parse(uriStr)
                    val treeFile = DocumentFile.fromTreeUri(context, treeUri)
                    if (treeFile != null && treeFile.exists() && treeFile.isDirectory) {
                        val backupDir = treeFile.findFile("backup") ?: treeFile.createDirectory("backup")
                        if (backupDir != null) {
                            // Check existing main backup file content novel count
                            val existingMainDoc = backupDir.findFile(BACKUP_FILENAME)
                            if (existingMainDoc != null && existingMainDoc.exists()) {
                                try {
                                    val existingJson = context.contentResolver.openInputStream(existingMainDoc.uri)?.use { stream ->
                                        stream.bufferedReader().readText()
                                    } ?: ""
                                    val existingCount = countNovels(existingJson)
                                    val newCount = countNovels(backupJson)
                                    if (newCount == 0 && existingCount >= 1) {
                                        Log.e(TAG, "ABORT: Refusing to overwrite populated backup ($existingCount novels) with 0 novels.")
                                        return false
                                    }
                                } catch (e: Exception) {
                                    Log.e(TAG, "Error checking existing backup file content", e)
                                }
                            }

                            val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                            val datedFilename = "lorelight_backup_$dateStr.json"

                            // 1. Write dated copy first
                            var datedDocFile = backupDir.findFile(datedFilename)
                            if (datedDocFile == null) {
                                datedDocFile = backupDir.createFile("application/json", datedFilename)
                            }
                            if (datedDocFile == null) {
                                Log.e(TAG, "Failed to create dated backup document file: $datedFilename")
                                return false
                            }

                            val writeDatedSuccess = try {
                                context.contentResolver.openOutputStream(datedDocFile.uri)?.use { out ->
                                    out.write(backupJson.toByteArray())
                                }
                                true
                            } catch (e: Exception) {
                                Log.e(TAG, "Failed writing to dated backup file", e)
                                false
                            }

                            if (!writeDatedSuccess) {
                                Log.e(TAG, "Dated backup write failed. Aborting without touching main backup.")
                                return false
                            }

                            // 2. Write main lorelight_backup.json copy
                            var mainDocFile = backupDir.findFile(BACKUP_FILENAME)
                            if (mainDocFile == null) {
                                mainDocFile = backupDir.createFile("application/json", BACKUP_FILENAME)
                            }
                            if (mainDocFile != null) {
                                context.contentResolver.openOutputStream(mainDocFile.uri)?.use { out ->
                                    out.write(backupJson.toByteArray())
                                }
                            }

                            // 3. Prune dated backups (keep 7 newest)
                            try {
                                val datedFiles = backupDir.listFiles()
                                    .filter { it.name != null && it.name!!.startsWith("lorelight_backup_") && it.name!!.endsWith(".json") && it.name != BACKUP_FILENAME }
                                    .sortedByDescending { it.name!! }
                                if (datedFiles.size > 7) {
                                    datedFiles.drop(7).forEach { oldFile ->
                                        oldFile.delete()
                                    }
                                }
                            } catch (e: Exception) {
                                Log.e(TAG, "Error pruning old dated backups", e)
                            }

                            Log.d(TAG, "Successfully updated custom folder backups ($datedFilename & $BACKUP_FILENAME).")
                            return true
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to write to custom SAF folder", e)
                }
            }
            // No SAF folder configured (or it failed): the run still counts as a
            // success when the local copies landed.
            if (localOk) {
                Log.d(TAG, "Backup written to local app storage (no custom folder configured).")
            }
            localOk
        } catch (e: Exception) {
            Log.e(TAG, "Failed to write automatic backup file", e)
            false
        }
    }

    /**
     * Writes the backup to the two permission-free locations that
     * [com.lorelight.core.SelfHealingEngine] already searches during recovery:
     *
     *  1. getExternalFilesDir("AutoBackups")  - visible in a file manager under
     *     Android/data/com.lorelight/files/AutoBackups
     *  2. filesDir                            - always available, survives when
     *     external storage is unmounted
     *
     * Returns true if at least one write succeeded.
     */
    private fun writeLocalFallbacks(context: Context, backupJson: String): Boolean {
        var wroteAny = false

        try {
            val extDir = context.getExternalFilesDir("AutoBackups")
            if (extDir != null) {
                if (!extDir.exists()) extDir.mkdirs()
                writeAtomically(File(extDir, BACKUP_FILENAME), backupJson)
                wroteAny = true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed writing external AutoBackups copy", e)
        }

        try {
            writeAtomically(File(context.filesDir, BACKUP_FILENAME), backupJson)
            wroteAny = true
        } catch (e: Exception) {
            Log.e(TAG, "Failed writing internal backup copy", e)
        }

        return wroteAny
    }

    /**
     * Writes to a temp file and renames over the target. A process death midway
     * through can then never leave a truncated backup behind -- the old good
     * copy simply stays in place.
     */
    private fun writeAtomically(target: File, content: String) {
        val tmp = File(target.parentFile, "${target.name}.tmp")
        tmp.writeText(content)
        if (target.exists() && !target.delete()) {
            // Fall back to a direct overwrite if the delete was refused.
            target.writeText(content)
            tmp.delete()
            return
        }
        if (!tmp.renameTo(target)) {
            target.writeText(content)
            tmp.delete()
        }
    }

    fun getSingleBackupInfo(context: Context): BackupInfo? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val uriStr = prefs.getString(KEY_CUSTOM_URI, null)
        val pathName = prefs.getString(KEY_CUSTOM_PATH_NAME, "Custom Folder") ?: "Custom Folder"
        if (!uriStr.isNullOrEmpty()) {
            try {
                val treeUri = Uri.parse(uriStr)
                val treeFile = DocumentFile.fromTreeUri(context, treeUri)
                if (treeFile != null && treeFile.exists()) {
                    val backupDir = treeFile.findFile("backup")
                    val backupDocFile = backupDir?.findFile(BACKUP_FILENAME)
                    if (backupDocFile != null && backupDocFile.exists()) {
                        return BackupInfo(
                            name = BACKUP_FILENAME,
                            locationType = "custom",
                            locationName = "Custom Folder: $pathName/backup",
                            dateFormatted = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(backupDocFile.lastModified())),
                            sizeFormatted = formatFileSize(backupDocFile.length()),
                            file = null,
                            uri = backupDocFile.uri
                        )
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error looking up backup info", e)
            }
        }

        // No custom folder, or nothing there yet: report the local copy so the
        // settings screen shows a real date/size instead of looking broken.
        try {
            val candidates = listOf(
                context.getExternalFilesDir("AutoBackups")?.let { File(it, BACKUP_FILENAME) } to "App Storage: AutoBackups",
                File(context.filesDir, BACKUP_FILENAME) to "Internal App Storage"
            )
            for ((file, label) in candidates) {
                if (file != null && file.exists() && file.length() > 0) {
                    return BackupInfo(
                        name = BACKUP_FILENAME,
                        locationType = "local",
                        locationName = label,
                        dateFormatted = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(file.lastModified())),
                        sizeFormatted = formatFileSize(file.length()),
                        file = file,
                        uri = null
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error looking up local backup info", e)
        }

        return null
    }

    private fun formatFileSize(size: Long): String {
        return when {
            size < 1024 -> "$size B"
            size < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", size / 1024.0)
            else -> String.format(Locale.US, "%.1f MB", size / (1024.0 * 1024.0))
        }
    }
}

data class BackupInfo(
    val name: String,
    val locationType: String,
    val locationName: String,
    val dateFormatted: String,
    val sizeFormatted: String,
    val file: File?,
    val uri: Uri?
)
