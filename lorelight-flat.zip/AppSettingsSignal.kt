package com.lorelight.data.local

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * App-wide reactive signal for settings/preferences changes.
 * Whenever any setting is updated, [notifyChanged] is called,
 * incrementing [version] and causing observing Composables to recompose.
 */
object AppSettingsSignal {
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version.asStateFlow()

    fun notifyChanged() {
        _version.update { it + 1 }
    }

    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        notifyChanged()
    }
    private val registeredPrefs = mutableSetOf<String>()

    /**
     * Registers a listener on the named [SharedPreferences] store so any preference
     * write automatically triggers [notifyChanged].
     */
    fun watch(context: Context, prefName: String) {
        val key = prefName.trim()
        if (key.isNotEmpty() && !registeredPrefs.contains(key)) {
            try {
                val prefs = context.applicationContext.getSharedPreferences(key, Context.MODE_PRIVATE)
                prefs.registerOnSharedPreferenceChangeListener(listener)
                registeredPrefs.add(key)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /**
     * Automatically attaches listeners to all common preference stores used across the app.
     */
    fun watchAllCommonPrefs(context: Context) {
        listOf(
            AppPrefs.NAME,
            "lorelight_settings",
            "lorelight_manga_reader_prefs",
            "reader_prefs",
            "lorelight_manga_prefs",
            "lorelight_backup_prefs",
            "reader_text_filters",
            "manga_reader_text_filters",
            "lorelight_browse_prefs"
        ).forEach { watch(context, it) }
    }
}
