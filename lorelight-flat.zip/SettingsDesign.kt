package com.lorelight.ui.settings

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.ui.theme.GlassPanel
import com.lorelight.ui.theme.getThemedButtonProps
import androidx.compose.ui.semantics.Role

/*
 * SETTINGS DESIGN LAYER
 *
 * One place that owns how a settings row looks, so the settings screens stop
 * inventing their own card radius, container tint and font size each time.
 *
 * Before this file there were three competing treatments on a single screen:
 * 14.dp + surface + outlineVariant border (hub cards), 16.dp + surfaceVariant at
 * 40% (summary card), and 12.dp + surfaceVariant at 40-50% (in-category cards),
 * with type hardcoded at 11/12/13/14/18.sp instead of coming from the theme.
 *
 * Everything here is built on GlassPanel from ui/theme/Glass.kt, which is the
 * same component the reader and every dialog already use. Settings was the only
 * major surface still using raw Card, which is why it looked foreign.
 */

// ---------------------------------------------------------------------------
// Tokens. These are actually used, unlike the previous private set.
// ---------------------------------------------------------------------------

val SettingsPanelRadius = 18.dp
val SettingsGroupGap = 14.dp
val SettingsRowMinHeight = 56.dp
val SettingsRowHPad = 16.dp
val SettingsRowVPad = 12.dp
private val SettingsPanelVPad = 4.dp

// ---------------------------------------------------------------------------
// Building blocks
// ---------------------------------------------------------------------------

/** A small caps label used to separate groups that were previously separate categories. */
@Composable
fun SettingsSectionLabel(text: String) {
    Text(
        text = text.uppercase(),
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.sp,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 6.dp, top = 6.dp)
    )
}

/**
 * A titled glass container holding one or more rows. Replaces the ad-hoc Card
 * usage. Pass title = null for an untitled container.
 */
@Composable
fun SettingsGroup(
    title: String? = null,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(modifier = modifier.fillMaxWidth()) {
        if (!title.isNullOrBlank()) {
            SettingsSectionLabel(title)
            Spacer(modifier = Modifier.height(8.dp))
        }
        GlassPanel(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = SettingsPanelRadius,
            tintAlpha = 0.62f
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = SettingsPanelVPad),
                content = content
            )
        }
    }
}

/** Hairline separator between rows inside a group. Drawn as a Box so it does not
 *  depend on which Material 3 divider API this project's version exposes. */
@Composable
fun SettingsRowDivider() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = SettingsRowHPad)
            .height(0.7.dp)
            .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
    )
}

/**
 * The single settings row. Subtitles wrap to three lines instead of being cut
 * off at one line with an ellipsis, which is what the old hub cards did to
 * every category description.
 *
 * `compact` is the two-pane category rail. There the row is label-only: the
 * long category description is deliberately not rendered, which is how the
 * platform's own settings rails behave. That removes the reason the labels were
 * being squeezed in the first place, so nothing has to shrink or truncate - the
 * name gets the full width of the rail and wraps on a word boundary if a
 * translation or a large system font actually needs a second line.
 */
@Composable
fun SettingsRow(
    title: String,
    subtitle: String? = null,
    icon: ImageVector? = null,
    trailingText: String? = null,
    showChevron: Boolean = false,
    highlighted: Boolean = false,
    onClick: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
    compact: Boolean = false
) {
    val sizing = Modifier
        .fillMaxWidth()
        .heightIn(min = SettingsRowMinHeight)
    val interactive = if (onClick != null) sizing.clickable(role = Role.Button) { onClick() } else sizing

    // Same animated theme-gradient treatment as the main bottom navigation
    // bar's sliding highlight, adapted to this vertical row list: the
    // gradient fades in/out behind the active row instead of sliding, since
    // each row here is its own separate card rather than a single strip.
    val highlightAlpha by animateFloatAsState(
        targetValue = if (highlighted) 1f else 0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "settingsRowHighlight"
    )
    val (_, rowHighlightGradient, _) = getThemedButtonProps(
        MaterialTheme.colorScheme.primary,
        MaterialTheme.colorScheme.onPrimaryContainer
    )

    Row(
        modifier = interactive
            .background(
                brush = rowHighlightGradient,
                alpha = highlightAlpha
            )
            .padding(
                horizontal = if (compact) SettingsRowHPad * 0.65f else SettingsRowHPad,
                vertical = SettingsRowVPad
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Box(
                modifier = Modifier
                    .size(if (compact) 30.dp else 36.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(if (compact) 16.dp else 19.dp)
                )
            }
            Spacer(modifier = Modifier.width(if (compact) 8.dp else 14.dp))
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = if (compact) MaterialTheme.typography.bodyMedium
                else MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                // Two lines is a safety net for long translations / large font
                // scales, not the expected layout. Word wrapping is the default,
                // so labels never break mid-word.
                maxLines = if (compact) 2 else Int.MAX_VALUE,
                overflow = TextOverflow.Ellipsis
            )
            // The rail shows names only. Descriptions still appear on the
            // detail pane and in the single-pane hub, where there is room.
            if (!subtitle.isNullOrBlank() && !compact) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }

        if (trailingText != null) {
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = trailingText,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
        }
        if (trailing != null) {
            Spacer(modifier = Modifier.width(8.dp))
            trailing()
        }
        if (showChevron) {
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

/** Search box. Colours are left at their defaults on purpose so this compiles
 *  against both the old and new Material 3 text field colour APIs. */
@Composable
fun SettingsSearchField(
    query: String,
    onQueryChange: (String) -> Unit,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = modifier.fillMaxWidth(),
        placeholder = { Text("Search settings") },
        leadingIcon = {
            Icon(imageVector = Icons.Default.Search, contentDescription = null)
        },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = onClear) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Clear search")
                }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(14.dp)
    )
}

/**
 * Persistent category rail for wide layouts. Selecting a category here never
 * pushes a back entry, so on a tablet or a landscape phone you can move between
 * categories without pressing Back once.
 */
@Composable
fun SettingsCategoryRail(
    activeCategory: SettingsCategory?,
    query: String,
    onQueryChange: (String) -> Unit,
    onSelect: (SettingsCategory) -> Unit,
    modifier: Modifier = Modifier
) {
    val hits = settingsSearchResults(query)

    Column(modifier = modifier) {
        Text(
            text = "Settings",
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(start = 6.dp, bottom = 12.dp)
        )

        SettingsSearchField(
            query = query,
            onQueryChange = onQueryChange,
            onClear = { onQueryChange("") }
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (query.isNotBlank()) {
                items(hits) { hit ->
                    SettingsGroup {
                        SettingsRow(
                            title = hit.label,
                            subtitle = hit.category.title,
                            icon = hit.category.icon,
                            onClick = {
                                onQueryChange("")
                                onSelect(hit.category)
                            },
                            compact = true
                        )
                    }
                }
            } else {
                items(SettingsCategory.values().toList()) { category ->
                    SettingsGroup {
                        SettingsRow(
                            title = category.title,
                            subtitle = category.desc,
                            icon = category.icon,
                            highlighted = category == activeCategory,
                            onClick = { onSelect(category) },
                            compact = true
                        )
                    }
                }
            }
        }
    }
}

/** Shown in the detail pane of a wide layout when no category is selected yet. */
@Composable
fun SettingsPlaceholderPane() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 90.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.Settings,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.30f),
            modifier = Modifier.size(52.dp)
        )
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = "Pick a category",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Choose a section on the left, or search to jump straight to a setting.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
        )
    }
}

// ---------------------------------------------------------------------------
// Search index
// ---------------------------------------------------------------------------

/**
 * One searchable setting. This index is written by hand for now: it maps a
 * human label to the category that contains it, so search can jump you to the
 * right screen instead of only matching category titles.
 *
 * When the declarative settings model lands, this list is generated from the
 * setting definitions themselves and can deep-link to the exact row.
 */
data class SettingsSearchHit(
    val label: String,
    val category: SettingsCategory,
    val keywords: String = ""
)

val settingsSearchIndex: List<SettingsSearchHit> = listOf(
    // Appearance
    SettingsSearchHit("Theme mode", SettingsCategory.APPEARANCE, "dark light night day amoled"),
    SettingsSearchHit("Colour palette", SettingsCategory.APPEARANCE, "color accent scheme theme"),
    SettingsSearchHit("Library background", SettingsCategory.APPEARANCE, "wallpaper image backdrop"),
    SettingsSearchHit("Reader background", SettingsCategory.APPEARANCE, "paper sepia page colour"),
    SettingsSearchHit("App font", SettingsCategory.APPEARANCE, "typeface typography family"),
    SettingsSearchHit("Manage typography fonts", SettingsCategory.APPEARANCE, "download font manager custom ttf"),

    // Reading and voice
    SettingsSearchHit("Text margins", SettingsCategory.READING, "padding side inset"),
    SettingsSearchHit("Line spacing", SettingsCategory.READING, "leading line height"),
    SettingsSearchHit("Font size", SettingsCategory.READING, "text size bigger smaller"),
    SettingsSearchHit("Reading mode", SettingsCategory.READING, "long strip webtoon paged rtl ltr vertical"),
    SettingsSearchHit("Page gap", SettingsCategory.READING, "spacing between pages"),
    SettingsSearchHit("Crop borders", SettingsCategory.READING, "trim white edges"),
    SettingsSearchHit("Maximum zoom", SettingsCategory.READING, "pinch scale magnify"),
    SettingsSearchHit("Double tap to zoom", SettingsCategory.READING, "tap zoom gesture"),
    SettingsSearchHit("Orientation lock", SettingsCategory.READING, "rotate portrait landscape"),
    SettingsSearchHit("Keep screen on", SettingsCategory.READING, "awake sleep timeout"),
    SettingsSearchHit("Fullscreen", SettingsCategory.READING, "immersive hide status bar cutout"),
    SettingsSearchHit("Tap zones", SettingsCategory.READING, "tap navigation zone overlay"),
    SettingsSearchHit("Volume key navigation", SettingsCategory.READING, "volume buttons page turn invert"),
    SettingsSearchHit("Autoscroll speed", SettingsCategory.READING, "auto scroll slider speed"),
    SettingsSearchHit("Autoscroll speed while reading aloud", SettingsCategory.READING, "autoscroll tts speed"),
    SettingsSearchHit("Pause autoscroll on tap", SettingsCategory.READING, "tap pause autoscroll"),
    SettingsSearchHit("Text-to-speech voice", SettingsCategory.READING, "tts voice accent narrator language"),
    SettingsSearchHit("Speech speed", SettingsCategory.READING, "tts rate faster slower"),
    SettingsSearchHit("Speech pitch", SettingsCategory.READING, "tts pitch tone"),
    SettingsSearchHit("Follow voice while reading", SettingsCategory.READING, "tts follow scroll focus bubble"),
    SettingsSearchHit("Show OCR text boxes", SettingsCategory.READING, "ocr debug boxes recognition manga text"),
    SettingsSearchHit("Grayscale", SettingsCategory.READING, "black and white monochrome"),
    SettingsSearchHit("Invert colours", SettingsCategory.READING, "negative invert"),
    SettingsSearchHit("Brightness overlay", SettingsCategory.READING, "dim darker screen brightness"),
    SettingsSearchHit("Preload pages", SettingsCategory.READING, "prefetch buffer ahead"),
    SettingsSearchHit("Show page number", SettingsCategory.READING, "page counter indicator"),
    SettingsSearchHit("Show page slider", SettingsCategory.READING, "seek bar scrubber"),

    // Library and sources
    SettingsSearchHit("Automatic update checks", SettingsCategory.LIBRARY, "auto check new chapters background"),
    SettingsSearchHit("Update interval", SettingsCategory.LIBRARY, "how often hours frequency"),
    SettingsSearchHit("Update on Wi-Fi only", SettingsCategory.LIBRARY, "wifi mobile data metered"),
    SettingsSearchHit("New chapter notifications", SettingsCategory.LIBRARY, "notify alert push"),
    SettingsSearchHit("Refetch novel and manga details", SettingsCategory.LIBRARY, "refresh covers metadata missing images"),
    SettingsSearchHit("Manga source languages", SettingsCategory.LIBRARY, "language filter browse translate"),
    SettingsSearchHit("Installed extensions", SettingsCategory.LIBRARY, "extension uninstall manga source plugin"),
    SettingsSearchHit("Show adult sources", SettingsCategory.LIBRARY, "nsfw adult 18 filter"),

    // Downloads and storage
    SettingsSearchHit("Download queue", SettingsCategory.STORAGE, "queue active queued failed progress downloads"),
    SettingsSearchHit("Failed downloads", SettingsCategory.STORAGE, "retry failed error download"),
    SettingsSearchHit("Offline chapter cache", SettingsCategory.STORAGE, "cache size offline stored"),
    SettingsSearchHit("Clear cache", SettingsCategory.STORAGE, "delete free space wipe cache"),
    SettingsSearchHit("Per novel downloads", SettingsCategory.STORAGE, "per novel storage delete downloads"),
    SettingsSearchHit("Source health", SettingsCategory.STORAGE, "plugin health broken source status"),
    SettingsSearchHit("Download tuning", SettingsCategory.STORAGE, "parallel speed limit pacing retries tune"),
    SettingsSearchHit("Parallel downloads", SettingsCategory.STORAGE, "at once concurrent simultaneous chapters pages"),
    SettingsSearchHit("Download speed limit", SettingsCategory.STORAGE, "throttle bandwidth cap kbps mbps slow"),
    SettingsSearchHit("Download on Wi-Fi only", SettingsCategory.STORAGE, "mobile data metered quota wifi"),
    SettingsSearchHit("Retry attempts", SettingsCategory.STORAGE, "retries failed download attempts"),

    // Backup and restore
    SettingsSearchHit("Create a backup", SettingsCategory.BACKUP_RESTORE, "export save backup now json"),
    SettingsSearchHit("Restore a backup", SettingsCategory.BACKUP_RESTORE, "import load restore merge json"),
    SettingsSearchHit("Backup location", SettingsCategory.BACKUP_RESTORE, "folder path where saved custom"),
    SettingsSearchHit("Automatic daily backup", SettingsCategory.BACKUP_RESTORE, "auto backup daily scheduled"),
    SettingsSearchHit("Include sources in backup", SettingsCategory.BACKUP_RESTORE, "sources plugins extensions repos backup"),

    // Advanced and about
    SettingsSearchHit("Crash reports", SettingsCategory.ADVANCED, "crash error stacktrace diagnostics"),
    SettingsSearchHit("Diagnostic logs", SettingsCategory.ADVANCED, "dev log share logs txt"),
    SettingsSearchHit("Developer mode", SettingsCategory.ADVANCED, "developer unlock hidden debug"),
    SettingsSearchHit("Network speed throttle", SettingsCategory.ADVANCED, "slow network throttle test bandwidth"),
    SettingsSearchHit("App version", SettingsCategory.ADVANCED, "version build about"),
    SettingsSearchHit("Discord community", SettingsCategory.ADVANCED, "discord community support help")
)

/** Case-insensitive match over label, keywords and the owning category name. */
fun settingsSearchResults(query: String): List<SettingsSearchHit> {
    val needle = query.trim().lowercase()
    if (needle.length < 2) return emptyList()
    return settingsSearchIndex.filter { hit ->
        hit.label.lowercase().contains(needle) ||
            hit.keywords.lowercase().contains(needle) ||
            hit.category.title.lowercase().contains(needle)
    }.take(25)
}
