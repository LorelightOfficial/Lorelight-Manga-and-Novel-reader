package com.lorelight.data.download

import androidx.compose.runtime.mutableStateListOf
import java.util.concurrent.ConcurrentHashMap

/**
 * Download job & chapter lifecycle status.
 */
enum class DownloadStatus {
    QUEUED,
    ACTIVE,
    PAUSED,
    DONE,
    FAILED,
    CANCELLED
}

/**
 * Per-chapter or per-page child item inside a download job.
 */
data class DownloadItemState(
    val id: String,                         // Unique ID within job (e.g. chapter URL or index)
    val name: String,                       // Display name e.g. "Chapter 1: Arrival"
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val current: Long = 0L,                 // Progress bytes or page count
    val total: Long = 0L,                   // Total bytes or total pages (0 if unknown)
    val errorMessage: String? = null,
    val startedAt: Long? = null,
    val finishedAt: Long? = null
) {
    val fraction: Float
        get() = if (total > 0L) (current.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                else if (status == DownloadStatus.DONE) 1f
                else 0f

    val isFinished: Boolean
        get() = status == DownloadStatus.DONE || status == DownloadStatus.FAILED || status == DownloadStatus.CANCELLED

    val isDone: Boolean get() = status == DownloadStatus.DONE
    val isFailed: Boolean get() = status == DownloadStatus.FAILED
    val isDownloading: Boolean get() = status == DownloadStatus.ACTIVE
    /** Display name for this item, used in the queue's "currently downloading" line. */
    val label: String get() = name
}

/**
 * Represents a single unified download job (Novel or Manga) containing child items.
 */
data class DownloadJobState(
    val id: String,
    val novelId: String = "",
    val title: String,
    val kind: String,                       // "Novel" or "Manga"
    val items: List<DownloadItemState> = emptyList(), // Per-chapter child items
    val legacyCurrent: Int = 0,             // Fallback current count when items is empty
    val legacyTotal: Int = 0,               // Fallback total count when items is empty
    val status: String = "Starting...",
    val downloadStatus: DownloadStatus = DownloadStatus.ACTIVE,
    val active: Boolean = (downloadStatus == DownloadStatus.ACTIVE),
    val startedAt: Long = System.currentTimeMillis(),
    val finishedAt: Long = 0L,
    val errorMessage: String? = null
) {
    // Derived aggregate counts
    val totalCount: Int
        get() = if (items.isNotEmpty()) items.size else legacyTotal.coerceAtLeast(0)

    val completedCount: Int
        get() = if (items.isNotEmpty()) items.count { it.status == DownloadStatus.DONE } else legacyCurrent.coerceAtLeast(0)

    val failedCount: Int
        get() = if (items.isNotEmpty()) items.count { it.status == DownloadStatus.FAILED }
                else if (downloadStatus == DownloadStatus.FAILED) 1 else 0

    val activeCount: Int
        get() = if (items.isNotEmpty()) items.count { it.status == DownloadStatus.ACTIVE }
                else if (downloadStatus == DownloadStatus.ACTIVE) 1 else 0

    val pendingCount: Int
        get() = if (items.isNotEmpty()) items.count { it.status == DownloadStatus.QUEUED || it.status == DownloadStatus.PAUSED }
                else if (downloadStatus == DownloadStatus.QUEUED || downloadStatus == DownloadStatus.PAUSED) 1 else 0

    val current: Int
        get() = completedCount

    val total: Int
        get() = totalCount

    val fraction: Float
        get() {
            if (items.isNotEmpty()) {
                val sumFraction = items.sumOf { it.fraction.toDouble() }
                return (sumFraction / items.size.toDouble()).toFloat().coerceIn(0f, 1f)
            }
            return if (legacyTotal > 0) (legacyCurrent.toFloat() / legacyTotal.toFloat()).coerceIn(0f, 1f) else 0f
        }

    val isFinished: Boolean
        get() = downloadStatus == DownloadStatus.DONE ||
                downloadStatus == DownloadStatus.FAILED ||
                downloadStatus == DownloadStatus.CANCELLED

    val isDone: Boolean get() = downloadStatus == DownloadStatus.DONE
    val isPaused: Boolean get() = downloadStatus == DownloadStatus.PAUSED
    val isFailed: Boolean get() = downloadStatus == DownloadStatus.FAILED
    /** Fallback fraction used by the queue UI when a job has no per-item breakdown. */
    val overallProgress: Float get() = fraction
}

/**
 * Process-wide source of truth for both Novel chapter downloads and
 * Manga page downloads.
 * Backed by Compose snapshot state so background IO threads and UI
 * Composables interact safely and seamlessly.
 */
object DownloadProgressBus {

    private val lock = Any()
    private val _queue = mutableStateListOf<DownloadJobState>()
    val queue: List<DownloadJobState> get() = _queue

    // Cancellation callbacks registered by download runners
    private val cancellers = ConcurrentHashMap<String, () -> Unit>()
    // Pause / Resume callbacks
    private val pauseControllers = ConcurrentHashMap<String, (Boolean) -> Unit>()
    // Retry callbacks registered by download runners: jobId -> callback(itemIdsToRetry)
    private val retryControllers = ConcurrentHashMap<String, (List<String>?) -> Unit>()
    // Flag tracking cancellation requests by job id
    private val cancelledIds = ConcurrentHashMap.newKeySet<String>()

    /**
     * Backward-compatible accessor for the most relevant/active job.
     */
    val current: DownloadJobState?
        get() = _queue.firstOrNull { it.active } ?: _queue.firstOrNull()

    /**
     * Enqueues or starts a download job with child items or initial counts.
     */
    fun enqueue(
        id: String,
        title: String,
        kind: String,
        total: Int = 0,
        novelId: String = "",
        asActive: Boolean = true,
        items: List<DownloadItemState> = emptyList()
    ): DownloadJobState {
        cancelledIds.remove(id)
        val initialStatus = if (asActive) DownloadStatus.ACTIVE else DownloadStatus.QUEUED
        val statusText = if (asActive) "Starting download..." else "Queued"
        val job = DownloadJobState(
            id = id,
            novelId = novelId,
            title = title.ifBlank { "Untitled" },
            kind = kind,
            items = items,
            legacyCurrent = 0,
            legacyTotal = if (items.isNotEmpty()) items.size else total.coerceAtLeast(0),
            status = statusText,
            downloadStatus = initialStatus,
            active = asActive,
            startedAt = System.currentTimeMillis(),
            finishedAt = 0L,
            errorMessage = null
        )

        synchronized(lock) {
            val idx = _queue.indexOfFirst { it.id == id }
            if (idx >= 0) {
                _queue[idx] = job
            } else {
                _queue.add(0, job)
            }
        }
        return job
    }

    /**
     * Start/Enqueue with explicit ID and optional items list.
     */
    fun start(
        id: String,
        title: String,
        kind: String,
        total: Int = 0,
        novelId: String = "",
        items: List<DownloadItemState> = emptyList()
    ): DownloadJobState {
        return enqueue(
            id = id,
            title = title,
            kind = kind,
            total = total,
            novelId = novelId,
            asActive = true,
            items = items
        )
    }

    /**
     * Overload without ID: auto-generates ID.
     */
    fun start(title: String, kind: String, total: Int) {
        val autoId = "${kind.lowercase()}_${System.currentTimeMillis()}"
        start(id = autoId, title = title, kind = kind, total = total)
    }

    /**
     * Sets or updates child items for a job.
     */
    fun setItems(id: String, items: List<DownloadItemState>) {
        synchronized(lock) {
            val idx = _queue.indexOfFirst { it.id == id }
            if (idx >= 0) {
                val c = _queue[idx]
                _queue[idx] = c.copy(
                    items = items,
                    legacyTotal = items.size
                )
            }
        }
    }

    /**
     * Starts progress on a specific child item.
     */
    fun startItem(jobId: String, itemId: String) {
        synchronized(lock) {
            val idx = _queue.indexOfFirst { it.id == jobId }
            if (idx >= 0) {
                val job = _queue[idx]
                val itemIdx = job.items.indexOfFirst { it.id == itemId }
                val newItems = if (itemIdx >= 0) {
                    job.items.toMutableList().apply {
                        this[itemIdx] = this[itemIdx].copy(
                            status = DownloadStatus.ACTIVE,
                            startedAt = System.currentTimeMillis(),
                            errorMessage = null
                        )
                    }
                } else {
                    job.items + DownloadItemState(
                        id = itemId,
                        name = itemId,
                        status = DownloadStatus.ACTIVE,
                        startedAt = System.currentTimeMillis()
                    )
                }
                val activeName = newItems.find { it.id == itemId }?.name ?: itemId
                val doneCount = newItems.count { it.status == DownloadStatus.DONE }
                val totalCount = newItems.size
                _queue[idx] = job.copy(
                    items = newItems,
                    status = "Downloading $activeName ($doneCount/$totalCount)",
                    downloadStatus = DownloadStatus.ACTIVE,
                    active = true
                )
            }
        }
    }

    /**
     * Updates progress for a specific child item.
     */
    fun updateItemProgress(jobId: String, itemId: String, current: Long, total: Long) {
        synchronized(lock) {
            val idx = _queue.indexOfFirst { it.id == jobId }
            if (idx >= 0) {
                val job = _queue[idx]
                val itemIdx = job.items.indexOfFirst { it.id == itemId }
                if (itemIdx >= 0) {
                    val newItems = job.items.toMutableList().apply {
                        this[itemIdx] = this[itemIdx].copy(
                            current = current,
                            total = total,
                            status = if (this[itemIdx].status == DownloadStatus.QUEUED) DownloadStatus.ACTIVE else this[itemIdx].status
                        )
                    }
                    _queue[idx] = job.copy(items = newItems)
                }
            }
        }
    }

    /**
     * Marks a specific child item as completed.
     */
    fun finishItem(jobId: String, itemId: String) {
        synchronized(lock) {
            val idx = _queue.indexOfFirst { it.id == jobId }
            if (idx >= 0) {
                val job = _queue[idx]
                val itemIdx = job.items.indexOfFirst { it.id == itemId }
                if (itemIdx >= 0) {
                    val newItems = job.items.toMutableList().apply {
                        this[itemIdx] = this[itemIdx].copy(
                            status = DownloadStatus.DONE,
                            finishedAt = System.currentTimeMillis(),
                            errorMessage = null
                        )
                    }
                    val doneCount = newItems.count { it.status == DownloadStatus.DONE }
                    val failedCount = newItems.count { it.status == DownloadStatus.FAILED }
                    val totalCount = newItems.size
                    val newStatusText = if (doneCount + failedCount == totalCount) {
                        "Completed $doneCount of $totalCount items"
                    } else {
                        "Downloaded $doneCount/$totalCount items"
                    }
                    _queue[idx] = job.copy(
                        items = newItems,
                        status = newStatusText,
                        legacyCurrent = doneCount
                    )
                }
            }
        }
    }

    /**
     * Marks a specific child item as failed.
     */
    fun failItem(jobId: String, itemId: String, errorMessage: String) {
        synchronized(lock) {
            val idx = _queue.indexOfFirst { it.id == jobId }
            if (idx >= 0) {
                val job = _queue[idx]
                val itemIdx = job.items.indexOfFirst { it.id == itemId }
                if (itemIdx >= 0) {
                    val newItems = job.items.toMutableList().apply {
                        this[itemIdx] = this[itemIdx].copy(
                            status = DownloadStatus.FAILED,
                            finishedAt = System.currentTimeMillis(),
                            errorMessage = errorMessage
                        )
                    }
                    val doneCount = newItems.count { it.status == DownloadStatus.DONE }
                    val failedCount = newItems.count { it.status == DownloadStatus.FAILED }
                    val totalCount = newItems.size
                    _queue[idx] = job.copy(
                        items = newItems,
                        status = "$doneCount done, $failedCount failed of $totalCount"
                    )
                }
            }
        }
    }

    /**
     * Legacy progress update for a job without item breakdown.
     */
    fun update(id: String, done: Int, total: Int? = null, status: String? = null) {
        synchronized(lock) {
            val idx = _queue.indexOfFirst { it.id == id }
            if (idx >= 0) {
                val c = _queue[idx]
                if (c.downloadStatus == DownloadStatus.CANCELLED) return
                _queue[idx] = c.copy(
                    legacyCurrent = done.coerceAtLeast(0),
                    legacyTotal = (total ?: c.legacyTotal).coerceAtLeast(0),
                    status = status ?: c.status,
                    downloadStatus = DownloadStatus.ACTIVE,
                    active = true
                )
            }
        }
    }

    fun update(done: Int, total: Int? = null, status: String? = null) {
        val c = current ?: return
        update(c.id, done, total, status)
    }

    /**
     * Marks job as completed.
     */
    fun finish(id: String, statusMessage: String) {
        synchronized(lock) {
            val idx = _queue.indexOfFirst { it.id == id }
            if (idx >= 0) {
                val c = _queue[idx]
                val updatedItems = c.items.map { item ->
                    if (item.status != DownloadStatus.FAILED && item.status != DownloadStatus.DONE) {
                        item.copy(status = DownloadStatus.DONE, finishedAt = System.currentTimeMillis())
                    } else item
                }
                val hasFailures = updatedItems.any { it.status == DownloadStatus.FAILED }
                val finalStatus = if (hasFailures) DownloadStatus.FAILED else DownloadStatus.DONE
                _queue[idx] = c.copy(
                    items = updatedItems,
                    legacyCurrent = if (c.legacyTotal > 0) c.legacyTotal else c.legacyCurrent,
                    status = statusMessage,
                    downloadStatus = finalStatus,
                    active = false,
                    finishedAt = System.currentTimeMillis()
                )
            }
        }
        unregisterCanceller(id)
    }

    fun finish(status: String) {
        val c = current ?: return
        finish(c.id, status)
    }

    /**
     * Marks job as failed.
     */
    fun fail(id: String, errorMessage: String) {
        synchronized(lock) {
            val idx = _queue.indexOfFirst { it.id == id }
            if (idx >= 0) {
                val c = _queue[idx]
                _queue[idx] = c.copy(
                    status = errorMessage,
                    errorMessage = errorMessage,
                    downloadStatus = DownloadStatus.FAILED,
                    active = false,
                    finishedAt = System.currentTimeMillis()
                )
            }
        }
        unregisterCanceller(id)
    }

    /**
     * Retries failed items in a specific job.
     */
    fun retryFailedItems(id: String) {
        var failedItemIds = emptyList<String>()
        synchronized(lock) {
            val idx = _queue.indexOfFirst { it.id == id }
            if (idx >= 0) {
                val c = _queue[idx]
                failedItemIds = c.items.filter { it.status == DownloadStatus.FAILED }.map { it.id }
                val updatedItems = c.items.map { item ->
                    if (item.status == DownloadStatus.FAILED) {
                        item.copy(status = DownloadStatus.QUEUED, errorMessage = null)
                    } else item
                }
                _queue[idx] = c.copy(
                    items = updatedItems,
                    downloadStatus = DownloadStatus.ACTIVE,
                    active = true,
                    status = "Retrying failed items...",
                    errorMessage = null
                )
            }
        }
        retryControllers[id]?.invoke(failedItemIds)
    }

    /**
     * Retries a single item in a job.
     */
    fun retryItem(jobId: String, itemId: String) {
        synchronized(lock) {
            val idx = _queue.indexOfFirst { it.id == jobId }
            if (idx >= 0) {
                val c = _queue[idx]
                val updatedItems = c.items.map { item ->
                    if (item.id == itemId) {
                        item.copy(status = DownloadStatus.QUEUED, errorMessage = null)
                    } else item
                }
                _queue[idx] = c.copy(
                    items = updatedItems,
                    downloadStatus = DownloadStatus.ACTIVE,
                    active = true,
                    status = "Retrying item...",
                    errorMessage = null
                )
            }
        }
        retryControllers[jobId]?.invoke(listOf(itemId))
    }

    /**
     * Retries all failed items across all jobs in the queue.
     */
    fun retryAllFailed() {
        val jobIds = synchronized(lock) {
            _queue.filter { it.failedCount > 0 || it.downloadStatus == DownloadStatus.FAILED }.map { it.id }
        }
        for (id in jobIds) {
            retryFailedItems(id)
        }
    }

    /**
     * Cancels an individual item in a job.
     */
    fun cancelItem(jobId: String, itemId: String) {
        synchronized(lock) {
            val idx = _queue.indexOfFirst { it.id == jobId }
            if (idx >= 0) {
                val c = _queue[idx]
                val updatedItems = c.items.map { item ->
                    if (item.id == itemId) {
                        item.copy(status = DownloadStatus.CANCELLED, errorMessage = "Cancelled by user")
                    } else item
                }
                _queue[idx] = c.copy(items = updatedItems)
            }
        }
    }

    // Callbacks registration
    fun registerCanceller(id: String, onCancel: () -> Unit) {
        cancellers[id] = onCancel
    }

    fun unregisterCanceller(id: String) {
        cancellers.remove(id)
        pauseControllers.remove(id)
        retryControllers.remove(id)
    }

    fun registerPauseController(id: String, onPauseToggle: (Boolean) -> Unit) {
        pauseControllers[id] = onPauseToggle
    }

    fun registerRetryController(id: String, onRetry: (List<String>?) -> Unit) {
        retryControllers[id] = onRetry
    }

    fun isCancelled(id: String): Boolean {
        return cancelledIds.contains(id)
    }

    fun cancel(id: String) {
        cancelledIds.add(id)
        cancellers[id]?.invoke()
        synchronized(lock) {
            val idx = _queue.indexOfFirst { it.id == id }
            if (idx >= 0) {
                val c = _queue[idx]
                val cancelledItems = c.items.map { item ->
                    if (!item.isFinished) item.copy(status = DownloadStatus.CANCELLED) else item
                }
                _queue[idx] = c.copy(
                    items = cancelledItems,
                    status = "Download cancelled",
                    downloadStatus = DownloadStatus.CANCELLED,
                    active = false,
                    finishedAt = System.currentTimeMillis()
                )
            }
        }
        unregisterCanceller(id)
    }

    fun togglePause(id: String) {
        synchronized(lock) {
            val idx = _queue.indexOfFirst { it.id == id }
            if (idx >= 0) {
                val c = _queue[idx]
                if (c.downloadStatus == DownloadStatus.ACTIVE) {
                    _queue[idx] = c.copy(
                        downloadStatus = DownloadStatus.PAUSED,
                        active = false,
                        status = "Paused"
                    )
                    pauseControllers[id]?.invoke(true)
                } else if (c.downloadStatus == DownloadStatus.PAUSED) {
                    _queue[idx] = c.copy(
                        downloadStatus = DownloadStatus.ACTIVE,
                        active = true,
                        status = "Resuming..."
                    )
                    pauseControllers[id]?.invoke(false)
                }
            }
        }
    }

    fun remove(id: String) {
        cancel(id)
        synchronized(lock) {
            _queue.removeAll { it.id == id }
        }
    }

    fun clearCompleted() {
        synchronized(lock) {
            _queue.removeAll { it.downloadStatus == DownloadStatus.DONE }
        }
    }

    fun clear() {
        synchronized(lock) {
            val toRemove = _queue.filter { it.isFinished }
            if (toRemove.isNotEmpty()) {
                _queue.removeAll(toRemove)
            } else {
                _queue.clear()
            }
        }
    }

    fun cancelAll() {
        synchronized(lock) {
            val activeIds = _queue.map { it.id }
            for (id in activeIds) {
                cancel(id)
            }
        }
    }

    /** Pauses a single job by id (no-op if it isn't currently active). */
    fun pauseJob(id: String) {
        val job = synchronized(lock) { _queue.firstOrNull { it.id == id } } ?: return
        if (job.downloadStatus == DownloadStatus.ACTIVE) togglePause(id)
    }

    /** Resumes a single job by id (no-op if it isn't currently paused). */
    fun resumeJob(id: String) {
        val job = synchronized(lock) { _queue.firstOrNull { it.id == id } } ?: return
        if (job.downloadStatus == DownloadStatus.PAUSED) togglePause(id)
    }

    /** Cancels a single job by id. Alias of [cancel] for call-site clarity in the queue UI. */
    fun cancelJob(id: String) = cancel(id)

    /** Retries the failed items of a single job by id. Alias of [retryFailedItems]. */
    fun retryJob(id: String) = retryFailedItems(id)

    /** Pauses every currently-active job in the queue. */
    fun pauseAll() {
        val activeIds = synchronized(lock) {
            _queue.filter { it.downloadStatus == DownloadStatus.ACTIVE }.map { it.id }
        }
        for (id in activeIds) {
            togglePause(id)
        }
    }
}
