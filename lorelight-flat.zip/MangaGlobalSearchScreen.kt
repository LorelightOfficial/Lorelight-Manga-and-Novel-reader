package com.lorelight.manga.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.lorelight.manga.model.sanitizedMangas
import eu.kanade.tachiyomi.extension.ExtensionManager
import eu.kanade.tachiyomi.extension.model.Extension
import tachiyomi.domain.source.service.SourceManager
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import eu.kanade.tachiyomi.source.CatalogueSource
import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.SManga
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.cancellation.CancellationException
import androidx.compose.ui.semantics.Role

private data class MangaSourceSearchState(
    val sourceId: Long,
    val sourceName: String,
    val lang: String,
    val loading: Boolean,
    val items: List<SManga>,
    val error: String?
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MangaGlobalSearchScreen(
    onBack: () -> Unit,
    onOpenManga: (Long, SManga) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val nsfwMode = remember(context) { readNsfwMode(context) }
    var isInitialLoading by remember { mutableStateOf(true) }
    var sources by remember { mutableStateOf<List<CatalogueSource>>(emptyList()) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            val sourceManager = Injekt.get<SourceManager>()
            sourceManager.isInitialized.first { it }
            val loaded = sourceManager.getOnlineSources()
            val installed = Injekt.get<ExtensionManager>().installedExtensionsFlow.value
            val extBySourceId = installed.flatMap { ext -> ext.sources.map { s -> s.id to ext } }.toMap()

            val sortedSources = when (nsfwMode) {
                NsfwFilterMode.NSFW_TOP ->
                    loaded.sortedWith(compareByDescending<CatalogueSource> { extBySourceId[it.id]?.isNsfw == true }.thenBy { it.name.lowercase() })
                NsfwFilterMode.NSFW_LAST ->
                    loaded.sortedWith(compareBy<CatalogueSource> { extBySourceId[it.id]?.isNsfw == true }.thenBy { it.name.lowercase() })
                NsfwFilterMode.NORMAL -> loaded.sortedBy { it.name.lowercase() }
            }
            sources = sortedSources
            isInitialLoading = false
        }
    }

    var query by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf(false) }
    val results = remember { mutableStateListOf<MangaSourceSearchState>() }

    fun runSearch() {
        val q = query.trim()
        if (q.isBlank() || sources.isEmpty()) return
        submitted = true
        results.clear()
        results.addAll(sources.map {
            MangaSourceSearchState(
                sourceId = it.id,
                sourceName = it.name,
                lang = it.lang,
                loading = true,
                items = emptyList(),
                error = null
            )
        })

        sources.forEach { source ->
            scope.launch(Dispatchers.IO) {
                try {
                    val items = withTimeoutOrNull(20_000L) {
                        val fList = try { source.getFilterList() } catch (_: Throwable) { FilterList() }
                        val mangasPage = source.getSearchManga(1, q, fList)
                        mangasPage.mangas.sanitizedMangas()
                    } ?: emptyList()

                    val idx = results.indexOfFirst { it.sourceId == source.id }
                    if (idx >= 0) {
                        results[idx] = results[idx].copy(loading = false, items = items)
                    }
                } catch (e: Throwable) {
                    if (e is CancellationException) throw e
                    val idx = results.indexOfFirst { it.sourceId == source.id }
                    if (idx >= 0) {
                        results[idx] = results[idx].copy(
                            loading = false,
                            error = e.localizedMessage ?: e.message ?: "Search failed"
                        )
                    }
                }
            }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                windowInsets = WindowInsets(0, 0, 0, 0),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    TextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        placeholder = { Text("Search all manga sources") },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { runSearch() }),
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                actions = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, contentDescription = "Clear") }
                    }
                }
            )
        }
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when {
                isInitialLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
                sources.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Install a manga source first", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                !submitted -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Type a title and press search", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                else -> LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(results.size) { i ->
                        MangaSourceResultBlock(results[i], onOpenManga)
                    }
                }
            }
        }
    }
}

@Composable
private fun MangaSourceResultBlock(
    r: MangaSourceSearchState,
    onOpenManga: (Long, SManga) -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = r.sourceName,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            if (r.loading) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            }
        }
        when {
            r.error != null -> Text(
                text = r.error,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            !r.loading && r.items.isEmpty() -> Text(
                text = "No results",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            else -> {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(r.items.size) { i ->
                        val manga = r.items[i]
                        Column(
                            Modifier
                                .width(100.dp)
                                .clickable(role = Role.Button) { onOpenManga(r.sourceId, manga) }
                        ) {
                            MangaCoverImage(
                                coverUrl = manga.thumbnail_url,
                                sourceId = r.sourceId,
                                title = manga.title,
                                modifier = Modifier
                                    .width(100.dp)
                                    .aspectRatio(0.7f)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = manga.title,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}
