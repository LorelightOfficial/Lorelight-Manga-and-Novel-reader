package com.lorelight.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index

/**
 * One row per chapter, per novel. This is the authoritative home for per-chapter
 * READ STATE, modelled on mihon's `Chapter`:
 *
 *  - [completed]    -> mihon `Chapter.read`         (chapter finished)
 *  - [lastPageRead] -> mihon `Chapter.lastPageRead` (resume point inside it)
 *  - [bookmark]     -> mihon `Chapter.bookmark`
 *  - [lastReadAt]   -> when the state last changed, for history/sorting
 *
 * Before this, the manga reader only stored a single position on the novel row,
 * so nothing could remember which chapters were done or where each one was left.
 *
 * IMPORTANT: the `defaultValue` on the three columns below MUST stay identical to
 * the DEFAULT clauses in MIGRATION_3_4. Room verifies the schema on open, and a
 * mismatch drops the app into the destructive fallback, which wipes the library.
 */
@Entity(
    tableName = "chapters",
    primaryKeys = ["novelId", "idx"],
    indices = [Index(value = ["novelId"])]
)
data class ChapterEntity(
    val novelId: String,
    val idx: Int,
    val title: String,
    val url: String,
    val completed: Boolean,
    /** 0-based page the reader was last on. Reset to 0 when marked unread. */
    @ColumnInfo(defaultValue = "0")
    val lastPageRead: Int = 0,
    @ColumnInfo(defaultValue = "0")
    val bookmark: Boolean = false,
    /** Epoch millis of the last read-state change; 0 = never read. */
    @ColumnInfo(defaultValue = "0")
    val lastReadAt: Long = 0L
)
