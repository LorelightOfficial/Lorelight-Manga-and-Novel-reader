package com.lorelight.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import dev.chrisbanes.haze.HazeState
import dev.chrisbanes.haze.hazeChild

@Immutable
data class GlassPalette(
    val container: Color,
    val content: Color,
    val secondaryContent: Color,
    val accent: Color,
    val borderTop: Color,
    val borderBottom: Color,
    val shadow: Color
)

@Composable
fun rememberGlassPalette(
    colorScheme: ColorScheme = MaterialTheme.colorScheme,
    tintAlpha: Float = 0.65f,
    borderAlpha: Float = 0.12f
): GlassPalette {
    val isLight = colorScheme.background.luminance() > 0.5f
    return remember(colorScheme, tintAlpha, borderAlpha, isLight) {
        if (isLight) {
            val lightGlassBase = lerp(colorScheme.surface, colorScheme.surfaceVariant, 0.20f)
            val effectiveAlpha = (0.75f + (tintAlpha.coerceIn(0.35f, 0.85f) - 0.35f) / 0.50f * 0.18f).coerceIn(0.72f, 0.94f)
            val container = lightGlassBase.copy(alpha = effectiveAlpha)
            val content = colorScheme.onSurface
            val secondaryContent = colorScheme.onSurfaceVariant
            val accent = colorScheme.primary
            val borderTop = Color.White.copy(alpha = 0.70f)
            val borderBottom = colorScheme.outline.copy(alpha = 0.22f)
            val shadow = Color(0x0E19241B)
            GlassPalette(
                container = container,
                content = content,
                secondaryContent = secondaryContent,
                accent = accent,
                borderTop = borderTop,
                borderBottom = borderBottom,
                shadow = shadow
            )
        } else {
            val container = colorScheme.surface.copy(alpha = tintAlpha)
            val content = colorScheme.onSurface
            val secondaryContent = colorScheme.onSurfaceVariant
            val accent = colorScheme.primary
            val borderTop = Color.White.copy(alpha = borderAlpha)
            val borderBottom = Color.White.copy(alpha = 0.01f)
            val shadow = Color.Black.copy(alpha = 0.10f)
            GlassPalette(
                container = container,
                content = content,
                secondaryContent = secondaryContent,
                accent = accent,
                borderTop = borderTop,
                borderBottom = borderBottom,
                shadow = shadow
            )
        }
    }
}

@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    hazeState: HazeState? = null,
    cornerRadius: Dp = 16.dp,
    shape: Shape? = null,
    borderAlpha: Float = 0.12f,
    tintAlpha: Float = 0.65f,
    content: @Composable BoxScope.() -> Unit
) {
    val isLight = MaterialTheme.colorScheme.background.luminance() > 0.5f
    val glassPalette = rememberGlassPalette(
        colorScheme = MaterialTheme.colorScheme,
        tintAlpha = tintAlpha,
        borderAlpha = borderAlpha
    )

    val panelShape = shape ?: RoundedCornerShape(cornerRadius)

    // Real-time blur is one of the more expensive things this app does per
    // frame. Battery saver trades it for the plain tinted surface below -
    // still glassy in color, just without the sampled backdrop blur.
    val motionLevel = LocalMotionLevel.current
    val glassModifier = if (hazeState != null && motionLevel.allowsHeavyBlur) {
        modifier.hazeChild(
            state = hazeState,
            shape = panelShape
        )
    } else {
        modifier
    }

    val glassColorScheme = if (isLight) {
        MaterialTheme.colorScheme.copy(
            onSurface = glassPalette.content,
            onSurfaceVariant = glassPalette.secondaryContent,
            primary = glassPalette.accent,
            surface = glassPalette.container,
            surfaceVariant = MaterialTheme.colorScheme.surfaceVariant,
            onPrimary = MaterialTheme.colorScheme.onPrimary,
            outline = glassPalette.borderBottom,
            outlineVariant = glassPalette.borderTop
        )
    } else {
        MaterialTheme.colorScheme
    }

    Box(
        modifier = glassModifier
            .shadow(
                elevation = 10.dp,
                shape = panelShape,
                clip = false,
                ambientColor = glassPalette.shadow,
                spotColor = glassPalette.shadow
            )
            .clip(panelShape)
            .background(glassPalette.container)
            // Physically-inspired glass optics, painted inside the clip so
            // they read as part of the pane rather than decoration on top.
            //
            // Real glass does four things a flat tint cannot:
            //  1. it catches ambient light near the top edge (refraction
            //     brightens where the pane bends toward the light);
            //  2. a soft diagonal sheen crosses it - the reflection of the
            //     light source itself, always off-axis, never centered;
            //  3. it self-shades along the bottom, where the pane's thickness
            //     absorbs and bends light away from the eye;
            //  4. its cut edge glows: a thin inner rim just inside the border
            //     that is brightest on the lit (top) side.
            .drawBehind {
                val w = size.width
                val h = size.height

                // 1. Top refraction bloom - strongest in the first quarter.
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = if (isLight) 0.38f else 0.09f),
                            Color.White.copy(alpha = if (isLight) 0.10f else 0.025f),
                            Color.Transparent
                        ),
                        startY = 0f,
                        endY = h * 0.45f
                    )
                )

                // 2. Diagonal specular sheen - a broad, faint band sweeping
                // from the upper-left, like a window reflecting the sky.
                drawRect(
                    brush = Brush.linearGradient(
                        colorStops = arrayOf(
                            0.00f to Color.Transparent,
                            0.30f to Color.Transparent,
                            0.45f to Color.White.copy(alpha = if (isLight) 0.14f else 0.05f),
                            0.52f to Color.White.copy(alpha = if (isLight) 0.20f else 0.075f),
                            0.60f to Color.White.copy(alpha = if (isLight) 0.10f else 0.035f),
                            0.72f to Color.Transparent,
                            1.00f to Color.Transparent
                        ),
                        start = Offset(0f, 0f),
                        end = Offset(w * 0.9f, h * 1.1f)
                    )
                )

                // 3. Bottom thickness shading - the pane darkens where its
                // depth turns light away from the viewer.
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.Black.copy(alpha = if (isLight) 0.045f else 0.16f)
                        ),
                        startY = h * 0.62f,
                        endY = h
                    )
                )

                // 4. Side falloff - barely-there vignette on both flanks so
                // the pane appears to curve away at its edges.
                drawRect(
                    brush = Brush.horizontalGradient(
                        colorStops = arrayOf(
                            0.00f to Color.Black.copy(alpha = if (isLight) 0.030f else 0.085f),
                            0.10f to Color.Transparent,
                            0.90f to Color.Transparent,
                            1.00f to Color.Black.copy(alpha = if (isLight) 0.030f else 0.085f)
                        )
                    )
                )
            }
            // Outer border: the pane's polished edge. Bright where lit
            // (top-left), falling to near-nothing at the bottom-right.
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colorStops = arrayOf(
                        0.0f to glassPalette.borderTop,
                        0.45f to lerp(glassPalette.borderTop, glassPalette.borderBottom, 0.6f),
                        1.0f to glassPalette.borderBottom
                    )
                ),
                shape = panelShape
            )
            // Inner rim light: a hairline just inside the edge, the classic
            // double-line signature of a real bevelled pane. Cooler and
            // fainter than the outer edge, top-weighted.
            .drawBehind {
                val rimInset = 1.6.dp.toPx()
                val rimR = (cornerRadius.toPx() - rimInset).coerceAtLeast(0f)
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = if (isLight) 0.42f else 0.14f),
                            Color.White.copy(alpha = if (isLight) 0.06f else 0.02f),
                            Color.Transparent
                        )
                    ),
                    topLeft = Offset(rimInset, rimInset),
                    size = androidx.compose.ui.geometry.Size(
                        size.width - rimInset * 2f,
                        size.height - rimInset * 2f
                    ),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(rimR, rimR),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 0.8.dp.toPx())
                )
            }
    ) {
        MaterialTheme(colorScheme = glassColorScheme) {
            CompositionLocalProvider(LocalContentColor provides glassPalette.content) {
                content()
            }
        }
    }
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    hazeState: HazeState? = null,
    cornerRadius: Dp = 16.dp,
    content: @Composable BoxScope.() -> Unit
) {
    GlassPanel(
        modifier = modifier,
        hazeState = hazeState,
        cornerRadius = cornerRadius,
        tintAlpha = 0.6f,
        content = content
    )
}

@Composable
fun GlassBottomSheet(
    modifier: Modifier = Modifier,
    hazeState: HazeState? = null,
    content: @Composable BoxScope.() -> Unit
) {
    GlassPanel(
        modifier = modifier,
        hazeState = hazeState,
        cornerRadius = 24.dp,
        tintAlpha = 0.7f,
        content = content
    )
}

@Composable
fun GlassDialog(
    modifier: Modifier = Modifier,
    hazeState: HazeState? = null,
    content: @Composable BoxScope.() -> Unit
) {
    GlassPanel(
        modifier = modifier,
        hazeState = hazeState,
        cornerRadius = 24.dp,
        tintAlpha = 0.75f,
        content = content
    )
}

/**
 * Theme wrapper that gives Material menus (DropdownMenu / ExposedDropdownMenu)
 * the same glass tint as the rest of the app. Menus live in their own popup
 * window, which cannot sample the content behind it for blur, so the pane
 * relies on a stronger translucent tint plus the shared glass content colors.
 */
@Composable
fun GlassMenuTheme(content: @Composable () -> Unit) {
    val base = MaterialTheme.colorScheme
    val palette = rememberGlassPalette(colorScheme = base, tintAlpha = 0.80f)
    val isLight = base.background.luminance() > 0.5f
    val menuContainer = if (isLight) {
        palette.container.copy(alpha = (palette.container.alpha + 0.06f).coerceAtMost(0.97f))
    } else {
        palette.container.copy(alpha = 0.90f)
    }
    MaterialTheme(
        colorScheme = base.copy(
            surface = menuContainer,
            surfaceContainer = menuContainer,
            surfaceContainerLow = menuContainer,
            surfaceContainerHigh = menuContainer,
            onSurface = palette.content,
            onSurfaceVariant = palette.secondaryContent,
            primary = palette.accent
        ),
        shapes = MaterialTheme.shapes.copy(
            extraSmall = RoundedCornerShape(16.dp)
        )
    ) {
        content()
    }
}

/**
 * Drop-in replacement for [androidx.compose.material3.DropdownMenu] with the
 * Lorelight glass pane treatment applied to its container and content colors.
 */
@Composable
fun GlassDropdownMenu(
    expanded: Boolean,
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
    offset: DpOffset = DpOffset(0.dp, 0.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    GlassMenuTheme {
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = onDismissRequest,
            modifier = modifier,
            offset = offset,
            content = content
        )
    }
}

@Composable
fun GlassTopBar(
    modifier: Modifier = Modifier,
    hazeState: HazeState? = null,
    content: @Composable BoxScope.() -> Unit
) {
    GlassPanel(
        modifier = modifier,
        hazeState = hazeState,
        cornerRadius = 0.dp,
        tintAlpha = 0.65f,
        content = content
    )
}
