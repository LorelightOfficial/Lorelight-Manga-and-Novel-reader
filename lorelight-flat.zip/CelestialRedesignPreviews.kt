package com.lorelight.ui.theme.modeswitch.celestial

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.center
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.tooling.preview.PreviewParameter
import androidx.compose.ui.tooling.preview.PreviewParameterProvider
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class NewExpressionProvider : PreviewParameterProvider<CelestialExpression> {
    override val values = CelestialExpression.entries.asSequence()
}
class StoneThemeProvider : PreviewParameterProvider<String> {
    override val values = sequenceOf("forest", "readerblood", "blackgold", "Satin Pink", "readerblacknew", "Ocean Blue", "cyne", "readerpurple", "readerwhite")
}

@Preview(name = "New expression catalogue", widthDp = 380, heightDp = 176, showBackground = true)
@Composable
private fun NewExpressionPreview(@PreviewParameter(NewExpressionProvider::class) expression: CelestialExpression) {
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface {
            Column(Modifier.fillMaxSize().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(expression.name.replace('_',' '), fontSize = 14.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        NewSeatedSprite("forest", 1f, expression)
                        Text("Sun / dark mode", fontSize = 12.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        NewSeatedSprite("readerblood", 0f, expression)
                        Text("Moon / light mode", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Preview(name = "Compact bowl / 64 dp panels", widthDp = 320, heightDp = 208, showBackground = true)
@Composable
private fun MaterialPreview(@PreviewParameter(StoneThemeProvider::class) theme: String) {
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface {
            Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(theme, fontSize = 14.sp)
                Box(Modifier.fillMaxWidth().height(80.dp), contentAlignment = Alignment.Center) {
                    Row(Modifier.fillMaxWidth().height(64.dp)) {
                        Box(Modifier.weight(1f).fillMaxHeight().background(Color(0xFF333B40), RoundedCornerShape(24.dp)))
                        Spacer(Modifier.width(88.dp))
                        Box(Modifier.weight(1f).fillMaxHeight().background(Color(0xFF333B40), RoundedCornerShape(24.dp)))
                    }
                    NewSeatedSprite(theme, 1f, CelestialExpression.NEUTRAL)
                }
                Text("Code-drawn bowl. Fixed character centre.", fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun NewSeatedSprite(theme: String, form: Float, expression: CelestialExpression) {
    Canvas(Modifier.size(96.dp, 72.dp)) {
        drawCelestialAltar(size, isLight = form < .5f, openAmount = 0f, timeSec = 0f, themeId = theme)
        drawCelestialBody(size.center, 64.dp.toPx() * CELESTIAL_BODY_RADIUS_FRACTION, form, celestialPose(expression), 0f)
    }
}
