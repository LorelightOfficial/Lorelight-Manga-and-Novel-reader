package eu.kanade.tachiyomi.ui.base.delegate

import eu.kanade.domain.ui.model.AppTheme

/**
 * Minimal theming delegate for the reader-theme context.
 *
 * Lorelight already applies its own base theme (R.style.Theme_Lorelight) via a
 * ContextThemeWrapper before this is called, so no additional style overlays are
 * required. Returning an empty list keeps the current look unchanged while still
 * satisfying the reader night-mode context wrapper. AMOLED or per-theme overlays
 * can be added here later without affecting the app's own theming.
 */
object ThemingDelegate {

    fun getThemeResIds(appTheme: AppTheme, isAmoled: Boolean): List<Int> {
        return emptyList()
    }
}
