package com.lorelight.data.db

import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * FIX A1 + A8: one single serialized writer for ALL persistence.
 *
 * THE BUGS THIS FIXES
 * -------------------
 * 1. Progress writes and full-library writes used two DIFFERENT concurrency
 *    primitives. Library saves went through `NovelPreferences.saveMutex`, while
 *    progress saves went straight to Room from an unsynchronised coroutine. Two
 *    writers with no shared ordering means a full-library save built from a
 *    slightly older in-memory list could land AFTER a fresh progress write and
 *    roll the reading position backwards.
 *
 * 2. "Flush now" paths (TTS pause, activity onPause/onStop) launched a
 *    fire-and-forget coroutine and returned immediately, so the process could
 *    die before the write ever reached disk.
 *
 * 3. Snapshot files and SharedPreferences.commit() ran on the calling thread,
 *    which for lifecycle callbacks is the main thread -> visible stutter on
 *    large libraries.
 *
 * HOW IT WORKS
 * ------------
 * A single background thread executes every write in submission order, so there
 * is a total order across progress rows, library rows, history rows and rescue
 * snapshots. [awaitBlocking] and [drainBlocking] let shutdown paths wait for
 * that queue to actually reach disk instead of hoping it does.
 *
 * Never call [awaitBlocking] or [drainBlocking] from inside a block already
 * running on the writer thread - that would deadlock. Use [isWriterThread] if a
 * call site cannot know.
 */
object DbWriter {

    private const val TAG = "DbWriter"
    private const val THREAD_NAME = "lorelight-db-writer"

    private val pending = AtomicInteger(0)

    private val executor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, THREAD_NAME).apply {
            priority = Thread.NORM_PRIORITY
        }
    }

    /** Number of writes queued or in flight. Surfaced by diagnostics/settings. */
    fun pendingWrites(): Int = pending.get()

    fun isWriterThread(): Boolean = Thread.currentThread().name == THREAD_NAME

    /** Queue a write. Returns immediately; ordering against other writes is kept. */
    fun submit(tag: String, block: () -> Unit) {
        if (isWriterThread()) {
            // Already serialized - run inline rather than deadlocking on ourselves.
            runGuarded(tag, block)
            return
        }
        pending.incrementAndGet()
        try {
            executor.execute {
                try {
                    runGuarded(tag, block)
                } finally {
                    pending.decrementAndGet()
                }
            }
        } catch (t: Throwable) {
            pending.decrementAndGet()
            android.util.Log.e(TAG, "Could not queue write: $tag", t)
        }
    }

    /**
     * Queue a write and block until it has actually run.
     *
     * Used by shutdown / "flush now" paths. Returns true when the write
     * completed within [timeoutMs].
     */
    fun awaitBlocking(tag: String, timeoutMs: Long = DEFAULT_TIMEOUT_MS, block: () -> Unit): Boolean {
        if (isWriterThread()) {
            runGuarded(tag, block)
            return true
        }
        pending.incrementAndGet()
        val future: Future<*> = try {
            executor.submit {
                try {
                    runGuarded(tag, block)
                } finally {
                    pending.decrementAndGet()
                }
            }
        } catch (t: Throwable) {
            pending.decrementAndGet()
            android.util.Log.e(TAG, "Could not queue blocking write: $tag", t)
            // Last resort: do it here so the data is not silently dropped.
            runGuarded(tag, block)
            return true
        }
        return try {
            future.get(timeoutMs, TimeUnit.MILLISECONDS)
            true
        } catch (t: Throwable) {
            android.util.Log.e(TAG, "Blocking write did not finish in ${timeoutMs}ms: $tag", t)
            false
        }
    }

    /**
     * Blocks until every write queued so far has run. Because the queue is FIFO,
     * an empty task submitted now can only run after all earlier writes.
     */
    fun drainBlocking(timeoutMs: Long = DEFAULT_TIMEOUT_MS): Boolean =
        awaitBlocking("drain", timeoutMs) { }

    private fun runGuarded(tag: String, block: () -> Unit) {
        try {
            block()
        } catch (t: Throwable) {
            android.util.Log.e(TAG, "Write failed: $tag", t)
        }
    }

    const val DEFAULT_TIMEOUT_MS = 4_000L
}
