package com.lorelight.utils

import android.content.ComponentCallbacks2
import android.content.Context
import coil.imageLoader
import com.lorelight.ui.components.clearBase64ImageCache

/**
 * Lightweight, dependency-free memory monitor.
 *
 * Wired into [com.lorelight.LorelightApplication.onTrimMemory]. When the app's
 * UI is fully hidden (i.e. the app has gone to the background) or the system is
 * under memory pressure, we proactively free the heaviest allocations:
 *  - Coil's in-memory bitmap cache (cover thumbnails, avatars, website images)
 *  - Our own decoded Base64 / EPUB cover-bitmap cache
 *
 * Everything here can be rebuilt lazily on next use, so clearing it is safe and
 * cheap -- it just trades a tiny reload cost for lower idle memory.
 */
object MemoryManager {

    /**
     * Called from Application.onTrimMemory. TRIM_MEMORY_UI_HIDDEN fires exactly
     * when the app leaves the foreground; higher levels mean the system is low
     * on memory while we are cached in the background.
     */
    fun onTrimMemory(context: Context, level: Int) {
        if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN) {
            releaseHeavyMemory(context)
        }
    }

    /** Frees the heavy image / EPUB allocations. Safe to call at any time. */
    fun releaseHeavyMemory(context: Context) {
        // 1. Coil in-memory image cache for page loader, cover loader, and default loader.
        runCatching {
            com.lorelight.manga.reader.MangaImageLoaderProvider.getImageLoader(context).memoryCache?.clear()
        }
        runCatching {
            com.lorelight.manga.reader.MangaImageLoaderProvider.getCoverImageLoader(context).memoryCache?.clear()
        }
        runCatching {
            context.applicationContext.imageLoader.memoryCache?.clear()
        }
        // 2. Decoded EPUB / Base64 cover bitmaps we keep ourselves.
        runCatching {
            clearBase64ImageCache()
        }
    }
}
