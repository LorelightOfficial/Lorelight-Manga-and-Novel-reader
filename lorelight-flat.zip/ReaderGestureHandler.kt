package com.lorelight.ui.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.TimeoutCancellationException
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.utils.Token

@Composable
fun WordSpanView(
    token: Token,
    isSelected: Boolean,
    highlightColor: Color,
    textColor: Color,
    fontSize: Float,
    currentFontFamily: FontFamily?,
    isCaveat: Boolean,
    selectionVersion: Int,
    selRange: WordRange?,
    onPositioned: (Offset, Offset) -> Unit,
    onWordSelected: (WordRange, Boolean) -> Unit,
    wordPositions: SnapshotStateMap<Int, WordPosition>,
    persistentHighlightColor: Color? = null
) {
    var viewLayoutCoords by remember { mutableStateOf<LayoutCoordinates?>(null) }
    var accumulatedDragOffset by remember(selectionVersion) { mutableStateOf(Offset.Zero) }
    var lastClosestIdx by remember(selectionVersion, token.wordIdx) { mutableStateOf(token.wordIdx) }
    val haptic = LocalHapticFeedback.current
    val currentSelRange by rememberUpdatedState(selRange)

    Box(
        modifier = Modifier
            .graphicsLayer {
                // Cache word rendering onto a hardware GPU layer to eliminate subpixel layout/font-hinting wiggles during scroll/drag
                clip = false
            }
            .pointerInput(token.wordIdx, selectionVersion) {
                detectConflictFreeDragGesturesAfterLongPress(
                    onDragStart = { offset ->
                        val currentWordPos = wordPositions[token.wordIdx]
                        if (currentWordPos != null) {
                            accumulatedDragOffset = currentWordPos.leftAnchor + offset
                        } else {
                            val rootOffset = viewLayoutCoords?.localToRoot(offset)
                            if (rootOffset != null) {
                                accumulatedDragOffset = rootOffset
                            }
                        }
                        lastClosestIdx = token.wordIdx
                        onWordSelected(WordRange(token.wordIdx, token.wordIdx), true)
                        try {
                            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                        } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError("ReaderGestureHandler.Haptic", e) }
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        accumulatedDragOffset += dragAmount
                        
                        var closestIdx = -1
                        var minDistance = Float.MAX_VALUE
                        for ((idx, wPos) in wordPositions) {
                            val wordCenter = Offset(
                                (wPos.leftAnchor.x + wPos.rightAnchor.x) / 2f,
                                (wPos.leftAnchor.y + wPos.rightAnchor.y) / 2f
                            )
                            val distX = accumulatedDragOffset.x - wordCenter.x
                            val distY = accumulatedDragOffset.y - wordCenter.y
                            val dist = distX * distX + distY * distY
                            if (dist < minDistance) {
                                minDistance = dist
                                closestIdx = idx
                            }
                        }
                        if (closestIdx != -1) {
                            if (lastClosestIdx != closestIdx) {
                                lastClosestIdx = closestIdx
                                onWordSelected(WordRange(token.wordIdx, closestIdx), true)
                                try {
                                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                                } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError("ReaderGestureHandler.Haptic", e) }
                            }
                        }
                    },
                    onDragEnd = {
                        if (currentSelRange != null) {
                            onWordSelected(WordRange(token.wordIdx, lastClosestIdx), false)
                        }
                    },
                    onDragCancel = {
                        if (currentSelRange != null) {
                            onWordSelected(WordRange(token.wordIdx, lastClosestIdx), false)
                        }
                    }
                )
            }
            .onGloballyPositioned { coords ->
                viewLayoutCoords = coords
                if (coords.isAttached) {
                    val h = coords.size.height.toFloat()
                    val w = coords.size.width.toFloat()
                    val leftAnchor = coords.localToRoot(Offset(0f, h))
                    val rightAnchor = coords.localToRoot(Offset(w, h))
                    onPositioned(leftAnchor, rightAnchor)
                }
            }
    ) {
        val backgroundModifier = if (isSelected) {
            Modifier
                .background(
                    color = highlightColor.copy(alpha = 0.28f),
                    shape = RoundedCornerShape(4.dp)
                )
                .border(
                    width = 0.5.dp,
                    color = highlightColor.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(4.dp)
                )
        } else if (persistentHighlightColor != null) {
            Modifier
                .background(
                    color = persistentHighlightColor.copy(alpha = 0.45f),
                    shape = RoundedCornerShape(4.dp)
                )
        } else {
            Modifier
        }
        Text(
            text = token.raw,
            style = MaterialTheme.typography.bodyLarge.copy(
                fontSize = fontSize.sp,
                fontFamily = currentFontFamily,
                fontStyle = if (isCaveat) FontStyle.Italic else FontStyle.Normal,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            ),
            color = if (isSelected) {
                if (highlightColor == Color(0xFF555555)) Color.Black else highlightColor
            } else textColor,
            modifier = Modifier
                .then(backgroundModifier)
                .padding(horizontal = 2.dp, vertical = 1.dp)
        )
    }
}

suspend fun androidx.compose.ui.input.pointer.PointerInputScope.detectConflictFreeDragGesturesAfterLongPress(
    onDragStart: (Offset) -> Unit,
    onDrag: (change: androidx.compose.ui.input.pointer.PointerInputChange, dragAmount: Offset) -> Unit,
    onDragEnd: () -> Unit,
    onDragCancel: () -> Unit,
    onTap: () -> Unit = {}
) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = true)
        if (down.isConsumed) return@awaitEachGesture

        var dragStartOffset = down.position
        var longPressed = false
        var isAborted = false
        var wasTap = false

        try {
            withTimeout(viewConfiguration.longPressTimeoutMillis) {
                while (true) {
                    val event = awaitPointerEvent()
                    if (event.changes.count { it.pressed } >= 2) {
                        isAborted = true
                        throw Exception("Abort")
                    }
                    val mainChange = event.changes.firstOrNull { it.id == down.id }
                    if (mainChange == null || !mainChange.pressed || mainChange.isConsumed) {
                        // Finger lifted before the long-press fired and without dragging => treat as a tap.
                        if (mainChange != null && !mainChange.pressed) {
                            val releasePan = mainChange.position - down.position
                            if (releasePan.getDistance() <= viewConfiguration.touchSlop) {
                                wasTap = true
                            }
                        }
                        isAborted = true
                        throw Exception("Released")
                    }
                    val pan = mainChange.position - down.position
                    if (pan.getDistance() > viewConfiguration.touchSlop) {
                        isAborted = true
                        throw Exception("Moved")
                    }
                }
            }
        } catch (e: TimeoutCancellationException) {
            longPressed = true
        } catch (e: Exception) {
            isAborted = true
        }

        if (wasTap && !longPressed) {
            onTap()
            return@awaitEachGesture
        }

        if (longPressed && !isAborted) {
            onDragStart(dragStartOffset)
            var currentPointerId = down.id
            var dragSuccess = false
            try {
                do {
                    val event = awaitPointerEvent()
                    val change = event.changes.firstOrNull { it.id == currentPointerId }
                    if (change == null || !change.pressed || change.isConsumed) {
                        break
                    }
                    val dragAmount = change.position - change.previousPosition
                    onDrag(change, dragAmount)
                } while (event.changes.any { it.pressed })
                dragSuccess = true
            } finally {
                if (dragSuccess) {
                    onDragEnd()
                } else {
                    onDragCancel()
                }
            }
        }
    }
}
