package com.lorelight.ui.settings

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material3.*
import com.lorelight.ui.components.LorelightDialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lorelight.manga.ui.MangaSourcesCache
import com.lorelight.manga.util.MangaLanguages
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import eu.kanade.tachiyomi.extension.ExtensionManager
import eu.kanade.tachiyomi.extension.model.Extension
import tachiyomi.domain.source.service.SourceManager
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun MangaSourcesSettingsSection() {
    val context = LocalContext.current

    val sourceManager = remember { Injekt.get<SourceManager>() }
    var installedSources by remember { mutableStateOf(sourceManager.getOnlineSources()) }

    LaunchedEffect(Unit) {
        sourceManager.sources.collectLatest {
            installedSources = sourceManager.getOnlineSources()
        }
    }

    val presentLangs = remember(installedSources) {
        installedSources.map { it.lang }.filter { it.isNotBlank() }.distinct().toSet()
    }

    val settingsVersion by com.lorelight.data.local.AppSettingsSignal.version.collectAsState()
    var selectedLangs by remember(presentLangs, settingsVersion) {
        mutableStateOf(MangaLanguages.effective(context, presentLangs))
    }

    fun updateSelection(newSelection: Set<String>) {
        val finalSelection = if (newSelection.isEmpty()) presentLangs else newSelection
        selectedLangs = finalSelection
        MangaLanguages.writeSelected(context, finalSelection)
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "SOURCE LANGUAGES",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(start = 4.dp, top = 8.dp)
        )

        Text(
            text = "Only sources in the selected languages are shown when browsing.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 4.dp)
        )

        if (presentLangs.isEmpty()) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                border = borderIndicator(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No manga sources installed yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = { updateSelection(presentLangs) }
                ) {
                    Text("Select all")
                }
                Spacer(Modifier.width(8.dp))
                TextButton(
                    onClick = { updateSelection(MangaLanguages.defaultFor(presentLangs)) }
                ) {
                    Text("Reset to default")
                }
            }

            val langSourceCounts = remember(installedSources) {
                installedSources.groupBy { it.lang }.mapValues { it.value.size }
            }

            val sortedLangs = remember(presentLangs) {
                presentLangs.sortedWith(
                    compareBy<String> { if (it.equals("all", true)) 0 else 1 }
                        .thenBy { MangaLanguages.displayName(it).lowercase() }
                )
            }

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                border = borderIndicator(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(vertical = 4.dp)) {
                    sortedLangs.forEach { lang ->
                        val isChecked = selectedLangs.contains(lang)
                        val sourceCount = langSourceCounts[lang] ?: 0

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { checked ->
                                    val next = if (checked) selectedLangs + lang else selectedLangs - lang
                                    updateSelection(next)
                                }
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = MangaLanguages.displayName(lang),
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "$sourceCount ${if (sourceCount == 1) "source" else "sources"}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MangaInstalledExtensionsSection(
    onChanged: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val extensionManager = remember { Injekt.get<ExtensionManager>() }
    var installedExtensions by remember { mutableStateOf<List<Extension.Installed>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var busyPkgs by remember { mutableStateOf(setOf<String>()) }
    var extensionToUninstall by remember { mutableStateOf<Extension.Installed?>(null) }

    // The real extension manager keeps this list up to date on its own
    // (install, update, uninstall all flow through here automatically).
    LaunchedEffect(Unit) {
        extensionManager.installedExtensionsFlow.collectLatest { list ->
            installedExtensions = list
            isLoading = false
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "INSTALLED EXTENSIONS (${installedExtensions.size})",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(start = 4.dp, top = 8.dp)
        )

        if (isLoading) {
            com.lorelight.ui.components.LorelightLoading(
                shape = com.lorelight.ui.components.LoadingShape.LIST_ROWS,
                itemCount = 4,
                modifier = Modifier.fillMaxWidth()
            )
        } else if (installedExtensions.isEmpty()) {
            com.lorelight.ui.components.LorelightEmpty(
                title = "No manga extensions installed",
                message = "Install extensions from the Browse tab to see them here.",
                compact = true,
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                installedExtensions.forEach { ext ->
                    val isBusy = busyPkgs.contains(ext.pkgName)
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        border = borderIndicator(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val extIcon = ext.icon
                            if (extIcon != null) {
                                Image(
                                    bitmap = remember(extIcon) { extIcon.toBitmap().asImageBitmap() },
                                    contentDescription = ext.name,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.primaryContainer),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Extension,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }

                            Spacer(Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = ext.name,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f, fill = false)
                                    )
                                    if (ext.isNsfw) {
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            "18+",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }
                                    if (!ext.isShared) {
                                        Spacer(Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = MaterialTheme.colorScheme.tertiaryContainer
                                        ) {
                                            Text(
                                                "Private",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onTertiaryContainer,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = "${MangaLanguages.displayName(ext.lang)} • v${ext.versionName} • ${ext.sources.size} ${if (ext.sources.size == 1) "source" else "sources"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Spacer(Modifier.width(8.dp))

                            if (isBusy) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    strokeWidth = 2.dp
                                )
                            } else {
                                OutlinedButton(
                                    onClick = { extensionToUninstall = ext },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = MaterialTheme.colorScheme.error
                                    )
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Delete,
                                        contentDescription = "Uninstall",
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text("Uninstall", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    val toUninstall = extensionToUninstall
    if (toUninstall != null) {
        LorelightDialog(
            onDismissRequest = { extensionToUninstall = null },
            title = { Text("Uninstall ${toUninstall.name}?") },
            text = { Text("Its manga sources will be removed from Browse.") },
            isDestructive = true,
            confirmButton = {
                TextButton(
                    onClick = {
                        val pkg = toUninstall.pkgName
                        val displayName = toUninstall.name
                        extensionToUninstall = null
                        scope.launch {
                            busyPkgs = busyPkgs + pkg
                            // The real extension manager opens the system uninstaller
                            // and updates installedExtensionsFlow by itself once done.
                            extensionManager.uninstallExtension(toUninstall)
                            busyPkgs = busyPkgs - pkg

                            MangaSourcesCache.clear()
                            onChanged()
                            Toast.makeText(context, "Uninstalling $displayName", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("Uninstall", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { extensionToUninstall = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

