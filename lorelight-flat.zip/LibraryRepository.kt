package com.lorelight.data.repository

import android.content.Context
import com.lorelight.data.chapters.ChapterReadStore
import com.lorelight.data.db.ProgressStore
import com.lorelight.data.local.AppSettingsSignal
import com.lorelight.data.local.NovelPreferences
import com.lorelight.data.local.ReadingPositionStore
import com.lorelight.data.local.ReadingProgressSignal
import com.lorelight.data.model.Novel
import com.lorelight.data.model.Website
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import com.lorelight.data.model.Highlight

/**
 * THE SINGLE PUBLIC SURFACE FOR LIBRARY STATE.
 *
 * WHAT PROBLEM THIS SOLVES
 * ------------------------
 * Library state is spread across four stores:
 *
 *   1. NovelPreferences - the novels list, which lives in the Room novels
 *      table, NOT in SharedPreferences despite the name. The progress
 *      fields are MIRRORED onto each Novel row here. The legacy prefs JSON
 *      was migrated once and is kept, renamed, as a backup that is never
 *      read again.
 *   2. ProgressStore    - a Room reading_progress table, one row per novel.
 *      This is the hot path, rewritten on every page turn, because rewriting
 *      the whole novels JSON that often would be absurd.
 *   3. ReadingPositionStore - SharedPreferences holding the exact scroll
 *      position per novel PER CHAPTER, plus a layout signature so a stale
 *      pixel offset can be thrown away when typography changes.
 *   4. ChapterReadStore - one small JSON file per series holding per-chapter
 *      completed / bookmarked / current state, keyed by chapter URL.
 *
 * ProgressStore's own comments call these "three position systems". That is
 * the disagreement the plan describes: which one is right depends on which
 * screen you ask.
 *
 * WHAT ALREADY RECONCILES THESE, AND WHY NOT TO ADD ANOTHER
 * ---------------------------------------------------------
 * The plan for this section asks for a one-shot reconciler on first launch.
 * Most of one already exists, spread through loadNovelsFromPrefs:
 *
 *   - migrateNovelsFromPrefsIfNeeded moves the legacy prefs JSON into Room
 *     once, behind a room_migration_done flag, and keeps the JSON as backup.
 *   - a rescue snapshot restores the library when Room opens but reads back
 *     empty, and a FAILED read is never cached and never saved over.
 *   - ProgressStore.backfillIfNeeded seeds reading_progress once, behind its
 *     own flag.
 *   - ProgressStore.overlay layers reading_progress over the novel rows and
 *     syncAll writes them back. Both are NEWEST TIMESTAMP WINS in each
 *     direction, so a half-written row cannot drag a position backwards.
 *
 * The merge rule the plan wants is therefore already implemented and
 * load-bearing. A second reconciler laid on top would race the first over
 * the same rows, and the failure would look like progress randomly moving.
 * What is genuinely missing is narrower: ChapterReadStore and
 * ReadingPositionStore take no part in that timestamp negotiation.
 *
 * WHY THIS IS A FACADE AND NOT A REWRITE
 * --------------------------------------
 * Collapsing those four into one store is NOT safe to do blind, and each of
 * them exists for a reason that is documented at its own definition:
 *
 *  - ChapterReadStore is a deliberate rewrite that REPLACED a Room table. Its
 *    header explains that read marks used to be keyed by a chapter's index,
 *    so a single new chapter on a newest-first source shifted every mark by
 *    one. Folding it back into Room would reintroduce a fixed bug.
 *  - ReadingPositionStore's per-chapter keys carry a v1 migration that must
 *    not be dropped, or every existing user loses their saved position once.
 *  - The buffered write path in TtsPlaybackManager exists for battery: the
 *    position save was deliberately moved OUT of the per-sentence path and
 *    into the flush, and that comment warns against putting it back.
 *
 * So the first move is to make every caller come through one door, WITHOUT
 * changing what happens behind it. Once all callers are here, the stores
 * behind this object can be merged one at a time, and the blast radius of
 * each merge is this file rather than the whole app.
 *
 * THE RULE FOR CALLERS
 * --------------------
 * UI observes flows from here and writes through here. UI does not call
 * NovelPreferences, ProgressStore, ReadingPositionStore or ChapterReadStore
 * directly. Where that is not yet true it is a known remaining migration,
 * tracked in PLAN_O.txt under O2, not an invitation to add more.
 */
object LibraryRepository {

    // ---------------------------------------------------------------------
    // READS
    // ---------------------------------------------------------------------

    /**
     * The library, re-read whenever a reading position is persisted or a
     * setting changes.
     *
     * Both signals are StateFlows, so this emits once immediately on collect
     * rather than waiting for the first change. Reads happen on the IO
     * dispatcher because loadNovels parses JSON, and identical successive
     * lists are dropped so a signal bump that changed nothing visible does
     * not cause a recomposition.
     */
    fun observeLibrary(context: Context): Flow<List<Novel>> {
        val app = context.applicationContext
        return combine(
            ReadingProgressSignal.version,
            AppSettingsSignal.version
        ) { progress, settings -> progress to settings }
            .map { withContext(Dispatchers.IO) { loadLibrary(app) } }
            .distinctUntilChanged()
    }

    /** A single entry, tracked live. Emits null once the novel is removed. */
    fun observeEntry(context: Context, novelId: String): Flow<Novel?> =
        observeLibrary(context)
            .map { list -> list.firstOrNull { it.id == novelId } }
            .distinctUntilChanged()

    /**
     * Per-chapter read / bookmark / current state for one series.
     *
     * This is already a live StateFlow that publishes a mark in the same frame
     * it is made, so it is exposed as-is rather than being wrapped.
     */
    fun observeChapterState(context: Context, novelId: String): StateFlow<ChapterReadStore.Snapshot> =
        ChapterReadStore.observe(context, novelId)

    /**
     * A one-shot read of the library, progress already overlaid.
     *
     * loadNovelsFromPrefs applies the Room progress overlay internally, so the
     * rows this returns already carry the freshest position rather than the
     * possibly-stale copy mirrored in the JSON.
     */
    fun loadLibrary(context: Context): List<Novel> =
        NovelPreferences.loadNovelsFromPrefs(context)

    /** The entry the Continue Reading affordance should point at, or null. */
    fun pickResumeEntry(novels: List<Novel>): Novel? =
        NovelPreferences.pickResumeNovel(novels)

    /** The freshest stored position for one novel, or null if none recorded. */
    fun storedProgressFor(context: Context, novelId: String) =
        ProgressStore.loadProgress(context, novelId)

    // ---------------------------------------------------------------------
    // WRITES
    // ---------------------------------------------------------------------

    /**
     * Replace the whole library.
     *
     * allowEmpty defaults to false on purpose: an empty list is nearly always
     * a failed load rather than a real "the user deleted everything", and
     * writing it would destroy the library. Callers that genuinely mean it
     * must say so.
     */
    fun saveLibrary(context: Context, novels: List<Novel>, allowEmpty: Boolean = false) {
        NovelPreferences.saveNovelsToPrefs(context, novels, allowEmpty)
    }

    /** Blocking variant of [saveLibrary], for call sites that cannot lose the write (e.g. onPause). */
    fun saveLibrarySync(context: Context, novels: List<Novel>, allowEmpty: Boolean = false) {
        NovelPreferences.saveNovelsToPrefsSync(context, novels, allowEmpty)
    }

    /** The saved website/source list. */
    fun loadWebsites(context: Context): List<Website> =
        NovelPreferences.loadWebsitesFromPrefs(context)

    /** Replace the whole website/source list. */
    fun saveWebsites(context: Context, websites: List<Website>) {
        NovelPreferences.saveWebsitesToPrefs(context, websites)
    }

    /** Blocking variant of [saveWebsites]. */
    fun saveWebsitesSync(context: Context, websites: List<Website>) {
        NovelPreferences.saveWebsitesToPrefsSync(context, websites)
    }

    /** Drops the in-memory novels/history cache so the next read hits disk. */
    fun invalidateCache() {
        NovelPreferences.invalidateCache()
    }

    /**
     * Progress for one novel: the hot path.
     *
     * Goes to the Room row via the app's single writer thread, and notifies
     * ReadingProgressSignal so every screen showing this novel updates. The
     * whole novels JSON is NOT rewritten here.
     */
    fun setProgress(context: Context, novel: Novel) {
        NovelPreferences.saveProgressOnly(context, novel)
    }

    /**
     * The same write, but blocking, for the cases that cannot afford to lose
     * it: process death, an explicit flush, a backup about to be taken.
     * Returns whether it actually reached disk.
     */
    fun setProgressBlocking(context: Context, novel: Novel): Boolean =
        NovelPreferences.saveProgressOnlySync(context, novel)

    /**
     * Record where the reader is, from the reader.
     *
     * This is the ONE place that knows a reader position has two destinations,
     * and it deliberately keeps them distinct rather than collapsing them:
     *
     *  - The exact scroll position goes to ReadingPositionStore IMMEDIATELY.
     *    It is called on close and on backgrounding, which are exactly the
     *    moments a position must not be lost.
     *  - The paragraph / offset / word triple goes into the buffered progress
     *    pipeline, which coalesces writes and flushes on its own schedule.
     *    That buffering is a battery decision documented in
     *    TtsPlaybackManager, and defeating it here would restore a bug where
     *    a blocking disk write ran on every sentence.
     *
     * The guards match the previous behaviour exactly. The position write is
     * skipped when there is nothing meaningful to record - no novel, no
     * chapter, or a list that has not measured yet, since a fraction computed
     * from zero items would be garbage. The buffered write is NOT guarded,
     * because it was not guarded before and it is what carries the paragraph
     * the user was actually on.
     *
     * recordDetailedProgress is OPTIONAL, and that is load-bearing. The
     * reader saves position on close, on backgrounding, and again a beat
     * after scrolling settles. Only the first two should also touch the
     * buffered pipeline. Passing null is how a caller says position only.
     */
    fun recordReaderPosition(
        context: Context,
        novelId: String,
        chapterIndex: Int,
        itemIndex: Int,
        offset: Int,
        totalItems: Int,
        lastVisibleIndex: Int,
        layoutSig: Int,
        wordIndex: Int,
        recordDetailedProgress: ((Int, Int, Int) -> Unit)? = null
    ) {
        if (novelId.isNotEmpty() && chapterIndex >= 0 && totalItems > 0) {
            val fraction = ((lastVisibleIndex + 1).toFloat() / totalItems).coerceIn(0f, 1f)
            ReadingPositionStore.save(
                context = context,
                novelId = novelId,
                chapterIndex = chapterIndex,
                index = itemIndex,
                offset = offset,
                fraction = fraction,
                layoutSig = layoutSig
            )
        }
        recordDetailedProgress?.invoke(itemIndex, offset, wordIndex)
    }

    /** The stored scroll position for a chapter, or null if none recorded. */
    fun loadReaderPosition(context: Context, novelId: String, chapterIndex: Int) =
        ReadingPositionStore.load(context, novelId, chapterIndex)

    /** Where a chapter should open, and which store decided it. */
    data class ResolvedPosition(
        val index: Int,
        val offset: Int,
        /** Short tag naming the winner. Cheap to log, safe to ignore. */
        val source: String
    )

    /**
     * Decide where a chapter should open.
     *
     * Two things claim to know where you were, and until now the reader simply
     * preferred one of them:
     *
     *  1. ReadingPositionStore - a position PER CHAPTER, with a pixel offset
     *     and a layout signature. Written on close, on backgrounding, and a
     *     beat after scrolling settles.
     *  2. The novel row - ONE paragraph index and offset, belonging to
     *     whichever chapter the row calls current, carrying lastReadTimestamp.
     *     This is the copy that travels: it is what a backup restores and what
     *     other screens display.
     *
     * The old rule was "the stored position wins if it exists". That is wrong
     * in one direction and dangerous in the other:
     *
     *  - Restore a backup onto a device that still holds its own older prefs
     *    and the stale local position silently beat the restored one. Neither
     *    copy carried a write time, so it was not even detectable. That is why
     *    the store now stamps its writes.
     *  - When nothing was stored, the row was applied REGARDLESS of which
     *    chapter it describes. Opening a chapter for the first time could jump
     *    you to paragraph 412 of it because that is where you were in a
     *    different chapter. Position without chapter identity is not a
     *    position - the same lesson ChapterReadStore encodes by keying on
     *    chapter URL.
     *
     * So the row is a candidate only when it speaks for THIS chapter, and it
     * wins only when provably newer. A stored entry with savedAt = 0L predates
     * stamping: its age is unknown, so it keeps its old privilege rather than
     * losing to a row that merely looks newer. Nobody's position moves on
     * upgrade.
     *
     * Clamping and FIX #12's reflow-proof fraction fallback live here too, so
     * the reader is left with nothing to decide.
     */
    fun resolveReaderPosition(
        context: Context,
        novelId: String,
        chapterIndex: Int,
        totalItems: Int,
        layoutSig: Int,
        novelChapterIndex: Int,
        novelParagraphIndex: Int,
        novelScrollOffset: Int,
        novelLastReadAt: Long,
        fallbackIndex: Int
    ): ResolvedPosition {
        if (totalItems <= 0) return ResolvedPosition(0, 0, "empty-list")
        val last = totalItems - 1
        val stored = loadReaderPosition(context, novelId, chapterIndex)
        // -1 is ProgressStore's "no opinion" (FIX C16): a row that never
        // recorded which chapter its paragraph belongs to. Those were applied
        // before this change, so they still are - refusing them would strand
        // older libraries at the top of every chapter.
        val rowSpeaksForThisChapter = novelChapterIndex < 0 || novelChapterIndex == chapterIndex
        val rowIndex = novelParagraphIndex.coerceIn(0, last)
        val rowOffset = novelScrollOffset.coerceAtLeast(0)

        if (stored == null) {
            return if (rowSpeaksForThisChapter) {
                ResolvedPosition(rowIndex, rowOffset, "row-only")
            } else {
                ResolvedPosition(fallbackIndex.coerceIn(0, last), 0, "row-wrong-chapter")
            }
        }

        val rowIsNewer = rowSpeaksForThisChapter &&
            stored.savedAt > 0L &&
            novelLastReadAt > stored.savedAt
        if (rowIsNewer) return ResolvedPosition(rowIndex, rowOffset, "row-newer")

        return if (stored.layoutSig != layoutSig && stored.fraction > 0f) {
            // FIX #12: typography changed since this was saved, so the stored
            // pixel offset is meaningless. The fraction is reflow-proof.
            ResolvedPosition(
                index = ((stored.fraction * totalItems).toInt() - 1).coerceIn(0, last),
                offset = 0,
                source = "stored-fraction"
            )
        } else {
            ResolvedPosition(
                index = stored.index.coerceIn(0, last),
                offset = stored.offset.coerceAtLeast(0),
                source = "stored-exact"
            )
        }
    }

    /**
     * Typography hash. A stored pixel offset is only meaningful for the
     * layout it was measured in, so the reader compares this before trusting
     * one.
     */
    fun layoutSignature(fontSize: Float, lineSpacing: Float, paragraphSpacing: Float): Int =
        ReadingPositionStore.layoutSignature(fontSize, lineSpacing, paragraphSpacing)

    // ---------------------------------------------------------------------
    // PER-CHAPTER STATE
    // ---------------------------------------------------------------------

    /** Mark a chapter read or unread. Identity is the chapter URL, not index. */
    fun setChapterRead(context: Context, novel: Novel, chapterIndex: Int, read: Boolean) {
        if (read) ChapterReadStore.markCompleted(context, novel, chapterIndex)
        else ChapterReadStore.markNotCompleted(context, novel, chapterIndex)
    }

    fun setAllChaptersRead(context: Context, novel: Novel, read: Boolean) {
        ChapterReadStore.setAllCompleted(context, novel, read)
    }

    fun setBookmark(context: Context, novel: Novel, chapterIndex: Int, bookmarked: Boolean) {
        ChapterReadStore.setBookmark(context, novel, chapterIndex, bookmarked)
    }

    /** Stamp the chapter just opened. Drives the chapter list highlight. */
    fun setCurrentChapter(context: Context, novel: Novel, chapterIndex: Int) {
        ChapterReadStore.setCurrent(context, novel, chapterIndex)
    }

    // ---------------------------------------------------------------------
    // MEMBERSHIP
    // ---------------------------------------------------------------------

    /**
     * Add a novel, or replace the existing row with the same id.
     *
     * Returns the resulting library so callers can render it without an
     * immediate re-read.
     */
    fun addToLibrary(context: Context, novel: Novel): List<Novel> {
        val current = loadLibrary(context)
        val merged = current.filterNot { it.id == novel.id } + novel
        saveLibrary(context, merged)
        return merged
    }

    /**
     * Remove a novel and the state that hangs off it.
     *
     * The saved scroll position and the Room progress row are dropped too.
     * Leaving them behind is how orphaned keys accumulate, and worse, how a
     * re-added novel silently inherits the position of the one that was
     * deleted.
     *
     * allowEmpty is passed through: removing the last novel is a real empty
     * library, not a failed load, and must be allowed to persist.
     */
    fun removeFromLibrary(context: Context, novelId: String): List<Novel> {
        val remaining = loadLibrary(context).filterNot { it.id == novelId }
        saveLibrary(context, remaining, allowEmpty = true)
        ReadingPositionStore.clearNovel(context, novelId)
        ProgressStore.deleteProgress(context, novelId)
        return remaining
    }

    // ---------------------------------------------------------------------
    // DIAGNOSTICS
    // ---------------------------------------------------------------------

    /** False when the last library read failed, so callers can refuse to overwrite. */
    // -----------------------------------------------------------------
    // READING HISTORY
    // -----------------------------------------------------------------

    /** The reading history, newest first. */
    fun loadHistory(context: Context): List<com.lorelight.data.model.HistoryEntry> =
        NovelPreferences.loadHistoryFromPrefs(context)

    /**
     * Replaces the stored history.
     *
     * allowEmpty is not ceremony. Clearing the history and failing to read it
     * look identical from here, and a failed read must never be allowed to
     * erase a good history, so a caller that genuinely means empty has to say
     * so out loud.
     */
    fun saveHistory(
        context: Context,
        history: List<com.lorelight.data.model.HistoryEntry>,
        allowEmpty: Boolean = false
    ) {
        NovelPreferences.saveHistoryToPrefs(context, history, allowEmpty)
    }

    /** Records that the user opened this novel. */
    fun addHistoryEntry(context: Context, novel: Novel) {
        NovelPreferences.addHistoryEntry(context, novel)
    }

    fun removeHistoryEntry(context: Context, novelId: String) {
        NovelPreferences.removeHistoryEntry(context, novelId)
    }

    fun clearHistory(context: Context) {
        NovelPreferences.clearAllHistory(context)
    }

    // -----------------------------------------------------------------
    // LAST READING MODE (read vs listen)
    // -----------------------------------------------------------------

    /**
     * Remembers whether the user was reading or listening, so reopening a
     * novel resumes the mode they left it in rather than the default.
     */
    fun setLastMode(context: Context, novelId: String, listen: Boolean) {
        NovelPreferences.setLastMode(context, novelId, listen)
    }

    fun wasLastModeListen(context: Context, novelId: String): Boolean =
        NovelPreferences.wasLastModeListen(context, novelId)

    fun hasUsedTts(context: Context, novelId: String): Boolean =
        NovelPreferences.hasUsedTts(context, novelId)

    // -----------------------------------------------------------------
    // Highlights
    // -----------------------------------------------------------------

    /**
     * Saved highlights, every novel at once, because that is how they are
     * stored. Routable only now that Highlight lives in data/model.
     */
    fun loadHighlights(context: Context): List<Highlight> =
        NovelPreferences.loadHighlightsFromPrefs(context)

    fun saveHighlights(context: Context, highlights: List<Highlight>) =
        NovelPreferences.saveHighlightsToPrefs(context, highlights)

    fun isHealthy(): Boolean = NovelPreferences.isLibraryHealthy()

    /** Queued writes not yet on disk. Surfaced by the monitoring screen. */
    fun pendingWriteCount(): Int = NovelPreferences.pendingWriteCount()

    /** Drain queued writes. Used before backup and on the way out. */
    fun flushPendingWrites(timeoutMs: Long = 4_000L): Boolean =
        NovelPreferences.flushPendingWrites(timeoutMs)
}
