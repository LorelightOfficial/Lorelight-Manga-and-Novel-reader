package com.lorelight.browse.repo

import android.content.Context
import com.lorelight.browse.model.InstalledPlugin
import com.lorelight.browse.model.PluginInfo
import com.lorelight.crawler.CrawlerEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

object PluginManager {
    // FIX B11 + C17: shared, Cloudflare-aware, pooled client instead of a
    // private per-object OkHttpClient.
    private val client: OkHttpClient
        get() = com.lorelight.network.HttpClients.shared()

    private fun pluginsDir(context: Context): File {
        val dir = File(context.filesDir, "plugins")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    // FIX A5: a repo-supplied id containing path separators ("../../evil")
    // used to write outside the plugins directory. Ids are now reduced to a
    // single safe file-name component. Ordinary ids are unchanged.
    fun pluginFile(context: Context, pluginId: String): File =
        File(pluginsDir(context), com.lorelight.browse.js.sanitizePluginId(pluginId) + ".js")

    suspend fun installPlugin(context: Context, info: PluginInfo): Result<InstalledPlugin> =
        withContext(Dispatchers.IO) {
            try {
                val js = download(info.url) ?: return@withContext Result.failure(Exception("Download failed"))
                val file = pluginFile(context, info.id)
                file.writeText(js)
                val installed = InstalledPlugin(
                    info = info,
                    filePath = file.absolutePath,
                    installedVersion = info.version,
                    pinned = false
                )
                PluginStore.save(context, installed)
                Result.success(installed)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    fun uninstallPlugin(context: Context, id: String) {
        pluginFile(context, id).delete()
        PluginStore.remove(context, id)
        // Engine context eviction is wired in Phase 2 (JSPluginEngine.evict).
        // Delete this plugin's namespaced storage prefs:
        context.getSharedPreferences(com.lorelight.browse.js.pluginStoragePrefsName(id), Context.MODE_PRIVATE)
            .edit().clear().apply()
    }

    suspend fun updatePlugin(context: Context, info: PluginInfo): Result<InstalledPlugin> =
        withContext(Dispatchers.IO) {
            try {
                val js = download(info.url) ?: return@withContext Result.failure(Exception("Download failed"))
                val file = pluginFile(context, info.id)
                file.writeText(js)
                val installed = InstalledPlugin(
                    info = info,
                    filePath = file.absolutePath,
                    installedVersion = info.version,
                    pinned = PluginStore.getInstalled(context).firstOrNull { it.info.id == info.id }?.pinned ?: false
                )
                PluginStore.save(context, installed)
                // Engine context eviction is wired in Phase 2.
                Result.success(installed)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    // Plain string compare, matching LNReader.
    fun hasUpdate(installed: InstalledPlugin, available: PluginInfo): Boolean =
        available.version != installed.installedVersion

    private fun download(url: String): String? {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", CrawlerEngine.MOBILE_UA)
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw Exception("HTTP ${resp.code}")
            return resp.body?.string()
        }
    }
}
