package com.lorelight.manga.reader
import com.lorelight.R
import androidx.compose.ui.res.stringResource


import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.ui.theme.GlassPanel
import com.lorelight.ui.theme.rememberGlassPalette
import com.lorelight.ui.components.readerSafeTopPadding
import kotlin.math.roundToInt
import androidx.compose.ui.semantics.Role

@Composable
fun MangaReaderTopBar(
    mangaTitle: String,
    chapterTitle: String,
    isAutoscrolling: Boolean,
    readerHighlightColor: Color = Color(0xFF81C784),
    onBack: () -> Unit,
    onOpenContents: () -> Unit,
    onToggleAutoscroll: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    // REVERTED to the original bar, matching the novel reader: a solid black
    // slab running up behind the status bar, with the ink pinned to white.
    // The inset sits on the ROW so the black covers the status-bar strip while
    // the controls stay clear of the clock.
    val barInk = Color.White

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.Black)
    ) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(start = 8.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        IconButton(
            onClick = onBack,
            modifier = Modifier.size(36.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = stringResource(R.string.reader_font_close),
                tint = barInk,
                modifier = Modifier.size(20.dp)
            )
        }

        // Chapter name only, by request. This used to stack the manga title on
        // top with the chapter underneath in smaller grey text. The title is
        // kept as a fallback for the brief moment before the chapter name is
        // known, so the bar is never left blank.
        Box(
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp, end = 8.dp, top = 2.dp)
        ) {
            Text(
                text = if (chapterTitle.isNotBlank()) chapterTitle else mangaTitle,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = barInk
            )
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onOpenContents,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MenuBook,
                    contentDescription = stringResource(R.string.reader_contents_title),
                    tint = barInk,
                    modifier = Modifier.size(20.dp)
                )
            }

            IconButton(
                onClick = onToggleAutoscroll,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = if (isAutoscrolling) Icons.Default.Pause else Icons.Default.KeyboardDoubleArrowDown,
                    contentDescription = if (isAutoscrolling) stringResource(R.string.manga_reader_pause_autoscroll_desc) else stringResource(R.string.manga_reader_start_autoscroll_desc),
                    tint = if (isAutoscrolling) readerHighlightColor else barInk,
                    modifier = Modifier.size(20.dp)
                )
            }

            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = stringResource(R.string.manga_reader_settings_desc),
                    tint = barInk,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
    }
}



@Composable
fun MangaReaderBottomBar(
    currentPage: Int,
    totalPages: Int,
    currentChapterIndex: Int,
    totalChapters: Int,
    readingMode: MangaReadingMode,
    showPageSlider: Boolean = true,
    onPageSeek: (Int) -> Unit,
    onPrevChapter: () -> Unit,
    onNextChapter: () -> Unit,
    onOpenReadingMode: () -> Unit,
    onCycleOrientation: () -> Unit,
    ttsAvailable: Boolean = false,
    ttsSessionOn: Boolean = false,
    ttsPaused: Boolean = false,
    onToggleTtsSession: () -> Unit = {},
    onTtsPlayPause: () -> Unit = {},
    onStopTtsSession: () -> Unit = {},
    bgColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    val total = totalPages.coerceAtLeast(1)
    val isRtl = readingMode == MangaReadingMode.PAGED_RTL

    var draggingValue by remember { mutableStateOf<Float?>(null) }

    val currentSliderValue = if (isRtl) {
        (total - currentPage).toFloat()
    } else {
        (currentPage + 1).toFloat()
    }

    val sliderValue = draggingValue ?: currentSliderValue

    val displayedPage = if (draggingValue != null) {
        val targetVal = draggingValue!!.roundToInt().coerceIn(1, total)
        if (isRtl) (total - targetVal + 1) else targetVal
    } else {
        currentPage + 1
    }

    // The bottom panel is a frosted slab now rather than bare controls
    // floating on the page. Same palette as every other glass surface in
    // the app, so it belongs to the app rather than to the page behind it.
    // navigationBarsPadding stays OUTSIDE the tint: the glass ends where
    // the gesture bar begins instead of sliding under it.
    val glass = rememberGlassPalette(tintAlpha = 0.82f)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(glass.container)
            .border(1.dp, glass.borderTop, RoundedCornerShape(26.dp))
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Row 1: Page Slider
        // A single-page chapter makes the slider meaningless, and a 1f..1f
        // valueRange breaks the Material Slider, so only show it when there is
        // more than one page.
        if (showPageSlider && total > 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$displayedPage / $total",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = textColor,
                    modifier = Modifier.padding(end = 8.dp)
                )

                Slider(
                    value = sliderValue.coerceIn(1f, total.toFloat()),
                    onValueChange = { newValue ->
                        draggingValue = newValue
                        // Seek live while dragging (like mihon) so the page
                        // tracks the thumb instead of only jumping on release.
                        // Dedup by page so a drag fires at most one seek per
                        // page it crosses.
                        val targetVal = newValue.roundToInt().coerceIn(1, total)
                        val targetPageIndex = if (isRtl) {
                            total - targetVal
                        } else {
                            targetVal - 1
                        }
                        if (targetPageIndex != currentPage) {
                            onPageSeek(targetPageIndex)
                        }
                    },
                    onValueChangeFinished = {
                        val dV = draggingValue
                        if (dV != null) {
                            val targetVal = dV.roundToInt().coerceIn(1, total)
                            val targetPageIndex = if (isRtl) {
                                total - targetVal
                            } else {
                                targetVal - 1
                            }
                            onPageSeek(targetPageIndex)
                            draggingValue = null
                        }
                    },
                    valueRange = 1f..total.toFloat(),
                    // A tick per page draws hundreds of dots on long chapters
                    // (visual noise + extra draw cost). The value is already
                    // snapped to a whole page in onValueChangeFinished, so a
                    // continuous track loses nothing.
                    steps = 0,
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(
                        thumbColor = textColor,
                        activeTrackColor = textColor,
                        inactiveTrackColor = textColor.copy(alpha = 0.3f)
                    )
                )
            }
        }

        // Row 2: Control Pill Card
        Card(
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(containerColor = bgColor.copy(alpha = 0.5f)),
            modifier = Modifier
                .height(52.dp)
                .widthIn(max = 360.dp)
                .padding(start = 24.dp, end = 24.dp, top = 4.dp, bottom = 8.dp)
                .border(1.dp, textColor.copy(alpha = 0.08f), RoundedCornerShape(32.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // READ-ALOUD PANEL REMOVED. The pill used to swap all five of
                // its normal controls for a six-button TTS transport the moment
                // a session started, which meant starting read-aloud took the
                // chapter and reading-mode buttons away. Now the pill never
                // changes shape: only the read-aloud icon itself becomes a
                // pause/resume button while a session is running, and a long
                // press on it ends the session.
                IconButton(
                    onClick = onPrevChapter,
                    enabled = currentChapterIndex > 0,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FastRewind,
                        contentDescription = stringResource(R.string.manga_reader_previous_chapter),
                        tint = if (currentChapterIndex > 0) textColor else textColor.copy(alpha = 0.35f),
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = onOpenReadingMode,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ViewDay,
                        contentDescription = stringResource(R.string.manga_reader_reading_mode),
                        tint = textColor,
                        modifier = Modifier.size(18.dp)
                    )
                }

                IconButton(
                    onClick = onCycleOrientation,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ScreenRotation,
                        contentDescription = stringResource(R.string.manga_reader_cycle_orientation),
                        tint = textColor,
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (ttsAvailable) {
                    // One button, two states: start, or stop. Tapping it a
                    // second time used to pause and keep the session alive,
                    // which meant the reader was still held by TTS with
                    // nothing to show for it -- and ending it properly was
                    // hidden behind a long press nobody would guess at. A
                    // second tap now means what it looks like it means and
                    // ends the session. Long press still stops too, so the
                    // old habit keeps working.
                    MangaPillIconButton(
                        icon = if (ttsSessionOn) Icons.Default.Stop
                            else Icons.Default.RecordVoiceOver,
                        description = if (ttsSessionOn) stringResource(R.string.manga_reader_stop_reading_aloud)
                            else stringResource(R.string.manga_reader_read_aloud),
                        textColor = textColor,
                        highlighted = ttsSessionOn,
                        onClick = {
                            if (ttsSessionOn) onStopTtsSession() else onToggleTtsSession()
                        },
                        onLongClick = onStopTtsSession
                    )
                }

                IconButton(
                    onClick = onNextChapter,
                    enabled = currentChapterIndex < totalChapters - 1,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FastForward,
                        contentDescription = stringResource(R.string.manga_reader_next_chapter),
                        tint = if (currentChapterIndex < totalChapters - 1) textColor else textColor.copy(alpha = 0.35f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MangaPillIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    textColor: Color,
    onClick: () -> Unit,
    highlighted: Boolean = false,
    onLongClick: (() -> Unit)? = null
) {
    if (onLongClick == null) {
        IconButton(
            onClick = onClick,
            modifier = Modifier.size(36.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = description,
                tint = if (highlighted) textColor else textColor.copy(alpha = 0.9f),
                modifier = Modifier.size(18.dp)
            )
        }
        return
    }

    // IconButton has no long-press hook, so the long-press variant is a plain
    // Box with combinedClickable. Same 36.dp touch target either way.
    Box(
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(
                if (highlighted) textColor.copy(alpha = 0.16f) else Color.Transparent
            )
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = if (highlighted) textColor else textColor.copy(alpha = 0.9f),
            modifier = Modifier.size(18.dp)
        )
    }
}

@Composable
fun MangaPageOverlayIndicator(
    currentPage: Int,
    totalPages: Int,
    bgColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            // RESTYLE: full pill with a hairline edge, matching the glass chips
            // used elsewhere in Lorelight instead of a plain rounded rectangle.
            .background(bgColor.copy(alpha = 0.78f), RoundedCornerShape(50))
            .border(1.dp, textColor.copy(alpha = 0.18f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 5.dp)
    ) {
        Text(
            text = "${currentPage + 1} / ${totalPages.coerceAtLeast(1)}",
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun MangaContentsDrawer(
    visible: Boolean,
    chapterNames: List<String>,
    currentChapterIndex: Int,
    // Dimming used to be driven by a set of chapter NAMES mirrored onto the
    // novel row, which the manga reader never even passed -- so nothing was ever
    // dimmed here, while the details page dimmed from the chapters table. Same
    // question, two different answers. This now takes the indices the details
    // page uses, so both screens agree and duplicate or retitled chapter names
    // cannot confuse it.
    completedIndices: Set<Int> = emptySet(),
    readerHighlightColor: Color = Color(0xFF81C784),
    readerTextColor: Color = Color.White,
    onSelectChapter: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val chaptersListState = rememberLazyListState(initialFirstVisibleItemIndex = currentChapterIndex.coerceAtLeast(0))

    LaunchedEffect(visible) {
        if (visible && currentChapterIndex in chapterNames.indices) {
            chaptersListState.scrollToItem(currentChapterIndex)
        }
    }

    AnimatedVisibility(
        visible = visible,
        enter = slideInHorizontally(
            initialOffsetX = { -it },
            animationSpec = tween(260, easing = FastOutSlowInEasing)
        ) + fadeIn(tween(200)),
        exit = slideOutHorizontally(
            targetOffsetX = { -it },
            animationSpec = tween(240)
        ) + fadeOut(tween(180))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(0.55f))
                .clickable(role = Role.Button) { onDismiss() }
        ) {
            GlassPanel(
                cornerRadius = 0.dp,
                tintAlpha = 0.90f,
                modifier = Modifier
                    .fillMaxHeight()
                    // FIX: mirrors the novel reader's Contents drawer -- a fixed
                    // 280dp only ever looked like ~60% of the screen on typical
                    // phone widths. On a tablet's wider screen it shrank to a
                    // sliver. A real 60% width fraction scales correctly on both.
                    .fillMaxWidth(0.6f)
                    .clickable(enabled = false) {}
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = readerSafeTopPadding())
                        .padding(16.dp)
                ) {
                    // CHAPTER SEARCH: hidden behind the magnifier until tapped, and
                    // wired exactly like the novel reader's Contents drawer.
                    // Filtering keeps the ORIGINAL chapter index next to the title so
                    // tapping a filtered row still opens the correct chapter.
                    var searchOpen by remember { mutableStateOf(false) }
                    var searchQuery by remember { mutableStateOf("") }
                    val filteredChapters = remember(chapterNames, searchQuery) {
                        val q = searchQuery.trim()
                        if (q.isEmpty()) chapterNames.withIndex().toList()
                        else chapterNames.withIndex().filter { it.value.contains(q, ignoreCase = true) }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp),
                            tint = readerHighlightColor
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = stringResource(R.string.reader_contents_title),
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = readerTextColor,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = {
                            searchOpen = !searchOpen
                            if (!searchOpen) searchQuery = ""
                        }) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = stringResource(R.string.manga_reader_search_chapters),
                                tint = if (searchOpen) readerHighlightColor else readerTextColor
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = stringResource(R.string.reader_font_close),
                                tint = readerTextColor
                            )
                        }
                    }

                    HorizontalDivider(
                        color = readerTextColor.copy(alpha = 0.15f),
                        modifier = Modifier.padding(vertical = 12.dp)
                    )

                    AnimatedVisibility(visible = searchOpen) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            singleLine = true,
                            placeholder = {
                                Text(
                                    stringResource(R.string.manga_reader_search_chapters),
                                    fontSize = 14.sp,
                                    color = readerTextColor.copy(alpha = 0.5f)
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                    tint = readerHighlightColor
                                )
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = stringResource(R.string.manga_reader_clear_search),
                                            modifier = Modifier.size(16.dp),
                                            tint = readerTextColor.copy(alpha = 0.7f)
                                        )
                                    }
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = readerHighlightColor,
                                unfocusedBorderColor = readerTextColor.copy(alpha = 0.25f),
                                focusedTextColor = readerTextColor,
                                unfocusedTextColor = readerTextColor,
                                cursorColor = readerHighlightColor
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        )
                    }

                    com.lorelight.ui.components.VerticalFastScroller(
                        listState = chaptersListState,
                        thumbColor = readerHighlightColor,
                        modifier = Modifier.weight(1f)
                    ) {
                        LazyColumn(
                            state = chaptersListState,
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            if (filteredChapters.isEmpty()) {
                                item {
                                    Text(
                                        text = "No chapters match \"${searchQuery.trim()}\"",
                                        fontSize = 13.sp,
                                        color = readerTextColor.copy(alpha = 0.6f),
                                        modifier = Modifier.padding(vertical = 24.dp)
                                    )
                                }
                            }
                            itemsIndexed(filteredChapters) { _, entry ->
                                val index = entry.index
                                val chTitle = entry.value
                                val isActive = index == currentChapterIndex
                                val isCompleted = completedIndices.contains(index)
                                com.lorelight.ui.reader.ChapterRowItem(
                                    index = index,
                                    chTitle = chTitle,
                                    isActive = isActive,
                                    isCompleted = isCompleted,
                                    isCached = false,
                                    readerHighlightColor = readerHighlightColor,
                                    readerTextColor = readerTextColor,
                                    onClick = {
                                        onSelectChapter(index)
                                        onDismiss()
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

