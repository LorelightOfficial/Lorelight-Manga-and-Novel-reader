package com.lorelight.ui.components

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.ui.animation.shimmer
import com.lorelight.ui.theme.LocalMotionLevel

/**
 * The four states every screen eventually needs, in one place.
 *
 * Before this file, each screen invented its own: some showed a bare centred
 * spinner that replaced content the user was already reading, some showed a
 * raw exception string like "unexpected token (position: unknown @1:17...)",
 * some showed nothing at all and just looked broken. Empty shelves said
 * "Your shelf is empty" while empty search said "No results" in a different
 * size, weight and colour.
 *
 * Rules these surfaces enforce:
 *  - Loading is shaped like the content it replaces, never a lone spinner in
 *    the middle of a screen that already has content.
 *  - Every error names what failed in plain language and offers a next step.
 *  - Offline is its own state, and it offers downloaded content instead of
 *    just apologising.
 *  - Empty states tell the user the one action that fills them.
 */

/* ────────────────────────────── Loading ───────────────────────────── */

/** What the incoming content looks like, so the placeholder can match it. */
enum class LoadingShape {
    /** Cover art in a grid: library, browse, search results. */
    COVER_GRID,

    /** Icon + two lines of text: sources, extensions, repositories, fonts. */
    LIST_ROWS,

    /** Title line + small meta line: chapter lists, history. */
    CHAPTER_ROWS,

    /** A small spinner with a label, for footers and inline refreshes. */
    INLINE
}

@Composable
fun LorelightLoading(
    shape: LoadingShape,
    modifier: Modifier = Modifier,
    columns: Int = 3,
    itemCount: Int = 9,
    label: String? = null
) {
    when (shape) {
        LoadingShape.COVER_GRID ->
            com.lorelight.ui.animation.BookGridSkeleton(
                modifier = modifier,
                columns = columns.coerceIn(2, 6),
                itemCount = itemCount.coerceIn(3, 24)
            )

        LoadingShape.LIST_ROWS -> SkeletonRows(
            modifier = modifier,
            itemCount = itemCount.coerceIn(3, 14),
            withLeadingBlock = true
        )

        LoadingShape.CHAPTER_ROWS -> SkeletonRows(
            modifier = modifier,
            itemCount = itemCount.coerceIn(3, 14),
            withLeadingBlock = false
        )

        LoadingShape.INLINE -> Row(
            modifier = modifier
                .fillMaxWidth()
                .padding(vertical = 18.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.primary
            )
            if (!label.isNullOrBlank()) {
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = label,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun SkeletonRows(
    modifier: Modifier = Modifier,
    itemCount: Int,
    withLeadingBlock: Boolean
) {
    val motion = LocalMotionLevel.current
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        repeat(itemCount) { index ->
            // Widths vary slightly so the placeholder reads as text, not as a
            // set of identical grey bars.
            val titleFraction = when (index % 3) {
                0 -> 0.72f
                1 -> 0.58f
                else -> 0.66f
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (withLeadingBlock) {
                    SkeletonBlock(
                        width = 40.dp,
                        height = 40.dp,
                        corner = 12.dp,
                        animate = motion.allowsLoopingAnimation
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                }
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    SkeletonLine(
                        fraction = titleFraction,
                        height = 13.dp,
                        animate = motion.allowsLoopingAnimation
                    )
                    SkeletonLine(
                        fraction = titleFraction * 0.5f,
                        height = 10.dp,
                        animate = motion.allowsLoopingAnimation
                    )
                }
            }
        }
    }
}

@Composable
private fun SkeletonBlock(
    width: Dp,
    height: Dp,
    corner: Dp,
    animate: Boolean
) {
    val base = Modifier
        .size(width = width, height = height)
        .clip(RoundedCornerShape(corner))
        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
    Box(modifier = if (animate) base.shimmer() else base)
}

@Composable
private fun SkeletonLine(
    fraction: Float,
    height: Dp,
    animate: Boolean
) {
    val base = Modifier
        .fillMaxWidth(fraction.coerceIn(0.1f, 1f))
        .height(height)
        .clip(RoundedCornerShape(height / 2))
        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
    Box(modifier = if (animate) base.shimmer() else base)
}

/* ─────────────────────────────── Empty ────────────────────────────── */

@Composable
fun LorelightEmpty(
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    secondaryActionLabel: String? = null,
    onSecondaryAction: (() -> Unit)? = null,
    compact: Boolean = false
) {
    StateScaffold(
        modifier = modifier,
        icon = icon,
        iconTint = MaterialTheme.colorScheme.primary.copy(alpha = 0.55f),
        title = title,
        message = message,
        compact = compact
    ) {
        StateActions(
            primaryLabel = actionLabel,
            onPrimary = onAction,
            secondaryLabel = secondaryActionLabel,
            onSecondary = onSecondaryAction
        )
    }
}

/* ─────────────────────────────── Error ────────────────────────────── */

/**
 * What actually went wrong, inferred from whatever string the network or
 * parser threw. Users should never see the raw text again.
 */
enum class FailureKind {
    OFFLINE,
    TIMEOUT,
    // Generic block from the source (cookies, IP ban)
    BLOCKED,
    // Cloudflare JS challenge - needs browser visit to clear
    CLOUDFLARE,
    // HTTP 429 or explicit rate-limit message
    RATE_LIMITED,
    NOT_FOUND,
    PARSE,
    // Extension version mismatch - site layout changed
    EXTENSION_OUTDATED,
    // Source plugin removed or domain dead
    SOURCE_REMOVED,
    SERVER,
    PERMISSION,
    STORAGE,
    UNKNOWN
}

fun classifyFailure(message: String?, throwable: Throwable? = null): FailureKind {
    val text = buildString {
        append(message?.lowercase().orEmpty())
        append(' ')
        append(throwable?.javaClass?.simpleName?.lowercase().orEmpty())
        append(' ')
        append(throwable?.message?.lowercase().orEmpty())
    }

    return when {
        text.contains("unable to resolve host") ||
            text.contains("no address associated") ||
            text.contains("network is unreachable") ||
            text.contains("unknownhost") ||
            text.contains("failed to connect") ||
            text.contains("no internet") -> FailureKind.OFFLINE

        text.contains("timeout") || text.contains("timed out") -> FailureKind.TIMEOUT

        text.contains("cloudflare") ||
            text.contains("captcha") ||
            text.contains("jschallenge") ||
            text.contains("cf-ray") -> FailureKind.CLOUDFLARE

        text.contains("429") ||
            text.contains("rate limit") ||
            text.contains("too many requests") -> FailureKind.RATE_LIMITED

        text.contains("403") ||
            text.contains("forbidden") ||
            text.contains("blocked") -> FailureKind.BLOCKED

        text.contains("extension out of date") ||
            text.contains("version mismatch") ||
            text.contains("unsupported version") -> FailureKind.EXTENSION_OUTDATED

        text.contains("source removed") ||
            text.contains("plugin not found") ||
            text.contains("no plugin installed") -> FailureKind.SOURCE_REMOVED

        text.contains("404") || text.contains("not found") -> FailureKind.NOT_FOUND

        text.contains("unexpected token") ||
            text.contains("malformed") ||
            text.contains("jsonexception") ||
            text.contains("xmlpull") ||
            text.contains("parse") ||
            text.contains("selector") -> FailureKind.PARSE

        text.contains("500") ||
            text.contains("502") ||
            text.contains("503") ||
            text.contains("server error") -> FailureKind.SERVER

        text.contains("permission") || text.contains("securityexception") -> FailureKind.PERMISSION

        text.contains("enospc") ||
            text.contains("no space") ||
            text.contains("storage") -> FailureKind.STORAGE

        else -> FailureKind.UNKNOWN
    }
}

private fun FailureKind.defaultTitle(): String = when (this) {
    FailureKind.OFFLINE             -> "You're offline"
    FailureKind.TIMEOUT             -> "The source took too long"
    FailureKind.BLOCKED             -> "The source blocked this request"
    FailureKind.CLOUDFLARE          -> "A browser check is blocking this"
    FailureKind.RATE_LIMITED        -> "The source is rate-limiting you"
    FailureKind.NOT_FOUND           -> "That page is gone"
    FailureKind.PARSE               -> "The source sent something unreadable"
    FailureKind.EXTENSION_OUTDATED  -> "Extension may be out of date"
    FailureKind.SOURCE_REMOVED      -> "Source not available"
    FailureKind.SERVER              -> "The source is having problems"
    FailureKind.PERMISSION          -> "Lorelight needs permission"
    FailureKind.STORAGE             -> "Not enough room to save this"
    FailureKind.UNKNOWN             -> "That didn't work"
}

private fun FailureKind.defaultMessage(): String = when (this) {
    FailureKind.OFFLINE ->
        "Lorelight couldn't reach the internet. Anything you've downloaded still opens."
    FailureKind.TIMEOUT ->
        "The site didn't answer in time. It's usually busy rather than broken - try again in a moment."
    FailureKind.BLOCKED ->
        "The site is asking for a browser check. Opening it in the in-app browser once usually clears it."
    FailureKind.CLOUDFLARE ->
        "Open the source in the browser once to pass the check, then come back."
    FailureKind.RATE_LIMITED ->
        "Too many requests in a short time. Wait a minute before trying again."
    FailureKind.NOT_FOUND ->
        "This entry has moved or been removed at the source. Another source may still have it."
    FailureKind.PARSE ->
        "The page layout changed, so this extension can't read it. An extension update usually fixes this."
    FailureKind.EXTENSION_OUTDATED ->
        "The extension may not be compatible with the current site layout. Try updating it."
    FailureKind.SOURCE_REMOVED ->
        "This source is not installed or is no longer available. Move this title to another source."
    FailureKind.SERVER ->
        "The site returned an error of its own. Nothing on your side is wrong."
    FailureKind.PERMISSION ->
        "Grant the permission and this will work. Nothing was changed."
    FailureKind.STORAGE ->
        "Free some space, or point Lorelight at a folder with more room, then try again."
    FailureKind.UNKNOWN ->
        "Something failed partway through. Nothing was lost - you can try again."
}

private fun FailureKind.icon(): ImageVector = when (this) {
    FailureKind.OFFLINE -> Icons.Filled.CloudOff
    else -> Icons.Filled.ErrorOutline
}

@Composable
fun LorelightError(
    message: String?,
    modifier: Modifier = Modifier,
    kind: FailureKind = classifyFailure(message),
    title: String? = null,
    explanation: String? = null,
    onRetry: (() -> Unit)? = null,
    retryLabel: String = "Try again",
    onOpenWebsite: (() -> Unit)? = null,
    onFindAnotherSource: (() -> Unit)? = null,
    onShowDownloaded: (() -> Unit)? = null,
    details: String? = message,
    compact: Boolean = false
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    StateScaffold(
        modifier = modifier,
        icon = kind.icon(),
        iconTint = MaterialTheme.colorScheme.error.copy(alpha = 0.75f),
        title = title ?: kind.defaultTitle(),
        message = explanation ?: kind.defaultMessage(),
        compact = compact
    ) {
        StateActions(
            primaryLabel = if (onRetry != null) retryLabel else null,
            primaryIcon = Icons.Filled.Refresh,
            onPrimary = onRetry,
            secondaryLabel = when {
                onShowDownloaded != null -> "Show downloaded only"
                onOpenWebsite != null -> "Open in browser"
                onFindAnotherSource != null -> "Try another source"
                else -> null
            },
            secondaryIcon = when {
                onShowDownloaded != null -> Icons.Filled.CloudOff
                onOpenWebsite != null -> Icons.Filled.Language
                else -> Icons.Filled.Search
            },
            onSecondary = onShowDownloaded ?: onOpenWebsite ?: onFindAnotherSource,
            tertiaryLabel = if (!details.isNullOrBlank()) "Copy details" else null,
            tertiaryIcon = Icons.Filled.ContentCopy,
            onTertiary = if (!details.isNullOrBlank()) {
                {
                    clipboard.setText(AnnotatedString(details))
                    Toast.makeText(context, "Error details copied", Toast.LENGTH_SHORT).show()
                }
            } else null
        )
    }
}

/**
 * Offline is common enough to deserve its own entry point, and it always
 * offers downloaded content when the screen can filter to it.
 */
@Composable
fun LorelightOffline(
    modifier: Modifier = Modifier,
    title: String = "You're offline",
    message: String = "Lorelight can't reach the internet right now. Downloaded chapters still open normally.",
    onRetry: (() -> Unit)? = null,
    onShowDownloaded: (() -> Unit)? = null,
    compact: Boolean = false
) {
    LorelightError(
        message = null,
        modifier = modifier,
        kind = FailureKind.OFFLINE,
        title = title,
        explanation = message,
        onRetry = onRetry,
        onShowDownloaded = onShowDownloaded,
        details = null,
        compact = compact
    )
}

/* ───────────────────────────── Shared shell ───────────────────────── */

@Composable
private fun StateScaffold(
    modifier: Modifier,
    icon: ImageVector?,
    iconTint: Color,
    title: String,
    message: String,
    compact: Boolean,
    actions: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .then(if (compact) Modifier else Modifier.heightIn(min = 220.dp))
            .padding(horizontal = 24.dp, vertical = if (compact) 18.dp else 32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            if (icon != null) {
                Box(
                    modifier = Modifier
                        .size(if (compact) 44.dp else 56.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(iconTint.copy(alpha = 0.10f))
                        .border(
                            width = 1.dp,
                            color = iconTint.copy(alpha = 0.22f),
                            shape = RoundedCornerShape(18.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(if (compact) 22.dp else 26.dp)
                    )
                }
                Spacer(modifier = Modifier.height(14.dp))
            }
            Text(
                text = title,
                fontSize = if (compact) 15.sp else 17.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = message,
                fontSize = 13.sp,
                lineHeight = 19.sp,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.85f)
            )
            actions()
        }
    }
}

@Composable
private fun StateActions(
    primaryLabel: String?,
    onPrimary: (() -> Unit)?,
    primaryIcon: ImageVector? = null,
    secondaryLabel: String? = null,
    onSecondary: (() -> Unit)? = null,
    secondaryIcon: ImageVector? = null,
    tertiaryLabel: String? = null,
    onTertiary: (() -> Unit)? = null,
    tertiaryIcon: ImageVector? = null
) {
    val hasPrimary = primaryLabel != null && onPrimary != null
    val hasSecondary = secondaryLabel != null && onSecondary != null
    val hasTertiary = tertiaryLabel != null && onTertiary != null
    if (!hasPrimary && !hasSecondary && !hasTertiary) return

    Spacer(modifier = Modifier.height(16.dp))
    Row(
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (hasPrimary) {
            StateActionButton(
                label = primaryLabel!!,
                icon = primaryIcon,
                emphasised = true,
                onClick = onPrimary!!
            )
        }
        if (hasSecondary) {
            StateActionButton(
                label = secondaryLabel!!,
                icon = secondaryIcon,
                emphasised = false,
                onClick = onSecondary!!
            )
        }
    }
    if (hasTertiary) {
        TextButton(
            onClick = onTertiary!!,
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
        ) {
            if (tertiaryIcon != null) {
                Icon(
                    imageVector = tertiaryIcon,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
                Spacer(modifier = Modifier.width(6.dp))
            }
            Text(
                text = tertiaryLabel!!,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
        }
    }
}

@Composable
private fun StateActionButton(
    label: String,
    icon: ImageVector?,
    emphasised: Boolean,
    onClick: () -> Unit
) {
    val accent = MaterialTheme.colorScheme.primary
    TextButton(
        onClick = onClick,
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (emphasised) accent.copy(alpha = 0.16f)
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f)
            )
            .border(
                width = 1.dp,
                color = if (emphasised) accent.copy(alpha = 0.35f)
                else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f),
                shape = RoundedCornerShape(14.dp)
            )
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(15.dp),
                tint = if (emphasised) accent else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.width(7.dp))
        }
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = if (emphasised) FontWeight.SemiBold else FontWeight.Medium,
            color = if (emphasised) accent else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
