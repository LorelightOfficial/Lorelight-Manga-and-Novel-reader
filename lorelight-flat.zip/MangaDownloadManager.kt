package com.lorelight.manga.download

import android.content.Context
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.lorelight.data.download.DownloadProgressBus
import com.lorelight.data.download.DownloadItemState
import com.lorelight.data.download.DownloadStatus
import com.lorelight.data.model.Novel
import com.lorelight.data.model.decodeMangaChapterUrl
import com.lorelight.data.model.mangaSourceId
import com.lorelight.manga.reader.MangaImageLoaderProvider
import com.lorelight.manga.reader.MangaPageKey
import com.lorelight.manga.reader.MangaPageListCache
import com.lorelight.manga.reader.MangaPageOcr
import com.lorelight.manga.reader.MangaReaderPrefs
import com.lorelight.manga.reader.MangaReadingMode
import kotlinx.coroutines.flow.first
import tachiyomi.domain.source.service.SourceManager
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import com.lorelight.manga.util.MangaNamingUtils
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.online.HttpSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

/**
 * FEATURE: Real manga downloading with multi-job queue support.
 *
 * This downloader does the manga-correct thing:
 *  1. Resolve the installed extension HttpSource for the manga.
 *  2. For every chapter, fetch its page list.
 *  3. Pre-fetch every page image THROUGH the same Coil image loader the reader
 *     uses, so each page lands in Coil's on-disk manga_pages cache. The reader
 *     then serves those pages from disk instead of the network.
 *  4. If "Run OCR while downloading" is on, OCR each page up front and store
 *     the bubbles in MangaOcrCache so the reader never waits for ML Kit.
 *
 * Progress is published to DownloadProgressBus so both the Downloads Queue screen
 * and the Settings monitor show it live in real time.
 */
object MangaDownloadManager {

    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val pausedJobs = ConcurrentHashMap.newKeySet<String>()

    val isDownloading: Boolean
        get() = activeJobs.values.any { it.isActive }

    fun isManga(novel: Novel): Boolean {
        val pid = novel.pluginId ?: return false
        return MangaNamingUtils.isMangaPluginId(pid)
    }

    fun stop(jobId: String? = null) {
        if (jobId != null) {
            activeJobs.remove(jobId)?.cancel()
            DownloadProgressBus.cancel(jobId)
        } else {
            stopAll()
        }
    }

    fun stopAll() {
        activeJobs.forEach { (id, job) ->
            job.cancel()
            DownloadProgressBus.cancel(id)
        }
        activeJobs.clear()
        pausedJobs.clear()
    }

    /**
     * Launches a whole-manga download on [scope]. Safe to call from the main
     * thread; all network/disk work runs on Dispatchers.IO.
     */
    fun downloadWhole(context: Context, novel: Novel, scope: CoroutineScope) {
        val appContext = context.applicationContext
        val jobId = "manga_${novel.id}"

        // If this specific novel is already active, don't duplicate
        val existing = activeJobs[jobId]
        if (existing != null && existing.isActive) {
            DownloadProgressBus.update(
                id = jobId,
                done = DownloadProgressBus.queue.firstOrNull { it.id == jobId }?.current ?: 0,
                status = "Download already running..."
            )
            return
        }

        val totalChapters = novel.chapterUrls.size
        val initialItems = novel.chapterUrls.mapIndexed { index, url ->
            val name = novel.chapters.getOrNull(index) ?: "Chapter ${index + 1}"
            DownloadItemState(
                id = url,
                name = name,
                status = DownloadStatus.QUEUED
            )
        }
        DownloadProgressBus.start(
            id = jobId,
            title = novel.title,
            kind = "Manga",
            total = totalChapters,
            novelId = novel.id,
            items = initialItems
        )

        val job = scope.launch(Dispatchers.IO) {
            try {
                runDownload(appContext, novel, jobId)
            } finally {
                activeJobs.remove(jobId)
                pausedJobs.remove(jobId)
                DownloadProgressBus.unregisterCanceller(jobId)
            }
        }

        activeJobs[jobId] = job

        DownloadProgressBus.registerCanceller(jobId) {
            job.cancel()
            activeJobs.remove(jobId)
        }

        DownloadProgressBus.registerPauseController(jobId) { isPaused ->
            if (isPaused) {
                pausedJobs.add(jobId)
            } else {
                pausedJobs.remove(jobId)
            }
        }
    }

    private suspend fun runDownload(context: Context, novel: Novel, jobId: String) {
        val ocrOnDownload = MangaOcrCache.isOcrOnDownloadEnabled(context)
        // Taken ONCE per job: moving a slider mid-download must not reshape a run
        // that is already in flight, or the progress numbers stop meaning anything.
        val tuning = com.lorelight.data.download.DownloadTuning.snapshot(context)
        val blockedReason = com.lorelight.data.download.DownloadTuning.blockedReason(context, tuning)
        if (blockedReason != null) {
            DownloadProgressBus.fail(jobId, blockedReason)
            return
        }
        try {
            val sourceManager = Injekt.get<SourceManager>()
            sourceManager.isInitialized.first { it }
            val sourceId = novel.mangaSourceId
            val source = sourceId?.let { sourceManager.get(it) } as? HttpSource
            if (sourceId == null || source == null) {
                DownloadProgressBus.fail(jobId, "Couldn't download: the manga extension isn't installed.")
                return
            }

            val chapterUrls = novel.chapterUrls
            val chapterNames = novel.chapters
            if (chapterUrls.isEmpty()) {
                DownloadProgressBus.fail(jobId, "Couldn't download: no chapters found for this manga.")
                return
            }

            val rtl = MangaReaderPrefs.getReadingMode(context) == MangaReadingMode.PAGED_RTL
            val loader = MangaImageLoaderProvider.getImageLoader(context)

            var pagesDone = 0
            var pagesTotalKnown = 0
            var failedPages = 0
            val totalChapters = chapterUrls.size

            for (chIndex in chapterUrls.indices) {
                if (DownloadProgressBus.isCancelled(jobId) || activeJobs[jobId]?.isActive == false) {
                    DownloadProgressBus.cancel(jobId)
                    return
                }

                while (pausedJobs.contains(jobId)) {
                    delay(500L)
                    if (DownloadProgressBus.isCancelled(jobId)) {
                        DownloadProgressBus.cancel(jobId)
                        return
                    }
                }

                val encodedUrl = chapterUrls[chIndex]
                val decoded = decodeMangaChapterUrl(encodedUrl)
                val rawUrl = decoded?.second ?: encodedUrl
                val chName = chapterNames.getOrNull(chIndex) ?: "Chapter ${chIndex + 1}"

                DownloadProgressBus.startItem(jobId, encodedUrl)

                val cachedPages = MangaPageListCache.get(sourceId, rawUrl)
                val pages: List<Page> = if (cachedPages != null) {
                    cachedPages
                } else {
                    try {
                        val sChapter = SChapter.create().apply {
                            url = rawUrl
                            name = chName
                        }
                        val fetched = source.getPageList(sChapter).mapIndexed { index, p ->
                            Page(index, p.url, p.imageUrl)
                        }
                        MangaPageListCache.put(sourceId, rawUrl, fetched)
                        fetched
                    } catch (t: Throwable) {
                        emptyList()
                    }
                }

                pagesTotalKnown += pages.size
                var chapterFailedPages = 0

                if (pages.isEmpty()) {
                    DownloadProgressBus.failItem(jobId, encodedUrl, "Failed to read page list")
                } else {
                    // PARALLEL PAGE FETCH.
                    //
                    // This used to be one image at a time with a fixed 120ms gap
                    // after each. For a 200 page chapter that is 200 round trips
                    // paid strictly back to back, and most of a round trip is dead
                    // time: DNS, TLS, the server thinking, Cloudflare. Overlapping
                    // a handful of requests hides that latency, which is where the
                    // real speed-up lives -- not in the transfer itself.
                    //
                    // Width and pacing are the user's "Manga pages at once" and
                    // "Pause between manga pages".
                    val pageGate = kotlinx.coroutines.sync.Semaphore(tuning.parallelPages)
                    val pagesFinished = java.util.concurrent.atomic.AtomicInteger(0)
                    val pagesFailed = java.util.concurrent.atomic.AtomicInteger(0)
                    val aborted = java.util.concurrent.atomic.AtomicBoolean(false)

                    kotlinx.coroutines.coroutineScope {
                        val pageJobs = pages.map { page ->
                            launch {
                                pageGate.acquire()
                                try {
                                    if (aborted.get()) return@launch
                                    if (DownloadProgressBus.isCancelled(jobId) || activeJobs[jobId]?.isActive == false) {
                                        aborted.set(true)
                                        return@launch
                                    }

                                    while (pausedJobs.contains(jobId)) {
                                        delay(500L)
                                        if (DownloadProgressBus.isCancelled(jobId)) {
                                            aborted.set(true)
                                            return@launch
                                        }
                                    }

                                    // 1) Warm the image into Coil's on-disk cache.
                                    val ok = try {
                                        val request = ImageRequest.Builder(context)
                                            .data(MangaPageKey(sourceId, page))
                                            .allowHardware(false)
                                            .build()
                                        loader.execute(request) is SuccessResult
                                    } catch (t: Throwable) {
                                        false
                                    }
                                    if (!ok) pagesFailed.incrementAndGet()

                                    // 2) Optionally pre-compute OCR bubbles for this page.
                                    val ocrPageKey = page.imageUrl?.takeIf { it.isNotBlank() }
                                        ?: page.url.takeIf { it.isNotBlank() }?.let { "$it#${page.index}" }
                                        ?: "page_${page.index}"
                                    if (ocrOnDownload && !MangaOcrCache.has(context, sourceId, ocrPageKey)) {
                                        try {
                                            val blocks = MangaPageOcr.extractBlocks(context, sourceId, page, rtl)
                                            if (blocks != null) MangaOcrCache.save(context, sourceId, ocrPageKey, blocks)
                                        } catch (t: Throwable) {
                                            // OCR is best-effort
                                        }
                                    }

                                    // Progress counts COMPLETIONS, not page index:
                                    // with several in flight, pages finish out of
                                    // order and the bar must still only move forward.
                                    val finished = pagesFinished.incrementAndGet()
                                    DownloadProgressBus.updateItemProgress(
                                        jobId = jobId,
                                        itemId = encodedUrl,
                                        current = finished.toLong(),
                                        total = pages.size.toLong()
                                    )
                                    // Held inside the permit on purpose: the gap has
                                    // to pace requests, and releasing first would let
                                    // the next page start instantly and defeat it.
                                    if (tuning.pageDelayMs > 0L) delay(tuning.pageDelayMs)
                                } finally {
                                    pageGate.release()
                                }
                            }
                        }
                        pageJobs.forEach { it.join() }
                    }

                    pagesDone += pagesFinished.get()
                    failedPages += pagesFailed.get()
                    chapterFailedPages = pagesFailed.get()

                    if (aborted.get()) {
                        DownloadProgressBus.cancel(jobId)
                        return
                    }

                    if (chapterFailedPages == 0) {
                        DownloadProgressBus.finishItem(jobId, encodedUrl)
                    } else {
                        DownloadProgressBus.failItem(jobId, encodedUrl, "$chapterFailedPages/${pages.size} pages failed")
                    }
                }

                // Politeness gap between chapters, same setting the novel
                // downloader uses.
                if (tuning.chapterDelayMs > 0L) delay(tuning.chapterDelayMs)
            }

            val summary = when {
                pagesTotalKnown == 0 -> "No pages could be read for this manga. Open it once online, then try again."
                failedPages == 0 -> "Downloaded $pagesTotalKnown pages for offline reading."
                else -> "Downloaded ${pagesTotalKnown - failedPages} of $pagesTotalKnown pages. $failedPages failed."
            }
            DownloadProgressBus.finish(jobId, summary)
        } catch (t: Throwable) {
            DownloadProgressBus.fail(jobId, "Download failed: ${t.message ?: t.toString()}")
        }
    }
}
