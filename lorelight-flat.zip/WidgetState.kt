package com.lorelight.widget

import android.content.Context
import android.content.res.Configuration
import androidx.compose.ui.graphics.toArgb
import com.lorelight.data.chapters.ChapterReadStore
import com.lorelight.data.model.Novel
import com.lorelight.data.model.isManga
import com.lorelight.data.repository.LibraryRepository
import com.lorelight.tts.TtsPlaybackManager
import com.lorelight.ui.theme.getAppColorScheme
import org.json.JSONArray

internal enum class ResumeMode { EMPTY, READING, MANGA, PLAYING, PAUSED }
internal data class WidgetResume(
    val novel: Novel?, val mode: ResumeMode,
    val chapter: String = "", val page: Int = 0, val percent: Int = 0,
    val chapterIndex: Int = -1, val chapterCount: Int = 0
)

internal object WidgetState {
    fun mode(novel: Novel?, audio: Boolean, playing: Boolean): ResumeMode = when {
        novel == null -> ResumeMode.EMPTY
        novel.isManga -> ResumeMode.MANGA
        audio && playing -> ResumeMode.PLAYING
        audio -> ResumeMode.PAUSED
        else -> ResumeMode.READING
    }
    fun resume(context: Context, library: List<Novel>): WidgetResume {
        val active = TtsPlaybackManager.activeNovel.value
        val audio = active != null && !active.isManga && TtsPlaybackManager.sessionActive.value &&
            (TtsPlaybackManager.isPlaying.value || LibraryRepository.wasLastModeListen(context, active.id))
        val novel = if (audio) active else LibraryRepository.pickResumeEntry(library)
        if (novel == null) return WidgetResume(null, ResumeMode.EMPTY)
        val snapshot = LibraryRepository.observeChapterState(context, novel.id).value
        val stored = ChapterReadStore.currentIndex(novel, snapshot)
        val index = when {
            audio -> TtsPlaybackManager.activeChapterIndex.value
            stored in novel.chapters.indices -> stored
            novel.currentChapterIndex in novel.chapters.indices -> novel.currentChapterIndex
            else -> -1
        }
        val count = if (audio) TtsPlaybackManager.chapters.value.size else novel.chapters.size.takeIf { it > 0 } ?: novel.totalChapters
        val key = if (index >= 0) ChapterReadStore.keyFor(novel, index) else ""
        return WidgetResume(novel, mode(novel, audio, TtsPlaybackManager.isPlaying.value),
            chapter = (if (audio) TtsPlaybackManager.chapters.value.getOrNull(index) else novel.chapters.getOrNull(index))
                ?: novel.currentChapter.ifBlank { "Not started" },
            page = if (key.isBlank()) 0 else snapshot.pageOf(key),
            percent = if (index >= 0 && count > 0) (((index + 1f) / count) * 100).toInt().coerceIn(0,100) else 0,
            chapterIndex = index, chapterCount = count)
    }
}

internal enum class ShelfMode { RECENT, FAVOURITES, SELECTED }
internal enum class ShelfMedia { ALL, NOVELS, MANGA }
internal data class ShelfSettings(
    val mode: ShelfMode = ShelfMode.RECENT,
    val media: ShelfMedia = ShelfMedia.ALL,
    val ids: List<String> = emptyList(), val page: Int = 0
)
internal object WidgetPreferences {
    private fun prefs(context: Context) = context.getSharedPreferences("lorelight_widgets", Context.MODE_PRIVATE)
    fun load(context: Context, id: Int): ShelfSettings {
        val p = prefs(context)
        return ShelfSettings(
            mode = runCatching { ShelfMode.valueOf(p.getString("mode_$id", "RECENT")!!) }.getOrDefault(ShelfMode.RECENT),
            media = runCatching { ShelfMedia.valueOf(p.getString("media_$id", "ALL")!!) }.getOrDefault(ShelfMedia.ALL),
            ids = runCatching { val a = JSONArray(p.getString("ids_$id", "[]")); (0 until a.length()).map { a.getString(it) } }.getOrDefault(emptyList()),
            page = p.getInt("page_$id", 0).coerceAtLeast(0))
    }
    fun save(context: Context, id: Int, settings: ShelfSettings) {
        prefs(context).edit().putString("mode_$id", settings.mode.name)
            .putString("media_$id", settings.media.name)
            .putString("ids_$id", JSONArray(settings.ids).toString()).putInt("page_$id", settings.page).apply()
    }
    fun delete(context: Context, id: Int) {
        prefs(context).edit().remove("mode_$id").remove("media_$id").remove("ids_$id").remove("page_$id").apply()
    }
    fun entries(library: List<Novel>, settings: ShelfSettings): List<Novel> {
        val eligible = library.filter { when (settings.media) {
            ShelfMedia.ALL -> true
            ShelfMedia.NOVELS -> !it.isManga
            ShelfMedia.MANGA -> it.isManga
        } }
        return when (settings.mode) {
            ShelfMode.RECENT -> eligible.sortedWith(compareByDescending<Novel> { it.lastReadTimestamp }.thenByDescending { it.dateAdded })
            ShelfMode.FAVOURITES -> eligible.filter { it.isFavorite }.sortedByDescending { it.lastReadTimestamp }
            ShelfMode.SELECTED -> { val byId = eligible.associateBy { it.id }; settings.ids.distinct().mapNotNull { byId[it] } }
        }
    }
}

internal data class WidgetPalette(val surface: Int, val text: Int, val secondary: Int, val accent: Int, val onAccent: Int, val outline: Int)
internal object WidgetAppearance {
    fun scheme(context: Context): androidx.compose.material3.ColorScheme {
        val p = context.getSharedPreferences("reader_prefs", Context.MODE_PRIVATE)
        val light = when (p.getString("app_theme_mode", "Dark")) {
            "Light" -> true
            "Dark" -> false
            else -> context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK != Configuration.UI_MODE_NIGHT_YES
        }
        return getAppColorScheme(p.getString("app_theme", "Forest Green") ?: "Forest Green", light)
    }
    fun palette(context: Context): WidgetPalette {
        val c = scheme(context)
        // Opaque surface: wallpaper must not destroy text contrast.
        return WidgetPalette(c.surfaceVariant.toArgb(), c.onSurface.toArgb(), c.onSurfaceVariant.toArgb(),
            c.primary.toArgb(), c.onPrimary.toArgb(), c.outline.toArgb())
    }
}
