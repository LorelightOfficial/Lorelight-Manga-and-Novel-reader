package com.lorelight.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.lorelight.crawler.CrawlerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class NovelImportService : Service() {

    companion object {
        const val TAG = "NovelImportService"
        const val NOTIFICATION_ID = 2027
        const val CHANNEL_ID = "novel_import_channel"

        const val EXTRA_NOVEL_ID = "extra_novel_id"
        const val EXTRA_SOURCE_URL = "extra_source_url"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_SITE_STATUS = "extra_site_status"

        fun start(context: Context, novelId: String, sourceUrl: String, title: String, siteStatus: String) {
            val intent = Intent(context, NovelImportService::class.java).apply {
                putExtra(EXTRA_NOVEL_ID, novelId)
                putExtra(EXTRA_SOURCE_URL, sourceUrl)
                putExtra(EXTRA_TITLE, title)
                putExtra(EXTRA_SITE_STATUS, siteStatus)
            }
            ContextCompat.startForegroundService(context, intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val novelId = intent.getStringExtra(EXTRA_NOVEL_ID) ?: ""
        val sourceUrl = intent.getStringExtra(EXTRA_SOURCE_URL) ?: ""
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "Novel"
        val siteStatus = intent.getStringExtra(EXTRA_SITE_STATUS) ?: "Ongoing"

        if (novelId.isBlank() || sourceUrl.isBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }

        // 1. Show foreground notification immediately
        val initialNotification = buildNotification(title, "Starting import...", 0, 0)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID, 
                initialNotification, 
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, initialNotification)
        }

        // 2. Launch crawler coroutine
        serviceScope.launch {
            try {
                CrawlerEngine.streamChapters(sourceUrl, applicationContext) { chapters, siteTotal ->
                    NovelImportManager.applyChapters(applicationContext, novelId, chapters, siteTotal)
                    updateNotification(title, chapters.size, siteTotal)
                }
                NovelImportManager.markDone(applicationContext, novelId, siteStatus.takeIf { it.isNotBlank() && it != "Importing" } ?: "Completed")
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                com.lorelight.core.DiagnosticLogger.log("ERROR", e.message ?: e.toString())
                NovelImportManager.markDone(applicationContext, novelId, "Error")
            } finally {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(startId)
            }
        }

        return START_REDELIVER_INTENT
    }

    private fun updateNotification(title: String, current: Int, total: Int) {
        val text = if (total > 0) "Imported $current / $total chapters" else "Imported $current chapters"
        val notification = buildNotification(title, text, current, total)
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    private fun buildNotification(title: String, text: String, current: Int, total: Int): Notification {
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Importing $title")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)

        if (total > 0) {
            builder.setProgress(total, current, false)
        } else {
            builder.setProgress(100, 0, true)
        }

        // Click on notification can launch MainActivity
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            val pendingIntent = PendingIntent.getActivity(
                this, 
                0, 
                launchIntent, 
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.setContentIntent(pendingIntent)
        }

        return builder.build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Novel Import Service"
            val descriptionText = "Shows background novel import progress"
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                setShowBadge(true)
            }
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
}
