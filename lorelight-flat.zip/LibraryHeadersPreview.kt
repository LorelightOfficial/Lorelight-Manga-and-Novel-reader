package com.lorelight.ui.library

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

/** Open in Android Studio's Design view to inspect the actual native layouts. */
@Preview(name = "Small phone", widthDp = 320, heightDp = 420, fontScale = 1f, showBackground = true)
@Preview(name = "Small phone - 200% text", widthDp = 320, heightDp = 520, fontScale = 2f, showBackground = true)
@Preview(name = "Phone - 150% text", widthDp = 360, heightDp = 480, fontScale = 1.5f, showBackground = true)
@Preview(name = "Tablet", widthDp = 800, heightDp = 420, fontScale = 1f, showBackground = true)
@Preview(name = "Tablet - 200% text", widthDp = 800, heightDp = 520, fontScale = 2f, showBackground = true)
@Composable
private fun LibraryHeadersPreview() {
    MaterialTheme(colorScheme = darkColorScheme()) {
        Surface {
            Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                var media by remember { mutableStateOf("novels") }
                LibraryBookshelfHeader(
                    title = "My Bookshelf",
                    mediaOptions = listOf("novels" to "Novels", "manga" to "Manga"),
                    selectedMedia = media,
                    showMediaFilter = true,
                    onMediaSelected = { media = it }
                ) {
                    IconButton(onClick = {}, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Default.Tune, "Sort & Filter")
                    }
                    IconButton(onClick = {}, modifier = Modifier.size(48.dp)) {
                        Icon(Icons.Default.MoreVert, "Bookshelf Options")
                    }
                }
                // Empty selection, single selection, multiple selection, large count.
                listOf(0, 1, 12, 12345).forEach { count ->
                    LibrarySelectionToolbar(
                        selectedCount = count,
                        hasItems = true,
                        allSelected = count == 12345,
                        onClose = {},
                        onSelectAll = {},
                        onEdit = {},
                        onMigrate = {},
                        onDelete = {}
                    )
                }
            }
        }
    }
}
