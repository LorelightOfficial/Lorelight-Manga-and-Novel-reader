# Changes Log

## Fix Library Re-animation on TTS Updates (BUG A)
- **File**: `app/src/main/java/com/lorelight/ui/library/LibraryScreen.kt`
- **Description**: Removed `displayedNovels` from the `LaunchedEffect` key list for grid entrance animations. The keys are now strictly `(libraryMediaFilter, librarySourceFilter, librarySortMode, libraryLoaded)`. This prevents the library bookshelf grid from re-triggering its slide/fade entrance animation every time a new TTS sentence updates the novel's timestamp/progress.

## Fix Blank/Empty Manga Pages on Scroll Back (BUG B)
- **File**: `app/src/main/java/com/lorelight/manga/reader/MangaWebtoonViewer.kt`
- **Description**: Updated `WebtoonPageItem` to render a placeholder whenever the image page status is not `Ready` (regardless of `knownAspect`). When `knownAspect` is available, the placeholder fills the reserved aspect-ratio box to maintain stable layout geometry; otherwise, it defaults to 300dp. Added a dim background fill and centered progress indicator so recycled/re-decoding pages do not show as blank background.
- **File**: `app/src/main/java/com/lorelight/manga/reader/MangaPageLoader.kt`
- **Description**: Raised Coil memory cache `maxSizePercent` from `0.25` to `0.45` in `MangaImageLoaderProvider` to keep more adjacent software bitmaps in memory, reducing memory eviction during scrolling.

## Add Bounded Prefetching for Manga Pages (BUG C)
- **File**: `app/src/main/java/com/lorelight/manga/reader/MangaWebtoonViewer.kt`
- **Description**: Integrated bounded prefetching inside the active page change listener in `MangaWebtoonViewer`. When the active page changes, Coil image requests are enqueued for adjacent pages (previous ~2 and next ~4 `MangaFeedItem.Page` items) using `MangaPageKey` if not already `Ready`.

## Filter Extensions Screen to Show Only Available Extensions (CHANGE 1)
- **File**: `app/src/main/java/com/lorelight/manga/ui/MangaExtensionsScreen.kt`
- **Description**: Removed the "UPDATE AVAILABLE" and "INSTALLED" sticky headers and item blocks from the extension LazyColumn so only available (not-installed) extensions are displayed. Updated empty-state condition to depend solely on `notInstalled.isEmpty()`.

## Add Uninstall Overflow Menu to Sources (CHANGE 2)
- **File**: `app/src/main/java/com/lorelight/manga/ui/MangaSourcesScreen.kt`
- **Description**: Added a three-dot `Icons.Filled.MoreVert` overflow menu to `SourceListItem` for installed sources that opens a DropdownMenu with an "Uninstall" option. Tapping "Uninstall" triggers a confirmation AlertDialog (`Uninstall {name}? Its sources will be removed from Browse.`). On confirm, invokes `MangaExtensionManager.uninstallExtension`, clears source/page caches, refreshes the source list, and displays a Toast notification.

## Cache Sources List and First-Page Results (CHANGE 3)
- **File**: `app/src/main/java/com/lorelight/manga/ui/MangaSourcesScreen.kt`
- **Description**: Added process-level `MangaSourcesCache` to store resolved sources and extension mappings. Re-entering the Sources screen seeds instantly from cache and refreshes quietly in the background without full-screen loading spinners.
- **File**: `app/src/main/java/com/lorelight/manga/ui/MangaSourceScreen.kt`
- **Description**: Created `MangaFirstPageCache` in-memory cache with a 5-minute TTL keyed by `(sourceId, mode, query)`. Opening a source populates `mangaList` instantly when cached and executes a background network refresh, preserving pagination, search, and filter logic without altering underlying `CatalogueSource` APIs.

## History Page Date Grouping (CHANGE 1)
- **File**: `app/src/main/java/com/lorelight/ui/library/HistoryScreen.kt`
- **Description**: Updated `historyDayLabel` so "Today" is the only relative date label. Removed "Yesterday" and weekday branches so all items prior to today are grouped under their actual calendar dates (`d MMM yyyy`).

## Resilient Manga Cover Loading & Details Page Cache Reuse (CHANGE 2)
- **File**: `app/src/main/java/com/lorelight/ui/library/DetailsScreen.kt`
- **Description**: Rendered http/https manga covers on the Details screen with `MangaCoverImage` instead of `NovelCoverImage`, passing `coverUrl`, `mangaSourceId`, and `title`. This reuses the exact same source headers and Coil cache used in Browse so covers load reliably and appear instantly from cache.
- **File**: `app/src/main/java/com/lorelight/manga/ui/MangaCoverImage.kt`
- **Description**: Configured `SubcomposeAsyncImage` to use the shared `MangaImageLoaderProvider.getImageLoader(context)` disk cache. Added fallback `User-Agent` header (`Mozilla/5.0 (Android)`) whenever the resolved `HttpSource` headers do not provide one.

## Read-aloud Smooth Distance-Aware Scrolling (CHANGE 1)
- **File**: `app/src/main/java/com/lorelight/manga/reader/MangaReaderScreen.kt`
- **Description**: Replaced double-jump scrolling in `focusTtsBlock` with single distance-aware animated moves. If target item is off-screen, uses `animateScrollToItem`. Skips micro-adjustments when delta is less than 10% viewport height, and sets animation duration proportionally (`180ms..650ms`) using `FastOutSlowInEasing`.

## Accelerated Parallel OCR & Look-Ahead Depth Setting (CHANGE 2)
- **File**: `app/src/main/java/com/lorelight/manga/reader/MangaTtsController.kt`
- **Description**: Added `scaleBitmapIfNeeded` in `loadBitmap` to cap page bitmap longest side at ~2048px before ML Kit text recognition for significantly faster OCR processing without loss of accuracy.
- **File**: `app/src/main/java/com/lorelight/manga/reader/MangaReaderPrefs.kt`
- **Description**: Added `KEY_OCR_LOOKAHEAD` preference with `getOcrLookahead` (default 1) and `setOcrLookahead` (range 0..5).
- **File**: `app/src/main/java/com/lorelight/manga/reader/MangaReaderScreen.kt`
- **Description**: Replaced single-page prefetch with concurrent async OCR jobs for up to `ocrLookahead` upcoming uncached pages, overlapping bitmap decode and recognition. Preserved on-demand OCR for current page when lookahead is 0.
- **File**: `app/src/main/java/com/lorelight/manga/reader/MangaReaderSettingsPanel.kt`
- **Description**: Added "OCR pages ahead" slider control (range 0–5) in reader settings under experimental read-aloud options, persisting preference changes immediately.

## Process-Level In-Memory Cache for Manga Extensions Screen
- **File**: `app/src/main/java/com/lorelight/manga/ui/MangaExtensionsCache.kt`
- **Description**: Created process-lifetime singleton `MangaExtensionsCache` to store available extension info and installed extensions.
- **File**: `app/src/main/java/com/lorelight/manga/ui/MangaExtensionsScreen.kt`
- **Description**: Seeded initial extension screen state from `MangaExtensionsCache`, skipping network fetch when cache is populated and avoiding redundant loading spinners on screen re-entry. Invalidated cache prior to refresh upon extension installation, uninstallation, updates, or repository modifications.

## Manga Reader Page Caching & Placeholder Optimizations
- **File**: `app/src/main/java/com/lorelight/manga/reader/MangaPageLoader.kt`
- **Description**: Expanded memory cache capacity (`0.50` RAM) and disk cache size (`512MB`), and explicitly enabled `memoryCachePolicy` and `diskCachePolicy` (`CachePolicy.ENABLED`).
- **File**: `app/src/main/java/com/lorelight/manga/reader/MangaWebtoonViewer.kt`
- **Description**: Added deterministic `pageCacheKey` (`memoryCacheKey`, `diskCacheKey`, and `placeholderMemoryCacheKey`) to `AsyncImage` so recycled pages render their cached bitmaps immediately on the first frame. Updated placeholder background drawing while image is not ready.

## Manga Reader Voice Controls for Read-Aloud
- **File**: `app/src/main/java/com/lorelight/manga/reader/MangaTtsVoiceControls.kt`
- **Description**: Added `MangaTtsVoiceControls` composable for selecting Accent, Voice, and Speed bound to the shared `TtsPlaybackManager`.
- **File**: `app/src/main/java/com/lorelight/manga/reader/MangaReaderSettingsPanel.kt`
- **Description**: Added `MangaTtsVoiceControls()` in the manga reader settings panel under experimental TTS options.
- **File**: `app/src/main/java/com/lorelight/manga/reader/MangaTtsController.kt`
- **Description**: Invoked `applyVoiceSettings()` before speaking each text block in `MangaTtsController.speak()` so voice setting changes apply immediately mid-playback.

## Lorelight Unified Storage & Persistence Refactor
- **Files**: `app/src/main/java/com/lorelight/data/local/StorageReset.kt`, `app/src/main/java/com/lorelight/data/db/DbWriter.kt`, `app/src/main/java/com/lorelight/data/repository/NovelRepository.kt`, `app/src/main/java/com/lorelight/data/local/AppPrefs.kt`, `app/src/main/java/com/lorelight/network/HttpClients.kt`, `app/src/main/java/com/lorelight/data/local/NovelPreferences.kt`
- **Description**: Unified all reading progress, history, and library storage into a single Room database backed by a serial background FIFO writer (`DbWriter`). Executed a one-time idempotent hard storage reset (`StorageReset`) to eliminate conflicting legacy JSON snapshots, SharedPreference sources, and self-healing auto-restores. Guaranteed thread-safe, monotonic progress updates and synchronous disk flushing on app process termination.

## Build blocker fix: R / BuildConfig namespace (2026-08-17)
- Repointed BuildConfig imports from eu.kanade.tachiyomi.BuildConfig to com.lorelight.BuildConfig in 4 files (FileExtensions, ShizukuInstaller, ExtensionInstallReceiver, NotificationReceiver). Only APPLICATION_ID/DEBUG used, both present under com.lorelight.
- Repointed R imports from eu.kanade.tachiyomi.R to com.lorelight.R in 6 files.
- Added 9 missing vector drawables from upstream Mihon (ic_extension_24dp, ic_mihon, ic_pause_24dp, ic_play_arrow_24dp, ic_close_24dp, ic_warning_white_24dp, ic_book_24dp, ic_done_24dp, ic_refresh_24dp).
- Added res/values/colors.xml with accent_blue (#0058A0).
- ContextExtensions: R.style.Theme_Tachiyomi -> R.style.Theme_Lorelight (use app own theme, avoids importing Mihon full theme cascade).
- DownloadJob: converted 3 android R.string notifier strings to MR (tachiyomi.i18n.MR + Context.stringResource), matching sibling notifier files.

## Add missing getBitmapOrNull helper (2026-08-17)
- Added eu.kanade.tachiyomi.util.system.ImageExtensions.kt providing Drawable.getBitmapOrNull(), which the library-update notification imports to turn a loaded cover into a bitmap. This was one of the missing vendored helpers; adding it lets the notifier (already converted to Coil 2) resolve cleanly.

## Add missing standalone util classes (2026-08-17)
- Added DeviceUtil (isMiui/isSamsung/invalidDefaultBrowsers), WebViewUtil.supportsWebView plus WebView.setDefaultSettings()/setUserAgent() extensions, and LocaleHelper (getDefaultEnabledLanguages/comparator/getDisplayName). These are the self-contained helpers the network WebView interceptor and the source/extension language lists import. They have no database or theming dependencies, so they are safe to add on their own.

## Add reader/theming support classes (2026-08-17)
- Added the Mihon reader/theming helpers the backend still referenced: ThemeMode + AppTheme enums, UiPreferences (theme mode/app theme/AMOLED), ThemingDelegate, ReaderPreferences (reader background theme + TappingInvertMode), and the ReadingMode/ReaderOrientation viewer-flag enums used by the domain Manga model.
- ThemingDelegate.getThemeResIds returns no extra style overlays, so the app keeps its own Theme.Lorelight look unchanged. These Mihon classes only feed the manga-reader theme context; the app novel UI keeps using its own ReaderViewModel theming.
- Registered UiPreferences and ReaderPreferences in the Injekt preference module so the reader-theme context resolves them at runtime.

## Port remaining 15 Mihon classes from official source (2026-08-17)
- Copied from the official Mihon zip (0.20.4): manga interactors (UpdateManga, Get/SetExcludedScanlators, SetMangaViewerFlags), DB chapter models (Chapter interface + toDomainChapter, ChapterImpl), the core archive module (ArchiveReader/EpubReader/ZipWriter + helpers) for epub/cbz reading, Shizuku extension-installer (ShellInterface + IShellInterface.aidl), and models MigrationFlag + RemoteMangaUpdate.
- ShellInterface adapted for Lorelight: BuildConfig import switched to com.lorelight, and Kotlin 2.2 multi-dollar strings rewritten for Kotlin 2.1.
- Added libraries to version catalog + app deps: libarchive (1.1.6), unifile, shizuku api/provider (13.1.5). Added ShizukuProvider to the manifest. All four interactors were already registered in the DI module.

## Full audit fixes (2026-08-17)
- Re-applied notification icon remap (13 references to deleted Mihon icons now use the app-own ic_tts_notification or neutral android system icons) in DownloadNotifier, LibraryUpdateNotifier, ExtensionUpdateNotifier, ExtensionInstallService. These were hard build failures.
- Re-applied Coil 2 conversion of LibraryUpdateNotifier (coil3 imports/usages removed; app ships Coil 2 only).
- Deleted 5 dead Coil-3 files in data/coil (they imported coil3 which is not a dependency = build failure) plus 3 confirmed-unreferenced manga files: MangaPageQueue.kt, MangaReaderGestures.kt, MangaSanitize.kt.
- Verified: all braces balanced (428 files), all XML valid, TOML valid, every R.* resource reference resolves, no duplicate class declarations, all main screens connected to navigation.

## Enable real release minification (2026-08-17)
- Removed the R8 kill-switches (-dontobfuscate/-dontoptimize): release builds now get full code shrinking + obfuscation + optimization, which also lets resource shrinking actually remove unused resources. Enabled R8 full mode in gradle.properties.
- Added keep rules for the newly added libraries (libarchive native, unifile, shizuku, SQLDelight) so minification does not break epub/cbz reading, extension installs, or the database. Line numbers kept so crash logs stay readable.

## Hidden developer log panel (2026-08-17)
- About Lorelight: tapping the circular info icon 5 times unlocks a Developer Logs panel below the app info (stays unlocked).
- Panel shows a rolling live log (app starts, crashes, handled errors) in a monospace view with Copy, Share and Refresh buttons, so logs can be pasted/shared when reporting issues.
- DevLogStore auto-wipes entries older than 24 hours on every read/write and caps the log at 1500 lines, so it can never grow storage.
- CrashReporter now also feeds every crash/handled error into the dev log, and app startup is logged.

## Add unpack workflow for zip-based repo updates (2026-08-17)
- Added .github/workflows/unpack.yml: a manual one-shot action that extracts checkpoint6-cleaned.zip from the repo root and replaces the whole repo with it, avoiding per-file GitHub API rate limits.

## Auto zip-to-APK pipeline (2026-08-17)
- Restored the Build Release APK workflow (was only in the GitHub repo, never in the app zip) into .github/workflows/build-release.yml, now ignoring pushes that only add a zip.
- Added .github/workflows/unpack.yml: on uploading any .zip to the repo it auto-extracts it, replaces the old source, removes the zip, commits, then builds and uploads the signed release APK in the same run. One upload = full rebuild, no per-file rate limits.
