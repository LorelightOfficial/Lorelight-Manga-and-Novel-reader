package com.lorelight.ui.reader

import androidx.compose.ui.graphics.Color

fun getThemeBgColor(themeState: String): Color {
    return when (themeState) {
        "blackgold" -> Color(0xFF0C0A07)       // Rich deep obsidian gold-black
        "Satin Pink" -> Color(0xFF140D12)      // Luxury dark satin plum-pink
        "readerblacknew" -> Color.Black        // Complete AMOLED Black (#000000)
        "Ocean Blue" -> Color(0xFF060B11)      // Deep sea navy
        "cyne" -> Color(0xFF080F12)            // Deep tech cyber cyan-black
        "readerpurple" -> Color(0xFF0A0712)    // Deep velvet royal purple
        "readerblood" -> Color(0xFF100808)     // Deep blood crimson-black
        else -> Color(0xFF051109)              // Deep forest green
    }
}

fun getThemeTextColor(themeState: String): Color {
    return when (themeState) {
        "blackgold" -> Color(0xFFE9C484)       // Muted gold text
        "Satin Pink" -> Color(0xFFEBC7D5)      // Soft pastel rose text
        "readerblacknew" -> Color(0xFFE4E4E7)  // Slate white text (excellent soft white contrast!)
        "Ocean Blue" -> Color(0xFFCBE2F7)      // Clear soft azure text
        "cyne" -> Color(0xFFC2F3F8)            // Lucid electric cyan text
        "readerpurple" -> Color(0xFFE9DDF5)    // Muted lavender text
        "readerblood" -> Color(0xFFF9D5D5)     // Muted crimson-rose text
        else -> Color(0xFFD2E8D4)              // Forest sage text
    }
}

fun getDefaultHighlightColor(themeState: String): Color {
    return when (themeState) {
        "blackgold" -> Color(0xFFE1B970)
        "Satin Pink" -> Color(0xFFFFB0D0)
        "readerblacknew" -> Color(0xFF888888) 
        "Ocean Blue" -> Color(0xFF81C7F4)
        "cyne" -> Color(0xFF62D2DF)
        "readerpurple" -> Color(0xFFD59DFB)
        "readerblood" -> Color(0xFFF28F8F)
        else -> Color(0xFF388E3C)
    }
}

fun blendColors(color1: Color, color2: Color, ratio: Float): Color {
    val r = color1.red + (color2.red - color1.red) * ratio
    val g = color1.green + (color2.green - color1.green) * ratio
    val b = color1.blue + (color2.blue - color1.blue) * ratio
    return Color(red = r.coerceIn(0f, 1f), green = g.coerceIn(0f, 1f), blue = b.coerceIn(0f, 1f), alpha = 1f)
}
