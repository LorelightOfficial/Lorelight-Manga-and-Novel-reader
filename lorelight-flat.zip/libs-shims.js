// Pure-JS module registrations mirroring LNReader's @libs/* (VERIFIED strings) + htmlparser2 stub.

__registerModule('@libs/filterInputs', function(module){
  module.exports = { FilterTypes: {
    TextInput: 'Text',
    Picker: 'Picker',
    CheckboxGroup: 'Checkbox',
    Switch: 'Switch',
    ExcludableCheckboxGroup: 'XCheckbox'
  } };
});

__registerModule('@libs/novelStatus', function(module){
  module.exports = { NovelStatus: {
    Unknown: 'Unknown',
    Ongoing: 'Ongoing',
    Completed: 'Completed',
    Licensed: 'Licensed',
    PublishingFinished: 'Publishing Finished',
    Cancelled: 'Cancelled',
    OnHiatus: 'On Hiatus'
  } };
});

__registerModule('@libs/defaultCover', function(module){
  module.exports = { defaultCover: 'https://github.com/LNReader/lnreader-plugins/blob/main/icons/src/coverNotAvailable.jpg?raw=true' };
});

__registerModule('@libs/isAbsoluteUrl', function(module){
  module.exports = { isUrlAbsolute: function(u){ return /^(?:[a-z+]+:)?\/\//i.test(String(u)); } };
});

__registerModule('@libs/fetch', function(module){
  var __fetchToken = 0;
  function rawFetch(url, init){
    return new Promise(function(resolve, reject){
      var token = ++__fetchToken;
      globalThis.__fetchCallbacks[token] = { resolve: resolve, reject: reject };
      __native.fetch(String(url), JSON.stringify(init || {}), token);
    });
  }
  function wrap(raw){
    var headers = raw.headers || {};
    var lower = {};
    for (var k in headers){ if (headers.hasOwnProperty(k)) lower[k.toLowerCase()] = headers[k]; }
    return {
      ok: raw.status >= 200 && raw.status < 300,
      status: raw.status,
      url: raw.url,
      headers: { get: function(name){ var v = lower[String(name).toLowerCase()]; return v === undefined ? null : v; } },
      text: function(){ return Promise.resolve(raw.body); },
      json: function(){ return Promise.resolve(JSON.parse(raw.body)); }
    };
  }
  function fetchApi(url, init){ return rawFetch(url, init).then(wrap); }
  function fetchText(url, init){ return rawFetch(url, init).then(function(r){ return r.body; }); }
  function fetchFile(){ __native.log('[@libs/fetch] fetchFile is not supported in Lorelight'); throw new Error('fetchFile not supported'); }
  function fetchProto(){ __native.log('[@libs/fetch] fetchProto is not supported in Lorelight'); throw new Error('fetchProto not supported'); }
  module.exports = { fetchApi: fetchApi, fetchText: fetchText, fetchFile: fetchFile, fetchProto: fetchProto };
});

__registerModule('@libs/storage', function(module){
  function now(){ return Date.now(); }
  function toEpoch(expires){
    if (expires == null) return null;
    if (typeof expires === 'number') return expires;
    if (expires instanceof Date) return expires.getTime();
    return null;
  }
  var storage = {
    set: function(key, value, expires){
      var rec = { created: now(), value: value, expires: toEpoch(expires) };
      __native.storageSet(globalThis.__pluginId, String(key), JSON.stringify(rec));
    },
    get: function(key, raw){
      var s = __native.storageGet(globalThis.__pluginId, String(key));
      if (s == null || s === '') return undefined;
      var rec; try { rec = JSON.parse(s); } catch(e){ return undefined; }
      if (rec.expires != null && now() > rec.expires){ __native.storageDelete(globalThis.__pluginId, String(key)); return undefined; }
      return raw ? rec : rec.value;
    },
    getAllKeys: function(){ var s = __native.storageKeys(globalThis.__pluginId); try { return JSON.parse(s) || []; } catch(e){ return []; } },
    delete: function(key){ __native.storageDelete(globalThis.__pluginId, String(key)); },
    clearAll: function(){ __native.storageClear(globalThis.__pluginId); }
  };
  var stubStore = { get: function(){ return {}; } };
  module.exports = { storage: storage, localStorage: stubStore, sessionStorage: stubStore };
});


