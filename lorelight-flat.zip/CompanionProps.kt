/*
 * =============================================================================
 * CompanionProps.kt - which prop appears, when, and how rarely.
 * Package: com.lorelight.companion
 *
 * THE ONLY DESIGN RULE THAT MATTERS HERE: SCARCITY
 *
 * A hat that shows up every time you finish a chapter is a UI element. A hat
 * that shows up twice a month is an event you tell someone about. So the
 * budget below is deliberately mean: a one-in-seven roll, a six hour gap, two
 * a day maximum, and never the same prop twice running.
 *
 * Everything else in this file exists to serve that one rule.
 *
 * WHERE THEY DRAW
 *
 * CompanionPropOverlay goes into CelestialModeToggle's `propOverlay` slot, so
 * it inherits the puck's bob and press dip and lands on the face. It is
 * draw-only and never takes a touch: the tap is the theme toggle, always.
 *
 * WHAT IT DOES NOT DO
 *
 * It never queues. If a prop is already on screen, a second one is dropped.
 * Two hats at once is not a feature.
 * =============================================================================
 */
package com.lorelight.companion

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.delay
import kotlin.random.Random

/* =========================================================================
 * THE BUDGET
 * =======================================================================*/

/**
 * Chance a prop appears when a moment has earned one.
 *
 * A one-in-seven roll, as the file header promises: rare enough that seeing
 * one still means something, common enough that it is not a myth.
 */
private const val PROP_CHANCE = 1f / 7f

/** Six hours between props, so two triggers in the same evening cannot both land one. */
private const val PROP_MIN_GAP_MS = 6 * 60 * 60 * 1000L

/** Two a day, maximum. */
private const val PROP_DAILY_CAP = 2

/**
 * The random loop's cadence and its odds.
 *
 * This is the part that makes props ambient instead of trigger-locked -- he
 * does not need a reason to put a hat on. Polled slowly and at low odds so an
 * ambient prop stays a rare, occasional thing rather than a fixture: it still
 * has to clear the six-hour gap and the daily cap above.
 */
internal const val PROP_RANDOM_POLL_MS = 20_000L
internal const val PROP_RANDOM_CHANCE = 0.05f

/**
 * How long a prop stays on screen once it appears.
 *
 * Long enough to actually read as an outfit rather than a flash -- the
 * catalogue's own `holdMs` is a punchline length, too short for that -- but
 * with the odds and gap above restored, this only ever plays out
 * occasionally, not back-to-back.
 */
internal const val PROP_DWELL_MS = 20_000L

/**
 * Delay before the ONE guaranteed prop of a session.
 *
 * Everything else here is a dice roll, and a dice roll is exactly why props
 * kept being reported as missing: with a 20s poll at 0.35 odds you can easily
 * open the app, look straight at him, and see nothing at all. So the first one
 * after launch is certain. It still respects the daily cap and the gap, so it
 * cannot stack on top of a prop that is already showing.
 */
internal const val PROP_FIRST_DELAY_MS = 1_200L

/* =========================================================================
 * THE CATALOGUE
 * =======================================================================*/

/**
 * Every prop, with its own timing.
 *
 * `holdMs` is the interesting number. A punchline is short.
 * A beard is a joke about time passing, so it lingers. Ambient things like the
 * lantern stay longest because they are scenery rather than punchlines.
 */
enum class CompanionProp(
    val enterMs: Long,
    val holdMs: Long,
    val exitMs: Long,
    /** Some props only suit one character. A lantern is the moon's. */
    val mood: Mood? = null
) {

    /* --- worn on the face --------------------------------------------- */
    SPECTACLES(520L, 4200L, 460L),
    SUNGLASSES(300L, 2400L, 420L),

    /* --- beside and above -------------------------------------------- */
    LANTERN(900L, 5200L, 800L, mood = Mood.MOON);

    /**
     * True for props whose drawing changes frame to frame. The rest are a
     * fixed image once they have finished entering, so the overlay can stop
     * its frame loop for the whole dwell instead of invalidating the draw
     * thousands of times for an identical picture.
     */
    val isAnimated: Boolean
        get() = when (this) {
            LANTERN -> true
            else -> false
        }

    val totalMs: Long get() = enterMs + holdMs + exitMs

    /**
     * Total life of a prop under the always-on rotation: the prop's own
     * entry and exit, with the fixed dwell in between instead of its short
     * punchline hold.
     */
    val dwellTotalMs: Long get() = enterMs + PROP_DWELL_MS + exitMs

    /** The entry/exit envelope for that fixed-dwell rotation. */
    fun dwellEnvelope(elapsedMs: Float): Float = when {
        elapsedMs <= 0f -> 0f
        elapsedMs < enterMs -> easeOutBack(elapsedMs / enterMs)
        elapsedMs < enterMs + PROP_DWELL_MS -> 1f
        elapsedMs < dwellTotalMs -> {
            val t = (elapsedMs - enterMs - PROP_DWELL_MS) / exitMs.toFloat()
            1f - easeInQuad(t.coerceIn(0f, 1f))
        }
        else -> 0f
    }

    /**
     * The entry/exit envelope at [elapsedMs], 0..1.
     *
     * Entry is eased out so props arrive with weight and leave without
     * snapping. Exit is faster than entry on every prop: the arrival is the
     * part worth watching.
     */
    fun envelope(elapsedMs: Float): Float = when {
        elapsedMs <= 0f -> 0f
        elapsedMs < enterMs -> easeOutBack(elapsedMs / enterMs)
        elapsedMs < enterMs + holdMs -> 1f
        elapsedMs < totalMs -> {
            val t = (elapsedMs - enterMs - holdMs) / exitMs.toFloat()
            1f - easeInQuad(t.coerceIn(0f, 1f))
        }
        else -> 0f
    }
}

/** A little overshoot on arrival. Props should land, not materialise. */
private fun easeOutBack(t: Float): Float {
    val x = t.coerceIn(0f, 1f) - 1f
    return 1f + x * x * (2.70158f * x + 1.70158f)
}

private fun easeInQuad(t: Float) = t * t

/* =========================================================================
 * WHAT EARNS WHAT
 * =======================================================================*/

/**
 * The props each moment can produce. First match that survives the budget
 * wins; an empty list means this moment never produces a prop.
 *
 * The pairings are the joke, and they are chosen so the prop reads as a
 * comment on the moment rather than random dress-up:
 *
 *  - ninety minutes reading -> he has put his reading SPECTACLES on
 *  - switching to dark      -> SUNGLASSES, obviously
 *  - deep night             -> the LANTERN, because someone has to hold it
 */
internal fun propsFor(event: CompanionEvent): List<CompanionProp> = when (event) {
    CompanionEvent.FIRST_EVER -> emptyList()
    CompanionEvent.BACK_AFTER_AGES -> emptyList()
    CompanionEvent.BACK_AFTER_WEEK -> emptyList()
    CompanionEvent.BACK_AFTER_DAY -> emptyList()
    CompanionEvent.BACK_SAME_DAY -> emptyList()

    CompanionEvent.CHAPTER_DONE -> emptyList()
    CompanionEvent.MODE_SWITCHED -> listOf(CompanionProp.SUNGLASSES)
    CompanionEvent.STREAK -> emptyList()
    CompanionEvent.NOVEL_ADDED -> emptyList()
    CompanionEvent.MANGA_ADDED -> emptyList()

    CompanionEvent.LONG_SESSION -> listOf(CompanionProp.SPECTACLES)
    CompanionEvent.UNFINISHED_WAITING -> emptyList()
    CompanionEvent.LIBRARY_GROWING -> emptyList()
    CompanionEvent.LATE_NIGHT -> listOf(CompanionProp.LANTERN)
    CompanionEvent.EARLY_MORNING -> emptyList()
    CompanionEvent.IDLE_MUSING -> emptyList()
}

/**
 * The propless reaction each moment triggers.
 *
 * Unlike props these are NOT rationed. They cost nothing, they are what makes
 * him feel alive rather than decorated, and a gesture with no bubble is a
 * perfectly good thing for him to do.
 */
internal fun gestureFor(event: CompanionEvent): CompanionGesture = when (event) {
    CompanionEvent.FIRST_EVER -> CompanionGesture.HOP
    CompanionEvent.BACK_AFTER_AGES -> CompanionGesture.DOUBLE_TAKE
    CompanionEvent.BACK_AFTER_WEEK -> CompanionGesture.TILT_CURIOUS
    CompanionEvent.BACK_AFTER_DAY -> CompanionGesture.NOD
    CompanionEvent.BACK_SAME_DAY -> CompanionGesture.GLANCE_RIGHT

    CompanionEvent.CHAPTER_DONE -> CompanionGesture.NOD
    CompanionEvent.MODE_SWITCHED -> CompanionGesture.GLANCE_LEFT
    CompanionEvent.STREAK -> CompanionGesture.HOP
    CompanionEvent.NOVEL_ADDED -> CompanionGesture.TILT_CURIOUS
    CompanionEvent.MANGA_ADDED -> CompanionGesture.TILT_CURIOUS

    CompanionEvent.LONG_SESSION -> CompanionGesture.SLEEPY_SQUINT
    CompanionEvent.UNFINISHED_WAITING -> CompanionGesture.LOOK_AWAY
    CompanionEvent.LIBRARY_GROWING -> CompanionGesture.HOP
    CompanionEvent.LATE_NIGHT -> CompanionGesture.DOZE
    CompanionEvent.EARLY_MORNING -> CompanionGesture.WAKE
    CompanionEvent.IDLE_MUSING -> CompanionGesture.BREATHE
}

/* =========================================================================
 * THE DIRECTOR
 * =======================================================================*/

/**
 * Owns the currently visible prop and the rationing that decides whether
 * there is one at all.
 *
 * Deliberately not a coroutine or a flow: the overlay drives its own frame
 * clock and calls [clear] when the show is over, so this holds one nullable
 * field and four counters.
 */
@Stable
class CompanionPropState internal constructor(
    private val store: CompanionStore,
    /** Injectable for tests; production passes the real dice. */
    private val roll: () -> Float = { Random.nextFloat() }
) {

    /** The prop on screen, or null. Read by the overlay. */
    var active: CompanionProp? by mutableStateOf(null)
        private set

    /**
     * Offers the props a moment has earned. Usually does nothing, which is
     * the entire point.
     *
     * @return true if a prop is now on screen.
     */
    internal fun offer(event: CompanionEvent, mood: Mood, now: Long): Boolean {
        if (active != null) return false

        val candidates = propsFor(event).filter { it.mood == null || it.mood == mood }
        if (candidates.isEmpty()) return false

        if (!withinBudget(now)) return false
        if (roll() > chanceFor(event)) return false

        // Never the same prop twice running: repetition is what turns a
        // surprise into wallpaper.
        val last = store.getString(KEY_LAST)
        val fresh = candidates.filter { it.name != last }
        val pool = if (fresh.isEmpty()) candidates else fresh
        val chosen = pool[(roll() * pool.size).toInt().coerceIn(0, pool.size - 1)]

        show(chosen, now)
        return true
    }

    /**
     * Offers a prop for no reason whatsoever.
     *
     * [offer] can only ever fire when something happens, and the interesting
     * things happen rarely -- that is the real reason props were invisible.
     * This one needs no trigger and draws from the whole catalogue. It is
     * called on a slow loop, so props become weather rather than a reward.
     *
     * Mood still filters: the lantern belongs to the moon.
     *
     * @return true if a prop is now on screen.
     */
    internal fun offerRandom(
        mood: Mood,
        now: Long,
        /** Skips the dice only. The gap and the daily cap still apply. */
        certain: Boolean = false
    ): Boolean {
        if (active != null) return false
        if (!withinBudget(now)) return false
        if (!certain && roll() > PROP_RANDOM_CHANCE) return false

        val candidates = CompanionProp.entries.filter {
            it.mood == null || it.mood == mood
        }
        if (candidates.isEmpty()) return false

        // Never the same prop twice running, same as the event path: repetition
        // is what turns a surprise into wallpaper.
        val last = store.getString(KEY_LAST)
        val fresh = candidates.filter { it.name != last }
        val pool = if (fresh.isEmpty()) candidates else fresh
        val chosen = pool[(roll() * pool.size).toInt().coerceIn(0, pool.size - 1)]

        show(chosen, now)
        return true
    }

    /**
     * Shows a prop immediately, bypassing the dice but NOT the daily cap.
     *
     * Used for the handful of moments where the prop IS the response and a
     * silent nothing would be a bug: a facepalm at the fourth reopen of the
     * same chapter, a rain cloud when a page will not load.
     */
    internal fun forceShow(prop: CompanionProp, mood: Mood, now: Long): Boolean {
        if (active != null) return false
        if (prop.mood != null && prop.mood != mood) return false
        if (!withinBudget(now)) return false
        show(prop, now)
        return true
    }

    private fun show(prop: CompanionProp, now: Long) {
        val day = now / 86_400_000L
        val storedDay = store.getLong(KEY_DAY, -1L)
        val count = if (storedDay == day) store.getInt(KEY_COUNT, 0) else 0

        store.putLong(KEY_AT, now)
        store.putLong(KEY_DAY, day)
        store.putInt(KEY_COUNT, count + 1)
        store.putString(KEY_LAST, prop.name)

        active = prop
    }

    /** Called by the overlay when the show has finished playing out. */
    internal fun clear() {
        active = null
    }

    /**
     * A prop's chance. Most moments use the mean default; the two moments
     * that are already rare on their own get to be certain, because rolling
     * dice on something that happens once a month just deletes the feature.
     */
    private fun chanceFor(event: CompanionEvent): Float = when (event) {
        CompanionEvent.FIRST_EVER -> 1.0f
        CompanionEvent.BACK_AFTER_AGES -> 1.0f
        CompanionEvent.LIBRARY_GROWING -> 1.0f
        else -> PROP_CHANCE
    }

    private fun withinBudget(now: Long): Boolean {
        val lastAt = store.getLong(KEY_AT, 0L)
        if (lastAt > 0L && now - lastAt < PROP_MIN_GAP_MS) return false

        val day = now / 86_400_000L
        if (store.getLong(KEY_DAY, -1L) == day &&
            store.getInt(KEY_COUNT, 0) >= PROP_DAILY_CAP
        ) {
            return false
        }
        return true
    }

    private companion object {
        const val KEY_AT = "prop.at"
        const val KEY_DAY = "prop.day"
        const val KEY_COUNT = "prop.count"
        const val KEY_LAST = "prop.last"
    }
}

/* =========================================================================
 * THE OVERLAY
 * =======================================================================*/

/** Must match BODY_RADIUS_FRACTION in ModeSwitch.kt. */
private const val PUCK_BODY_RADIUS_FRACTION = com.lorelight.ui.theme.modeswitch.celestial.CELESTIAL_BODY_RADIUS_FRACTION

/**
 * Draws the active prop over the puck.
 *
 * Goes into CelestialModeToggle's `propOverlay` slot. Renders nothing at all
 * when there is no prop, which is almost always.
 *
 * @param ink the outline colour. It has to contrast with the BODY rather than
 *        the page, and the body is bright in both themes, so a near-black
 *        token is right in light and dark alike.
 * @param glow the accent, used for flame, glass tint, halos and confetti.
 */
@Composable
fun CompanionPropOverlay(
    state: CompanionPropState,
    ink: Color,
    glow: Color,
    modifier: Modifier = Modifier
) {
    val prop = state.active ?: return

    // Reset per prop. Written from the frame loop, read only inside the draw
    // lambda, so a new value invalidates the draw phase and nothing else.
    val clock = remember(prop) { mutableFloatStateOf(0f) }

    LaunchedEffect(prop) {
        var startNanos = 0L
        val enterEnd = prop.enterMs.toFloat()
        val holdEnd = enterEnd + PROP_DWELL_MS
        while (true) {
            val elapsed = withFrameNanos { now ->
                if (startNanos == 0L) startNanos = now
                val e = (now - startNanos) / 1_000_000f
                clock.floatValue = e
                e
            }
            if (elapsed >= prop.dwellTotalMs) break
            // A static prop is a fixed image for the entire dwell. Sleep
            // through it rather than invalidating the draw every frame for a
            // picture that never changes -- that idle churn is what made the
            // mode-switch animation stutter once props became always-on.
            if (!prop.isAnimated && elapsed >= enterEnd && elapsed < holdEnd) {
                delay((holdEnd - elapsed).toLong().coerceAtLeast(1L))
            }
        }
        state.clear()
    }

    Canvas(modifier = modifier) {
        val elapsed = clock.floatValue
        val envelope = prop.dwellEnvelope(elapsed)
        if (envelope <= 0.002f) return@Canvas

        drawCompanionProp(
            prop = prop,
            center = center,
            r = size.minDimension * PUCK_BODY_RADIUS_FRACTION,
            appear = envelope,
            seconds = elapsed / 1000f,
            ink = ink,
            glow = glow
        )
    }
}
