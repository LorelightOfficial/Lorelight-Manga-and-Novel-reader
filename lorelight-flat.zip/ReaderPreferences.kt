package eu.kanade.tachiyomi.ui.reader.setting

import tachiyomi.core.common.preference.Preference
import tachiyomi.core.common.preference.PreferenceStore

class ReaderPreferences(
    private val preferenceStore: PreferenceStore,
) {

    /**
     * Reader background theme: 0 = White, 1 = Black, 2 = Gray, 3 = Automatic.
     */
    val readerTheme: Preference<Int> = preferenceStore.getInt("pref_reader_theme_key", 1)

    enum class TappingInvertMode(
        val shouldInvertHorizontal: Boolean = false,
        val shouldInvertVertical: Boolean = false,
    ) {
        NONE,
        HORIZONTAL(shouldInvertHorizontal = true),
        VERTICAL(shouldInvertVertical = true),
        BOTH(shouldInvertHorizontal = true, shouldInvertVertical = true),
    }
}
