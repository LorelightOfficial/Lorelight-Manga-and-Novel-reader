package com.lorelight.data.local

import android.content.Context
import com.lorelight.data.db.DbWriter
import com.lorelight.data.db.LorelightDatabase
import com.lorelight.data.db.ProgressStore
import com.lorelight.data.db.toEntity
import com.lorelight.data.db.toNovel
import com.lorelight.data.db.toHistoryEntry
import com.lorelight.data.model.Novel
import com.lorelight.data.model.Website
import com.lorelight.data.model.toJSONObject
import com.lorelight.data.model.toNovel
import com.lorelight.data.model.toWebsite
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object NovelPreferences {

    // FIX A1 + A8: all persistence now goes through the single serialized
    // DbWriter queue. Previously library saves took `saveMutex` inside an IO
    // coroutine while progress saves went straight to Room with no shared
    // ordering at all, so a full-library save built from a slightly older
    // in-memory list could land after a newer progress write and undo it.
    // Snapshot files and prefs commits also ran on the calling (often main)
    // thread; they now run on the writer thread.

    // Read health: false until a database read has genuinely succeeded.
    // While false, ALL saves are refused so a failed read can never
    // overwrite good data with nothing.
    @Volatile private var novelsReadHealthy = false
    @Volatile private var historyReadHealthy = false

    fun isLibraryHealthy(): Boolean = novelsReadHealthy

    /**
     * FIX D3: drops the in-memory library/history caches so the next read comes
     * from the database instead of from process memory.
     *
     * cachedNovels is a process-wide static, and loadNovelsFromPrefs() returns it
     * unconditionally whenever it is set. Nothing cleared it except a full
     * clearLocalData() wipe. A background worker (LibraryUpdateWorker ->
     * NewChaptersManager) populates that static in a process that can easily
     * outlive the Activity, so when the user reopened the app the UI could be
     * handed a list captured hours or days earlier - and then write it back.
     */
    fun invalidateCache() {
        cachedNovels = null
        cachedHistory = null
    }

    @Volatile private var cachedNovels: List<Novel>? = null
    @Volatile private var cachedWebsites: List<Website>? = null

    // FIX C15: canonical settings store; AppPrefs also folds in the legacy
    // "lorelight_settings" file that the library screen used to own.
    private fun prefs(context: Context): android.content.SharedPreferences =
        AppPrefs.get(context)

    fun saveNovelsToPrefs(context: Context, novels: List<Novel>, allowEmpty: Boolean = false) {
        if (!guardSave(context, novels, allowEmpty)) return
        cachedNovels = novels
        val appContext = context.applicationContext
        // FIX D1: `allowEmpty` doubles as the "this list is the whole truth"
        // signal. Only the deliberate delete/replace flows pass it, and only
        // those may run a destructive replaceAll().
        DbWriter.submit("saveNovels(${novels.size})") {
            writeLibrary(appContext, novels, authoritative = allowEmpty)
        }
    }

    // Genuinely synchronous save — used on crash/shutdown paths where the
    // process may die before a background write gets to run. Blocks until the
    // queued write has actually reached disk.
    fun saveNovelsToPrefsSync(context: Context, novels: List<Novel>, allowEmpty: Boolean = false) {
        if (!guardSave(context, novels, allowEmpty)) return
        cachedNovels = novels
        val appContext = context.applicationContext
        DbWriter.awaitBlocking("saveNovelsSync(${novels.size})") {
            writeLibrary(appContext, novels, authoritative = allowEmpty)
        }
    }

    /**
     * Single implementation of a library write. Runs on the writer thread.
     *
     * @param authoritative true only when the caller genuinely knows the FULL
     * library and intends absences to mean deletions (removal + replace flows).
     * Everything else merges, so a stale or partial list can never delete rows.
     */
    private fun writeLibrary(appContext: Context, novels: List<Novel>, authoritative: Boolean) {
        // FIX D2: a full save is usually driven by a UI-held list that predates
        // the newest progress-only write. Layer the reading_progress rows over
        // the incoming list FIRST, so persisting the library can never roll a
        // reading position backwards. (overlay() already ignores rows that are
        // older than the incoming novel, so this is safe in both directions.)
        val safe = if (novels.isEmpty()) novels else ProgressStore.overlay(appContext, novels)
        writeNovelSnapshot(appContext, safe)
        try {
            val dao = LorelightDatabase.get(appContext).novelDao()
            when {
                safe.isEmpty() -> if (authoritative) dao.replaceAllAllowEmpty(emptyList())
                authoritative -> dao.replaceAll(safe.map { it.toEntity() })
                else -> dao.mergeAll(safe.map { it.toEntity() })
            }
            // Phase 1B: keep reading_progress in step with the novel rows.
            ProgressStore.syncAll(appContext, safe)
        } catch (e: Exception) { e.printStackTrace() }
    }

    /**
     * FIX A1: blocks until every queued write has reached disk.
     *
     * Call this from "we might be about to die" paths (activity onStop, TTS
     * pause/stop, service teardown) instead of firing a save and hoping.
     */
    fun flushPendingWrites(timeoutMs: Long = 4_000L): Boolean = DbWriter.drainBlocking(timeoutMs)

    /** Queued-write depth, surfaced by the diagnostics/settings screens. */
    fun pendingWriteCount(): Int = DbWriter.pendingWrites()

    // Returns true if the save is allowed to proceed.
    private fun guardSave(context: Context, novels: List<Novel>, allowEmpty: Boolean): Boolean {
        if (!novelsReadHealthy) {
            android.util.Log.e("NovelPreferences", "SAVE BLOCKED: library was never read successfully this session.")
            return false
        }
        if (novels.isEmpty() && !allowEmpty) {
            val existingCount = cachedNovels?.size ?: readNovelSnapshot(context).size
            if (existingCount > 0) {
                android.util.Log.e("NovelPreferences", "SAVE BLOCKED: refusing to write an empty library over existing data.")
                return false
            }
        }
        return true
    }

    /**
     * Phase 1B fast path: persists ONLY the reading position for one novel.
     *
     * The old route for a page turn was loadNovelsFromPrefs -> copy the whole
     * list -> saveNovelsToPrefs, which upserted every row in the library and then
     * ran a delete pass over every id. Doing that on every page turn and every
     * TTS flush is what left a wide window for the library to come back stale if
     * the process was killed mid-write.
     *
     * This writes one reading_progress row and refreshes the in-memory cache, so
     * a later full save cannot roll the position backwards.
     */
    fun saveProgressOnly(context: Context, novel: Novel) {
        if (!novelsReadHealthy) {
            android.util.Log.e("NovelPreferences", "PROGRESS SAVE BLOCKED: library was never read successfully this session.")
            return
        }
        if (novel.id.isEmpty()) return
        val appContext = context.applicationContext
        updateCachedNovel(novel)
        DbWriter.submit("saveProgress(${novel.id})") { ProgressStore.saveProgress(appContext, novel) }
        // Tell the UI the position moved. The manga path has always done the
        // equivalent of this (NovelImportManager.bump); the novel path never
        // did, which is why novel screens only ever updated on a cold start.
        // Fired AFTER updateCachedNovel so any listener that reloads is
        // guaranteed to read the new position rather than the old one.
        ReadingProgressSignal.notifyChanged()
    }

    /**
     * Blocking variant, for shutdown paths where the process may die immediately.
     *
     * FIX A1: this now really is synchronous. It waits for the write to run on
     * the writer thread, so it is ordered behind any library save that is
     * already queued instead of racing it.
     */
    fun saveProgressOnlySync(context: Context, novel: Novel): Boolean {
        if (!novelsReadHealthy) return false
        if (novel.id.isEmpty()) return false
        updateCachedNovel(novel)
        ReadingProgressSignal.notifyChanged()
        val appContext = context.applicationContext
        var written = false
        DbWriter.awaitBlocking("saveProgressSync(${novel.id})") {
            written = ProgressStore.saveProgress(appContext, novel)
        }
        return written
    }

    /** Swaps one novel in the in-memory library. Does not touch the database. */
    private fun updateCachedNovel(novel: Novel) {
        val current = cachedNovels ?: return
        val idx = current.indexOfFirst { it.id == novel.id }
        if (idx < 0) return
        val updated = current.toMutableList()
        updated[idx] = novel
        cachedNovels = updated
    }

    fun loadNovelsFromPrefs(context: Context): List<Novel> {
        cachedNovels?.let { return it } // serve from memory after first load

        migrateNovelsFromPrefsIfNeeded(context)

        val list = mutableListOf<Novel>()
        var readOk = true
        try {
            LorelightDatabase.get(context).novelDao().getAll().forEach { entity ->
                try { list.add(entity.toNovel()) } catch (e: Exception) { e.printStackTrace() }
            }
        } catch (e: Exception) {
            readOk = false
            e.printStackTrace()
        }

        // SELF-HEAL: the database opened fine but came back empty, while a
        // last-known-good snapshot still holds novels -> restore from snapshot.
        if (readOk && list.isEmpty()) {
            val snapshot = readNovelSnapshot(context)
            if (snapshot.isNotEmpty()) {
                android.util.Log.w("NovelPreferences", "Library was empty; restoring ${snapshot.size} novels from rescue snapshot.")
                try {
                    LorelightDatabase.get(context).novelDao().replaceAll(snapshot.map { it.toEntity() })
                } catch (e: Exception) { e.printStackTrace() }
                list.addAll(snapshot)
            }
        }

        // FAILED READ: never cache this and never allow saving over it.
        if (!readOk) {
            novelsReadHealthy = false
            val snapshot = readNovelSnapshot(context)
            android.util.Log.e("NovelPreferences", "Library read FAILED. Serving ${snapshot.size} novels from snapshot without caching.")
            return snapshot
        }

        // MIGRATION: move inline Base64 covers out of the data into files on disk.
        var migrated = false
        val migratedList = list.map { novel ->
            val cover = novel.coverImageBase64
            if (CoverStorage.isBase64Payload(cover)) {
                val path = CoverStorage.migrateBase64ToFile(context, novel.id, cover!!)
                if (path != null) { migrated = true; novel.copy(coverImageBase64 = path) } else novel
            } else novel
        }
        // LIBRARY BACKEND FIX: same ordering bug as the history path.
        // saveNovelsToPrefs() -> guardSave() rejects the write while
        // novelsReadHealthy is still false, and the flag was not set until
        // after this block. The slimmed cover list was therefore never
        // persisted, so every launch re-migrated the same Base64 covers.
        novelsReadHealthy = true
        if (migrated) {
            saveNovelsToPrefs(context, migratedList) // persist the slim version
        }
        // Phase 1B: reading_progress is the fresher source for reading position.
        // Seed it once from the novel rows, then layer it over what we just read.
        ProgressStore.backfillIfNeeded(context, migratedList)
        val withProgress = ProgressStore.overlay(context, migratedList)

        novelsReadHealthy = true
        cachedNovels = withProgress
        writeNovelSnapshot(context, withProgress)
        return withProgress
    }

    // ONE-TIME migration: copy the legacy SharedPreferences JSON library into Room.
    // The legacy JSON is kept (renamed) as a backup and never read again.
    private fun migrateNovelsFromPrefsIfNeeded(context: Context) {
        try {
            val sharedPrefs = prefs(context)
            if (sharedPrefs.getBoolean("room_migration_done", false)) return

            val dao = LorelightDatabase.get(context).novelDao()
            val jsonStr = sharedPrefs.getString("saved_novels", null)
            if (!jsonStr.isNullOrEmpty() && dao.count() == 0) {
                val legacy = mutableListOf<Novel>()
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    try { legacy.add(arr.getJSONObject(i).toNovel()) } catch (e: Exception) { e.printStackTrace() }
                }
                if (legacy.isNotEmpty()) {
                    dao.replaceAll(legacy.map { it.toEntity() })
                }
                // Keep the old JSON as a safety backup under a different key.
                sharedPrefs.edit()
                    .putString("saved_novels_backup_pre_room", jsonStr)
                    .remove("saved_novels")
                    .putBoolean("room_migration_done", true)
                    .commit()
            } else {
                sharedPrefs.edit().putBoolean("room_migration_done", true).commit()
            }

            // Also migrate reading history from prefs to Room, one time.
            val historyStr = sharedPrefs.getString("reading_history_list", null)
            if (!historyStr.isNullOrEmpty()) {
                val entries = mutableListOf<com.lorelight.data.model.HistoryEntry>()
                val harr = JSONArray(historyStr)
                for (i in 0 until harr.length()) {
                    try {
                        val obj = harr.getJSONObject(i)
                        entries.add(
                            com.lorelight.data.model.HistoryEntry(
                                novelId = obj.optString("novelId"),
                                novelTitle = obj.optString("novelTitle"),
                                chapterId = obj.optString("chapterId"),
                                chapterTitle = obj.optString("chapterTitle"),
                                timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                                lastModified = obj.optLong("lastModified", System.currentTimeMillis()),
                                novelJson = obj.optString("novelJson")
                            )
                        )
                    } catch (e: Exception) { e.printStackTrace() }
                }
                if (entries.isNotEmpty()) {
                    LorelightDatabase.get(context).historyDao()
                        .replaceAll(entries.map { it.toEntity() })
                }
                sharedPrefs.edit()
                    .putString("reading_history_backup_pre_room", historyStr)
                    .remove("reading_history_list")
                    .commit()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun rescueDir(context: Context): java.io.File =
        java.io.File(context.filesDir, "rescue").apply { if (!exists()) mkdirs() }

    private fun writeNovelSnapshot(context: Context, novels: List<Novel>) {
        if (novels.isEmpty()) return
        try {
            val arr = JSONArray()
            novels.forEach { arr.put(it.toJSONObject()) }
            val tmp = java.io.File(rescueDir(context), "novels_snapshot.json.tmp")
            tmp.writeText(arr.toString())
            val target = java.io.File(rescueDir(context), "novels_snapshot.json")
            if (target.exists()) target.delete()
            tmp.renameTo(target)
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun readNovelSnapshot(context: Context): List<Novel> {
        val out = mutableListOf<Novel>()
        try {
            val f = java.io.File(rescueDir(context), "novels_snapshot.json")
            if (!f.exists()) return out
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                try { out.add(arr.getJSONObject(i).toNovel()) } catch (e: Exception) { e.printStackTrace() }
            }
        } catch (e: Exception) { e.printStackTrace() }
        return out
    }

    private fun writeHistorySnapshot(context: Context, history: List<com.lorelight.data.model.HistoryEntry>, allowEmpty: Boolean = false) {
        if (history.isEmpty() && !allowEmpty) return
        try {
            val target = java.io.File(rescueDir(context), "history_snapshot.json")
            if (history.isEmpty()) {
                if (target.exists()) target.delete()
                return
            }
            val arr = JSONArray()
            history.forEach { item ->
                val o = org.json.JSONObject()
                o.put("novelId", item.novelId)
                o.put("novelTitle", item.novelTitle)
                o.put("chapterId", item.chapterId)
                o.put("chapterTitle", item.chapterTitle)
                o.put("timestamp", item.timestamp)
                o.put("lastModified", item.lastModified)
                o.put("novelJson", item.novelJson)
                arr.put(o)
            }
            val tmp = java.io.File(rescueDir(context), "history_snapshot.json.tmp")
            tmp.writeText(arr.toString())
            if (target.exists()) target.delete()
            tmp.renameTo(target)
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun readHistorySnapshot(context: Context): List<com.lorelight.data.model.HistoryEntry> {
        val out = mutableListOf<com.lorelight.data.model.HistoryEntry>()
        try {
            val f = java.io.File(rescueDir(context), "history_snapshot.json")
            if (!f.exists()) return out
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    com.lorelight.data.model.HistoryEntry(
                        novelId = o.optString("novelId"),
                        novelTitle = o.optString("novelTitle"),
                        chapterId = o.optString("chapterId"),
                        chapterTitle = o.optString("chapterTitle"),
                        timestamp = o.optLong("timestamp", System.currentTimeMillis()),
                        lastModified = o.optLong("lastModified", System.currentTimeMillis()),
                        novelJson = o.optString("novelJson")
                    )
                )
            }
        } catch (e: Exception) { e.printStackTrace() }
        return out
    }

    fun saveWebsitesToPrefs(context: Context, websites: List<Website>) {
        cachedWebsites = websites
        val appContext = context.applicationContext
        DbWriter.submit("saveWebsites") { writeWebsites(appContext, websites) }
    }

    private fun writeWebsites(appContext: Context, websites: List<Website>) {
        try {
            val arr = JSONArray()
            websites.forEach { arr.put(it.toJSONObject()) }
            prefs(appContext).edit().putString("saved_websites", arr.toString()).commit()
        } catch (e: Exception) { e.printStackTrace() }
    }

    // Previously this just delegated to the async version, so "Sync" was a lie.
    fun saveWebsitesToPrefsSync(context: Context, websites: List<Website>) {
        cachedWebsites = websites
        val appContext = context.applicationContext
        DbWriter.awaitBlocking("saveWebsitesSync") { writeWebsites(appContext, websites) }
    }

    fun loadWebsitesFromPrefs(context: Context): List<Website> {
        cachedWebsites?.let { return it }
        val list = mutableListOf<Website>()
        try {
            val sharedPrefs = prefs(context)
            val jsonStr = sharedPrefs.getString("saved_websites", null)
            if (!jsonStr.isNullOrEmpty()) {
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    try {
                        val obj = arr.getJSONObject(i)
                        list.add(obj.toWebsite())
                    } catch (ce: Exception) {
                        ce.printStackTrace()
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        // royalroad.com and novelfull.com removed — they are becoming supported sources,
        // so user-added versions must NOT be auto-removed here.
        val deprecatedUrls = listOf("wuxiaworld.com", "lightnovelpub.com", "lightnovelpub", "novelonlinefull.com", "novelfire.net")
        val hasOld = list.any { item -> deprecatedUrls.any { item.url.contains(it) } }
        
        val defaults = listOf(
            Website("https://freewebnovel.com", "FreeWebNovel", "https://www.google.com/s2/favicons?sz=256&domain=freewebnovel.com")
        )
        
        val resultList = if (list.isEmpty() || hasOld) {
            val filtered = list.filterNot { item -> deprecatedUrls.any { item.url.contains(it) } }.toMutableList()
            defaults.forEach { defaultWeb ->
                val normDef = defaultWeb.url.replace("https://", "").replace("http://", "").replace("www.", "").removeSuffix("/")
                if (filtered.none { it.url.replace("https://", "").replace("http://", "").replace("www.", "").removeSuffix("/") == normDef }) {
                    filtered.add(defaultWeb)
                }
            }
            saveWebsitesToPrefs(context, filtered)
            filtered
        } else {
            list
        }
        cachedWebsites = resultList
        return resultList
    }

    // FIX #34: SimpleDateFormat is not thread safe. These are read only from the
    // UI thread (Continue Reading card and History rows).
    private val sdfTimeCached = SimpleDateFormat("h:mm a", Locale.US)
    private val sdfSameYearCached = SimpleDateFormat("d MMMM h:mm a", Locale.US)
    private val sdfOtherYearCached = SimpleDateFormat("d MMMM yyyy, h:mm a", Locale.US)

    fun formatLastReadTime(timestamp: Long): String {
        if (timestamp <= 0L) return "Not started yet"
        val now = System.currentTimeMillis()
        
        val cal1 = Calendar.getInstance()
        cal1.timeInMillis = now
        val cal2 = Calendar.getInstance()
        cal2.timeInMillis = timestamp
        
        val isSameDay = cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                        cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
                        
        cal1.add(Calendar.DAY_OF_YEAR, -1)
        val isYesterday = cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                          cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
                          
        val nowCal = Calendar.getInstance()
        nowCal.timeInMillis = now
        val isSameYear = nowCal.get(Calendar.YEAR) == cal2.get(Calendar.YEAR)

        return when {
            isSameDay -> "Today, ${sdfTimeCached.format(Date(timestamp))}"
            isYesterday -> "Yesterday, ${sdfTimeCached.format(Date(timestamp))}"
            isSameYear -> sdfSameYearCached.format(Date(timestamp))
            else -> sdfOtherYearCached.format(Date(timestamp))
        }
    }

    // FIX #30: never fall back to an arbitrary novel. A novel with
    // lastReadTimestamp == 0L has never been opened, and showing it produced the
    // "1 January 1970" card. Returning null lets the empty state render.
    fun pickResumeNovel(novels: List<com.lorelight.data.model.Novel>): com.lorelight.data.model.Novel? =
        novels.filter { it.lastReadTimestamp > 0L }.maxByOrNull { it.lastReadTimestamp }

    private fun modePrefs(context: Context) =
        context.applicationContext.getSharedPreferences("lorelight_reading_modes", Context.MODE_PRIVATE)

    fun setLastMode(context: Context, novelId: String, listen: Boolean) {
        if (novelId.isBlank()) return
        val editor = modePrefs(context).edit()
        editor.putString("last_mode_$novelId", if (listen) "listen" else "read")
        if (listen) editor.putBoolean("tts_used_$novelId", true)
        editor.apply()
    }

    fun wasLastModeListen(context: Context, novelId: String): Boolean =
        modePrefs(context).getString("last_mode_$novelId", "read") == "listen"

    fun hasUsedTts(context: Context, novelId: String): Boolean =
        modePrefs(context).getBoolean("tts_used_$novelId", false)

    @Volatile private var cachedHistory: List<com.lorelight.data.model.HistoryEntry>? = null

    fun saveHistoryToPrefs(context: Context, history: List<com.lorelight.data.model.HistoryEntry>, allowEmpty: Boolean = false) {
        if (!guardSaveHistory(context, history, allowEmpty)) return
        cachedHistory = history
        val appContext = context.applicationContext
        DbWriter.submit("saveHistory(${history.size})") { writeHistory(appContext, history, allowEmpty = allowEmpty) }
    }

    fun saveHistoryToPrefsSync(context: Context, history: List<com.lorelight.data.model.HistoryEntry>, allowEmpty: Boolean = false) {
        if (!guardSaveHistory(context, history, allowEmpty)) return
        cachedHistory = history
        val appContext = context.applicationContext
        DbWriter.awaitBlocking("saveHistorySync(${history.size})") { writeHistory(appContext, history, allowEmpty = allowEmpty) }
    }

    private fun writeHistory(appContext: Context, history: List<com.lorelight.data.model.HistoryEntry>, allowEmpty: Boolean = false) {
        writeHistorySnapshot(appContext, history, allowEmpty = allowEmpty)
        try {
            val dao = LorelightDatabase.get(appContext).historyDao()
            if (history.isEmpty()) dao.replaceAllAllowEmpty(emptyList())
            else dao.replaceAll(history.map { it.toEntity() })
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun guardSaveHistory(context: Context, history: List<com.lorelight.data.model.HistoryEntry>, allowEmpty: Boolean): Boolean {
        if (!historyReadHealthy) {
            android.util.Log.e("NovelPreferences", "SAVE BLOCKED: history was never read successfully this session.")
            return false
        }
        if (history.isEmpty() && !allowEmpty) {
            val existingCount = cachedHistory?.size ?: readHistorySnapshot(context).size
            if (existingCount > 0) {
                android.util.Log.e("NovelPreferences", "SAVE BLOCKED: refusing to write an empty history over existing data.")
                return false
            }
        }
        return true
    }

    fun loadHistoryFromPrefs(context: Context): List<com.lorelight.data.model.HistoryEntry> {
        cachedHistory?.let { return it }

        migrateNovelsFromPrefsIfNeeded(context)

        val list = mutableListOf<com.lorelight.data.model.HistoryEntry>()
        var readOk = true
        try {
            LorelightDatabase.get(context).historyDao().getAll().forEach { entity ->
                try { list.add(entity.toHistoryEntry()) } catch (e: Exception) { e.printStackTrace() }
            }
        } catch (e: Exception) {
            readOk = false
            e.printStackTrace()
        }

        // SELF-HEAL: the database opened fine but came back empty, while a
        // last-known-good snapshot still holds history -> restore from snapshot.
        if (readOk && list.isEmpty()) {
            val snapshot = readHistorySnapshot(context)
            if (snapshot.isNotEmpty()) {
                android.util.Log.w("NovelPreferences", "History was empty; restoring ${snapshot.size} entries from rescue snapshot.")
                try {
                    LorelightDatabase.get(context).historyDao().replaceAll(snapshot.map { it.toEntity() })
                } catch (e: Exception) { e.printStackTrace() }
                list.addAll(snapshot)
            }
        }

        // FAILED READ: never cache this and never allow saving over it.
        if (!readOk) {
            historyReadHealthy = false
            val snapshot = readHistorySnapshot(context)
            android.util.Log.e("NovelPreferences", "History read FAILED. Serving ${snapshot.size} entries from snapshot without caching.")
            return snapshot
        }

        // MIGRATION: move inline Base64 covers out of embedded novelJson into files on disk.
        var migrated = false
        val migratedEntries = list.map { entry ->
            if (entry.novelJson.isNotEmpty()) {
                try {
                    val json = org.json.JSONObject(entry.novelJson)
                    val cover = json.optString("coverImageBase64", null)
                    if (CoverStorage.isBase64Payload(cover)) {
                        val novelId = entry.novelId.ifEmpty { json.optString("id") }
                        val path = CoverStorage.migrateBase64ToFile(context, novelId, cover!!)
                        if (path != null) {
                            migrated = true
                            json.put("coverImageBase64", path)
                            entry.copy(novelJson = json.toString())
                        } else entry
                    } else entry
                } catch (e: Exception) { entry }
            } else entry
        }
        // HISTORY BACKEND FIX: mark the read healthy BEFORE attempting the
        // migration save.
        //
        // saveHistoryToPrefs() -> guardSaveHistory() bails out when
        // historyReadHealthy is false. Because the flag used to be set on the
        // line AFTER this block, the cover migration write was silently
        // rejected on every launch, logging "SAVE BLOCKED: history was never
        // read successfully this session." The Base64 covers were therefore
        // re-migrated from scratch every single time the app started.
        historyReadHealthy = true
        if (migrated) {
            saveHistoryToPrefs(context, migratedEntries)
        }
        cachedHistory = migratedEntries
        writeHistorySnapshot(context, migratedEntries)
        return migratedEntries
    }

    private val HISTORY_JSON_REFRESH_MS = 60_000L

    /**
     * FIX #24 / #25: writes ONE row instead of rewriting the entire table.
     *
     * This is called on every activeNovel emission. The old version loaded the
     * whole history, re-serialized the complete novel (including all chapter
     * URLs), upserted up to 1000 rows and rewrote a JSON snapshot file - every
     * single time. Now it upserts a single row, reuses the previously stored
     * novelJson if it is less than a minute old, and trims with one SQL
     * statement.
     *
     * novelJson is still stored COMPLETE (chapters and chapterUrls included),
     * because NovelRemovalManager relies on it to reopen novels that have been
     * removed from the library.
     */
    fun addHistoryEntry(context: Context, novel: com.lorelight.data.model.Novel) {
        if (novel.id.isEmpty()) return
        val appContext = context.applicationContext
        DbWriter.submit("addHistoryEntry(${novel.id})") {
            run {
                try {
                    val dao = LorelightDatabase.get(appContext).historyDao()
                    val existing = dao.getById(novel.id)
                    val now = System.currentTimeMillis()

                    // Reuse the stored blob unless it is stale. lastModified
                    // tracks when the JSON was last rebuilt, which is separate
                    // from timestamp (when the novel was last read).
                    val reuseJson = existing != null &&
                        existing.novelJson.isNotEmpty() &&
                        (now - existing.lastModified) < HISTORY_JSON_REFRESH_MS

                    val json: String
                    val jsonStamp: Long
                    if (reuseJson) {
                        json = existing!!.novelJson
                        jsonStamp = existing.lastModified
                    } else {
                        val slimNovel = if (CoverStorage.isBase64Payload(novel.coverImageBase64)) {
                            val path = CoverStorage.migrateBase64ToFile(
                                appContext, novel.id, novel.coverImageBase64!!
                            )
                            novel.copy(coverImageBase64 = path ?: "")
                        } else novel
                        json = slimNovel.toJSONObject().toString()
                        jsonStamp = now
                    }

                    dao.upsertOne(
                        com.lorelight.data.db.HistoryEntity(
                            novelId = novel.id,
                            novelTitle = novel.title,
                            chapterId = novel.currentChapter,
                            chapterTitle = novel.currentChapter,
                            // RESUME REDESIGN. chapterId and chapterTitle are
                            // both the same NAME, which told the player nothing
                            // it could act on. Record the real index too.
                            chapterIndex = novel.currentChapterIndex,
                            timestamp = now,
                            lastModified = jsonStamp,
                            novelJson = json
                        )
                    )

                    val maxEntries = try {
                        prefs(appContext).getInt("history_max_entries", 1000)
                    } catch (e: Exception) { 1000 }
                    if (maxEntries > 0) dao.trimToLimit(maxEntries)

                    // Invalidate the in-memory cache so the next read reflects
                    // this write. Do NOT rebuild it here - that would undo the
                    // point of this fix.
                    cachedHistory = null

                    // The rescue snapshot is now refreshed on the same throttled
                    // cadence as the JSON rebuild, instead of on every tick.
                    if (!reuseJson) {
                        try {
                            writeHistorySnapshot(
                                appContext,
                                dao.getAll().map { it.toHistoryEntry() }
                            )
                        } catch (e: Exception) { e.printStackTrace() }
                    }
                } catch (e: Exception) { e.printStackTrace() }
            }
        }
    }

    fun removeHistoryEntry(context: Context, novelId: String) {
        try {
            val appContext = context.applicationContext
            val current = loadHistoryFromPrefs(appContext).toMutableList()
            current.removeAll { it.novelId == novelId }
            cachedHistory = current
            DbWriter.submit("removeHistoryEntry($novelId)") {
                try {
                    LorelightDatabase.get(appContext).historyDao().deleteByIds(listOf(novelId))
                } catch (e: Exception) { e.printStackTrace() }
                writeHistorySnapshot(appContext, current, allowEmpty = true)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun clearAllHistory(context: Context) {
        try {
            val appContext = context.applicationContext
            cachedHistory = emptyList()
            DbWriter.submit("clearAllHistory") {
                try {
                    LorelightDatabase.get(appContext).historyDao().deleteAll()
                } catch (e: Exception) { e.printStackTrace() }
                writeHistorySnapshot(appContext, emptyList(), allowEmpty = true)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun removeBookmarksForNovel(context: Context, novelId: String) {
        try {
            val current = loadBookmarksFromPrefs(context).toMutableList()
            val filtered = current.filterNot { it.optString("novelId") == novelId }
            saveBookmarksToPrefs(context, filtered)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun clearLocalData(context: Context) {
        try {
            val uid = "guest"
            val settings = context.getSharedPreferences("lorelight_settings_$uid", Context.MODE_PRIVATE)
            val reader = context.getSharedPreferences("reader_prefs_$uid", Context.MODE_PRIVATE)
            settings.edit().clear().commit()
            reader.edit().clear().commit()
            LorelightDatabase.get(context).novelDao().deleteAll()
            LorelightDatabase.get(context).historyDao().deleteAll()
            cachedNovels = null
            cachedWebsites = null
            cachedHistory = null
            novelsReadHealthy = false
            historyReadHealthy = false
            try {
                val dir = rescueDir(context)
                java.io.File(dir, "novels_snapshot.json").delete()
                java.io.File(dir, "history_snapshot.json").delete()
            } catch (e: Exception) { e.printStackTrace() }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }



    // --- Bookmarks storage ---
    fun saveBookmarksToPrefs(context: Context, bookmarks: List<org.json.JSONObject>) {
        try {
            val sharedPrefs = prefs(context)
            val arr = JSONArray()
            bookmarks.forEach { arr.put(it) }
            sharedPrefs.edit().putString("saved_bookmarks", arr.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun loadBookmarksFromPrefs(context: Context): List<org.json.JSONObject> {
        val list = mutableListOf<org.json.JSONObject>()
        try {
            val sharedPrefs = prefs(context)
            val jsonStr = sharedPrefs.getString("saved_bookmarks", null)
            if (!jsonStr.isNullOrEmpty()) {
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    list.add(arr.getJSONObject(i))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    // --- Highlights storage ---
    fun saveHighlightsToPrefs(context: Context, highlights: List<com.lorelight.data.model.Highlight>) {
        try {
            val sharedPrefs = prefs(context)
            val arr = JSONArray()
            highlights.forEach { h ->
                val obj = org.json.JSONObject()
                obj.put("id", h.id)
                obj.put("novelId", h.novelId)
                obj.put("chapterTitle", h.chapterTitle)
                obj.put("startWordIdx", h.startWordIdx)
                obj.put("endWordIdx", h.endWordIdx)
                obj.put("colorHex", h.colorHex)
                obj.put("createdTimestamp", h.createdTimestamp)
                arr.put(obj)
            }
            sharedPrefs.edit().putString("saved_highlights", arr.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun loadHighlightsFromPrefs(context: Context): List<com.lorelight.data.model.Highlight> {
        val list = mutableListOf<com.lorelight.data.model.Highlight>()
        try {
            val sharedPrefs = prefs(context)
            val jsonStr = sharedPrefs.getString("saved_highlights", null)
            if (!jsonStr.isNullOrEmpty()) {
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    list.add(
                        com.lorelight.data.model.Highlight(
                            id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                            novelId = obj.optString("novelId", ""),
                            chapterTitle = obj.optString("chapterTitle", ""),
                            startWordIdx = obj.optInt("startWordIdx", 0),
                            endWordIdx = obj.optInt("endWordIdx", 0),
                            colorHex = obj.optString("colorHex", "#FFFF00"),
                            createdTimestamp = obj.optLong("createdTimestamp", System.currentTimeMillis())
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    // --- Categories storage ---
    fun saveCategoriesToPrefs(context: Context, categories: List<org.json.JSONObject>) {
        try {
            val sharedPrefs = prefs(context)
            val arr = JSONArray()
            categories.forEach { arr.put(it) }
            sharedPrefs.edit().putString("saved_categories", arr.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun loadCategoriesFromPrefs(context: Context): List<org.json.JSONObject> {
        val list = mutableListOf<org.json.JSONObject>()
        try {
            val sharedPrefs = prefs(context)
            val jsonStr = sharedPrefs.getString("saved_categories", null)
            if (!jsonStr.isNullOrEmpty()) {
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    list.add(arr.getJSONObject(i))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    // --- Collections storage ---
    fun saveCollectionsToPrefs(context: Context, collections: List<org.json.JSONObject>) {
        try {
            val sharedPrefs = prefs(context)
            val arr = JSONArray()
            collections.forEach { arr.put(it) }
            sharedPrefs.edit().putString("saved_collections", arr.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun loadCollectionsFromPrefs(context: Context): List<org.json.JSONObject> {
        val list = mutableListOf<org.json.JSONObject>()
        try {
            val sharedPrefs = prefs(context)
            val jsonStr = sharedPrefs.getString("saved_collections", null)
            if (!jsonStr.isNullOrEmpty()) {
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    list.add(arr.getJSONObject(i))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }



    // --- Website State storage ---
    fun saveWebsiteStatesToPrefs(context: Context, states: List<org.json.JSONObject>) {
        try {
            val sharedPrefs = prefs(context)
            val arr = JSONArray()
            states.forEach { arr.put(it) }
            sharedPrefs.edit().putString("saved_website_states", arr.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun loadWebsiteStatesFromPrefs(context: Context): List<org.json.JSONObject> {
        val list = mutableListOf<org.json.JSONObject>()
        try {
            val sharedPrefs = prefs(context)
            val jsonStr = sharedPrefs.getString("saved_website_states", null)
            if (!jsonStr.isNullOrEmpty()) {
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    list.add(arr.getJSONObject(i))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }


}
