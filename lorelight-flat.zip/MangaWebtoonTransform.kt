package com.lorelight.manga.reader

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Pan/zoom state for the webtoon (long-strip) viewer.
 *
 * Vertical scrolling stays owned by the underlying LazyColumn; this only holds
 * the extra pinch-zoom [scale] and pan [offset] that the container applies on
 * top via `graphicsLayer`. [scale] of 1f means "fit width" (no zoom).
 */
@Stable
class WebtoonTransformState {
    var scale by mutableStateOf(1f)
    var offset by mutableStateOf(Offset.Zero)

    fun reset() {
        scale = 1f
        offset = Offset.Zero
    }
}

@Composable
fun rememberWebtoonTransformState(): WebtoonTransformState =
    remember { WebtoonTransformState() }

/**
 * Pinch-to-zoom + double-tap-to-zoom for the webtoon viewer.
 *
 * - Two-finger gestures pinch-zoom (clamped to [minScale]..[maxZoom]) and pan
 *   via the gesture centroid; only multi-touch events are consumed, so a
 *   single-finger vertical drag still scrolls the LazyColumn untouched.
 * - Double-tap toggles between fit-width and [doubleTapScale]. A single tap is
 *   never consumed here, so the tap-zone layer keeps handling page turns.
 *
 * @param disableZoomOut when true, the minimum scale is clamped to fit-width
 *   (1f); otherwise the page can be shrunk below fit-width.
 * @param atFirstPosition / atLastPosition reserved for future edge-of-feed
 *   overscroll affordances; accepted now so the call site is stable.
 */
fun Modifier.webtoonGestures(
    transformState: WebtoonTransformState,
    containerSize: Size,
    disableZoomOut: Boolean,
    doubleTapToZoom: Boolean,
    maxZoom: Float,
    doubleTapScale: Float,
    atFirstPosition: Boolean,
    atLastPosition: Boolean,
): Modifier {
    val minScale = if (disableZoomOut) 1f else 0.5f

    fun clampOffset(raw: Offset, scale: Float): Offset {
        if (scale <= 1f) return Offset.Zero
        val maxX = (containerSize.width * (scale - 1f)) / 2f
        val maxY = (containerSize.height * (scale - 1f)) / 2f
        return Offset(
            x = raw.x.coerceIn(-maxX, maxX),
            y = raw.y.coerceIn(-maxY, maxY),
        )
    }

    return this
        .pointerInput(transformState, containerSize, minScale, maxZoom) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                do {
                    val event = awaitPointerEvent()
                    val pressedCount = event.changes.count { it.pressed }
                    if (pressedCount >= 2) {
                        val zoom = event.calculateZoom()
                        val pan = event.calculatePan()
                        if (zoom != 1f || pan != Offset.Zero) {
                            val newScale = (transformState.scale * zoom).coerceIn(minScale, maxZoom)
                            transformState.scale = newScale
                            transformState.offset = clampOffset(transformState.offset + pan, newScale)
                            event.changes.forEach { it.consume() }
                        }
                    }
                } while (event.changes.any { it.pressed })
            }
        }
        .pointerInput(transformState, doubleTapToZoom, doubleTapScale, maxZoom, minScale) {
            if (!doubleTapToZoom) return@pointerInput
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                waitForUpOrCancellation() ?: return@awaitEachGesture
                val secondDown = withTimeoutOrNull(viewConfiguration.doubleTapTimeoutMillis) {
                    awaitFirstDown(requireUnconsumed = false)
                } ?: return@awaitEachGesture
                val secondUp = waitForUpOrCancellation() ?: return@awaitEachGesture
                secondUp.consume()
                if (transformState.scale > 1f) {
                    transformState.reset()
                } else {
                    transformState.scale = doubleTapScale.coerceIn(1f, maxZoom)
                }
            }
        }
}
