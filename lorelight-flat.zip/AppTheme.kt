package eu.kanade.domain.ui.model

/**
 * App theme options for the Mihon-sourced reader-theme context.
 *
 * Lorelight drives its own visible theming through its ReaderViewModel, so only
 * a single default entry is needed here to satisfy [ThemingDelegate]. Additional
 * palette entries can be added later without affecting the app's own theming.
 */
enum class AppTheme {
    DEFAULT,
}
