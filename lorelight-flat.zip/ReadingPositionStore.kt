package com.lorelight.data.local

import android.content.Context
import com.lorelight.core.getSafeFloat
import com.lorelight.core.getSafeInt

/**
 * Per-novel + per-chapter reading position.
 *
 * v2: keys now include the chapter index, store a scroll fraction, and store a
 * layout signature so a stale pixel offset can be discarded when typography
 * changes. Old v1 keys (novel-only) are migrated on first read, never dropped.
 *
 * v3: every write is stamped. This store is not the only thing that remembers
 * where you were - the novel row carries a paragraph index too - and without a
 * timestamp there was no way to tell which of the two was written later. An
 * entry saved before v3 has no stamp and reports savedAt = 0L, which callers
 * must read as UNKNOWN, never as "very old".
 */
object ReadingPositionStore {
    private const val PREF_NAME = "reading_position"

    data class Position(
        val index: Int,
        val offset: Int,
        val fraction: Float,
        val layoutSig: Int,
        /** When this was written. 0L means it predates v3, i.e. unknown. */
        val savedAt: Long = 0L
    )

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)

    private fun kIdx(id: String, ch: Int) = "pos_idx_${id}_c$ch"
    private fun kOff(id: String, ch: Int) = "pos_off_${id}_c$ch"
    private fun kFrac(id: String, ch: Int) = "pos_frac_${id}_c$ch"
    private fun kSig(id: String, ch: Int) = "pos_sig_${id}_c$ch"
    private fun kAt(id: String, ch: Int) = "pos_at_${id}_c$ch"

    // v1 legacy keys (no chapter component)
    private fun legacyIdx(id: String) = "pos_idx_$id"
    private fun legacyOff(id: String) = "pos_off_$id"

    /** Stable hash of the typography settings that affect pixel offsets. */
    fun layoutSignature(fontSize: Float, lineSpacing: Float, paragraphSpacing: Float): Int {
        var h = fontSize.hashCode()
        h = 31 * h + lineSpacing.hashCode()
        h = 31 * h + paragraphSpacing.hashCode()
        return h
    }

    /**
     * FIX #6: uses apply() (async). NEVER use commit() here - the old code called
     * commit() from a scroll listener, doing a blocking fsync on the UI thread on
     * every single frame.
     */
    fun save(
        context: Context,
        novelId: String,
        chapterIndex: Int,
        index: Int,
        offset: Int,
        fraction: Float,
        layoutSig: Int
    ) {
        if (novelId.isBlank() || chapterIndex < 0) return
        prefs(context).edit()
            .putInt(kIdx(novelId, chapterIndex), index)
            .putInt(kOff(novelId, chapterIndex), offset)
            .putFloat(kFrac(novelId, chapterIndex), fraction)
            .putInt(kSig(novelId, chapterIndex), layoutSig)
            .putLong(kAt(novelId, chapterIndex), System.currentTimeMillis())
            .apply()
    }

    fun load(context: Context, novelId: String, chapterIndex: Int): Position? {
        if (novelId.isBlank() || chapterIndex < 0) return null
        val p = prefs(context)
        val key = kIdx(novelId, chapterIndex)
        if (p.contains(key)) {
            return Position(
                index = p.getSafeInt(key, 0),
                offset = p.getSafeInt(kOff(novelId, chapterIndex), 0),
                fraction = p.getSafeFloat(kFrac(novelId, chapterIndex), 0f),
                layoutSig = p.getSafeInt(kSig(novelId, chapterIndex), 0),
                // Defensive in the way getSafeInt is: a key written as another
                // type by an older build would throw ClassCastException here.
                savedAt = runCatching {
                    p.getLong(kAt(novelId, chapterIndex), 0L)
                }.getOrDefault(0L)
            )
        }
        // FIX #3 MIGRATION - DO NOT DELETE THIS BLOCK.
        // Adopt the old novel-only key for whichever chapter is opened first, then
        // remove it. Without this, every existing user loses their saved position
        // once on upgrade.
        val lIdx = legacyIdx(novelId)
        if (p.contains(lIdx)) {
            val idx = p.getSafeInt(lIdx, 0)
            val off = p.getSafeInt(legacyOff(novelId), 0)
            p.edit().remove(lIdx).remove(legacyOff(novelId)).apply()
            save(context, novelId, chapterIndex, idx, off, 0f, 0)
            // savedAt = 0L deliberately: save() above stamped the file with
            // now, but this VALUE is a v1 position of unknown age. Reporting
            // it as fresh would let it outrank a genuinely newer novel row.
            return Position(idx, off, 0f, 0, 0L)
        }
        return null
    }

    /** FIX #15: drop orphaned keys when a novel is removed from the library. */
    fun clearNovel(context: Context, novelId: String) {
        if (novelId.isBlank()) return
        val p = prefs(context)
        val ed = p.edit()
        p.all.keys.filter { it.contains(novelId) }.forEach { ed.remove(it) }
        ed.apply()
    }
}
