package com.lorelight.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast
import com.lorelight.data.local.AppPrefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * S7 - Handles inline notification action buttons on new-chapter notifications.
 *
 * Actions:
 *   ACTION_DOWNLOAD  Imports the new chapters directly into the library (the
 *                    same path the "Add to library" button on the review screen
 *                    takes) and dismisses the notification.
 *   ACTION_MUTE      Suppresses future update notifications for this title
 *                    (writes a per-novel mute flag via AppPrefs) and dismisses
 *                    the notification.  The user can unmute from Settings > Notifications.
 *
 * Both actions are fire-and-forget: the receiver exits after kicking off the
 * coroutine and the work runs on the IO dispatcher to avoid blocking the main
 * thread inside onReceive.
 */
class NotificationActionReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_DOWNLOAD = "com.lorelight.action.DOWNLOAD_NEW_CHAPTERS"
        const val ACTION_MUTE     = "com.lorelight.action.MUTE_NOVEL_UPDATES"

        /** Extra carrying the target novel ID (String). */
        const val EXTRA_NOVEL_ID = "novel_id"

        /** SharedPreferences key prefix for per-novel mute flags. */
        private const val PREF_MUTE_PREFIX = "notif_mute_"

        /** Returns true when the user has muted update notifications for [novelId]. */
        fun isMuted(context: Context, novelId: String): Boolean =
            AppPrefs.get(context).getBoolean("$PREF_MUTE_PREFIX$novelId", false)

        /** Persists the mute flag for [novelId]. Pass false to unmute. */
        fun setMuted(context: Context, novelId: String, muted: Boolean) {
            AppPrefs.get(context).edit()
                .putBoolean("$PREF_MUTE_PREFIX$novelId", muted)
                .apply()
        }
    }

    // Receiver-scoped coroutine scope — tied to a SupervisorJob so one
    // failing coroutine does not cancel sibling work.
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onReceive(context: Context, intent: Intent) {
        val novelId = intent.getStringExtra(EXTRA_NOVEL_ID) ?: return
        when (intent.action) {
            ACTION_DOWNLOAD -> handleDownload(context, novelId)
            ACTION_MUTE     -> handleMute(context, novelId)
        }
    }

    // ---- Download action ---------------------------------------------------

    private fun handleDownload(context: Context, novelId: String) {
        // goAsync() is NOT used here because the coroutine keeps the process
        // alive long enough without it (the scope is not cancelled on return).
        scope.launch {
            try {
                val imported = NewChaptersManager.importSelectedTitles(
                    context = context,
                    novelIdsToImport = setOf(novelId)
                )
                // NewChaptersManager.importSelectedTitles already cancels the
                // notification for this title, so nothing extra is needed here.
                if (imported > 0) {
                    showToast(context, "Downloaded $imported new chapter${if (imported == 1) "" else "s"}.")
                }
            } catch (e: Exception) {
                showToast(context, "Download failed: ${e.message}")
            }
        }
    }

    // ---- Mute action -------------------------------------------------------

    private fun handleMute(context: Context, novelId: String) {
        setMuted(context, novelId, muted = true)
        // Dismiss the notification immediately so the user gets visual feedback.
        NewChaptersNotifier.cancelNotification(context, novelId)
        showToast(context, "Update notifications muted. Unmute in Settings.")
    }

    // ---- Helpers -----------------------------------------------------------

    private fun showToast(context: Context, message: String) {
        // Toast must be shown on the main thread.
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            Toast.makeText(context.applicationContext, message, Toast.LENGTH_SHORT).show()
        }
    }
}
