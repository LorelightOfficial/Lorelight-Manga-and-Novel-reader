package com.lorelight.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ReadingProgressDao {
    @Query("SELECT * FROM reading_progress WHERE novelId = :novelId")
    fun get(novelId: String): ReadingProgressEntity?

    @Query("SELECT * FROM reading_progress")
    fun getAll(): List<ReadingProgressEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsert(progress: ReadingProgressEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsertAll(progress: List<ReadingProgressEntity>)

    @Query("DELETE FROM reading_progress WHERE novelId = :novelId")
    fun delete(novelId: String)
}
