package com.lorelight.ui.theme.modeswitch

import android.graphics.Bitmap
import android.view.View
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Stable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.lorelight.ui.theme.modeswitch.celestial.CelestialAltarArt
import com.lorelight.ui.theme.modeswitch.celestial.CelestialAltarWell
import com.lorelight.ui.theme.modeswitch.celestial.CelestialBodyView
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.abs
import kotlin.random.Random
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.animation.core.withInfiniteAnimationFrameNanos
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.center
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.util.lerp
import com.lorelight.ui.theme.modeswitch.celestial.CelestialExpression
import com.lorelight.ui.theme.modeswitch.celestial.rememberCelestialFaceState
import kotlinx.coroutines.launch
import kotlin.math.PI
import com.lorelight.ui.theme.modeswitch.celestial.CelestialFaceSnapshot
import com.lorelight.ui.theme.modeswitch.celestial.CelestialFaceState
import com.lorelight.ui.theme.modeswitch.celestial.drawCelestialBody
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback

/**
 * Day / night switch animations.
 *
 * Both animations work the same way underneath: right before the theme flips
 * we grab a bitmap of the window, flip the theme instantly behind it, then draw
 * that stale bitmap in a full-screen overlay and take it apart. So what you
 * watch is the OLD screen being lit up / swept away, and the new theme is
 * simply what is already sitting underneath.
 *
 * That also means neither needs AGSL, so they run on minSdk 24 rather than
 * Android 13+.
 */
enum class ModeSwitchAnimation(
    val id: String,
    val label: String,
    val blurb: String,
    val durationMs: Int
) {
    CELESTIAL_ARC(
        "celestial", "Celestial Arc",
        "The sun or moon rises from the toggle, arcs into the sky, and its light washes the new theme across the screen",
        1400
    ),
    SPLASH_WASH(
        "splash", "Splash Wash",
        "Water pours down the glass and washes the old theme away -- an accelerating sheet that breaks into fingers, rivulets that outrun it, and spray thrown off the impact",
        1600
    ),
    EMBER_BURN(
        "ember", "Ember Burn",
        "The old screen smolders away like paper from where you tapped, with tall licking flames on the seam and drifting sparks",
        2600
    ),
    GLASS_SHATTER(
        "shatter", "Glass Shatter",
        "Cracks spider out from your finger, then the old screen breaks into shards that tumble away",
        1300
    ),
    TERMINATOR(
        "terminator", "Terminator Sweep",
        "Lite: the curved day / night line crosses with an atmospheric rim - easiest on older devices",
        700
    );

    companion object {
        fun all(): List<ModeSwitchAnimation> = values().toList()

        fun fromId(id: String?): ModeSwitchAnimation? = values().firstOrNull { it.id == id }

        fun poolFromCsv(csv: String?): List<ModeSwitchAnimation> {
            val found = csv.orEmpty()
                .split(',')
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .mapNotNull { fromId(it) }
                .distinct()
            return if (found.isEmpty()) all() else found
        }

        fun poolToCsv(pool: Collection<ModeSwitchAnimation>): String =
            all().filter { pool.contains(it) }.joinToString(",") { it.id }
    }
}

/**
 * Every random value an animation needs, drawn ONCE when the run starts.
 *
 * This matters: the draw lambda re-runs on every frame, so rolling dice inside
 * it would make the stars jump around instead of twinkling in place.
 */
class ModeSwitchRun(seed: Long) {
    private val r = Random(seed)

    // x, y (biased to the upper sky), appear delay, size, twinkle phase
    val stars: List<FloatArray> = List(30) {
        floatArrayOf(
            r.nextFloat(),
            r.nextFloat() * r.nextFloat() * 0.72f,
            0.15f + r.nextFloat() * 0.45f,
            0.5f + r.nextFloat(),
            r.nextFloat() * 6.28f
        )
    }

    // -- Splash Wash --
    // per column: speed multiplier, start delay, wobble phase
    val streams: List<FloatArray> = List(22) {
        floatArrayOf(
            0.75f + r.nextFloat() * 0.5f,
            r.nextFloat(),
            r.nextFloat() * 6.28f
        )
    }

    // stray droplets: x fraction, delay, size, fall speed multiplier
    val drops: List<FloatArray> = List(26) {
        floatArrayOf(
            r.nextFloat(),
            r.nextFloat() * 0.5f,
            0.5f + r.nextFloat(),
            0.8f + r.nextFloat() * 0.7f
        )
    }

    // -- Ember Burn --
    // three noise harmonics shaping the burn front: frequency, amplitude, phase
    val burnWobble: List<FloatArray> = List(3) { k ->
        floatArrayOf(
            (2 + k * 2 + r.nextInt(2)).toFloat(),
            0.030f + r.nextFloat() * 0.045f,
            r.nextFloat() * 6.28f
        )
    }

    // sparks riding the burn front: angle, delay, speed, size, flicker phase
    val sparks: List<FloatArray> = List(34) {
        floatArrayOf(
            r.nextFloat() * 6.28f,
            0.05f + r.nextFloat() * 0.75f,
            0.5f + r.nextFloat(),
            0.6f + r.nextFloat(),
            r.nextFloat() * 6.28f
        )
    }

    // flame tongues licking along the burn front:
    // angle, sway phase, height multiplier, width multiplier, flicker speed
    val flames: List<FloatArray> = List(30) {
        floatArrayOf(
            r.nextFloat() * 6.28f,
            r.nextFloat() * 6.28f,
            0.55f + r.nextFloat() * 0.95f,
            0.60f + r.nextFloat() * 0.70f,
            0.70f + r.nextFloat() * 0.90f
        )
    }

    // -- Glass Shatter --
    // shared jittered vertex grid so neighbouring shards tile with no gaps.
    // (cols+1) x (rows+1) points, two floats each: jitter as a cell fraction.
    val shatterCols = 5
    val shatterRows = 8
    val shatterVerts: FloatArray = FloatArray((shatterCols + 1) * (shatterRows + 1) * 2) { i ->
        val pt = i / 2
        val col = pt % (shatterCols + 1)
        val row = pt / (shatterCols + 1)
        // pin the border vertices so the sheet still covers the whole screen
        if (col == 0 || col == shatterCols || row == 0 || row == shatterRows) 0f
        else (r.nextFloat() - 0.5f) * 0.6f
    }

    // per shard: delay jitter, fall speed, sideways drift, spin direction/speed
    val shards: List<FloatArray> = List(shatterCols * shatterRows) {
        floatArrayOf(
            r.nextFloat(),
            0.8f + r.nextFloat() * 0.6f,
            (r.nextFloat() - 0.5f) * 2f,
            (r.nextFloat() - 0.5f) * 2f
        )
    }

    // radial crack polylines: angle, length fraction, two kink offsets
    val cracks: List<FloatArray> = List(11) { i ->
        floatArrayOf(
            (i.toFloat() / 11f) * 6.28f + (r.nextFloat() - 0.5f) * 0.5f,
            0.55f + r.nextFloat() * 0.45f,
            (r.nextFloat() - 0.5f) * 0.30f,
            (r.nextFloat() - 0.5f) * 0.30f
        )
    }
}

private fun findWindow(view: View): android.view.Window? {
    // This view first, then its ancestors. The order matters: the DecorView at
    // the top of the tree is built with a DecorContext that wraps the
    // *application* context, so an Activity is never reachable through it.
    // Handing this function a root view therefore returned null, PixelCopy was
    // skipped entirely, and the software fallback below then threw on Coil's
    // hardware cover bitmaps -- which is why the switch animation only ever
    // appeared on screens that had no cover art on them.
    var v: View? = view
    while (v != null) {
        var ctx: android.content.Context? = v.context
        while (ctx is android.content.ContextWrapper) {
            if (ctx is android.app.Activity) return ctx.window
            ctx = ctx.baseContext
        }
        v = v.parent as? View
    }
    return null
}

/**
 * Grabs the current window into a bitmap, capped so it stays cheap.
 *
 * PixelCopy is used wherever it exists because the software path below cannot
 * read back hardware layers: Coil hands us HARDWARE bitmaps for covers on API
 * 26+, and Canvas.drawBitmap throws on those. Without this the animation would
 * silently degrade to an instant flip on any screen showing artwork - which is
 * to say, the Library, which is where the toggle lives.
 *
 * PixelCopy also scales the source rect straight into the destination bitmap,
 * so the downscale is free and there is no full-size intermediate allocation.
 */
suspend fun captureWindow(view: View, maxDim: Int = 1000): ImageBitmap? {
    // Geometry comes from the root so the whole window is captured, but the
    // window itself is resolved from the view we were handed, because that is
    // the one whose context really is the Activity.
    val root = view.rootView ?: view
    val w = root.width
    val h = root.height
    if (w <= 0 || h <= 0) return null
    val scale = min(1f, maxDim.toFloat() / max(w, h).toFloat())
    val bw = max(1, (w * scale).roundToInt())
    val bh = max(1, (h * scale).roundToInt())

    val window = findWindow(view)
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O && window != null) {
        val target = try {
            Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        } catch (_: Throwable) {
            null
        }
        if (target != null) {
            val loc = IntArray(2)
            root.getLocationInWindow(loc)
            val rect = android.graphics.Rect(loc[0], loc[1], loc[0] + w, loc[1] + h)
            val ok = suspendCancellableCoroutine<Boolean> { cont ->
                try {
                    android.view.PixelCopy.request(
                        window,
                        rect,
                        target,
                        { result ->
                            if (cont.isActive) {
                                cont.resume(result == android.view.PixelCopy.SUCCESS)
                            }
                        },
                        android.os.Handler(android.os.Looper.getMainLooper())
                    )
                } catch (_: Throwable) {
                    if (cont.isActive) cont.resume(false)
                }
            }
            if (ok) return target.asImageBitmap()
        }
    }

    // API 24-25, or PixelCopy refused. Software draw; may throw on hardware
    // bitmaps, in which case the caller flips the theme with no animation.
    return try {
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)
        canvas.scale(bw.toFloat() / w.toFloat(), bh.toFloat() / h.toFloat())
        root.draw(canvas)
        bmp.asImageBitmap()
    } catch (_: Throwable) {
        null
    }
}

/**
 * A flat stand-in for the screenshot, used when the window cannot be read back
 * at all. Eight pixels is plenty, since drawBase stretches it over the screen.
 */
private fun solidBitmap(color: Color): ImageBitmap? {
    if (color == Color.Unspecified) return null
    return try {
        val bmp = Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(
            android.graphics.Color.argb(
                (color.alpha * 255f).roundToInt(),
                (color.red * 255f).roundToInt(),
                (color.green * 255f).roundToInt(),
                (color.blue * 255f).roundToInt()
            )
        )
        bmp.asImageBitmap()
    } catch (_: Throwable) {
        null
    }
}

@Stable
/** How long the outgoing character slides (celestial) or fades (other effects). */
private const val DESCENT_MS = 280

/** How long the opposite character takes to appear in the bowl. */
private const val EMERGE_MS = 220

class ModeSwitchController {
    var capture by mutableStateOf<ImageBitmap?>(null)
        private set
    var animation by mutableStateOf<ModeSwitchAnimation?>(null)
        private set
    var run by mutableStateOf<ModeSwitchRun?>(null)
        private set
    var toLight by mutableStateOf(false)
        private set

    /** Where the toggle sits in root coordinates, so effects start at your finger. */
    var origin by mutableStateOf(Offset.Zero)

    val progress = Animatable(0f)

    /**
     * Departure opacity/slide progress: 0 = seated and visible, 1 = absent.
     * The legacy name is kept for call-site compatibility, not altar motion.
     */
    val descent = Animatable(0f)
    var slideOut by mutableStateOf(false)
        private set

    private var busy = false

    private var previous: ModeSwitchAnimation? = null

    val isRunning: Boolean
        get() = capture != null

    /** True from the first frame of the descent until the emergence settles. */
    val isBusy: Boolean
        get() = busy

    private fun pick(pool: List<ModeSwitchAnimation>): ModeSwitchAnimation {
        if (pool.isEmpty()) return ModeSwitchAnimation.CELESTIAL_ARC
        if (pool.size == 1) return pool[0]
        // never the same one twice in a row
        var choice = pool[Random.nextInt(pool.size)]
        var guard = 0
        while (choice == previous && guard < 8) {
            choice = pool[Random.nextInt(pool.size)]
            guard++
        }
        return choice
    }

    /**
     * Capture, flip, animate. [flip] is invoked the instant the overlay is in
     * place, so the theme change itself is never visible as a hard cut.
     */
    suspend fun play(
        view: View,
        pool: List<ModeSwitchAnimation>,
        targetLight: Boolean,
        flip: () -> Unit,
        fallbackColor: Color = Color.Unspecified
    ) {
        if (isRunning || busy) return
        busy = true
        try {
            val chosen = pick(pool)
            slideOut = chosen == ModeSwitchAnimation.CELESTIAL_ARC
            // Slide out only for Celestial Arc; fade out for every other effect.
            // Capture the empty bowl before flipping, so no duplicate body is
            // baked into the old-screen overlay.
            descent.animateTo(
                targetValue = 1f,
                animationSpec = tween(DESCENT_MS, easing = FastOutSlowInEasing)
            )
            // A screenshot is preferred but never required. If the window refuses
            // to give one up, animate over a flat sheet in the outgoing background
            // colour rather than hard-cutting the theme.
            val shot = captureWindow(view) ?: solidBitmap(fallbackColor)
            if (shot == null) {
                flip()
            } else {
                previous = chosen
                toLight = targetLight
                animation = chosen
                run = ModeSwitchRun(System.nanoTime())
                capture = shot
                progress.snapTo(0f)
                flip()
                try {
                    progress.animateTo(1f, tween(chosen.durationMs, easing = LinearEasing))
                } finally {
                    capture = null
                    animation = null
                    run = null
                }
            }
            // The replacement appears in its fixed seat; it never rises or hovers.
            slideOut = false
            descent.animateTo(
                targetValue = 0f,
                animationSpec = tween(EMERGE_MS, easing = FastOutSlowInEasing)
            )
        } finally {
            slideOut = false
            capture = null
            animation = null
            run = null
            // Ensure a cancelled transition never leaves the new character hidden.
            kotlinx.coroutines.withContext(kotlinx.coroutines.NonCancellable) { descent.snapTo(0f) }
            busy = false
        }
    }
}

private fun sstep(t: Float): Float {
    val x = t.coerceIn(0f, 1f)
    return x * x * (3f - 2f * x)
}

private fun mix(a: Float, b: Float, t: Float): Float = a + (b - a) * t

/**
 * Smooth symmetric pulse: 1f at [center], easing to 0f at [center] +- [width].
 * Symmetric on purpose -- descent() plays the same curve in both directions.
 */
private fun bump(t: Float, center: Float, width: Float): Float {
    val x = abs(t - center) / width
    if (x >= 1f) return 0f
    val a = 1f - x
    return a * a * (3f - 2f * a)
}

private fun DrawScope.drawBase(img: ImageBitmap, alpha: Float = 1f, dy: Float = 0f) {
    drawImage(
        image = img,
        srcOffset = IntOffset.Zero,
        srcSize = IntSize(img.width, img.height),
        dstOffset = IntOffset(0, dy.roundToInt()),
        dstSize = IntSize(size.width.roundToInt(), size.height.roundToInt()),
        alpha = alpha.coerceIn(0f, 1f)
    )
}

// ------------------------------------------------------------ CELESTIAL ARC
/**
 * The flagship. The actual 3D sun / moon sprite pops out of the toggle,
 * sails along a rising arc into the upper sky, and the light it casts is what
 * changes the theme: a circular light front expands from the body, the old
 * screen survives only OUTSIDE that front, and the seam glows like the
 * atmosphere at dawn / dusk. Going dark, stars twinkle in behind the front;
 * going light, soft rays wheel around the sun.
 */
private fun DrawScope.drawCelestialArc(
    img: ImageBitmap,
    p: Float,
    o: Offset,
    toLight: Boolean,
    run: ModeSwitchRun
) {
    val w = size.width
    val h = size.height
    val diag = hypot(w, h)
    val minD = min(w, h)

    // -- flight: quadratic arc from the toggle to DEAD CENTRE of the screen.
    // The control point sits well above the destination, so the body launches
    // hard, overshoots a little and then settles into the middle of the screen
    // instead of drifting off into a corner.
    val launchOrigin = o - Offset(0f, 64.dp.toPx() * 0.42f)
    val rise = sstep((p / 0.55f).coerceIn(0f, 1f))
    val apex = Offset(w * 0.5f, h * 0.5f)
    val ctrl = Offset(mix(launchOrigin.x, apex.x, 0.12f), apex.y - h * 0.30f)
    val inv = 1f - rise
    val pos = Offset(
        inv * inv * launchOrigin.x + 2f * inv * rise * ctrl.x + rise * rise * apex.x,
        inv * inv * launchOrigin.y + 2f * inv * rise * ctrl.y + rise * rise * apex.y
    )

    val popIn = 1f
    val fadeOut = 1f - sstep((p - 0.90f) / 0.10f)
    val bodyAlpha = (popIn * fadeOut).coerceIn(0f, 1f)
    // Centre stage, so it can afford to be properly big.
    val bodyR = mix(64.dp.toPx() * com.lorelight.ui.theme.modeswitch.celestial.CELESTIAL_BODY_RADIUS_FRACTION, minD * 0.18f, rise)

    // -- light front: the new theme exists only where the light has reached --
    val reveal = sstep(((p - 0.08f) / 0.84f).coerceIn(0f, 1f))
    val frontR = bodyR * 1.2f + reveal * diag * 1.30f

    if (reveal < 0.999f) {
        val lit = Path()
        lit.addOval(Rect(pos.x - frontR, pos.y - frontR, pos.x + frontR, pos.y + frontR))
        clipPath(lit, ClipOp.Difference) { drawBase(img) }
    }

    val warm = Color(0xFFFFC978)
    val cool = Color(0xFF8FA8FF)
    val rim = if (toLight) warm else cool

    // -- sky wash: dawn gold / dusk indigo breathes in and back out --
    val wash = sin(p * Math.PI.toFloat())
    if (wash > 0.02f) {
        val tint = if (toLight) Color(0xFFFFDFA8) else Color(0xFF17224A)
        val litClip = Path()
        litClip.addOval(Rect(pos.x - frontR, pos.y - frontR, pos.x + frontR, pos.y + frontR))
        clipPath(litClip) {
            drawRect(
                brush = Brush.verticalGradient(
                    0f to tint.copy(alpha = if (toLight) 0.26f else 0.34f),
                    0.7f to Color.Transparent
                ),
                alpha = wash
            )
        }
    }

    // -- atmospheric rim riding the seam of the light front --
    if (reveal > 0.001f && reveal < 0.99f) {
        val soft = 90.dp.toPx()
        val gradR = frontR + soft
        val inner = ((frontR - soft) / gradR).coerceIn(0f, 1f)
        val edge = (frontR / gradR).coerceIn(0f, 1f)
        drawCircle(
            brush = Brush.radialGradient(
                inner to Color.Transparent,
                edge to rim.copy(alpha = 0.55f),
                1f to Color.Transparent,
                center = pos,
                radius = gradR
            ),
            radius = gradR,
            center = pos,
            alpha = (1f - reveal * 0.55f)
        )
        drawCircle(
            color = Color.White,
            radius = frontR,
            center = pos,
            alpha = 0.35f * (1f - reveal),
            style = Stroke(width = 2.dp.toPx())
        )
    }

    // -- stars twinkle in behind the nightfall front --
    if (!toLight) {
        for (s in run.stars) {
            val appear = sstep((p - s[2]) / 0.28f)
            if (appear <= 0.01f) continue
            val sx = s[0] * w
            val sy = s[1] * h
            // only inside the region the night has already claimed
            if (hypot(sx - pos.x, sy - pos.y) > frontR * 0.92f) continue
            val twinkle = 0.55f + 0.45f * sin(p * 22f + s[4])
            drawCircle(
                color = Color(0xFFEAF0FF),
                radius = (0.9f + 1.3f * s[3]).dp.toPx(),
                center = Offset(sx, sy),
                alpha = (appear * twinkle * fadeOut).coerceIn(0f, 1f)
            )
        }
    }

    // -- glow + rays / halo around the body --
    if (bodyAlpha > 0.01f) {
        val glow = if (toLight) Color(0xFFFFD98C) else Color(0xFFB9C8FF)
        drawCircle(
            brush = Brush.radialGradient(
                0f to glow.copy(alpha = 0.55f),
                0.55f to glow.copy(alpha = 0.18f),
                1f to Color.Transparent,
                center = pos,
                radius = bodyR * 2.8f
            ),
            radius = bodyR * 2.8f,
            center = pos,
            alpha = bodyAlpha
        )

        if (toLight) {
            // soft sun rays, slowly wheeling
            val rayA = 0.20f * bodyAlpha * sstep((p - 0.15f) / 0.25f)
            if (rayA > 0.01f) {
                val spin = p * 40f
                for (k in 0 until 8) {
                    val a = Math.toRadians((spin + k * 45f).toDouble()).toFloat()
                    val r1 = bodyR * 1.35f
                    val r2 = bodyR * (2.1f + 0.35f * sin(p * 10f + k))
                    drawLine(
                        color = warm,
                        start = Offset(pos.x + cos(a) * r1, pos.y + sin(a) * r1),
                        end = Offset(pos.x + cos(a) * r2, pos.y + sin(a) * r2),
                        strokeWidth = 5.dp.toPx(),
                        cap = StrokeCap.Round,
                        alpha = rayA
                    )
                }
            }
        } else {
            // quiet moonlight halo pulse
            val pulse = 0.5f + 0.5f * sin(p * 7f)
            drawCircle(
                color = cool,
                radius = bodyR * (1.55f + 0.14f * pulse),
                center = pos,
                alpha = 0.22f * bodyAlpha,
                style = Stroke(width = 2.5.dp.toPx())
            )
        }

        // New launch performance: determination opens into joy, then a farewell.
        val determined = com.lorelight.ui.theme.modeswitch.celestial.celestialPose(CelestialExpression.DETERMINED)
        val excited = com.lorelight.ui.theme.modeswitch.celestial.celestialPose(CelestialExpression.EXCITED)
        val wink = com.lorelight.ui.theme.modeswitch.celestial.celestialPose(CelestialExpression.WINK)
        val flightFace = when {
            p < 0.24f -> com.lorelight.ui.theme.modeswitch.celestial.blendCelestial(
                com.lorelight.ui.theme.modeswitch.celestial.CelestialRest, determined, sstep(p / 0.24f))
            p < 0.80f -> com.lorelight.ui.theme.modeswitch.celestial.blendCelestial(determined, excited, sstep((p - 0.24f) / 0.56f))
            else -> com.lorelight.ui.theme.modeswitch.celestial.blendCelestial(excited, wink, sstep((p - 0.80f) / 0.20f))
        }
        val tilt = sin(p * PI.toFloat()) * (if (toLight) -5f else 5f)
        rotate(degrees = tilt, pivot = pos) {
            drawCelestialBody(
                center = pos,
                radius = bodyR,
                form = if (toLight) 1f else 0f,
                face = flightFace,
                timeSec = p * 1.6f,
                alpha = bodyAlpha
            )
        }
    }
}

// -------------------------------------------------------------- SPLASH WASH
/**
 * Water running down the glass -- the same pour in both directions.
 *
 * This used to be two different animations sharing one name. Going light, the
 * screenshot was sliced into 22 vertical columns that each slid downward like
 * strips of paper; going dark, a sheet of liquid ran down. The strip version
 * was the odd one out -- solid rectangles of UI dropping past each other never
 * read as water -- and it was also why the two directions felt so unequal.
 * Both now run the same pour, rebuilt from how water actually behaves on a
 * vertical pane:
 *
 *  - it accelerates, so distance grows with time squared rather than linearly,
 *  - surface tension breaks the sheet into fingers instead of a level line,
 *  - mass gathers into a bright bead along every leading edge,
 *  - thin rivulets outrun the sheet, each dragging a heavy droplet at its tip,
 *  - the film refracts, so the outgoing pixels smear downward through it,
 *  - impact throws spray that flies on a real ballistic arc,
 *  - and the glass dries clean before the last frame.
 */
private fun DrawScope.drawSplashWash(
    img: ImageBitmap,
    p: Float,
    toLight: Boolean,
    run: ModeSwitchRun
) {
    val w = size.width
    val h = size.height
    val n = run.streams.size

    // Water is almost colourless; it borrows its tone from what it reveals.
    val body = if (toLight) Color(0xFFBFE4F5) else Color(0xFF121A2E)
    val deep = if (toLight) Color(0xFF6FB8DF) else Color(0xFF05080F)
    val sheen = if (toLight) Color.White else Color(0xFFC3D6FF)

    // Every wet element fades out before the end so the new theme is left dry.
    val settle = 1f - sstep(((p - 0.86f) / 0.14f).coerceIn(0f, 1f))

    // ---- the leading edge -------------------------------------------------
    // Sampled continuously and blended between neighbouring streams, so the
    // edge is a smooth organic curve instead of 22 visible stair steps.
    fun frontAt(fx: Float): Float {
        val g = fx.coerceIn(0f, 1f) * (n - 1)
        val i0 = g.toInt().coerceIn(0, n - 1)
        val i1 = (i0 + 1).coerceAtMost(n - 1)
        val u = sstep(g - i0)
        val a = run.streams[i0]
        val b = run.streams[i1]
        val delay = mix(0.03f + 0.17f * a[1], 0.03f + 0.17f * b[1], u)
        val speed = mix(1.06f + 0.34f * a[0], 1.06f + 0.34f * b[0], u)
        val phase = mix(a[2], b[2], u)
        val local = ((p - delay) / 0.72f).coerceIn(0f, 1f)
        // a brief push from the pour, then gravity owns it
        val fall = 0.20f * local + 0.80f * local * local
        val wob = sin(p * 8.5f + phase) * h * 0.009f +
            sin(p * 21f + phase * 2.1f) * h * 0.004f
        return fall * h * speed + wob
    }

    val segs = 48
    val segW = w / segs

    // ---- reveal: the outgoing screen survives only below the water --------
    val poured = Path()
    poured.moveTo(-w, -h)
    poured.lineTo(-w, frontAt(0f))
    for (i in 0..segs) poured.lineTo(i * segW, frontAt(i.toFloat() / segs))
    poured.lineTo(w * 2f, frontAt(1f))
    poured.lineTo(w * 2f, -h)
    poured.close()
    clipPath(poured, ClipOp.Difference) { drawBase(img) }

    // ---- refraction: old pixels dragged down through the film -------------
    // A real film displaces whatever you see through it. Clipping the outgoing
    // screenshot to a band on the wet side of the edge and pushing it downward
    // is both the cheapest and the most convincing version of that.
    if (settle > 0.01f) {
        val bandH = h * 0.06f
        val lens = Path()
        lens.moveTo(0f, frontAt(0f))
        for (i in 0..segs) lens.lineTo(i * segW, frontAt(i.toFloat() / segs))
        for (i in segs downTo 0) lens.lineTo(i * segW, frontAt(i.toFloat() / segs) - bandH)
        lens.close()
        clipPath(lens) { drawBase(img, alpha = 0.34f * settle, dy = bandH * 0.55f) }
    }

    // ---- the sheet: a thin film above, dense right at the bead ------------
    for (i in 0 until segs) {
        val f = frontAt((i + 0.5f) / segs)
        if (f <= 1f) continue
        val film = (h * 0.085f).coerceAtMost(f)
        drawRect(
            brush = Brush.verticalGradient(
                0.00f to body.copy(alpha = 0f),
                0.50f to body.copy(alpha = 0.09f * settle),
                0.86f to body.copy(alpha = 0.28f * settle),
                1.00f to deep.copy(alpha = 0.52f * settle),
                startY = f - film,
                endY = f
            ),
            topLeft = Offset(i * segW, f - film),
            size = androidx.compose.ui.geometry.Size(segW + 1f, film)
        )
    }

    // ---- the bead: surface tension holding mass on the edge ---------------
    val edge = Path()
    for (i in 0..segs) {
        val x = i * segW
        val y = frontAt(i.toFloat() / segs)
        if (i == 0) edge.moveTo(x, y) else edge.lineTo(x, y)
    }
    drawPath(edge, deep, alpha = 0.42f * settle, style = Stroke(width = 13.dp.toPx(), cap = StrokeCap.Round))
    drawPath(edge, body, alpha = 0.52f * settle, style = Stroke(width = 5.5.dp.toPx(), cap = StrokeCap.Round))
    drawPath(edge, sheen, alpha = 0.72f * settle, style = Stroke(width = 1.6.dp.toPx()))

    // ---- rivulets outrunning the sheet, each with a heavy tip -------------
    for (i in run.streams.indices) {
        if (i % 2 == 1) continue
        val s = run.streams[i]
        val fx = (i + 0.5f) / n
        val base = frontAt(fx)
        if (base <= 1f) continue
        val lead = ((p - 0.05f - 0.18f * s[1]) / 0.80f).coerceIn(0f, 1f)
        val extra = lead * lead * h * 0.17f * (0.55f + 0.60f * s[0])
        if (extra < 3f) continue
        val tipY = base + extra
        if (tipY > h * 1.03f) continue
        val x = fx * w + sin(p * 6.5f + s[2]) * w * 0.007f
        val rw = (2.0f + 2.2f * s[0]).dp.toPx()
        drawLine(
            color = body,
            start = Offset(x, base),
            end = Offset(x, tipY),
            strokeWidth = rw,
            cap = StrokeCap.Round,
            alpha = 0.38f * settle
        )
        drawLine(
            color = sheen,
            start = Offset(x - rw * 0.18f, base),
            end = Offset(x - rw * 0.18f, tipY - rw),
            strokeWidth = rw * 0.30f,
            cap = StrokeCap.Round,
            alpha = 0.30f * settle
        )
        drawCircle(color = deep, radius = rw * 0.95f, center = Offset(x, tipY), alpha = 0.55f * settle)
        drawCircle(
            color = sheen,
            radius = rw * 0.30f,
            center = Offset(x - rw * 0.24f, tipY - rw * 0.30f),
            alpha = 0.55f * settle
        )
    }

    // ---- faint runnels left behind on the washed glass --------------------
    for (i in run.streams.indices) {
        val s = run.streams[i]
        val fx = (i + 0.5f) / n
        val f = frontAt(fx)
        if (f <= h * 0.04f) continue
        val x = fx * w
        drawLine(
            color = sheen,
            start = Offset(x + sin(s[2]) * segW * 0.35f, 0f),
            end = Offset(x, f - 3f),
            strokeWidth = (0.7f + 1.3f * s[0]).dp.toPx(),
            cap = StrokeCap.Round,
            alpha = 0.09f * settle
        )
    }

    // ---- droplets, motion-blurred by their own speed ---------------------
    for (d in run.drops) {
        val t = ((p - d[1] * 0.7f) / 0.55f).coerceIn(0f, 1f)
        if (t <= 0.02f || t >= 0.995f) continue
        val y = (0.16f * t + 0.84f * t * t) * h * 1.2f * d[3]
        if (y > h) continue
        val r = (1.0f + 2.0f * d[2]).dp.toPx()
        val streak = r * (2.5f + 7f * t)
        val x = d[0] * w
        drawLine(
            color = body,
            start = Offset(x, y - streak),
            end = Offset(x, y),
            strokeWidth = r * 1.05f,
            cap = StrokeCap.Round,
            alpha = 0.26f * (1f - t) * settle
        )
        drawCircle(color = deep, radius = r, center = Offset(x, y), alpha = 0.62f * (1f - t * 0.55f) * settle)
        drawCircle(
            color = sheen,
            radius = r * 0.33f,
            center = Offset(x - r * 0.25f, y - r * 0.30f),
            alpha = 0.58f * (1f - t) * settle
        )
    }

    // ---- impact: a spreading sheet at the top, then ballistic spray -------
    val hit = 1f - sstep(((p - 0.02f) / 0.22f).coerceIn(0f, 1f))
    if (hit > 0.01f) {
        drawRect(
            brush = Brush.verticalGradient(
                0.00f to sheen.copy(alpha = 0.40f * hit),
                0.30f to body.copy(alpha = 0.26f * hit),
                1.00f to Color.Transparent,
                startY = 0f,
                endY = h * 0.28f
            ),
            size = androidx.compose.ui.geometry.Size(w, h * 0.28f)
        )
    }
    for (k in run.sparks.indices) {
        val s = run.sparks[k]
        val st = (p - 0.015f - s[1] * 0.05f) / 0.34f
        if (st <= 0f || st >= 1f) continue
        val dir = if (k % 2 == 0) 1f else -1f
        // thrown outward and up, then pulled back down by gravity
        val x = w * 0.5f + dir * (0.22f + 0.58f * s[2]) * w * 0.62f * st
        val y = h * 0.015f - (0.32f + 0.48f * s[3]) * h * 0.34f * st + h * 1.05f * st * st
        if (y > h || x < -12f || x > w + 12f) continue
        val rr = (0.9f + 1.7f * s[3]).dp.toPx() * (1f - 0.35f * st)
        drawCircle(
            color = if (st < 0.5f) sheen else body,
            radius = rr,
            center = Offset(x, y),
            alpha = (0.66f * (1f - st)).coerceIn(0f, 1f)
        )
    }
}

// --------------------------------------------------------------- EMBER BURN
/**
 * The old screen is a sheet of paper catching fire from where you tapped. An
 * irregular smoldering front eats outward; along the seam sits a charred dark
 * band, then a deep-orange glow, then a thin white-hot line. Sparks lift off
 * the front, drift upward and gutter out. The new theme is what's revealed
 * where the paper has burned through.
 */
private fun DrawScope.drawEmberBurn(
    img: ImageBitmap,
    p: Float,
    toLight: Boolean,
    o: Offset,
    run: ModeSwitchRun
) {
    val w = size.width
    val h = size.height
    val diag = hypot(w, h)
    val minD = min(w, h)

    val reveal = sstep((p / 0.88f).coerceIn(0f, 1f))
    val baseR = reveal * diag * 1.18f + 4.dp.toPx()

    // radius per angle, warped by the run's noise harmonics so the front looks
    // like burning paper rather than a compass circle
    fun radiusAt(a: Float): Float {
        var m = 1f
        for (k in run.burnWobble) m += k[1] * sin(k[0] * a + k[2] + p * 2.4f)
        return baseR * m
    }

    val segs = 64
    val hole = Path()
    for (i in 0..segs) {
        val a = (i.toFloat() / segs) * 6.2831855f
        val r = radiusAt(a)
        val x = o.x + cos(a) * r
        val y = o.y + sin(a) * r
        if (i == 0) hole.moveTo(x, y) else hole.lineTo(x, y)
    }
    hole.close()

    if (reveal < 0.999f) {
        clipPath(hole, ClipOp.Difference) { drawBase(img) }
    }

    val charCol = Color(0xFF1A0E06)
    val glowCol = if (toLight) Color(0xFFFF9E3D) else Color(0xFFFF7A26)
    val hotCol = Color(0xFFFFE9B8)

    if (reveal > 0.002f && reveal < 0.99f) {
        val flicker = 0.85f + 0.15f * sin(p * 31f)
        // charred paper band just outside the seam
        drawPath(hole, charCol, alpha = 0.55f, style = Stroke(width = 22.dp.toPx()))
        // the ember glow breathing on the seam
        drawPath(hole, glowCol, alpha = 0.60f * flicker, style = Stroke(width = 16.dp.toPx()))
        // white-hot leading line
        drawPath(hole, hotCol, alpha = 0.88f * flicker, style = Stroke(width = 3.5.dp.toPx()))
        // heat haze bleeding inward from the seam
        val soft = 110.dp.toPx()
        val gradR = baseR + soft
        drawCircle(
            brush = Brush.radialGradient(
                ((baseR - soft) / gradR).coerceIn(0f, 1f) to Color.Transparent,
                (baseR / gradR).coerceIn(0f, 1f) to glowCol.copy(alpha = 0.40f),
                1f to Color.Transparent,
                center = o,
                radius = gradR
            ),
            radius = gradR,
            center = o,
            alpha = 1f - reveal * 0.6f
        )
    }

    // -- flame tongues licking off the burn front --
    // Fire rises, so every tongue leans upward regardless of which way the
    // front happens to face at that angle, and breathes on its own clock.
    if (reveal > 0.002f && reveal < 0.995f) {
        val flameH = minD * 0.155f
        for (f in run.flames) {
            val a = f[0]
            val rr = radiusAt(a)
            val bx = o.x + cos(a) * rr
            val by = o.y + sin(a) * rr
            if (bx < -flameH || bx > w + flameH || by < -flameH || by > h + flameH) continue
            val lick = 0.55f + 0.45f * sin(p * 15f * f[4] + f[1])
            val hgt = flameH * f[2] * lick
            val wid = flameH * 0.30f * f[3]
            // outward normal blended with "straight up" so the flame leans up
            var dx = cos(a) * 0.45f
            var dy = sin(a) * 0.45f - 0.90f
            val dl = hypot(dx, dy)
            dx /= dl
            dy /= dl
            val px = -dy * wid
            val py = dx * wid
            val sway = sin(p * 19f + f[1]) * wid * 0.85f
            val tipX = bx + dx * hgt + sway
            val tipY = by + dy * hgt
            val midX = bx + dx * hgt * 0.45f + sway * 0.35f
            val midY = by + dy * hgt * 0.45f
            val fade = 1f - reveal * 0.30f
            val tongue = Path()
            tongue.moveTo(bx + px, by + py)
            tongue.lineTo(midX + px * 0.60f, midY + py * 0.60f)
            tongue.lineTo(tipX, tipY)
            tongue.lineTo(midX - px * 0.60f, midY - py * 0.60f)
            tongue.lineTo(bx - px, by - py)
            tongue.close()
            drawPath(tongue, glowCol, alpha = (0.55f * lick * fade).coerceIn(0f, 1f))
            // white-hot core sitting in the base of the tongue
            val core = Path()
            core.moveTo(bx + px * 0.55f, by + py * 0.55f)
            core.lineTo(midX, midY)
            core.lineTo(bx - px * 0.55f, by - py * 0.55f)
            core.close()
            drawPath(core, hotCol, alpha = (0.50f * lick * fade).coerceIn(0f, 1f))
        }
    }

    // sparks lifting off the front, drifting up, guttering out
    for (s in run.sparks) {
        val t = ((p - s[1]) / 0.35f).coerceIn(0f, 1f)
        if (t <= 0.01f || t >= 0.99f) continue
        val born = radiusAt(s[0])
        val sx = o.x + cos(s[0]) * born + sin(s[4] + p * 9f) * 10.dp.toPx() * t
        val sy = o.y + sin(s[0]) * born - t * h * 0.17f * s[2]
        val flick = 0.5f + 0.5f * sin(p * 34f + s[4])
        drawCircle(
            color = if (t < 0.6f) hotCol else glowCol,
            radius = (1.3f + 2.6f * s[3]).dp.toPx() * (1f - t * 0.5f),
            center = Offset(sx, sy),
            alpha = ((1f - t) * flick).coerceIn(0f, 1f)
        )
    }
}

// ------------------------------------------------------------ GLASS SHATTER
/**
 * The old screen is a pane of glass. Cracks spider out from the tap point
 * first; then the pane lets go and every shard tumbles away under gravity with
 * its own spin and drift, nearest shards first. The shards share a jittered
 * vertex grid, so before they fall the pane still tiles the screen perfectly.
 */
private fun DrawScope.drawGlassShatter(
    img: ImageBitmap,
    p: Float,
    toLight: Boolean,
    o: Offset,
    run: ModeSwitchRun
) {
    val w = size.width
    val h = size.height
    val diag = hypot(w, h)
    val cols = run.shatterCols
    val rows = run.shatterRows
    val cellW = w / cols
    val cellH = h / rows

    fun vx(c: Int, r: Int): Float =
        c * cellW + run.shatterVerts[(r * (cols + 1) + c) * 2] * cellW
    fun vy(c: Int, r: Int): Float =
        r * cellH + run.shatterVerts[(r * (cols + 1) + c) * 2 + 1] * cellH

    val crackPhase = sstep((p / 0.20f).coerceIn(0f, 1f))
    val anyFalling = p > 0.16f

    if (!anyFalling) {
        // pane intact: full screenshot plus growing cracks
        drawBase(img)
    } else {
        // pane released: draw every shard on its own trajectory
        for (idx in run.shards.indices) {
            val c = idx % cols
            val r = idx / cols
            val s = run.shards[idx]
            val cx = (c + 0.5f) * cellW
            val cy = (r + 0.5f) * cellH
            val dist = hypot(cx - o.x, cy - o.y) / diag
            val delay = 0.16f + dist * 0.26f + s[0] * 0.10f
            val t = ((p - delay) / 0.52f).coerceIn(0f, 1f)
            if (t >= 1f) continue

            val fall = t * t * h * 1.35f * s[1]
            val drift = t * w * 0.10f * s[2]
            val spin = t * 55f * s[3]
            val alpha = (1f - sstep((t - 0.55f) / 0.45f)).coerceIn(0f, 1f)
            if (alpha <= 0.01f) continue

            val shard = Path()
            shard.moveTo(vx(c, r), vy(c, r))
            shard.lineTo(vx(c + 1, r), vy(c + 1, r))
            shard.lineTo(vx(c + 1, r + 1), vy(c + 1, r + 1))
            shard.lineTo(vx(c, r + 1), vy(c, r + 1))
            shard.close()

            withTransform({
                translate(left = drift, top = fall)
                rotate(degrees = spin, pivot = Offset(cx, cy))
            }) {
                clipPath(shard) {
                    drawBase(img, alpha = alpha)
                    // glass edge catching the light as the shard turns
                    drawPath(
                        shard,
                        color = if (toLight) Color.White else Color(0xFFB9C8FF),
                        alpha = 0.18f * alpha * (0.5f + 0.5f * sin(spin * 0.2f + idx.toFloat())),
                        style = Stroke(width = 1.5.dp.toPx())
                    )
                }
            }
        }
    }

    // radiating cracks while the pane is still holding on
    if (crackPhase > 0.01f && p < 0.30f) {
        val fade = 1f - sstep((p - 0.20f) / 0.10f)
        val crackCol = if (toLight) Color.White else Color(0xFFDDE6FF)
        for (ck in run.cracks) {
            val reach = crackPhase * diag * 0.6f * ck[1]
            val a = ck[0]
            val m1 = Offset(
                o.x + cos(a + ck[2]) * reach * 0.45f,
                o.y + sin(a + ck[2]) * reach * 0.45f
            )
            val m2 = Offset(
                o.x + cos(a + ck[3]) * reach * 0.78f,
                o.y + sin(a + ck[3]) * reach * 0.78f
            )
            val end = Offset(o.x + cos(a) * reach, o.y + sin(a) * reach)
            val crack = Path()
            crack.moveTo(o.x, o.y)
            crack.lineTo(m1.x, m1.y)
            crack.lineTo(m2.x, m2.y)
            crack.lineTo(end.x, end.y)
            drawPath(crack, crackCol, alpha = 0.65f * fade, style = Stroke(width = 1.8.dp.toPx()))
            drawPath(crack, Color.Black, alpha = 0.25f * fade, style = Stroke(width = 3.5.dp.toPx()))
        }
        // stress ring around the impact point
        drawCircle(
            color = crackCol,
            radius = crackPhase * diag * 0.10f,
            center = o,
            alpha = 0.35f * fade,
            style = Stroke(width = 1.5.dp.toPx())
        )
    }
}

// --------------------------------------------------------------- TERMINATOR
private fun DrawScope.drawTerminator(img: ImageBitmap, p: Float, toLight: Boolean) {
    val w = size.width
    val h = size.height
    val e = sstep(p)
    val bulge = w * 0.14f
    val base = mix(-w * 0.32f, w * 1.36f, e)
    val steps = 28

    val cleared = Path()
    cleared.moveTo(-w, -h)
    cleared.lineTo(base, -h)
    var i = 0
    while (i <= steps) {
        val t = i.toFloat() / steps
        cleared.lineTo(base + bulge * sin(t * Math.PI.toFloat()), t * h)
        i++
    }
    cleared.lineTo(base, h * 2f)
    cleared.lineTo(-w, h * 2f)
    cleared.close()
    clipPath(cleared, ClipOp.Difference) { drawBase(img) }

    val seam = Path()
    seam.moveTo(base, -h * 0.06f)
    i = 0
    while (i <= steps) {
        val t = i.toFloat() / steps
        seam.lineTo(base + bulge * sin(t * Math.PI.toFloat()), t * h)
        i++
    }
    seam.lineTo(base, h * 1.06f)

    val warm = if (toLight) Color(0xFFFFC978) else Color(0xFFFF9A4D)
    val cool = if (toLight) Color(0xFFA8ECFF) else Color(0xFF6E8DE0)
    drawPath(seam, warm, alpha = 0.10f, style = Stroke(width = 120.dp.toPx()))
    drawPath(seam, warm, alpha = 0.20f, style = Stroke(width = 44.dp.toPx()))
    drawPath(seam, cool, alpha = 0.55f, style = Stroke(width = 7.dp.toPx()))
    drawPath(seam, Color.White, alpha = 0.72f, style = Stroke(width = 2.dp.toPx()))
}

/** Full-screen overlay. Renders nothing at all when no switch is in flight. */
@Composable
fun ModeSwitchOverlay(controller: ModeSwitchController) {
    val img = controller.capture ?: return
    val anim = controller.animation ?: return
    val run = controller.run ?: return
    val toLight = controller.toLight

    // The full-screen theme switch is the single largest piece of motion in
    // the app: a whole-window capture that gets washed, burned or shattered.
    // Reduced motion and battery saver skip the choreography entirely - the
    // palette still changes, it just changes immediately.
    if (!com.lorelight.ui.theme.LocalMotionLevel.current.allowsThemeSwitchAnimation) return

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        val p = controller.progress.value
        val o = if (controller.origin == Offset.Zero) {
            Offset(size.width * 0.5f, size.height * 0.86f)
        } else {
            controller.origin
        }
        when (anim) {
            ModeSwitchAnimation.CELESTIAL_ARC ->
                drawCelestialArc(img, p, o, toLight, run)
            ModeSwitchAnimation.SPLASH_WASH -> drawSplashWash(img, p, toLight, run)
            ModeSwitchAnimation.EMBER_BURN -> drawEmberBurn(img, p, toLight, o, run)
            ModeSwitchAnimation.GLASS_SHATTER -> drawGlassShatter(img, p, toLight, o, run)
            ModeSwitchAnimation.TERMINATOR -> drawTerminator(img, p, toLight)
        }
    }
}

private val SunGlow = Color(0xFFFFB753)
private val MoonGlow = Color(0xFF8FB6E8)
private val SunRimLight = Color(0xFFF3E2B8)
private val MoonRimLight = Color(0xFFAEC6E4)

private const val BODY_RADIUS_FRACTION = com.lorelight.ui.theme.modeswitch.celestial.CELESTIAL_BODY_RADIUS_FRACTION
private val TWO_PI = (2.0 * PI).toFloat()

/** The character is seated at a fixed centre. Only the chosen celestial flight
 * can slide it out; idle expressions never translate or hover the character. */
@Composable
@OptIn(ExperimentalFoundationApi::class)
@Suppress("UNUSED_PARAMETER")
fun CelestialModeToggle(
    isLight: Boolean,
    modifier: Modifier = Modifier,
    glyphSize: Dp = 64.dp,
    riseAbove: Dp = 0.dp,
    enabled: Boolean = true,
    hidden: Boolean = false,
    descent: () -> Float = { 0f },
    faceOverride: CelestialFaceState? = null,
    propOverlay: (@Composable () -> Unit)? = null,
    onPositioned: (Offset) -> Unit,
    onToggle: () -> Unit,
    onLongPress: (() -> Unit)? = null,
    slideOut: Boolean = false
) {
    val interaction = remember { MutableInteractionSource() }
    val haptics = LocalHapticFeedback.current
    val ownFace = rememberCelestialFaceState(autoIdle = faceOverride == null)
    val face = faceOverride ?: ownFace
    val press = remember { Animatable(1f) }
    val allowPressAnimation = com.lorelight.ui.theme.LocalMotionLevel.current.animatesTransitions
    LaunchedEffect(interaction, allowPressAnimation) {
        interaction.interactions.collect { event ->
            when (event) {
                is PressInteraction.Press -> press.animateTo(if (allowPressAnimation) 0.97f else 1f, tween(75))
                is PressInteraction.Release, is PressInteraction.Cancel -> press.animateTo(1f, tween(140))
            }
        }
    }
    Box(
        modifier = modifier.size(glyphSize)
            .onGloballyPositioned { onPositioned(it.boundsInRoot().center) }
            .combinedClickable(
                interactionSource = interaction, indication = null,
                enabled = enabled && !hidden && descent() < 0.001f,
                role = androidx.compose.ui.semantics.Role.Button,
                onLongClick = onLongPress?.let { action -> { haptics.performHapticFeedback(HapticFeedbackType.LongPress); action() } },
                onClick = onToggle
            )
            .semantics { contentDescription = if (isLight) "Switch to dark theme" else "Switch to light theme" },
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.fillMaxSize().graphicsLayer {
            val d = descent().coerceIn(0f, 1f)
            // Flight only: slide up out of the bowl, then hand off to the overlay.
            // Other effects and the incoming character use alpha ONLY.
            translationY = if (slideOut) -glyphSize.toPx() * 0.42f * sstep(d) else 0f
            scaleX = press.value
            scaleY = press.value
            alpha = if (hidden) 0f else if (slideOut) 1f - sstep((d - 0.82f) / 0.18f) else 1f - d
        }) {
            CelestialBodyView(
                form = if (isLight) 0f else 1f,
                modifier = Modifier.fillMaxSize(), face = face, hover = false
            )
            // Compatibility slot; the navigation no longer supplies old prop artwork.
            propOverlay?.invoke()
        }
    }
}

/**
 * The runic altar the sun and moon are set into, drawn by [CelestialAltarArt].
 * While the Celestial Arc is in flight the altar follows the flight's progress
 * one to one; when the arc deactivates it eases shut instead of snapping.
 */
@Composable
fun CelestialAltar(
    isLight: Boolean,
    modifier: Modifier = Modifier,
    arcActive: Boolean = false,
    arcProgress: () -> Float = { 0f },
    descent: () -> Float = { 0f },
    themeId: String = "forest"
) {
    val progress by rememberUpdatedState(arcProgress)
    val open = remember { Animatable(0f) }

    LaunchedEffect(arcActive) {
        if (arcActive) {
            // Follow the gesture 1:1 while active.
            while (true) {
                withFrameNanos { }
                open.snapTo(progress().coerceIn(0f, 1f))
            }
        } else if (open.value > 0f) {
            // Ease shut instead of snapping when the arc deactivates.
            open.animateTo(
                targetValue = 0f,
                animationSpec = tween(
                    durationMillis = 450,
                    easing = CubicBezierEasing(0.2f, 0f, 0f, 1f)
                )
            )
        }
    }

    // The altar opens for the descent on every animation, and additionally
    // tracks the flight one to one when the Celestial Arc is the one playing.
    CelestialAltarArt(
        isLight = isLight,
        modifier = modifier,
        openAmount = max(open.value, descent().coerceIn(0f, 1f)),
        themeId = themeId
    )
}

/**
 * The subtle ambient dent/glow inside the glass bar behind the altar, drawn
 * by [CelestialAltarWell].
 */
@Composable
fun CelestialPanelWell(
    isLight: Boolean,
    modifier: Modifier = Modifier
) {
    CelestialAltarWell(isLight = isLight, modifier = modifier)
}
