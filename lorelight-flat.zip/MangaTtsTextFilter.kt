package com.lorelight.manga.reader

import android.content.Context
import com.lorelight.utils.FilterRule
import com.lorelight.utils.TextFilter
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

/**
 * Read-aloud text filter for the manga reader.
 *
 * Uses its own private store, fully separate from the novel reader's
 * "reader_text_filters". Manga rules and novel rules never see each other, so
 * nothing changed in the manga reader can alter novel playback. Only the
 * matching logic is reused from TextFilter, and that is pure functions with no
 * state of their own.
 *
 * Nothing here touches the page image, the OCR disk cache, or the detected-text
 * overlay. It only shapes the string on its way to the voice, exactly like
 * MangaOcrAutocorrect.
 */
object MangaTtsTextFilter {
    private const val STORE = "manga_reader_text_filters"
    private const val KEY_RULES = "rules"

    /**
     * Links and bare site names. Kept deliberately narrow: real prose almost
     * never contains "word.knownSuffix", so this does not need to be clever to
     * be safe. Anything more aggressive risks eating dialogue.
     */
    private val WEB_ADDRESS = Regex(
        "(?:https?://\\S+" +
            "|www\\.\\S+" +
            "|\\b[A-Za-z0-9][A-Za-z0-9-]*\\." +
            "(?:com|net|org|co|io|me|info|biz|xyz|top|site|online|club|cc|tv|ru|in|us|to|ws|fun|live)" +
            "\\b(?:/\\S*)?)",
        RegexOption.IGNORE_CASE
    )

    // Parsed rules are cached against the raw stored string, so an edit made in
    // the settings panel is picked up with no cross-notification needed.
    @Volatile private var cachedJson: String? = null
    @Volatile private var cachedRules: List<FilterRule> = emptyList()

    fun loadRules(context: Context): List<FilterRule> {
        val json = prefs(context).getString(KEY_RULES, "") ?: ""
        val seen = cachedJson
        if (seen != null && seen == json) return cachedRules
        val parsed = parse(json)
        cachedJson = json
        cachedRules = parsed
        return parsed
    }

    fun saveRules(context: Context, rules: List<FilterRule>) {
        val arr = JSONArray()
        rules.forEach { rule ->
            val obj = JSONObject()
            obj.put("id", rule.id)
            obj.put("original", rule.original)
            obj.put("replacement", rule.replacement)
            obj.put("isVanish", rule.isVanish)
            obj.put("scope", rule.scope)
            obj.put("bookId", rule.bookId)
            obj.put("action", rule.action)
            obj.put("strictMatch", rule.strictMatch)
            arr.put(obj)
        }
        val json = arr.toString()
        prefs(context).edit().putString(KEY_RULES, json).apply()
        cachedJson = json
        cachedRules = rules
    }

    /**
     * Adds a skip rule. strictMatch defaults to true because the whole point
     * here is OCR text: TextFilter's squash step is what lets a rule for
     * "freewebnovel" still catch "F.r_e-e W e b N0vel".
     */
    fun addRule(context: Context, phrase: String, strictMatch: Boolean = true): List<FilterRule> {
        val clean = phrase.trim()
        val existing = loadRules(context)
        if (clean.isEmpty()) return existing
        if (existing.any { it.original.trim().equals(clean, ignoreCase = true) }) return existing
        val updated = existing + FilterRule(
            id = UUID.randomUUID().toString(),
            original = clean,
            replacement = "",
            isVanish = true,
            scope = "All Books",
            bookId = "",
            action = TextFilter.ACTION_ERASE_TEXT,
            strictMatch = strictMatch
        )
        saveRules(context, updated)
        return updated
    }

    fun deleteRule(context: Context, id: String): List<FilterRule> {
        val updated = loadRules(context).filterNot { it.id == id }
        saveRules(context, updated)
        return updated
    }

    /**
     * Returns [text] with everything the user asked to skip removed. A blank
     * result is a valid outcome and means "say nothing for this bubble"; the
     * caller already guards on isNotBlank().
     */
    fun apply(context: Context, text: String, mangaKey: String): String {
        if (text.isBlank()) return text
        if (!MangaReaderPrefs.getTtsFilterEnabled(context)) return text

        var out = text
        if (MangaReaderPrefs.getTtsFilterSkipWebAddresses(context)) {
            out = WEB_ADDRESS.replace(out, " ")
        }

        val rules = loadRules(context)
        if (rules.isNotEmpty()) {
            val lines = out.split('\n')
            val erase = TextFilter.linesToErase(lines, rules, mangaKey)
            if (erase.isNotEmpty()) {
                out = lines.filterIndexed { idx, _ -> !erase.contains(idx) }.joinToString("\n")
            }
            out = TextFilter.applyRawStringRules(out, rules, mangaKey)
        }

        return tidy(out)
    }

    /** Closes up the gaps left by deletions so the voice does not pause oddly. */
    private fun tidy(text: String): String =
        text.replace(Regex("[ \\t]{2,}"), " ")
            .replace(Regex("\\s*\\n\\s*"), "\n")
            .trim()

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(STORE, Context.MODE_PRIVATE)

    private fun parse(json: String): List<FilterRule> {
        if (json.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            val list = ArrayList<FilterRule>(arr.length())
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val original = obj.optString("original", "")
                if (original.isBlank()) continue
                val isVanish = obj.optBoolean("isVanish", true)
                list.add(
                    FilterRule(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        original = original,
                        replacement = obj.optString("replacement", ""),
                        isVanish = isVanish,
                        scope = obj.optString("scope", "All Books"),
                        bookId = obj.optString("bookId", ""),
                        action = obj.optString(
                            "action",
                            if (isVanish) TextFilter.ACTION_ERASE_TEXT else TextFilter.ACTION_REPLACE
                        ),
                        strictMatch = obj.optBoolean("strictMatch", false)
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }
}
