package com.lorelight.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * O3 - Source failure recovery sheet.
 *
 * Raised in place of (or alongside) LorelightError when a source-tied operation
 * fails on the Details page, the reader, or Browse. Offers only the actions
 * that make sense for [kind]:
 *
 *   Retry              always shown
 *   Open in browser    when the source has a web URL (not OFFLINE)
 *   Clear session      CLOUDFLARE, BLOCKED, RATE_LIMITED
 *   Update extension   EXTENSION_OUTDATED, PARSE
 *   Find on another    PARSE, EXTENSION_OUTDATED, SOURCE_REMOVED, NOT_FOUND
 *   Copy details       always shown when [rawError] is non-null
 *
 * [sourceUrl] is the URL to open in the in-app browser (null = not available).
 * [pluginName] names the extension in user-visible messages.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SourceRecoverySheet(
    kind: FailureKind,
    pluginName: String,
    sourceUrl: String? = null,
    rawError: String? = null,
    sheetState: SheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    onDismiss: () -> Unit,
    onRetry: () -> Unit,
    onOpenInBrowser: ((url: String) -> Unit)? = null,
    onClearSession: (() -> Unit)? = null,
    onUpdateExtension: (() -> Unit)? = null,
    onFindOnAnotherSource: (() -> Unit)? = null
) {
    val clipboard = LocalClipboardManager.current

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Header
            Text(
                text = kind.recoveryTitle(pluginName),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                text = kind.recoveryBody(),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Spacer(Modifier.height(4.dp))

            // Retry — always first
            RecoveryAction(
                icon = Icons.Filled.Refresh,
                label = "Try again",
                onClick = { onRetry(); onDismiss() }
            )

            // Open in browser — when source URL available and not a pure offline failure
            if (sourceUrl != null && kind != FailureKind.OFFLINE) {
                RecoveryAction(
                    icon = Icons.Filled.Language,
                    label = "Open in browser",
                    sublabel = "Clears Cloudflare challenges",
                    onClick = { onOpenInBrowser?.invoke(sourceUrl); onDismiss() }
                )
            }

            // Clear session — for Cloudflare / blocked / rate-limited
            if (kind == FailureKind.CLOUDFLARE ||
                kind == FailureKind.BLOCKED ||
                kind == FailureKind.RATE_LIMITED
            ) {
                RecoveryAction(
                    icon = Icons.Filled.DeleteSweep,
                    label = "Clear source session",
                    sublabel = "Removes cached cookies for $pluginName",
                    onClick = { onClearSession?.invoke(); onDismiss() }
                )
            }

            // Update extension — when outdated or parse failure
            if (kind == FailureKind.EXTENSION_OUTDATED || kind == FailureKind.PARSE) {
                RecoveryAction(
                    icon = Icons.Filled.SystemUpdate,
                    label = "Update $pluginName",
                    sublabel = "Site layout may have changed",
                    onClick = { onUpdateExtension?.invoke(); onDismiss() }
                )
            }

            // Find on another source — when source is unreliable or gone
            if (kind == FailureKind.SOURCE_REMOVED ||
                kind == FailureKind.NOT_FOUND ||
                kind == FailureKind.PARSE ||
                kind == FailureKind.EXTENSION_OUTDATED
            ) {
                RecoveryAction(
                    icon = Icons.Filled.SwapHoriz,
                    label = "Find this title on another source",
                    sublabel = "Progress and bookmarks carry over",
                    onClick = { onFindOnAnotherSource?.invoke(); onDismiss() }
                )
            }

            // Copy details — debug aid, always last
            if (!rawError.isNullOrBlank()) {
                RecoveryAction(
                    icon = Icons.Filled.ContentCopy,
                    label = "Copy error details",
                    onClick = {
                        clipboard.setText(AnnotatedString(rawError))
                        onDismiss()
                    }
                )
            }
        }
    }
}

@Composable
private fun RecoveryAction(
    icon: ImageVector,
    label: String,
    sublabel: String? = null,
    onClick: () -> Unit
) {
    TextButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                modifier = Modifier.size(20.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
                if (sublabel != null) {
                    Text(
                        text = sublabel,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

// ─── FailureKind extensions for O3 ─────────────────────────────────────────

fun FailureKind.recoveryTitle(pluginName: String): String = when (this) {
    FailureKind.OFFLINE         -> "You're offline"
    FailureKind.TIMEOUT         -> "$pluginName took too long"
    FailureKind.CLOUDFLARE      -> "$pluginName needs a browser check"
    FailureKind.BLOCKED         -> "$pluginName blocked this request"
    FailureKind.RATE_LIMITED    -> "$pluginName is rate-limiting you"
    FailureKind.NOT_FOUND       -> "This entry has moved"
    FailureKind.PARSE           -> "$pluginName sent something unreadable"
    FailureKind.EXTENSION_OUTDATED -> "$pluginName extension is out of date"
    FailureKind.SOURCE_REMOVED  -> "$pluginName is no longer available"
    FailureKind.SERVER          -> "$pluginName is having problems"
    FailureKind.PERMISSION      -> "Permission needed"
    FailureKind.STORAGE         -> "Not enough space"
    FailureKind.UNKNOWN         -> "Something went wrong"
}

fun FailureKind.recoveryBody(): String = when (this) {
    FailureKind.OFFLINE         -> "Connect to the internet and try again. Downloaded chapters still open."
    FailureKind.TIMEOUT         -> "The site didn't respond in time — it's usually busy, not broken. Try again in a moment."
    FailureKind.CLOUDFLARE      -> "Opening the source in the browser once usually clears the check."
    FailureKind.BLOCKED         -> "The site rejected the request. Opening it in the browser or clearing the session cookie usually fixes this."
    FailureKind.RATE_LIMITED    -> "Too many requests in a short time. Wait a minute, clear your session, or try another source."
    FailureKind.NOT_FOUND       -> "This entry may have moved or been removed. Another source might still have it."
    FailureKind.PARSE           -> "The page layout changed, so the extension can't read it. An update usually fixes this."
    FailureKind.EXTENSION_OUTDATED -> "A newer version of the extension may already fix this. Update it and try again."
    FailureKind.SOURCE_REMOVED  -> "This source is no longer installed or has been shut down. Move this title to another source to keep reading."
    FailureKind.SERVER          -> "The site returned an error on its side — nothing you did caused this."
    FailureKind.PERMISSION      -> "Grant the permission Lorelight needs, then try again."
    FailureKind.STORAGE         -> "Free some storage space, then try again."
    FailureKind.UNKNOWN         -> "Nothing was lost — you can retry safely."
}
