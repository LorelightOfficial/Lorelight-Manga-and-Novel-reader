package com.lorelight.ui.theme.modeswitch.celestial

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.lerp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

// ---------------------------------------------------------------------------
// Design 2 — CHIBI  (UwU kawaii, default curved closed eyes)
// ---------------------------------------------------------------------------

internal fun DrawScope.drawChibi(
    c: Offset, radius: Float, form: Float,
    face: CelestialFaceSnapshot, alpha: Float
) {
    if (radius <= 0f || alpha <= 0f) return
    val r = radius
    val f = form.coerceIn(0f, 1f)
    val a = alpha.coerceIn(0f, 1f)
    fun pt(x: Float, y: Float) = Offset(c.x + r * x, c.y + r * y)

    // Body colours
    val bodyCore  = lerp(Color(0xFFF8F0FF), Color(0xFFFFF5C0), f)
    val bodyMid   = lerp(Color(0xFFD0C0F8), Color(0xFFFFDE6A), f)
    val bodyEdge  = lerp(Color(0xFF9080D8), Color(0xFFE8943A), f)
    val inkColor  = lerp(Color(0xFF2A2060), Color(0xFF5A2820), f)

    // Soft outer glow ring
    drawCircle(
        Brush.radialGradient(
            0f to bodyMid.copy(alpha = 0.26f * a),
            1f to Color.Transparent,
            center = c, radius = r * 1.45f
        ), r * 1.45f, c
    )

    // Main body sphere
    drawCircle(
        Brush.radialGradient(
            0f to bodyCore, 0.48f to bodyMid, 1f to bodyEdge,
            center = pt(-0.3f, -0.38f), radius = r * 1.6f
        ), r, c, alpha = a
    )

    // Clip everything inside the body circle
    val disc = Path().apply { addOval(Rect(c.x - r, c.y - r, c.x + r, c.y + r)) }
    clipPath(disc) {
        // Highlight sheen
        drawOval(
            bodyCore.copy(alpha = 0.55f * a),
            pt(-0.58f, -0.72f), Size(r * 0.80f, r * 0.34f)
        )
        // Moon craters (only moon form)
        if (f < 1f) {
            val craters = floatArrayOf(-0.38f, -0.50f, 0.12f, 0.28f, -0.58f, 0.08f, 0.58f, -0.22f, 0.07f)
            for (i in craters.indices step 3) {
                val cp = pt(craters[i], craters[i + 1]); val cr = craters[i + 2] * r
                drawCircle(Color(0xFF8070C8).copy(alpha = 0.28f * a * (1f - f)), cr, cp)
                drawCircle(bodyCore.copy(alpha = 0.60f * a * (1f - f)), cr * 0.72f, cp + Offset(cr * 0.12f, cr * 0.18f))
            }
        }
        // Sun inner sparkle dots (instead of rays)
        if (f > 0f) for (i in 0 until 12) {
            val t = i * 30f * PI.toFloat() / 180f
            val dist = 0.55f + (i % 3) * 0.08f
            drawCircle(
                Color(0xFFFFC840).copy(alpha = (0.22f + (i % 2) * 0.12f) * a * f),
                r * (0.035f + (i % 2) * 0.018f),
                pt(cos(t) * dist, sin(t) * dist)
            )
        }
        // Terminator shadow
        drawCircle(
            Brush.radialGradient(
                0.38f to Color.Transparent, 1f to inkColor.copy(alpha = 0.20f * a),
                center = pt(-0.32f, -0.42f), radius = r * 1.75f
            ), r, c
        )
    }
    drawCircle(inkColor.copy(alpha = 0.18f * a), r, c, style = Stroke(r * 0.018f))

    // ---- Big rosy chibi cheeks ----
    val cheekCol = lerp(Color(0xFFCC88CC), Color(0xFFFF8888), f)
    val blush = (0.35f + face.cheekGlow.coerceIn(0f, 1f) * 0.50f) * a
    for (side in listOf(-1f, 1f)) {
        val cp = pt(side * 0.50f, 0.30f)
        drawOval(
            Brush.radialGradient(listOf(cheekCol.copy(alpha = blush), Color.Transparent), cp, r * 0.28f),
            cp - Offset(r * 0.28f, r * 0.14f), Size(r * 0.56f, r * 0.28f)
        )
    }

    // ---- Thin arched brows ----
    for (side in listOf(-1f, 1f)) {
        val bv = if (side < 0f) face.browLeft else face.browRight
        val bx = c.x + side * r * 0.34f
        val by = c.y - r * (0.40f + bv.coerceAtLeast(0f) * 0.10f)
        val curvature = if (bv < 0f) -bv * 0.08f else 0f
        val bp = Path().apply {
            moveTo(bx - side * r * 0.16f, by + r * curvature)
            quadraticBezierTo(bx, by - r * 0.042f, bx + side * r * 0.16f, by - r * 0.012f)
        }
        drawPath(bp, inkColor.copy(alpha = 0.70f * a), style = Stroke(r * 0.042f, cap = StrokeCap.Round))
    }

    // ---- Eyes: curved UwU arcs when nearly closed, small round anime eye when open ----
    chibiBothEyes(c, r, face, inkColor, form, a)

    // ---- Tiny button nose ----
    drawOval(bodyEdge.copy(alpha = 0.30f * a), pt(-0.04f, 0.18f), Size(r * 0.08f, r * 0.04f))

    // ---- Mouth ----
    val smile = face.mouthSmile.coerceIn(-1f, 1f)
    val opening = face.mouthOpen.coerceIn(0f, 1f)
    val my = c.y + r * 0.44f
    val mw = r * (0.11f + 0.08f * abs(smile))
    if (opening < 0.08f) {
        val mp = Path().apply {
            moveTo(c.x - mw, my - r * 0.02f * smile)
            quadraticBezierTo(c.x, my + r * 0.18f * smile, c.x + mw, my - r * 0.02f * smile)
        }
        drawPath(mp, inkColor.copy(alpha = a), style = Stroke(r * 0.040f, cap = StrokeCap.Round))
    } else {
        val mh = r * (0.06f + 0.24f * opening)
        val wide = mw * if (smile < 0.2f) 0.72f else 1.08f
        val mp = Path().apply {
            moveTo(c.x - wide, my); cubicTo(c.x - wide, my - mh * 0.5f, c.x + wide, my - mh * 0.5f, c.x + wide, my)
            cubicTo(c.x + wide, my + mh, c.x - wide, my + mh, c.x - wide, my); close()
        }
        drawPath(mp, inkColor.copy(alpha = a))
        clipPath(mp) {
            if (smile > 0.3f) drawOval(bodyCore.copy(alpha = 0.90f * a), Offset(c.x - wide, my - mh * 0.42f), Size(wide * 2f, mh * 0.30f))
            drawOval(Color(0xFFD08888).copy(alpha = 0.90f * a), Offset(c.x - wide * 0.6f, my + mh * 0.30f), Size(wide * 1.2f, mh * 0.50f))
        }
    }

    // tears
    if (face.tears > 0.01f) for (side in listOf(-1f, 1f)) {
        val tx = c.x + side * r * 0.52f; val ty = c.y + r * 0.14f
        val t2 = face.tears.coerceIn(0f, 1f)
        val tp = Path().apply {
            moveTo(tx, ty); cubicTo(tx - r * 0.08f, ty + r * 0.18f * t2, tx - r * 0.06f, ty + r * 0.40f * t2, tx, ty + r * 0.40f * t2)
            cubicTo(tx + r * 0.08f, ty + r * 0.40f * t2, tx + r * 0.08f, ty + r * 0.18f * t2, tx, ty); close()
        }
        drawPath(tp, Brush.verticalGradient(listOf(Color(0xFFCAE9FF), Color(0xFF6EADDB)), ty, ty + r * 0.46f), alpha = a * t2)
    }
}

private fun DrawScope.chibiBothEyes(c: Offset, r: Float, face: CelestialFaceSnapshot, ink: Color, form: Float, a: Float) {
    for (side in listOf(-1f, 1f)) {
        val lid = if (side < 0f) face.lidLeft else face.lidRight
        val ex = c.x + side * r * 0.36f
        val ey = c.y - r * 0.04f
        val ew = r * 0.22f; val eh = r * 0.26f
        val openness = (1f - lid).coerceIn(0f, 1f)
        if (openness < 0.14f) {
            // UwU arc (happy closed eye)
            val dir = if (face.mouthSmile > 0.4f) -1f else 1f
            val ep = Path().apply {
                moveTo(ex - ew, ey)
                quadraticBezierTo(ex, ey + dir * eh * 0.50f, ex + ew, ey)
            }
            drawPath(ep, ink.copy(alpha = a), style = Stroke(ew * 0.24f, cap = StrokeCap.Round))
        } else {
            val hh = eh * openness
            val shape = Path().apply {
                moveTo(ex - ew, ey)
                cubicTo(ex - ew * 0.85f, ey - hh * 1.20f, ex + ew * 0.82f, ey - hh * 1.20f, ex + ew, ey)
                cubicTo(ex + ew * 0.68f, ey + hh * 0.85f, ex - ew * 0.68f, ey + hh * 0.85f, ex - ew, ey); close()
            }
            drawPath(shape, Color(0xFFFFF8F4).copy(alpha = a))
            clipPath(shape) {
                val iris = Offset(ex + face.pupilX * ew * 0.22f, ey + face.pupilY * eh * 0.16f)
                val ir = ew * 0.70f * face.pupilScale.coerceIn(0.5f, 1.3f)
                val hue = lerp(Color(0xFF7888D8), Color(0xFFBF7030), form)
                drawOval(
                    Brush.verticalGradient(listOf(ink, hue, lerp(Color(0xFFC0D8F0), Color(0xFFFFD868), form)), iris.y - eh, iris.y + eh),
                    iris - Offset(ir, eh * 0.82f), Size(ir * 2f, eh * 1.62f), alpha = a
                )
                drawOval(ink.copy(alpha = a), iris - Offset(ir * 0.40f, eh * 0.56f), Size(ir * 0.80f, eh * 1.12f))
                drawPath(shape, Brush.verticalGradient(listOf(ink.copy(alpha = 0.40f * a), Color.Transparent), ey - hh, ey))
                drawCircle(Color.White.copy(alpha = 0.95f * a), ew * 0.23f, iris - Offset(ew * 0.20f, eh * 0.28f))
                drawCircle(Color.White.copy(alpha = 0.65f * a), ew * 0.10f, iris + Offset(ew * 0.22f, eh * 0.22f))
            }
            val upper = Path().apply {
                moveTo(ex - ew, ey)
                cubicTo(ex - ew * 0.85f, ey - hh * 1.20f, ex + ew * 0.82f, ey - hh * 1.20f, ex + ew, ey)
            }
            drawPath(upper, ink.copy(alpha = a), style = Stroke(ew * 0.20f, cap = StrokeCap.Round))
        }
    }
}

// ---------------------------------------------------------------------------
// Design 3 — MINIMAL  (clean geometry, dot eyes, single-stroke smile)
// ---------------------------------------------------------------------------

internal fun DrawScope.drawMinimal(
    c: Offset, radius: Float, form: Float,
    face: CelestialFaceSnapshot, alpha: Float
) {
    if (radius <= 0f || alpha <= 0f) return
    val r = radius; val f = form.coerceIn(0f, 1f); val a = alpha.coerceIn(0f, 1f)
    fun pt(x: Float, y: Float) = Offset(c.x + r * x, c.y + r * y)

    val bodyA = lerp(Color(0xFFEEF4FF), Color(0xFFFFF9E8), f)
    val bodyB = lerp(Color(0xFF9AB0CC), Color(0xFFE8B040), f)
    val ink   = lerp(Color(0xFF304060), Color(0xFF603820), f)

    // Three concentric ambient rings for depth
    for (i in 1..3) {
        drawCircle(
            bodyB.copy(alpha = 0.06f * (4 - i) * a),
            r * (1f + i * 0.16f), c
        )
    }

    // Body
    drawCircle(Brush.radialGradient(0f to bodyA, 0.6f to bodyA, 1f to bodyB, center = pt(-0.25f, -0.30f), radius = r * 1.5f), r, c, alpha = a)

    // Clip interior
    val disc = Path().apply { addOval(Rect(c.x - r, c.y - r, c.x + r, c.y + r)) }
    clipPath(disc) {
        drawOval(bodyA.copy(alpha = 0.70f * a), pt(-0.52f, -0.66f), Size(r * 0.68f, r * 0.28f))
        // Moon: simple arc craters
        if (f < 1f) {
            val cdata = floatArrayOf(-0.32f, -0.44f, 0.16f, 0.34f, -0.60f, 0.07f)
            for (i in cdata.indices step 3) {
                val cp = pt(cdata[i], cdata[i + 1]); val cr = cdata[i + 2] * r
                drawCircle(bodyB.copy(alpha = 0.22f * a * (1f - f)), cr, cp, style = Stroke(cr * 0.22f))
            }
        }
        drawCircle(Brush.radialGradient(0.3f to Color.Transparent, 1f to ink.copy(alpha = 0.18f * a), center = pt(-0.28f, -0.36f), radius = r * 1.7f), r, c)
    }
    drawCircle(ink.copy(alpha = 0.14f * a), r, c, style = Stroke(r * 0.015f))

    // Brows (thin, minimal)
    for (side in listOf(-1f, 1f)) {
        val bv = if (side < 0f) face.browLeft else face.browRight
        val bx = c.x + side * r * 0.35f; val by = c.y - r * (0.38f + bv.coerceAtLeast(0f) * 0.08f)
        drawLine(ink.copy(alpha = 0.65f * a), Offset(bx - side * r * 0.12f, by + r * 0.02f * bv), Offset(bx + side * r * 0.12f, by - r * 0.02f * bv), r * 0.038f, cap = StrokeCap.Round)
    }

    // Eyes: simple filled circles that squash/enlarge with lid
    for (side in listOf(-1f, 1f)) {
        val lid = if (side < 0f) face.lidLeft else face.lidRight
        val ex = c.x + side * r * 0.35f; val ey = c.y - r * 0.05f
        val openness = (1f - lid).coerceIn(0f, 1f)
        if (openness < 0.12f) {
            drawLine(ink.copy(alpha = a), Offset(ex - r * 0.14f, ey), Offset(ex + r * 0.14f, ey), r * 0.038f, cap = StrokeCap.Round)
        } else {
            val ew = r * 0.14f * (0.5f + 0.5f * openness)
            val eh = r * 0.17f * openness
            drawOval(ink.copy(alpha = a), Offset(ex - ew, ey - eh), Size(ew * 2f, eh * 2f))
            drawCircle(Color.White.copy(alpha = 0.85f * a), ew * 0.32f, Offset(ex - ew * 0.35f + face.pupilX * ew * 0.3f, ey - eh * 0.20f))
        }
    }

    // Blush (subtle)
    val blush = (0.10f + face.cheekGlow * 0.28f) * a
    val cc = lerp(Color(0xFFBB88BB), Color(0xFFEE8866), f)
    for (side in listOf(-1f, 1f)) {
        val cp = pt(side * 0.49f, 0.28f)
        drawOval(Brush.radialGradient(listOf(cc.copy(alpha = blush), Color.Transparent), cp, r * 0.20f), cp - Offset(r * 0.20f, r * 0.10f), Size(r * 0.40f, r * 0.20f))
    }

    // Mouth (single arc stroke)
    val smile = face.mouthSmile.coerceIn(-1f, 1f)
    val opening = face.mouthOpen.coerceIn(0f, 1f)
    val my = c.y + r * 0.44f; val mw = r * 0.12f
    if (opening < 0.08f) {
        val mp = Path().apply {
            moveTo(c.x - mw, my); quadraticBezierTo(c.x, my + r * 0.16f * smile, c.x + mw, my)
        }
        drawPath(mp, ink.copy(alpha = a), style = Stroke(r * 0.038f, cap = StrokeCap.Round))
    } else {
        val mh = r * (0.05f + 0.20f * opening)
        val wide = mw * 1.1f
        val mp = Path().apply {
            moveTo(c.x - wide, my); cubicTo(c.x - wide, my - mh * 0.5f, c.x + wide, my - mh * 0.5f, c.x + wide, my)
            cubicTo(c.x + wide, my + mh, c.x - wide, my + mh, c.x - wide, my); close()
        }
        drawPath(mp, ink.copy(alpha = a))
    }

    // Tears
    if (face.tears > 0.01f) for (side in listOf(-1f, 1f)) {
        val tx = c.x + side * r * 0.50f; val ty = c.y + r * 0.12f; val t2 = face.tears
        drawLine(Color(0xFF88C8E8).copy(alpha = 0.80f * a * t2), Offset(tx, ty), Offset(tx - r * 0.02f, ty + r * 0.36f * t2), r * 0.038f, cap = StrokeCap.Round)
    }
}

// ---------------------------------------------------------------------------
// Design 4 — GLOWY  (ethereal rings, star pupils, nebula palette)
// ---------------------------------------------------------------------------

internal fun DrawScope.drawGlowy(
    c: Offset, radius: Float, form: Float,
    face: CelestialFaceSnapshot, alpha: Float
) {
    if (radius <= 0f || alpha <= 0f) return
    val r = radius; val f = form.coerceIn(0f, 1f); val a = alpha.coerceIn(0f, 1f)
    fun pt(x: Float, y: Float) = Offset(c.x + r * x, c.y + r * y)

    // Nebula palette: moon = teal/violet, sun = amber/rose
    val coreA = lerp(Color(0xFFEEF8FF), Color(0xFFFFF8E0), f)
    val midA  = lerp(Color(0xFF80C8E8), Color(0xFFFFCE60), f)
    val outerA = lerp(Color(0xFF6040C0), Color(0xFFE06020), f)
    val ink   = lerp(Color(0xFF201840), Color(0xFF502010), f)
    val glow  = lerp(Color(0xFF40A0E0), Color(0xFFFFAA30), f)

    // 4 soft concentric glow rings
    for (i in 4 downTo 1) {
        val ringR = r * (1f + i * 0.22f)
        val ringA = 0.09f * (5 - i) * a
        drawCircle(Brush.radialGradient(0f to glow.copy(alpha = ringA), 1f to Color.Transparent, center = c, radius = ringR), ringR, c)
    }

    // Body
    drawCircle(
        Brush.radialGradient(0f to coreA, 0.45f to midA, 1f to outerA, center = pt(-0.28f, -0.35f), radius = r * 1.55f),
        r, c, alpha = a
    )

    val disc = Path().apply { addOval(Rect(c.x - r, c.y - r, c.x + r, c.y + r)) }
    clipPath(disc) {
        // Interior sparkle particles
        for (i in 0 until 20) {
            val t = i * 137.5f * PI.toFloat() / 180f
            val dist = 0.18f + (i % 5) * 0.12f
            val sz = r * (0.018f + (i % 3) * 0.012f)
            drawCircle(
                glow.copy(alpha = (0.25f + (i % 2) * 0.20f) * a),
                sz, pt(cos(t) * dist, sin(t) * dist)
            )
        }
        drawOval(coreA.copy(alpha = 0.72f * a), pt(-0.55f, -0.68f), Size(r * 0.72f, r * 0.30f))
        // Moon craters as glowing rings
        if (f < 1f) {
            val cd = floatArrayOf(-0.36f, -0.48f, 0.14f, 0.30f, -0.56f, 0.08f, 0.56f, -0.20f, 0.07f)
            for (i in cd.indices step 3) {
                val cp = pt(cd[i], cd[i + 1]); val cr = cd[i + 2] * r
                drawCircle(midA.copy(alpha = 0.35f * a * (1f - f)), cr, cp, style = Stroke(cr * 0.30f))
            }
        }
        drawCircle(Brush.radialGradient(0.35f to Color.Transparent, 1f to ink.copy(alpha = 0.22f * a), center = pt(-0.30f, -0.38f), radius = r * 1.72f), r, c)
    }
    drawCircle(glow.copy(alpha = 0.28f * a), r, c, style = Stroke(r * 0.022f))

    // Brows
    for (side in listOf(-1f, 1f)) {
        val bv = if (side < 0f) face.browLeft else face.browRight
        val bx = c.x + side * r * 0.36f; val by = c.y - r * (0.40f + bv.coerceAtLeast(0f) * 0.09f)
        val bp = Path().apply {
            moveTo(bx - side * r * 0.18f, by + r * 0.02f)
            quadraticBezierTo(bx, by - r * 0.055f, bx + side * r * 0.17f, by - r * 0.015f)
        }
        drawPath(bp, ink.copy(alpha = 0.72f * a), style = Stroke(r * 0.048f, cap = StrokeCap.Round))
    }

    // Eyes with glowing star-shaped pupils
    glowingEyes(c, r, face, ink, glow, midA, f, a)

    // Big rosy cheeks with glow
    val cheekC = lerp(Color(0xFFAA88DD), Color(0xFFFF9966), f)
    val blush = (0.22f + face.cheekGlow * 0.55f) * a
    for (side in listOf(-1f, 1f)) {
        val cp = pt(side * 0.51f, 0.30f)
        drawOval(Brush.radialGradient(listOf(cheekC.copy(alpha = blush), Color.Transparent), cp, r * 0.22f), cp - Offset(r * 0.22f, r * 0.11f), Size(r * 0.44f, r * 0.22f))
    }

    // Tiny nose glow
    drawOval(outerA.copy(alpha = 0.22f * a), pt(-0.04f, 0.18f), Size(r * 0.08f, r * 0.04f))

    // Mouth
    val smile = face.mouthSmile.coerceIn(-1f, 1f)
    val opening = face.mouthOpen.coerceIn(0f, 1f)
    val my = c.y + r * 0.44f; val mw = r * (0.12f + 0.09f * abs(smile))
    if (opening < 0.08f) {
        val mp = Path().apply { moveTo(c.x - mw, my - r * 0.025f * smile); quadraticBezierTo(c.x, my + r * 0.18f * smile, c.x + mw, my - r * 0.025f * smile) }
        drawPath(mp, ink.copy(alpha = a), style = Stroke(r * 0.042f, cap = StrokeCap.Round))
    } else {
        val mh = r * (0.06f + 0.25f * opening); val wide = mw * if (smile < 0.2f) 0.70f else 1.10f
        val mp = Path().apply {
            moveTo(c.x - wide, my); cubicTo(c.x - wide, my - mh * 0.55f, c.x + wide, my - mh * 0.55f, c.x + wide, my)
            cubicTo(c.x + wide, my + mh, c.x - wide, my + mh, c.x - wide, my); close()
        }
        drawPath(mp, ink.copy(alpha = a))
        clipPath(mp) {
            if (smile > 0.35f) drawOval(coreA.copy(alpha = 0.88f * a), Offset(c.x - wide, my - mh * 0.40f), Size(wide * 2f, mh * 0.28f))
            drawOval(Color(0xFFD090A0).copy(alpha = 0.88f * a), Offset(c.x - wide * 0.58f, my + mh * 0.32f), Size(wide * 1.18f, mh * 0.48f))
        }
    }
    if (face.tears > 0.01f) for (side in listOf(-1f, 1f)) {
        val tx = c.x + side * r * 0.52f; val ty = c.y + r * 0.15f; val t2 = face.tears
        val tp = Path().apply { moveTo(tx, ty); cubicTo(tx - r * 0.08f, ty + r * 0.18f * t2, tx - r * 0.06f, ty + r * 0.38f * t2, tx, ty + r * 0.38f * t2); cubicTo(tx + r * 0.08f, ty + r * 0.38f * t2, tx + r * 0.08f, ty + r * 0.18f * t2, tx, ty); close() }
        drawPath(tp, Brush.verticalGradient(listOf(Color(0xFFCAECFF), Color(0xFF6EADDB)), ty, ty + r * 0.44f), alpha = a * t2)
    }
}

private fun DrawScope.glowingEyes(c: Offset, r: Float, face: CelestialFaceSnapshot, ink: Color, glow: Color, iris: Color, form: Float, a: Float) {
    for (side in listOf(-1f, 1f)) {
        val lid = if (side < 0f) face.lidLeft else face.lidRight
        val ex = c.x + side * r * 0.37f; val ey = c.y - r * 0.05f
        val ew = r * 0.23f; val eh = r * 0.27f
        val openness = (1f - lid).coerceIn(0f, 1f)
        if (openness < 0.10f) {
            val ep = Path().apply { moveTo(ex - ew, ey); quadraticBezierTo(ex, ey + eh * 0.36f, ex + ew, ey) }
            drawPath(ep, ink.copy(alpha = a), style = Stroke(ew * 0.22f, cap = StrokeCap.Round))
        } else {
            val hh = eh * openness
            val shape = Path().apply {
                moveTo(ex - ew, ey); cubicTo(ex - ew * 0.86f, ey - hh * 1.22f, ex + ew * 0.83f, ey - hh * 1.22f, ex + ew, ey)
                cubicTo(ex + ew * 0.70f, ey + hh * 0.88f, ex - ew * 0.70f, ey + hh * 0.88f, ex - ew, ey); close()
            }
            drawPath(shape, Color(0xFFFFFAF4).copy(alpha = a))
            clipPath(shape) {
                val ip = Offset(ex + face.pupilX * ew * 0.22f, ey + face.pupilY * eh * 0.16f)
                val ir = ew * 0.72f * face.pupilScale.coerceIn(0.45f, 1.30f)
                drawOval(Brush.verticalGradient(listOf(ink, iris, lerp(Color(0xFFB8DCEE), Color(0xFFFFD870), form)), ip.y - eh, ip.y + eh), ip - Offset(ir, eh * 0.84f), Size(ir * 2f, eh * 1.68f), alpha = a)
                drawOval(ink.copy(alpha = a), ip - Offset(ir * 0.40f, eh * 0.58f), Size(ir * 0.80f, eh * 1.16f))
                // Star shimmer inside pupil
                for (k in 0 until 4) {
                    val st = k * 45f * PI.toFloat() / 180f
                    drawLine(glow.copy(alpha = 0.55f * a), ip, ip + Offset(cos(st) * ir * 0.50f, sin(st) * ir * 0.50f), ir * 0.08f, cap = StrokeCap.Round)
                }
                drawCircle(Color.White.copy(alpha = 0.95f * a), ew * 0.24f, ip - Offset(ew * 0.22f, eh * 0.30f))
                drawCircle(Color.White.copy(alpha = 0.68f * a), ew * 0.11f, ip + Offset(ew * 0.24f, eh * 0.24f))
            }
            val upper = Path().apply { moveTo(ex - ew, ey); cubicTo(ex - ew * 0.86f, ey - hh * 1.22f, ex + ew * 0.83f, ey - hh * 1.22f, ex + ew, ey) }
            drawPath(upper, ink.copy(alpha = a), style = Stroke(ew * 0.18f, cap = StrokeCap.Round))
        }
    }
}

// ---------------------------------------------------------------------------
// Design 5 — PIXEL  (chunky retro-art style)
// ---------------------------------------------------------------------------

internal fun DrawScope.drawPixel(
    c: Offset, radius: Float, form: Float,
    face: CelestialFaceSnapshot, alpha: Float
) {
    if (radius <= 0f || alpha <= 0f) return
    val r = radius; val f = form.coerceIn(0f, 1f); val a = alpha.coerceIn(0f, 1f)
    fun pt(x: Float, y: Float) = Offset(c.x + r * x, c.y + r * y)

    // Chunky limited palette
    val bg   = lerp(Color(0xFFDDE8F8), Color(0xFFFFF0B0), f)
    val mid  = lerp(Color(0xFF7090C8), Color(0xFFE8A028), f)
    val dark = lerp(Color(0xFF304878), Color(0xFF883010), f)
    val ink  = lerp(Color(0xFF182038), Color(0xFF401808), f)

    // Body — chunky circle with hard-ish edge gradient
    drawCircle(Brush.radialGradient(0f to bg, 0.62f to mid, 1f to dark, center = c, radius = r), r, c, alpha = a)

    // Pixel-block border: 8 squares around the perimeter
    val blockR = r * 0.12f
    for (i in 0 until 8) {
        val t = i * 45f * PI.toFloat() / 180f
        val bp = pt(cos(t).toFloat() * 0.90f, sin(t).toFloat() * 0.90f)
        val half = blockR * 0.85f
        drawRect(dark.copy(alpha = 0.42f * a), Offset(bp.x - half, bp.y - half), Size(half * 2f, half * 2f))
        drawRect(bg.copy(alpha = 0.55f * a), Offset(bp.x - half * 0.55f, bp.y - half * 0.55f), Size(half * 1.10f, half * 1.10f))
    }

    // Highlight block
    drawRect(bg.copy(alpha = 0.82f * a), pt(-0.56f, -0.58f), Size(r * 0.36f, r * 0.20f))

    // Moon: square-ish crater blocks
    if (f < 1f) {
        val cd = floatArrayOf(-0.28f, -0.40f, 0.14f, 0.30f, -0.52f, 0.08f)
        for (i in cd.indices step 3) {
            val cr = cd[i + 2] * r; val cp = pt(cd[i], cd[i + 1])
            drawRect(mid.copy(alpha = 0.32f * a * (1f - f)), Offset(cp.x - cr, cp.y - cr), Size(cr * 2f, cr * 2f))
            drawRect(bg.copy(alpha = 0.52f * a * (1f - f)), Offset(cp.x - cr * 0.62f, cp.y - cr * 0.62f), Size(cr * 1.24f, cr * 1.24f))
        }
    }
    // Sun: small pixel dots around body (no rays)
    if (f > 0f) {
        val dotPos = floatArrayOf(-0.88f, 0f, 0.88f, 0f, 0f, -0.88f, 0f, 0.88f, 0.62f, 0.62f, -0.62f, 0.62f, 0.62f, -0.62f, -0.62f, -0.62f)
        for (i in dotPos.indices step 2) {
            val dp = pt(dotPos[i], dotPos[i + 1]); val ds = r * 0.065f
            drawRect(Color(0xFFFFD020).copy(alpha = 0.68f * a * f), Offset(dp.x - ds, dp.y - ds), Size(ds * 2f, ds * 2f))
        }
    }

    drawCircle(ink.copy(alpha = 0.26f * a), r, c, style = Stroke(r * 0.022f))

    // Brows: short horizontal lines
    for (side in listOf(-1f, 1f)) {
        val bv = if (side < 0f) face.browLeft else face.browRight
        val bx = c.x + side * r * 0.36f; val by = c.y - r * (0.38f + bv.coerceAtLeast(0f) * 0.08f)
        drawLine(ink.copy(alpha = 0.80f * a), Offset(bx - r * 0.14f, by - r * 0.01f * bv), Offset(bx + r * 0.14f, by + r * 0.01f * bv), r * 0.046f, cap = StrokeCap.Square)
    }

    // Pixel eyes: thick rounded rectangles
    for (side in listOf(-1f, 1f)) {
        val lid = if (side < 0f) face.lidLeft else face.lidRight
        val ex = c.x + side * r * 0.36f; val ey = c.y - r * 0.04f
        val openness = (1f - lid).coerceIn(0f, 1f)
        val ew = r * 0.16f; val eh = r * 0.18f * openness
        if (openness < 0.10f) {
            drawLine(ink.copy(alpha = a), Offset(ex - r * 0.15f, ey), Offset(ex + r * 0.15f, ey), r * 0.046f, cap = StrokeCap.Square)
        } else {
            // Outer block
            drawRect(ink.copy(alpha = a), Offset(ex - ew - r * 0.02f, ey - eh - r * 0.02f), Size((ew + r * 0.02f) * 2f, (eh + r * 0.02f) * 2f))
            // White sclera
            drawRect(Color.White.copy(alpha = a), Offset(ex - ew, ey - eh), Size(ew * 2f, eh * 2f))
            // Pupil block
            val px = (ex + face.pupilX * ew * 0.40f).coerceIn(ex - ew * 0.52f, ex + ew * 0.52f)
            val py = (ey + face.pupilY * eh * 0.40f).coerceIn(ey - eh * 0.52f, ey + eh * 0.52f)
            drawRect(ink.copy(alpha = a), Offset(px - ew * 0.52f, py - eh * 0.52f), Size(ew * 1.04f, eh * 1.04f))
            drawRect(Color.White.copy(alpha = 0.90f * a), Offset(px - ew * 0.22f, py - eh * 0.30f), Size(ew * 0.36f, eh * 0.36f))
        }
    }

    // Cheeks
    val blush = (0.18f + face.cheekGlow * 0.38f) * a
    val cc = lerp(Color(0xFFCC88BB), Color(0xFFFF8866), f)
    for (side in listOf(-1f, 1f)) {
        val cp = pt(side * 0.50f, 0.30f); val cw = r * 0.24f; val ch = r * 0.12f
        drawRect(cc.copy(alpha = blush), Offset(cp.x - cw, cp.y - ch), Size(cw * 2f, ch * 2f))
    }

    // Mouth: pixel-style stepped
    val smile = face.mouthSmile.coerceIn(-1f, 1f)
    val opening = face.mouthOpen.coerceIn(0f, 1f)
    val my = c.y + r * 0.44f; val mw = r * 0.14f
    if (opening < 0.08f) {
        val dir = if (smile >= 0f) 1f else -1f
        drawLine(ink.copy(alpha = a), Offset(c.x - mw, my + dir * r * 0.02f), Offset(c.x, my), r * 0.046f, cap = StrokeCap.Square)
        drawLine(ink.copy(alpha = a), Offset(c.x, my), Offset(c.x + mw, my + dir * r * 0.02f), r * 0.046f, cap = StrokeCap.Square)
    } else {
        val mh = r * (0.06f + 0.20f * opening)
        drawRect(ink.copy(alpha = a), Offset(c.x - mw, my), Size(mw * 2f, mh))
        drawRect(bg.copy(alpha = 0.88f * a), Offset(c.x - mw * 0.75f, my + mh * 0.18f), Size(mw * 1.50f, mh * 0.64f))
    }

    if (face.tears > 0.01f) for (side in listOf(-1f, 1f)) {
        val t2 = face.tears; val tx = c.x + side * r * 0.50f; val ty = c.y + r * 0.12f
        drawRect(Color(0xFF88C8E8).copy(alpha = 0.78f * a * t2), Offset(tx - r * 0.022f, ty), Size(r * 0.044f, r * 0.35f * t2))
    }
}
