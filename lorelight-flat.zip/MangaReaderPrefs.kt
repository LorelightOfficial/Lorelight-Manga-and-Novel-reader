package com.lorelight.manga.reader

import android.content.Context
import android.content.SharedPreferences
import com.lorelight.core.getSafeBoolean
import com.lorelight.core.getSafeFloat
import com.lorelight.core.getSafeInt
import com.lorelight.core.getSafeLong
import com.lorelight.core.getSafeString

object MangaReaderPrefs {
    private const val PREFS_NAME = "lorelight_manga_reader_prefs"

    private const val KEY_READING_MODE = "reading_mode"
    private const val KEY_BACKGROUND = "background"
    private const val KEY_READER_BG_TYPE = "reader_background_type"
    private const val KEY_READER_BG_COLOR = "reader_bg_color"
    private const val KEY_KEEP_SCREEN_ON = "keep_screen_on"
    private const val KEY_SHOW_PAGE_NUMBER = "show_page_number"
    private const val KEY_SHOW_PAGE_SLIDER = "show_page_slider"
    private const val KEY_VOLUME_KEY_NAV = "volume_key_nav"
    private const val KEY_INVERT_VOLUME_KEYS = "invert_volume_keys"
    private const val KEY_TAP_ZONES_ENABLED = "tap_zones_enabled"
    private const val KEY_CROP_BORDERS = "crop_borders"
    private const val PREFIX_MODE_OVERRIDE = "mode_override_"

    private const val KEY_SIDE_PADDING = "side_padding"
    private const val KEY_PAGE_GAP = "page_gap"
    private const val KEY_DISABLE_ZOOM_OUT = "disable_zoom_out"
    private const val KEY_DOUBLE_TAP_ZOOM = "double_tap_zoom"
    private const val KEY_MAX_ZOOM = "max_zoom"
    private const val KEY_SCALE_TYPE = "scale_type"
    private const val KEY_ORIENTATION = "orientation"
    private const val KEY_FULLSCREEN = "fullscreen"

    private const val KEY_TAP_ZONE_LAYOUT = "tap_zone_layout"
    private const val KEY_TAP_ZONE_INVERT = "tap_zone_invert"
    private const val KEY_SHOW_ZONE_OVERLAY_ON_OPEN = "show_zone_overlay_on_open"

    private const val KEY_AUTOSCROLL_SPEED = "autoscroll_speed"
    private const val KEY_AUTOSCROLL_PAUSE_ON_TAP = "autoscroll_pause_on_tap"
    private const val KEY_AUTOSCROLL_RESUME_DELAY = "autoscroll_resume_delay"

    private const val KEY_BRIGHTNESS_OVERLAY = "brightness_overlay"
    private const val KEY_GRAYSCALE = "grayscale"
    private const val KEY_INVERT_COLORS = "invert_colors"

    private const val KEY_EXPERIMENTAL_TTS = "experimental_manga_tts"
    private const val KEY_SHOW_OCR_BOXES = "show_ocr_boxes"
    private const val KEY_OCR_LOOKAHEAD = "ocr_lookahead"
    private const val KEY_FOLLOW_VOICE_TTS = "follow_voice_tts"
    private const val KEY_OCR_AUTOCORRECT = "ocr_autocorrect_level"
    private const val KEY_TTS_FILTER_ENABLED = "tts_filter_enabled"
    private const val KEY_TTS_FILTER_SKIP_WEB = "tts_filter_skip_web"


    // Read-aloud voice settings for the MANGA reader only.
    private const val KEY_TTS_VOICE = "manga_tts_voice"
    private const val KEY_TTS_ACCENT = "manga_tts_accent"
    private const val KEY_TTS_RATE = "manga_tts_rate"
    private const val KEY_TTS_PITCH = "manga_tts_pitch"

    private const val NOVEL_STORE = "reader_prefs"
    private const val DEFAULT_ACCENT = "United States (US)"

    private val sharedChangeListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        com.lorelight.data.local.AppSettingsSignal.notifyChanged()
    }
    @Volatile private var isListenerRegistered = false

    private fun getPrefs(context: Context): SharedPreferences {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        if (!isListenerRegistered) {
            prefs.registerOnSharedPreferenceChangeListener(sharedChangeListener)
            isListenerRegistered = true
        }
        return prefs
    }

    fun getReadingMode(context: Context): MangaReadingMode {
        val str = getPrefs(context).getSafeString(KEY_READING_MODE, null)
        return parseEnum(str, MangaReadingMode.LONG_STRIP) ?: MangaReadingMode.LONG_STRIP
    }

    fun setReadingMode(context: Context, mode: MangaReadingMode) {
        getPrefs(context).edit().putString(KEY_READING_MODE, mode.name).apply()
    }

    fun getReaderBackgroundType(context: Context): String {
        return getPrefs(context).getSafeString(KEY_READER_BG_TYPE, "Theme") ?: "Theme"
    }

    /**
     * The manga-specific background override, or null when the manga reader
     * should follow the app theme chosen in the novel reader settings.
     */
    fun getReaderBackgroundTypeOrNull(context: Context): String? =
        getPrefs(context).getSafeString(KEY_READER_BG_TYPE, null)

    fun setReaderBackgroundType(context: Context, type: String) {
        getPrefs(context).edit().putString(KEY_READER_BG_TYPE, type).apply()
    }

    fun getReaderBgColor(context: Context): Long {
        return getPrefs(context).getSafeLong(KEY_READER_BG_COLOR, 0xFF1C1B1FL)
    }

    fun setReaderBgColor(context: Context, color: Long) {
        getPrefs(context).edit().putLong(KEY_READER_BG_COLOR, color).apply()
    }

    fun getKeepScreenOn(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_KEEP_SCREEN_ON, true)
    }

    fun setKeepScreenOn(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_KEEP_SCREEN_ON, value).apply()
    }

    fun getShowPageNumber(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_SHOW_PAGE_NUMBER, true)
    }

    fun setShowPageNumber(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_SHOW_PAGE_NUMBER, value).apply()
    }

    fun getShowPageSlider(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_SHOW_PAGE_SLIDER, true)
    }

    fun setShowPageSlider(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_SHOW_PAGE_SLIDER, value).apply()
    }

    fun getVolumeKeyNav(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_VOLUME_KEY_NAV, false)
    }

    fun setVolumeKeyNav(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_VOLUME_KEY_NAV, value).apply()
    }

    fun getInvertVolumeKeys(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_INVERT_VOLUME_KEYS, false)
    }

    fun setInvertVolumeKeys(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_INVERT_VOLUME_KEYS, value).apply()
    }

    fun getTapZonesEnabled(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_TAP_ZONES_ENABLED, true)
    }

    fun setTapZonesEnabled(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_TAP_ZONES_ENABLED, value).apply()
    }

    fun getSidePadding(context: Context): Int {
        return getPrefs(context).getSafeInt(KEY_SIDE_PADDING, 0)
    }

    fun setSidePadding(context: Context, value: Int) {
        getPrefs(context).edit().putInt(KEY_SIDE_PADDING, value).apply()
    }

    fun getPageGap(context: Context): Int {
        return getPrefs(context).getSafeInt(KEY_PAGE_GAP, 0)
    }

    fun setPageGap(context: Context, value: Int) {
        getPrefs(context).edit().putInt(KEY_PAGE_GAP, value).apply()
    }

    fun getDisableZoomOut(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_DISABLE_ZOOM_OUT, false)
    }

    fun setDisableZoomOut(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_DISABLE_ZOOM_OUT, value).apply()
    }

    fun getDoubleTapZoom(context: Context): Int {
        return getPrefs(context).getSafeInt(KEY_DOUBLE_TAP_ZOOM, 2)
    }

    fun setDoubleTapZoom(context: Context, value: Int) {
        getPrefs(context).edit().putInt(KEY_DOUBLE_TAP_ZOOM, value).apply()
    }

    fun getDoubleTapToZoom(context: Context): Boolean {
        return getDoubleTapZoom(context) > 0
    }

    fun setDoubleTapToZoom(context: Context, value: Boolean) {
        setDoubleTapZoom(context, if (value) 2 else 0)
    }

    fun getMaxZoom(context: Context): Float {
        return getPrefs(context).getSafeFloat(KEY_MAX_ZOOM, 3f)
    }

    fun setMaxZoom(context: Context, value: Float) {
        getPrefs(context).edit().putFloat(KEY_MAX_ZOOM, value).apply()
    }

    fun getScaleType(context: Context): String {
        return getPrefs(context).getSafeString(KEY_SCALE_TYPE, "Fit width") ?: "Fit width"
    }

    fun setScaleType(context: Context, type: String) {
        getPrefs(context).edit().putString(KEY_SCALE_TYPE, type).apply()
    }

    fun getOrientation(context: Context): Int {
        return getPrefs(context).getSafeInt(KEY_ORIENTATION, 0)
    }

    fun setOrientation(context: Context, value: Int) {
        getPrefs(context).edit().putInt(KEY_ORIENTATION, value).apply()
    }

    fun getFullscreen(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_FULLSCREEN, false)
    }

    fun setFullscreen(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_FULLSCREEN, value).apply()
    }

    fun getCropBorders(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_CROP_BORDERS, false)
    }

    fun setCropBorders(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_CROP_BORDERS, value).apply()
    }

    fun getTapZoneLayout(context: Context): MangaTapZoneLayout {
        val prefs = getPrefs(context)
        if (!prefs.getSafeBoolean("migrated_tap_zone_default_v2", false)) {
            prefs.edit()
                .putString(KEY_TAP_ZONE_LAYOUT, MangaTapZoneLayout.RIGHT_AND_LEFT.name)
                .putBoolean("migrated_tap_zone_default_v2", true)
                .apply()
            return MangaTapZoneLayout.RIGHT_AND_LEFT
        }
        val str = prefs.getSafeString(KEY_TAP_ZONE_LAYOUT, null)
        return parseEnum(str, MangaTapZoneLayout.RIGHT_AND_LEFT) ?: MangaTapZoneLayout.RIGHT_AND_LEFT
    }

    fun setTapZoneLayout(context: Context, layout: MangaTapZoneLayout) {
        getPrefs(context).edit().putString(KEY_TAP_ZONE_LAYOUT, layout.name).apply()
    }

    fun getTapZoneInvert(context: Context): MangaTapInvert {
        val str = getPrefs(context).getSafeString(KEY_TAP_ZONE_INVERT, null)
        return parseEnum(str, MangaTapInvert.NONE) ?: MangaTapInvert.NONE
    }

    fun setTapZoneInvert(context: Context, invert: MangaTapInvert) {
        getPrefs(context).edit().putString(KEY_TAP_ZONE_INVERT, invert.name).apply()
    }

    fun getShowZoneOverlayOnOpen(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_SHOW_ZONE_OVERLAY_ON_OPEN, false)
    }

    fun setShowZoneOverlayOnOpen(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_SHOW_ZONE_OVERLAY_ON_OPEN, value).apply()
    }

    fun getAutoscrollSpeed(context: Context): Int {
        return getPrefs(context).getSafeInt(KEY_AUTOSCROLL_SPEED, 120)
    }

    fun setAutoscrollSpeed(context: Context, value: Int) {
        getPrefs(context).edit().putInt(KEY_AUTOSCROLL_SPEED, value).apply()
    }

    fun getAutoscrollPauseOnTap(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_AUTOSCROLL_PAUSE_ON_TAP, false)
    }

    fun setAutoscrollPauseOnTap(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_AUTOSCROLL_PAUSE_ON_TAP, value).apply()
    }

    /**
     * How long autoscroll waits after your finger leaves the glass before it
     * starts moving again, in milliseconds. Only consulted when "pause on tap"
     * is OFF, which is the mode where autoscroll is meant to keep going.
     */
    fun getAutoscrollResumeDelay(context: Context): Int {
        return getPrefs(context).getSafeInt(KEY_AUTOSCROLL_RESUME_DELAY, 2000).coerceIn(0, 10000)
    }

    fun setAutoscrollResumeDelay(context: Context, value: Int) {
        getPrefs(context).edit().putInt(KEY_AUTOSCROLL_RESUME_DELAY, value.coerceIn(0, 10000)).apply()
    }

    /** Master gate for screen-based manga TTS. Off by default. */
    fun getExperimentalTts(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_EXPERIMENTAL_TTS, false)
    }

    fun setExperimentalTts(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_EXPERIMENTAL_TTS, value).apply()
    }

    /** Debug overlay drawing OCR boxes and their read order. */
    fun getShowOcrBoxes(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_SHOW_OCR_BOXES, false)
    }

    fun setShowOcrBoxes(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_SHOW_OCR_BOXES, value).apply()
    }

    fun getOcrLookahead(context: Context): Int {
        return getPrefs(context).getSafeInt(KEY_OCR_LOOKAHEAD, 1).coerceIn(0, 5)
    }

    fun setOcrLookahead(context: Context, value: Int) {
        getPrefs(context).edit().putInt(KEY_OCR_LOOKAHEAD, value.coerceIn(0, 5)).apply()
    }

    /** Measure the page, enlarge only what is too small to recognise. */
    const val OCR_DETAIL_AUTO = 0

    /**
     * How much the page is enlarged before text recognition.
     *
     * English manhwa and manhua are usually only 720-900px wide, which puts
     * their lettering below what the recognizer can read reliably, so small
     * pages are enlarged and large raws are left untouched. There is no manual
     * override any more: this is not a taste setting, it is what the recognizer
     * needs in order to work.
     * Manga only -- the novel reader never reads this store.
     */
    fun getOcrDetail(context: Context): Int {
        // Always Auto. The manual rungs existed to work around bad recognition
        // on small pages, but Auto already measures the page and enlarges only
        // what needs it: Standard just made small pages unreadable again, and
        // High/Maximum burned memory enlarging raws that were already big
        // enough. Any value stored by an older build is ignored rather than
        // migrated, so nobody is left stuck on a rung they cannot see.
        return OCR_DETAIL_AUTO
    }

    /** Optional auto-scrolling to current spoken bubble. Default is false (page-driven speech). */
    fun getFollowVoiceTts(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_FOLLOW_VOICE_TTS, false)
    }

    fun setFollowVoiceTts(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_FOLLOW_VOICE_TTS, value).apply()
    }

    /**
     * How hard the OCR autocorrect may try before text reaches the voice.
     * Stored by name so levels can be added later without a migration.
     * Only the spoken text is affected; the OCR cache and the debug overlay
     * keep the pristine recognizer output.
     */
    fun getOcrAutocorrectLevel(context: Context): MangaOcrCorrectionLevel {
        return MangaOcrCorrectionLevel.fromName(
            getPrefs(context).getSafeString(KEY_OCR_AUTOCORRECT, null)
        )
    }

    fun setOcrAutocorrectLevel(context: Context, value: MangaOcrCorrectionLevel) {
        getPrefs(context).edit().putString(KEY_OCR_AUTOCORRECT, value.name).apply()
    }

    fun getTtsFilterEnabled(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_TTS_FILTER_ENABLED, true)
    }

    fun setTtsFilterEnabled(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_TTS_FILTER_ENABLED, value).apply()
    }

    fun getTtsFilterSkipWebAddresses(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_TTS_FILTER_SKIP_WEB, true)
    }

    fun setTtsFilterSkipWebAddresses(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_TTS_FILTER_SKIP_WEB, value).apply()
    }

    // ---- Read-aloud voice, manga only ----
    //
    // These used to come straight from TtsPlaybackManager, which is the novel
    // reader's live session state, so picking a voice or speed for manga changed
    // it for novels too. Now the manga reader keeps its own values here.
    //
    // The getters fall back to the novel reader's SAVED value only while the
    // manga store has never been written, so existing installs keep sounding the
    // same instead of snapping to a default. The setters only ever write the
    // manga store, so a change made here can never travel the other way.

    fun getTtsVoiceName(context: Context): String? {
        val prefs = getPrefs(context)
        if (prefs.contains(KEY_TTS_VOICE)) return prefs.getSafeString(KEY_TTS_VOICE, null)
        return try {
            context.getSharedPreferences(NOVEL_STORE, Context.MODE_PRIVATE)
                .getSafeString("selected_voice_name", null)
        } catch (_: Throwable) {
            null
        }
    }

    fun setTtsVoiceName(context: Context, name: String) {
        getPrefs(context).edit().putString(KEY_TTS_VOICE, name).apply()
    }

    fun getTtsAccent(context: Context): String {
        val prefs = getPrefs(context)
        if (prefs.contains(KEY_TTS_ACCENT)) {
            return prefs.getSafeString(KEY_TTS_ACCENT, DEFAULT_ACCENT) ?: DEFAULT_ACCENT
        }
        return try {
            context.getSharedPreferences(NOVEL_STORE, Context.MODE_PRIVATE)
                .getSafeString("selected_accent", DEFAULT_ACCENT) ?: DEFAULT_ACCENT
        } catch (_: Throwable) {
            DEFAULT_ACCENT
        }
    }

    fun setTtsAccent(context: Context, accent: String) {
        getPrefs(context).edit().putString(KEY_TTS_ACCENT, accent).apply()
    }

    fun getTtsRate(context: Context): Float {
        return getPrefs(context).getSafeFloat(KEY_TTS_RATE, 1.0f)
    }

    fun setTtsRate(context: Context, value: Float) {
        getPrefs(context).edit().putFloat(KEY_TTS_RATE, value.coerceIn(0.25f, 4.0f)).apply()
    }

    fun getTtsPitch(context: Context): Float {
        return getPrefs(context).getSafeFloat(KEY_TTS_PITCH, 1.0f)
    }

    fun setTtsPitch(context: Context, value: Float) {
        getPrefs(context).edit().putFloat(KEY_TTS_PITCH, value.coerceIn(0.25f, 4.0f)).apply()
    }

    fun getBrightnessOverlay(context: Context): Int {
        return getPrefs(context).getSafeInt(KEY_BRIGHTNESS_OVERLAY, 0)
    }

    fun setBrightnessOverlay(context: Context, value: Int) {
        getPrefs(context).edit().putInt(KEY_BRIGHTNESS_OVERLAY, value).apply()
    }

    fun getGrayscale(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_GRAYSCALE, false)
    }

    fun setGrayscale(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_GRAYSCALE, value).apply()
    }

    fun getInvertColors(context: Context): Boolean {
        return getPrefs(context).getSafeBoolean(KEY_INVERT_COLORS, false)
    }

    fun setInvertColors(context: Context, value: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_INVERT_COLORS, value).apply()
    }

    fun getModeOverrideKey(sourceId: Long, mangaUrl: String): String = "mode_override_${sourceId}_$mangaUrl"

    fun getModeOverride(context: Context, sourceId: Long, mangaUrl: String): MangaReadingMode? {
        val str = getPrefs(context).getSafeString(getModeOverrideKey(sourceId, mangaUrl), null) ?: return null
        return parseEnum<MangaReadingMode>(str, null)
    }

    fun setModeOverride(context: Context, sourceId: Long, mangaUrl: String, mode: MangaReadingMode?) {
        val key = getModeOverrideKey(sourceId, mangaUrl)
        if (mode == null) {
            getPrefs(context).edit().remove(key).apply()
        } else {
            getPrefs(context).edit().putString(key, mode.name).apply()
        }
    }

    fun getModeOverride(context: Context, novelId: String): MangaReadingMode? {
        val str = getPrefs(context).getSafeString(PREFIX_MODE_OVERRIDE + novelId, null) ?: return null
        return parseEnum<MangaReadingMode>(str, null)
    }

    fun setModeOverride(context: Context, novelId: String, mode: MangaReadingMode?) {
        if (mode == null) {
            getPrefs(context).edit().remove(PREFIX_MODE_OVERRIDE + novelId).apply()
        } else {
            getPrefs(context).edit().putString(PREFIX_MODE_OVERRIDE + novelId, mode.name).apply()
        }
    }

    fun getEffectiveReadingMode(context: Context, novelId: String): MangaReadingMode {
        return getModeOverride(context, novelId) ?: getReadingMode(context)
    }

    fun resetToDefaults(context: Context) {
        getPrefs(context).edit().clear().apply()
    }

    inline fun <reified T : Enum<T>> parseEnum(name: String?, default: T?): T? {
        if (name.isNullOrBlank()) return default
        return try {
            java.lang.Enum.valueOf(T::class.java, name)
        } catch (e: Exception) {
            default
        }
    }
}

