package com.lorelight.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "novels")
data class NovelEntity(
    @PrimaryKey val id: String,
    val title: String,
    val currentChapter: String,
    val lastReadTimestamp: Long,
    val author: String,
    val status: String,
    val totalChapters: Int,
    val language: String,
    val genresJson: String,          // JSON array of strings
    val description: String,
    val chaptersJson: String,        // JSON array of strings
    val coverImageBase64: String?,   // file path or legacy base64
    val isOnline: Boolean,
    val sourceUrl: String?,
    val chapterUrlsJson: String,     // JSON array of strings
    val currentParagraphIndex: Int,
    val completedChaptersJson: String, // JSON array of strings
    val currentScrollOffset: Int,
    val currentWordIndex: Int,
    val isFavorite: Boolean,
    val categoriesJson: String,      // JSON array of strings
    val readingStatus: String,
    val dateAdded: Long,
    val dateModified: Long,
    val lastCheckedTimestamp: Long,
    val pluginId: String?,
    val pluginNovelPath: String?,
    // RESUME REDESIGN. See Novel.currentChapterIndex. -1 = nothing recorded.
    val currentChapterIndex: Int = -1
)
