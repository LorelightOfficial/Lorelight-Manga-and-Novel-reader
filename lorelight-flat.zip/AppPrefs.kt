package com.lorelight.data.local

import android.content.Context
import android.content.SharedPreferences
import android.util.Log

/**
 * The one place that opens the app's general settings store.
 *
 * The app used to write general settings into two different files:
 *  - "lorelight_settings_guest" (settings screen, library update scheduler,
 *    worker, self healing)
 *  - "lorelight_settings"       (library screen: shelf layout, sort, filters)
 *
 * Nothing ever read across the two, so backup only covered one of them and a
 * few library toggles silently lived outside backup/restore. [get] now returns
 * the canonical store and copies any keys from the old file across exactly
 * once, without overwriting values that already exist.
 */
object AppPrefs {

    /** Canonical settings file name. */
    const val NAME = "lorelight_settings_guest"

    private const val LEGACY_NAME = "lorelight_settings"
    private const val MIGRATION_FLAG = "legacy_settings_merged_v1"

    private val sharedChangeListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        AppSettingsSignal.notifyChanged()
    }
    @Volatile private var isListenerRegistered = false

    fun notifyChanged() = AppSettingsSignal.notifyChanged()

    fun get(context: Context): SharedPreferences {
        val appContext = context.applicationContext
        val target = appContext.getSharedPreferences(NAME, Context.MODE_PRIVATE)
        if (!target.getBoolean(MIGRATION_FLAG, false)) {
            mergeLegacyOnce(appContext, target)
        }
        if (!isListenerRegistered) {
            target.registerOnSharedPreferenceChangeListener(sharedChangeListener)
            isListenerRegistered = true
        }
        return target
    }

    private fun mergeLegacyOnce(appContext: Context, target: SharedPreferences) {
        try {
            val legacy = appContext.getSharedPreferences(LEGACY_NAME, Context.MODE_PRIVATE)
            val editor = target.edit()
            var copied = 0
            for ((key, value) in legacy.all) {
                if (key == MIGRATION_FLAG) continue
                if (target.contains(key)) continue
                val applied = when (value) {
                    is Boolean -> { editor.putBoolean(key, value); true }
                    is Float -> { editor.putFloat(key, value); true }
                    is Int -> { editor.putInt(key, value); true }
                    is Long -> { editor.putLong(key, value); true }
                    is String -> { editor.putString(key, value); true }
                    is Set<*> -> {
                        val strings = value.filterIsInstance<String>().toSet()
                        if (strings.size == value.size) {
                            editor.putStringSet(key, strings)
                            true
                        } else {
                            false
                        }
                    }
                    else -> false
                }
                if (applied) copied++
            }
            editor.putBoolean(MIGRATION_FLAG, true).commit()
            if (copied > 0) {
                Log.i("AppPrefs", "Merged $copied legacy setting(s) into $NAME")
            }
        } catch (e: Throwable) {
            Log.w("AppPrefs", "Legacy settings merge failed: ${e.message}")
        }
    }
}
