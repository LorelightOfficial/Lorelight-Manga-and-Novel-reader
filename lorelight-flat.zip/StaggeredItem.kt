package com.lorelight.ui.animation

import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun StaggeredItem(
    index: Int,
    animate: Boolean = true,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    if (modifier == Modifier) {
        StaggeredItem(index = index, key = index, animate = animate, content = content)
    } else {
        StaggeredItem(index = index, key = index, animate = animate) {
            Box(modifier = modifier) {
                content()
            }
        }
    }
}

