package com.lorelight.ui.settings

/*
 * SettingsDataOps.kt - cache stats and backup/restore business logic pulled
 * out of SettingsScreen.kt (S4, pure move, no logic changes).
 *
 * Kept in the same package (com.lorelight.ui.settings) on purpose, same
 * precedent as navigation/ScreenDestination.kt (v26) and
 * ui/library/components/LibraryVisualEffects.kt (v30): callers outside this
 * package already import these functions by package + name
 * (e.g. "import com.lorelight.ui.settings.generateBackupJson" in
 * core/BackupManager.kt, "import com.lorelight.ui.settings.restoreBackupJson"
 * in core/SelfHealingEngine.kt), so moving the file needs zero import
 * changes anywhere.
 */

import android.content.Context
import android.content.SharedPreferences
import com.lorelight.R
import com.lorelight.core.BackupManager
import com.lorelight.data.model.Novel
import com.lorelight.data.model.Website
import com.lorelight.data.model.toJSONObject
import com.lorelight.data.model.toNovel
import eu.kanade.tachiyomi.extension.ExtensionManager
import kotlinx.coroutines.runBlocking
import mihon.domain.extension.interactor.AddExtensionStore
import mihon.domain.extension.interactor.GetExtensionStores
import org.json.JSONArray
import org.json.JSONObject
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CacheStats(val fileCount: Int, val totalSizeFormatted: String, val sizeInBytes: Long)

fun formatBytes(totalBytes: Long): String = when {
    totalBytes < 1024 -> "$totalBytes B"
    totalBytes < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", totalBytes / 1024.0)
    else -> String.format(Locale.US, "%.1f MB", totalBytes / (1024.0 * 1024.0))
}

data class NovelCacheStat(
    val novelId: String,
    val title: String,
    val fileCount: Int,
    val sizeInBytes: Long,
    val sizeFormatted: String
)

private fun cacheFileNameFor(url: String): String =
    url.replace(Regex("[^a-zA-Z0-9]"), "_") + ".txt"

fun getPerNovelCacheStats(context: Context, novels: List<com.lorelight.data.model.Novel>): List<NovelCacheStat> {
    val cacheDir = File(context.filesDir, "chapters_cache")
    if (!cacheDir.exists() || !cacheDir.isDirectory) return emptyList()
    val allFiles = (cacheDir.listFiles() ?: return emptyList())
        .filter { it.isFile && it.name.endsWith(".txt") }
        .associateBy { it.name }

    val out = mutableListOf<NovelCacheStat>()
    val claimed = mutableSetOf<String>()

    novels.forEach { novel ->
        var count = 0
        var bytes = 0L
        novel.chapterUrls.forEach { url ->
            val name = cacheFileNameFor(url)
            val f = allFiles[name]
            if (f != null && claimed.add(name)) {
                count++
                bytes += f.length()
            }
        }
        if (count > 0) {
            out.add(NovelCacheStat(novel.id, novel.title, count, bytes, formatBytes(bytes)))
        }
    }

    val leftover = allFiles.keys - claimed
    if (leftover.isNotEmpty()) {
        val bytes = leftover.sumOf { allFiles[it]?.length() ?: 0L }
        out.add(NovelCacheStat("__orphaned__", context.getString(R.string.settings_orphaned_novels_label), leftover.size, bytes, formatBytes(bytes)))
    }
    return out.sortedByDescending { it.sizeInBytes }
}

fun deleteCacheForNovel(context: Context, novel: com.lorelight.data.model.Novel): Int {
    var deleted = 0
    try {
        val cacheDir = File(context.filesDir, "chapters_cache")
        novel.chapterUrls.forEach { url ->
            val f = File(cacheDir, cacheFileNameFor(url))
            if (f.exists() && f.delete()) deleted++
        }
    } catch (e: Exception) { e.printStackTrace() }
    return deleted
}

fun deleteOrphanedCache(context: Context, novels: List<com.lorelight.data.model.Novel>): Int {
    var deleted = 0
    try {
        val cacheDir = File(context.filesDir, "chapters_cache")
        val keep = novels.flatMap { it.chapterUrls }.map { cacheFileNameFor(it) }.toSet()
        (cacheDir.listFiles() ?: return 0)
            .filter { it.isFile && it.name.endsWith(".txt") && it.name !in keep }
            .forEach { if (it.delete()) deleted++ }
    } catch (e: Exception) { e.printStackTrace() }
    return deleted
}

fun getCacheStats(context: Context): CacheStats {
    val cacheDir = File(context.filesDir, "chapters_cache")
    if (!cacheDir.exists() || !cacheDir.isDirectory) {
        return CacheStats(0, "0 B", 0L)
    }
    val files = cacheDir.listFiles() ?: return CacheStats(0, "0 B", 0L)
    val txtFiles = files.filter { it.isFile && it.name.endsWith(".txt") }
    val count = txtFiles.size
    val totalBytes = txtFiles.sumOf { it.length() }
    return CacheStats(count, formatBytes(totalBytes), totalBytes)
}

fun deleteChaptersCache(context: Context): Boolean {
    return try {
        val cacheDir = File(context.filesDir, "chapters_cache")
        if (cacheDir.exists() && cacheDir.isDirectory) {
            val files = cacheDir.listFiles()
            if (files != null) {
                for (file in files) {
                    if (file.isFile && file.name.endsWith(".txt")) {
                        file.delete()
                    }
                }
            }
        }
        true
    } catch (e: Exception) {
        e.printStackTrace()
        false
    }
}

// FIX C15: single canonical settings store, which also merges the legacy
// "lorelight_settings" file that the library screen used to own.
private fun loreSettingsPrefs(context: Context): android.content.SharedPreferences =
    com.lorelight.data.local.AppPrefs.get(context)

/**
 * What the user chose to include in this backup.
 *
 * Persisted in the same "lorelight_backup_prefs" file that [BackupManager]
 * already owns, so the choice survives across sessions and is picked up by
 * both "Backup Now" and the file export path.
 */
data class BackupOptions(
    val includeSources: Boolean = true,
) {
    companion object {
        private const val PREFS = "lorelight_backup_prefs"
        private const val KEY_SOURCES = "backup_include_sources"

        fun load(context: Context): BackupOptions {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            return BackupOptions(
                includeSources = p.getBoolean(KEY_SOURCES, true),
            )
        }

        fun save(context: Context, options: BackupOptions) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_SOURCES, options.includeSources)
                .commit()
        }
    }
}

fun generateBackupJson(
    context: Context,
    options: BackupOptions = BackupOptions.load(context),
): String {
    val backupObj = JSONObject()
    
    // 1. Novels & History from Room via NovelPreferences
    val savedNovelsList = com.lorelight.data.repository.LibraryRepository.loadLibrary(context)
    val savedNovelsArr = JSONArray()
    savedNovelsList.forEach { novel ->
        val obj = novel.toJSONObject()
        val cover = novel.coverImageBase64
        // A remote http(s) cover restores fine on its own -- the new install
        // just downloads it again. Only LOCAL covers are lost on uninstall,
        // because filesDir is deleted with the app, so only those need to be
        // embedded here.
        val isRemote = cover != null &&
            (cover.startsWith("http://") || cover.startsWith("https://"))
        if (!isRemote) {
            val encoded = com.lorelight.data.local.CoverStorage
                .encodeCoverForBackup(context, novel.id, cover)
            if (encoded != null) {
                obj.put("coverBackupData", encoded)
                // Blank the stale absolute path. It points into the OLD
                // install's filesDir and is meaningless on the new device;
                // leaving it would only render a broken image.
                obj.put("coverImageBase64", "")
            }
        }
        savedNovelsArr.put(obj)
    }
    
    val lorePrefs = loreSettingsPrefs(context)
    val savedWebsites = lorePrefs.getString("saved_websites", "[]")
    
    val readingHistoryList = com.lorelight.data.repository.LibraryRepository.loadHistory(context)
    val readingHistoryArr = JSONArray()
    readingHistoryList.forEach { item ->
        val obj = JSONObject()
        obj.put("novelId", item.novelId)
        obj.put("novelTitle", item.novelTitle)
        obj.put("chapterId", item.chapterId)
        obj.put("chapterTitle", item.chapterTitle)
        obj.put("timestamp", item.timestamp)
        obj.put("lastModified", item.lastModified)
        obj.put("novelJson", item.novelJson)
        readingHistoryArr.put(obj)
    }

    backupObj.put("saved_novels", savedNovelsArr.toString())
    backupObj.put("saved_websites", savedWebsites)
    backupObj.put("reading_history", readingHistoryArr.toString())

    val highlightsList = com.lorelight.data.repository.LibraryRepository.loadHighlights(context)
    val highlightsArr = JSONArray()
    highlightsList.forEach { h ->
        val obj = JSONObject()
        obj.put("id", h.id)
        obj.put("novelId", h.novelId)
        obj.put("chapterTitle", h.chapterTitle)
        obj.put("startWordIdx", h.startWordIdx)
        obj.put("endWordIdx", h.endWordIdx)
        obj.put("colorHex", h.colorHex)
        obj.put("createdTimestamp", h.createdTimestamp)
        highlightsArr.put(obj)
    }
    backupObj.put("saved_highlights", highlightsArr.toString())
    
    // 2. SharedPreferences: reader_text_filters
    val filterPrefs = context.getSharedPreferences("reader_text_filters", Context.MODE_PRIVATE)
    val rules = filterPrefs.getString("rules", "[]")
    backupObj.put("reader_text_filters_rules", rules)

    // 2b. Manga side. The read-aloud text filters live in their own store, and
    // every manga reader setting (autoscroll, tap zones, OCR detail, TTS voice)
    // lives in lorelight_manga_reader_prefs. Without these two blocks a backup
    // silently dropped the entire manga half of the reader setup.
    val mangaFilterPrefs = context.getSharedPreferences("manga_reader_text_filters", Context.MODE_PRIVATE)
    backupObj.put("manga_reader_text_filters_rules", mangaFilterPrefs.getString("rules", "[]"))

    val mangaReaderPrefs = context.getSharedPreferences("lorelight_manga_reader_prefs", Context.MODE_PRIVATE)
    val mangaReaderPrefsObj = JSONObject()
    mangaReaderPrefs.all.forEach { (key, value) ->
        mangaReaderPrefsObj.put(key, value)
    }
    backupObj.put("lorelight_manga_reader_prefs", mangaReaderPrefsObj)
    
    // 3. SharedPreferences: reader_prefs
    val readerPrefs = context.getSharedPreferences("reader_prefs", Context.MODE_PRIVATE)
    val readerPrefsObj = JSONObject()
    val allReaderPrefs = readerPrefs.all
    allReaderPrefs.forEach { (key, value) ->
        readerPrefsObj.put(key, value)
    }
    backupObj.put("reader_prefs", readerPrefsObj)
    
    // ---- Sources (opt-in) -------------------------------------------------
    // Guarded so a user who only wants library data still gets a small file.
    if (options.includeSources) {
        val browsePrefs = context.getSharedPreferences(
            "lorelight_browse_prefs", Context.MODE_PRIVATE,
        )
        // Novel plugin repos + installed novel plugins are plain JSON in
        // SharedPreferences, so these restore perfectly.
        backupObj.put(
            "novel_plugin_repos",
            browsePrefs.getString("repo_urls", "[]") ?: "[]",
        )
        backupObj.put(
            "novel_installed_plugins",
            browsePrefs.getString("installed_plugins", "[]") ?: "[]",
        )

        // Manga extension repos live in tachiyomi.db behind suspend
        // interactors. generateBackupJson must therefore never run on the
        // main thread -- both call sites now dispatch to Dispatchers.IO.
        try {
            val stores = runBlocking { Injekt.get<GetExtensionStores>().get() }
            val storeArr = JSONArray()
            stores.forEach { storeArr.put(it.indexUrl) }
            backupObj.put("manga_extension_repos", storeArr.toString())
        } catch (e: Exception) {
            // A missing extension subsystem must never fail the whole backup.
            backupObj.put("manga_extension_repos", "[]")
        }

        // Installed manga extensions are APKs and cannot be restored as data.
        // Record them so the user knows what to reinstall after a restore.
        try {
            val extManager = Injekt.get<ExtensionManager>()
            val installedArr = JSONArray()
            extManager.installedExtensionsFlow.value.forEach { ext ->
                installedArr.put(
                    JSONObject()
                        .put("pkgName", ext.pkgName)
                        .put("name", ext.name)
                        .put("versionName", ext.versionName),
                )
            }
            backupObj.put("manga_installed_extensions", installedArr.toString())
        } catch (e: Exception) {
            backupObj.put("manga_installed_extensions", "[]")
        }
    }

    // Metadata
    backupObj.put("backup_timestamp", System.currentTimeMillis())
    backupObj.put("app_version", com.lorelight.BuildConfig.VERSION_NAME)
    
    return backupObj.toString()
}

fun restoreBackupJson(context: Context, backupStr: String): Boolean {
    try {
        val backupObj = JSONObject(backupStr)
        
        // 1. Merge Saved Novels via NovelPreferences
        val backupSavedNovelsStr = backupObj.optString("saved_novels", "[]")
        val backupSavedWebsitesStr = backupObj.optString("saved_websites", "[]")
        
        // Quick structural validation of backup input
        try {
            JSONArray(backupSavedNovelsStr)
        } catch (e: Exception) {
            return false
        }
        
        val currentNovels = com.lorelight.data.repository.LibraryRepository.loadLibrary(context)
        val mergedNovels = currentNovels.toMutableList()
        val existingNovelTitles = currentNovels.map { it.title }.filter { it.isNotEmpty() }.toMutableSet()
        
        val backupNovelsArr = JSONArray(backupSavedNovelsStr)
        for (i in 0 until backupNovelsArr.length()) {
            val novelObj = backupNovelsArr.getJSONObject(i)
            val parsed = novelObj.toNovel()
            if (parsed.title.isEmpty() || existingNovelTitles.contains(parsed.title)) {
                continue
            }
            // Rehydrate the embedded cover into THIS install's covers/ dir and
            // point the novel at the new local path. Older backups have no
            // "coverBackupData" key and simply restore without a cover.
            val coverData = novelObj.optString("coverBackupData", "")
            val novel = if (coverData.isNotEmpty()) {
                val restoredPath = com.lorelight.data.local.CoverStorage
                    .restoreCoverFromBackup(context, parsed.id, coverData)
                if (restoredPath != null) {
                    parsed.copy(coverImageBase64 = restoredPath)
                } else {
                    parsed
                }
            } else {
                parsed
            }
            mergedNovels.add(novel)
            existingNovelTitles.add(novel.title)
        }
        com.lorelight.data.repository.LibraryRepository.saveLibrary(context, mergedNovels)
        
        // Merge Saved Websites
        val lorePrefs = loreSettingsPrefs(context)
        val currentSavedWebsitesStr = lorePrefs.getString("saved_websites", "[]") ?: "[]"
        val mergedWebsites = JSONArray()
        val existingWebsitesUrls = mutableSetOf<String>()
        
        val currentWebsitesArr = JSONArray(currentSavedWebsitesStr)
        for (i in 0 until currentWebsitesArr.length()) {
            val webObj = currentWebsitesArr.getJSONObject(i)
            val url = webObj.optString("url", "")
            if (url.isNotEmpty()) {
                existingWebsitesUrls.add(url)
            }
            mergedWebsites.put(webObj)
        }
        
        val backupWebsitesArr = JSONArray(backupSavedWebsitesStr)
        for (i in 0 until backupWebsitesArr.length()) {
            val webObj = backupWebsitesArr.getJSONObject(i)
            val url = webObj.optString("url", "")
            if (url.isNotEmpty() && !existingWebsitesUrls.contains(url)) {
                mergedWebsites.put(webObj)
                existingWebsitesUrls.add(url)
            }
        }
        
        lorePrefs.edit()
            .putString("saved_websites", mergedWebsites.toString())
            .commit()

        // Merge Reading History via NovelPreferences
        val backupHistoryStr = if (backupObj.has("reading_history")) backupObj.optString("reading_history", "[]")
                               else backupObj.optString("reading_history_list", "[]")
        if (backupHistoryStr.isNotEmpty() && backupHistoryStr != "[]") {
            try {
                val currentHistory = com.lorelight.data.repository.LibraryRepository.loadHistory(context).toMutableList()
                val existingKeys = currentHistory.map { "${it.novelId}_${it.chapterId}" }.toMutableSet()
                val historyArr = JSONArray(backupHistoryStr)
                for (i in 0 until historyArr.length()) {
                    val obj = historyArr.getJSONObject(i)
                    val entry = com.lorelight.data.model.HistoryEntry(
                        novelId = obj.optString("novelId"),
                        novelTitle = obj.optString("novelTitle"),
                        chapterId = obj.optString("chapterId"),
                        chapterTitle = obj.optString("chapterTitle"),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        lastModified = obj.optLong("lastModified", System.currentTimeMillis()),
                        novelJson = obj.optString("novelJson")
                    )
                    val key = "${entry.novelId}_${entry.chapterId}"
                    if (existingKeys.add(key)) {
                        currentHistory.add(entry)
                    }
                }
                com.lorelight.data.repository.LibraryRepository.saveHistory(context, currentHistory)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
            
        // Merge Highlights
        val backupHighlightsStr = backupObj.optString("saved_highlights", "[]")
        if (backupHighlightsStr.isNotEmpty() && backupHighlightsStr != "[]") {
            try {
                val currentHighlights = com.lorelight.data.repository.LibraryRepository.loadHighlights(context).toMutableList()
                val existingIds = currentHighlights.map { it.id }.toMutableSet()
                val arr = JSONArray(backupHighlightsStr)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val id = obj.optString("id", "")
                    if (id.isNotEmpty() && existingIds.add(id)) {
                        currentHighlights.add(
                            com.lorelight.data.model.Highlight(
                                id = id,
                                novelId = obj.optString("novelId", ""),
                                chapterTitle = obj.optString("chapterTitle", ""),
                                startWordIdx = obj.optInt("startWordIdx", 0),
                                endWordIdx = obj.optInt("endWordIdx", 0),
                                colorHex = obj.optString("colorHex", "#FFFF00"),
                                createdTimestamp = obj.optLong("createdTimestamp", System.currentTimeMillis())
                            )
                        )
                    }
                }
                com.lorelight.data.repository.LibraryRepository.saveHighlights(context, currentHighlights)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // 2. SharedPreferences: reader_text_filters (Merge unique rules based on rule ID)
        val filterPrefs = context.getSharedPreferences("reader_text_filters", Context.MODE_PRIVATE)
        val currentRulesStr = filterPrefs.getString("rules", "[]") ?: "[]"
        val backupRulesStr = backupObj.optString("reader_text_filters_rules", "[]")
        
        val mergedRules = JSONArray()
        val existingRuleIds = mutableSetOf<String>()
        
        val currentRulesArr = JSONArray(currentRulesStr)
        for (i in 0 until currentRulesArr.length()) {
            val ruleObj = currentRulesArr.getJSONObject(i)
            val id = ruleObj.optString("id", "")
            if (id.isNotEmpty()) {
                existingRuleIds.add(id)
            }
            mergedRules.put(ruleObj)
        }
        
        val backupRulesArr = JSONArray(backupRulesStr)
        for (i in 0 until backupRulesArr.length()) {
            val ruleObj = backupRulesArr.getJSONObject(i)
            val id = ruleObj.optString("id", "")
            if (id.isNotEmpty() && !existingRuleIds.contains(id)) {
                mergedRules.put(ruleObj)
                existingRuleIds.add(id)
            }
        }
        filterPrefs.edit().putString("rules", mergedRules.toString()).commit()

        // 2b. Manga read-aloud filters: same merge-by-id policy, so restoring
        // never drops rules the user added since the backup. Missing key (old
        // backup) is a silent no-op.
        try {
            val mangaFilterPrefs = context.getSharedPreferences("manga_reader_text_filters", Context.MODE_PRIVATE)
            val mangaCurrentStr = mangaFilterPrefs.getString("rules", "[]") ?: "[]"
            val mangaBackupStr = backupObj.optString("manga_reader_text_filters_rules", "[]")
            val mangaMerged = JSONArray()
            val mangaSeen = mutableSetOf<String>()
            val mangaCurrentArr = JSONArray(mangaCurrentStr)
            for (i in 0 until mangaCurrentArr.length()) {
                val ruleObj = mangaCurrentArr.getJSONObject(i)
                val id = ruleObj.optString("id", "")
                if (id.isNotEmpty()) {
                    mangaSeen.add(id)
                }
                mangaMerged.put(ruleObj)
            }
            val mangaBackupArr = JSONArray(mangaBackupStr)
            for (i in 0 until mangaBackupArr.length()) {
                val ruleObj = mangaBackupArr.getJSONObject(i)
                val id = ruleObj.optString("id", "")
                if (id.isNotEmpty() && !mangaSeen.contains(id)) {
                    mangaMerged.put(ruleObj)
                    mangaSeen.add(id)
                }
            }
            mangaFilterPrefs.edit().putString("rules", mangaMerged.toString()).commit()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 2c. Manga reader settings: overlay from backup, same typed policy as
        // reader_prefs below. Guarded so an old backup without this key is a
        // no-op, including during SelfHealingEngine crash recovery.
        try {
            val mangaReaderPrefs = context.getSharedPreferences("lorelight_manga_reader_prefs", Context.MODE_PRIVATE)
            val mangaReaderPrefsObj = backupObj.optJSONObject("lorelight_manga_reader_prefs")
            if (mangaReaderPrefsObj != null) {
                val mangaEdit = mangaReaderPrefs.edit()
                val mangaKeys = mangaReaderPrefsObj.keys()
                while (mangaKeys.hasNext()) {
                    val key = mangaKeys.next()
                    val value = mangaReaderPrefsObj.get(key)
                    when (value) {
                        is Boolean -> mangaEdit.putBoolean(key, value)
                        is Float -> mangaEdit.putFloat(key, value)
                        is Int -> mangaEdit.putInt(key, value)
                        is Long -> mangaEdit.putLong(key, value)
                        is String -> mangaEdit.putString(key, value)
                        is Double -> mangaEdit.putFloat(key, value.toFloat())
                    }
                }
                mangaEdit.commit()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        // 3. SharedPreferences: reader_prefs (Safely overlay settings from backup)
        val readerPrefs = context.getSharedPreferences("reader_prefs", Context.MODE_PRIVATE)
        val readerPrefsObj = backupObj.optJSONObject("reader_prefs")
        val edit = readerPrefs.edit()
        if (readerPrefsObj != null) {
            val keys = readerPrefsObj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val value = readerPrefsObj.get(key)
                when (value) {
                    is Boolean -> edit.putBoolean(key, value)
                    is Float -> edit.putFloat(key, value)
                    is Int -> edit.putInt(key, value)
                    is Long -> edit.putLong(key, value)
                    is String -> edit.putString(key, value)
                    is Double -> edit.putFloat(key, value.toFloat())
                }
            }
        }
        edit.commit()
        
        // 4. Chapters Cache Files (Write backup caches if they exist, never overwriting local ones)
        val cacheObj = backupObj.optJSONObject("chapters_cache")
        if (cacheObj != null) {
            val cacheDir = File(context.filesDir, "chapters_cache")
            if (!cacheDir.exists()) {
                cacheDir.mkdirs()
            }
            val keys = cacheObj.keys()
            while (keys.hasNext()) {
                val fileName = keys.next()
                if (fileName.endsWith(".txt")) {
                    val file = File(cacheDir, fileName)
                    if (!file.exists()) {
                        try {
                            val content = cacheObj.getString(fileName)
                            file.writeText(content)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }
            }
        }

        // ---- Sources ------------------------------------------------------
        // Absent keys mean the backup was made with sources excluded, or is an
        // older backup. Both cases must be silent no-ops. Every block is
        // individually guarded because restoreBackupJson also runs during
        // automatic crash recovery (SelfHealingEngine), where a source failure
        // must never abort library recovery.
        try {
            val browsePrefs = context.getSharedPreferences(
                "lorelight_browse_prefs", Context.MODE_PRIVATE,
            )

            // Novel plugin repos: union, never drop the user's current repos.
            val backupRepos = backupObj.optString("novel_plugin_repos", "[]")
            if (backupRepos.isNotEmpty() && backupRepos != "[]") {
                val current = JSONArray(browsePrefs.getString("repo_urls", "[]") ?: "[]")
                val seen = mutableSetOf<String>()
                val merged = JSONArray()
                for (i in 0 until current.length()) {
                    val url = current.optString(i, "")
                    if (url.isNotEmpty() && seen.add(url)) merged.put(url)
                }
                val incoming = JSONArray(backupRepos)
                for (i in 0 until incoming.length()) {
                    val url = incoming.optString(i, "")
                    if (url.isNotEmpty() && seen.add(url)) merged.put(url)
                }
                browsePrefs.edit().putString("repo_urls", merged.toString()).commit()
            }

            // Installed novel plugins: union keyed on info.id.
            val backupPlugins = backupObj.optString("novel_installed_plugins", "[]")
            if (backupPlugins.isNotEmpty() && backupPlugins != "[]") {
                val current = JSONArray(browsePrefs.getString("installed_plugins", "[]") ?: "[]")
                val seenIds = mutableSetOf<String>()
                val merged = JSONArray()
                for (i in 0 until current.length()) {
                    val o = current.optJSONObject(i) ?: continue
                    val id = o.optJSONObject("info")?.optString("id", "") ?: ""
                    if (id.isNotEmpty()) seenIds.add(id)
                    merged.put(o)
                }
                val incoming = JSONArray(backupPlugins)
                for (i in 0 until incoming.length()) {
                    val o = incoming.optJSONObject(i) ?: continue
                    val id = o.optJSONObject("info")?.optString("id", "") ?: ""
                    if (id.isNotEmpty() && seenIds.add(id)) merged.put(o)
                }
                browsePrefs.edit().putString("installed_plugins", merged.toString()).commit()
            }

            // DEAD-SOURCE FIX.
            //
            // The block above restores only the plugin RECORDS. The plugin
            // itself is a .js file under files/plugins, and nothing ever brought
            // that file back -- so after a restore the source was listed, looked
            // installed, and then failed the instant anything asked it for a
            // chapter, because the engine reads that missing file. That is the
            // "the source that came with the backup doesn't work" bug.
            //
            // Every restored record carries its own download url, so re-fetch
            // any plugin whose file is missing. Anything that cannot be fetched
            // is dropped from the list rather than left behind as a source that
            // exists but can never load; its repo has just been restored above,
            // so it can be reinstalled in one tap.
            try {
                val installedNow = JSONArray(
                    browsePrefs.getString("installed_plugins", "[]") ?: "[]"
                )
                val unavailable = mutableListOf<String>()
                for (i in 0 until installedNow.length()) {
                    val entry = installedNow.optJSONObject(i) ?: continue
                    val info = entry.optJSONObject("info") ?: continue
                    val id = info.optString("id", "")
                    if (id.isEmpty()) continue
                    if (com.lorelight.browse.repo.PluginManager.pluginFile(context, id).exists()) {
                        continue
                    }
                    val url = info.optString("url", "")
                    if (url.isEmpty()) {
                        unavailable.add(id)
                        continue
                    }
                    val pluginInfo = com.lorelight.browse.model.PluginInfo(
                        id = id,
                        name = info.optString("name", id),
                        site = info.optString("site", ""),
                        lang = info.optString("lang", context.getString(R.string.settings_lang_unknown)),
                        version = info.optString("version", "0.0.0"),
                        url = url,
                        iconUrl = info.optString("iconUrl", ""),
                        hasSettings = info.optBoolean("hasSettings", false),
                        hasUpdate = info.optBoolean("hasUpdate", false),
                        repoUrl = info.optString("repoUrl", ""),
                        customJS = info.optString("customJS", "").ifEmpty { null }.takeIf { it != "null" },
                        customCSS = info.optString("customCSS", "").ifEmpty { null }.takeIf { it != "null" }
                    )
                    val ok = runBlocking {
                        runCatching {
                            com.lorelight.browse.repo.PluginManager
                                .installPlugin(context, pluginInfo)
                                .isSuccess
                        }.getOrDefault(false)
                    }
                    if (!ok) unavailable.add(id)
                }
                for (deadId in unavailable) {
                    com.lorelight.browse.repo.PluginStore.remove(context, deadId)
                }
                browsePrefs.edit()
                    .putString("sources_awaiting_reinstall", JSONArray(unavailable).toString())
                    .commit()
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // Manga extension repos: insert through the interactor so the DB
            // and its flows stay consistent. Duplicates are rejected by the
            // repository itself, so a failed Result here is expected.
            val backupStores = backupObj.optString("manga_extension_repos", "[]")
            if (backupStores.isNotEmpty() && backupStores != "[]") {
                val arr = JSONArray(backupStores)
                val addStore = Injekt.get<AddExtensionStore>()
                runBlocking {
                    for (i in 0 until arr.length()) {
                        val url = arr.optString(i, "")
                        if (url.isNotEmpty()) {
                            runCatching { addStore(url) }
                        }
                    }
                }
            }
            // "manga_installed_extensions" is intentionally NOT restored: those
            // are APKs, not data. The key exists as a record of what to
            // reinstall from the now-restored repos.
        } catch (e: Exception) {
            // Best effort: library data has already landed and must not be
            // rolled back because a repo insert failed.
            e.printStackTrace()
        }

        return true
    } catch (e: Exception) {
        e.printStackTrace()
        return false
    }
}
