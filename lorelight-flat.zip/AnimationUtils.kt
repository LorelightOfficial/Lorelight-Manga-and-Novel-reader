package com.lorelight.ui.animation

import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer

/**
 * Shimmer effect for loading placeholders. Apply to any Box/placeholder.
 * Usage: Modifier.shimmer()
 */
fun Modifier.shimmer(): Modifier = composed {
    // Motion policy (Settings > Appearance > Motion) can switch the loop off.
    // A shimmer is the app's single most persistent animation - it runs for as
    // long as anything is loading - so reduced motion gets a still highlight
    // instead. The placeholder still reads as a placeholder.
    val motion = com.lorelight.ui.theme.LocalMotionLevel.current
    if (!motion.allowsLoopingAnimation) {
        return@composed drawWithCache {
            val brush = Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.05f),
                    Color.White.copy(alpha = 0.10f),
                    Color.White.copy(alpha = 0.05f)
                ),
                start = Offset(0f, 0f),
                end = Offset(size.width, size.height)
            )
            onDrawWithContent {
                drawContent()
                drawRect(brush)
            }
        }
    }
    val transition = rememberInfiniteTransition(label = "shimmer")
    val progress by transition.animateFloat(
        initialValue = -1f,
        targetValue = 2f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing)
        ),
        label = "shimmerProgress"
    )
    drawWithCache {
        val width = size.width
        val brush = Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.04f),
                Color.White.copy(alpha = 0.14f),
                Color.White.copy(alpha = 0.04f)
            ),
            start = Offset(width * progress, 0f),
            end = Offset(width * (progress + 1f), size.height)
        )
        onDrawWithContent {
            drawContent()
            drawRect(brush)
        }
    }
}

/**
 * Press-scale feedback for anything clickable.
 * Usage:
 *   val interactionSource = remember { MutableInteractionSource() }
 *   Modifier
 *     .pressScale(interactionSource)
 *     .clickable(interactionSource = interactionSource, indication = null) { ... }
 */
fun Modifier.pressScale(
    interactionSource: MutableInteractionSource,
    pressedScale: Float = 0.96f
): Modifier = composed {
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "pressScale"
    )
    graphicsLayer {
        scaleX = scale
        scaleY = scale
    }
}

/**
 * Entrance stagger animation for lazy list / grid items.
 *
 * Each key animates EXACTLY ONCE, and only within the first 350ms of a fresh
 * list load. Anything that scrolls back into view renders instantly.
 *
 * The previous version reopened a shared window from inside composition every
 * time index 0 was composed. Lazy rows recompose index 0 on every scroll back
 * to the start, so the window kept reopening mid-scroll and nearby items
 * replayed their fade-in from alpha 0 -- books visibly blinking out and back.
 */
private var globalStaggerStartTime = 0L

/**
 * Keys that have already played their entrance. Global on purpose: lazy
 * layouts drop and rebuild item composition constantly, so per-item state
 * cannot be trusted to remember this.
 */
private val staggerRevealedKeys: MutableSet<Any> =
    java.util.Collections.newSetFromMap(java.util.concurrent.ConcurrentHashMap<Any, Boolean>())

/**
 * Lets a screen deliberately replay the entrance, e.g. after a real reload or
 * a filter change. Call from an effect, never during composition.
 */
fun resetStaggerEntrance() {
    staggerRevealedKeys.clear()
    globalStaggerStartTime = 0L
}

@Composable
fun StaggeredItem(
    index: Int,
    key: Any = index,
    animate: Boolean = true,
    content: @Composable () -> Unit
) {
    // Entrance staggers are decorative, and they are the animation people
    // notice most when scrolling a long shelf. Reduced motion draws the list
    // immediately.
    val motion = com.lorelight.ui.theme.LocalMotionLevel.current
    if (!animate || !motion.allowsEntranceStagger) {
        content()
        return
    }

    // Resolved once per key. Recomposition and lazy-layout recycling must not
    // be able to switch the entrance back on -- that is the entire fix.
    val shouldAnimate = remember(key) {
        val now = System.currentTimeMillis()
        if (staggerRevealedKeys.size > 4000) staggerRevealedKeys.clear()
        val firstTimeForThisKey = staggerRevealedKeys.add(key)
        // Only a genuinely new item 0 is allowed to open the window.
        if (index == 0 && firstTimeForThisKey) globalStaggerStartTime = now
        firstTimeForThisKey &&
            index < 12 &&
            globalStaggerStartTime != 0L &&
            (now - globalStaggerStartTime) < 350L
    }

    if (!shouldAnimate) {
        content()
        return
    }

    var visible by remember(key) { mutableStateOf(false) }
    LaunchedEffect(key) {
        kotlinx.coroutines.delay((index * 35).toLong())
        visible = true
    }

    val alpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(300, easing = FastOutSlowInEasing),
        label = "staggerAlpha"
    )
    val translationY by animateFloatAsState(
        targetValue = if (visible) 0f else 40f,
        animationSpec = tween(300, easing = FastOutSlowInEasing),
        label = "staggerY"
    )

    Box(
        modifier = Modifier.graphicsLayer {
            this.alpha = alpha
            this.translationY = translationY
        }
    ) {
        content()
    }
}
