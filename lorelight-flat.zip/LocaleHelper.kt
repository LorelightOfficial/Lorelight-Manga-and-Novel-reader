package eu.kanade.tachiyomi.util.system

import java.util.Locale

/**
 * Small helper around language codes used by the source/extension language lists.
 */
object LocaleHelper {

    /**
     * Languages enabled by default: "all", English, and the current device language.
     */
    fun getDefaultEnabledLanguages(): Set<String> {
        return setOf("all", "en", Locale.getDefault().language)
    }

    /**
     * Orders language codes by their localized display name.
     */
    val comparator = Comparator<String> { a, b ->
        getDisplayName(a).compareTo(getDisplayName(b))
    }

    /**
     * Returns the localized display name for a language code, or a sensible
     * fallback if it can't be resolved.
     */
    fun getDisplayName(lang: String?): String {
        return when (lang) {
            null, "" -> ""
            "all" -> "All"
            else -> {
                val locale = getLocale(lang)
                locale.getDisplayName(locale).replaceFirstChar { it.uppercase(locale) }
            }
        }
    }

    private fun getLocale(lang: String): Locale {
        val parts = lang.split("-", "_")
        return when (parts.size) {
            2 -> Locale(parts[0], parts[1])
            3 -> Locale(parts[0], parts[1], parts[2])
            else -> Locale(lang)
        }
    }
}
