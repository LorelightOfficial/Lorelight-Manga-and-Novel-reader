# Launcher shortcuts removed

Removed Resume reading, Search sources, and Downloads from Lorelight's app-icon long-press menu by removing their static shortcut registration and definitions. Deleted their three dedicated icons and six unused label strings.

The normal launcher icon, in-app reading/search/download features, deep links, notification actions, and all previous source changes are preserved. No home-screen widget has been implemented in this revision.

Validation: manifest and strings parse successfully, no shortcut resource references or dynamic shortcut publishers remain in the app source, normal launcher/deep-link declarations remain, and all previous source code is byte-for-byte unchanged by this patch.

This is source-level validation only, not an APK build or device test. The existing environment limitation remains: no Android SDK/Gradle installation and the original project lacks gradle/wrapper/gradle-wrapper.jar.

Device check: after building and installing this update, long-press the Lorelight app icon and verify those three app-specific entries are absent. Android/launcher items such as App info, Uninstall, or Widgets are controlled by the launcher and are not removed. A launcher can cache old entries; separately pinned copies of old shortcuts may need to be removed manually. Do not clear app data merely to refresh launcher entries.

## Widget recommendations — not implemented

- Current read (4x2): cover, title, current chapter and reading progress, with one-tap continuation. Unlike a static shortcut, it shows useful live reading context.
- Mini bookshelf (4x2 or 4x3): a small set of recent or chosen novel/manga covers that open the selected title.
- New chapters (4x2): recently updated followed titles and new-chapter counts, linked to the existing update review screen.
- Listening (4x1 or 4x2): current novel/chapter and TTS play/pause plus chapter navigation, coordinated with the existing playback service.

Suggested first release: Current read and Mini bookshelf. Use resizable layouts, readable large-text states, clear empty/loading states, theme-aware surfaces, and static decorative artwork rather than continuously animated widgets.
