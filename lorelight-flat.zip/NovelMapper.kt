package com.lorelight.browse.model

import android.net.Uri
import com.lorelight.data.model.Novel

/**
 * Encodes a plugin chapter path into a URL the reader understands.
 * CrawlerEngine.extractChapterText routes "lnplugin://" URLs to
 * JSPluginEngine.parseChapter for the actual chapter text.
 */
fun pluginChapterUrl(pluginId: String, chapterPath: String): String =
    "lnplugin://" + pluginId + "/" + Uri.encode(chapterPath, "")

/**
 * Converts a plugin's parsed novel details into the app's Novel model,
 * mirroring how the crawler stores online novels: the cover URL lives in
 * coverImageBase64, isOnline = true, and each chapter is an lnplugin:// URL
 * in chapterUrls (aligned by index with the chapters name list).
 */
fun SourceNovelDetails.toNovel(pluginId: String): Novel {
    val chapterNames = chapters.mapIndexed { index, ch ->
        ch.name.takeIf { it.isNotBlank() } ?: "Chapter ${index + 1}"
    }
    val chapterUrls = chapters.map { pluginChapterUrl(pluginId, it.path) }
    val genreList = genres
        ?.split(",", ";")
        ?.map { it.trim() }
        ?.filter { it.isNotEmpty() }
        ?.takeIf { it.isNotEmpty() }
        ?: listOf("Novel")
    return Novel(
        title = name.ifBlank { "Untitled" },
        currentChapter = chapterNames.firstOrNull() ?: "Chapter 1",
        lastReadTimestamp = 0L,
        author = author?.takeIf { it.isNotBlank() } ?: "Unknown Author",
        status = status?.takeIf { it.isNotBlank() } ?: "Ongoing",
        totalChapters = chapterNames.size,
        genres = genreList,
        description = summary?.takeIf { it.isNotBlank() } ?: "No description available.",
        chapters = chapterNames,
        coverImageBase64 = cover?.takeIf { it.isNotBlank() },
        isOnline = true,
        sourceUrl = path,
        chapterUrls = chapterUrls,
        pluginId = pluginId,
        pluginNovelPath = path
    )
}
