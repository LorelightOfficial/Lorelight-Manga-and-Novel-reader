package com.lorelight.manga.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.compose.AsyncImagePainter
import coil.request.ImageRequest
import com.lorelight.manga.reader.MangaImageLoaderProvider
import com.lorelight.ui.animation.ShimmerBox
import kotlinx.coroutines.delay
import tachiyomi.domain.manga.model.MangaCover

private const val MAX_COVER_RETRIES = 3
private const val COVER_RETRY_BASE_MS = 500L

@Composable
private fun CoverFallback(title: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(8.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.MenuBook,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title.split(" ").firstOrNull() ?: "Manga",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun MangaCoverImage(
    coverUrl: String?,
    sourceId: Long?,
    title: String = "Manga",
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    mangaId: Long = -1L,
    lastModified: Long = 0L,
) {
    if (coverUrl.isNullOrBlank()) {
        CoverFallback(title = title, modifier = modifier)
        return
    }

    val context = LocalContext.current
    val coverLoader = remember(context) { MangaImageLoaderProvider.getCoverImageLoader(context) }

    val mangaCover = remember(coverUrl, sourceId, mangaId, lastModified) {
        MangaCover(
            mangaId = mangaId,
            sourceId = sourceId ?: -1L,
            isMangaFavorite = false,
            url = coverUrl,
            lastModified = lastModified,
        )
    }

    var showShimmer by remember(coverUrl, sourceId) { mutableStateOf(false) }
    LaunchedEffect(coverUrl, sourceId) {
        delay(120)
        showShimmer = true
    }

    val coverAttempt = remember(coverUrl, sourceId) { mutableStateOf(0) }
    var state by remember(coverUrl, sourceId) { mutableStateOf<AsyncImagePainter.State>(AsyncImagePainter.State.Empty) }

    val imageRequest = remember(mangaCover, coverAttempt.value) {
        ImageRequest.Builder(context)
            .data(mangaCover)
            .placeholderMemoryCacheKey("$coverUrl;$lastModified")
            .crossfade(true)
            .build()
    }

    Box(modifier = modifier) {
        AsyncImage(
            model = imageRequest,
            imageLoader = coverLoader,
            contentDescription = "Manga cover",
            contentScale = contentScale,
            modifier = Modifier.fillMaxSize(),
            onState = { st -> state = st }
        )

        when {
            state is AsyncImagePainter.State.Success ||
                (state is AsyncImagePainter.State.Loading && (state as AsyncImagePainter.State.Loading).painter != null) -> {
                // Image or cached placeholder active: no overlay needed
            }
            state is AsyncImagePainter.State.Error && coverAttempt.value < MAX_COVER_RETRIES -> {
                if (showShimmer) {
                    ShimmerBox(modifier = Modifier.matchParentSize(), cornerRadius = 0)
                }
                LaunchedEffect(coverUrl, sourceId, coverAttempt.value) {
                    delay(COVER_RETRY_BASE_MS * (1L shl coverAttempt.value))
                    coverAttempt.value = coverAttempt.value + 1
                }
            }
            state is AsyncImagePainter.State.Error -> {
                CoverFallback(title, Modifier.matchParentSize())
            }
            else -> {
                if (showShimmer) {
                    ShimmerBox(modifier = Modifier.matchParentSize(), cornerRadius = 0)
                }
            }
        }
    }
}
