/*
 * =============================================================================
 * CompanionPropArt.kt - the twenty props, drawn.
 * Package: com.lorelight.companion
 *
 * WHERE THESE LAND
 *
 * Every function here is handed the body's centre and radius and draws in that
 * frame. The face landmark constants below are copied from CelestialBody's own
 * drawFace, so spectacles sit on the eyes and a moustache sits under the nose
 * rather than near them. If that file ever moves an eye, change these too --
 * they are the only coupling between the two files and there is no way to
 * share them without editing CelestialBody, which is off limits.
 *
 * WHY IT IS ALL BLOCKS AND LINES
 *
 * The app ships zero image assets and that is not going to change for a hat.
 * Every prop is rectangles, circles, arcs and lines. The stepped-block look of
 * the spectacles and the hats is deliberate rather than a limitation: it reads
 * as a knowingly chunky prop instead of a bad drawing.
 *
 * ALLOCATION
 *
 * Offset, Size, Color and CornerRadius are inline value classes, so the vast
 * majority of this file allocates nothing per frame. Stroke is a real object;
 * the few functions that need one build it once at the top and reuse it.
 *
 * `appear` is the entry/exit envelope, 0 to 1. Props use it differently on
 * purpose -- glasses drop in from above, arms grow out of the body, a halo
 * fades. A prop that only faded would look pasted on.
 * =============================================================================
 */
package com.lorelight.companion

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.abs
import kotlin.math.sin

/* =========================================================================
 * FACE LANDMARKS - mirrored from CelestialBody.drawFace, all as fractions
 * of the body radius.
 * =======================================================================*/

private const val EYE_DX = 0.36f      // eye centre, horizontal offset
private const val EYE_Y = -0.10f      // eye centre, vertical offset
private const val MOUTH_Y = 0.34f     // mouth line
private const val JAW_Y = 0.62f       // bottom of the face area

/* =========================================================================
 * THE DISPATCHER
 * =======================================================================*/

/**
 * Draws one prop over the body.
 *
 * @param center body centre, which is the centre of the puck box
 * @param r body radius
 * @param appear entry/exit envelope, 0..1
 * @param seconds elapsed time, for props that keep moving while held
 * @param ink the near-black outline colour; must contrast with the body
 * @param glow the accent colour, used for flame, glass and halos
 */
internal fun DrawScope.drawCompanionProp(
    prop: CompanionProp,
    center: Offset,
    r: Float,
    appear: Float,
    seconds: Float,
    ink: Color,
    glow: Color
) {
    if (appear <= 0.002f) return

    when (prop) {
        CompanionProp.SPECTACLES -> drawSpectacles(center, r, appear, ink, glow)
        CompanionProp.SUNGLASSES -> drawSunglasses(center, r, appear, ink, glow)
        CompanionProp.LANTERN -> drawLantern(center, r, appear, seconds, ink, glow)
    }
}

/* =========================================================================
 * WORN ON THE FACE
 * =======================================================================*/

private fun DrawScope.drawSpectacles(c: Offset, r: Float, a: Float, ink: Color, glow: Color) {
    // Drops in from above rather than fading: you see them land.
    val drop = (1f - a) * r * 1.60f
    val eyeY = c.y + EYE_Y * r - drop
    val dx = EYE_DX * r
    val half = r * 0.30f
    val bar = r * 0.085f
    val paint = ink.copy(alpha = a)

    for (side in -1..1 step 2) {
        val ex = c.x + side * dx
        // A square ring built from four blocks. Stepped on purpose.
        drawRect(paint, Offset(ex - half, eyeY - half), Size(half * 2f, bar))
        drawRect(paint, Offset(ex - half, eyeY + half - bar), Size(half * 2f, bar))
        drawRect(paint, Offset(ex - half, eyeY - half), Size(bar, half * 2f))
        drawRect(paint, Offset(ex + half - bar, eyeY - half), Size(bar, half * 2f))
        // A whisper of glass so the lens is not a hole.
        drawRect(
            glow.copy(alpha = a * 0.18f),
            Offset(ex - half + bar, eyeY - half + bar),
            Size((half - bar) * 2f, (half - bar) * 2f)
        )
    }

    // Bridge across the nose, and a temple bar out to each side.
    drawRect(paint, Offset(c.x - dx + half - bar, eyeY - bar * 0.5f), Size((dx - half) * 2f + bar * 2f, bar))
    drawRect(paint, Offset(c.x - dx - half - r * 0.28f, eyeY - bar * 0.5f), Size(r * 0.28f, bar))
    drawRect(paint, Offset(c.x + dx + half, eyeY - bar * 0.5f), Size(r * 0.28f, bar))
}

private fun DrawScope.drawSunglasses(c: Offset, r: Float, a: Float, ink: Color, glow: Color) {
    val drop = (1f - a) * r * 1.9f
    val eyeY = c.y + EYE_Y * r - drop
    val dx = EYE_DX * r
    val lensW = r * 0.62f
    val lensH = r * 0.46f
    val bar = r * 0.08f
    val paint = ink.copy(alpha = a)

    for (side in -1..1 step 2) {
        val ex = c.x + side * dx
        drawRoundRect(
            paint,
            Offset(ex - lensW / 2f, eyeY - lensH / 2f),
            Size(lensW, lensH),
            CornerRadius(r * 0.10f)
        )
        // One highlight streak. Without it the lenses read as two dark holes.
        // Struck in the accent rather than white: no hardcoded colours here,
        // and the accent is bright enough in both schemes to read as a glint.
        drawLine(
            glow.copy(alpha = a * 0.42f),
            Offset(ex - lensW * 0.28f, eyeY + lensH * 0.16f),
            Offset(ex + lensW * 0.10f, eyeY - lensH * 0.20f),
            r * 0.05f,
            StrokeCap.Round
        )
    }
    drawRect(paint, Offset(c.x - dx, eyeY - bar * 0.5f), Size(dx * 2f, bar))
    drawRect(paint, Offset(c.x - dx - lensW / 2f - r * 0.26f, eyeY - bar * 0.5f), Size(r * 0.26f, bar))
    drawRect(paint, Offset(c.x + dx + lensW / 2f, eyeY - bar * 0.5f), Size(r * 0.26f, bar))
}

/* =========================================================================
 * WORN ON THE HEAD
 * =======================================================================*/

/* =========================================================================
 * BESIDE AND ABOVE
 * =======================================================================*/

private fun DrawScope.drawLantern(c: Offset, r: Float, a: Float, s: Float, ink: Color, glow: Color) {
    val paint = ink.copy(alpha = a)
    val hangX = c.x + r * 1.28f
    val topY = c.y - r * 0.70f
    // A slow sway, as if it were actually hanging from something.
    val sway = sin(s * 1.5f) * r * 0.07f * a
    val bodyY = topY + r * 0.60f * a
    val bx = hangX + sway

    drawLine(paint, Offset(hangX, topY - r * 0.22f), Offset(bx, bodyY - r * 0.14f), r * 0.045f, StrokeCap.Round)
    drawCircle(paint, r * 0.075f, Offset(bx, bodyY - r * 0.16f), style = Stroke(width = r * 0.035f))

    val w = r * 0.34f * a
    val h = r * 0.46f * a
    // Warm spill first, so the glass looks lit rather than painted.
    val flicker = 0.82f + 0.18f * sin(s * 11.3f) * sin(s * 4.1f)
    drawCircle(glow.copy(alpha = a * 0.20f * flicker), w * 2.6f, Offset(bx, bodyY + h * 0.5f))
    drawRoundRect(
        glow.copy(alpha = a * 0.55f * flicker),
        Offset(bx - w / 2f, bodyY),
        Size(w, h),
        CornerRadius(r * 0.06f)
    )
    // Cage: top plate, bottom plate, two uprights.
    drawRect(paint, Offset(bx - w * 0.62f, bodyY - r * 0.05f), Size(w * 1.24f, r * 0.06f))
    drawRect(paint, Offset(bx - w * 0.62f, bodyY + h), Size(w * 1.24f, r * 0.06f))
    drawLine(paint, Offset(bx - w / 2f, bodyY), Offset(bx - w / 2f, bodyY + h), r * 0.035f)
    drawLine(paint, Offset(bx + w / 2f, bodyY), Offset(bx + w / 2f, bodyY + h), r * 0.035f)
    // The flame itself: two stacked circles, the upper one jittering.
    val fy = bodyY + h * 0.62f
    drawCircle(glow.copy(alpha = a * 0.95f), w * 0.26f * flicker, Offset(bx, fy))
    drawCircle(glow.copy(alpha = a * 0.70f), w * 0.17f * flicker, Offset(bx, fy - w * 0.26f * flicker))
}

