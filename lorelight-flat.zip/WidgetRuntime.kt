package com.lorelight.widget

import android.app.Application
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.work.*
import com.lorelight.data.local.AppSettingsSignal
import com.lorelight.data.local.ReadingProgressSignal
import com.lorelight.data.repository.LibraryRepository
import com.lorelight.tts.TtsPlaybackManager
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** No service, clock loop, or polling while no widgets are installed. */
internal object WidgetRuntime {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val requests = Channel<Unit>(Channel.CONFLATED)
    private val renderLock = Mutex()
    private var observer: Job? = null
    private var renderer: Job? = null
    private var chapterObserver: Job? = null
    private var watchedId: String? = null
    private var app: Context? = null
    private var lifecycleRegistered = false
    private val preferenceListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> app?.let { request(it) } }
    private val preferenceFiles = listOf("reader_prefs", "lorelight_reading_modes", "lorelight_widgets")

    fun ids(context: Context, provider: Class<out AppWidgetProvider>): IntArray =
        AppWidgetManager.getInstance(context).getAppWidgetIds(ComponentName(context, provider))
    fun hasWidgets(context: Context): Boolean =
        ids(context, ContinueReadingWidget::class.java).isNotEmpty() || ids(context, MiniBookshelfWidget::class.java).isNotEmpty()

    @Synchronized
    @OptIn(ExperimentalCoroutinesApi::class)
    fun start(context: Context) {
        val c = context.applicationContext
        if (!hasWidgets(c) || observer?.isActive == true) return
        app = c
        preferenceFiles.forEach { c.getSharedPreferences(it, Context.MODE_PRIVATE).registerOnSharedPreferenceChangeListener(preferenceListener) }
        renderer = scope.launch {
            for (ignored in requests) {
                try { refresh(c) } catch (e: CancellationException) { throw e }
                catch (e: Exception) { Log.w("LorelightWidgets", "Widget refresh failed", e) }
                delay(750) // Conflate page turns; never restart work for every sentence.
            }
        }
        observer = scope.launch {
            merge(
                ReadingProgressSignal.version.map { Unit }, AppSettingsSignal.version.map { Unit },
                TtsPlaybackManager.activeNovel.map { Unit }, TtsPlaybackManager.activeChapterIndex.map { Unit },
                TtsPlaybackManager.chapters.map { Unit }, TtsPlaybackManager.isPlaying.map { Unit },
                TtsPlaybackManager.sessionActive.map { Unit }, TtsPlaybackManager.isFetchingChapter.map { Unit }
            ).collect { requests.trySend(Unit) }
        }
        if (!lifecycleRegistered && c is Application) {
            lifecycleRegistered = true
            c.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
                override fun onActivityStopped(activity: Activity) { request(c); preloadCovers(c) }
                override fun onActivityCreated(a: Activity, b: Bundle?) {}
                override fun onActivityStarted(a: Activity) {}
                override fun onActivityResumed(a: Activity) {}
                override fun onActivityPaused(a: Activity) {}
                override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
                override fun onActivityDestroyed(a: Activity) {}
            })
        }
        requests.trySend(Unit)
    }
    fun request(context: Context) {
        if (!hasWidgets(context)) return
        start(context)
        requests.trySend(Unit)
    }
    @Synchronized fun stopIfUnused(context: Context) {
        if (hasWidgets(context)) return
        observer?.cancel(); observer = null
        renderer?.cancel(); renderer = null
        chapterObserver?.cancel(); chapterObserver = null; watchedId = null
        preferenceFiles.forEach { context.getSharedPreferences(it, Context.MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(preferenceListener) }
        WorkManager.getInstance(context).cancelUniqueWork("lorelight_widget_covers")
        WidgetCovers.clear()
    }
    suspend fun refresh(context: Context) = renderLock.withLock {
        if (!hasWidgets(context)) return@withLock
        val library = LibraryRepository.loadLibrary(context)
        if (!LibraryRepository.isHealthy()) return@withLock // Never replace good content with a failed DB read.
        val resume = WidgetState.resume(context, library)
        if (watchedId != resume.novel?.id) {
            chapterObserver?.cancel()
            watchedId = resume.novel?.id
            chapterObserver = watchedId?.let { id -> scope.launch {
                LibraryRepository.observeChapterState(context, id).collect { requests.trySend(Unit) }
            } }
        }
        val manager = AppWidgetManager.getInstance(context)
        for (id in ids(context, ContinueReadingWidget::class.java)) {
            manager.updateAppWidget(id, WidgetViews.continueReading(context, id, resume))
        }
        for (id in ids(context, MiniBookshelfWidget::class.java)) {
            manager.updateAppWidget(id, WidgetViews.bookshelf(context, id, library))
        }
    }
    fun preloadCovers(context: Context) {
        if (!hasWidgets(context)) return
        WorkManager.getInstance(context).enqueueUniqueWork("lorelight_widget_covers", ExistingWorkPolicy.KEEP,
            OneTimeWorkRequestBuilder<WidgetCoverWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build())
    }
}

abstract class LorelightWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        WidgetRuntime.start(context)
        val pending = goAsync()
        WidgetRuntime.scope.launch {
            try { withTimeout(8000) { WidgetRuntime.refresh(context.applicationContext) } }
            catch (e: Exception) { Log.w("LorelightWidgets", "Initial widget update deferred", e) }
            finally { pending.finish() }
        }
        WidgetRuntime.preloadCovers(context)
    }
    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, id: Int, options: Bundle) {
        onUpdate(context, manager, intArrayOf(id))
    }
    override fun onEnabled(context: Context) { WidgetRuntime.request(context) }
    override fun onDisabled(context: Context) { WidgetRuntime.stopIfUnused(context) }
    override fun onDeleted(context: Context, ids: IntArray) { ids.forEach { WidgetPreferences.delete(context, it) } }
    override fun onRestored(context: Context, oldIds: IntArray, newIds: IntArray) {
        oldIds.zip(newIds).forEach { (old, new) ->
            WidgetPreferences.save(context, new, WidgetPreferences.load(context, old)); WidgetPreferences.delete(context, old)
        }
        WidgetRuntime.request(context)
    }
}
class ContinueReadingWidget : LorelightWidgetProvider()
class MiniBookshelfWidget : LorelightWidgetProvider()

class WidgetCoverWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        if (!WidgetRuntime.hasWidgets(applicationContext)) return Result.success()
        return try {
            withContext(Dispatchers.IO) {
                val library = LibraryRepository.loadLibrary(applicationContext)
                val resume = WidgetState.resume(applicationContext, library).novel
                val books = WidgetRuntime.ids(applicationContext, MiniBookshelfWidget::class.java).flatMap {
                    WidgetViews.visibleShelfEntries(applicationContext, it, library)
                }
                WidgetCovers.prefetch(applicationContext, (listOfNotNull(resume) + books).distinctBy { it.id }.take(16))
                WidgetRuntime.refresh(applicationContext)
            }
            Result.success()
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { Result.failure() }
    }
}
