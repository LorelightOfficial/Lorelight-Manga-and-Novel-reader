package com.lorelight.data.model

import androidx.compose.runtime.Immutable
import org.json.JSONArray
import org.json.JSONObject

@Immutable
data class Novel(
    val title: String,
    val currentChapter: String,
    val lastReadTimestamp: Long,
    val author: String = "Unknown Author",
    val status: String = "Ongoing",
    val totalChapters: Int = 100,
    val language: String = "English",
    val genres: List<String> = listOf("Fantasy", "Adventure"),
    val description: String = "No description available.",
    val chapters: List<String> = (1..100).map { "Chapter $it" },
    val coverImageBase64: String? = null,
    val isOnline: Boolean = false,
    val sourceUrl: String? = null,
    val chapterUrls: List<String> = emptyList(),
    val chapterNumbers: List<Float> = emptyList(),
    val currentParagraphIndex: Int = 0,
    val currentMangaPageIndex: Int = 0,
    val completedChapters: List<String> = emptyList(),
    val currentScrollOffset: Int = 0,
    val currentWordIndex: Int = 0,
    val isFavorite: Boolean = false,
    val categories: List<String> = emptyList(),
    val readingStatus: String = "Reading", // Reading, Completed, On Hold, Dropped, Plan To Read
    val dateAdded: Long = System.currentTimeMillis(),
    val dateModified: Long = System.currentTimeMillis(),
    val lastCheckedTimestamp: Long = 0L,
    val pluginId: String? = null,
    val pluginNovelPath: String? = null,
    val id: String = java.util.UUID.randomUUID().toString(),
    // RESUME REDESIGN. The durable answer to "where was I".
    //
    // currentChapter is a NAME, and a name is not an identity. Sources re-title
    // their chapter lists, the list shifts when new chapters land at the top,
    // and names repeat outright. Every resume path used to do
    // indexOf(currentChapter), which either landed on the wrong chapter (the
    // details page listing 189 when you were on 234) or missed entirely and
    // fell back to 0 (the player opening "Chapter 1").
    //
    // This index is written by whoever actually turned the page, so it cannot
    // drift. -1 means nothing has been recorded yet.
    val currentChapterIndex: Int = -1
)

fun Novel.toJSONObject(): JSONObject {
    val obj = JSONObject()
    obj.put("title", title)
    obj.put("currentChapter", currentChapter)
    obj.put("currentChapterIndex", currentChapterIndex)
    obj.put("lastReadTimestamp", lastReadTimestamp)
    obj.put("author", author)
    obj.put("status", status)
    obj.put("totalChapters", totalChapters)
    obj.put("language", language)
    
    val genresArr = JSONArray()
    genres.forEach { genresArr.put(it) }
    obj.put("genres", genresArr)
    
    obj.put("description", description)
    
    val chaptersArr = JSONArray()
    chapters.forEach { chaptersArr.put(it) }
    obj.put("chapters", chaptersArr)
    
    obj.put("coverImageBase64", coverImageBase64 ?: JSONObject.NULL)
    obj.put("isOnline", isOnline)
    obj.put("sourceUrl", sourceUrl ?: JSONObject.NULL)
    val chapterUrlsArr = JSONArray()
    chapterUrls.forEach { chapterUrlsArr.put(it) }
    obj.put("chapterUrls", chapterUrlsArr)
    val chapterNumbersArr = JSONArray()
    chapterNumbers.forEach { chapterNumbersArr.put(it.toDouble()) }
    obj.put("chapterNumbers", chapterNumbersArr)
    
    obj.put("currentParagraphIndex", currentParagraphIndex)
    obj.put("currentMangaPageIndex", currentMangaPageIndex)
    val completedChaptersArr = JSONArray()
    completedChapters.forEach { completedChaptersArr.put(it) }
    obj.put("completedChapters", completedChaptersArr)
    
    obj.put("currentScrollOffset", currentScrollOffset)
    obj.put("currentWordIndex", currentWordIndex)
    obj.put("isFavorite", isFavorite)
    val catArr = JSONArray()
    categories.forEach { catArr.put(it) }
    obj.put("categories", catArr)
    obj.put("readingStatus", readingStatus)
    obj.put("dateAdded", dateAdded)
    obj.put("dateModified", dateModified)
    obj.put("lastCheckedTimestamp", lastCheckedTimestamp)
    obj.put("pluginId", pluginId ?: JSONObject.NULL)
    obj.put("pluginNovelPath", pluginNovelPath ?: JSONObject.NULL)
    obj.put("id", id)
    
    return obj
}

fun JSONObject.toNovel(): Novel {
    val genresList = mutableListOf<String>()
    val genresArr = optJSONArray("genres")
    if (genresArr != null) {
        for (i in 0 until genresArr.length()) {
            genresList.add(genresArr.optString(i, ""))
        }
    } else {
        genresList.addAll(listOf("Fantasy", "Adventure"))
    }
    
    val chaptersList = mutableListOf<String>()
    val chaptersArr = optJSONArray("chapters")
    if (chaptersArr != null) {
        for (i in 0 until chaptersArr.length()) {
            val valChapter = chaptersArr.optString(i)
            if (!valChapter.isNullOrEmpty()) {
                chaptersList.add(valChapter)
            }
        }
    } else {
        chaptersList.addAll((1..100).map { "Chapter $it" })
    }
    
    val cover = optString("coverImageBase64", null)
    val coverVal = if (cover == "null" || cover.isNullOrEmpty()) null else cover
    
    val chapterUrlsList = mutableListOf<String>()
    val chapterUrlsArr = optJSONArray("chapterUrls")
    if (chapterUrlsArr != null) {
        for (i in 0 until chapterUrlsArr.length()) {
            val valUrl = chapterUrlsArr.optString(i)
            if (!valUrl.isNullOrEmpty()) {
                chapterUrlsList.add(valUrl)
            }
        }
    }

    val chapterNumbersList = mutableListOf<Float>()
    val chapterNumbersArr = optJSONArray("chapterNumbers")
    if (chapterNumbersArr != null) {
        for (i in 0 until chapterNumbersArr.length()) {
            val valNum = chapterNumbersArr.optDouble(i, -1.0).toFloat()
            chapterNumbersList.add(valNum)
        }
    }

    val completedChaptersList = mutableListOf<String>()
    val completedChaptersArr = optJSONArray("completedChapters")
    if (completedChaptersArr != null) {
        for (i in 0 until completedChaptersArr.length()) {
            val valCh = completedChaptersArr.optString(i)
            if (!valCh.isNullOrEmpty()) {
                completedChaptersList.add(valCh)
            }
        }
    }

    val currentScrollOffset = optInt("currentScrollOffset", 0)
    val currentWordIndex = optInt("currentWordIndex", 0)

    val isFavorite = optBoolean("isFavorite", false)
    val categoriesList = mutableListOf<String>()
    val categoriesArr = optJSONArray("categories")
    if (categoriesArr != null) {
        for (i in 0 until categoriesArr.length()) {
            categoriesList.add(categoriesArr.optString(i, ""))
        }
    }
    val readingStatus = optString("readingStatus", "Reading")
    val dateAdded = optLong("dateAdded", System.currentTimeMillis())
    val dateModified = optLong("dateModified", System.currentTimeMillis())
    val loadedId = optString("id", "")
    val id = if (loadedId.isNotEmpty()) loadedId else java.util.UUID.nameUUIDFromBytes(("${optString("title", "Unknown")}-${optString("author", "Unknown Author")}").toByteArray()).toString()

    return Novel(
        title = optString("title", "Unknown"),
        currentChapter = optString("currentChapter", "Chapter 1"),
        currentChapterIndex = optInt("currentChapterIndex", -1),
        lastReadTimestamp = optLong("lastReadTimestamp", 0L),
        author = optString("author", "Unknown Author"),
        status = optString("status", "Ongoing"),
        totalChapters = optInt("totalChapters", 100),
        language = optString("language", "English"),
        genres = genresList,
        description = optString("description", "No description available."),
        chapters = chaptersList,
        coverImageBase64 = coverVal,
        isOnline = optBoolean("isOnline", false),
        sourceUrl = optString("sourceUrl", null).takeIf { it != "null" },
        chapterUrls = chapterUrlsList,
        chapterNumbers = chapterNumbersList,
        currentParagraphIndex = optInt("currentParagraphIndex", 0),
        currentMangaPageIndex = optInt("currentMangaPageIndex", optInt("currentParagraphIndex", 0)),
        completedChapters = completedChaptersList,
        currentScrollOffset = currentScrollOffset,
        currentWordIndex = currentWordIndex,
        isFavorite = isFavorite,
        categories = categoriesList,
        readingStatus = readingStatus,
        dateAdded = dateAdded,
        dateModified = dateModified,
        lastCheckedTimestamp = optLong("lastCheckedTimestamp", 0L),
        pluginId = optString("pluginId", null).takeIf { !it.isNullOrEmpty() && it != "null" },
        pluginNovelPath = optString("pluginNovelPath", null).takeIf { !it.isNullOrEmpty() && it != "null" },
        id = id
    )
}
