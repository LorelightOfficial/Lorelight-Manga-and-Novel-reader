package com.lorelight.work

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.lorelight.data.local.AppPrefs
import com.lorelight.service.NewChaptersManager
import java.util.concurrent.TimeUnit

class LibraryUpdateWorker(
    private val appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val prefs = AppPrefs.get(appContext)
        val enabled = prefs.getBoolean("lib_update_enabled", false)
        if (!enabled) {
            return Result.success()
        }

        try {
            NewChaptersManager.scanLibrary(appContext)
        } catch (e: Exception) {
            e.printStackTrace()
            return Result.retry()
        }

        return Result.success()
    }
}

object LibraryUpdateScheduler {
    private const val WORK_NAME = "lorelight_library_update"

    fun schedule(context: Context, hours: Long, wifiOnly: Boolean, chargingOnly: Boolean) {
        val networkType = if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(networkType)
            .setRequiresCharging(chargingOnly)
            .build()

        val request = PeriodicWorkRequestBuilder<LibraryUpdateWorker>(hours, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    }
}
