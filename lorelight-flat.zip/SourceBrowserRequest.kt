/**
 * =============================================================================
 * SOURCE BROWSER REQUEST
 *
 * One in-app browser serves both halves of the app, and in both halves the
 * point is the same: whatever you add has to stay attached to the source you
 * were browsing. A manga added from a manga source must open in the manga
 * reader through that extension. A novel added from a plugin site must pull
 * its chapters through that plugin.
 *
 * That only works if the browser knows WHICH source opened it. So the origin
 * travels with the request, instead of being guessed from the URL afterwards.
 * Guessing from the URL is what would break: two installed sources can share
 * a host, and a host can be reached by several spellings.
 *
 * Single-slot mutable object rather than threaded state, because the buttons
 * that open the browser live inside LazyColumn item scopes, several nesting
 * levels below the screen that hosts the dialog. Same pattern the app already
 * uses for AppSettingsSignal.
 * =============================================================================
 */
package com.lorelight.browse.ui

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.lorelight.data.model.Novel

/** Which source opened the browser, and therefore how an add is resolved. */
sealed class BrowserOrigin {

    /** A manga extension. Chapters come from the installed source. */
    class Manga(val sourceId: Long, val baseUrl: String) : BrowserOrigin()

    /** A novel plugin. Chapters come from the plugin's own parser. */
    class NovelPlugin(val pluginId: String, val site: String) : BrowserOrigin()

    /** No source behind it: fall back to the generic crawler. */
    object Crawler : BrowserOrigin()
}

/** What to open, what to call it, and who opened it. */
class BrowserTarget(
    val url: String,
    val siteName: String,
    val origin: BrowserOrigin
)

/**
 * Single-slot handoff between a source row and the browser host.
 *
 * Each host only renders the origin it owns, so the novel host and the manga
 * host can both be in composition without ever opening two dialogs at once.
 */
object SourceBrowserRequest {
    var target by mutableStateOf<BrowserTarget?>(null)
}

/**
 * Turns the address bar URL into the path a source parser expects.
 *
 * Sources are given paths relative to their own base ("/manga/foo"), not the
 * absolute URL the WebView is showing. Comparison ignores scheme and "www."
 * because a site reached as https://www.x.com and a base recorded as
 * http://x.com are the same place, and a mismatch here would silently send
 * the full URL to a parser that expects a path.
 */
fun sourceRelativePath(url: String, base: String): String {
    val cleanUrl = url.trim()
    if (cleanUrl.isEmpty()) return ""

    val cleanBase = base.trim().trimEnd('/')
    if (cleanBase.isNotEmpty()) {
        val bareUrl = stripHostNoise(cleanUrl)
        val bareBase = stripHostNoise(cleanBase)
        if (bareBase.isNotEmpty() && bareUrl.startsWith(bareBase, true)) {
            val rest = bareUrl.substring(bareBase.length)
            return if (rest.startsWith("/")) rest else "/" + rest
        }
    }

    // Different host, or the source never told us its base. Keep the path and
    // query, which is the part every parser actually reads.
    val parsed = Uri.parse(cleanUrl)
    val path = parsed.path
    if (path.isNullOrEmpty()) return "/"
    val query = parsed.query
    return if (query.isNullOrEmpty()) path else path + "?" + query
}

private fun stripHostNoise(value: String): String =
    value.removePrefix("https://")
        .removePrefix("http://")
        .removePrefix("www.")

/**
 * Saves whatever the browser resolved, and returns a short message for the
 * button to show.
 *
 * Two genuinely different cases, which is why this is not one call:
 *
 * - The source already handed over the whole chapter list (a manga extension,
 *   or a novel plugin). There is nothing left to fetch, so it goes straight
 *   into the library still linked to that source.
 *
 * - There was no source, only a web page. The chapter list still has to be
 *   crawled, so it goes in as a husk and the import service fills it in.
 *
 * Sending a source-linked title through the crawler path is the bug this
 * exists to prevent: it would overwrite real source chapters with scraped
 * text and the manga reader would never see it.
 */
fun addBrowserResultToLibrary(context: Context, novel: Novel): String {
    if (novel.chapters.isNotEmpty()) {
        val added = com.lorelight.service.NovelImportManager
            .addSourcedNovel(context, novel)
        com.lorelight.companion.CompanionBus.onLibraryAdd(novel)
        return if (added) novel.title else novel.title + " is already saved"
    }

    com.lorelight.service.NovelImportManager.ensureHuskSaved(context, novel)
    com.lorelight.service.NovelImportService.start(
        context,
        novel.id,
        novel.sourceUrl ?: "",
        novel.title,
        novel.status
    )
    com.lorelight.companion.CompanionBus.onLibraryAdd(novel)
    return novel.title
}
