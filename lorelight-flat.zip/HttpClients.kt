package com.lorelight.network

import android.content.Context
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Single shared OkHttp client for the whole app.
 *
 * Before this existed, six subsystems (crawler, JS bridge, plugin manager,
 * plugin repo, manga extension manager, manga repo) each built their own
 * OkHttpClient, so every one of them carried its own connection pool, thread
 * pool and cookie state - and none of them installed [CloudflareInterceptor],
 * which meant the Cloudflare solver shipped in the app was never used.
 *
 * Everything now shares one client, so:
 *  - connections and threads are pooled once instead of six times,
 *  - a Cloudflare challenge solved for one subsystem is reused by the others,
 *  - timeouts are configured in a single place.
 *
 * Call [init] once from Application.onCreate so the interceptor can be
 * installed. The client still works before that, just without Cloudflare
 * handling.
 */
object HttpClients {

    private const val CONNECT_TIMEOUT_S = 30L
    private const val READ_TIMEOUT_S = 30L

    /**
     * Read timeout only fires when NOTHING arrives for 30s. A server that
     * trickles a few bytes at a time resets it forever, so a stalled page
     * download could hang for the life of the process. mihon caps the whole
     * call at two minutes; this matches that.
     */
    private const val CALL_TIMEOUT_S = 120L

    @Volatile private var appContext: Context? = null
    @Volatile private var cached: OkHttpClient? = null
    @Volatile private var cachedIsCloudflareAware: Boolean = false

    /** Called from Application.onCreate. Safe to call more than once. */
    fun init(context: Context) {
        appContext = context.applicationContext
        NetworkThrottle.init(context)
        synchronized(this) {
            // A client may already have been built before the Application
            // context was known (for example from a WorkManager entry point).
            // Drop it so the next caller gets a Cloudflare-aware client.
            if (cached != null && !cachedIsCloudflareAware) {
                cached = null
            }
        }
    }

    /** True when the shared client has the Cloudflare interceptor installed. */
    fun isCloudflareAware(): Boolean = cachedIsCloudflareAware

    /** The shared client. Created on first use. */
    fun shared(): OkHttpClient {
        cached?.let { return it }
        return synchronized(this) {
            cached ?: build().also { cached = it }
        }
    }

    /**
     * A builder pre-seeded with the shared client's config, including the
     * Cloudflare interceptor and the shared connection pool. Use this when a
     * caller needs one extra setting (for example its own cookie jar) instead
     * of building a brand new client.
     */
    fun sharedBuilder(): OkHttpClient.Builder = shared().newBuilder()

    private fun build(): OkHttpClient {
        // Manga page downloads are serialized by MangaPageLoader's own gate
        // (one at a time, exactly like mihon), so a wide per-host allowance
        // buys nothing there. These limits exist for everything else that
        // shares this client: the crawler, the JS bridge, plugin and repo
        // fetches, which genuinely do fan out.
        val dispatcher = okhttp3.Dispatcher().apply {
            maxRequests = 64
            maxRequestsPerHost = 8
        }
        // Sockets are kept warm far longer than OkHttp's default (5 idle
        // connections). Reading a chapter is a burst of requests to ONE host,
        // and the crawler, JS bridge and repo fetches share this client, so the
        // default pool was being churned constantly -- every eviction costs the
        // next page a fresh DNS lookup and TLS handshake, which on mobile is
        // most of the time a page takes to start arriving. Idle sockets are
        // cheap; handshakes are not.
        val connectionPool = okhttp3.ConnectionPool(12, 5, TimeUnit.MINUTES)
        val builder = OkHttpClient.Builder()
            .dispatcher(dispatcher)
            .connectionPool(connectionPool)
            .followRedirects(true)
            .retryOnConnectionFailure(true)
            .connectTimeout(CONNECT_TIMEOUT_S, TimeUnit.SECONDS)
            .readTimeout(READ_TIMEOUT_S, TimeUnit.SECONDS)
            .callTimeout(CALL_TIMEOUT_S, TimeUnit.SECONDS)
            .addNetworkInterceptor(NetworkThrottle.createNetworkInterceptor())

        val ctx = appContext
        cachedIsCloudflareAware = if (ctx != null) {
            try {
                builder.addInterceptor(CloudflareInterceptor(ctx))
                true
            } catch (e: Throwable) {
                false
            }
        } else {
            false
        }

        return builder.build()
    }
}
