package com.lorelight.companion

import com.lorelight.ui.theme.modeswitch.celestial.CelestialFaceState

// Shared with word reveal; these are new speech beats, not the old talk poses.
const val TALK_CADENCE_SUN_MS = 230L
const val TALK_CADENCE_MOON_MS = 340L

suspend fun CelestialFaceState.playTalk(mood: Mood, speakMs: Long, reduceMotion: Boolean = false) {
    speak(speakMs, if (mood == Mood.SUN) TALK_CADENCE_SUN_MS else TALK_CADENCE_MOON_MS,
        moon = mood == Mood.MOON, reduced = reduceMotion)
}
