package com.lorelight.ui.library

// Split out of LibraryScreen.kt (S4 file-split pass) to keep that file
// under control. Same package on purpose (see navigation/ScreenDestination.kt
// for the same precedent) so every existing call site in HistoryScreen.kt /
// ContinueReadingCard.kt / LibraryScreen.kt keeps working with zero import
// changes. Pure move, no behaviour change.
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.ui.graphics.Shadow
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalDensity
import kotlin.math.absoluteValue
import androidx.compose.ui.window.Dialog
import com.lorelight.R
import com.lorelight.core.getSafeBoolean
import com.lorelight.core.getSafeFloat
import com.lorelight.core.getSafeInt
import com.lorelight.crawler.CrawlerEngine
import com.lorelight.data.model.Novel
import com.lorelight.ui.components.LibraryCoverImage
import com.lorelight.ui.components.NovelCoverImage
import com.lorelight.ui.reader.ReaderViewModel
import com.lorelight.ui.theme.*
import com.lorelight.utils.EpubExtractor
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import androidx.compose.ui.semantics.Role


@Composable
fun AudioControllerCard(
    novel: Novel,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onSkipBackward: () -> Unit,
    onSkipForward: () -> Unit,
    onPrevChapter: () -> Unit,
    onNextChapter: () -> Unit,
    hasPrevChapter: Boolean,
    hasNextChapter: Boolean,
    onStop: () -> Unit,
    onCardClick: () -> Unit
) {
    // PLAIN, matching ContinueReadingCard exactly. This card SWAPS IN for the
    // continue-reading card when playback starts, so the two have to be the
    // same object wearing different controls. When the glass came off that one
    // this was missed, and starting playback made the box visibly change
    // material mid-session -- glare, bloom and L-shaped corner brackets
    // reappearing on a card that had just been flattened.
    //
    // Same radius, same surfaceVariant fill, same hairline outline, no frame.
    val playerCorner = 16.dp
    val playerShape = RoundedCornerShape(playerCorner)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(playerShape)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .border(
                1.dp,
                MaterialTheme.colorScheme.outline.copy(alpha = 0.30f),
                playerShape
            )
            .clickable(role = Role.Button) { onCardClick() }
    ) {
        Box(
            modifier = Modifier.padding(12.dp)
        ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp, 80.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(MaterialTheme.colorScheme.outline),
                contentAlignment = Alignment.Center
            ) {
                LibraryCoverImage(
                    novel = novel,
                    modifier = Modifier.fillMaxSize()
                )
                val importingIds by com.lorelight.service.NovelImportManager.importing.collectAsState()
                val isImporting = importingIds.contains(novel.id) || novel.status == "Importing"
                if (isImporting) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.45f)),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.VolumeUp,
                            contentDescription = "Playing audio",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "NOW PLAYING",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )
                    
                    IconButton(
                        onClick = onStop,
                        modifier = Modifier.size(20.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Stop TTS",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
                
                Text(
                    text = novel.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Text(
                    text = novel.currentChapter,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onPrevChapter,
                        enabled = hasPrevChapter,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.FastRewind,
                            contentDescription = "Prev Chapter",
                            tint = if (hasPrevChapter) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    
                    IconButton(
                        onClick = onSkipBackward,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SkipPrevious,
                            contentDescription = "Prev Sentence",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .clickable(role = Role.Button) { onPlayPause() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    
                    IconButton(
                        onClick = onSkipForward,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SkipNext,
                            contentDescription = "Next Sentence",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    
                    IconButton(
                        onClick = onNextChapter,
                        enabled = hasNextChapter,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.FastForward,
                            contentDescription = "Next Chapter",
                            tint = if (hasNextChapter) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
}


private class ParticleState(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var size: Float,
    var alpha: Float,
    var angle: Float,
    var rotationSpeed: Float,
    var phase: Float,
    val isFirefly: Boolean,
    val layer: Int, // 0 = background, 1 = mid, 2 = foreground
    val speedMultiplier: Float
)

private data class ThemeAnimationConfig(
    val fireflyColor: Color,
    val windColor: Color,
    val windType: String // "leaf", "dust", "petal", "feather", "mist", "wisp", "magical", "ember"
)

private fun getThemeAnimationConfig(themeName: String, primaryColor: Color): ThemeAnimationConfig {
    val normalized = themeName.lowercase()
    return when {
        normalized.contains("forest") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFFAED581), // light green-yellow
            windColor = Color(0xFFC5E1A5),
            windType = "leaf"
        )
        normalized.contains("gold") || normalized.contains("golden") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFFFFE082), // warm gold
            windColor = Color(0xFFFFD54F),
            windType = "dust"
        )
        normalized.contains("pink") || normalized.contains("satin") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFFFF8DA1), // pink rose
            windColor = Color(0xFFFFB0D0),
            windType = "petal"
        )
        normalized.contains("black") || normalized.contains("midnight") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFFFFFFFF), // pure white glow
            windColor = Color(0xFFE5E7EB),
            windType = "feather"
        )
        normalized.contains("ocean") || normalized.contains("blue") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFF81C7F4), // ocean mist cyan
            windColor = Color(0xFFB3E5FC),
            windType = "mist"
        )
        normalized.contains("cyan") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFF80DEEA), // cyan
            windColor = Color(0xFFB2EBF2),
            windType = "wisp"
        )
        normalized.contains("purple") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFFE1BEE7), // violet
            windColor = Color(0xFFD59DFB),
            windType = "magical"
        )
        normalized.contains("blood") || normalized.contains("red") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFFFF5252), // fiery crimson
            windColor = Color(0xFFFA5F70),
            windType = "leaf"
        )
        else -> ThemeAnimationConfig(
            fireflyColor = primaryColor.copy(alpha = 0.85f),
            windColor = primaryColor.copy(alpha = 0.65f),
            windType = "magical"
        )
    }
}

@Composable
fun WindAndFirefliesBackground(
    themeName: String,
    primaryColor: Color,
    modifier: Modifier = Modifier
) {
    val config = remember(themeName, primaryColor) {
        getThemeAnimationConfig(themeName, primaryColor)
    }

    val context = LocalContext.current
    val density = LocalDensity.current
    val particles = remember { mutableStateListOf<ParticleState>() }
    var frameTime by remember { mutableStateOf(0L) }

    // Check system animation / accessibility toggle, and defer to the shared
    // motion policy so Reduced/Battery saver also stop this purely ambient,
    // informationless effect - not just the raw platform toggle.
    val motionLevel = LocalMotionLevel.current
    val removeAnimations = remember(context, motionLevel) {
        if (!motionLevel.allowsAmbientEffects) return@remember true
        try {
            val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? android.view.accessibility.AccessibilityManager
            val systemAnimDisabled = android.provider.Settings.Global.getFloat(
                context.contentResolver,
                android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,
                1.0f
            ) == 0.0f
            systemAnimDisabled || (am?.isEnabled == true && am.isTouchExplorationEnabled)
        } catch (e: Exception) {
            false
        }
    }

    // Lifecycle observer to pause when app is backgrounded
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    var isAppActive by remember { mutableStateOf(true) }
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            isAppActive = (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME || event == androidx.lifecycle.Lifecycle.Event.ON_START)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LaunchedEffect(config, removeAnimations, isAppActive) {
        if (removeAnimations) {
            // Setup static layout for accessibility
            if (particles.isEmpty()) {
                repeat(24) { index ->
                    val isFirefly = index % 3 == 0
                    particles.add(
                        ParticleState(
                            x = kotlin.random.Random.nextFloat(),
                            y = kotlin.random.Random.nextFloat(),
                            vx = 0f,
                            vy = 0f,
                            size = kotlin.random.Random.nextInt(2, 4).toFloat(),
                            alpha = 0.3f + kotlin.random.Random.nextFloat() * 0.4f,
                            angle = kotlin.random.Random.nextInt(0, 360).toFloat(),
                            rotationSpeed = 0f,
                            phase = kotlin.random.Random.nextFloat() * 6.28f,
                            isFirefly = isFirefly,
                            layer = index % 3,
                            speedMultiplier = 1.0f
                        )
                    )
                }
            }
            return@LaunchedEffect
        }

        var lastTime = withFrameMillis { it }
        while (isAppActive) {
            val now = withFrameMillis { it }
            val deltaSec = ((now - lastTime) / 1000f).coerceAtMost(0.1f)
            lastTime = now

            if (particles.isEmpty()) {
                // Initialize 3 layers of parallax depth (10 in background, 8 in midground, 6 in foreground)
                // Layer 0: Background (smaller, slower, more translucent)
                // Layer 1: Midground (standard)
                // Layer 2: Foreground (larger, faster, sharper)
                repeat(10) { i ->
                    val isFirefly = i % 2 == 0
                    particles.add(
                        ParticleState(
                            x = kotlin.random.Random.nextFloat(),
                            y = kotlin.random.Random.nextFloat(),
                            vx = kotlin.random.Random.nextInt(40, 70).toFloat(),
                            vy = kotlin.random.Random.nextInt(-8, 8).toFloat(),
                            size = kotlin.random.Random.nextInt(1, 3).toFloat(),
                            alpha = 0.15f + kotlin.random.Random.nextFloat() * 0.3f,
                            angle = kotlin.random.Random.nextInt(0, 360).toFloat(),
                            rotationSpeed = kotlin.random.Random.nextInt(-30, 30).toFloat(),
                            phase = kotlin.random.Random.nextFloat() * 6.28f,
                            isFirefly = isFirefly,
                            layer = 0,
                            speedMultiplier = 0.5f + kotlin.random.Random.nextFloat() * 0.3f
                        )
                    )
                }

                repeat(8) { i ->
                    val isFirefly = i % 2 != 0
                    particles.add(
                        ParticleState(
                            x = kotlin.random.Random.nextFloat(),
                            y = kotlin.random.Random.nextFloat(),
                            vx = kotlin.random.Random.nextInt(70, 110).toFloat(),
                            vy = kotlin.random.Random.nextInt(-12, 12).toFloat(),
                            size = kotlin.random.Random.nextInt(2, 4).toFloat(),
                            alpha = 0.3f + kotlin.random.Random.nextFloat() * 0.4f,
                            angle = kotlin.random.Random.nextInt(0, 360).toFloat(),
                            rotationSpeed = kotlin.random.Random.nextInt(-50, 50).toFloat(),
                            phase = kotlin.random.Random.nextFloat() * 6.28f,
                            isFirefly = isFirefly,
                            layer = 1,
                            speedMultiplier = 0.9f + kotlin.random.Random.nextFloat() * 0.3f
                        )
                    )
                }

                repeat(6) { i ->
                    val isFirefly = i % 2 == 0
                    particles.add(
                        ParticleState(
                            x = kotlin.random.Random.nextFloat(),
                            y = kotlin.random.Random.nextFloat(),
                            vx = kotlin.random.Random.nextInt(120, 170).toFloat(),
                            vy = kotlin.random.Random.nextInt(-18, 18).toFloat(),
                            size = kotlin.random.Random.nextInt(3, 5).toFloat(),
                            alpha = 0.5f + kotlin.random.Random.nextFloat() * 0.3f,
                            angle = kotlin.random.Random.nextInt(0, 360).toFloat(),
                            rotationSpeed = kotlin.random.Random.nextInt(-80, 80).toFloat(),
                            phase = kotlin.random.Random.nextFloat() * 6.28f,
                            isFirefly = isFirefly,
                            layer = 2,
                            speedMultiplier = 1.4f + kotlin.random.Random.nextFloat() * 0.4f
                        )
                    )
                }
            }

            for (p in particles) {
                p.phase += deltaSec * (1.1f * p.speedMultiplier)
                val layerScale = when (p.layer) {
                    0 -> 0.5f
                    2 -> 1.6f
                    else -> 1.0f
                }

                if (p.isFirefly) {
                    // Premium firefly breathing curve (sin eased through 0..1)
                    val breathing = (kotlin.math.sin(p.phase) + 1f) / 2f
                    p.alpha = 0.15f + breathing * 0.65f

                    // Organic wandering on BOTH axes using layered sine offsets
                    val wanderX = kotlin.math.sin(p.phase * 1.3f) * 15f
                    val wanderY = kotlin.math.cos(p.phase * 0.9f) * 10f - 18f // generic upward trend
                    
                    p.x += (wanderX * p.speedMultiplier * layerScale * deltaSec) / 400f
                    p.y += (wanderY * p.speedMultiplier * layerScale * deltaSec) / 250f

                    // Edge wrapping respawn
                    if (p.y < -0.1f) {
                        p.y = 1.1f
                        p.x = kotlin.random.Random.nextFloat()
                    }
                    if (p.y > 1.1f) {
                        p.y = -0.1f
                        p.x = kotlin.random.Random.nextFloat()
                    }
                    if (p.x < -0.1f) p.x = 1.1f
                    if (p.x > 1.1f) p.x = -0.1f
                } else {
                    // Wind particles: gentle vertical bobbing + varied speed drift
                    p.angle += p.rotationSpeed * p.speedMultiplier * deltaSec
                    val bobbing = kotlin.math.sin(p.phase * 0.8f) * 12f
                    
                    p.x += (p.vx * p.speedMultiplier * layerScale * deltaSec) / 450f
                    p.y += ((p.vy + bobbing) * p.speedMultiplier * layerScale * deltaSec) / 300f

                    // Soft fade out at edge boundaries (no teleport pops)
                    if (p.x > 1.1f) {
                        p.x = -0.1f
                        p.y = kotlin.random.Random.nextFloat()
                    }
                    if (p.y < -0.1f) p.y = 1.1f
                    if (p.y > 1.1f) p.y = -0.1f
                }
            }
            frameTime = now
        }
    }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val frame = frameTime // draw dependency hook

        for (p in particles) {
            val cx = p.x * w
            val cy = p.y * h
            
            // Adjust scale factor based on 3D depth layer
            val layerScale = when (p.layer) {
                0 -> 0.5f
                2 -> 1.5f
                else -> 1.0f
            }
            val sizePx = p.size * density.density * layerScale

            // Smooth fading edge mask to completely eliminate popping on boundaries
            val edgeFadeX = if (p.x < 0.12f) p.x / 0.12f else if (p.x > 0.88f) (1f - p.x) / 0.12f else 1f
            val edgeFadeY = if (p.y < 0.12f) p.y / 0.12f else if (p.y > 0.88f) (1f - p.y) / 0.12f else 1f
            val boundaryFade = (edgeFadeX * edgeFadeY).coerceIn(0f, 1f)

            val pAlpha = p.alpha * boundaryFade * when (p.layer) {
                0 -> 0.4f   // Back layer is highly transparent
                2 -> 0.9f   // Fore layer is sharp and vivid
                else -> 0.65f
            }

            if (pAlpha <= 0.01f) continue

            if (p.isFirefly) {
                // Glow pulsing size synced with breathing alpha
                val glowPulsing = 1f + (p.alpha * 0.3f)
                drawCircle(
                    color = config.fireflyColor.copy(alpha = pAlpha * 0.28f),
                    radius = sizePx * 1.5f * glowPulsing,
                    center = Offset(cx, cy)
                )
                drawCircle(
                    color = config.fireflyColor.copy(alpha = pAlpha),
                    radius = sizePx * 0.4f,
                    center = Offset(cx, cy)
                )
            } else {
                when (config.windType) {
                    "leaf" -> {
                        withTransform({
                            translate(cx, cy)
                            rotate(p.angle)
                        }) {
                            // High-quality curled leaf (two-tone light & shadow fills)
                            val leftPath = Path().apply {
                                moveTo(0f, -sizePx)
                                quadraticTo(-sizePx * 0.45f, -sizePx * 0.25f, 0f, sizePx)
                                close()
                            }
                            drawPath(
                                path = leftPath,
                                color = config.windColor.copy(alpha = pAlpha * 0.85f),
                                style = Fill
                            )
                            val rightPath = Path().apply {
                                moveTo(0f, -sizePx)
                                quadraticTo(sizePx * 0.55f, -sizePx * 0.15f, 0f, sizePx)
                                close()
                            }
                            drawPath(
                                path = rightPath,
                                color = config.windColor.copy(alpha = pAlpha * 1.15f),
                                style = Fill
                            )
                            drawLine(
                                color = config.windColor.copy(alpha = pAlpha * 0.45f),
                                start = Offset(0f, sizePx * 0.6f),
                                end = Offset(0f, -sizePx * 0.6f),
                                strokeWidth = 1.2f * density.density
                            )
                        }
                    }
                    "dust" -> {
                        // Soft glowing dust motes (radial glow circles) instead of sharp squares
                        drawCircle(
                            color = config.windColor.copy(alpha = pAlpha * 0.15f),
                            radius = sizePx * 2.2f,
                            center = Offset(cx, cy)
                        )
                        drawCircle(
                            color = config.windColor.copy(alpha = pAlpha),
                            radius = sizePx * 0.6f,
                            center = Offset(cx, cy)
                        )
                    }
                    "petal" -> {
                        withTransform({
                            translate(cx, cy)
                            rotate(p.angle)
                        }) {
                            val path = Path().apply {
                                moveTo(0f, -sizePx)
                                quadraticTo(sizePx * 0.6f, -sizePx * 0.3f, sizePx * 0.1f, sizePx)
                                quadraticTo(-sizePx * 0.6f, -sizePx * 0.3f, 0f, -sizePx)
                                close()
                            }
                            drawPath(
                                path = path,
                                color = config.windColor.copy(alpha = pAlpha * 0.9f),
                                style = Fill
                            )
                            // Soft bright highlight on the edge
                            drawPath(
                                path = path,
                                color = Color.White.copy(alpha = pAlpha * 0.45f),
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f * density.density)
                            )
                        }
                    }
                    "feather" -> {
                        withTransform({
                            translate(cx, cy)
                            rotate(p.angle)
                        }) {
                            drawOval(
                                color = config.windColor.copy(alpha = pAlpha * 0.35f),
                                topLeft = Offset(-sizePx * 0.22f, -sizePx),
                                size = Size(sizePx * 0.45f, sizePx * 2)
                            )
                            drawLine(
                                color = config.windColor.copy(alpha = pAlpha * 0.7f),
                                start = Offset(0f, -sizePx),
                                end = Offset(0f, sizePx),
                                strokeWidth = 1f * density.density
                            )
                        }
                    }
                    "mist" -> {
                        drawCircle(
                            color = config.windColor.copy(alpha = pAlpha * 0.22f),
                            radius = sizePx * 1.3f,
                            center = Offset(cx, cy)
                        )
                        drawCircle(
                            color = config.windColor.copy(alpha = pAlpha * 0.1f),
                            radius = sizePx * 2.4f,
                            center = Offset(cx, cy)
                        )
                    }
                    "wisp" -> {
                        withTransform({
                            translate(cx, cy)
                            rotate(p.angle)
                        }) {
                            val alphaVal = pAlpha * 0.25f
                            drawOval(
                                color = config.windColor.copy(alpha = alphaVal),
                                topLeft = Offset(-sizePx, -sizePx * 0.45f),
                                size = Size(sizePx * 1.6f, sizePx * 0.9f)
                            )
                            drawOval(
                                color = config.windColor.copy(alpha = alphaVal),
                                topLeft = Offset(-sizePx * 0.25f, -sizePx * 0.65f),
                                size = Size(sizePx * 1.3f, sizePx * 1.3f)
                            )
                        }
                    }
                    "magical" -> {
                        withTransform({
                            translate(cx, cy)
                            rotate(p.angle)
                        }) {
                            val path = Path().apply {
                                moveTo(0f, -sizePx)
                                quadraticTo(0f, 0f, sizePx, 0f)
                                quadraticTo(0f, 0f, 0f, sizePx)
                                quadraticTo(0f, 0f, -sizePx, 0f)
                                quadraticTo(0f, 0f, 0f, -sizePx)
                                close()
                            }
                            drawPath(
                                path = path,
                                color = config.windColor.copy(alpha = pAlpha),
                                style = Fill
                            )
                        }
                    }
                    "ember" -> {
                        drawCircle(
                            color = config.windColor.copy(alpha = pAlpha),
                            radius = sizePx * 0.35f,
                            center = Offset(cx, cy)
                        )
                        drawCircle(
                            color = Color(0xFFFF8F00).copy(alpha = pAlpha * 0.32f),
                            radius = sizePx * 1.15f,
                            center = Offset(cx, cy)
                        )
                    }
                }
            }
        }
    }
}
