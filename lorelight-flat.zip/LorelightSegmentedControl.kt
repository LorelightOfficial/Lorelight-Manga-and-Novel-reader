package com.lorelight.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.LineHeightStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.ui.theme.LocalMotionLevel
import com.lorelight.ui.theme.getThemedButtonProps
import com.lorelight.ui.theme.motionSpring

/** Text and geometry shared by the control and adaptive header measurement. */
internal data class SegmentedControlMetrics(
    val textStyle: TextStyle,
    val preferredWidth: Dp,
    val height: Dp
)

@Composable
internal fun rememberSegmentedControlMetrics(
    labels: List<String>,
    fontSize: TextUnit,
    minimumHeight: Dp
): SegmentedControlMetrics {
    val density = LocalDensity.current
    val textMeasurer = rememberTextMeasurer()
    // A smaller fontSize must not inherit a much taller body lineHeight.
    // Measure using the actual app font and Android font scale, not a dp guess.
    val labelStyle = LocalTextStyle.current.copy(
        fontSize = fontSize,
        lineHeight = fontSize * 1.3f,
        textAlign = TextAlign.Center,
        platformStyle = PlatformTextStyle(includeFontPadding = false),
        lineHeightStyle = LineHeightStyle(
            alignment = LineHeightStyle.Alignment.Center,
            trim = LineHeightStyle.Trim.None
        )
    )
    val sizes = labels.flatMap { label ->
        listOf(FontWeight.Medium, FontWeight.Bold).map { weight ->
            textMeasurer.measure(
                text = AnnotatedString(label),
                style = labelStyle.copy(fontWeight = weight),
                softWrap = false,
                maxLines = 1
            ).size
        }
    }
    val textWidth = with(density) { (sizes.maxOfOrNull { it.width } ?: 0).toDp() }
    val textHeight = with(density) { (sizes.maxOfOrNull { it.height } ?: 0).toDp() }
    return SegmentedControlMetrics(
        textStyle = labelStyle,
        // 6 dp text padding on each side, 4 dp outer track padding each side.
        preferredWidth = maxOf(48.dp, textWidth + 12.dp) * labels.size + 8.dp,
        height = maxOf(minimumHeight, 48.dp, textHeight + 16.dp)
    )
}

/**
 * One animated selection control for the whole app.
 *
 * The app had at least six hand-rolled versions of this: the Novels/Manga pill
 * row in the library, the Languages/Extensions/Repositories pills in manga
 * browse settings, the System/Light/Dark row in Appearance, the Font Studio
 * tabs, the popular/latest tabs on both source screens, and the segmented
 * control written for the onboarding flow. Each had its own corner radius,
 * its own idea of the selected colour, and only one of them animated.
 *
 * This is the onboarding version, generalised: a highlight that slides between
 * segments on the theme's own button gradient, correct Tab semantics for
 * screen readers, and it honours the motion policy so "Reduced" cross-fades
 * and "Battery saver" snaps.
 */
@Composable
fun LorelightSegmentedControl(
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 46.dp,
    cornerRadius: Dp = 16.dp,
    fontSize: TextUnit = 13.sp,
    accent: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f),
    inactiveContentColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    showTrackBorder: Boolean = true,
    haptic: Boolean = true,
    role: Role = Role.Tab
) {
    if (options.isEmpty()) return

    val metrics = rememberSegmentedControlMetrics(options, fontSize, height)
    val motion = LocalMotionLevel.current
    val hapticFeedback = LocalHapticFeedback.current
    // Same gradient the themed buttons use, so a selected segment reads as
    // part of the theme rather than as a generic primary-coloured pill.
    val (_, highlightGradient, onHighlight) = getThemedButtonProps(
        accent,
        MaterialTheme.colorScheme.onPrimary
    )

    val selectedIndex = options.indexOf(selected).let { if (it < 0) 0 else it }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(metrics.height)
            .clip(RoundedCornerShape(cornerRadius))
            .background(trackColor)
            .then(
                if (showTrackBorder) Modifier.border(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(cornerRadius)
                ) else Modifier
            )
            .padding(4.dp)
    ) {
        val segmentWidth = maxWidth / options.size
        val targetOffset = segmentWidth * selectedIndex
        val animatedOffset by animateDpAsState(
            targetValue = targetOffset,
            animationSpec = motionSpring<Dp>(dampingRatio = 0.78f, stiffness = 360f),
            label = "segmentedHighlight"
        )
        // Reduced motion still moves the highlight (it carries meaning), it
        // just does it without the overshoot; battery saver snaps.
        val highlightOffset = if (motion.animatesTransitions) animatedOffset else targetOffset

        Box(
            modifier = Modifier
                .offset(x = highlightOffset)
                .width(segmentWidth)
                .fillMaxHeight()
                .clip(RoundedCornerShape(cornerRadius - 4.dp))
                .background(highlightGradient)
        )

        Row(modifier = Modifier.fillMaxWidth().fillMaxHeight().selectableGroup()) {
            options.forEachIndexed { index, option ->
                val isSelected = index == selectedIndex
                Box(
                    modifier = Modifier
                        // Row divides the final pixels evenly; fixed widths can
                        // accumulate rounding error and clip the last segment.
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(cornerRadius - 4.dp))
                        .selectable(
                            selected = isSelected,
                            role = role,
                            onClick = {
                                if (!isSelected) {
                                    if (haptic) {
                                        hapticFeedback.performHapticFeedback(
                                            HapticFeedbackType.TextHandleMove
                                        )
                                    }
                                    onSelect(option)
                                }
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = option,
                        style = metrics.textStyle,
                        softWrap = false,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) onHighlight else inactiveContentColor,
                        modifier = Modifier.padding(horizontal = 6.dp)
                    )
                }
            }
        }
    }
}

/** Convenience overload for controls driven by an index instead of a label. */
@Composable
fun LorelightSegmentedControl(
    options: List<String>,
    selectedIndex: Int,
    onSelectIndex: (Int) -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 46.dp,
    cornerRadius: Dp = 16.dp,
    fontSize: TextUnit = 13.sp,
    accent: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f),
    inactiveContentColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    showTrackBorder: Boolean = true,
    haptic: Boolean = true,
    role: Role = Role.Tab
) {
    val safeIndex = selectedIndex.coerceIn(0, (options.size - 1).coerceAtLeast(0))
    LorelightSegmentedControl(
        options = options,
        selected = options.getOrElse(safeIndex) { "" },
        onSelect = { label ->
            val index = options.indexOf(label)
            if (index >= 0) onSelectIndex(index)
        },
        modifier = modifier,
        height = height,
        cornerRadius = cornerRadius,
        fontSize = fontSize,
        accent = accent,
        trackColor = trackColor,
        inactiveContentColor = inactiveContentColor,
        showTrackBorder = showTrackBorder,
        haptic = haptic,
        role = role
    )
}

/**
 * S8 - Overload for controls where the stored/programmatic value differs from
 * the display label. Separating them makes the stored value stable across
 * translations while the label shown to the user can be a string resource.
 *
 * @param options  Pairs of (storedValue, displayLabel). storedValue is written
 *                 to SharedPreferences; displayLabel is shown in the UI.
 * @param selected The currently active storedValue.
 * @param onSelect Called with the storedValue of the tapped segment.
 *
 * Example:
 * ```
 * LorelightSegmentedControl(
 *     options = listOf(
 *         "novels" to stringResource(R.string.library_filter_novels),
 *         "manga"  to stringResource(R.string.library_filter_manga)
 *     ),
 *     selected = libraryMediaFilter,  // "novels" or "manga"
 *     onSelect  = { libraryMediaFilter = it }
 * )
 * ```
 */
@JvmName("LorelightSegmentedControlValueLabelPairs")
@Composable
fun LorelightSegmentedControl(
    options: List<Pair<String, String>>,
    selected: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 46.dp,
    cornerRadius: Dp = 16.dp,
    fontSize: TextUnit = 13.sp,
    accent: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f),
    inactiveContentColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    showTrackBorder: Boolean = true,
    haptic: Boolean = true,
    role: Role = Role.Tab
) {
    // Map from display label back to stored value for the callback.
    val labelToValue = remember(options) { options.associate { (v, l) -> l to v } }
    LorelightSegmentedControl(
        options = options.map { it.second },
        selected = options.firstOrNull { it.first == selected }?.second
            ?: options.firstOrNull()?.second ?: "",
        onSelect = { label -> onSelect(labelToValue[label] ?: label) },
        modifier = modifier,
        height = height,
        cornerRadius = cornerRadius,
        fontSize = fontSize,
        accent = accent,
        trackColor = trackColor,
        inactiveContentColor = inactiveContentColor,
        showTrackBorder = showTrackBorder,
        haptic = haptic,
        role = role
    )
}

/** Kept for call sites that only need a brush-free flat highlight. */
internal fun flatHighlight(color: Color): Brush = Brush.horizontalGradient(listOf(color, color))
