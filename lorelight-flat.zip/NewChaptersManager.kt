package com.lorelight.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.lorelight.MainActivity
import com.lorelight.browse.model.toNovel
import com.lorelight.data.local.AppPrefs
import com.lorelight.data.local.NovelPreferences
import com.lorelight.data.model.Novel
import com.lorelight.data.model.encodeMangaChapterUrl
import com.lorelight.data.model.getChapterList
import com.lorelight.data.model.isManga
import com.lorelight.data.model.mangaSourceId
import kotlinx.coroutines.flow.first
import tachiyomi.domain.source.service.SourceManager
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class PendingChapterItem(
    val title: String,
    val url: String
)

data class PendingTitleUpdate(
    val novelId: String,
    val novelTitle: String,
    val coverImage: String?,
    val isManga: Boolean,
    val author: String,
    val chapters: List<PendingChapterItem>,
    val detectedTimestamp: Long = System.currentTimeMillis()
)

object NewChaptersNotifier {
    const val CHANNEL_ID = "library_updates"
    private const val NOTIFICATION_GROUP_KEY = "lorelight_new_chapters_group"

    fun getNotificationId(novelId: String): Int {
        // Derive stable positive integer from novelId
        return (novelId.hashCode() and 0x7FFFFFFF)
    }

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "New Chapter Notifications",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifies you when followed novels and manga get new chapters"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun postNotification(
        context: Context,
        novelId: String,
        title: String,
        newChapters: List<PendingChapterItem>,
        isManga: Boolean
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    context,
                    android.Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }
        }

        ensureChannel(context)
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notifId = getNotificationId(novelId)

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MainActivity.EXTRA_OPEN_NEW_CHAPTERS, true)
            putExtra(MainActivity.EXTRA_TARGET_NOVEL_ID, novelId)
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            notifId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val count = newChapters.size
        val contentType = if (isManga) "chapter" else "chapter"
        val subtitle = if (count == 1) {
            "New $contentType available • Tap to review"
        } else {
            "$count new ${contentType}s available • Tap to review"
        }

        val bigText = buildString {
            if (count == 1) {
                append("New chapter: ${newChapters.first().title}\nTap to review and add to library.")
            } else {
                append("$count new chapters available:\n")
                newChapters.take(4).forEach { append("• ${it.title}\n") }
                if (count > 4) {
                    append("...and ${count - 4} more\n")
                }
                append("Tap to review and add to library.")
            }
        }

        // S7: inline action buttons — Download and Mute.
        // Skip actions if the user has muted this title.
        val isMuted = com.lorelight.service.NotificationActionReceiver.isMuted(context, novelId)

        val downloadPendingIntent = if (!isMuted) {
            val downloadIntent = Intent(context, NotificationActionReceiver::class.java).apply {
                action = NotificationActionReceiver.ACTION_DOWNLOAD
                putExtra(NotificationActionReceiver.EXTRA_NOVEL_ID, novelId)
            }
            PendingIntent.getBroadcast(
                context,
                notifId + 1,
                downloadIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        } else null

        val mutePendingIntent = if (!isMuted) {
            val muteIntent = Intent(context, NotificationActionReceiver::class.java).apply {
                action = NotificationActionReceiver.ACTION_MUTE
                putExtra(NotificationActionReceiver.EXTRA_NOVEL_ID, novelId)
            }
            PendingIntent.getBroadcast(
                context,
                notifId + 2,
                muteIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        } else null

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText).setSummaryText(if (isManga) "Manga Update" else "Novel Update"))
            .setGroup(NOTIFICATION_GROUP_KEY)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setOnlyAlertOnce(false)

        if (downloadPendingIntent != null) {
            builder.addAction(android.R.drawable.stat_sys_download_done, "Download", downloadPendingIntent)
        }
        if (mutePendingIntent != null) {
            builder.addAction(android.R.drawable.ic_lock_silent_mode, "Mute", mutePendingIntent)
        }

        notificationManager.notify(notifId, builder.build())
    }

    fun cancelNotification(context: Context, novelId: String) {
        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.cancel(getNotificationId(novelId))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun cancelAllNotifications(context: Context, novelIds: List<String>) {
        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            novelIds.forEach { id ->
                notificationManager.cancel(getNotificationId(id))
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

object NewChaptersManager {
    private const val PREFS_NAME = "lorelight_new_chapters_store"
    private const val KEY_PENDING_JSON = "pending_updates_json"
    private const val PREFIX_LAST_NOTIFIED_URL = "last_notified_url_"
    private const val PREFIX_LAST_NOTIFIED_COUNT = "last_notified_count_"

    private val _pendingUpdates = MutableStateFlow<List<PendingTitleUpdate>>(emptyList())
    val pendingUpdates: StateFlow<List<PendingTitleUpdate>> = _pendingUpdates.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _scanProgress = MutableStateFlow(0 to 0) // current to total
    val scanProgress: StateFlow<Pair<Int, Int>> = _scanProgress.asStateFlow()

    fun init(context: Context) {
        loadPendingFromPrefs(context)
    }

    private fun getStorePrefs(context: Context) =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    @Synchronized
    private fun loadPendingFromPrefs(context: Context) {
        try {
            val jsonStr = getStorePrefs(context).getString(KEY_PENDING_JSON, "[]") ?: "[]"
            val arr = JSONArray(jsonStr)
            val list = mutableListOf<PendingTitleUpdate>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val chaptersArr = obj.optJSONArray("chapters") ?: JSONArray()
                val chapters = mutableListOf<PendingChapterItem>()
                for (j in 0 until chaptersArr.length()) {
                    val cObj = chaptersArr.getJSONObject(j)
                    chapters.add(PendingChapterItem(cObj.getString("title"), cObj.getString("url")))
                }
                if (chapters.isNotEmpty()) {
                    list.add(
                        PendingTitleUpdate(
                            novelId = obj.getString("novelId"),
                            novelTitle = obj.getString("novelTitle"),
                            coverImage = obj.optString("coverImage", null).takeIf { it != "null" && !it.isNullOrEmpty() },
                            isManga = obj.optBoolean("isManga", false),
                            author = obj.optString("author", "Unknown"),
                            chapters = chapters,
                            detectedTimestamp = obj.optLong("detectedTimestamp", System.currentTimeMillis())
                        )
                    )
                }
            }
            _pendingUpdates.value = list
        } catch (e: Exception) {
            e.printStackTrace()
            _pendingUpdates.value = emptyList()
        }
    }

    @Synchronized
    private fun savePendingToPrefs(context: Context, list: List<PendingTitleUpdate>) {
        _pendingUpdates.value = list
        try {
            val arr = JSONArray()
            list.forEach { item ->
                val obj = JSONObject().apply {
                    put("novelId", item.novelId)
                    put("novelTitle", item.novelTitle)
                    put("coverImage", item.coverImage ?: JSONObject.NULL)
                    put("isManga", item.isManga)
                    put("author", item.author)
                    put("detectedTimestamp", item.detectedTimestamp)
                    val chArr = JSONArray()
                    item.chapters.forEach { ch ->
                        chArr.put(JSONObject().apply {
                            put("title", ch.title)
                            put("url", ch.url)
                        })
                    }
                    put("chapters", chArr)
                }
                arr.put(obj)
            }
            getStorePrefs(context).edit().putString(KEY_PENDING_JSON, arr.toString()).commit()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun getLastNotifiedUrl(context: Context, novelId: String): String? {
        return getStorePrefs(context).getString("$PREFIX_LAST_NOTIFIED_URL$novelId", null)
    }

    fun setLastNotifiedMarker(context: Context, novelId: String, latestUrl: String, count: Int) {
        getStorePrefs(context).edit()
            .putString("$PREFIX_LAST_NOTIFIED_URL$novelId", latestUrl)
            .putInt("$PREFIX_LAST_NOTIFIED_COUNT$novelId", count)
            .commit()
    }

    /**
     * Detects new chapters from source without modifying the library novel.
     * Returns the unimported chapters (preserves chronological order).
     */
    suspend fun detectNewChapters(context: Context, target: Novel): List<PendingChapterItem> = withContext(Dispatchers.IO) {
        if (target.isManga) {
            return@withContext detectNewMangaChapters(context, target)
        }
        if (target.pluginId != null) {
            return@withContext detectNewPluginNovelChapters(context, target)
        }

        val url = target.sourceUrl
        if (url.isNullOrBlank()) return@withContext emptyList()
        val existingUrls = target.chapterUrls.toSet()

        var latest: List<com.lorelight.crawler.CrawledChapter> = emptyList()
        com.lorelight.crawler.CrawlerEngine.streamChapters(url, context) { chapters, _ ->
            latest = chapters
        }

        latest.filter { it.url !in existingUrls }
            .map { PendingChapterItem(title = it.title, url = it.url) }
    }

    private suspend fun detectNewMangaChapters(context: Context, target: Novel): List<PendingChapterItem> {
        val sourceId = target.mangaSourceId ?: return emptyList()
        val path = target.pluginNovelPath ?: target.sourceUrl ?: return emptyList()
        val sourceManager = Injekt.get<SourceManager>()
        sourceManager.isInitialized.first { it }
        val source = sourceManager.get(sourceId) ?: return emptyList()
        val reqManga = eu.kanade.tachiyomi.source.model.SManga.create().apply { url = path }
        val freshChapters = try {
            source.getChapterList(reqManga)
        } catch (e: Exception) {
            return emptyList()
        }
        val reversedChapters = freshChapters.reversed()
        val reversedUrls = reversedChapters.map { encodeMangaChapterUrl(sourceId, it.url) }
        val existingUrls = target.chapterUrls.toSet()

        val results = mutableListOf<PendingChapterItem>()
        reversedUrls.forEachIndexed { i, u ->
            if (u !in existingUrls) {
                val rawName = reversedChapters.getOrNull(i)?.name
                val fallbackNum = existingUrls.size + results.size + 1
                val title = if (!rawName.isNullOrBlank()) rawName else "Chapter $fallbackNum"
                results.add(PendingChapterItem(title = title, url = u))
            }
        }
        return results
    }

    private suspend fun detectNewPluginNovelChapters(context: Context, target: Novel): List<PendingChapterItem> {
        val pluginId = target.pluginId ?: return emptyList()
        val path = target.pluginNovelPath ?: target.sourceUrl ?: return emptyList()
        val fresh = try {
            com.lorelight.browse.js.JSPluginEngine.parseNovel(context, pluginId, path).toNovel(pluginId)
        } catch (e: Exception) {
            return emptyList()
        }
        val existingUrls = target.chapterUrls.toSet()
        val results = mutableListOf<PendingChapterItem>()
        fresh.chapterUrls.forEachIndexed { i, u ->
            if (u !in existingUrls) {
                val title = fresh.chapters.getOrNull(i) ?: "Chapter ${existingUrls.size + results.size + 1}"
                results.add(PendingChapterItem(title = title, url = u))
            }
        }
        return results
    }

    /**
     * Executes a full scan across all eligible library novels & manga.
     * Updates notifications and pending review state.
     */
    suspend fun scanLibrary(
        context: Context,
        onProgressUpdate: ((Int, Int) -> Unit)? = null
    ): Int = withContext(Dispatchers.IO) {
        _isScanning.value = true
        init(context)

        val prefs = AppPrefs.get(context)
        val skipCompleted = prefs.getBoolean("lib_update_skip_completed", true)
        val novels = NovelPreferences.loadNovelsFromPrefs(context)

        val activeList = _pendingUpdates.value.toMutableList()
        var newlyFoundTitlesCount = 0

        val eligibleNovels = novels.filter { novel ->
            val isComplete = novel.readingStatus == "Completed" ||
                    (novel.totalChapters > 0 && novel.completedChapters.size >= novel.totalChapters)
            !(skipCompleted && isComplete)
        }

        val total = eligibleNovels.size
        _scanProgress.value = 0 to total

        eligibleNovels.forEachIndexed { index, novel ->
            _scanProgress.value = (index + 1) to total
            onProgressUpdate?.invoke(index + 1, total)

            try {
                val detected = detectNewChapters(context, novel)
                if (detected.isNotEmpty()) {
                    val latestUrl = detected.last().url
                    val lastNotified = getLastNotifiedUrl(context, novel.id)

                    val isNewer = lastNotified == null || lastNotified != latestUrl

                    if (isNewer) {
                        newlyFoundTitlesCount++
                        setLastNotifiedMarker(context, novel.id, latestUrl, detected.size)
                        // Post single, stable notification row for this title
                        NewChaptersNotifier.postNotification(
                            context = context,
                            novelId = novel.id,
                            title = novel.title,
                            newChapters = detected,
                            isManga = novel.isManga
                        )
                    }

                    // Update pending repository list
                    val existingIdx = activeList.indexOfFirst { it.novelId == novel.id }
                    val item = PendingTitleUpdate(
                        novelId = novel.id,
                        novelTitle = novel.title,
                        coverImage = novel.coverImageBase64,
                        isManga = novel.isManga,
                        author = novel.author,
                        chapters = detected,
                        detectedTimestamp = System.currentTimeMillis()
                    )
                    if (existingIdx >= 0) {
                        activeList[existingIdx] = item
                    } else {
                        activeList.add(item)
                    }
                } else {
                    // No new chapters or user manually caught up outside
                    activeList.removeAll { it.novelId == novel.id }
                    NewChaptersNotifier.cancelNotification(context, novel.id)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        savePendingToPrefs(context, activeList)
        _isScanning.value = false
        return@withContext newlyFoundTitlesCount
    }

    /**
     * Imports new chapters for the specified titles into the user's library.
     */
    suspend fun importSelectedTitles(
        context: Context,
        novelIdsToImport: Set<String>
    ): Int = withContext(Dispatchers.IO) {
        if (novelIdsToImport.isEmpty()) return@withContext 0
        init(context)

        val currentPending = _pendingUpdates.value
        val targets = currentPending.filter { it.novelId in novelIdsToImport }
        if (targets.isEmpty()) return@withContext 0

        val novels = NovelPreferences.loadNovelsFromPrefs(context).toMutableList()
        var importedCount = 0

        targets.forEach { update ->
            val idx = novels.indexOfFirst { it.id == update.novelId }
            if (idx >= 0) {
                val existing = novels[idx]
                val existingUrls = existing.chapterUrls.toSet()
                val freshChapters = update.chapters.filter { it.url !in existingUrls }

                if (freshChapters.isNotEmpty()) {
                    val newTitles = freshChapters.map { it.title }
                    val newUrls = freshChapters.map { it.url }

                    novels[idx] = existing.copy(
                        chapters = existing.chapters + newTitles,
                        chapterUrls = existing.chapterUrls + newUrls,
                        totalChapters = maxOf(existing.totalChapters, existing.chapterUrls.size + newUrls.size),
                        lastCheckedTimestamp = System.currentTimeMillis(),
                        dateModified = System.currentTimeMillis()
                    )
                    importedCount++
                }

                // Update marker to the latest imported chapter URL
                if (update.chapters.isNotEmpty()) {
                    setLastNotifiedMarker(context, update.novelId, update.chapters.last().url, update.chapters.size)
                }
                // Dismiss notification for this title
                NewChaptersNotifier.cancelNotification(context, update.novelId)
            }
        }

        if (importedCount > 0) {
            NovelPreferences.saveNovelsToPrefsSync(context, novels)
        }

        // Remove imported items from pending list
        val remaining = currentPending.filter { it.novelId !in novelIdsToImport }
        savePendingToPrefs(context, remaining)

        return@withContext importedCount
    }

    /**
     * Dismisses pending new chapter alerts for specific titles without importing them.
     * Updates the seen marker so we do not re-alert until newer chapters appear.
     */
    fun dismissTitles(context: Context, novelIdsToDismiss: Set<String>) {
        init(context)
        val currentPending = _pendingUpdates.value
        currentPending.filter { it.novelId in novelIdsToDismiss }.forEach { update ->
            if (update.chapters.isNotEmpty()) {
                setLastNotifiedMarker(context, update.novelId, update.chapters.last().url, update.chapters.size)
            }
            NewChaptersNotifier.cancelNotification(context, update.novelId)
        }

        val remaining = currentPending.filter { it.novelId !in novelIdsToDismiss }
        savePendingToPrefs(context, remaining)
    }

    /**
     * Clears all pending titles and notifications.
     */
    fun dismissAll(context: Context) {
        init(context)
        val currentPending = _pendingUpdates.value
        currentPending.forEach { update ->
            if (update.chapters.isNotEmpty()) {
                setLastNotifiedMarker(context, update.novelId, update.chapters.last().url, update.chapters.size)
            }
            NewChaptersNotifier.cancelNotification(context, update.novelId)
        }
        savePendingToPrefs(context, emptyList())
    }
}
