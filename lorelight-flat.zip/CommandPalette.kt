package com.lorelight.ui.components

import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.semantics.Role

/**
 * S6 (plan item 17): the app-wide command palette. One searchable list that
 * can reach anything registered in [commands] instead of the 2-4 taps most
 * features need today.
 *
 * Opened today by Ctrl+K on a hardware keyboard (wired from
 * MainActivity.dispatchKeyEvent through [CommandPaletteTrigger], since a
 * physical Ctrl+K has nothing to do with touch and needed no changes to any
 * existing gesture). Long-press on the bottom bar / the sun-moon companion
 * is still on the plan (see PLAN_S.txt, S6) but deliberately left alone this
 * pass: that bar already carries the tab-switch tap targets, the mode-switch
 * animation and the companion's own gestures, and adding a long-press there
 * needs to be traced very carefully first so it cannot eat one of those
 * taps by mistake.
 *
 * New features register one [PaletteCommand] each - no new entry point per
 * feature, so the palette grows without ever needing its own redesign.
 */
data class PaletteCommand(
    val id: String,
    val label: String,
    val subtitle: String? = null,
    val keywords: String = "",
    val action: () -> Unit
)

/**
 * Global, Compose-observable flag a plain (non-Compose) Android callback -
 * such as Activity.dispatchKeyEvent for Ctrl+K - can flip to ask the palette
 * to open. LorelightApp watches this with snapshotFlow and clears it once
 * consumed, so it behaves like a one-shot event rather than sticky state.
 */
object CommandPaletteTrigger {
    var requestOpen by mutableStateOf(false)
}

/**
 * S6 - Global flag the Command Palette can set to ask LibraryScreen to open
 * the EPUB file picker. The launcher must live in a Composable scope, so
 * it can’t be called directly from a PaletteCommand action. LibraryScreen
 * watches this with snapshotFlow and clears it once consumed, exactly like
 * CommandPaletteTrigger above.
 */
object EpubImportTrigger {
    var requestLaunch by mutableStateOf(false)
}

private const val PALETTE_PREFS_NAME = "lorelight_command_palette"
private const val KEY_RECENTS = "recent_command_ids"
private const val MAX_RECENTS = 6

/** Most-recently-used command ids, most recent first. */
private object CommandPaletteRecents {
    fun get(context: Context): List<String> {
        val raw = context.getSharedPreferences(PALETTE_PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_RECENTS, null) ?: return emptyList()
        return raw.split(",").filter { it.isNotBlank() }
    }

    fun record(context: Context, id: String) {
        val prefs = context.getSharedPreferences(PALETTE_PREFS_NAME, Context.MODE_PRIVATE)
        val existing = get(context).toMutableList()
        existing.remove(id)
        existing.add(0, id)
        while (existing.size > MAX_RECENTS) existing.removeAt(existing.size - 1)
        prefs.edit().putString(KEY_RECENTS, existing.joinToString(",")).apply()
    }
}

/**
 * Cheap fuzzy match: exact match scores highest, then "starts with", then a
 * plain substring, then an in-order subsequence match (so "scnw" still finds
 * "scan for new chapters"). Returns null when [query] cannot be found in
 * [target] at all, so the caller can drop it from the results.
 */
private fun fuzzyScore(query: String, target: String): Int? {
    if (query.isBlank()) return 0
    val q = query.trim().lowercase()
    val t = target.lowercase()
    if (t == q) return 1000
    if (t.startsWith(q)) return 900
    if (t.contains(q)) return 700
    var qi = 0
    var lastMatch = -1
    var gaps = 0
    for (ti in t.indices) {
        if (qi < q.length && t[ti] == q[qi]) {
            if (lastMatch >= 0) gaps += (ti - lastMatch - 1)
            lastMatch = ti
            qi++
        }
    }
    if (qi < q.length) return null
    return (500 - gaps).coerceAtLeast(1)
}

@Composable
fun CommandPalette(
    visible: Boolean,
    onDismiss: () -> Unit,
    commands: List<PaletteCommand>
) {
    if (!visible) return
    val context = LocalContext.current
    var query by remember(visible) { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }

    val results = remember(query, commands) {
        if (query.isBlank()) {
            val recentIds = CommandPaletteRecents.get(context)
            val byId = commands.associateBy { it.id }
            val recentCommands = recentIds.mapNotNull { byId[it] }
            val rest = commands.filter { it.id !in recentIds }
            recentCommands + rest
        } else {
            commands
                .mapNotNull { cmd ->
                    fuzzyScore(query, cmd.label + " " + cmd.keywords)?.let { cmd to it }
                }
                .sortedByDescending { it.second }
                .map { it.first }
        }
    }

    fun run(cmd: PaletteCommand) {
        CommandPaletteRecents.record(context, cmd.id)
        onDismiss()
        cmd.action()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.72f)
                .padding(top = 48.dp),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            shadowElevation = 12.dp
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusRequester),
                    placeholder = { Text("Search commands and titles\u2026") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(
                        onSearch = { results.firstOrNull()?.let(::run) }
                    )
                )
                Spacer(modifier = Modifier.height(12.dp))
                if (results.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            "No matching commands",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(results, key = { it.id }) { cmd ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(role = Role.Button) { run(cmd) }
                                    .padding(vertical = 14.dp, horizontal = 8.dp)
                            ) {
                                Text(cmd.label, fontWeight = FontWeight.Medium)
                                if (!cmd.subtitle.isNullOrBlank()) {
                                    Text(
                                        cmd.subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    LaunchedEffect(visible) {
        if (visible) {
            kotlinx.coroutines.delay(80)
            runCatching { focusRequester.requestFocus() }
        }
    }
}
