package com.lorelight.manga.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.IndeterminateCheckBox
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import eu.kanade.tachiyomi.source.model.Filter
import eu.kanade.tachiyomi.source.model.FilterList

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MangaFilterSheet(
    filters: FilterList,
    onReset: () -> Unit,
    onApply: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var updateVersion by remember { mutableStateOf(0) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Filters",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleLarge
                )
                TextButton(onClick = {
                    onReset()
                    updateVersion++
                }) {
                    Text("Reset")
                }
            }

            Spacer(Modifier.height(8.dp))

            Column(
                modifier = Modifier
                    .weight(1f, fill = false)
                    .heightIn(max = 450.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Key on updateVersion to recompose when any filter state mutates
                key(updateVersion) {
                    filters.forEach { filter ->
                        FilterItemRenderer(filter = filter, onStateChanged = { updateVersion++ })
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            Button(
                onClick = {
                    onApply()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Apply Filters", fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FilterItemRenderer(
    filter: Filter<*>,
    onStateChanged: () -> Unit
) {
    when (filter) {
        is Filter.Header -> {
            Text(
                text = filter.name,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        is Filter.Separator -> {
            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
        }
        is Filter.CheckBox -> {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        filter.state = !filter.state
                        onStateChanged()
                    }
                    .padding(vertical = 4.dp)
            ) {
                Checkbox(
                    checked = filter.state,
                    onCheckedChange = {
                        filter.state = it
                        onStateChanged()
                    }
                )
                Spacer(Modifier.width(8.dp))
                Text(filter.name, style = MaterialTheme.typography.bodyMedium)
            }
        }
        is Filter.TriState -> {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        val next = when (filter.state) {
                            Filter.TriState.STATE_IGNORE -> Filter.TriState.STATE_INCLUDE
                            Filter.TriState.STATE_INCLUDE -> Filter.TriState.STATE_EXCLUDE
                            else -> Filter.TriState.STATE_IGNORE
                        }
                        filter.state = next
                        onStateChanged()
                    }
                    .padding(vertical = 4.dp)
            ) {
                val icon = when (filter.state) {
                    Filter.TriState.STATE_INCLUDE -> Icons.Filled.CheckBox
                    Filter.TriState.STATE_EXCLUDE -> Icons.Filled.IndeterminateCheckBox
                    else -> Icons.Filled.CheckBoxOutlineBlank
                }
                val tint = when (filter.state) {
                    Filter.TriState.STATE_INCLUDE -> MaterialTheme.colorScheme.primary
                    Filter.TriState.STATE_EXCLUDE -> MaterialTheme.colorScheme.error
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
                Icon(icon, contentDescription = null, tint = tint)
                Spacer(Modifier.width(8.dp))
                Text(filter.name, style = MaterialTheme.typography.bodyMedium)
            }
        }
        is Filter.Text -> {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(filter.name, style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(4.dp))
                OutlinedTextField(
                    value = filter.state,
                    onValueChange = {
                        filter.state = it
                        onStateChanged()
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        is Filter.Select<*> -> {
            var expanded by remember { mutableStateOf(false) }
            val selectedIndex = filter.state
            val values = filter.values
            val selectedLabel = if (selectedIndex in values.indices) values[selectedIndex].toString() else ""

            Column(modifier = Modifier.fillMaxWidth()) {
                Text(filter.name, style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.height(4.dp))
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                    OutlinedTextField(
                        value = selectedLabel,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        values.forEachIndexed { index, item ->
                            DropdownMenuItem(
                                text = { Text(item.toString()) },
                                onClick = {
                                    @Suppress("UNCHECKED_CAST")
                                    (filter as Filter<Int>).state = index
                                    expanded = false
                                    onStateChanged()
                                }
                            )
                        }
                    }
                }
            }
        }
        is Filter.Group<*> -> {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = filter.name,
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
                val children = filter.state
                if (children is List<*>) {
                    children.filterIsInstance<Filter<*>>().forEach { child ->
                        Box(modifier = Modifier.padding(start = 12.dp)) {
                            FilterItemRenderer(filter = child, onStateChanged = onStateChanged)
                        }
                    }
                }
            }
        }
        is Filter.Sort -> {
            val selection = filter.state
            val values = filter.values

            Column(modifier = Modifier.fillMaxWidth()) {
                Text(filter.name, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(4.dp))
                values.forEachIndexed { index, name ->
                    val isSelected = selection?.index == index
                    val ascending = if (isSelected) selection?.ascending ?: false else true

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val nextAscending = if (isSelected) !ascending else true
                                filter.state = Filter.Sort.Selection(index, nextAscending)
                                onStateChanged()
                            }
                            .padding(vertical = 6.dp, horizontal = 4.dp)
                    ) {
                        Text(
                            text = name,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                        if (isSelected) {
                            Icon(
                                imageVector = if (ascending) Icons.Filled.ArrowUpward else Icons.Filled.ArrowDownward,
                                contentDescription = if (ascending) "Ascending" else "Descending",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
