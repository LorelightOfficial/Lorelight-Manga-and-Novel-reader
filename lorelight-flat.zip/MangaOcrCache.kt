package com.lorelight.manga.download

import android.content.Context
import com.lorelight.manga.reader.MangaTextBlock
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/**
 * FEATURE: pre-computed manga OCR cache + the "Run OCR while downloading" toggle.
 *
 * The manga reader OCRs each page on demand while reading aloud, so the reader
 * waits for ML Kit every time. When the user downloads a manga with the toggle
 * on, MangaDownloadManager OCRs each page up front and stores the result here.
 * MangaPageOcr.extractBlocks() then returns the cached bubbles instantly.
 *
 * Cache is content-addressed by (sourceId, page.url) so it is found again no
 * matter which manga/chapter the page belongs to.
 */
object MangaOcrCache {

    // v3: page text is now de-duplicated with fuzzy matching and seam repair is
    // text-verified, so pages cached by older builds are discarded on first read.
    private const val CURRENT_VERSION = 4
    private const val PREFS = "lorelight_manga_download_prefs"
    private const val KEY_OCR_ON_DOWNLOAD = "manga_ocr_on_download"

    fun isOcrOnDownloadEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_OCR_ON_DOWNLOAD, false)

    fun setOcrOnDownloadEnabled(context: Context, value: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_OCR_ON_DOWNLOAD, value).apply()
    }

    private fun cacheDir(context: Context): File =
        File(context.filesDir, "manga_ocr_cache").apply { mkdirs() }

    private fun sha1(input: String): String {
        return try {
            val md = MessageDigest.getInstance("SHA-1")
            md.digest(input.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
        } catch (t: Throwable) {
            input.hashCode().toString()
        }
    }

    fun fileFor(context: Context, sourceId: Long, pageUrl: String): File {
        val dir = File(cacheDir(context), sourceId.toString()).apply { mkdirs() }
        return File(dir, sha1(pageUrl) + ".json")
    }

    fun has(context: Context, sourceId: Long, pageUrl: String): Boolean {
        return !load(context, sourceId, pageUrl).isNullOrEmpty()
    }

    fun delete(context: Context, sourceId: Long, pageUrl: String) {
        val f = fileFor(context, sourceId, pageUrl)
        if (f.exists()) f.delete()
    }

    fun load(context: Context, sourceId: Long, pageUrl: String): List<MangaTextBlock>? {
        val f = fileFor(context, sourceId, pageUrl)
        if (!f.exists() || f.length() == 0L) return null
        return try {
            val content = f.readText().trim()
            if (content.isEmpty() || content == "[]" || content == "{}") {
                f.delete()
                return null
            }
            if (content.startsWith("{")) {
                val root = JSONObject(content)
                val ver = root.optInt("version", 0)
                if (ver != CURRENT_VERSION) {
                    f.delete()
                    return null
                }
                val arr = root.optJSONArray("blocks") ?: return null
                if (arr.length() == 0) {
                    f.delete()
                    return null
                }
                parseBlocksJson(arr)
            } else if (content.startsWith("[")) {
                // Outdated unversioned format -> invalidate
                f.delete()
                null
            } else {
                f.delete()
                null
            }
        } catch (t: Throwable) {
            f.delete()
            null
        }
    }

    private fun parseBlocksJson(arr: JSONArray): List<MangaTextBlock>? {
        if (arr.length() == 0) return null
        val out = ArrayList<MangaTextBlock>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(
                MangaTextBlock(
                    text = o.optString("text"),
                    left = o.optInt("left"),
                    top = o.optInt("top"),
                    right = o.optInt("right"),
                    bottom = o.optInt("bottom"),
                    pageWidth = o.optInt("pageWidth"),
                    pageHeight = o.optInt("pageHeight")
                )
            )
        }
        return if (out.isEmpty()) null else out
    }

    fun save(context: Context, sourceId: Long, pageUrl: String, blocks: List<MangaTextBlock>) {
        val f = fileFor(context, sourceId, pageUrl)
        if (blocks.isEmpty()) {
            // Never persist empty or failed OCR results to disk as valid entries
            if (f.exists()) f.delete()
            return
        }
        try {
            val root = JSONObject()
            root.put("version", CURRENT_VERSION)
            root.put("timestamp", System.currentTimeMillis())

            val arr = JSONArray()
            for (b in blocks) {
                arr.put(
                    JSONObject()
                        .put("text", b.text)
                        .put("left", b.left)
                        .put("top", b.top)
                        .put("right", b.right)
                        .put("bottom", b.bottom)
                        .put("pageWidth", b.pageWidth)
                        .put("pageHeight", b.pageHeight)
                )
            }
            root.put("blocks", arr)

            f.parentFile?.mkdirs()
            f.writeText(root.toString())
        } catch (t: Throwable) {
            // best-effort cache; ignore
        }
    }

    /** Rough count/size for the settings monitor. */
    fun stats(context: Context): Pair<Int, Long> {
        val dir = File(context.filesDir, "manga_ocr_cache")
        if (!dir.exists()) return 0 to 0L
        var count = 0
        var bytes = 0L
        dir.walkTopDown().forEach { if (it.isFile) { count++; bytes += it.length() } }
        return count to bytes
    }
}
