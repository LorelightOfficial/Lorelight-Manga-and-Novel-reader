package com.lorelight.ui.settings

import android.content.ClipData
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.BuildConfig
import com.lorelight.core.DevLogStore
import eu.kanade.tachiyomi.util.storage.getUriCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Hidden developer panel shown under the About card after tapping the info
 * icon 5 times. Displays the rolling 24-hour [DevLogStore] log with copy and
 * share actions so logs can be sent along when reporting a crash or error.
 */
@Composable
fun DevLogPanel() {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    var logText by remember { mutableStateOf(DevLogStore.read(context)) }
    var copied by remember { mutableStateOf(false) }
    var isExporting by remember { mutableStateOf(false) }
    // "App log" is the curated DevLogStore.append() trail. "Full log" adds the
    // raw logcat output underneath it, so a report can include everything the
    // OS/libraries printed too, not only what the app explicitly recorded.
    var showFullLog by remember { mutableStateOf(false) }
    var systemLog by remember { mutableStateOf("") }
    var loadingFullLog by remember { mutableStateOf(false) }

    fun loadFullLog() {
        loadingFullLog = true
        scope.launch(Dispatchers.IO) {
            val sys = DevLogStore.readSystemLog(context)
            withContext(Dispatchers.Main) {
                systemLog = sys
                loadingFullLog = false
            }
        }
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Text(
                text = "Developer Logs",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Auto-wiped every 24 hours",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                androidx.compose.material3.FilterChip(
                    selected = !showFullLog,
                    onClick = { showFullLog = false },
                    label = { Text("App log", fontSize = 11.sp) }
                )
                androidx.compose.material3.FilterChip(
                    selected = showFullLog,
                    onClick = {
                        showFullLog = true
                        if (systemLog.isBlank()) loadFullLog()
                    },
                    label = { Text("Full command log", fontSize = 11.sp) }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(380.dp)
                    .background(
                        MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                        RoundedCornerShape(8.dp)
                    )
                    .verticalScroll(rememberScrollState())
                    .horizontalScroll(rememberScrollState())
                    .padding(8.dp)
            ) {
                SelectionContainer {
                    val displayedText = if (showFullLog) {
                        when {
                            loadingFullLog -> "Loading full command log..."
                            systemLog.isBlank() -> "No system log captured yet."
                            else -> buildString {
                                append(logText.ifBlank { "(no app-recorded entries)" })
                                append("\n\n")
                                append(DevLogStore.LINE_BREAK)
                                append("\nFULL SYSTEM LOG (logcat)\n")
                                append(DevLogStore.LINE_BREAK)
                                append("\n")
                                append(systemLog)
                            }
                        }
                    } else {
                        logText.ifBlank { "No logs yet — screen opens, errors and full crash stack traces will appear here." }
                    }
                    Text(
                        text = displayedText,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        lineHeight = 13.sp,
                        softWrap = false,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(onClick = {
                    val toCopy = if (showFullLog) {
                        buildString {
                            append(logText.ifBlank { "(no app-recorded entries)" })
                            append("\n\n")
                            append(DevLogStore.LINE_BREAK)
                            append("\nFULL SYSTEM LOG (logcat)\n")
                            append(DevLogStore.LINE_BREAK)
                            append("\n")
                            append(systemLog.ifBlank { "(not loaded)" })
                        }
                    } else {
                        logText.ifBlank { "Lorelight dev logs (empty)" }
                    }
                    clipboard.setText(AnnotatedString(toCopy))
                    copied = true
                }) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (copied) "Copied" else "Copy", fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = {
                        if (isExporting) return@OutlinedButton
                        isExporting = true
                        scope.launch(Dispatchers.IO) {
                            try {
                                val rawLog = DevLogStore.read(context)
                                val bodyText = if (showFullLog) {
                                    val sys = systemLog.ifBlank { DevLogStore.readSystemLog(context) }
                                    buildString {
                                        append(rawLog.ifBlank { "(no app-recorded entries)" })
                                        append("\n\n")
                                        append(DevLogStore.LINE_BREAK)
                                        append("\nFULL SYSTEM LOG (logcat)\n")
                                        append(DevLogStore.LINE_BREAK)
                                        append("\n")
                                        append(sys)
                                    }
                                } else {
                                    rawLog.ifBlank { "(no log entries)" }
                                }
                                val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", Locale.US).format(Date())
                                val header = buildString {
                                    appendLine("=== Lorelight Developer Log ===")
                                    appendLine("App: Lorelight")
                                    appendLine("Version: ${BuildConfig.VERSION_NAME} • Stable Build (build ${BuildConfig.VERSION_CODE})")
                                    appendLine("OS: Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                                    appendLine("Device: ${Build.MANUFACTURER} ${Build.MODEL}")
                                    appendLine("Exported: $dateStr")
                                    appendLine("================================")
                                    appendLine()
                                }
                                val fullContent = header + bodyText

                                val devLogsDir = File(context.cacheDir, "dev_logs").apply { mkdirs() }
                                try {
                                    devLogsDir.listFiles()?.forEach { it.delete() }
                                } catch (_: Exception) {}

                                val timestamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
                                val fileName = "lorelight-devlog-$timestamp.txt"
                                val snapshotFile = File(devLogsDir, fileName)
                                snapshotFile.writeText(fullContent)

                                val uri = snapshotFile.getUriCompat(context)
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    putExtra(Intent.EXTRA_SUBJECT, fileName)
                                    clipData = ClipData.newRawUri(fileName, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }

                                withContext(Dispatchers.Main) {
                                    context.startActivity(Intent.createChooser(sendIntent, "Share logs"))
                                }
                            } catch (e: Exception) {
                                DevLogStore.append(context, "DEV", "Failed to share dev logs: ${e.message}")
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(context, "Failed to export dev logs: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            } finally {
                                withContext(Dispatchers.Main) {
                                    isExporting = false
                                }
                            }
                        }
                    },
                    enabled = !isExporting
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(if (isExporting) "Preparing..." else "Share", fontSize = 12.sp)
                }
                OutlinedButton(onClick = {
                    copied = false
                    logText = DevLogStore.read(context)
                    if (showFullLog) loadFullLog()
                }) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Refresh", fontSize = 12.sp)
                }
            }
        }
    }
}
