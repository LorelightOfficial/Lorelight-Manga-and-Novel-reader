package com.lorelight.browse.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.IndeterminateCheckBox
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lorelight.browse.model.FilterDef
import com.lorelight.browse.model.FilterValue
import com.lorelight.browse.model.FilterValues

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilterBottomSheet(
    filters: List<FilterDef>,
    initial: FilterValues?,
    onApply: (FilterValues) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val pickerState = remember { mutableStateMapOf<String, String>() }
    val textState = remember { mutableStateMapOf<String, String>() }
    val switchState = remember { mutableStateMapOf<String, Boolean>() }
    val checkboxState = remember { mutableStateMapOf<String, Set<String>>() }
    val includeState = remember { mutableStateMapOf<String, Set<String>>() }
    val excludeState = remember { mutableStateMapOf<String, Set<String>>() }

    LaunchedEffect(filters, initial) {
        val provided = initial?.map ?: emptyMap()
        pickerState.clear(); textState.clear(); switchState.clear()
        checkboxState.clear(); includeState.clear(); excludeState.clear()

        filters.forEach { f ->
            val existing = provided[f.key]?.value
            when (f) {
                is FilterDef.Picker ->
                    pickerState[f.key] = (existing as? String) ?: f.default
                is FilterDef.TextInput ->
                    textState[f.key] = (existing as? String) ?: f.default
                is FilterDef.Switch ->
                    switchState[f.key] = (existing as? Boolean) ?: f.default
                is FilterDef.CheckboxGroup ->
                    checkboxState[f.key] = (existing as? List<*>)
                        ?.filterIsInstance<String>()?.toSet() ?: f.defaults.toSet()
                is FilterDef.ExcludableCheckboxGroup -> {
                    val pair = existing as? Pair<*, *>
                    includeState[f.key] = (pair?.first as? List<*>)
                        ?.filterIsInstance<String>()?.toSet() ?: f.includedDefaults.toSet()
                    excludeState[f.key] = (pair?.second as? List<*>)
                        ?.filterIsInstance<String>()?.toSet() ?: f.excludedDefaults.toSet()
                }
            }
        }
    }

    fun build(): FilterValues {
        val map = mutableMapOf<String, FilterValue>()
        filters.forEach { f ->
            when (f) {
                is FilterDef.Picker -> map[f.key] = FilterValue("Picker", pickerState[f.key] ?: f.default)
                is FilterDef.TextInput -> map[f.key] = FilterValue("Text", textState[f.key] ?: f.default)
                is FilterDef.Switch -> map[f.key] = FilterValue("Switch", switchState[f.key] ?: f.default)
                is FilterDef.CheckboxGroup -> map[f.key] = FilterValue("Checkbox", (checkboxState[f.key] ?: emptySet()).toList())
                is FilterDef.ExcludableCheckboxGroup -> map[f.key] = FilterValue(
                    "XCheckbox",
                    Pair((includeState[f.key] ?: emptySet()).toList(), (excludeState[f.key] ?: emptySet()).toList())
                )
            }
        }
        return FilterValues(map)
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text("Filters", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))

            filters.forEach { f ->
                Text(f.label, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(6.dp))

                when (f) {
                    is FilterDef.Picker -> {
                        var expanded by remember { mutableStateOf(false) }
                        val cur = pickerState[f.key] ?: f.default
                        val curLabel = f.options.firstOrNull { it.second == cur }?.first ?: cur

                        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                            OutlinedTextField(
                                value = curLabel,
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                                modifier = Modifier.menuAnchor().fillMaxWidth()
                            )
                            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                f.options.forEach { opt ->
                                    DropdownMenuItem(
                                        text = { Text(opt.first) },
                                        onClick = { pickerState[f.key] = opt.second; expanded = false }
                                    )
                                }
                            }
                        }
                    }
                    is FilterDef.TextInput -> {
                        OutlinedTextField(
                            value = textState[f.key] ?: "",
                            onValueChange = { textState[f.key] = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                    is FilterDef.Switch -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(
                                checked = switchState[f.key] ?: false,
                                onCheckedChange = { switchState[f.key] = it }
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(f.label)
                        }
                    }
                    is FilterDef.CheckboxGroup -> {
                        val sel = checkboxState[f.key] ?: emptySet()
                        f.options.forEach { opt ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Checkbox(
                                    checked = sel.contains(opt.second),
                                    onCheckedChange = { checked ->
                                        val ns = sel.toMutableSet()
                                        if (checked) ns.add(opt.second) else ns.remove(opt.second)
                                        checkboxState[f.key] = ns
                                    }
                                )
                                Text(opt.first)
                            }
                        }
                    }
                    is FilterDef.ExcludableCheckboxGroup -> {
                        val inc = includeState[f.key] ?: emptySet()
                        val exc = excludeState[f.key] ?: emptySet()
                        f.options.forEach { opt ->
                            val state = when {
                                inc.contains(opt.second) -> 1
                                exc.contains(opt.second) -> 2
                                else -> 0
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        val ni = inc.toMutableSet()
                                        val ne = exc.toMutableSet()
                                        when (state) {
                                            0 -> ni.add(opt.second)
                                            1 -> { ni.remove(opt.second); ne.add(opt.second) }
                                            else -> ne.remove(opt.second)
                                        }
                                        includeState[f.key] = ni
                                        excludeState[f.key] = ne
                                    }
                                    .padding(vertical = 4.dp)
                            ) {
                                val icon = when (state) {
                                    1 -> Icons.Filled.CheckBox
                                    2 -> Icons.Filled.IndeterminateCheckBox
                                    else -> Icons.Filled.CheckBoxOutlineBlank
                                }
                                Icon(
                                    icon,
                                    contentDescription = null,
                                    tint = when (state) {
                                        1 -> MaterialTheme.colorScheme.primary
                                        2 -> MaterialTheme.colorScheme.error
                                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(opt.first)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }

            Row(
                Modifier.fillMaxWidth().padding(bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        filters.forEach { f ->
                            when (f) {
                                is FilterDef.Picker -> pickerState[f.key] = f.default
                                is FilterDef.TextInput -> textState[f.key] = f.default
                                is FilterDef.Switch -> switchState[f.key] = f.default
                                is FilterDef.CheckboxGroup -> checkboxState[f.key] = f.defaults.toSet()
                                is FilterDef.ExcludableCheckboxGroup -> {
                                    includeState[f.key] = f.includedDefaults.toSet()
                                    excludeState[f.key] = f.excludedDefaults.toSet()
                                }
                            }
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Reset") }
                Button(onClick = { onApply(build()) }, modifier = Modifier.weight(1f)) { Text("Apply") }
            }
        }
    }
}
