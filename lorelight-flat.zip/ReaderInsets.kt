package com.lorelight.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.statusBars
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Top padding that keeps a reader panel clear of the status row.
 *
 * statusBarsPadding() alone is not enough here. Both readers run immersive:
 * while the chrome is hidden the status bar is GONE, so its inset is zero, and
 * a panel opened in that state draws its title right into the clock strip the
 * moment the bar slides back in. A punch-hole or notch does the same thing on
 * its own. So this takes whichever is largest -- the status bar, the display
 * cutout, or a floor that stands in for the bar while it is hidden -- and the
 * panel is safe in every combination of those states.
 */
@Composable
fun readerSafeTopPadding(minimum: Dp = 26.dp): Dp {
    val status = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val cutout = WindowInsets.displayCutout.asPaddingValues().calculateTopPadding()
    return maxOf(status, cutout, minimum)
}
