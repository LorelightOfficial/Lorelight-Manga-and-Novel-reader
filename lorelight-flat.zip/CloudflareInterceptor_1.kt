package eu.kanade.tachiyomi.network.interceptor

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.ContextCompat
import eu.kanade.tachiyomi.network.AndroidCookieJar
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response
import org.jsoup.Jsoup
import java.io.IOException
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class CloudflareInterceptor(
    private val context: Context,
    private val cookieManager: AndroidCookieJar,
    private val defaultUserAgentProvider: () -> String
) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val response = try {
            chain.proceed(request)
        } catch (e: Exception) {
            if (e is IOException) throw e else throw IOException(e)
        }

        if (!isChallenge(response)) {
            return response
        }

        response.close()

        val solved = try {
            resolveWithWebView(request)
        } catch (e: Exception) {
            Log.e("CloudflareInterceptor", "Failed to resolve Cloudflare challenge", e)
            false
        }

        if (solved) {
            return try {
                chain.proceed(request)
            } catch (e: Exception) {
                if (e is IOException) throw e else throw IOException(e)
            }
        } else {
            throw IOException(
                "Cloudflare challenge could not be solved automatically. Open the source's website once in a browser, pass the check, then retry."
            )
        }
    }

    private fun isChallenge(response: Response): Boolean {
        if (response.code !in ERROR_CODES) return false
        val server = response.header("Server") ?: ""
        if (!server.contains("cloudflare", ignoreCase = true)) return false

        return try {
            val bodyString = response.peekBody(1024L * 100L).string()
            val doc = Jsoup.parse(bodyString)
            doc.getElementById("challenge-error-title") != null ||
                doc.getElementById("challenge-error-text") != null ||
                doc.getElementById("challenge-form") != null ||
                doc.getElementById("challenge-running") != null ||
                doc.getElementById("cf-challenge") != null ||
                bodyString.contains("challenge-platform", ignoreCase = true) ||
                bodyString.contains("Just a moment...", ignoreCase = true)
        } catch (e: Exception) {
            false
        }
    }

    private fun resolveWithWebView(request: Request): Boolean {
        val origUrl = request.url.toString()
        val httpUrl = request.url
        val latch = CountDownLatch(1)
        var solved = false
        val oldCookie = cookieManager.get(httpUrl).firstOrNull { it.name == "cf_clearance" }
        var webView: WebView? = null

        val mainExecutor = ContextCompat.getMainExecutor(context)
        val handler = Handler(Looper.getMainLooper())

        val checkRunnable = object : Runnable {
            override fun run() {
                if (latch.count > 0) {
                    val newCookies = cookieManager.get(httpUrl)
                    if (newCookies.any { it.name == "cf_clearance" && it != oldCookie }) {
                        solved = true
                        latch.countDown()
                    } else {
                        handler.postDelayed(this, 500)
                    }
                }
            }
        }

        mainExecutor.execute {
            try {
                val wv = WebView(context)
                webView = wv
                @SuppressLint("SetJavaScriptEnabled")
                wv.settings.javaScriptEnabled = true
                wv.settings.domStorageEnabled = true
                wv.settings.databaseEnabled = true
                wv.settings.userAgentString = request.header("User-Agent") ?: defaultUserAgentProvider()

                val headerMap = mutableMapOf<String, String>()
                val headers = request.headers
                for (i in 0 until headers.size) {
                    val name = headers.name(i)
                    val lowerName = name.lowercase(Locale.ROOT)
                    val value = headers.value(i)
                    if (lowerName in UNSAFE_HEADERS || lowerName.startsWith("proxy-")) continue
                    if (lowerName == "connection" && value.equals("upgrade", ignoreCase = true)) continue
                    headerMap[name] = value
                }

                wv.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        val newCookies = cookieManager.get(httpUrl)
                        if (newCookies.any { it.name == "cf_clearance" && it != oldCookie }) {
                            solved = true
                            latch.countDown()
                        }
                    }
                }

                handler.postDelayed(checkRunnable, 500)
                wv.loadUrl(origUrl, headerMap)
            } catch (e: Exception) {
                Log.e("CloudflareInterceptor", "Error initializing WebView for Cloudflare challenge", e)
                latch.countDown()
            }
        }

        try {
            latch.await(30, TimeUnit.SECONDS)
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
        }

        mainExecutor.execute {
            handler.removeCallbacks(checkRunnable)
            try {
                webView?.stopLoading()
                webView?.destroy()
                webView = null
            } catch (e: Exception) {
                Log.e("CloudflareInterceptor", "Error destroying WebView", e)
            }
        }

        if (!solved) {
            val finalCookies = cookieManager.get(httpUrl)
            if (finalCookies.any { it.name == "cf_clearance" && it != oldCookie }) {
                solved = true
            }
        }

        return solved
    }

    companion object {
        private val ERROR_CODES = listOf(403, 503)
        private val UNSAFE_HEADERS = setOf(
            "content-length",
            "host",
            "trailer",
            "te",
            "upgrade",
            "cookie2",
            "keep-alive",
            "transfer-encoding",
            "set-cookie"
        )
    }
}
