package com.lorelight.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import com.lorelight.core.BackupManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private sealed class SPhase {
    data object Idle : SPhase()
    data object Loading : SPhase()
    data class Failed(val msg: String) : SPhase()
}

/**
 * Storage folder selection — the mandatory first step.
 * Full redesign: animated entrance, breathing hero icon, warm copy,
 * smooth loading state, inline error with retry.
 */
@Composable
fun StorageOnboardingScreen(onFolderSelected: (String, String) -> Unit) {
    val context = LocalContext.current
    val scope   = rememberCoroutineScope()
    var phase   by remember { mutableStateOf<SPhase>(SPhase.Idle) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        phase = SPhase.Loading
        scope.launch(Dispatchers.IO) {
            try {
                val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, flags)
                val name = DocumentFile.fromTreeUri(context, uri)?.name ?: "Lorelight"
                context.getSharedPreferences("lorelight_backup_prefs", Context.MODE_PRIVATE).edit()
                    .putString(BackupManager.KEY_LOCATION_TYPE, "custom")
                    .putString(BackupManager.KEY_CUSTOM_URI, uri.toString())
                    .putString(BackupManager.KEY_CUSTOM_PATH_NAME, name)
                    .apply()
                BackupManager.initializeDirectories(context, uri)
                BackupManager.createBackup(context)
                withContext(Dispatchers.Main) { onFolderSelected(uri.toString(), name) }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    phase = SPhase.Failed(e.localizedMessage ?: "Something went wrong")
                }
            }
        }
    }

    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(80); visible = true }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    0f   to MaterialTheme.colorScheme.background,
                    0.5f to MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.14f),
                    1f   to MaterialTheme.colorScheme.background
                )
            )
            .windowInsetsPadding(WindowInsets.safeDrawing),
        contentAlignment = Alignment.Center
    ) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(360)) + slideInVertically(tween(380, easing = FastOutSlowInEasing)) { it / 4 }
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 440.dp)
                    .fillMaxWidth()
                    .padding(horizontal = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                // Wordmark
                Text(
                    "LORELIGHT",
                    fontSize = 27.sp, fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 5.sp, color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(30.dp))

                // Animated folder hero
                StorageHeroIcon()
                Spacer(Modifier.height(26.dp))

                // Headline
                Text(
                    "Choose your home folder",
                    fontSize = 24.sp, fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center, letterSpacing = (-0.3).sp
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "One folder keeps your library, downloads, and backups together. " +
                    "You pick it once \u2014 you can always move it later.",
                    fontSize = 13.sp, lineHeight = 19.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.60f),
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(26.dp))

                // What’s in the folder
                StorageFeatureCard()
                Spacer(Modifier.height(24.dp))

                // Error banner
                AnimatedVisibility(
                    visible = phase is SPhase.Failed,
                    enter = expandVertically() + fadeIn(),
                    exit  = shrinkVertically() + fadeOut()
                ) {
                    val errMsg = (phase as? SPhase.Failed)?.msg ?: ""
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.20f))
                                .border(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(Icons.Default.ErrorOutline, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                            Text(errMsg, fontSize = 12.sp, lineHeight = 16.sp, color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                        Spacer(Modifier.height(12.dp))
                    }
                }

                // CTA
                when (phase) {
                    SPhase.Loading -> Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            strokeWidth = 3.dp, modifier = Modifier.size(42.dp)
                        )
                        Text("Setting up your folder\u2026", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    else -> {
                        Button(
                            onClick = { phase = SPhase.Idle; picker.launch(null) },
                            shape = CircleShape,
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor   = MaterialTheme.colorScheme.onPrimary
                            )
                        ) {
                            Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(10.dp))
                            Text(
                                if (phase is SPhase.Failed) "TRY AGAIN" else "CHOOSE FOLDER",
                                fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp
                            )
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(
                            "You can change or migrate this folder later in Settings \u2192 Backup",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.40f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StorageHeroIcon() {
    val pulse = rememberInfiniteTransition(label = "storagePulse")
    val scale by pulse.animateFloat(
        1f, 1.18f,
        animationSpec = infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glowScale"
    )
    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(110.dp)) {
        Box(
            modifier = Modifier.size(104.dp).scale(scale).clip(CircleShape)
                .background(Brush.radialGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f), Color.Transparent)))
        )
        Box(
            modifier = Modifier.size(72.dp).clip(CircleShape)
                .background(Brush.radialGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.20f), MaterialTheme.colorScheme.primary.copy(alpha = 0.06f))))
                .border(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.20f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.FolderOpen, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(34.dp))
        }
    }
}

@Composable
private fun StorageFeatureCard() {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.34f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("What goes in this folder", fontSize = 12.sp, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary, letterSpacing = 0.4.sp)
            StorageRow(Icons.Default.Download, "Downloads", "Offline chapters and manga pages you save for later")
            StorageRow(Icons.Default.Backup,   "Backups",   "Automatic snapshots of your library and reading progress")
            StorageRow(Icons.Default.BugReport, "Logs",     "Crash reports stored locally \u2014 never sent anywhere")
        }
    }
}

@Composable
private fun StorageRow(icon: ImageVector, title: String, desc: String) {
    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(
            modifier = Modifier.size(34.dp).clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.11f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(17.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
            Text(desc,  fontSize = 11.sp, lineHeight = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.78f))
        }
    }
}
