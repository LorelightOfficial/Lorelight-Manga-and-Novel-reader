__registerModule('urlencode', function(module){
  function encode(str){ return encodeURIComponent(String(str)); }   // charset arg ignored (UTF-8 only)
  function decode(str){ return decodeURIComponent(String(str)); }
  var fn = function(str){ return encode(str); };
  fn.encode = encode;
  fn.decode = decode;
  module.exports = fn;
});
