package com.lorelight.ui.library

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.lorelight.ui.theme.GlassDialog
import com.lorelight.ui.theme.getThemedButtonProps

@Composable
fun BookshelfDisplaySettingsDialog(
    showDialog: Boolean,
    bookshelfCoverScale: Float,
    onBookshelfCoverScaleChange: (Float) -> Unit,
    bookshelfRows: Int,
    onBookshelfRowsChange: (Int) -> Unit,
    bookDesignEnabled: Boolean = true,
    onBookDesignChange: (Boolean) -> Unit = {},
    bookDesignStyles: Set<Int> = ALL_BOOK_DESIGNS,
    onBookDesignStylesChange: (Set<Int>) -> Unit = {},
    shelfDesignEnabled: Boolean = true,
    onShelfDesignChange: (Boolean) -> Unit = {},
    mixMangaAndNovels: Boolean = false,
    onMixMangaAndNovelsChange: (Boolean) -> Unit = {},
    onDismissRequest: () -> Unit
) {
    if (showDialog) {
        Dialog(
            onDismissRequest = onDismissRequest
        ) {
            GlassDialog(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Text(
                        text = "Bookshelf Display Settings",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        fontFamily = MaterialTheme.typography.headlineLarge.fontFamily,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    
                    Text(
                        text = "Cover Image Size",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Slider(
                            value = bookshelfCoverScale,
                            onValueChange = onBookshelfCoverScaleChange,
                            valueRange = 0.5f..1.2f,
                            colors = SliderDefaults.colors(
                                activeTrackColor = MaterialTheme.colorScheme.primary,
                                inactiveTrackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "${(bookshelfCoverScale * 100).toInt()}%",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(42.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.End
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Number of Rows",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Slider(
                            value = bookshelfRows.toFloat(),
                            onValueChange = { onBookshelfRowsChange(it.toInt().coerceIn(1, 3)) },
                            valueRange = 1f..3f,
                            steps = 1,
                            colors = SliderDefaults.colors(
                                activeTrackColor = MaterialTheme.colorScheme.primary,
                                inactiveTrackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.2f)
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "$bookshelfRows",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.width(42.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.End
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "3D book design",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            fontWeight = FontWeight.SemiBold
                        )
                        Switch(
                            checked = bookDesignEnabled,
                            onCheckedChange = onBookDesignChange,
                            colors = SwitchDefaults.colors(
                                checkedTrackColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    }

                    // ── Book design picker: live 3D previews of the three designs ──
                    androidx.compose.animation.AnimatedVisibility(visible = bookDesignEnabled) {
                        Column {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Book designs",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Pick one or more. Books mix the selected designs.",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                val designs = listOf(
                                    BOOK_DESIGN_MODERN to "Modern",
                                    BOOK_DESIGN_ANCIENT to "Ancient",
                                    BOOK_DESIGN_INKED to "Inked Edge"
                                )
                                designs.forEach { (style, label) ->
                                    val selected = style in bookDesignStyles
                                    Column(
                                        modifier = Modifier.weight(1f),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(
                                                    if (selected)
                                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
                                                    else
                                                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.04f)
                                                )
                                                .border(
                                                    width = if (selected) 2.dp else 1.dp,
                                                    color = if (selected) MaterialTheme.colorScheme.primary
                                                            else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                                                    shape = RoundedCornerShape(12.dp)
                                                )
                                                .clickable {
                                                    val next = if (selected) bookDesignStyles - style
                                                               else bookDesignStyles + style
                                                    // Keep at least one design enabled
                                                    if (next.isNotEmpty()) onBookDesignStylesChange(next)
                                                }
                                                .padding(horizontal = 8.dp, vertical = 12.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Book3DDesignPreview(
                                                designStyle = style,
                                                modifier = Modifier.fillMaxWidth()
                                            )
                                            if (selected) {
                                                Box(
                                                    modifier = Modifier
                                                        .align(Alignment.TopEnd)
                                                        .size(18.dp)
                                                        .clip(RoundedCornerShape(9.dp))
                                                        .background(MaterialTheme.colorScheme.primary),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Filled.Check,
                                                        contentDescription = "$label design enabled",
                                                        tint = MaterialTheme.colorScheme.background,
                                                        modifier = Modifier.size(12.dp)
                                                    )
                                                }
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = label,
                                            fontSize = 11.sp,
                                            textAlign = TextAlign.Center,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (selected) MaterialTheme.colorScheme.primary
                                                    else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Wooden shelf design",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                            fontWeight = FontWeight.SemiBold
                        )
                        Switch(
                            checked = shelfDesignEnabled,
                            onCheckedChange = onShelfDesignChange,
                            colors = SwitchDefaults.colors(
                                checkedTrackColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Mix novels and manga",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Show both in one shelf",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                        Switch(
                            checked = mixMangaAndNovels,
                            onCheckedChange = onMixMangaAndNovelsChange,
                            colors = SwitchDefaults.colors(
                                checkedTrackColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    val primaryColor = MaterialTheme.colorScheme.primary
                    val (isPremiumBtn, btnGrad, btnContent) = getThemedButtonProps(primaryColor, MaterialTheme.colorScheme.background)
                    Button(
                        onClick = onDismissRequest,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isPremiumBtn) Color.Transparent else primaryColor,
                            contentColor = btnContent
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(
                                if (isPremiumBtn) {
                                    Modifier.background(btnGrad, RoundedCornerShape(10.dp))
                                } else {
                                    Modifier
                                }
                            ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Apply Layout", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
