package com.lorelight.ui.library

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.ui.graphics.Shadow
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalDensity
import kotlin.math.absoluteValue
import androidx.compose.ui.window.Dialog
import com.lorelight.R
import com.lorelight.core.getSafeBoolean
import com.lorelight.core.getSafeFloat
import com.lorelight.core.getSafeInt
import com.lorelight.crawler.CrawlerEngine
import com.lorelight.data.local.NovelPreferences
import com.lorelight.data.model.Novel
import com.lorelight.ui.components.LibraryCoverImage
import com.lorelight.ui.components.NovelCoverImage
import com.lorelight.ui.reader.ReaderViewModel
import com.lorelight.ui.theme.*
import com.lorelight.utils.EpubExtractor
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private val Novel.isManga: Boolean get() = pluginId?.let { com.lorelight.manga.util.MangaNamingUtils.isMangaPluginId(it) } == true

fun formatLastReadTime(timestamp: Long): String =
    NovelPreferences.formatLastReadTime(timestamp)

private fun formatLastReadTimeUnusedLegacy(timestamp: Long): String {
    val now = System.currentTimeMillis()
    val sdfTime = SimpleDateFormat("h:mm a", Locale.US)
    val sdfFull = SimpleDateFormat("d MMMM h:mm a", Locale.US)
    
    val cal1 = Calendar.getInstance()
    cal1.timeInMillis = now
    val cal2 = Calendar.getInstance()
    cal2.timeInMillis = timestamp
    
    val isSameDay = cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                    cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
                    
    cal1.add(Calendar.DAY_OF_YEAR, -1)
    val isYesterday = cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                      cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
                      
    return when {
        isSameDay -> "Today, ${sdfTime.format(Date(timestamp))}"
        isYesterday -> "Yesterday, ${sdfTime.format(Date(timestamp))}"
        else -> sdfFull.format(Date(timestamp))
    }
}

fun getFileName(context: Context, uri: Uri): String {
    var result: String? = null
    if (uri.scheme == "content") {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        try {
            if (cursor != null && cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index != -1) {
                    result = cursor.getString(index)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            cursor?.close()
        }
    }
    if (result == null) {
        result = uri.path
        val cut = result?.lastIndexOf('/')
        if (cut != null && cut != -1) {
            result = result.substring(cut + 1)
        }
    }
    return result ?: "Unknown Novel"
}

@Composable
fun AudioControllerCard(
    novel: Novel,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onSkipBackward: () -> Unit,
    onSkipForward: () -> Unit,
    onPrevChapter: () -> Unit,
    onNextChapter: () -> Unit,
    hasPrevChapter: Boolean,
    hasNextChapter: Boolean,
    onStop: () -> Unit,
    onCardClick: () -> Unit
) {
    // PLAIN, matching ContinueReadingCard exactly. This card SWAPS IN for the
    // continue-reading card when playback starts, so the two have to be the
    // same object wearing different controls. When the glass came off that one
    // this was missed, and starting playback made the box visibly change
    // material mid-session -- glare, bloom and L-shaped corner brackets
    // reappearing on a card that had just been flattened.
    //
    // Same radius, same surfaceVariant fill, same hairline outline, no frame.
    val playerCorner = 16.dp
    val playerShape = RoundedCornerShape(playerCorner)
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(playerShape)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
            .border(
                1.dp,
                MaterialTheme.colorScheme.outline.copy(alpha = 0.30f),
                playerShape
            )
            .clickable { onCardClick() }
    ) {
        Box(
            modifier = Modifier.padding(12.dp)
        ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp, 80.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(MaterialTheme.colorScheme.outline),
                contentAlignment = Alignment.Center
            ) {
                LibraryCoverImage(
                    novel = novel,
                    modifier = Modifier.fillMaxSize()
                )
                val importingIds by com.lorelight.service.NovelImportManager.importing.collectAsState()
                val isImporting = importingIds.contains(novel.id) || novel.status == "Importing"
                if (isImporting) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.45f)),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.VolumeUp,
                            contentDescription = "Playing audio",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.width(12.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "NOW PLAYING",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )
                    
                    IconButton(
                        onClick = onStop,
                        modifier = Modifier.size(20.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Stop TTS",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
                
                Text(
                    text = novel.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Text(
                    text = novel.currentChapter,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onPrevChapter,
                        enabled = hasPrevChapter,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.FastRewind,
                            contentDescription = "Prev Chapter",
                            tint = if (hasPrevChapter) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    
                    IconButton(
                        onClick = onSkipBackward,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SkipPrevious,
                            contentDescription = "Prev Sentence",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary)
                            .clickable { onPlayPause() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    
                    IconButton(
                        onClick = onSkipForward,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SkipNext,
                            contentDescription = "Next Sentence",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    
                    IconButton(
                        onClick = onNextChapter,
                        enabled = hasNextChapter,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.FastForward,
                            contentDescription = "Next Chapter",
                            tint = if (hasNextChapter) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
}

@Composable
fun LibraryScreen(
    currentNovel: Novel?,
    importedNovels: List<Novel>,
    onCurrentNovelChange: (Novel?) -> Unit,
    onImportedNovelsChange: (List<Novel>) -> Unit,
    onSelectNovelForDetails: (Novel) -> Unit,
    onReadCurrent: () -> Unit = {},
    readerViewModel: ReaderViewModel,
    heroImageRes: Int = R.drawable.darklibrarygreen,
    libraryLoaded: Boolean = true,
    pendingEpubUri: Uri? = null,
    onPendingEpubHandled: () -> Unit = {}
) {
    val context = LocalContext.current
    val isPlaying by readerViewModel.isPlaying.collectAsState()
    val activeNovel by readerViewModel.activeNovel.collectAsState()

    var ttsSessionShown by remember(activeNovel?.id) { mutableStateOf(false) }
    LaunchedEffect(activeNovel?.id, isPlaying) {
        if (isPlaying) ttsSessionShown = true
        val an = activeNovel
        if (an != null && !an.isManga) {
            NovelPreferences.setLastMode(context, an.id, isPlaying || ttsSessionShown)
        }
    }
    val activeChapterIndex by readerViewModel.activeChapterIndex.collectAsState()
    val chapters by readerViewModel.chapters.collectAsState()
    // FIX C15: the library screen was the ONLY user of the orphan
    // "lorelight_settings" file, so shelf layout, sort mode, media filter and
    // source filter lived outside backup/restore and outside every other
    // settings read. AppPrefs returns the canonical store and folds the old
    // file's keys in exactly once.
    val settingsVersion by com.lorelight.data.local.AppSettingsSignal.version.collectAsState()
    val sharedPrefs = remember(context, settingsVersion) { com.lorelight.data.local.AppPrefs.get(context) }
    
    var isManageMode by remember { mutableStateOf(false) }
    var selectedNovelTitles by remember { mutableStateOf(setOf<String>()) }
    var showEditDialog by remember { mutableStateOf(false) }
    var showMigrateDialog by remember { mutableStateOf(false) }
    if (showMigrateDialog) {
        val migrateTargets = importedNovels.filter { it.title in selectedNovelTitles }
        com.lorelight.browse.migrate.MigrateSourceDialog(
            novels = migrateTargets,
            onDismiss = { showMigrateDialog = false },
            onApplied = { migrated ->
                if (migrated.isNotEmpty()) {
                    val byId = migrated.associateBy { it.id }
                    onImportedNovelsChange(importedNovels.map { byId[it.id] ?: it })
                }
                showMigrateDialog = false
                selectedNovelTitles = emptySet()
                isManageMode = false
            }
        )
    }
    
    var bookshelfCoverScale by remember(settingsVersion) {
        val scale = sharedPrefs.getSafeFloat("bookshelf_cover_scale", 1.0f)
        mutableStateOf(scale)
    }
    var bookshelfRows by remember(settingsVersion) {
        val rows = sharedPrefs.getSafeInt("bookshelf_rows", 2)
        mutableStateOf(rows.coerceIn(1, 3))
    }
    var bookshelfBookDesign by remember(settingsVersion) {
        val enabled = sharedPrefs.getSafeBoolean("bookshelf_book_design", true)
        mutableStateOf(enabled)
    }
    var bookshelfBookDesignStyles by remember(settingsVersion) {
        // Multi-select: stored as comma-separated design ids, default = all designs
        val raw = sharedPrefs.getString("bookshelf_book_design_styles", null)
        val parsed = raw?.split(",")
            ?.mapNotNull { it.trim().toIntOrNull() }
            ?.filter { it in ALL_BOOK_DESIGNS }
            ?.toSet()
        mutableStateOf(if (parsed.isNullOrEmpty()) ALL_BOOK_DESIGNS else parsed)
    }
    var bookshelfShelfDesign by remember(settingsVersion) {
        val enabled = sharedPrefs.getSafeBoolean("bookshelf_shelf_design", true)
        mutableStateOf(enabled)
    }
    var bookshelfMixMedia by remember(settingsVersion) {
        val mix = sharedPrefs.getSafeBoolean("bookshelf_mix_media", false)
        mutableStateOf(mix)
    }
    var libraryMediaFilter by remember(settingsVersion) { mutableStateOf(sharedPrefs.getString("library_media_filter", "Novels") ?: "Novels") }
    LaunchedEffect(importedNovels) {
        if (importedNovels.isNotEmpty()) {
            val hasManga = importedNovels.any { it.isManga }
            val hasNovel = importedNovels.any { !it.isManga }
            if (hasManga && !hasNovel) {
                if (libraryMediaFilter != "Manga") libraryMediaFilter = "Manga"
            } else if (hasNovel && !hasManga) {
                if (libraryMediaFilter != "Novels") libraryMediaFilter = "Novels"
            }
        }
    }
    var isEpubLoading by remember { mutableStateOf(false) }

    // Library sort & filter state
    var librarySortMode by remember(settingsVersion) { mutableStateOf(sharedPrefs.getString("library_sort_mode", "Last read") ?: "Last read") }
    var librarySourceFilter by remember(settingsVersion) { mutableStateOf(sharedPrefs.getString("library_source_filter", "All") ?: "All") }
    var showSortMenu by remember { mutableStateOf(false) }
    val displayedNovels = remember(importedNovels, librarySortMode, librarySourceFilter, libraryMediaFilter, bookshelfMixMedia) {
        importedNovels
            .filter { novel ->
                if (bookshelfMixMedia) {
                    true
                } else if (libraryMediaFilter == "Manga") {
                    novel.isManga
                } else {
                    !novel.isManga
                }
            }
            .filter { novel ->
                when (librarySourceFilter) {
                    "Online" -> novel.isOnline
                    "Local" -> !novel.isOnline
                    else -> true
                }
            }
            .let { list ->
                when (librarySortMode) {
                    "Title (A-Z)" -> list.sortedBy { it.title.lowercase() }
                    "Recently added" -> list.sortedByDescending { it.dateAdded }
                    else -> list.sortedByDescending { it.lastReadTimestamp }
                }
            }
    }
    
    val gridState = rememberLazyGridState()
    val listState = rememberLazyListState()
    
    LaunchedEffect(bookshelfCoverScale, bookshelfRows, bookshelfBookDesign, bookshelfBookDesignStyles, bookshelfShelfDesign, bookshelfMixMedia) {
        sharedPrefs.edit()
            .putFloat("bookshelf_cover_scale", bookshelfCoverScale)
            .putInt("bookshelf_rows", bookshelfRows)
            .putBoolean("bookshelf_book_design", bookshelfBookDesign)
            .putString("bookshelf_book_design_styles", bookshelfBookDesignStyles.sorted().joinToString(","))
            .putBoolean("bookshelf_shelf_design", bookshelfShelfDesign)
            .putBoolean("bookshelf_mix_media", bookshelfMixMedia)
            .apply()
    }
    
    LaunchedEffect(Unit) {
        if (CoverFetchSession.done) return@LaunchedEffect
        CoverFetchSession.done = true
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val current = importedNovels
            var changed = false
            val updated = current.map { novel ->
                val cover = novel.coverImageBase64
                if (!cover.isNullOrEmpty() && (cover.startsWith("http://") || cover.startsWith("https://"))) {
                    try {
                        val bytes = org.jsoup.Jsoup.connect(cover)
                            .ignoreContentType(true)
                            .userAgent("Mozilla/5.0")
                            .timeout(12000)
                            .execute()
                            .bodyAsBytes()
                        val path = if (bytes != null && bytes.isNotEmpty())
                            com.lorelight.data.local.CoverStorage.saveCoverBytes(context, novel.id, bytes) else null
                        if (path != null) { changed = true; novel.copy(coverImageBase64 = path) } else novel
                    } catch (e: Exception) { novel }
                } else novel
            }
            if (changed) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    onImportedNovelsChange(updated)
                }
            }
        }
    }
    
    val coroutineScope = rememberCoroutineScope()

    var editedTitle by remember(selectedNovelTitles.firstOrNull()) {
        mutableStateOf("")
    }
    var editedCoverBase64 by remember(selectedNovelTitles.firstOrNull()) {
        mutableStateOf<String?>(null)
    }
    
    val targetNovel = remember(showEditDialog, selectedNovelTitles.firstOrNull()) {
        importedNovels.find { it.title == selectedNovelTitles.firstOrNull() }
    }
    
    LaunchedEffect(targetNovel) {
        if (targetNovel != null) {
            editedTitle = targetNovel.title
            editedCoverBase64 = targetNovel.coverImageBase64
        }
    }
    
    val coverPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    val inputStream = context.contentResolver.openInputStream(uri)
                    val bytes = inputStream?.readBytes()
                    inputStream?.close()
                    if (bytes != null) {
                        val base64Str = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                        editedCoverBase64 = base64Str
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(context, "Failed to load cover image", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    // Single import path, shared by the in-app picker and external triggers.
    suspend fun importEpubFromUri(uri: Uri, fromExternalApp: Boolean = false) {
        isEpubLoading = true
        try {
            val fileName = getFileName(context, uri)
            if (!fileName.endsWith(".epub", ignoreCase = true) && !fromExternalApp) {
                Toast.makeText(context, "Please select an EPUB file (ending with .epub)", Toast.LENGTH_LONG).show()
                isEpubLoading = false
                return
            }
            
            val result = com.lorelight.service.NovelImportManager.importEpub(context, uri)
            when (result) {
                is com.lorelight.service.EpubImportResult.Success -> {
                    val novel = result.novel
                    val freshNovels = com.lorelight.data.local.NovelPreferences.loadNovelsFromPrefs(context)
                    onImportedNovelsChange(freshNovels)
                    onCurrentNovelChange(novel)
                    onSelectNovelForDetails(novel)
                    val firstChapter = novel.chapters.firstOrNull() ?: novel.currentChapter
                    readerViewModel.startReading(novel, firstChapter)
                    onReadCurrent()
                    Toast.makeText(
                        context,
                        if (result.isNew) "Successfully imported \u201C${novel.title}\u201D" else "Opened \u201C${novel.title}\u201D",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                is com.lorelight.service.EpubImportResult.Error -> {
                    Toast.makeText(context, result.message, Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to import EPUB: ${e.localizedMessage ?: e.message}", Toast.LENGTH_LONG).show()
        } finally {
            isEpubLoading = false
        }
    }

    val epubLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch { importEpubFromUri(uri) }
        }
    }

    // "Open with Lorelight" / share-sheet hand-off is owned solely by MainActivity.
    // This screen must NOT import it as well - running both importers in parallel
    // raced on the extracted epub file and the saved novel list, which is what made
    // books occasionally not land in the library and made a successful import still
    // report "failed". The in-app picker below is the only import this screen starts.

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        val configuration = androidx.compose.ui.platform.LocalConfiguration.current
        val isTablet = configuration.screenWidthDp >= 600
        val heroHeight = if (isTablet) 240.dp else 280.dp

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 680.dp)
                .height(heroHeight)
        ) {
            Image(
                painter = painterResource(id = heroImageRes),
                contentDescription = "Library Hero Banner",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colorStops = arrayOf(
                                0.0f to Color.Transparent,
                                0.45f to Color.Transparent,
                                0.85f to MaterialTheme.colorScheme.background,
                                1.0f to MaterialTheme.colorScheme.background
                            )
                        )
                    )
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clipToBounds()
            ) {
                val appThemeName by readerViewModel.appTheme.collectAsState()
                WindAndFirefliesBackground(
                    themeName = appThemeName,
                    primaryColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.matchParentSize()
                )

                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 32.dp)
                            .height(48.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Library",
                            fontSize = 32.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = MaterialTheme.typography.headlineLarge.fontFamily,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Glass, matching the source-page buttons and the
                            // bottom nav panes rather than a flat filled pill.
                            com.lorelight.ui.theme.GlassPanel(
                                cornerRadius = 12.dp,
                                tintAlpha = 0.65f,
                                modifier = Modifier
                                    .clickable {
                                        try {
                                            epubLauncher.launch("application/epub+zip")
                                        } catch (e: Exception) {
                                            epubLauncher.launch("*/*")
                                        }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.MenuBook,
                                        contentDescription = "Import",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Import",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
 
                    Spacer(modifier = Modifier.height(100.dp))
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                val actNovel = activeNovel
                val showAudioCard = actNovel != null &&
                    !actNovel.isManga &&
                    (isPlaying || ttsSessionShown)
                if (actNovel != null && showAudioCard) {
                    AudioControllerCard(
                        novel = actNovel,
                        isPlaying = isPlaying,
                        onPlayPause = { readerViewModel.togglePlayPause() },
                        onSkipBackward = { readerViewModel.skipBackward() },
                        onSkipForward = { readerViewModel.skipForward() },
                        onPrevChapter = {
                            if (activeChapterIndex > 0) {
                                readerViewModel.selectChapter(activeChapterIndex - 1)
                            }
                        },
                        onNextChapter = {
                            if (activeChapterIndex < chapters.size - 1) {
                                readerViewModel.selectChapter(activeChapterIndex + 1)
                            }
                        },
                        hasPrevChapter = activeChapterIndex > 0,
                        hasNextChapter = activeChapterIndex < chapters.size - 1,
                        onStop = {
                            readerViewModel.stopSpeaking()
                            ttsSessionShown = false
                        },
                        onCardClick = {
                            onCurrentNovelChange(actNovel)
                            onReadCurrent()
                        }
                    )
                } else {
                    val resumeNovel = remember(currentNovel, importedNovels, isPlaying, ttsSessionShown) {
                        val cur = currentNovel
                        if (cur != null) importedNovels.firstOrNull { it.id == cur.id } ?: cur
                        else NovelPreferences.pickResumeNovel(importedNovels)
                    }
                    val resumeIsManga = resumeNovel?.isManga == true
                    ContinueReadingCard(
                        novel = resumeNovel,
                        isManga = resumeIsManga,
                        showPlayButton = !resumeIsManga,
                        onReadClick = {
                            resumeNovel?.let {
                                onCurrentNovelChange(it)
                                NovelPreferences.setLastMode(context, it.id, false)
                                onReadCurrent()
                            }
                        },
                        onPlayTtsClick = {
                            resumeNovel?.let {
                                onCurrentNovelChange(it)
                                NovelPreferences.setLastMode(context, it.id, true)
                                readerViewModel.startReadingAndPlay(it)
                            }
                        }
                    )
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
            Column(modifier = Modifier.fillMaxSize()) {
            Spacer(modifier = Modifier.height(12.dp))

            if (isManageMode) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f, fill = false),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(onClick = { 
                            isManageMode = false
                            selectedNovelTitles = emptySet()
                        }) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Cancel",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = "${selectedNovelTitles.size} Selected",
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        if (importedNovels.isNotEmpty()) {
                            val allSel = selectedNovelTitles.size == importedNovels.size
                            TextButton(
                                onClick = {
                                    selectedNovelTitles = if (allSel) emptySet() else importedNovels.map { it.title }.toSet()
                                }
                            ) {
                                Text(
                                    text = if (allSel) "Deselect All" else "Select All",
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        
                        if (selectedNovelTitles.size == 1) {
                            IconButton(onClick = { showEditDialog = true }) {
                                Icon(
                                    imageVector = Icons.Filled.Edit,
                                    contentDescription = "Edit Novel",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        if (selectedNovelTitles.isNotEmpty()) {
                            IconButton(onClick = { showMigrateDialog = true }) {
                                Icon(
                                    imageVector = Icons.Filled.SwapHoriz,
                                    contentDescription = "Transfer to another source",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        
                        if (selectedNovelTitles.isNotEmpty()) {
                            IconButton(onClick = {
                                val selectedNovels = importedNovels.filter { it.title in selectedNovelTitles }
                                selectedNovels.forEach { novelToRemove ->
                                    com.lorelight.data.local.NovelRemovalManager.removeNovelFromLibrary(context, novelToRemove)
                                }
                                val remainingNovels = importedNovels.filter { it.title !in selectedNovelTitles }
                                onImportedNovelsChange(remainingNovels)
                                if (currentNovel != null && currentNovel.title in selectedNovelTitles) {
                                    onCurrentNovelChange(NovelPreferences.pickResumeNovel(remainingNovels))
                                }
                                selectedNovelTitles = emptySet()
                                isManageMode = false
                            }) {
                                Icon(
                                    imageVector = Icons.Filled.Delete,
                                    contentDescription = "Delete Novels",
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "My Bookshelf",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = MaterialTheme.typography.headlineLarge.fontFamily,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        if (!bookshelfMixMedia) {
                            Row(
                                modifier = Modifier
                                    .height(28.dp)
                                    .clip(RoundedCornerShape(50))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(50)),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                listOf("Novels", "Manga").forEach { item ->
                                    val selected = libraryMediaFilter == item
                                    Box(
                                        modifier = Modifier
                                            .fillMaxHeight()
                                            .clip(RoundedCornerShape(50))
                                            .background(if (selected) MaterialTheme.colorScheme.primary else Color.Transparent)
                                            .clickable {
                                                libraryMediaFilter = item
                                                sharedPrefs.edit().putString("library_media_filter", item).apply()
                                            }
                                            .padding(horizontal = 12.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = item,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                    
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box {
                            // Plain icon buttons by request. The glass pane made
                            // these two read as heavy chips on the bookshelf row.
                            IconButton(onClick = { showSortMenu = true }) {
                                Icon(
                                    imageVector = Icons.Filled.Tune,
                                    contentDescription = "Sort & Filter",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            GlassDropdownMenu(
                                expanded = showSortMenu,
                                onDismissRequest = { showSortMenu = false },
                            ) {
                                Text("Sort by", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                                listOf("Last read", "Title (A-Z)", "Recently added").forEach { opt ->
                                    DropdownMenuItem(
                                        text = { Text(if (librarySortMode == opt) "$opt  ✓" else opt, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp) },
                                        onClick = {
                                            librarySortMode = opt
                                            sharedPrefs.edit().putString("library_sort_mode", opt).apply()
                                            showSortMenu = false
                                        }
                                    )
                                }
                                HorizontalDivider()
                                Text("Show", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                                listOf("All", "Online", "Local").forEach { opt ->
                                    DropdownMenuItem(
                                        text = { Text(if (librarySourceFilter == opt) "$opt  ✓" else opt, color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp) },
                                        onClick = {
                                            librarySourceFilter = opt
                                            sharedPrefs.edit().putString("library_source_filter", opt).apply()
                                            showSortMenu = false
                                        }
                                    )
                                }
                            }
                        }

                        Box {
                            var showThreeDotMenu by remember { mutableStateOf(false) }
                            var showDisplayDialog by remember { mutableStateOf(false) }
                            
                            IconButton(onClick = { showThreeDotMenu = true }) {
                                Icon(
                                    imageVector = Icons.Filled.MoreVert,
                                    contentDescription = "Bookshelf Options",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            
                            GlassDropdownMenu(
                                expanded = showThreeDotMenu,
                                onDismissRequest = { showThreeDotMenu = false },
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Display Settings", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp) },
                                    onClick = {
                                        showThreeDotMenu = false
                                        showDisplayDialog = true
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Edit / Manage Novels", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp) },
                                    onClick = {
                                        showThreeDotMenu = false
                                        isManageMode = true
                                        selectedNovelTitles = emptySet()
                                    }
                                )
                            }
                            
                            BookshelfDisplaySettingsDialog(
                                showDialog = showDisplayDialog,
                                bookshelfCoverScale = bookshelfCoverScale,
                                onBookshelfCoverScaleChange = { bookshelfCoverScale = it },
                                bookshelfRows = bookshelfRows,
                                onBookshelfRowsChange = { bookshelfRows = it },
                                bookDesignEnabled = bookshelfBookDesign,
                                onBookDesignChange = { bookshelfBookDesign = it },
                                bookDesignStyles = bookshelfBookDesignStyles,
                                onBookDesignStylesChange = { bookshelfBookDesignStyles = it },
                                shelfDesignEnabled = bookshelfShelfDesign,
                                onShelfDesignChange = { bookshelfShelfDesign = it },
                                mixMangaAndNovels = bookshelfMixMedia,
                                onMixMangaAndNovelsChange = { bookshelfMixMedia = it },
                                onDismissRequest = { showDisplayDialog = false }
                            )
                        }
                    }
                }
            }

            val animOffsetY = remember { androidx.compose.animation.core.Animatable(40f) }
            val animAlpha = remember { androidx.compose.animation.core.Animatable(0f) }

            LaunchedEffect(libraryMediaFilter, librarySourceFilter, librarySortMode, libraryLoaded) {
                animOffsetY.snapTo(40f)
                animAlpha.snapTo(0f)
                launch {
                    animOffsetY.animateTo(
                        targetValue = 0f,
                        animationSpec = androidx.compose.animation.core.tween(
                            durationMillis = 350,
                            easing = androidx.compose.animation.core.FastOutSlowInEasing
                        )
                    )
                }
                launch {
                    animAlpha.animateTo(
                        targetValue = 1f,
                        animationSpec = androidx.compose.animation.core.tween(
                            durationMillis = 300
                        )
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .graphicsLayer {
                        translationY = animOffsetY.value
                        alpha = animAlpha.value
                    }
            ) {
                BookGrid(
                    importedNovels = displayedNovels,
                    currentNovel = currentNovel,
                    isManageMode = isManageMode,
                    selectedNovelTitles = selectedNovelTitles,
                    bookshelfCoverScale = bookshelfCoverScale,
                    bookshelfRows = bookshelfRows,
                    bookDesign = bookshelfBookDesign,
                    bookDesignStyles = bookshelfBookDesignStyles,
                    shelfDesign = bookshelfShelfDesign,
                    gridState = gridState,
                    libraryLoaded = libraryLoaded,
                    modifier = Modifier.fillMaxSize(),
                    onNovelSelect = { novel ->
                        if (isManageMode) {
                            selectedNovelTitles = if (novel.title in selectedNovelTitles) {
                                selectedNovelTitles - novel.title
                            } else {
                                selectedNovelTitles + novel.title
                            }
                        } else {
                            onSelectNovelForDetails(novel)
                        }
                    },
                    onNovelLongPress = { novel ->
                        if (!isManageMode) {
                            isManageMode = true
                            selectedNovelTitles = setOf(novel.title)
                        }
                    }
                )
            }
            }
            }
        }
    }

    BookEditDetailsDialog(
        showDialog = showEditDialog,
        targetNovel = targetNovel,
        importedNovels = importedNovels,
        currentNovel = currentNovel,
        editedTitle = editedTitle,
        onEditedTitleChange = { editedTitle = it },
        editedCoverBase64 = editedCoverBase64,
        onCoverPickerLaunch = { coverPickerLauncher.launch("image/*") },
        onImportedNovelsChange = onImportedNovelsChange,
        onCurrentNovelChange = onCurrentNovelChange,
        onDismissRequest = { showEditDialog = false },
        onSuccess = {
            selectedNovelTitles = emptySet()
            showEditDialog = false
            isManageMode = false
        }
    )
}

private class ParticleState(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var size: Float,
    var alpha: Float,
    var angle: Float,
    var rotationSpeed: Float,
    var phase: Float,
    val isFirefly: Boolean,
    val layer: Int, // 0 = background, 1 = mid, 2 = foreground
    val speedMultiplier: Float
)

private data class ThemeAnimationConfig(
    val fireflyColor: Color,
    val windColor: Color,
    val windType: String // "leaf", "dust", "petal", "feather", "mist", "wisp", "magical", "ember"
)

private fun getThemeAnimationConfig(themeName: String, primaryColor: Color): ThemeAnimationConfig {
    val normalized = themeName.lowercase()
    return when {
        normalized.contains("forest") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFFAED581), // light green-yellow
            windColor = Color(0xFFC5E1A5),
            windType = "leaf"
        )
        normalized.contains("gold") || normalized.contains("golden") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFFFFE082), // warm gold
            windColor = Color(0xFFFFD54F),
            windType = "dust"
        )
        normalized.contains("pink") || normalized.contains("satin") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFFFF8DA1), // pink rose
            windColor = Color(0xFFFFB0D0),
            windType = "petal"
        )
        normalized.contains("black") || normalized.contains("midnight") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFFFFFFFF), // pure white glow
            windColor = Color(0xFFE5E7EB),
            windType = "feather"
        )
        normalized.contains("ocean") || normalized.contains("blue") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFF81C7F4), // ocean mist cyan
            windColor = Color(0xFFB3E5FC),
            windType = "mist"
        )
        normalized.contains("cyan") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFF80DEEA), // cyan
            windColor = Color(0xFFB2EBF2),
            windType = "wisp"
        )
        normalized.contains("purple") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFFE1BEE7), // violet
            windColor = Color(0xFFD59DFB),
            windType = "magical"
        )
        normalized.contains("blood") || normalized.contains("red") -> ThemeAnimationConfig(
            fireflyColor = Color(0xFFFF5252), // fiery crimson
            windColor = Color(0xFFFA5F70),
            windType = "leaf"
        )
        else -> ThemeAnimationConfig(
            fireflyColor = primaryColor.copy(alpha = 0.85f),
            windColor = primaryColor.copy(alpha = 0.65f),
            windType = "magical"
        )
    }
}

@Composable
fun WindAndFirefliesBackground(
    themeName: String,
    primaryColor: Color,
    modifier: Modifier = Modifier
) {
    val config = remember(themeName, primaryColor) {
        getThemeAnimationConfig(themeName, primaryColor)
    }

    val context = LocalContext.current
    val density = LocalDensity.current
    val particles = remember { mutableStateListOf<ParticleState>() }
    var frameTime by remember { mutableStateOf(0L) }

    // Check system animation / accessibility toggle
    val removeAnimations = remember(context) {
        try {
            val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? android.view.accessibility.AccessibilityManager
            val systemAnimDisabled = android.provider.Settings.Global.getFloat(
                context.contentResolver,
                android.provider.Settings.Global.ANIMATOR_DURATION_SCALE,
                1.0f
            ) == 0.0f
            systemAnimDisabled || (am?.isEnabled == true && am.isTouchExplorationEnabled)
        } catch (e: Exception) {
            false
        }
    }

    // Lifecycle observer to pause when app is backgrounded
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    var isAppActive by remember { mutableStateOf(true) }
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            isAppActive = (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME || event == androidx.lifecycle.Lifecycle.Event.ON_START)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LaunchedEffect(config, removeAnimations, isAppActive) {
        if (removeAnimations) {
            // Setup static layout for accessibility
            if (particles.isEmpty()) {
                repeat(24) { index ->
                    val isFirefly = index % 3 == 0
                    particles.add(
                        ParticleState(
                            x = kotlin.random.Random.nextFloat(),
                            y = kotlin.random.Random.nextFloat(),
                            vx = 0f,
                            vy = 0f,
                            size = kotlin.random.Random.nextInt(2, 4).toFloat(),
                            alpha = 0.3f + kotlin.random.Random.nextFloat() * 0.4f,
                            angle = kotlin.random.Random.nextInt(0, 360).toFloat(),
                            rotationSpeed = 0f,
                            phase = kotlin.random.Random.nextFloat() * 6.28f,
                            isFirefly = isFirefly,
                            layer = index % 3,
                            speedMultiplier = 1.0f
                        )
                    )
                }
            }
            return@LaunchedEffect
        }

        var lastTime = withFrameMillis { it }
        while (isAppActive) {
            val now = withFrameMillis { it }
            val deltaSec = ((now - lastTime) / 1000f).coerceAtMost(0.1f)
            lastTime = now

            if (particles.isEmpty()) {
                // Initialize 3 layers of parallax depth (10 in background, 8 in midground, 6 in foreground)
                // Layer 0: Background (smaller, slower, more translucent)
                // Layer 1: Midground (standard)
                // Layer 2: Foreground (larger, faster, sharper)
                repeat(10) { i ->
                    val isFirefly = i % 2 == 0
                    particles.add(
                        ParticleState(
                            x = kotlin.random.Random.nextFloat(),
                            y = kotlin.random.Random.nextFloat(),
                            vx = kotlin.random.Random.nextInt(40, 70).toFloat(),
                            vy = kotlin.random.Random.nextInt(-8, 8).toFloat(),
                            size = kotlin.random.Random.nextInt(1, 3).toFloat(),
                            alpha = 0.15f + kotlin.random.Random.nextFloat() * 0.3f,
                            angle = kotlin.random.Random.nextInt(0, 360).toFloat(),
                            rotationSpeed = kotlin.random.Random.nextInt(-30, 30).toFloat(),
                            phase = kotlin.random.Random.nextFloat() * 6.28f,
                            isFirefly = isFirefly,
                            layer = 0,
                            speedMultiplier = 0.5f + kotlin.random.Random.nextFloat() * 0.3f
                        )
                    )
                }

                repeat(8) { i ->
                    val isFirefly = i % 2 != 0
                    particles.add(
                        ParticleState(
                            x = kotlin.random.Random.nextFloat(),
                            y = kotlin.random.Random.nextFloat(),
                            vx = kotlin.random.Random.nextInt(70, 110).toFloat(),
                            vy = kotlin.random.Random.nextInt(-12, 12).toFloat(),
                            size = kotlin.random.Random.nextInt(2, 4).toFloat(),
                            alpha = 0.3f + kotlin.random.Random.nextFloat() * 0.4f,
                            angle = kotlin.random.Random.nextInt(0, 360).toFloat(),
                            rotationSpeed = kotlin.random.Random.nextInt(-50, 50).toFloat(),
                            phase = kotlin.random.Random.nextFloat() * 6.28f,
                            isFirefly = isFirefly,
                            layer = 1,
                            speedMultiplier = 0.9f + kotlin.random.Random.nextFloat() * 0.3f
                        )
                    )
                }

                repeat(6) { i ->
                    val isFirefly = i % 2 == 0
                    particles.add(
                        ParticleState(
                            x = kotlin.random.Random.nextFloat(),
                            y = kotlin.random.Random.nextFloat(),
                            vx = kotlin.random.Random.nextInt(120, 170).toFloat(),
                            vy = kotlin.random.Random.nextInt(-18, 18).toFloat(),
                            size = kotlin.random.Random.nextInt(3, 5).toFloat(),
                            alpha = 0.5f + kotlin.random.Random.nextFloat() * 0.3f,
                            angle = kotlin.random.Random.nextInt(0, 360).toFloat(),
                            rotationSpeed = kotlin.random.Random.nextInt(-80, 80).toFloat(),
                            phase = kotlin.random.Random.nextFloat() * 6.28f,
                            isFirefly = isFirefly,
                            layer = 2,
                            speedMultiplier = 1.4f + kotlin.random.Random.nextFloat() * 0.4f
                        )
                    )
                }
            }

            for (p in particles) {
                p.phase += deltaSec * (1.1f * p.speedMultiplier)
                val layerScale = when (p.layer) {
                    0 -> 0.5f
                    2 -> 1.6f
                    else -> 1.0f
                }

                if (p.isFirefly) {
                    // Premium firefly breathing curve (sin eased through 0..1)
                    val breathing = (kotlin.math.sin(p.phase) + 1f) / 2f
                    p.alpha = 0.15f + breathing * 0.65f

                    // Organic wandering on BOTH axes using layered sine offsets
                    val wanderX = kotlin.math.sin(p.phase * 1.3f) * 15f
                    val wanderY = kotlin.math.cos(p.phase * 0.9f) * 10f - 18f // generic upward trend
                    
                    p.x += (wanderX * p.speedMultiplier * layerScale * deltaSec) / 400f
                    p.y += (wanderY * p.speedMultiplier * layerScale * deltaSec) / 250f

                    // Edge wrapping respawn
                    if (p.y < -0.1f) {
                        p.y = 1.1f
                        p.x = kotlin.random.Random.nextFloat()
                    }
                    if (p.y > 1.1f) {
                        p.y = -0.1f
                        p.x = kotlin.random.Random.nextFloat()
                    }
                    if (p.x < -0.1f) p.x = 1.1f
                    if (p.x > 1.1f) p.x = -0.1f
                } else {
                    // Wind particles: gentle vertical bobbing + varied speed drift
                    p.angle += p.rotationSpeed * p.speedMultiplier * deltaSec
                    val bobbing = kotlin.math.sin(p.phase * 0.8f) * 12f
                    
                    p.x += (p.vx * p.speedMultiplier * layerScale * deltaSec) / 450f
                    p.y += ((p.vy + bobbing) * p.speedMultiplier * layerScale * deltaSec) / 300f

                    // Soft fade out at edge boundaries (no teleport pops)
                    if (p.x > 1.1f) {
                        p.x = -0.1f
                        p.y = kotlin.random.Random.nextFloat()
                    }
                    if (p.y < -0.1f) p.y = 1.1f
                    if (p.y > 1.1f) p.y = -0.1f
                }
            }
            frameTime = now
        }
    }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val frame = frameTime // draw dependency hook

        for (p in particles) {
            val cx = p.x * w
            val cy = p.y * h
            
            // Adjust scale factor based on 3D depth layer
            val layerScale = when (p.layer) {
                0 -> 0.5f
                2 -> 1.5f
                else -> 1.0f
            }
            val sizePx = p.size * density.density * layerScale

            // Smooth fading edge mask to completely eliminate popping on boundaries
            val edgeFadeX = if (p.x < 0.12f) p.x / 0.12f else if (p.x > 0.88f) (1f - p.x) / 0.12f else 1f
            val edgeFadeY = if (p.y < 0.12f) p.y / 0.12f else if (p.y > 0.88f) (1f - p.y) / 0.12f else 1f
            val boundaryFade = (edgeFadeX * edgeFadeY).coerceIn(0f, 1f)

            val pAlpha = p.alpha * boundaryFade * when (p.layer) {
                0 -> 0.4f   // Back layer is highly transparent
                2 -> 0.9f   // Fore layer is sharp and vivid
                else -> 0.65f
            }

            if (pAlpha <= 0.01f) continue

            if (p.isFirefly) {
                // Glow pulsing size synced with breathing alpha
                val glowPulsing = 1f + (p.alpha * 0.3f)
                drawCircle(
                    color = config.fireflyColor.copy(alpha = pAlpha * 0.28f),
                    radius = sizePx * 1.5f * glowPulsing,
                    center = Offset(cx, cy)
                )
                drawCircle(
                    color = config.fireflyColor.copy(alpha = pAlpha),
                    radius = sizePx * 0.4f,
                    center = Offset(cx, cy)
                )
            } else {
                when (config.windType) {
                    "leaf" -> {
                        withTransform({
                            translate(cx, cy)
                            rotate(p.angle)
                        }) {
                            // High-quality curled leaf (two-tone light & shadow fills)
                            val leftPath = Path().apply {
                                moveTo(0f, -sizePx)
                                quadraticTo(-sizePx * 0.45f, -sizePx * 0.25f, 0f, sizePx)
                                close()
                            }
                            drawPath(
                                path = leftPath,
                                color = config.windColor.copy(alpha = pAlpha * 0.85f),
                                style = Fill
                            )
                            val rightPath = Path().apply {
                                moveTo(0f, -sizePx)
                                quadraticTo(sizePx * 0.55f, -sizePx * 0.15f, 0f, sizePx)
                                close()
                            }
                            drawPath(
                                path = rightPath,
                                color = config.windColor.copy(alpha = pAlpha * 1.15f),
                                style = Fill
                            )
                            drawLine(
                                color = config.windColor.copy(alpha = pAlpha * 0.45f),
                                start = Offset(0f, sizePx * 0.6f),
                                end = Offset(0f, -sizePx * 0.6f),
                                strokeWidth = 1.2f * density.density
                            )
                        }
                    }
                    "dust" -> {
                        // Soft glowing dust motes (radial glow circles) instead of sharp squares
                        drawCircle(
                            color = config.windColor.copy(alpha = pAlpha * 0.15f),
                            radius = sizePx * 2.2f,
                            center = Offset(cx, cy)
                        )
                        drawCircle(
                            color = config.windColor.copy(alpha = pAlpha),
                            radius = sizePx * 0.6f,
                            center = Offset(cx, cy)
                        )
                    }
                    "petal" -> {
                        withTransform({
                            translate(cx, cy)
                            rotate(p.angle)
                        }) {
                            val path = Path().apply {
                                moveTo(0f, -sizePx)
                                quadraticTo(sizePx * 0.6f, -sizePx * 0.3f, sizePx * 0.1f, sizePx)
                                quadraticTo(-sizePx * 0.6f, -sizePx * 0.3f, 0f, -sizePx)
                                close()
                            }
                            drawPath(
                                path = path,
                                color = config.windColor.copy(alpha = pAlpha * 0.9f),
                                style = Fill
                            )
                            // Soft bright highlight on the edge
                            drawPath(
                                path = path,
                                color = Color.White.copy(alpha = pAlpha * 0.45f),
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5f * density.density)
                            )
                        }
                    }
                    "feather" -> {
                        withTransform({
                            translate(cx, cy)
                            rotate(p.angle)
                        }) {
                            drawOval(
                                color = config.windColor.copy(alpha = pAlpha * 0.35f),
                                topLeft = Offset(-sizePx * 0.22f, -sizePx),
                                size = Size(sizePx * 0.45f, sizePx * 2)
                            )
                            drawLine(
                                color = config.windColor.copy(alpha = pAlpha * 0.7f),
                                start = Offset(0f, -sizePx),
                                end = Offset(0f, sizePx),
                                strokeWidth = 1f * density.density
                            )
                        }
                    }
                    "mist" -> {
                        drawCircle(
                            color = config.windColor.copy(alpha = pAlpha * 0.22f),
                            radius = sizePx * 1.3f,
                            center = Offset(cx, cy)
                        )
                        drawCircle(
                            color = config.windColor.copy(alpha = pAlpha * 0.1f),
                            radius = sizePx * 2.4f,
                            center = Offset(cx, cy)
                        )
                    }
                    "wisp" -> {
                        withTransform({
                            translate(cx, cy)
                            rotate(p.angle)
                        }) {
                            val alphaVal = pAlpha * 0.25f
                            drawOval(
                                color = config.windColor.copy(alpha = alphaVal),
                                topLeft = Offset(-sizePx, -sizePx * 0.45f),
                                size = Size(sizePx * 1.6f, sizePx * 0.9f)
                            )
                            drawOval(
                                color = config.windColor.copy(alpha = alphaVal),
                                topLeft = Offset(-sizePx * 0.25f, -sizePx * 0.65f),
                                size = Size(sizePx * 1.3f, sizePx * 1.3f)
                            )
                        }
                    }
                    "magical" -> {
                        withTransform({
                            translate(cx, cy)
                            rotate(p.angle)
                        }) {
                            val path = Path().apply {
                                moveTo(0f, -sizePx)
                                quadraticTo(0f, 0f, sizePx, 0f)
                                quadraticTo(0f, 0f, 0f, sizePx)
                                quadraticTo(0f, 0f, -sizePx, 0f)
                                quadraticTo(0f, 0f, 0f, -sizePx)
                                close()
                            }
                            drawPath(
                                path = path,
                                color = config.windColor.copy(alpha = pAlpha),
                                style = Fill
                            )
                        }
                    }
                    "ember" -> {
                        drawCircle(
                            color = config.windColor.copy(alpha = pAlpha),
                            radius = sizePx * 0.35f,
                            center = Offset(cx, cy)
                        )
                        drawCircle(
                            color = Color(0xFFFF8F00).copy(alpha = pAlpha * 0.32f),
                            radius = sizePx * 1.15f,
                            center = Offset(cx, cy)
                        )
                    }
                }
            }
        }
    }
}

// Runs the online-cover migration at most once per app process.
private object CoverFetchSession {
    @Volatile var done = false
}
