/*
 * =============================================================================
 * CompanionPropArt.kt - the twenty props, drawn.
 * Package: com.lorelight.companion
 *
 * WHERE THESE LAND
 *
 * Every function here is handed the body's centre and radius and draws in that
 * frame. The face landmark constants below are copied from CelestialBody's own
 * drawFace, so spectacles sit on the eyes and a moustache sits under the nose
 * rather than near them. If that file ever moves an eye, change these too --
 * they are the only coupling between the two files and there is no way to
 * share them without editing CelestialBody, which is off limits.
 *
 * WHY IT IS ALL BLOCKS AND LINES
 *
 * The app ships zero image assets and that is not going to change for a hat.
 * Every prop is rectangles, circles, arcs and lines. The stepped-block look of
 * the spectacles and the hats is deliberate rather than a limitation: it reads
 * as a knowingly chunky prop instead of a bad drawing.
 *
 * ALLOCATION
 *
 * Offset, Size, Color and CornerRadius are inline value classes, so the vast
 * majority of this file allocates nothing per frame. Stroke is a real object;
 * the few functions that need one build it once at the top and reuse it.
 *
 * `appear` is the entry/exit envelope, 0 to 1. Props use it differently on
 * purpose -- glasses drop in from above, arms grow out of the body, a halo
 * fades. A prop that only faded would look pasted on.
 * =============================================================================
 */
package com.lorelight.companion

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import kotlin.math.abs
import kotlin.math.sin

/* =========================================================================
 * FACE LANDMARKS - mirrored from CelestialBody.drawFace, all as fractions
 * of the body radius.
 * =======================================================================*/

private const val EYE_DX = 0.36f      // eye centre, horizontal offset
private const val EYE_Y = -0.10f      // eye centre, vertical offset
private const val MOUTH_Y = 0.34f     // mouth line
private const val JAW_Y = 0.62f       // bottom of the face area

/* =========================================================================
 * THE DISPATCHER
 * =======================================================================*/

/**
 * Draws one prop over the body.
 *
 * @param center body centre, which is the centre of the puck box
 * @param r body radius
 * @param appear entry/exit envelope, 0..1
 * @param seconds elapsed time, for props that keep moving while held
 * @param ink the near-black outline colour; must contrast with the body
 * @param glow the accent colour, used for flame, glass and halos
 */
internal fun DrawScope.drawCompanionProp(
    prop: CompanionProp,
    center: Offset,
    r: Float,
    appear: Float,
    seconds: Float,
    ink: Color,
    glow: Color
) {
    if (appear <= 0.002f) return

    when (prop) {
        CompanionProp.SPECTACLES -> drawSpectacles(center, r, appear, ink, glow)
        CompanionProp.SUNGLASSES -> drawSunglasses(center, r, appear, ink, glow)
        CompanionProp.MONOCLE -> drawMonocle(center, r, appear, ink, glow)
        CompanionProp.MOUSTACHE -> drawMoustache(center, r, appear, ink)
        CompanionProp.BEARD -> drawBeard(center, r, appear, ink)
        CompanionProp.TOP_HAT -> drawTopHat(center, r, appear, ink, glow)
        CompanionProp.PARTY_HAT -> drawPartyHat(center, r, appear, seconds, ink, glow)
        CompanionProp.WIZARD_HAT -> drawWizardHat(center, r, appear, ink, glow)
        CompanionProp.LANTERN -> drawLantern(center, r, appear, seconds, ink, glow)
        CompanionProp.HALO -> drawHalo(center, r, appear, seconds, glow)
        CompanionProp.RAIN_CLOUD -> drawRainCloud(center, r, appear, seconds, ink)
        CompanionProp.SWEAT_BEAD -> drawSweatBead(center, r, appear, seconds, glow)
        CompanionProp.ZZZ -> drawZzz(center, r, appear, seconds, ink)
        CompanionProp.SCARF -> drawScarf(center, r, appear, seconds, ink, glow)
    }
}

/* =========================================================================
 * WORN ON THE FACE
 * =======================================================================*/

private fun DrawScope.drawSpectacles(c: Offset, r: Float, a: Float, ink: Color, glow: Color) {
    // Drops in from above rather than fading: you see them land.
    val drop = (1f - a) * r * 1.60f
    val eyeY = c.y + EYE_Y * r - drop
    val dx = EYE_DX * r
    val half = r * 0.30f
    val bar = r * 0.085f
    val paint = ink.copy(alpha = a)

    for (side in -1..1 step 2) {
        val ex = c.x + side * dx
        // A square ring built from four blocks. Stepped on purpose.
        drawRect(paint, Offset(ex - half, eyeY - half), Size(half * 2f, bar))
        drawRect(paint, Offset(ex - half, eyeY + half - bar), Size(half * 2f, bar))
        drawRect(paint, Offset(ex - half, eyeY - half), Size(bar, half * 2f))
        drawRect(paint, Offset(ex + half - bar, eyeY - half), Size(bar, half * 2f))
        // A whisper of glass so the lens is not a hole.
        drawRect(
            glow.copy(alpha = a * 0.18f),
            Offset(ex - half + bar, eyeY - half + bar),
            Size((half - bar) * 2f, (half - bar) * 2f)
        )
    }

    // Bridge across the nose, and a temple bar out to each side.
    drawRect(paint, Offset(c.x - dx + half - bar, eyeY - bar * 0.5f), Size((dx - half) * 2f + bar * 2f, bar))
    drawRect(paint, Offset(c.x - dx - half - r * 0.28f, eyeY - bar * 0.5f), Size(r * 0.28f, bar))
    drawRect(paint, Offset(c.x + dx + half, eyeY - bar * 0.5f), Size(r * 0.28f, bar))
}

private fun DrawScope.drawSunglasses(c: Offset, r: Float, a: Float, ink: Color, glow: Color) {
    val drop = (1f - a) * r * 1.9f
    val eyeY = c.y + EYE_Y * r - drop
    val dx = EYE_DX * r
    val lensW = r * 0.62f
    val lensH = r * 0.46f
    val bar = r * 0.08f
    val paint = ink.copy(alpha = a)

    for (side in -1..1 step 2) {
        val ex = c.x + side * dx
        drawRoundRect(
            paint,
            Offset(ex - lensW / 2f, eyeY - lensH / 2f),
            Size(lensW, lensH),
            CornerRadius(r * 0.10f)
        )
        // One highlight streak. Without it the lenses read as two dark holes.
        // Struck in the accent rather than white: no hardcoded colours here,
        // and the accent is bright enough in both schemes to read as a glint.
        drawLine(
            glow.copy(alpha = a * 0.42f),
            Offset(ex - lensW * 0.28f, eyeY + lensH * 0.16f),
            Offset(ex + lensW * 0.10f, eyeY - lensH * 0.20f),
            r * 0.05f,
            StrokeCap.Round
        )
    }
    drawRect(paint, Offset(c.x - dx, eyeY - bar * 0.5f), Size(dx * 2f, bar))
    drawRect(paint, Offset(c.x - dx - lensW / 2f - r * 0.26f, eyeY - bar * 0.5f), Size(r * 0.26f, bar))
    drawRect(paint, Offset(c.x + dx + lensW / 2f, eyeY - bar * 0.5f), Size(r * 0.26f, bar))
}

private fun DrawScope.drawMonocle(c: Offset, r: Float, a: Float, ink: Color, glow: Color) {
    val ring = Stroke(width = r * 0.075f)
    val eyeY = c.y + EYE_Y * r
    val ex = c.x + EYE_DX * r
    val rad = r * 0.32f * a

    drawCircle(glow.copy(alpha = a * 0.16f), rad, Offset(ex, eyeY))
    drawCircle(ink.copy(alpha = a), rad, Offset(ex, eyeY), style = ring)

    // A chain of three short links drooping off toward the body edge.
    var from = Offset(ex + rad * 0.72f, eyeY + rad * 0.72f)
    for (i in 0 until 3) {
        val to = Offset(from.x + r * 0.12f, from.y + r * 0.17f)
        drawLine(ink.copy(alpha = a * 0.85f), from, to, r * 0.035f, StrokeCap.Round)
        from = to
    }
}

private fun DrawScope.drawMoustache(c: Offset, r: Float, a: Float, ink: Color) {
    // Sits ABOVE the mouth line, which is the difference between a moustache
    // and a very odd chin.
    val y = c.y + (MOUTH_Y - 0.16f) * r
    val wing = r * 0.40f * a
    val thick = Stroke(width = r * 0.13f, cap = StrokeCap.Round)
    val paint = ink.copy(alpha = a)

    for (side in -1..1 step 2) {
        // Each wing is a quarter arc curling down and out from the centre.
        val left = if (side < 0) c.x - wing else c.x
        drawArc(
            color = paint,
            startAngle = if (side < 0) 200f else 300f,
            sweepAngle = 60f,
            useCenter = false,
            topLeft = Offset(left, y - r * 0.10f),
            size = Size(wing, r * 0.34f),
            style = thick
        )
    }
    // The centre knot ties the two wings into one object.
    drawCircle(paint, r * 0.075f, Offset(c.x, y + r * 0.05f))
}

private fun DrawScope.drawBeard(c: Offset, r: Float, a: Float, ink: Color) {
    val jaw = c.y + JAW_Y * r
    val paint = ink.copy(alpha = a)
    val spread = r * 0.62f

    // The mass: a filled half-disc hanging off the jaw, scaled by `appear` so
    // it visibly grows rather than appearing whole.
    drawArc(
        color = paint,
        startAngle = 0f,
        sweepAngle = 180f,
        useCenter = true,
        topLeft = Offset(c.x - spread, jaw - r * 0.24f),
        size = Size(spread * 2f, (r * 0.86f) * a + r * 0.24f)
    )
    // Strands, longest in the middle, to break the silhouette.
    for (i in -3..3) {
        val x = c.x + i * (spread / 3.4f)
        val len = (r * 0.34f - kotlin.math.abs(i) * r * 0.055f) * a
        drawLine(
            paint,
            Offset(x, jaw + (r * 0.60f) * a),
            Offset(x, jaw + (r * 0.60f) * a + len),
            r * 0.065f,
            StrokeCap.Round
        )
    }
}

/* =========================================================================
 * WORN ON THE HEAD
 * =======================================================================*/

private fun DrawScope.drawTopHat(c: Offset, r: Float, a: Float, ink: Color, glow: Color) {
    val drop = (1f - a) * r * 2.0f
    val brimY = c.y - r * 0.74f - drop
    val paint = ink.copy(alpha = a)

    drawRoundRect(
        paint,
        Offset(c.x - r * 0.78f, brimY),
        Size(r * 1.56f, r * 0.14f),
        CornerRadius(r * 0.07f)
    )
    val crownH = r * 0.62f
    drawRect(paint, Offset(c.x - r * 0.44f, brimY - crownH), Size(r * 0.88f, crownH))
    // The band. One accent stripe is what says top hat rather than chimney.
    drawRect(
        glow.copy(alpha = a * 0.85f),
        Offset(c.x - r * 0.44f, brimY - crownH * 0.34f),
        Size(r * 0.88f, r * 0.11f)
    )
}

private fun DrawScope.drawPartyHat(c: Offset, r: Float, a: Float, s: Float, ink: Color, glow: Color) {
    val drop = (1f - a) * r * 2.0f
    val baseY = c.y - r * 0.72f - drop
    val steps = 6
    val coneH = r * 0.82f
    val halfW = r * 0.46f

    // Stacked shrinking blocks. A smooth triangle would need a Path; the
    // stepped version matches the spectacles and costs nothing.
    for (i in 0 until steps) {
        val f = i / steps.toFloat()
        val w = halfW * (1f - f)
        val y = baseY - coneH * f
        val h = coneH / steps + 1f
        val tint = if (i % 2 == 0) glow else ink
        drawRect(tint.copy(alpha = a * 0.92f), Offset(c.x - w, y - h), Size(w * 2f, h))
    }
    drawCircle(glow.copy(alpha = a), r * 0.11f, Offset(c.x, baseY - coneH - r * 0.06f))

    // Confetti: four ticks drifting down on staggered phases.
    for (i in 0 until 4) {
        val phase = (s * 0.55f + i * 0.25f) % 1f
        val x = c.x + (i - 1.5f) * r * 0.52f
        val y = baseY - coneH * 0.4f + phase * r * 1.7f
        val fade = (1f - phase) * a * 0.8f
        drawRect(
            (if (i % 2 == 0) glow else ink).copy(alpha = fade),
            Offset(x, y),
            Size(r * 0.09f, r * 0.14f)
        )
    }
}

private fun DrawScope.drawWizardHat(c: Offset, r: Float, a: Float, ink: Color, glow: Color) {
    val drop = (1f - a) * r * 2.1f
    val brimY = c.y - r * 0.76f - drop
    val paint = ink.copy(alpha = a)

    drawRoundRect(
        paint,
        Offset(c.x - r * 0.96f, brimY),
        Size(r * 1.92f, r * 0.13f),
        CornerRadius(r * 0.065f)
    )
    // Leaning cone: the lean is what separates a wizard from a traffic cone.
    rotate(degrees = -13f, pivot = Offset(c.x, brimY)) {
        val steps = 7
        val coneH = r * 1.02f
        val halfW = r * 0.44f
        for (i in 0 until steps) {
            val f = i / steps.toFloat()
            val w = halfW * (1f - f * 0.92f)
            val y = brimY - coneH * f
            val h = coneH / steps + 1f
            drawRect(paint, Offset(c.x - w, y - h), Size(w * 2f, h))
        }
        drawRect(
            glow.copy(alpha = a * 0.9f),
            Offset(c.x - halfW * 0.94f, brimY - coneH * 0.16f),
            Size(halfW * 1.88f, r * 0.11f)
        )
    }
}

/* =========================================================================
 * BESIDE AND ABOVE
 * =======================================================================*/

private fun DrawScope.drawLantern(c: Offset, r: Float, a: Float, s: Float, ink: Color, glow: Color) {
    val paint = ink.copy(alpha = a)
    val hangX = c.x + r * 1.28f
    val topY = c.y - r * 0.70f
    // A slow sway, as if it were actually hanging from something.
    val sway = sin(s * 1.5f) * r * 0.07f * a
    val bodyY = topY + r * 0.60f * a
    val bx = hangX + sway

    drawLine(paint, Offset(hangX, topY - r * 0.22f), Offset(bx, bodyY - r * 0.14f), r * 0.045f, StrokeCap.Round)
    drawCircle(paint, r * 0.075f, Offset(bx, bodyY - r * 0.16f), style = Stroke(width = r * 0.035f))

    val w = r * 0.34f * a
    val h = r * 0.46f * a
    // Warm spill first, so the glass looks lit rather than painted.
    val flicker = 0.82f + 0.18f * sin(s * 11.3f) * sin(s * 4.1f)
    drawCircle(glow.copy(alpha = a * 0.20f * flicker), w * 2.6f, Offset(bx, bodyY + h * 0.5f))
    drawRoundRect(
        glow.copy(alpha = a * 0.55f * flicker),
        Offset(bx - w / 2f, bodyY),
        Size(w, h),
        CornerRadius(r * 0.06f)
    )
    // Cage: top plate, bottom plate, two uprights.
    drawRect(paint, Offset(bx - w * 0.62f, bodyY - r * 0.05f), Size(w * 1.24f, r * 0.06f))
    drawRect(paint, Offset(bx - w * 0.62f, bodyY + h), Size(w * 1.24f, r * 0.06f))
    drawLine(paint, Offset(bx - w / 2f, bodyY), Offset(bx - w / 2f, bodyY + h), r * 0.035f)
    drawLine(paint, Offset(bx + w / 2f, bodyY), Offset(bx + w / 2f, bodyY + h), r * 0.035f)
    // The flame itself: two stacked circles, the upper one jittering.
    val fy = bodyY + h * 0.62f
    drawCircle(glow.copy(alpha = a * 0.95f), w * 0.26f * flicker, Offset(bx, fy))
    drawCircle(glow.copy(alpha = a * 0.70f), w * 0.17f * flicker, Offset(bx, fy - w * 0.26f * flicker))
}

private fun DrawScope.drawHalo(c: Offset, r: Float, a: Float, s: Float, glow: Color) {
    val bobY = sin(s * 1.9f) * r * 0.05f
    val y = c.y - r * 0.94f + bobY
    val rx = r * 0.56f * a
    val ry = r * 0.17f * a
    // Two rings: a soft wide one for the glow, a crisp one for the shape.
    drawArc(
        color = glow.copy(alpha = a * 0.22f),
        startAngle = 0f, sweepAngle = 360f, useCenter = false,
        topLeft = Offset(c.x - rx * 1.18f, y - ry * 1.5f),
        size = Size(rx * 2.36f, ry * 3f),
        style = Stroke(width = r * 0.14f)
    )
    drawArc(
        color = glow.copy(alpha = a * 0.92f),
        startAngle = 0f, sweepAngle = 360f, useCenter = false,
        topLeft = Offset(c.x - rx, y - ry),
        size = Size(rx * 2f, ry * 2f),
        style = Stroke(width = r * 0.055f)
    )
}

private fun DrawScope.drawRainCloud(c: Offset, r: Float, a: Float, s: Float, ink: Color) {
    val drop = (1f - a) * r * 1.2f
    val y = c.y - r * 0.98f - drop
    val paint = ink.copy(alpha = a * 0.88f)

    // Three overlapping discs read as a cloud far better than one lozenge.
    drawCircle(paint, r * 0.26f, Offset(c.x - r * 0.30f, y + r * 0.04f))
    drawCircle(paint, r * 0.34f, Offset(c.x, y - r * 0.04f))
    drawCircle(paint, r * 0.24f, Offset(c.x + r * 0.31f, y + r * 0.05f))
    drawRoundRect(
        paint,
        Offset(c.x - r * 0.46f, y + r * 0.02f),
        Size(r * 0.92f, r * 0.20f),
        CornerRadius(r * 0.10f)
    )

    // Rain on three staggered phases so it never marches in step.
    for (i in 0 until 3) {
        val phase = (s * 1.5f + i * 0.33f) % 1f
        val x = c.x + (i - 1) * r * 0.30f
        val ry = y + r * 0.24f + phase * r * 0.60f
        drawLine(
            ink.copy(alpha = a * (1f - phase) * 0.85f),
            Offset(x, ry),
            Offset(x, ry + r * 0.14f),
            r * 0.045f,
            StrokeCap.Round
        )
    }
}

private fun DrawScope.drawSweatBead(c: Offset, r: Float, a: Float, s: Float, glow: Color) {
    // Runs down the temple on a loop, so it reads as sweating rather than as
    // a bead stuck to the face.
    val phase = (s * 0.65f) % 1f
    val x = c.x + r * 0.74f
    val y = c.y - r * 0.34f + phase * r * 0.70f
    val fade = a * (1f - phase * 0.55f)
    val rad = r * 0.10f

    drawCircle(glow.copy(alpha = fade * 0.85f), rad, Offset(x, y))
    // The tail: a narrowing tick above the bead.
    drawLine(
        glow.copy(alpha = fade * 0.55f),
        Offset(x, y - rad * 1.7f),
        Offset(x, y - rad * 0.4f),
        rad * 0.7f,
        StrokeCap.Round
    )
    // Specular dot, again in the accent rather than a hardcoded white.
    drawCircle(glow.copy(alpha = fade * 0.55f), rad * 0.30f, Offset(x - rad * 0.3f, y - rad * 0.3f))
}

private fun DrawScope.drawZzz(c: Offset, r: Float, a: Float, s: Float, ink: Color) {
    // Three block Zs rising and fading on staggered phases.
    for (i in 0 until 3) {
        val phase = (s * 0.42f + i * 0.34f) % 1f
        val size = r * (0.16f + i * 0.05f)
        val x = c.x + r * 0.68f + i * r * 0.24f
        val y = c.y - r * 0.52f - phase * r * 1.05f
        val alpha = a * (1f - phase) * 0.9f
        val w = size
        val t = size * 0.24f
        val paint = ink.copy(alpha = alpha)
        drawRect(paint, Offset(x, y), Size(w, t))
        drawRect(paint, Offset(x, y + w - t), Size(w, t))
        drawLine(paint, Offset(x + w, y + t), Offset(x, y + w - t), t, StrokeCap.Butt)
    }
}

private fun DrawScope.drawScarf(c: Offset, r: Float, a: Float, s: Float, ink: Color, glow: Color) {
    val y = c.y + r * 0.66f
    val band = r * 0.19f
    val paint = glow.copy(alpha = a * 0.92f)

    drawRoundRect(
        paint,
        Offset(c.x - r * 0.72f * a, y),
        Size(r * 1.44f * a, band),
        CornerRadius(r * 0.09f)
    )
    // Two stripes for weave, then a tail that lifts on a slow breeze.
    for (i in 0 until 2) {
        drawRect(
            ink.copy(alpha = a * 0.28f),
            Offset(c.x - r * 0.34f + i * r * 0.42f, y),
            Size(r * 0.09f, band)
        )
    }
    val lift = sin(s * 1.7f) * 10f
    rotate(degrees = lift, pivot = Offset(c.x + r * 0.58f, y + band)) {
        drawRoundRect(
            paint,
            Offset(c.x + r * 0.48f, y + band * 0.6f),
            Size(band * 0.92f, r * 0.62f * a),
            CornerRadius(r * 0.07f)
        )
    }
}
