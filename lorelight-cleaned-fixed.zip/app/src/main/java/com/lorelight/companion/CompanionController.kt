/*
 * =============================================================================
 * CompanionController.kt - the one file the rest of the app talks to.
 * Package: com.lorelight.companion
 *
 * Everything else in this package is deliberately ignorant of Lorelight. This
 * file is the seam: it owns the state, exposes a handful of plain methods the
 * app can call when something happens, and renders the bubble.
 *
 * HOW THE APP USES IT (three things, nothing more):
 *
 *   val companion = rememberCompanionState(versionCode)
 *   CompanionHost(companion, faceState, isLightTheme, reduceMotion)
 *   companion?.onMangaAdded(title)          // ...and friends
 *
 * THE RULES THIS FILE ENFORCES
 *
 *  - ONE bubble at a time. A line arriving while he is already speaking is
 *    DISCARDED, never queued.
 *  - He never speaks over a moving screen. A granted line waits for the list
 *    to be still, and if the user stays busy for 10 seconds the line is
 *    thrown away rather than saved.
 *  - The daily cap is only charged when a bubble actually reaches the screen,
 *    so a line lost to the stillness gate costs the user nothing.
 *  - The tap on the puck is the theme toggle and stays instant. The bubble
 *    never intercepts touches; it just gets out of the way.
 * =============================================================================
 */
package com.lorelight.companion

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.platform.LocalContext
import com.lorelight.ui.theme.modeswitch.celestial.CelestialFaceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** How often the ambient check runs. Cheap: a few comparisons. */
private const val AMBIENT_POLL_MS = 60_000L

/** Granularity of the stillness wait. */
private const val STILLNESS_POLL_MS = 250L

class CompanionState internal constructor(
    private val scope: CoroutineScope,
    private val corpus: CompanionCorpus,
    private val assembler: LineAssembler,
    private val detector: CompanionDetector,
    private val governor: CompanionGovernor,
    private val hints: HintLadder,
    /** Owns the visible prop and the rationing that keeps props rare. */
    val props: CompanionPropState,
    private val appVersionCode: Int
) {

    /** The line currently on screen, or null for silence. */
    var line by mutableStateOf<CompanionLine?>(null)
        private set

    /**
     * A propless reaction waiting to play, or null.
     *
     * Gestures and speech both drive the face, so they can never run at once.
     * Speech wins: the host plays a gesture only while he is silent, and
     * cancels one the moment a line arrives.
     */
    var gesture by mutableStateOf<CompanionGesture?>(null)
        private set

    /** Which character is up. Kept in sync with the live theme by the host. */
    var mood: Mood = Mood.SUN
        internal set

    /** Where the user is. Some lines are browse-only. */
    var surface: CompanionSurface = CompanionSurface.BROWSE

    /** Facts the detector is allowed to know. Update this whenever they change. */
    var signals: CompanionSignals = CompanionSignals()

    /**
     * True while the tab shell is what the user is actually looking at.
     *
     * He is drawn on the altar beside the sun/moon toggle, and that altar
     * only exists on Library, History, Browse and Settings. A line spoken
     * while a reader or a details page is covering the screen is a line
     * nobody sees, and it still burns the daily cap and the cooldown -- so
     * the newest one is held instead and delivered on the way back.
     */
    var onScreen: Boolean = true
        private set

    private var pendingCandidates: List<Candidate>? = null
    private var pendingCurated: CompanionLine? = null
    private var pendingAt: Long = 0L

    /** Fail-safe timer for a line whose bubble never reports back. */
    private var watchdog: kotlinx.coroutines.Job? = null

    /**
     * How long a held line stays worth saying. Surfacing "nice pick" an hour
     * later, about a book already half read, is worse than silence.
     */
    private val pendingMaxAgeMs: Long = 10 * 60 * 1000L

    private var lastMotionAt: Long = 0L
    private var speaking = false
    private val sessionStartAt: Long = System.currentTimeMillis()

    /* =====================================================================
     * THINGS THE APP TELLS HIM
     * ===================================================================*/

    /**
     * Tells him whether his own screen is the one being shown. Called from
     * MainActivity on every navigation.
     *
     * Switching this off also clears anything mid-sentence. The bubble is out
     * of view the instant the reader opens, and leaving [line] set would
     * block every later line for good, because he speaks strictly one at a
     * time and only the host's finish timer ever clears it.
     */
    fun setOnScreen(visible: Boolean) {
        if (onScreen == visible) return
        onScreen = visible

        if (!visible) {
            watchdog?.cancel()
            line = null
            speaking = false
            return
        }

        val curated = pendingCurated
        val candidates = pendingCandidates
        val heldFor = System.currentTimeMillis() - pendingAt
        pendingCurated = null
        pendingCandidates = null
        pendingAt = 0L

        if (heldFor > pendingMaxAgeMs) return
        when {
            curated != null -> speakCurated(curated)
            candidates != null -> offer(candidates)
        }
    }

    /** Call on any scroll or fling. Keeps him from talking over movement. */
    fun noteMotion() {
        lastMotionAt = System.currentTimeMillis()
    }

    fun onNovelAdded(title: String) = offer(
        Candidate(CompanionEvent.NOVEL_ADDED, LineParams(title = title))
    )

    fun onMangaAdded(title: String) = offer(
        Candidate(CompanionEvent.MANGA_ADDED, LineParams(title = title))
    )

    fun onChapterFinished(chapterNumber: Int? = null) = offer(
        Candidate(CompanionEvent.CHAPTER_DONE, LineParams(n = chapterNumber))
    )

    /**
     * Call when the user taps the sun/moon.
     *
     * The very first tap ever earns the payoff line, which outranks the
     * ordinary theme-switch comment that one time - it is the punchline to
     * five launches of hints, and it must never be lost to a dice roll.
     *
     * @param nowLight the theme the app is switching TO.
     */
    fun onThemeToggled(nowLight: Boolean) {
        val newMood = Mood.forTheme(nowLight)

        // A tap always clears whatever he was saying: the toggle is the
        // user's action and it wins, instantly.
        val wasSpeaking = line != null
        dismiss()

        val firstEver = hints.noteToggled()

        if (firstEver) {
            hints.payoffLine(newMood)?.let { speakCurated(it) }
            return
        }

        // A toggle that cancelled a line in progress does not immediately
        // start another one - that would read as him talking over himself.
        if (wasSpeaking) return

        offer(Candidate(CompanionEvent.MODE_SWITCHED))
    }

    /** The user tapped, or otherwise dismissed him. Instant. */
    fun dismiss() {
        line = null
    }

    /* ---------------------------------------------------------------------
     * REACTIONS WITH NO WORDS
     *
     * These skip the whole line pipeline. There is no dice roll and no daily
     * cap, because a gesture costs nothing and silence is not a reward: if a
     * page fails to load he should wince every single time.
     * -------------------------------------------------------------------*/

    /**
     * Plays a body-language beat. Ignored while he is speaking, since the
     * mouth cannot follow two scripts at once.
     */
    fun performGesture(g: CompanionGesture) {
        if (line != null) return
        gesture = g
    }

    /** A chapter or page would not load. He winces, and it may start raining. */
    fun onLoadFailed() {
        performGesture(CompanionGesture.WINCE)
        props.forceShow(CompanionProp.RAIN_CLOUD, mood, System.currentTimeMillis())
    }

    /** The same chapter has been opened over and over. Fond exasperation. */
    fun onRepeatedReopen() {
        performGesture(CompanionGesture.EYE_ROLL)
    }

    /** A whole novel finished. The one moment that earns the moustache. */
    fun onNovelFinished() {
        performGesture(CompanionGesture.HOP)
        props.forceShow(CompanionProp.MOUSTACHE, mood, System.currentTimeMillis())
    }

    /** The unread pile has got out of hand. */
    fun onUnreadPiledUp() {
        performGesture(CompanionGesture.LOOK_AWAY)
        props.forceShow(CompanionProp.SWEAT_BEAD, mood, System.currentTimeMillis())
    }

    /** Called by the host once a gesture has played out or been cancelled. */
    internal fun clearGesture() {
        gesture = null
    }

    /* =====================================================================
     * INTERNAL PIPELINE
     * ===================================================================*/

    /**
     * Offers one or more candidates. At most one line can result, and it may
     * well be silence - which is the normal outcome.
     */
    internal fun offer(vararg candidates: Candidate) = offer(candidates.toList())

    internal fun offer(candidates: List<Candidate>) {
        if (candidates.isEmpty()) return

        // SURFACE GATE. Off his own screen there is no bubble to put the words
        // in, so keep the newest offer and let it land on the way back. This
        // is the one thing that IS queued, because adding a book from inside a
        // source page is exactly when he most has something to say.
        if (!onScreen) {
            pendingCandidates = candidates
            pendingCurated = null
            pendingAt = System.currentTimeMillis()
            return
        }

        // One bubble at a time. Anything arriving now is dropped, not queued.
        if (line != null || speaking) return

        scope.launch {
            val now = System.currentTimeMillis()
            val winner = governor.choose(candidates, now, surface) ?: return@launch

            val built = assembler.assemble(winner.event, mood, winner.params) ?: return@launch

            // He was granted a line. Now wait for a still screen - and give
            // up entirely if the user stays busy.
            if (!awaitStillness()) return@launch
            if (line != null || speaking) return@launch

            noteSideEffects(winner)
            show(built)
        }
    }

    /** Hint-ladder and payoff lines: curated, and they skip the dice. */
    private fun speakCurated(curated: CompanionLine) {
        // Same surface gate as offer(). A launch greeting earned while the app
        // resumed straight into a reader is worth holding for a few minutes.
        if (!onScreen) {
            pendingCurated = curated
            pendingCandidates = null
            pendingAt = System.currentTimeMillis()
            return
        }
        if (line != null || speaking) return
        scope.launch {
            if (!awaitStillness()) return@launch
            show(curated)
        }
    }

    private fun show(built: CompanionLine) {
        speaking = true
        line = built

        // The prop rides along with the words rather than instead of them. It
        // draws on its own overlay layer above the body, so it never competes
        // with the talking face for control -- he can wave and speak at once.
        built.event?.let { props.offer(it, mood, System.currentTimeMillis()) }

        // WATCHDOG. "Finished" is reported by the bubble itself, so if the
        // host is not composed for any reason that report never arrives and
        // he is stuck mid-sentence forever, dropping every later line on the
        // floor. The surface gate should now make that impossible; this is
        // here so that if it ever happens again it costs one line instead of
        // the whole session.
        watchdog?.cancel()
        watchdog = scope.launch {
            delay(SPEAKING_WATCHDOG_MS)
            if (line === built) {
                line = null
                speaking = false
            }
        }
    }

    /**
     * Records the side effects of a line that is about to be spoken - the
     * once-ever milestone, the per-title nag cooldown.
     */
    private fun noteSideEffects(winner: Candidate) {
        val now = System.currentTimeMillis()
        when (winner.event) {
            CompanionEvent.LIBRARY_GROWING ->
                winner.params.n?.let { detector.noteMilestoneSpoken(it) }
            CompanionEvent.UNFINISHED_WAITING ->
                winner.params.title?.let { detector.noteTitleNagged(it, now) }
            else -> Unit
        }
    }

    /**
     * Waits for the screen to be still.
     *
     * @return true if it went still in time, false if the line should be
     *         thrown away. It is never re-rolled and never queued: if the
     *         user was busy, the moment has simply passed.
     */
    private suspend fun awaitStillness(): Boolean {
        val deadline = System.currentTimeMillis() + CompanionPolicy.STILLNESS_RETRY_WINDOW_MS

        while (System.currentTimeMillis() < deadline) {
            val quietFor = System.currentTimeMillis() - lastMotionAt
            if (lastMotionAt == 0L || quietFor >= CompanionPolicy.STILLNESS_MS) return true
            delay(STILLNESS_POLL_MS)
        }
        return false
    }

    /* --- called by the host as the bubble lives and dies ------------------ */

    /**
     * The bubble is now actually visible. THIS is the moment that counts
     * against the daily cap and starts the global cooldown - not the earlier
     * decision to speak, which might have been thrown away.
     */
    internal fun onAppeared() {
        governor.noteSpoken(System.currentTimeMillis())
    }

    internal fun onFinished() {
        watchdog?.cancel()
        speaking = false
        line = null
    }

    /* =====================================================================
     * THE AUTONOMOUS BEHAVIOUR
     * ===================================================================*/

    /**
     * The arrival moment: he waits for the screen to settle, then either
     * teaches you about the toggle or greets you - never both, because two
     * lines at launch is exactly the behaviour that makes people uninstall.
     */
    internal suspend fun runArrival() {
        val now = System.currentTimeMillis()

        // Read the gap BEFORE stamping this visit, or it is always zero.
        val arrival = detector.arrivalCandidate(now)
        detector.noteSeen(now)

        delay(CompanionPolicy.ARRIVAL_DELAY_MS)

        // The hint ladder speaks first while it is still running: on those
        // early launches, teaching the toggle matters more than a greeting.
        val hint = hints.nextHint(mood)
        if (hint != null) {
            speakCurated(hint)
            return
        }

        arrival?.let { offer(it) }
    }

    /** The quiet, occasional musings. Mostly this decides to say nothing. */
    internal suspend fun runAmbientLoop() {
        while (true) {
            delay(AMBIENT_POLL_MS)

            val now = System.currentTimeMillis()
            val withSession = CompanionSignals(
                libraryCount = signals.libraryCount,
                streakDays = signals.streakDays,
                sessionStartAt = if (signals.sessionStartAt > 0L) signals.sessionStartAt
                else sessionStartAt,
                surface = surface,
                unfinished = signals.unfinished
            )

            offer(detector.ambientCandidates(now, withSession))
        }
    }

    /**
     * Props, on their own clock.
     *
     * Deliberately a separate loop from the ambient line loop. Speech and
     * props are different channels: he can be wearing a hat while saying
     * nothing at all, and that is most of the charm. Hanging props off lines
     * is exactly what made them invisible, because it meant a prop needed a
     * rare event AND a dice roll AND a six-hour window to line up at once.
     */
    internal suspend fun runRandomPropLoop() {
        // The first prop of a session is CERTAIN, not rolled. Props have now
        // been reported invisible twice, and both times the wiring was intact
        // -- it was the odds. A guaranteed opener also makes the feature
        // falsifiable: if nothing shows a few seconds after launch, the fault
        // is in the drawing, not in the scheduling.
        delay(PROP_FIRST_DELAY_MS)

        // Hold the guaranteed first prop until he is on screen, or it is spent
        // on a reader session and looks like it never fired at all. Capped, so
        // a long reading session cannot make it wait forever.
        var waitedTicks = 0
        while (!onScreen && waitedTicks < 30) {
            delay(1_000L)
            waitedTicks++
        }
        if (onScreen) {
            props.offerRandom(mood, System.currentTimeMillis(), certain = true)
        }

        while (true) {
            delay(PROP_RANDOM_POLL_MS)
            if (onScreen) props.offerRandom(mood, System.currentTimeMillis())
        }
    }
}

/* =========================================================================
 * COMPOSABLE ENTRY POINTS
 * =======================================================================*/

/**
 * Builds the companion, loading its 24KB corpus off the main thread.
 *
 * Returns null until the corpus is ready. The caller should simply render
 * nothing in that window - it is a few milliseconds and he is not supposed to
 * say anything for the first few seconds anyway.
 */
@Composable
fun rememberCompanionState(appVersionCode: Int): CompanionState? {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var state by remember { mutableStateOf<CompanionState?>(null) }

    LaunchedEffect(Unit) {
        val built = withContext(Dispatchers.IO) {
            buildCompanion(context, scope, appVersionCode)
        }
        state = built
    }
    return state
}

/** Constructed off the main thread. Parsing JSON is the expensive part. */
private fun buildCompanion(
    context: Context,
    scope: CoroutineScope,
    appVersionCode: Int
): CompanionState? {
    return try {
        val store = PrefsCompanionStore(context)
        val corpus = CompanionCorpus.load(context)
        val bag = ShuffleBag(store)
        val assembler = LineAssembler(corpus, store, bag)
        val hints = HintLadder(store, corpus, assembler)

        hints.onLaunch(appVersionCode)

        CompanionState(
            scope = scope,
            corpus = corpus,
            assembler = assembler,
            detector = CompanionDetector(store),
            governor = CompanionGovernor(store),
            hints = hints,
            props = CompanionPropState(store),
            appVersionCode = appVersionCode
        )
    } catch (t: Throwable) {
        // A missing or malformed corpus must never crash the reader. He
        // simply does not exist this run.
        null
    }
}

/**
 * Renders the bubble and drives the talking face.
 *
 * Place this directly ABOVE the puck in the bottom bar, centred on it. It
 * takes no touches and adds no layout height when he is silent.
 */
@Composable
fun CompanionHost(
    state: CompanionState?,
    faceState: CelestialFaceState,
    isLightTheme: Boolean,
    reduceMotion: Boolean,
    modifier: Modifier = Modifier
) {
    if (state == null) return

    // The mood is never stored - it is read from the live theme, so it can
    // never drift out of sync with what is on screen.
    state.mood = Mood.forTheme(isLightTheme)

    LaunchedEffect(state) { state.runArrival() }
    LaunchedEffect(state) { state.runAmbientLoop() }
    LaunchedEffect(state) { state.runRandomPropLoop() }

    val current = state.line
    val pendingGesture = state.gesture

    // ONE effect owns the face, keyed on both inputs. That is what makes the
    // priority rule airtight: when a line arrives this effect restarts, which
    // cancels any gesture mid-flight -- and playGesture's finally block eases
    // the face back to rest and unpins before speech takes over. Two separate
    // effects would both be writing pinnedSnapshot on alternate frames, which
    // looks exactly as broken as it sounds.
    LaunchedEffect(current, pendingGesture) {
        if (current != null) {
            // The face talks for exactly as long as the words are arriving,
            // so the mouth stops when the sentence does.
            faceState.playTalk(
                mood = current.mood,
                speakMs = speakDurationMs(current.text),
                reduceMotion = reduceMotion
            )
            return@LaunchedEffect
        }
        if (pendingGesture != null) {
            faceState.playGesture(
                gesture = pendingGesture,
                mood = state.mood,
                reduceMotion = reduceMotion
            )
            state.clearGesture()
        }
    }

    // ZERO-SIZE HOST.
    //
    // The bubble is measured normally but the host reports a size of 0x0,
    // so it occupies no space in the bottom bar at all: nothing around it
    // can be moved, resized, re-centred or reflowed by a line appearing,
    // however long that line is. It is painted over the screen rather than
    // inserted into it. A Box could not do this -- a Box takes the size of
    // its child, which is exactly what was nudging the bar.
    //
    // The child is then placed centred on the host's point and sitting on
    // top of it, so the bubble grows upward out of the puck.
    Layout(
        content = {
            CompanionSpeechBox(
                text = current?.text,
                mood = state.mood,
                reduceMotion = reduceMotion,
                onAppeared = { state.onAppeared() },
                onDone = { state.onFinished() }
            )
        },
        modifier = modifier
    ) { measurables, constraints ->
        val bubble = measurables.firstOrNull()?.measure(
            Constraints(maxWidth = constraints.maxWidth)
        )
        layout(0, 0) {
            bubble?.place(-bubble.width / 2, -bubble.height)
        }
    }
}

/**
 * How long the mouth should move: the reveal, plus a beat of the hold.
 *
 * Not the whole hold - he finishes the sentence and then the words sit there
 * for a moment while he is quiet again, which is what real speech looks like.
 */
/** How long a line may sit unfinished before it is force-cleared. */
private const val SPEAKING_WATCHDOG_MS = 15_000L

private fun speakDurationMs(text: String): Long =
    companionRevealDurationMs(text) + MOUTH_TAIL_MS
