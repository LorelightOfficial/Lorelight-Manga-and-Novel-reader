package com.lorelight

import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import kotlinx.coroutines.flow.first
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import com.lorelight.ui.components.LorelightDialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.R
import com.lorelight.core.BackupManager
import com.lorelight.core.CrashReporter
import com.lorelight.core.DiagnosticLogger
import com.lorelight.core.SelfHealingEngine
import com.lorelight.data.model.Novel
import com.lorelight.data.model.isManga
import com.lorelight.data.model.Website
import com.lorelight.data.model.toJSONObject
import com.lorelight.data.model.toNovel
import com.lorelight.data.model.toWebsite
import com.lorelight.data.local.NovelPreferences
import com.lorelight.manga.model.safeTitle
import com.lorelight.manga.model.seedFrom
import com.lorelight.manga.model.sanitizedChapters
import com.lorelight.tts.TtsPlaybackManager
import androidx.compose.animation.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Close
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.zIndex
import com.lorelight.ui.components.resolveFontFamily
import com.lorelight.ui.components.getAppTypography
import com.lorelight.ui.library.LibraryScreen
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lorelight.ui.components.FontManagerScreen
import com.lorelight.ui.library.HistoryScreen
import com.lorelight.ui.library.DetailsScreen
import com.lorelight.ui.library.ComingSoonScreen
import com.lorelight.ui.reader.ReaderViewModel
import com.lorelight.ui.settings.SettingsScreen
import kotlinx.coroutines.launch
import com.lorelight.browse.model.toNovel
import androidx.lifecycle.lifecycleScope
import com.lorelight.ui.theme.*
import com.lorelight.utils.EpubExtractor
import org.json.JSONArray
import org.json.JSONObject
import android.content.Context
import com.lorelight.data.model.getChapterList
import com.lorelight.data.model.getMangaDetails
import com.lorelight.manga.model.toNovel

fun saveNovelsToPrefs(context: Context, novels: List<Novel>) {
    com.lorelight.data.local.NovelPreferences.saveNovelsToPrefs(context, novels)
}

fun saveNovelsToPrefsSync(context: Context, novels: List<Novel>) {
    com.lorelight.data.local.NovelPreferences.saveNovelsToPrefsSync(context, novels)
}

fun saveWebsitesToPrefs(context: Context, websites: List<Website>) {
    com.lorelight.data.local.NovelPreferences.saveWebsitesToPrefs(context, websites)
}

fun saveWebsitesToPrefsSync(context: Context, websites: List<Website>) {
    com.lorelight.data.local.NovelPreferences.saveWebsitesToPrefsSync(context, websites)
}

fun loadWebsitesFromPrefs(context: Context): List<Website> {
    return com.lorelight.data.local.NovelPreferences.loadWebsitesFromPrefs(context)
}

class MainActivity : ComponentActivity() {
    companion object {
        const val EXTRA_OPEN_READER = "extra_open_reader"
        const val EXTRA_OPEN_NEW_CHAPTERS = "extra_open_new_chapters"
        const val EXTRA_TARGET_NOVEL_ID = "extra_target_novel_id"

        // Incremented every time the TTS notification is tapped. The compose
        // layer observes this and pushes the Reader screen.
        val openReaderSignal = kotlinx.coroutines.flow.MutableStateFlow(0)
        val openNewChaptersSignal = kotlinx.coroutines.flow.MutableStateFlow(0)

        // Set when the OS hands us an .epub through "Open with Lorelight" or
        // the share sheet. Handled and opened directly in the reader.
        val pendingEpubUri = kotlinx.coroutines.flow.MutableStateFlow<android.net.Uri?>(null)

        // Light-mode status-bar band (below). It must NOT be painted over the
        // novel or manga reader, both of which draw their own full-bleed
        // backgrounds right up into the inset.
        val readerVisible = androidx.compose.runtime.mutableStateOf(false)

        // Same band, suppressed on the novel details screen. Its hero art is
        // full-bleed and has to run under the clock exactly like it does in
        // dark mode; the band would otherwise cut a flat strip across the top
        // of the image. The artwork's own position is unchanged either way.
        val detailsVisible = androidx.compose.runtime.mutableStateOf(false)

        @Suppress("DEPRECATION")
        fun extractEpubUri(intent: android.content.Intent?): android.net.Uri? {
            if (intent == null) return null
            return when (intent.action) {
                android.content.Intent.ACTION_VIEW -> {
                    intent.data ?: intent.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
                }
                android.content.Intent.ACTION_SEND -> {
                    val streamUri = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(android.content.Intent.EXTRA_STREAM, android.net.Uri::class.java)
                    } else {
                        intent.getParcelableExtra<android.net.Uri>(android.content.Intent.EXTRA_STREAM)
                    }
                    streamUri ?: intent.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri ?: intent.data
                }
                else -> null
            }
        }
    }

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (com.lorelight.ui.reader.VolumeKeyBus.active) {
            val code = event.keyCode
            if (code == android.view.KeyEvent.KEYCODE_VOLUME_DOWN ||
                code == android.view.KeyEvent.KEYCODE_VOLUME_UP) {
                if (event.action == android.view.KeyEvent.ACTION_DOWN) {
                    com.lorelight.ui.reader.VolumeKeyBus.emit(if (code == android.view.KeyEvent.KEYCODE_VOLUME_DOWN) 1 else -1)
                }
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra(EXTRA_OPEN_READER, false)) {
            openReaderSignal.value = openReaderSignal.value + 1
        }
        if (intent.getBooleanExtra(EXTRA_OPEN_NEW_CHAPTERS, false)) {
            openNewChaptersSignal.value = openNewChaptersSignal.value + 1
        }
        extractEpubUri(intent)?.let { uri ->
            if (uri.scheme == "content") {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {}
            }
            pendingEpubUri.value = uri
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        com.lorelight.data.local.AppSettingsSignal.watchAllCommonPrefs(this)
        SelfHealingEngine.onAppStart(this)
        CrashReporter.init(this)
        super.onCreate(savedInstanceState)
        TtsPlaybackManager.init(this)
        BackupManager.init(this)
        com.lorelight.service.NewChaptersManager.init(this)
        enableEdgeToEdge()

        try {
            val prefs = com.lorelight.data.local.AppPrefs.get(this)
            if (prefs.getBoolean("lib_update_enabled", false)) {
                val hours = prefs.getLong("lib_update_hours", 12L)
                val wifiOnly = prefs.getBoolean("lib_update_wifi_only", true)
                val chargingOnly = prefs.getBoolean("lib_update_charging_only", false)
                com.lorelight.work.LibraryUpdateScheduler.schedule(this, hours, wifiOnly, chargingOnly)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }

        setContent {
            val readerViewModel: ReaderViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
            val themeState by readerViewModel.appTheme.collectAsState()
            // FIX B14: isLightMode was hardcoded to false, so getAppColorScheme's
            // light variant for all nine themes was dead code and the app was
            // permanently dark. The mode is chosen in Settings > Appearance and
            // persisted as "app_theme_mode".
            val themeMode by readerViewModel.appThemeMode.collectAsState()
            val systemInDark = androidx.compose.foundation.isSystemInDarkTheme()
            val isLightMode = when (themeMode) {
                "Light" -> true
                "Dark" -> false
                else -> !systemInDark
            }
            val activeScheme = remember(themeState, isLightMode) { getAppColorScheme(themeState, isLightMode) }

            val view = androidx.compose.ui.platform.LocalView.current
            val window = (view.context as? android.app.Activity)?.window
            if (window != null) {
                val windowInsetsController = androidx.core.view.WindowCompat.getInsetsController(window, view)
                windowInsetsController.isAppearanceLightStatusBars = isLightMode
                windowInsetsController.isAppearanceLightNavigationBars = isLightMode
            }

            val appFontState by readerViewModel.appInterfaceFont.collectAsState()
            // The default interface face is a downloaded one, so on a fresh
            // install it is a NAME with no file behind it. Fetch it once,
            // off the main thread, and bump the tick when it lands so the
            // typography re-resolves immediately instead of at next launch.
            var appFontTick by remember { mutableIntStateOf(0) }
            LaunchedEffect(Unit) {
                val arrived = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    com.lorelight.ui.components.CustomFontManager
                        .ensureDefaultAppFont(applicationContext)
                }
                if (arrived) appFontTick++
            }
            val appFontFamily = remember(appFontState, appFontTick) { resolveFontFamily(appFontState, this) }

            MaterialTheme(
                colorScheme = activeScheme.animated(),
                typography = getAppTypography(appFontFamily)
            ) {
                // Light mode left the status-bar strip transparent, so the dark
                // app background bled through behind the clock. Each theme now
                // paints that strip with the dominant colour of the top ~4% of
                // its OWN light hero banner, so the band reads as a continuation
                // of the artwork rather than a separate tinted bar. Sampled by
                // median-cut quantisation over drawable/lightlibrary*.webp; the
                // dominant is stable across 2/4/8% crops for all eight. Every
                // value clears 4.8:1 against black, which is the floor the dark
                // status-bar icons need in light mode.
                val statusBarTint = when (themeState) {
                    "blackgold" -> Color(0xFFDFE5EB)
                    "readerblacknew" -> Color(0xFFFEFDF9)
                    "readerblood" -> Color(0xFFFDF7F2)
                    "Satin Pink" -> Color(0xFFF3B0A1)
                    "Ocean Blue" -> Color(0xFF178BF2)
                    "cyne" -> Color(0xFF3DB3ED)
                    "readerpurple" -> Color(0xFF8C6F9C)
                    else -> Color(0xFFF3FAFD)
                }
                // targetSdk 36 ignores window.statusBarColor, so the band has
                // to be a real composable sized to the top inset.
                val statusBarInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
                Box(modifier = Modifier.fillMaxSize()) {
                    LorelightApp(readerViewModel = readerViewModel)
                    if (isLightMode && !readerVisible.value && !detailsVisible.value && statusBarInset > 0.dp) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .fillMaxWidth()
                                .height(statusBarInset)
                                .background(statusBarTint)
                        )
                    }
                }
            }
        }
        if (intent?.getBooleanExtra(EXTRA_OPEN_READER, false) == true) {
            openReaderSignal.value = openReaderSignal.value + 1
        }
        if (intent?.getBooleanExtra(EXTRA_OPEN_NEW_CHAPTERS, false) == true) {
            openNewChaptersSignal.value = openNewChaptersSignal.value + 1
        }
        extractEpubUri(intent)?.let { uri ->
            if (uri.scheme == "content") {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {}
            }
            pendingEpubUri.value = uri
        }
    }
}

/**
 * True when two Novel objects refer to the same browse target, even if their
 * ids differ. A freshly created Novel gets a random UUID, so a placeholder
 * stub and the fully parsed novel for the SAME source entry do not share an
 * id. Comparing ids alone made the Details back-stack push a duplicate entry.
 */
private fun isSameNovelTarget(a: Novel, b: Novel): Boolean {
    if (a.id == b.id) return true
    val aPlugin = a.pluginId
    val aPath = a.pluginNovelPath
    if (!aPlugin.isNullOrBlank() && aPlugin == b.pluginId &&
        !aPath.isNullOrBlank() && aPath == b.pluginNovelPath
    ) return true
    val aUrl = a.sourceUrl
    if (a.pluginId.isNullOrBlank() && b.pluginId.isNullOrBlank() &&
        !aUrl.isNullOrBlank() && aUrl == b.sourceUrl
    ) return true
    return false
}

/**
 * Every full-screen place the app can be.
 *
 * The whole navigation tree is ONE ordered stack of these. Crawler, New
 * Chapters and Font Manager used to be loose `Boolean` flags living beside the
 * stack, which meant back ordering between them and Details/Reader was
 * undefined, they could stack on top of each other, and switching tabs left
 * them floating over the new tab. They are real destinations now.
 *
 * Entries store IDENTITY (a novel id), never a whole `Novel`. A Novel is a
 * large mutable record; embedding one in a stack entry made the entry go stale
 * the moment the library changed and made the stack impossible to persist.
 * Novels are resolved through `novelRegistry` at render time.
 */
sealed class ScreenDestination {
    data class Tab(val tabIndex: Int) : ScreenDestination()
    data class Details(val novelId: String) : ScreenDestination()
    data class Reader(val novelId: String?) : ScreenDestination()
    object Crawler : ScreenDestination()
    object NewChapters : ScreenDestination()
    object FontManager : ScreenDestination()

    /** Compact form used to persist the stack across rotation / process death. */
    fun encode(): String = when (this) {
        is Tab -> "T:$tabIndex"
        is Details -> "D:$novelId"
        is Reader -> "R:${novelId ?: ""}"
        Crawler -> "C:"
        NewChapters -> "N:"
        FontManager -> "F:"
    }

    companion object {
        fun decode(raw: String): ScreenDestination? {
            val tag = raw.substringBefore(':')
            val arg = raw.substringAfter(':', "")
            return when (tag) {
                "T" -> Tab(arg.toIntOrNull() ?: 0)
                "D" -> if (arg.isBlank()) null else Details(arg)
                "R" -> Reader(arg.ifBlank { null })
                "C" -> Crawler
                "N" -> NewChapters
                "F" -> FontManager
                else -> null
            }
        }

        /** Hard ceiling so Details -> Reader -> Details -> ... cannot grow forever. */
        const val MAX_DEPTH = 12
    }
}

@Composable
fun LorelightApp(
    readerViewModel: ReaderViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    val context = LocalContext.current
    val mangaReaderViewModel: com.lorelight.manga.reader.MangaReaderViewModel = androidx.lifecycle.viewmodel.compose.viewModel()

    var customUriState by remember {
        mutableStateOf(
            context.getSharedPreferences("lorelight_backup_prefs", Context.MODE_PRIVATE)
                .getString(com.lorelight.core.BackupManager.KEY_CUSTOM_URI, null)
        )
    }

    if (customUriState.isNullOrEmpty()) {
        com.lorelight.ui.components.StorageOnboardingScreen(
            onFolderSelected = { uri, name ->
                customUriState = uri
            }
        )
    } else {
        // ── The navigation tree ──────────────────────────────────────────
        // The stack now SURVIVES rotation and process death. It used to be a
        // plain `remember`, so rotating the phone - or simply coming back to a
        // backgrounded app that Android had trimmed - threw the entire tree
        // away and silently dropped the user on Library, mid-book.
        val navStack = androidx.compose.runtime.saveable.rememberSaveable(
            saver = androidx.compose.runtime.saveable.listSaver<
                androidx.compose.runtime.snapshots.SnapshotStateList<ScreenDestination>, String>(
                save = { stack -> stack.map { it.encode() } },
                restore = { saved ->
                    val restored = saved.mapNotNull { ScreenDestination.decode(it) }
                    mutableStateListOf<ScreenDestination>().apply {
                        if (restored.isEmpty()) add(ScreenDestination.Tab(0)) else addAll(restored)
                    }
                }
            )
        ) { mutableStateListOf<ScreenDestination>(ScreenDestination.Tab(0)) }

        // Novels the stack points at, keyed by id. Browse can open Details for
        // a novel that is NOT in the library yet (a stub), so ids cannot always
        // be resolved from `importedNovels`.
        val novelRegistry = remember { mutableStateMapOf<String, Novel>() }

    fun pushDestination(destination: ScreenDestination) {
        val last = navStack.lastOrNull()
        if (last == destination) return
        
        when (destination) {
            is ScreenDestination.Tab -> {
                // Tabs must not leave a breadcrumb of every tab you visited.
                // Library (tab 0) is always the base of the stack and any other
                // tab sits exactly one level above it, so back always reads
                // sub-screen -> tab -> Library -> exit, no matter how many tabs
                // were touched on the way.
                navStack.clear()
                navStack.add(ScreenDestination.Tab(0))
                if (destination.tabIndex != 0) {
                    navStack.add(destination)
                }
            }
            is ScreenDestination.Details -> {
                if (last is ScreenDestination.Details && last.novelId == destination.novelId) {
                    return
                }
                navStack.add(destination)
            }
            is ScreenDestination.Reader -> {
                if (last is ScreenDestination.Reader) {
                    return
                }
                navStack.add(destination)
            }
            // Single-instance overlays. Opening one that is already somewhere in
            // the tree re-surfaces it instead of stacking a second copy, so you
            // can never be forced to press Back twice through the same screen.
            ScreenDestination.Crawler,
            ScreenDestination.NewChapters,
            ScreenDestination.FontManager -> {
                navStack.remove(destination)
                navStack.add(destination)
            }
        }

        // Depth guard: drop the oldest non-base entries rather than let the
        // stack grow without bound.
        while (navStack.size > ScreenDestination.MAX_DEPTH) {
            navStack.removeAt(1)
        }
    }

    val selectedTabState = remember {
        object : MutableState<Int> {
            override var value: Int
                get() = navStack.filterIsInstance<ScreenDestination.Tab>().lastOrNull()?.tabIndex ?: 0
                set(value) {
                    pushDestination(ScreenDestination.Tab(value))
                }
            override fun component1(): Int = value
            override fun component2(): (Int) -> Unit = { value = it }
        }
    }
    var selectedTab by selectedTabState

    val tabs = listOf("Library", "History", "Browse", "Settings")
    
    var currentNovel by remember { mutableStateOf<Novel?>(null) }

    val selectedNovelForDetailsState = remember {
        object : MutableState<Novel?> {
            override var value: Novel?
                get() = navStack.filterIsInstance<ScreenDestination.Details>()
                    .lastOrNull()
                    ?.let { novelRegistry[it.novelId] }
                set(value) {
                    if (value == null) {
                        // Assigning null means "this novel is gone" (deleted,
                        // failed to import, went offline) - NOT "go back". It
                        // still unwinds every trailing Details/Reader, because
                        // none of them can render without the novel.
                        while (navStack.isNotEmpty() && (navStack.last() is ScreenDestination.Details || navStack.last() is ScreenDestination.Reader)) {
                            navStack.removeAt(navStack.size - 1)
                        }
                    } else {
                        novelRegistry[value.id] = value
                        // Re-point an entry for the SAME target rather than
                        // pushing a duplicate: a browse stub and its fully
                        // parsed novel have different ids but are one screen.
                        val existingIndex = navStack.indexOfLast { entry ->
                            entry is ScreenDestination.Details &&
                                (entry.novelId == value.id ||
                                    novelRegistry[entry.novelId]?.let { isSameNovelTarget(it, value) } == true)
                        }
                        if (existingIndex != -1) {
                            navStack[existingIndex] = ScreenDestination.Details(value.id)
                        } else {
                            pushDestination(ScreenDestination.Details(value.id))
                        }
                    }
                }
            override fun component1(): Novel? = value
            override fun component2(): (Novel?) -> Unit = { value = it }
        }
    }
    var selectedNovelForDetails by selectedNovelForDetailsState
    var detailsLoading by remember { mutableStateOf(false) }
    val browseNovelScope = androidx.compose.runtime.rememberCoroutineScope()

    var importedNovels by remember { mutableStateOf(emptyList<Novel>()) }
    var websites by remember { mutableStateOf(emptyList<Website>()) }
    var websitesLoaded by remember { mutableStateOf(false) }
    var libraryLoaded by remember { mutableStateOf(false) }

    // Keep the registry that backs the nav stack in step with the library, then
    // drop any stack entry that can no longer resolve to a novel. This is what
    // makes a RESTORED stack safe: after a rotation or a process restart the
    // registry starts empty, so Details/Reader entries are re-seated from the
    // library here, and anything that was only ever a transient browse stub is
    // pruned instead of leaving an invisible screen you have to Back through.
    LaunchedEffect(importedNovels, libraryLoaded) {
        importedNovels.forEach { novel -> novelRegistry[novel.id] = novel }
        if (!libraryLoaded) return@LaunchedEffect
        val referenced = navStack.mapNotNull { entry ->
            when (entry) {
                is ScreenDestination.Details -> entry.novelId
                is ScreenDestination.Reader -> entry.novelId
                else -> null
            }
        }.toSet()
        novelRegistry.keys.retainAll { it in referenced || importedNovels.any { n -> n.id == it } }
        while (
            navStack.size > 1 &&
            navStack.last().let { it is ScreenDestination.Details && novelRegistry[it.novelId] == null }
        ) {
            navStack.removeAt(navStack.size - 1)
        }
    }

    LaunchedEffect(Unit) {
        val loadedWebsites = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            NovelPreferences.loadWebsitesFromPrefs(context)
        }
        websites = loadedWebsites
        websitesLoaded = true
    }

    LaunchedEffect(Unit) {
        val loadedNovels = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            NovelPreferences.loadNovelsFromPrefs(context)
        }
        importedNovels = loadedNovels
        libraryLoaded = true
        currentNovel = NovelPreferences.pickResumeNovel(loadedNovels)
    }

    LaunchedEffect(Unit) {
        com.lorelight.service.NovelImportManager.tick.collect {
            val refreshed = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                NovelPreferences.loadNovelsFromPrefs(context)
            }
            importedNovels = refreshed
        }
    }

    // LIVE READING POSITION.
    //
    // The twin of the tick collector above. Manga progress went through
    // NovelImportManager, which bumps tick, so manga screens were always live.
    // Novel progress went through NovelPreferences.saveProgressOnly, which
    // notified nobody -- so the row on disk was right within milliseconds while
    // every screen kept drawing the list loaded at app start. That single gap
    // produced three symptoms that looked like three bugs: a chapter-list
    // highlight stuck on an old chapter, a Continue Reading card reading its
    // number from that same stale novel, and a History list frozen at whatever
    // it was first handed.
    //
    // Reloading here fixes all three at once, because Details re-resolves its
    // novel from importedNovels, History rebuilds whenever importedNovels
    // changes, and the resume pick re-runs on the same key.
    //
    // Throttled deliberately: a TTS session flushes roughly every five
    // sentences, and reloading the library on every flush would be wasteful.
    // Real reading events are seconds apart, so a short floor coalesces bursts
    // without ever making the screen feel behind.
    LaunchedEffect(Unit) {
        var lastReload = 0L
        com.lorelight.data.local.ReadingProgressSignal.version.collect { v ->
            if (v == 0) return@collect
            val now = System.currentTimeMillis()
            if (now - lastReload < 600L) return@collect
            lastReload = now
            val refreshed = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                NovelPreferences.invalidateCache()
                NovelPreferences.loadNovelsFromPrefs(context)
            }
            // Never let a failed or empty read blank out a populated screen.
            if (refreshed.isNotEmpty()) importedNovels = refreshed
        }
    }

    // FIX #33: keep the Continue Reading snapshot in sync with the live library.
    // Continue Reading has to point at whatever was read most recently, so
    // re-pick the winner every time the library changes. It used to only
    // refresh the copy it was already holding, which meant reading a different
    // book left the card stuck on the previous one - read a manga, then a
    // novel, and the card still offered the manga.
    LaunchedEffect(importedNovels) {
        val resume = NovelPreferences.pickResumeNovel(importedNovels)
        val cur = currentNovel
        if (resume != null) {
            if (resume != cur) currentNovel = resume
        } else if (cur != null) {
            val fresh = importedNovels.firstOrNull { it.id == cur.id }
            if (fresh != null && fresh != cur) currentNovel = fresh
        }
    }

    // Auto-check each online novel for new chapters (every 3 days), on app open.
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(4000)
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                com.lorelight.service.NovelImportManager.autoCheckStaleNovels(context)
            } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError(context, "MainActivity.autoCheckStaleNovels", e) }
        }
    }
    
    val showReaderState = remember {
        object : MutableState<Boolean> {
            override var value: Boolean
                get() = navStack.any { it is ScreenDestination.Reader }
                set(value) {
                    if (!value) {
                        // Pop only the Reader entries sitting on TOP. The old
                        // `removeAll` deleted Reader entries from anywhere in
                        // the stack, which could silently reorder the tree.
                        while (navStack.size > 1 && navStack.last() is ScreenDestination.Reader) {
                            navStack.removeAt(navStack.size - 1)
                        }
                    } else {
                        pushDestination(
                            ScreenDestination.Reader(selectedNovelForDetailsState.value?.id)
                        )
                    }
                }
            override fun component1(): Boolean = value
            override fun component2(): (Boolean) -> Unit = { value = it }
        }
    }
    var showReader by showReaderState

    // ── Tapping the TTS media notification opens the Reader ──
    LaunchedEffect(Unit) {
        MainActivity.openReaderSignal.collect { signal ->
            if (signal > 0 && TtsPlaybackManager.sessionActive.value && !showReader) {
                // BACK-STACK FIX: seat the novel's Details page under the Reader so
                // backing out of a notification-opened reader returns to the novel
                // instead of dumping the user on the Library tab.
                TtsPlaybackManager.activeNovel.value?.let { playing ->
                    selectedNovelForDetails = playing
                }
                showReader = true
            }
        }
    }

    // Stack-backed, not a loose flag: Back now reaches it in the right order,
    // it cannot open twice, and switching tabs closes it instead of leaving it
    // floating over the new tab.
    val showNewChaptersState = remember {
        object : MutableState<Boolean> {
            override var value: Boolean
                get() = navStack.contains(ScreenDestination.NewChapters)
                set(value) {
                    if (value) pushDestination(ScreenDestination.NewChapters)
                    else navStack.remove(ScreenDestination.NewChapters)
                }
            override fun component1(): Boolean = value
            override fun component2(): (Boolean) -> Unit = { value = it }
        }
    }
    var showNewChapters by showNewChaptersState

    LaunchedEffect(Unit) {
        MainActivity.openNewChaptersSignal.collect { signal ->
            if (signal > 0) {
                showNewChapters = true
            }
        }
    }

    LaunchedEffect(showReader) {
        MainActivity.readerVisible.value = showReader
        val activity = context as? android.app.Activity ?: return@LaunchedEffect
        activity.requestedOrientation = if (showReader) {
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        } else {
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }
    }

    // ONE back implementation, shared by the system/gesture Back button and by
    // every in-app back arrow, so the two can never drift apart. Pops exactly
    // one level and treats Library as the base of the app.
    //
    // They used to be separate code paths: system Back popped a single navStack
    // entry, while the in-app arrow assigned `selectedNovelForDetails = null`,
    // whose setter unwinds EVERY trailing Details/Reader entry at once. Same
    // gesture, two different results - which is what made back feel scrambled.
    fun goBackOneLevel() {
        if (navStack.size > 1) {
            navStack.removeAt(navStack.size - 1)
        } else {
            navStack.clear()
            navStack.add(ScreenDestination.Tab(0))
        }
    }

    // Root-level Back. Library (tab 0) is the base of the app. Previously the
    // handler simply switched OFF at the root, so one stray Back tap - or the
    // tail end of a swipe gesture - killed the app instantly with no warning
    // and no chance to cancel. Now the first tap at the root warns and the
    // second within two seconds actually leaves.
    var lastRootBackAt by remember { mutableStateOf(0L) }
    val atRoot = navStack.size <= 1 && navStack.firstOrNull() == ScreenDestination.Tab(0)
    val hostActivity = context as? android.app.Activity

    androidx.activity.compose.BackHandler {
        if (!atRoot) {
            goBackOneLevel()
            return@BackHandler
        }
        val now = System.currentTimeMillis()
        if (now - lastRootBackAt in 1..2000L) {
            hostActivity?.finish()
        } else {
            lastRootBackAt = now
            android.widget.Toast.makeText(
                context,
                "Press back again to exit",
                android.widget.Toast.LENGTH_SHORT
            ).show()
        }
    }
    
    val showCrawlerState = remember {
        object : MutableState<Boolean> {
            override var value: Boolean
                get() = navStack.contains(ScreenDestination.Crawler)
                set(value) {
                    if (value) pushDestination(ScreenDestination.Crawler)
                    else navStack.remove(ScreenDestination.Crawler)
                }
            override fun component1(): Boolean = value
            override fun component2(): (Boolean) -> Unit = { value = it }
        }
    }
    var showCrawler by showCrawlerState
    val showFontManagerState = remember {
        object : MutableState<Boolean> {
            override var value: Boolean
                get() = navStack.contains(ScreenDestination.FontManager)
                set(value) {
                    if (value) pushDestination(ScreenDestination.FontManager)
                    else navStack.remove(ScreenDestination.FontManager)
                }
            override fun component1(): Boolean = value
            override fun component2(): (Boolean) -> Unit = { value = it }
        }
    }
    var showFontManager by showFontManagerState
    var isImportingEpub by remember { mutableStateOf(false) }

    // A book arriving from outside the app ("Open with" / share sheet) imports into
    // the library and STOPS there - it lands on the Library tab, it does not open the
    // reader or chapter one. MainActivity is the single owner of this hand-off; the
    // Library screen must never import the same uri again (that parallel second
    // importer was what raced and produced false "failed" messages).
    val incomingEpubUri by MainActivity.pendingEpubUri.collectAsState()
    var lastHandledEpubUri by remember { mutableStateOf<android.net.Uri?>(null) }
    LaunchedEffect(incomingEpubUri) {
        val uri = incomingEpubUri ?: return@LaunchedEffect
        // A recomposition, rotation or activity restart must not re-import the same book.
        if (uri == lastHandledEpubUri) return@LaunchedEffect
        lastHandledEpubUri = uri
        showFontManager = false
        showCrawler = false
        showNewChapters = false
        showReader = false
        selectedNovelForDetails = null
        selectedTab = 0
        isImportingEpub = true
        val titlesBefore = importedNovels.map { it.title }.toSet()
        try {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
                // Most senders only grant transient read access, which is all the
                // importer needs - it copies the book into app storage right away.
            }
            val result = com.lorelight.service.NovelImportManager.importEpub(context, uri)
            // The outcome is decided by re-reading the library from disk AFTER the
            // import, not by whichever code path finished first.
            val freshNovels = com.lorelight.data.local.NovelPreferences.loadNovelsFromPrefs(context)
            importedNovels = freshNovels
            when (result) {
                is com.lorelight.service.EpubImportResult.Success -> {
                    val novel = result.novel
                    currentNovel = novel
                    android.widget.Toast.makeText(
                        context,
                        if (result.isNew) "Added \u201C${novel.title}\u201D to your library"
                        else "Updated \u201C${novel.title}\u201D in your library",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
                is com.lorelight.service.EpubImportResult.Error -> {
                    // Safety net: if the importer complained but the book actually
                    // did save, report the truth instead of a bogus failure.
                    val landed = freshNovels.firstOrNull { it.title !in titlesBefore }
                    if (landed != null) {
                        currentNovel = landed
                        android.widget.Toast.makeText(
                            context,
                            "Added \u201C${landed.title}\u201D to your library",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        android.widget.Toast.makeText(
                            context,
                            result.message,
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        } catch (e: Exception) {
            android.widget.Toast.makeText(
                context,
                "Failed to import EPUB: ${e.localizedMessage ?: e.message}",
                android.widget.Toast.LENGTH_LONG
            ).show()
        } finally {
            isImportingEpub = false
            MainActivity.pendingEpubUri.value = null
        }
    }
    
    val activeNovel by readerViewModel.activeNovel.collectAsState()
    val themeState by readerViewModel.appTheme.collectAsState()
    
    var historyNovels by remember { mutableStateOf<List<Novel>>(emptyList()) }
    LaunchedEffect(importedNovels) {
        val historyEntries = com.lorelight.data.local.NovelPreferences.loadHistoryFromPrefs(context)
        historyNovels = historyEntries.mapNotNull { entry ->
            importedNovels.find { it.id == entry.novelId }
                ?: try {
                    if (entry.novelJson.isNotEmpty()) org.json.JSONObject(entry.novelJson).toNovel() else null
                } catch (e: Exception) { null }
        }
    }

    val heroThemeMode by readerViewModel.appThemeMode.collectAsState()
    val heroSystemDark = androidx.compose.foundation.isSystemInDarkTheme()
    val heroIsLight = when (heroThemeMode) {
        "Light" -> true
        "Dark" -> false
        else -> !heroSystemDark
    }
    val heroImageRes = if (heroIsLight) {
        when (themeState) {
            "blackgold" -> R.drawable.lightlibrarygold
            "Satin Pink" -> R.drawable.lightlibrarypink
            "readerblacknew" -> R.drawable.lightlibraryblackk
            "Ocean Blue" -> R.drawable.lightlibraryblue
            "cyne" -> R.drawable.lightlibrarycyne
            "readerpurple" -> R.drawable.lightlibrarypurple
            "readerblood" -> R.drawable.lightlibraryred
            else -> R.drawable.lightlibrarygreen
        }
    } else {
        when (themeState) {
            "blackgold" -> R.drawable.darklibrarygold
            "Satin Pink" -> R.drawable.darklibrarypink
            "readerblacknew" -> R.drawable.darklibraryblackk
            "Ocean Blue" -> R.drawable.darklibraryblue
            "cyne" -> R.drawable.darklibrarycyne
            "readerpurple" -> R.drawable.darklibrarypurple
            "readerblood" -> R.drawable.darklibraryred
            else -> R.drawable.darklibrarygreen
        }
    }

    LaunchedEffect(activeNovel) {
        val updatedNov = activeNovel
        // Skip if nothing actually changed — prevents remapping + re-serializing
        // the entire library on every TTS progress emission.
        if (updatedNov != null && importedNovels.firstOrNull { it.id == updatedNov.id } != updatedNov) {
            importedNovels = importedNovels.map {
                if (it.id == updatedNov.id) updatedNov else it
            }
            // The book actually open in the reader is by definition the one
            // Continue Reading should offer next, even when it is not the book
            // we were previously holding.
            currentNovel = updatedNov
            if (selectedNovelForDetails?.id == updatedNov.id) {
                selectedNovelForDetails = updatedNov
            }
            com.lorelight.data.local.NovelPreferences.addHistoryEntry(context, updatedNov)
        }
    }
    
    LaunchedEffect(importedNovels) {
        kotlinx.coroutines.delay(3000)
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            NovelPreferences.saveNovelsToPrefs(context, importedNovels)
        }
    }

    // FIX D3: re-read the library from the database every time the app returns
    // to the foreground.
    //
    // NovelPreferences.cachedNovels is a process-wide static that was only ever
    // cleared by a full data wipe. A periodic LibraryUpdateWorker can populate
    // it in a process that outlives this Activity, after which
    // loadNovelsFromPrefs() keeps serving that captured list - so reopening the
    // app could show a library from hours or days ago, and the debounced save
    // above would then write it straight back over the good rows.
    var foregroundTick by remember { mutableStateOf(0) }
    val fgLifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(fgLifecycleOwner) {
        val fgObserver = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_START) {
                foregroundTick++
            }
        }
        fgLifecycleOwner.lifecycle.addObserver(fgObserver)
        onDispose { fgLifecycleOwner.lifecycle.removeObserver(fgObserver) }
    }

    LaunchedEffect(foregroundTick) {
        if (foregroundTick == 0) return@LaunchedEffect
        val refreshed = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            NovelPreferences.invalidateCache()
            NovelPreferences.loadNovelsFromPrefs(context)
        }
        // Never let a failed/empty read blank out a populated screen.
        if (refreshed.isNotEmpty()) {
            importedNovels = refreshed
            currentNovel = NovelPreferences.pickResumeNovel(refreshed)
        }
    }
    
    LaunchedEffect(websites) {
        if (!websitesLoaded) return@LaunchedEffect
        kotlinx.coroutines.delay(3000)
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            NovelPreferences.saveWebsitesToPrefs(context, websites)
        }
    }

    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                TtsPlaybackManager.isAppInBackground.value = false
                DiagnosticLogger.logEngineStatus("App transition to FOREGROUND. Normal TTS state polling active.")
            }
            if (event == androidx.lifecycle.Lifecycle.Event.ON_PAUSE || event == androidx.lifecycle.Lifecycle.Event.ON_STOP) {
                TtsPlaybackManager.isAppInBackground.value = true
                DiagnosticLogger.logEngineStatus("App transition to BACKGROUND. Battery-saving check enabled.")
                
                val valActive = readerViewModel.activeNovel.value
                val finalList = if (valActive != null) {
                    importedNovels.map {
                        if (it.id == valActive.id) valActive else it
                    }
                } else {
                    importedNovels
                }
                saveNovelsToPrefsSync(context, finalList)
                if (websitesLoaded) {
                    saveWebsitesToPrefsSync(context, websites)
                }
                // FIX A1: the *Sync helpers hand their work to the serialized
                // DbWriter queue. Wait for that queue to actually drain, so an
                // ON_STOP save cannot still be in flight when the process dies.
                NovelPreferences.flushPendingWrites()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val icons = when (themeState) {
        "blackgold" -> listOf(
            R.drawable.ic_golden_library,
            R.drawable.ic_golden_history,
            R.drawable.ic_golden_website,
            R.drawable.ic_golden_settings
        )
        "Satin Pink" -> listOf(
            R.drawable.ic_pink_library,
            R.drawable.ic_pink_history,
            R.drawable.ic_pink_website,
            R.drawable.ic_pink_settings
        )
        "readerblacknew" -> listOf(
            R.drawable.ic_midnight_library,
            R.drawable.ic_midnight_history,
            R.drawable.ic_midnight_website,
            R.drawable.ic_midnight_settings
        )
        "Ocean Blue", "cyne" -> listOf(
            R.drawable.ic_ocean_library,
            R.drawable.ic_ocean_history,
            R.drawable.ic_ocean_website,
            R.drawable.ic_ocean_settings
        )
        "readerpurple", "readerblood" -> listOf(
            R.drawable.ic_pink_library,
            R.drawable.ic_pink_history,
            R.drawable.ic_pink_website,
            R.drawable.ic_pink_settings
        )
        else -> listOf(
            R.drawable.ic_forest_library,
            R.drawable.ic_forest_history,
            R.drawable.ic_forest_website,
            R.drawable.ic_forest_settings
        )
    }

    @Composable
    fun MainTabContentBlock(modifier: Modifier = Modifier) {
        AnimatedContent(
            targetState = selectedTab,
            transitionSpec = {
                val direction = if (targetState > initialState) 1 else -1
                (fadeIn(animationSpec = tween(180, easing = FastOutSlowInEasing)) +
                 slideInHorizontally(
                     animationSpec = tween(220, easing = FastOutSlowInEasing),
                     initialOffsetX = { (it / 20) * direction }
                 )
                ).togetherWith(
                 fadeOut(animationSpec = tween(120, easing = FastOutSlowInEasing)) +
                 slideOutHorizontally(
                     animationSpec = tween(220, easing = FastOutSlowInEasing),
                     targetOffsetX = { (-it / 20) * direction }
                 )
                )
            },
            label = "tabChangeTransition",
            modifier = modifier.fillMaxSize()
        ) { targetTab ->
            when (targetTab) {
                0 -> LibraryScreen(
                    currentNovel = currentNovel,
                    importedNovels = importedNovels,
                    libraryLoaded = libraryLoaded,
                    pendingEpubUri = incomingEpubUri,
                    onPendingEpubHandled = { MainActivity.pendingEpubUri.value = null },
                    onCurrentNovelChange = { updated ->
                        currentNovel = updated
                        if (updated != null) {
                            importedNovels = importedNovels.map {
                                if (it.id == updated.id) updated else it
                            }
                        }
                    },
                    onImportedNovelsChange = { newList ->
                        importedNovels = newList
                    },
                    onSelectNovelForDetails = { novel ->
                        selectedNovelForDetails = novel
                    },
                    onReadCurrent = {
                        currentNovel?.let { 
                            // BACK-STACK FIX: push the novel's Details page underneath
                            // the Reader first. Without this the stack was
                            // [Tab(0), Reader], so pressing back from the reader landed
                            // on the Library tab instead of the novel's details page.
                            selectedNovelForDetails = it
                            readerViewModel.startReading(it)
                            showReader = true 
                        }
                    },
                    readerViewModel = readerViewModel,
                    heroImageRes = heroImageRes
                )
                1 -> HistoryScreen(
                    history = historyNovels,
                    heroImageRes = heroImageRes,
                    onPlayClick = { historyNovel ->
                        // RESUME REDESIGN. The history card carries a slim JSON
                        // snapshot of the novel, and an older snapshot can hold
                        // the synthetic 1..100 placeholder chapter list. Handing
                        // that to the player is how it ended up announcing
                        // "Chapter 1". The library row is the live copy, so
                        // resume from that whenever it exists and keep the
                        // history blob only as a fallback for novels that are no
                        // longer in the library.
                        val live = importedNovels.firstOrNull { it.id == historyNovel.id }
                            ?: historyNovel
                        val updatedNovel = live.copy(
                            lastReadTimestamp = System.currentTimeMillis()
                        )
                        importedNovels = importedNovels.map {
                            if (it.id == updatedNovel.id) updatedNovel else it
                        }
                        currentNovel = updatedNovel
                        selectedNovelForDetails = updatedNovel
                        // Pass the recorded index explicitly instead of letting
                        // the player guess from a chapter name.
                        readerViewModel.startReading(
                            updatedNovel,
                            startChapterIndex = updatedNovel.currentChapterIndex
                                .takeIf { it in updatedNovel.chapters.indices }
                        )
                        showReader = true
                    },
                    onDeleteClick = { novel ->
                        com.lorelight.data.local.NovelPreferences.removeHistoryEntry(context, novel.id)
                        historyNovels = historyNovels.filterNot { it.id == novel.id }
                    },
                    onClearAllClick = {
                        com.lorelight.data.local.NovelPreferences.clearAllHistory(context)
                        historyNovels = emptyList()
                    },
                    readerViewModel = readerViewModel
                )
                2 -> com.lorelight.browse.ui.BrowseScreen(
                    onOpenNovel = { pluginId, item ->
                        if (!detailsLoading) {
                            val existing = importedNovels.firstOrNull {
                                it.pluginId == pluginId && it.pluginNovelPath == item.path
                            }
                            if (existing != null) {
                                selectedNovelForDetails = existing
                            } else {
                                val stub = com.lorelight.data.model.Novel(
                                    title = item.name,
                                    currentChapter = "",
                                    lastReadTimestamp = 0L,
                                    author = "",
                                    status = "",
                                    totalChapters = 0,
                                    genres = emptyList(),
                                    description = "",
                                    chapters = emptyList(),
                                    coverImageBase64 = item.cover,
                                    isOnline = true,
                                    sourceUrl = item.path,
                                    chapterUrls = emptyList(),
                                    pluginId = pluginId,
                                    pluginNovelPath = item.path
                                )
                                selectedNovelForDetails = stub
                                detailsLoading = true
                                browseNovelScope.launch {
                                    try {
                                        val details = com.lorelight.browse.js.JSPluginEngine.parseNovel(context, pluginId, item.path)
                                        val currentExisting = importedNovels.firstOrNull {
                                            it.pluginId == pluginId && it.pluginNovelPath == item.path
                                        }
                                        val mapped = details.toNovel(pluginId)
                                        val result = if (currentExisting != null) {
                                            mapped.copy(
                                                id = currentExisting.id,
                                                currentChapter = currentExisting.currentChapter,
                                                currentParagraphIndex = currentExisting.currentParagraphIndex,
                                                completedChapters = currentExisting.completedChapters,
                                                isFavorite = currentExisting.isFavorite,
                                                lastReadTimestamp = currentExisting.lastReadTimestamp
                                            )
                                        } else mapped.copy(id = stub.id)
                                        // If the user pressed back while this was loading, do not
                                        // re-open Details behind their back.
                                        if (selectedNovelForDetails?.let { isSameNovelTarget(it, stub) } == true) {
                                            selectedNovelForDetails = result
                                        }
                                        if (currentExisting != null) {
                                            com.lorelight.service.NovelImportManager.updateNovel(context, result.id) { result }
                                            importedNovels = importedNovels.map { if (it.id == result.id) result else it }
                                        }
                                    } catch (e: Exception) {
                                        val msg = when {
                                            e.message?.contains("429") == true ->
                                                "Too many requests - the site is rate-limiting you. Wait a moment and try again."
                                            e.message?.contains("403") == true ->
                                                "Cloudflare protection active. Please solve the captcha in web view."
                                            else -> "Couldn't open novel: ${e.message}"
                                        }
                                        android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()
                                        if (selectedNovelForDetails?.let { isSameNovelTarget(it, stub) } == true) {
                                            selectedNovelForDetails = null
                                        }
                                    } finally {
                                        detailsLoading = false
                                    }
                                }
                            }
                        }
                    },
                    onOpenManga = { sourceId, sManga ->
                        if (!detailsLoading) {
                            val pluginIdStr = "manga:$sourceId"
                            val existing = importedNovels.firstOrNull {
                                it.pluginId == pluginIdStr && it.pluginNovelPath == sManga.url
                            }
                            val stub = sManga.toNovel(sourceId, existing = existing)
                            selectedNovelForDetails = stub
                            detailsLoading = true
                            browseNovelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                try {
                                    val sourceManager = Injekt.get<tachiyomi.domain.source.service.SourceManager>()
                                    sourceManager.isInitialized.first { it }
                                    val source = sourceManager.get(sourceId)
                                    if (source == null) {
                                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                            android.widget.Toast.makeText(context, "Extension not installed", android.widget.Toast.LENGTH_SHORT).show()
                                            selectedNovelForDetails = null
                                        }
                                    } else {
                                        val reqManga = eu.kanade.tachiyomi.source.model.SManga.create().apply { url = sManga.url }
                                        val details = source.getMangaDetails(reqManga).seedFrom(reqManga.url, sManga.safeTitle() ?: "")
                                        val chapters = source.getChapterList(reqManga).sanitizedChapters()
                                        val currentExisting = importedNovels.firstOrNull {
                                            it.pluginId == pluginIdStr && it.pluginNovelPath == (details.url.ifBlank { sManga.url })
                                        }
                                        val mapped = details.toNovel(sourceId, existing = currentExisting ?: stub, chapters = chapters)
                                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                            if (selectedNovelForDetails?.let { isSameNovelTarget(it, stub) } == true) {
                                                selectedNovelForDetails = mapped
                                            }
                                            if (currentExisting != null) {
                                                com.lorelight.service.NovelImportManager.updateNovel(context, mapped.id) { mapped }
                                                importedNovels = importedNovels.map { if (it.id == mapped.id) mapped else it }
                                            }
                                        }
                                    }
                                } catch (e: Throwable) {
                                    if (e is kotlinx.coroutines.CancellationException) throw e
                                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                        val msg = if (e.message?.contains("403") == true) {
                                            "Cloudflare protection active. Please solve the captcha in web view."
                                        } else {
                                            "Couldn't open manga: ${e.message ?: e.toString()}"
                                        }
                                        android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_SHORT).show()
                                        selectedNovelForDetails = null
                                    }
                                } finally {
                                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                        detailsLoading = false
                                    }
                                }
                            }
                        }
                    }
                )
                3 -> SettingsScreen(
                    importedNovels = importedNovels,
                    websites = websites,
                    readerViewModel = readerViewModel,
                    onRestoreSuccess = {
                        browseNovelScope.launch {
                            val (newNovels, newWebsites) = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                                Pair(
                                    NovelPreferences.loadNovelsFromPrefs(context),
                                    NovelPreferences.loadWebsitesFromPrefs(context)
                                )
                            }
                            importedNovels = newNovels
                            websites = newWebsites
                            currentNovel = NovelPreferences.pickResumeNovel(newNovels)
                        }
                    },
                    onOpenFontManager = { showFontManager = true },
                    onOpenNewChapters = { showNewChapters = true }
                )
                else -> ComingSoonScreen(tabs[targetTab])
            }
        }
    }

    // ── Day / night switch ───────────────────────────────────────────────
    // The overlay needs a screenshot taken BEFORE the theme flips, so the
    // controller lives out here where both the bottom bar (which triggers it)
    // and the root Box (which draws it) can reach the same instance.
    val modeSwitchController = remember { com.lorelight.ui.theme.modeswitch.ModeSwitchController() }
    val modeSwitchScope = rememberCoroutineScope()
    val modeSwitchView = androidx.compose.ui.platform.LocalView.current
    val modeSwitchMode by readerViewModel.themeSwitchAnimMode.collectAsState()
    val modeSwitchPoolCsv by readerViewModel.themeSwitchAnimPool.collectAsState()
    val modeSwitchSingleId by readerViewModel.themeSwitchAnimSingle.collectAsState()
    val modeSwitchPool = remember(modeSwitchMode, modeSwitchPoolCsv, modeSwitchSingleId) {
        if (modeSwitchMode == "Single") {
            listOf(
                com.lorelight.ui.theme.modeswitch.ModeSwitchAnimation.fromId(modeSwitchSingleId)
                    ?: com.lorelight.ui.theme.modeswitch.ModeSwitchAnimation.CELESTIAL_ARC
            )
        } else {
            com.lorelight.ui.theme.modeswitch.ModeSwitchAnimation.poolFromCsv(modeSwitchPoolCsv)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                if (!com.lorelight.browse.ui.browseInSourceState.value) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(64.dp)
                    ) {
                        // Two real navigation panes with a transparent opening.
                        // The altar owns the middle and cannot cover any tab.
                        val modeGutter = 88.dp
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            GlassPanel(
                                cornerRadius = 24.dp,
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                            ) {}
                            Spacer(modifier = Modifier.width(modeGutter))
                            GlassPanel(
                                cornerRadius = 24.dp,
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                            ) {}
                        }

                        BoxWithConstraints(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 8.dp)
                        ) {
                            val totalWidth = maxWidth
                            val tabCount = tabs.size
                            // The tabs reserve the same opening as the panes.
                            val tabWidth = (totalWidth - modeGutter) / tabCount
                            
                            val targetOffset = tabWidth * selectedTab +
                                (if (selectedTab >= 2) modeGutter else 0.dp)
                            val animatedOffset by animateDpAsState(
                                targetValue = targetOffset,
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioMediumBouncy,
                                    stiffness = Spring.StiffnessMediumLow
                                ),
                                label = "tabIndicatorOffset"
                            )

                            // Giggle wobble animation when changing option
                            val giggleRotation = remember { Animatable(0f) }
                            val giggleScale = remember { Animatable(1f) }

                            LaunchedEffect(selectedTab) {
                                launch {
                                    giggleScale.animateTo(1.15f, tween(90, easing = FastOutSlowInEasing))
                                    giggleScale.animateTo(0.92f, tween(90, easing = FastOutSlowInEasing))
                                    giggleScale.animateTo(1.0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium))
                                }
                                launch {
                                    giggleRotation.animateTo(-7f, tween(70))
                                    giggleRotation.animateTo(7f, tween(70))
                                    giggleRotation.animateTo(-3f, tween(60))
                                    giggleRotation.animateTo(3f, tween(60))
                                    giggleRotation.animateTo(0f, spring(dampingRatio = Spring.DampingRatioMediumBouncy))
                                }
                            }

                            val isLight = MaterialTheme.colorScheme.background.luminance() > 0.5f

                            // Fluid sliding highlight background with giggle animation
                            Box(
                                modifier = Modifier
                                    .offset {
                                        androidx.compose.ui.unit.IntOffset(x = animatedOffset.roundToPx(), y = 0)
                                    }
                                    .width(tabWidth)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .graphicsLayer {
                                            rotationZ = giggleRotation.value
                                            scaleX = giggleScale.value
                                            scaleY = giggleScale.value
                                        }
                                        .size(width = tabWidth - 6.dp, height = 54.dp)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(
                                            if (isLight) {
                                                Brush.linearGradient(
                                                    colors = listOf(
                                                        MaterialTheme.colorScheme.primary,
                                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.92f)
                                                    )
                                                )
                                            } else {
                                                when (themeState) {
                                                    "blackgold" -> RefinedGoldGradient
                                                    "Satin Pink" -> RefinedPinkGradient
                                                    "readerblacknew" -> RefinedMidnightGradient
                                                    "Ocean Blue" -> RefinedOceanGradient
                                                    "cyne" -> RefinedCyanGradient
                                                    "readerpurple" -> RefinedPurpleGradient
                                                    "readerblood" -> RefinedBloodGradient
                                                    else -> RefinedForestGradient
                                                }
                                            }
                                        )
                                )
                            }

                            // The centre stays genuinely transparent; the altar
                            // is rendered as a sibling in this real opening.

                            Row(
                                modifier = Modifier.fillMaxSize(),
                                horizontalArrangement = Arrangement.Start,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                tabs.forEachIndexed { index, title ->
                                    val isSelected = selectedTab == index
                                    if (index == 2) {
                                        // ── Gutter for the day / night toggle.
                                        // The glyph itself is drawn OVER the
                                        // panel (see below) because GlassPanel
                                        // clips its children and we want the
                                        // body to breach the top edge, so this
                                        // only reserves the space for it.
                                        Spacer(modifier = Modifier.width(modeGutter))
                                    }
                                    Column(
                                        modifier = Modifier
                                            .width(tabWidth)
                                            .clip(RoundedCornerShape(16.dp))
                                            .clickable { selectedTab = index }
                                            .padding(vertical = 4.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Box(
                                            modifier = Modifier.height(24.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                painter = painterResource(id = icons[index]),
                                                contentDescription = title,
                                                tint = if (isSelected) {
                                                    if (isLight) {
                                                        MaterialTheme.colorScheme.onPrimary
                                                    } else {
                                                        when (themeState) {
                                                            "blackgold" -> GoldOnGradient
                                                            "Satin Pink" -> PinkOnGradient
                                                            "readerblacknew" -> MidnightOnGradient
                                                            "Ocean Blue" -> OceanOnGradient
                                                            "cyne" -> CyanOnGradient
                                                            "readerpurple" -> PurpleOnGradient
                                                            "readerblood" -> BloodOnGradient
                                                            else -> ForestOnGradient
                                                        }
                                                    }
                                                } else {
                                                    MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.70f)
                                                },
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(1.dp))
                                        Text(
                                            title,
                                            fontSize = 10.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            letterSpacing = 0.5.sp,
                                            color = if (isSelected) {
                                                if (isLight) {
                                                    MaterialTheme.colorScheme.onPrimary
                                                } else {
                                                    when (themeState) {
                                                        "blackgold" -> GoldOnGradient
                                                        "Satin Pink" -> PinkOnGradient
                                                        "readerblacknew" -> MidnightOnGradient
                                                        "Ocean Blue" -> OceanOnGradient
                                                        "cyne" -> CyanOnGradient
                                                        "readerpurple" -> PurpleOnGradient
                                                        "readerblood" -> BloodOnGradient
                                                        else -> ForestOnGradient
                                                    }
                                                }
                                            } else {
                                                MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.70f)
                                            }
                                        )
                                    }
                                }
                            }
                        }
                        }

                    // The altar and sun / moon occupy the real break between
                    // the panes. They remain siblings because each pane clips
                    // its own content at its separate rounded edge.
                    //
                    // Deliberately no .align() here: this Box already centres
                    // its children, and an .align() written in this lambda
                    // binds to the full-screen Box further out, which is what
                    // shoved the glyph to the far left of the screen.
                    val barIsLight =
                        MaterialTheme.colorScheme.background.luminance() > 0.5f
                    val preFlipBackground = MaterialTheme.colorScheme.background
                    // The altar opens (beam, flared halo, surging bowl) while
                    // the Celestial Arc is flying, and the puck itself leaves
                    // the altar for the duration -- the flying body IS the
                    // icon, and the new one rises back out of the bowl.
                    val celestialFlying = modeSwitchController.isRunning &&
                        modeSwitchController.animation ==
                        com.lorelight.ui.theme.modeswitch.ModeSwitchAnimation.CELESTIAL_ARC
                    // ---- The companion who lives on the altar ----------
                    // He borrows the puck's face so he can talk with it. If
                    // his corpus fails to load he is simply null and the
                    // toggle behaves exactly as it always did.
                    val companionFace =
                        com.lorelight.ui.theme.modeswitch.celestial
                            .rememberCelestialFaceState()
                    val companion =
                        com.lorelight.companion.rememberCompanionState(appVersionCode = 3)
                    // Screens and view models deep in the app cannot reach
                    // this local val, so he is published on a small bus --
                    // the same pattern AppSettingsSignal already uses. Cleared
                    // on dispose so nothing holds a dead composition.
                    androidx.compose.runtime.DisposableEffect(companion) {
                        com.lorelight.companion.CompanionBus.attach(companion)
                        onDispose {
                            com.lorelight.companion.CompanionBus.attach(null)
                        }
                    }
                    // Consecutive-days counter. Nothing else in the app tracks
                    // it, and without it his streak lines can never fire.
                    LaunchedEffect(companion) {
                        if (companion != null) {
                            com.lorelight.companion.CompanionBus.noteLaunch(context)
                        }
                    }
                    // The facts he is allowed to know, refreshed whenever the
                    // library or the screen actually changes: library size,
                    // reading vs browsing, and any book left hanging.
                    LaunchedEffect(companion, importedNovels, showReader) {
                        if (companion != null) {
                            com.lorelight.companion.CompanionBus.publishSignals(
                                importedNovels,
                                showReader
                            )
                            com.lorelight.companion.CompanionBus.noteLibrary(
                                importedNovels
                            )
                        }
                    }
                    // SURFACE GATE. He is only drawn on the altar in the tab
                    // shell, so he may only talk while one of the four tabs --
                    // Library, History, Browse, Settings -- is what the user is
                    // looking at. Anything he earns behind a reader or a
                    // details page is held and spoken on the way back out.
                    //
                    // A source page is NOT one of those four tabs even
                    // though the tab is still what is on the nav stack: it
                    // removes the whole bottom bar, and he is drawn inside
                    // that bar. Without this last term he was told he was on
                    // screen while nothing of him was composed, so a line
                    // earned by adding a book was spoken into a bubble that
                    // did not exist -- and because the bubble is what reports
                    // back that it has finished, he stayed "speaking" for the
                    // rest of the session and silently swallowed every line
                    // after it. That is the whole reason he went mute.
                    val companionOnScreen =
                        navStack.lastOrNull() is ScreenDestination.Tab &&
                            !showReader &&
                            !com.lorelight.browse.ui.browseInSourceState.value
                    LaunchedEffect(companion, companionOnScreen) {
                        if (companion != null) {
                            com.lorelight.companion.CompanionBus.setOnScreen(
                                companionOnScreen
                            )
                        }
                    }
                    val companionReduceMotion = try {
                        android.provider.Settings.Global.getFloat(
                            context.contentResolver,
                            android.provider.Settings.Global.TRANSITION_ANIMATION_SCALE,
                            1f
                        ) == 0f
                    } catch (_: Throwable) {
                        false
                    }

                    // Floats above the puck. graphicsLayer rather than offset
                    // so it adds NO layout height and can never shift the
                    // bottom bar, no matter how long the line is.
                    com.lorelight.companion.CompanionHost(
                        state = companion,
                        faceState = companionFace,
                        isLightTheme = barIsLight,
                        reduceMotion = companionReduceMotion,
                        // zIndex so the bubble paints OVER the altar and the
                        // puck instead of under them -- it is the topmost
                        // thing on the screen for as long as it is up.
                        modifier = Modifier
                            .zIndex(20f)
                            .graphicsLayer {
                                // Sits just clear of the puck's head. 96 left
                                // an obvious empty gap that made the bubble
                                // read as a floating notification rather than
                                // as something he is saying.
                                translationY = -58.dp.toPx()
                            }
                    )

                    com.lorelight.ui.theme.modeswitch.CelestialAltar(
                        isLight = barIsLight,
                        modifier = Modifier
                            .width(90.dp)
                            .height(52.dp),
                        arcActive = celestialFlying,
                        arcProgress = { modeSwitchController.progress.value },
                        descent = { modeSwitchController.descent.value }
                    )
                    com.lorelight.ui.theme.modeswitch.CelestialModeToggle(
                        isLight = barIsLight,
                        glyphSize = 56.dp,
                        faceOverride = companionFace,
                        // ---- COMPANION PROPS -------------------------------
                        // Drawn on their own layer above the body, so a prop
                        // never fights the talking face for control: he can
                        // wave and speak in the same breath.
                        //
                        // The ink has to contrast with the BODY, not the page,
                        // and the body is bright in BOTH themes. So take the
                        // dark half of the pair either way -- onSurface in
                        // light, surface in dark -- rather than the usual
                        // on-colour, which would go pale exactly when it needs
                        // to be dark.
                        propOverlay = {
                            val activeCompanion = companion
                            if (activeCompanion != null) {
                                com.lorelight.companion.CompanionPropOverlay(
                                    state = activeCompanion.props,
                                    ink = if (barIsLight) {
                                        MaterialTheme.colorScheme.onSurface
                                    } else {
                                        MaterialTheme.colorScheme.surface
                                    },
                                    glow = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        },
                        riseAbove = 18.dp,
                        hidden = celestialFlying,
                        descent = { modeSwitchController.descent.value },
                        onPositioned = { modeSwitchController.origin = it },
                        onToggle = {
                            val goingLight = !barIsLight
                            // Tell him first: the tap cancels whatever he was
                            // saying, and the very first tap ever earns the
                            // payoff line for five launches of hinting.
                            companion?.onThemeToggled(goingLight)
                            val applyFlip = {
                                readerViewModel.appThemeMode.value =
                                    if (goingLight) "Light" else "Dark"
                            }
                            // Honour "remove animations" in developer /
                            // accessibility options.
                            val reduceMotion = try {
                                android.provider.Settings.Global.getFloat(
                                    context.contentResolver,
                                    android.provider.Settings.Global.TRANSITION_ANIMATION_SCALE,
                                    1f
                                ) == 0f
                            } catch (_: Throwable) {
                                false
                            }
                            if (reduceMotion || modeSwitchController.isRunning ||
                                modeSwitchController.isBusy) {
                                applyFlip()
                            } else {
                                modeSwitchScope.launch {
                                    modeSwitchController.play(
                                        // Not rootView: the DecorView's
                                        // context wraps the application, not
                                        // the Activity, so the window (and
                                        // therefore PixelCopy) cannot be
                                        // reached from it.
                                        view = modeSwitchView,
                                        pool = modeSwitchPool,
                                        targetLight = goingLight,
                                        flip = applyFlip,
                                        fallbackColor = preFlipBackground
                                    )
                                }
                            }
                        }
                    )
                    }
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                MainTabContentBlock()
            }
        }

        AnimatedVisibility(
            visible = selectedNovelForDetails != null,
            enter = slideInVertically(
                initialOffsetY = { it / 8 },
                animationSpec = tween(320, easing = FastOutSlowInEasing)
            ) + fadeIn(tween(220)),
            exit = slideOutVertically(
                targetOffsetY = { it / 8 },
                animationSpec = tween(260, easing = FastOutSlowInEasing)
            ) + fadeOut(tween(160))
        ) {
            val selected = selectedNovelForDetails
            val novel = selected?.let { sel -> importedNovels.firstOrNull { it.id == sel.id } ?: sel }
            if (novel != null) {
                val identityMatch: (com.lorelight.data.model.Novel) -> Boolean = {
                    it.id == novel.id ||
                    (novel.pluginId != null &&
                     it.pluginId == novel.pluginId &&
                     it.pluginNovelPath == novel.pluginNovelPath)
                }
                androidx.activity.compose.BackHandler(enabled = !showReader) { goBackOneLevel() }
                // Details owns a full-bleed hero that has to run under the
                // clock, so the light-mode status-bar band stands down for as
                // long as this screen is composed. Tied to composition rather
                // than to selectedNovelForDetails so the band always comes back
                // on exit, including when the reader is popped on top first.
                androidx.compose.runtime.DisposableEffect(Unit) {
                    MainActivity.detailsVisible.value = true
                    onDispose { MainActivity.detailsVisible.value = false }
                }
                DetailsScreen(
                    novel = novel,
                    onBack = { goBackOneLevel() },
                    heroImageRes = heroImageRes,
                    isLoadingDetails = detailsLoading,
                    onUpdateCurrentChapter = { n, chapterIndex, chapterName ->
                        val updatedNovel = n.copy(
                            currentChapter = chapterName,
                            currentChapterIndex = chapterIndex,
                            lastReadTimestamp = System.currentTimeMillis()
                        )
                        importedNovels = importedNovels.map {
                            if (it.id == n.id) updatedNovel else it
                        }
                        selectedNovelForDetails = updatedNovel
                        currentNovel = updatedNovel
                        // The chapter list's highlight follows this stamp. It is
                        // recorded here, when a chapter is genuinely opened, so no
                        // part of the UI has to infer "where am I" from a name.
                        com.lorelight.data.chapters.ChapterReadStore.setCurrent(
                            context,
                            updatedNovel,
                            chapterIndex
                        )
                        // Explicit chapter pick -> opens selected chapter at page 1
                        mangaReaderViewModel.init(updatedNovel, forceChapterIndex = chapterIndex, forceChapterName = chapterName)
                        readerViewModel.startReading(updatedNovel, startChapterIndex = chapterIndex, startChapterName = chapterName)
                        showReader = true
                    },
                    onReadClick = {
                        // Plain "Continue" -> resume the saved position.
                        mangaReaderViewModel.init(novel)
                        readerViewModel.startReading(novel)
                        showReader = true
                    },
                    onDownloadWhole = { n ->
                        readerViewModel.startDownloadWhole(n)
                    },
                    onMigrated = { migrated ->
                        // The migrator rewrote pluginId / chapter lists / the
                        // resolved reading position. Swap the row in place; the
                        // debounced LaunchedEffect(importedNovels) above then
                        // persists it on the same path Delete already uses.
                        importedNovels = importedNovels.map {
                            if (it.id == migrated.id) migrated else it
                        }
                        selectedNovelForDetails = migrated
                        if (currentNovel?.id == migrated.id) currentNovel = migrated
                    },
                    isInLibrary = importedNovels.any(identityMatch),
                    onOpenInBrowser = {
                        val pid = novel.pluginId
                        if (pid != null && com.lorelight.manga.util.MangaNamingUtils.isMangaPluginId(pid)) {
                            val sourceId = com.lorelight.manga.util.MangaNamingUtils.toSourceId(pid)
                            val mangaPath = novel.pluginNovelPath ?: novel.sourceUrl
                            browseNovelScope.launch {
                                try {
                                    val sourceManager = Injekt.get<tachiyomi.domain.source.service.SourceManager>()
                                    sourceManager.isInitialized.first { it }
                                    val source = sourceId?.let { sourceManager.get(it) }
                                    if (source is eu.kanade.tachiyomi.source.online.HttpSource && mangaPath != null) {
                                        val webUrl = if (mangaPath.startsWith("http")) mangaPath else source.baseUrl.trimEnd('/') + "/" + mangaPath.trimStart('/')
                                        context.startActivity(
                                            android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(webUrl))
                                                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                        )
                                    } else {
                                        android.widget.Toast.makeText(context, "Couldn't open in browser", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Exception) {
                                    android.widget.Toast.makeText(context, "Couldn't open in browser", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }
                        } else {
                            val path = novel.pluginNovelPath ?: novel.sourceUrl
                            if (pid != null && path != null) {
                                browseNovelScope.launch {
                                    try {
                                        val webUrl = com.lorelight.browse.js.JSPluginEngine.resolveUrl(context, pid, path, true)
                                        context.startActivity(
                                            android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(webUrl))
                                                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                        )
                                    } catch (e: Exception) {
                                        android.widget.Toast.makeText(context, "Couldn't open in browser", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        }
                    },
                    onToggleLibrary = {
                        val inLib = importedNovels.any(identityMatch)
                        if (inLib) {
                            com.lorelight.data.local.NovelRemovalManager.removeNovelFromLibrary(context, novel)
                            importedNovels = importedNovels.filter { it.id != novel.id }
                            val isOnline = novel.isOnline || !novel.sourceUrl.isNullOrBlank() || !novel.pluginId.isNullOrBlank()
                            if (!isOnline && selectedNovelForDetails?.id == novel.id) {
                                selectedNovelForDetails = null
                            }
                        } else {
                            if (!importedNovels.any(identityMatch)) {
                                importedNovels = importedNovels + novel
                                com.lorelight.data.local.NovelPreferences.saveNovelsToPrefs(context, importedNovels)
                                // He reacts to the add, and re-counts the pile.
                                com.lorelight.companion.CompanionBus.onLibraryAdd(novel)
                                com.lorelight.companion.CompanionBus.noteLibrary(importedNovels)
                                val coverUrl = novel.coverImageBase64
                                if (coverUrl != null && (coverUrl.startsWith("http://", ignoreCase = true) || coverUrl.startsWith("https://", ignoreCase = true))) {
                                    browseNovelScope.launch {
                                        val localPath = com.lorelight.data.local.CoverStorage.downloadAndSaveCover(context, novel.id, coverUrl)
                                        if (localPath != null) {
                                            val updatedNovel = novel.copy(coverImageBase64 = localPath)
                                            importedNovels = importedNovels.map { if (it.id == novel.id) updatedNovel else it }
                                            com.lorelight.data.local.NovelPreferences.saveNovelsToPrefs(context, importedNovels)
                                        }
                                    }
                                }
                            }
                        }
                        android.widget.Toast.makeText(
                            context,
                            if (inLib) "Removed from Library" else "Added to Library",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                )
            }
        }

        // Draws the pre-flip screenshot on top and takes it apart. Must be the
        // LAST child of this Box so it covers the Scaffold and the details
        // sheet. Renders literally nothing when no switch is in flight.
        com.lorelight.ui.theme.modeswitch.ModeSwitchOverlay(controller = modeSwitchController)
    }

    AnimatedVisibility(
        visible = showReader,
        enter = slideInVertically(
            initialOffsetY = { it / 8 },
            animationSpec = tween(320, easing = FastOutSlowInEasing)
        ) + fadeIn(tween(220)),
        exit = slideOutVertically(
            targetOffsetY = { it / 8 },
            animationSpec = tween(260, easing = FastOutSlowInEasing)
        ) + fadeOut(tween(160))
    ) {
        val currentActiveNovel = activeNovel
        if (currentActiveNovel?.isManga == true) {
            LaunchedEffect(currentActiveNovel.id) {
                if (mangaReaderViewModel.uiState.value.novel?.id != currentActiveNovel.id) {
                    mangaReaderViewModel.init(currentActiveNovel)
                }
            }
            com.lorelight.manga.reader.MangaReaderScreen(
                viewModel = mangaReaderViewModel,
                onClose = { goBackOneLevel() }
            )
        } else {
            com.lorelight.ui.reader.ReaderScreen(
                viewModel = readerViewModel,
                onClose = { goBackOneLevel() },
                onOpenFontManager = { showFontManager = true }
            )
        }
    }

    AnimatedVisibility(
        visible = showNewChapters,
        enter = slideInVertically(
            initialOffsetY = { it / 12 },
            animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing)
        ) + scaleIn(
            initialScale = 0.96f,
            animationSpec = tween(durationMillis = 320, easing = FastOutSlowInEasing)
        ) + fadeIn(animationSpec = tween(250)),
        exit = slideOutVertically(
            targetOffsetY = { it / 12 },
            animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing)
        ) + scaleOut(
            targetScale = 0.96f,
            animationSpec = tween(durationMillis = 280, easing = FastOutSlowInEasing)
        ) + fadeOut(animationSpec = tween(200))
    ) {
        androidx.activity.compose.BackHandler {
            showNewChapters = false
        }
        com.lorelight.ui.chapters.NewChaptersScreen(
            onBack = { showNewChapters = false }
        )
    }

    if (showFontManager) {
        Dialog(
            onDismissRequest = { showFontManager = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                FontManagerScreen(
                    onBack = { showFontManager = false },
                    readerViewModel = readerViewModel
                )
            }
        }
    }

    if (isImportingEpub) {
        Dialog(
            onDismissRequest = { /* non-dismissible */ },
            properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                shadowElevation = 12.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(28.dp),
                        strokeWidth = 3.dp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Column {
                        Text(
                            text = "Opening Book",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Reading EPUB contents...",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }

    val showBatteryDialog by readerViewModel.showBatteryOptimizationDialog.collectAsState()
    if (showBatteryDialog) {
        var dontAskAgainChecked by remember { mutableStateOf(false) }
        LorelightDialog(
            onDismissRequest = { readerViewModel.dismissBatteryOptimizationDialog(dontAskAgainChecked) },
            title = {
                Text(
                    "Unrestricted Playback",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Android aggressively pauses apps when the screen is off to save battery. To ensure audio narration continues uninterrupted in the background, please grant unrestricted background battery permission.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { dontAskAgainChecked = !dontAskAgainChecked }
                    ) {
                        Checkbox(
                            checked = dontAskAgainChecked,
                            onCheckedChange = { dontAskAgainChecked = it }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "Don't ask again",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        readerViewModel.dismissBatteryOptimizationDialog(dontAskAgainChecked)
                        readerViewModel.launchBatteryExemptionIntent(context)
                    }
                ) {
                    Text("Grant Permission", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        readerViewModel.dismissBatteryOptimizationDialog(dontAskAgainChecked)
                    }
                ) {
                    Text("Not Now", color = MaterialTheme.colorScheme.outline)
                }
            },
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(16.dp)
        )
    }
}
}
