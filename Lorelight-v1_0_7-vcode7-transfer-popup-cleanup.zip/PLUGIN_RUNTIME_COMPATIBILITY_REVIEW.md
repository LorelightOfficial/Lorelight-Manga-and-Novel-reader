# Lorelight × LNReader plugin runtime compatibility review

## Objective
Adapt Lorelight's existing direct JavaScript plugin runtime to run LNReader-compatible English and multilingual sources. This is **not** an integration of LNReader's app/plugin installer. The supplied upstream repository is retained under `reference/lnreader-plugins-master/` for traceability and future source-level comparisons.

## Scope inventory (supplied repository snapshot)
- English standalone sources: 118 active TypeScript source files; 5 are explicitly marked `.broken.ts` and excluded from the active count.
- Multi-language standalone source group (`plugins/multi`): 1 active source.
- Multisource framework: 13 families, 15 TypeScript files total (templates plus helper scripts).
- Dedicated other-language source directories were not modified as part of this compatibility pass.

## Changes in this pass
1. `@libs/fetch.fetchText(url, init, encoding)` now honors the upstream optional encoding argument by decoding the original response bytes using the requested Java charset, with UTF-8 fallback for unsupported labels.
2. `@libs/fetch.fetchFile(url, init)` now returns a base64 string for successful responses and an empty string on HTTP/network failure, matching the upstream helper's contract.
3. `TextDecoder(label)` now preserves the requested encoding and uses a native byte-to-charset bridge. UTF-8 remains the fallback path.
4. The complete supplied LNReader plugins repository is retained in `reference/lnreader-plugins-master/`; it is reference/source material, not auto-installed or executed as raw TypeScript.

## Runtime coverage observed
- Runtime entry points: `popularNovels`, `searchNovels`, `parseNovel`, `parseChapter`, `resolveUrl`, and filters.
- Core imported packages in active English/multisource sources include `@libs/fetch`, `cheerio`, `@libs/filterInputs`, `@libs/defaultCover`, `@libs/novelStatus`, `@libs/storage`, `htmlparser2`, `dayjs`, `@libs/isAbsoluteUrl`, `@libs/aes`, `urlencode`, and `qs`.
- Existing shims include the above module families plus `@/types/constants` and `@/lib/utils`.
- Source patterns found include `Headers`, `FormData`, `AbortController`, `FileReader`, `TextEncoder`, `TextDecoder`, `Buffer`, `URLSearchParams`, and Base64 operations.

## Known limitations / not claimed as solved
- `fetchProto` remains unsupported because protobufjs is not bundled into Lorelight's QuickJS runtime. No direct `fetchProto(...)` calls were found in the scoped active English/multi/multisrc source files in this repository snapshot.
- Multisource helper scripts such as `get_filters.ts` and `filter_refresh.ts` import Node-only modules (`fs`, `path`, `readline`, `module-alias/register`). These are repository maintenance/build helpers, not runtime source templates; they are not intended to execute inside the Android plugin runtime.
- Binary `Blob`/`File` multipart upload semantics are not fully implemented; current FormData bridge supports string fields. This needs targeted support if a scoped source starts appending binary file objects.
- This pass does not guarantee every domain works. Cloudflare/anti-bot challenges, geo/IP restrictions, login walls, site downtime, changed selectors/APIs, TLS quirks, and source-specific defects require live tests per source.
- No website-by-website live test was performed in this offline workspace.
- Android Gradle compilation was not completed in this environment; the project archive lacks `gradle-wrapper.jar` and there is no confirmed local Gradle installation. Do not treat JS syntax checks as an Android build.

## Verification performed
- JavaScript syntax checks on all files in `app/src/main/assets/browse-js/`.
- Source inventory and import/API-pattern scans limited to English, `multi`, and `multisrc`.
- ZIP integrity test after packaging.

## Recommended next test gate
Run a controlled on-device test matrix for representative active sources: install/load plugin, popular list, search, open novel details, chapter list, chapter content, pagination, filters, and cover URLs. Record failures with plugin ID, operation, HTTP status, and JS stack trace. Then fix shared runtime issues before site-specific parser changes.
