# Lorelight vcode11 — LNReader-inspired source and plugin compatibility update

## Scope

This update builds on vcode10. It keeps the separate individual-source search/catalogue state, the global search generation guard and bounded concurrency, and the vcode9 shared QuickJS/fetch runtime lifetime fixes. It adds selected LNReader application/plugin-manager behaviours that fit Lorelight's Kotlin/Compose architecture.

Reference material inspected:

- `lnreader-master/src/screens/BrowseSourceScreen/useFilterSuggestions.ts`
- `lnreader-master/src/screens/BrowseSourceScreen/components/FilterBottomSheet.tsx`
- `lnreader-master/src/plugins/types/index.ts`
- `lnreader-master/src/plugins/types/filterTypes.ts`
- `lnreader-master/src/plugins/pluginManager.ts`
- `lnreader-master/src/plugins/helpers/fetch.ts`
- `lnreader-master/src/utils/compareVersion.ts`
- `lnreader-master/src/screens/GlobalSearchScreen/hooks/useGlobalSearch.ts`

This is a compatibility adaptation, not a port of React Native components into the Android UI.

## Source screen: optional dynamic filter suggestions

Lorelight now reads the `autocomplete` flag on a plugin Text filter and renders a dedicated Compose autocomplete field only when that flag is true. Ordinary Text filters retain their existing free-text field and do not make an additional plugin call.

The optional `getFilterSuggestions(filterKey, query)` method follows the LNReader contract. If a plugin does not implement it, the runtime returns an empty list and the filter continues as a normal text input.

Implemented protections and limits:

- 250 ms debounce and a two-character minimum query.
- 5-second overall timeout (4.5-second plugin invocation budget).
- Up to six normalized `{ label, value }` suggestions per response.
- Session cache capped at 200 entries, using access-order eviction.
- Per-plugin/filter failure backoff capped at 8 seconds.
- Query changes cancel the previous suggestion coroutine; stale UI state is not applied.
- Empty-string option values are preserved, matching the upstream `FilterOption` type rather than silently dropping a valid option.

## Plugin module compatibility

Added the missing `@libs/utils` alias from the supplied LNReader app plugin package map. It exports `utf8ToBytes` and `bytesToUtf8` using Lorelight's existing TextEncoder/TextDecoder polyfills.

Existing aliases/assets retained from earlier compatibility work include `dayjs`, `urlencode`, `cheerio`, `htmlparser2`, `qs`, `@libs/fetch`, `@libs/storage`, `@libs/filterInputs`, `@libs/novelStatus`, `@libs/defaultCover`, `@libs/isAbsoluteUrl`, `@libs/aes`, `@/types/constants`, and the legacy `@/lib/utils` module.

## Repository handling

- Repository URLs and plugin bundle URLs must be absolute HTTP(S) URLs.
- Plugin IDs are validated against a conservative file-safe identifier pattern; traversal-like IDs are rejected.
- Plugin entries with missing name/version, unsafe IDs, invalid bundle URLs, or invalid optional custom extension URLs are ignored.
- One duplicate plugin ID per repository is retained; across repositories, the first valid repository entry wins.
- Repository fetches are isolated: a failed repository does not suppress valid results from other repositories.
- Up to four repositories are fetched concurrently, avoiding both sequential latency and an unbounded fan-out.
- Repository response data is read with an 8 MiB streaming limit, including responses without Content-Length.

## Plugin installation and update acceptance

New plugin bundles are downloaded to a unique staging filename and are not activated immediately. The staging runtime must initialize successfully and expose the required LNReader plugin methods:

- `popularNovels`
- `searchNovels`
- `parseNovel`
- `parseChapter`

A non-empty embedded plugin ID must match the repository ID. A bundle must expose a non-empty version. Optional methods such as `parsePage`, `resolveUrl`, and `getFilterSuggestions` remain optional.

Only after the staging checks pass is the new bundle moved into place. The previous installed file is retained as a backup until metadata persistence succeeds; a failed activation/commit attempts to restore it. Staging runtime contexts and their temporary namespaced storage are cleaned up afterward.

Plugin bundle downloads are streamed with a 12 MiB cap. This avoids first buffering an unbounded chunked response and only then checking its size.

## Version/update handling

Added a pure Kotlin version comparator for numeric dotted versions, optional `v` prefixes, build metadata and common prerelease identifiers. Update indicators and bulk updates now use the comparator rather than treating any string difference as an upgrade. Pinned plugins remain excluded from bulk update handling.

Malformed/non-version strings do not trigger a speculative update. This is intentionally conservative; unusual custom version schemes may need a future explicit comparator policy.

## Validation performed

Passed:

- `node tests/plugin-runtime-contracts.test.js`
- `node tests/search-flow-contracts.test.js`
- `node tests/plugin-acceptance-contracts.test.js`
- `node --check` for every JavaScript file under `app/src/main/assets/browse-js/`
- Standalone `kotlinc` smoke tests for `PluginVersion` ordering
- ZIP CRC/integrity test after packaging

The JavaScript runtime test also exercises the new `@libs/utils` UTF-8 byte helpers with a non-ASCII string. Structural tests verify the filter contract, suggestion bounds/backoff/cache, staged plugin validation, rollback path, temporary storage cleanup, streaming size caps, repository isolation and semantic update checks.

## Compatibility gaps deliberately not claimed as solved

- `@libs/fetch.fetchProto()` remains unsupported because the LNReader helper depends on `protobufjs` parsing and encoding. The supplied LNReader app archive contains the helper implementation but does not provide a bundled protobufjs runtime that can simply be dropped into Lorelight. The previous plugin source audit did not find direct `fetchProto()` calls in its scoped active English/multisource sources, but sources outside that snapshot may use it.
- LNReader's `customJS`/`customCSS` extension assets are preserved as repository metadata but Lorelight does not currently inject them into its native reader or generic in-app browser. Sources that depend on those WebView extensions may therefore require additional work.
- The plugin staging check validates initialization, metadata and required method presence. It intentionally does not invoke live site methods during install, because doing so would make acceptance depend on website uptime, anti-bot state and network availability.
- This update does not implement every React Native-only package or native module from LNReader. Compatibility is limited to the module surface present in Lorelight and the optional APIs listed above.
- No website-by-website live test was possible in this offline source workspace. Successful plugin acceptance does not prove that a specific website's current selectors/API or anti-bot flow is working.

## Build limitation

A complete Android Gradle build could not be performed in this environment: the supplied project snapshot is missing `gradle/wrapper/gradle-wrapper.jar`, and there is no system Gradle installation. Kotlin/Compose compilation is therefore not claimed. The standalone `PluginVersion.kt` compilation is only a focused smoke test, not an Android build.

## Suggested device acceptance matrix

After installing vcode11, validate at least one source with no autocomplete and one source with autocomplete, then test:

1. Source catalogue initial load and latest/popular switching.
2. Individual source search, repeated identical submission, empty result and pagination retry.
3. Filter autocomplete suggestions, including selecting an option and clearing the field.
4. Global Search with multiple sources returning at different speeds.
5. Install a new source, update an existing source, and attempt an invalid bundle update to confirm the previously installed plugin remains usable.
6. Open novel details and chapters; test source-specific cover headers.

Capture the plugin ID, operation, exception and any `[fetch-abort]` / `[fetch-cancel-all]` diagnostics for failures.
