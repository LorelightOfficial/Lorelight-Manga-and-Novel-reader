# Lorelight vcode12 — infinite source pagination restoration

## Scope

This update is based on three inspected implementations:

- Lorelight's previous `Lorelight-flat.zip` `SourceScreen.kt`.
- The vcode11 `SourceScreen.kt`.
- The supplied LNReader `src/screens/BrowseSourceScreen/useBrowseSource.ts` and `BrowseSourceScreen.tsx`.

The change is limited to source catalogue/search pagination and its visible continuation/retry states. It preserves the vcode10/vcode11 separation between catalogue browsing and individual-source search, as well as the shared plugin-runtime and repository-acceptance changes already present in vcode11.

## Findings

### 1. Stale pagination observer after mode/state changes

In vcode11, the observer was declared as `LaunchedEffect(gridState)`. The coroutine captured the then-current `activeQuery` and `displayItemsState`, but its effect key did not change when the UI switched from catalogue to search or when the display-state object was rebuilt. The effect could therefore decide which page to request using stale mode/list information.

The previous Lorelight implementation used one `displayItemsState` object whose derived value stayed live. vcode10/vcode11 changed that to a derived state remembered from the currently selected list (`catalogItems` or `searchItems`) but did not update the pagination effect's keys to match.

vcode12 keys the pagination effect to the active query, filter values, latest/popular mode and currently selected display-state object. The snapshot reads the live displayed count, current visible novel indices, page, duplicate-page streak and loading/end flags. Catalogue and search now always select the page belonging to the list actually shown.

### 2. Fixed six-item trigger replaced by viewport-aware prefetch

The old Lorelight version triggered when the final visible grid index was within six items of the displayed list's end. LNReader's `BrowseSourceScreen.tsx` uses scroll distance and starts fetching at approximately 1.5 viewport heights from the end, with a movement gate to avoid repeated fetches from content-size-only updates.

vcode12 keeps a LazyGrid-native trigger but scales its item prefetch window to the number of novel cells currently visible: `max(6, ceil(visibleCells * 1.5))`. This naturally scales across one-column list mode, compact grids and wider grids. The snapshot also observes scroll-position changes, and the footer is treated as evidence that the final novel cells have been reached.

### 3. Duplicate-only pages must not mean end-of-list

vcode11 compared a fetched page against existing paths and set `endReached = true` when the resulting `fresh` list was empty. That conflated two different situations:

- The plugin returned an empty successful page (a useful end-of-list signal).
- The plugin returned a non-empty page whose novels overlapped earlier pages.

LNReader's supplied `useBrowseSource.ts` marks the list complete only when the plugin response itself is empty. It tracks the highest successfully loaded page separately from the highest requested page; failed pages are un-requested so they can be retried.

vcode12 follows that contract for both catalogue and search:

- An actually empty response sets the end-of-list flag.
- Every successful non-empty response advances the loaded page, even when every novel is a duplicate.
- Fresh novel paths are appended once; duplicate paths are not rendered twice.
- A failed request does not advance the loaded page and remains retryable.

To avoid unbounded background requests from a broken source that returns the same non-empty page forever, up to three consecutive duplicate-only pages are automatically stepped through while the user is within the prefetch window. After that, a footer action allows explicit continuation. This is a safety guard, not an end-of-list signal.

### 4. Page request gating and independent lists

Catalogue and search retain separate request jobs, generations, loaded-page counters and end flags. An automatic prefetch records which page it has requested so recompositions and scroll-offset changes cannot launch that same page repeatedly. Explicit retry/continue re-arms the next page. Changing filters/latest mode continues to reset only catalogue pagination; a new search resets only search pagination.

### 5. Local Hide Library edge case

If the local `Hide Library` display filter removes every currently loaded novel, there is no visible grid to scroll. vcode12 adds a continuation/retry action to that empty state so the user can reach later pages rather than being trapped on an empty screen. The adult-content hide preference remains respected and does not trigger hidden source loading.

## Validation performed

- Expanded `tests/search-flow-contracts.test.js` to check the pagination effect keys, live display-list measurement, viewport-scaled prefetch, duplicate-only page advancement, bounded duplicate auto-continuation, explicit retry, and the Hide Library empty-state continuation.
- `node tests/plugin-runtime-contracts.test.js` passed.
- `node tests/plugin-acceptance-contracts.test.js` passed.
- `node tests/search-flow-contracts.test.js` passed.
- All JavaScript files under `app/src/main/assets/browse-js/` passed `node --check`.
- The Kotlin compiler was invoked as a syntax scan. It reported unresolved Android/Compose/project references because the app dependencies were not supplied to the standalone invocation, but no Kotlin parser/syntax diagnostics (`expecting`, unexpected tokens, unclosed declarations) were reported.
- ZIP integrity is checked after packaging.

## Not verified

A complete Android Gradle build and on-device pagination test are not available in this environment. The project has `gradlew` and `gradle-wrapper.properties` but lacks `gradle/wrapper/gradle-wrapper.jar`, and there is no installed system Gradle. No live source websites were queried. Therefore this update is source-reviewed and portable-test-verified, not a confirmed Android build/device test.

## Device acceptance test

1. Open a source with more than one page and scroll continuously past the first loaded batch. Confirm more novels append without returning to the top.
2. Continue through several batches and confirm old novels are not duplicated.
3. Repeat in List, Compact Grid and regular Grid layouts.
4. Repeat after switching Popular/Latest or a source listing category.
5. Submit an individual-source search and scroll its results; confirm search pagination is independent from catalogue pagination.
6. Submit a different search and confirm a late result from the previous query cannot append to it.
7. Test a source with overlapping page boundaries; pagination should continue rather than treating a duplicate-only page as the end.
8. Simulate a page failure; retry should request that same page.
9. Enable Hide Library until all currently loaded novels are filtered out; confirm the empty state still allows loading another page.
10. Confirm a genuinely empty plugin page stops pagination cleanly.
