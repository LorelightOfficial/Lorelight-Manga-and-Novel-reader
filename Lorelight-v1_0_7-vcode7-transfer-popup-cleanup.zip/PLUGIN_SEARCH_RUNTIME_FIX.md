# Lorelight search/runtime refactor (vcode10)

## Primary diagnosis

The reported error is not an HTTP status returned by a novel website. In the previous runtime, `JSBridge.cancelAllFetches()` rejected every pending fetch with the generic text `The operation was aborted`; the JavaScript bridge then constructed the Error in `polyfill.js` (`__fetchReject`). That matches the reported stack location much better than a server-side rejection.

The supplied vcode8 source contains a concrete way to trigger that path across unrelated sources:

- `GlobalSearchScreen` starts up to **8** source searches concurrently (`Semaphore(8)`).
- `JSPluginEngine` retains only **5** plugin contexts in its `LruCache`.
- The cache's `entryRemoved` handler unconditionally called `PluginContext.destroy()` for an evicted context.
- `destroy()` calls `JSBridge.cancelAllFetches()`, so an active source search could be destroyed simply because another source was added to the cache. This produces a shared, cross-source failure rather than a defect in every website.

There was a second QuickJS race: `invokeAsync()` used an operation mutex, but `evalString()` did not. Source-screen setup (`getFilters`, `getImageRequestInit`) and searches could therefore evaluate the same QuickJS context while an async plugin operation was suspended. Cheerio cleanup also ran after `invokeAsync()` released the mutex, allowing cleanup to overlap a later operation.

## vcode9 changes

1. **Keep active contexts alive across LRU eviction.** Every public PluginContext operation now acquires/releases a lease. If the LRU evicts a leased context, it moves to an active-context registry instead of being destroyed. It is destroyed only after the last operation and native fetch have drained. This preserves the cache's five-idle-context memory bound without cancelling active searches.
2. **Serialize all synchronous QuickJS entry points.** `evalString()` now uses the same per-context mutex as async plugin invocations. This includes filter metadata, image request settings, source metadata and settings access.
3. **Move Cheerio cleanup inside the operation lock.** `cheerio.disposeAll()` runs in `invokeAsync()`'s `finally` before releasing the operation mutex.
4. **Notify context lifecycle when native fetches drain.** The bridge exposes a pending-fetch check and calls back after the final fetch exits, so an evicted context is not destroyed while its OkHttp request is still unwinding.
5. **Make runtime destruction idempotent.** Multiple cache/lifecycle paths cannot schedule repeated teardown of the same context.
6. **Harden cancellation bookkeeping and add diagnostics.** Late AbortSignal events no longer leave stale cancellation-token markers after a request has drained. JavaScript AbortSignal cancellation logs the request host, token, elapsed time and signal reason. Native bulk cancellation logs plugin id, pending request count and cancellation reason. This distinguishes a source-generated abort from Lorelight cancelling a plugin runtime.
7. **Remove cover-header setup from the search critical path.** Each plugin's static `imageRequestInit` is serialized once when its JS context is initialized. The source screen can read the cached value immediately instead of trying to evaluate JavaScript on a context that may be busy running a search; this also avoids the old race where it evaluated that context concurrently.
8. **Retain the vcode8 request improvements.** Lorelight does not add the old 1.2-second host delay or automatic 429 retry/backoff; it keeps the LNReader-style default fetch headers, device UA fallback, high-priority catalogue covers and bounded Search All fan-out.


## vcode10 source-screen and global-search refactor

The supplied LNReader source confirms that its **individual source browse flow** keeps catalogue browsing and source search separate:

- `src/screens/BrowseSourceScreen/useBrowseSource.ts` exposes two independent hooks: `useBrowseSource()` for popular/latest listings and `useSearchSource()` for search results. Each owns its own result list, loading/error state, page tracking, generation counter and serialized promise queue.
- `BrowseSourceScreen.tsx` sends the source search only when the search bar submits (`onSubmitEditing` -> `searchSource(searchText)`). Its scroll handler chooses `searchNextPage()` or `fetchNextPage()` based on whether there is a search term.
- Search generations prevent a late response from an earlier query from appending to the current results. A failed pagination request does not mark the source as permanently exhausted; the failed page can be requested again.

Before vcode10, Lorelight `SourceScreen.kt` routed catalogue loads, source search, filter changes and latest/popular changes through the same `items` list, `reload()` job and paging path. Search was started indirectly by `LaunchedEffect(activeQuery, filterValues, showLatest)`. That made the two workflows share state and made repeated submission of an unchanged query a no-op because Compose state did not change.

vcode10 now:

1. Splits catalogue and search data into `catalogItems` and `searchItems`, each with independent loading, error, page, end-of-list, paging-job and generation state.
2. Calls `startSearch()` directly from the keyboard Search action, snapshots the trimmed query, and starts a new generation on every submission—even if the query text is unchanged.
3. Keeps filter/latest reloads on the catalogue path only; they no longer replace the active search results. The filter/listing controls are hidden while displaying search results.
4. Cancels an in-flight catalogue fetch when an explicit source search starts, prioritizing the submitted search on that plugin's serialized QuickJS context. The catalogue is reloaded when search is cleared if its earlier request had to be cancelled.
5. Gives search and catalogue separate pagination requests and stale-result guards. Failed next-page requests retain the same next page and expose a retry affordance instead of setting `endReached` permanently.
6. Resets the grid to the top when entering or leaving search mode.
7. Captures the catalogue's `showLatest` and serialized filter values before launching a request, so a request cannot observe a half-updated UI selection while a filter change is starting a replacement load.
8. Global results now carry the plugin's cached `imageRequestInit.headers` alongside the search results. This matches LNReader's global result renderer, which passes `getPlugin(id)?.imageRequestInit` into `NovelCover`; Lorelight previously used only a generic User-Agent and site Referer in the global result cards. Metadata is captured from the same plugin context as the search, avoiding a second source initialization just to render covers.

The **global search** comparison is different: LNReader's `useGlobalSearch.ts` debounces text by 300 ms, uses a configurable concurrency setting (the supplied settings file defaults it to 3), invalidates old searches with `lastSearch`, and tracks per-source progress. Lorelight previously used a fixed eight-source semaphore and cancelled the previous job without a generation guard. vcode10 now debounces global text entry by 300 ms, invalidates/cancels an old generation immediately when the text changes, caps concurrency at 3, guards every result update by generation, streams per-source results, reports progress, and adds a "Has results" filter. It also preserves each plugin's image-request headers for the cover cards. An explicit keyboard submission still runs immediately and can repeat an identical query.

## vcode10 validation additions

- The existing Node runtime-contract and browse-shim integration suites were rerun and pass.
- The source/global Kotlin files were manually reviewed and run through the available Kotlin parser check; no Kotlin syntax errors were reported. This check cannot perform Android/Compose type resolution without the missing Gradle wrapper and project dependencies.
- The portable JavaScript files still pass syntax checks.

## LNReader comparison

The supplied LNReader app source's `src/plugins/helpers/fetch.ts` implements `fetchApi()` by adding default headers and calling the platform `fetch(url, init)` directly. It does not install a global per-host delay, and it does not create an AbortController for each plugin fetch. Its `fetchTimeout()` helper is separate (`src/utils/fetch/fetch.ts`) and is not the implementation used by `fetchApi()`.

The upstream plugin examples inspected during this pass also call `fetchApi()` from NovelBuddy search and the Readwn multisource search template without supplying an AbortSignal. Those upstream plugin files may differ from the exact plugin versions installed in the user's app, but they reinforce the runtime-lifecycle diagnosis.

## vcode9 runtime verification retained

- `node tests/plugin-runtime-contracts.test.js` passes, including request-header, request-body, binary-body, independent-fetch, AbortController-diagnostic and existing shim contract tests.
- `node tests/search-flow-contracts.test.js` passes its structural checks for separate source/catalogue state, explicit same-query submission, generation guards, independent pagination/retry, frozen catalogue mode/filter snapshots, global debounce/concurrency and plugin-specific cover headers.
- Every JavaScript file in `app/src/main/assets/browse-js/` passes `node --check`.
- ZIP integrity is checked after packaging.

## Not verified

- A complete Android Gradle build was not possible in this environment: this project snapshot has `gradlew` and `gradle-wrapper.properties`, but is missing `gradle/wrapper/gradle-wrapper.jar`; no system Gradle executable is installed. Kotlin/Android compilation is therefore **not claimed**.
- No live Android device or source endpoint was available here. The fix addresses the confirmed shared runtime lifetime/concurrency defects, but the final on-device verification is still required.
- Cover metadata setup is no longer serialized behind a search, and existing Coil priority/cache behavior is preserved. Actual first-time network image latency still depends on each image host, its headers/anti-bot response, network speed and image size; first-time uncached covers cannot be literally instantaneous. No broad cover-pipeline rewrite was made in this search-focused patch.

## Device test focus

After installing this build, test Search All with several sources enabled and then test search inside one source. If a source still aborts, collect the new `[fetch-abort]` and `[fetch-cancel-all]` log entries; they now identify whether a JS AbortSignal fired or Lorelight cancelled a context, and why.

## vcode11 LNReader-inspired compatibility and acceptance update

The vcode11 extension is documented in `PLUGIN_COMPATIBILITY_VCODE11.md`. It adds optional `getFilterSuggestions()` support for Text filters, the missing `@libs/utils` UTF-8 helper alias, stronger repository-index validation with isolated bounded parallel fetches, staged plugin initialization/contract validation before activation, rollback-aware replacement, streaming size limits, and conservative semantic version comparisons. It deliberately leaves `fetchProto()` and customJS/customCSS WebView injection as explicit compatibility gaps rather than claiming unsupported parity.
