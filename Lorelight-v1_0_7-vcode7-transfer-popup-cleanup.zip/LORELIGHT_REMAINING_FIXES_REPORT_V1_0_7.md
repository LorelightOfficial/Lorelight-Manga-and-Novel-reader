# Lorelight v1.0.7 — Remaining-Issues Fix Report

**Project version retained:** `versionCode = 7`, `versionName = 1.0.7`  
**Base archive:** `Lorelight-v1_0_7-vcode7-rechecked.zip`  
**Follow-up result:** 22 existing files modified, 2 files added, 0 files removed.

## Executive result

The follow-up fixes address the remaining source-level defects identified in the previous recheck. The highest-priority correctness issues (silently incomplete plugin chapter lists, array-valued Checkbox settings, HTTPS-to-HTTP fallback, private-address plugin HTTP access, unbounded native fetch responses, lost cover request parameters, old plugin-context reuse, invisible partial repository failures, and non-awaited transfer state persistence) were changed.

The project has **not** been proven defect-free. Three plugin-compatibility gaps are explicitly still unsupported (protobuf `fetchProto`, browser-origin `localStorage`/`sessionStorage`, and runtime application of `customJS`/`customCSS`). A full Android build, device test, and live-site test could not be run in this environment.

## Changes made

### 1. Plugin chapter pagination now fails honestly

- `page-plugin-shim.js` no longer swallows a non-abort `parsePage()` failure and returns a partial chapter list as a successful parse.
- Both rejected promises and synchronous exceptions from `parsePage()` now reject the parse with the failing page context.
- Abort/cancellation continues to propagate rather than being converted into a normal parse failure.
- A plugin requesting more than the 200-page safety limit now receives an explicit failure instead of a silently truncated chapter list.

**Impact:** a source error is visible and retryable at the caller instead of presenting incomplete chapter data as complete. The 200-page cap remains an intentional safety bound.

### 2. CheckboxGroup settings retain their array shape

- `JSPluginEngine.kt` preserves array/object defaults as JSON rather than flattening them into a scalar string.
- `PluginSettingsDialog.kt` renders checkbox/multiselect-style settings as selectable options and stores selected values as a JSON array.
- Saved selections follow the declared option order for stable serialization.

**Impact:** plugins using LNReader-style CheckboxGroup filters no longer receive a text field in place of a multiselect control.

### 3. HTTPS is no longer downgraded or accepted with invalid TLS

- Removed HTTPS-to-HTTP retry in both generic crawler page and chapter paths.
- Removed the in-app browser's HTTP fallback after HTTPS errors.
- WebView SSL certificate errors are cancelled instead of bypassed.

**Impact:** connection failures remain failures; the app does not silently send those requests over cleartext HTTP or proceed through a certificate error.

### 4. Plugin HTTP requests are restricted to public Internet DNS results

- Added `PublicInternetDns.kt`, which rejects loopback, private, link-local, site-local, multicast, CGNAT/shared, reserved/documentation/benchmark IPv4, non-global/special IPv6, and local-only hostnames.
- Applied the DNS policy to plugin fetch and plugin-cover clients.
- Those clients use isolated connection pools so a connection obtained through another client cannot be reused to bypass the new DNS lookup policy.
- URL validation also rejects unsupported schemes and URL user-info, with literal local IPs checked before connection.

**Impact:** substantially reduces plugin-request SSRF exposure, including DNS names resolving to private or special-use addresses. This is a defense-in-depth implementation, not a formal guarantee against every network-routing or platform edge case.

### 5. Native plugin fetch responses have streaming and concurrency limits

- Added a 12 MiB response limit, checking `Content-Length` when present and also enforcing the limit while streaming when the header is missing or inaccurate.
- Initial buffer allocation is capped rather than trusting an untrusted response length.
- At most four native plugin response downloads are buffered concurrently.
- Cancellation exceptions are rethrown and semaphore permits are released in `finally`.

**Impact:** bounds the largest response and limits aggregate concurrent buffering. Conversion to text/Base64/JSON can still create additional temporary copies within the per-response limit.

### 6. Cover fetches preserve plugin request initialization

- Added `PluginCoverFetcher.kt` and wired it into the cover image loader.
- The cover request now carries URL, HTTP method, headers, and body from `imageRequestInit` in both source browsing and global search.
- Added a 20 MiB streamed response cap, non-success HTTP rejection, and a cache key incorporating the request method, canonicalized headers, and body.

**Impact:** covers requiring POST or a request body are no longer reduced to a GET with headers only.

### 7. Plugin context replacement is generation-safe

- New operations only acquire the current cached plugin context; they do not reuse an old context displaced by an update.
- Active contexts are tracked by instance rather than one plugin-ID map entry, so multiple in-flight generations can drain and close independently.

**Impact:** updating a plugin while its old operation is still running is less likely to route new work into a stale context or lose track of an older active instance.

### 8. Partial repository refresh failures are visible

- Repository fetch results now carry warnings for individual repository failures when other repositories succeed.
- Browse state and UI expose an incomplete-catalogue warning and a short list of failed repositories.
- All-repository failure remains an error with retry, not an empty successful catalogue.
- Default repository values are no longer persisted as a side effect of screen composition; repository mutations are serialized and committed on IO.

**Impact:** users can distinguish a genuinely empty catalogue from a partially refreshed catalogue.

### 9. Transfer state persistence now waits for durable completion

- Chapter completion/bookmark remapping waits for the serialized writer and checks its success result.
- `DbWriter.awaitBlocking()` now reports writer failures instead of returning success after a swallowed exception.
- Chapter-state snapshots are written through a synced temporary file with backup/rollback handling; interrupted replacement can recover a valid target, temporary snapshot, or backup.
- Disk write errors propagate instead of being logged and treated as a successful migration.
- Relevant plugin/repository metadata changes use synchronous preference commits; IO-bound repository removal and browse mutations run off the UI thread.

**Impact:** transfer is less likely to report successful completion before its progress/completion/bookmark remapping is persisted. It can now fail visibly when the writer cannot commit.

### 10. Unsupported compatibility shims are now explicit

- `fetchProto` now throws an actionable capability error rather than a vague generic unsupported error.
- Access to the empty `localStorage`/`sessionStorage` compatibility snapshots emits a one-time diagnostic.

These are diagnostics, not full implementations; see remaining items below.

## Test and verification results

All checks below were run against the modified working tree after the final changes in this package.

| Check | Result |
|---|---:|
| Plugin runtime integration tests | 4 passed |
| Plugin runtime contract suite | 1 passed |
| Plugin acceptance contracts | 31 passed |
| Migration/progress contracts | 14 passed |
| Source search/pagination contracts | 19 passed |
| Reader behavior contracts | 14 passed |
| Fetch timeout contracts | 8 passed |
| Cloudflare safety contracts | 5 passed |
| **Total passing test assertions/results** | **96 passed** |
| Browse JavaScript syntax checks | 11 files passed `node --check` |
| Isolated `DbWriter.kt` compile | Passed with a minimal Android Log stub |
| Isolated `PublicInternetDns.kt` compile | Passed with a minimal OkHttp DNS interface stub |
| DNS address-policy smoke test | 8 private/special examples blocked; 2 public examples allowed |
| ZIP integrity | Checked after packaging |

The contract suites check source invariants and selected behavior paths. The isolated Kotlin compiles used stubs for unavailable Android/OkHttp types; they do **not** prove full app compilation or actual OkHttp/Android integration.

## Items still not implemented or not verified

### A. `@libs/fetch.fetchProto()` — not implemented

The runtime still does not provide dynamic protobuf schema parsing/encoding. The change only makes the unsupported capability explicit. Correct implementation would require a compatible protobuf runtime and a defined input/output contract; a misleading stub was not added.

### B. `localStorage` / `sessionStorage` — not implemented as browser storage

The current QuickJS environment does not expose a real browser-origin storage snapshot. The shim remains an empty compatibility surface with a one-time diagnostic. Plugin-scoped Lorelight storage is separate and must not be mistaken for browser `localStorage` semantics.

### C. Manifest `customJS` / `customCSS` — not injected into chapter pages

The metadata remains parsed and persisted, but the current chapter renderer is Compose-based and has no general plugin-controlled chapter WebView injection lifecycle. These fields are not claimed to work. Implementing injection without an execution surface and lifecycle contract would be misleading and could introduce unsafe script/style execution.

### D. Android build, real-device behavior, and live source websites — not verified

- The archive contains `gradle-wrapper.properties` but not `gradle-wrapper.jar`.
- No system Gradle executable or Android SDK was available in the execution environment.
- Therefore a real Gradle Android build, emulator test, and physical-device test were not run.
- No live plugin repository or target novel website was exercised. The app may still encounter site-specific HTML changes, anti-bot challenges, cookies, redirects, or source-plugin defects.
- Compose gesture behavior, manga feed continuity under real image loading/rotation/process restoration, TLS/DNS behavior on Android, and cover decoding still need device validation.

## Archive scope and version

Compared with the supplied rechecked archive, the code/test delta is:

- **22 modified source/test files**
- **2 new source files** (`PluginCoverFetcher.kt`, `PublicInternetDns.kt`)
- **0 removed source/test files**
- This report is included as one additional archive document.

The Android version metadata remains `versionCode 7` and `versionName 1.0.7`.
