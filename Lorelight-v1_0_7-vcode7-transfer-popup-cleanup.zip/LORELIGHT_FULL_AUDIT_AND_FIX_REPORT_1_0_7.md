# Lorelight 1.0.7 — Full Source, Runtime, Reader and Transfer Audit

**Working source:** `Lorelight-v1_0_7-vcode12-infinite-source-pagination.zip`  
**Android metadata retained:** `versionCode = 7`, `versionName = "1.0.7"`  
**Comparator:** the uploaded `lnreader-master.zip` application source.  
**Historical comparison:** the older Lorelight vcode7 archive was used only to identify regressions; it was not used as the current source baseline.

## Scope and evidence standard

This report covers the nine requested areas using the uploaded Lorelight and LNReader application source trees. Findings are labelled as:

- **Confirmed:** directly visible in source or reproduced by a contract test.
- **Fixed in this update:** code changed and a relevant local contract/syntax test passed.
- **Remaining:** source-level defect or compatibility gap still present.
- **Not verified:** requires the individual website plugin bundles, a live website, Android build, or device/emulator.

The uploaded LNReader archive is the LNReader app repository, not the separate `lnreader-plugins` bundle repository. Therefore this report can compare app/runtime contracts but cannot truthfully certify every individual website plugin. No live source website was tested. A passing source contract test is not proof that every website is currently reachable.

---

# 1. Source screen: catalogue, search, filters, sorting and pagination

## Current implementation

Relevant file: `app/src/main/java/com/lorelight/browse/ui/SourceScreen.kt`.

The current screen has separate state for catalogue and search:

- Separate catalogue/search result collections.
- Separate page counters, loading flags, errors, end-of-list flags, jobs and generation tokens.
- Search and catalogue requests use captured filter/latest/query values so a later UI change does not mutate the request already in progress.
- Stale request generations cannot publish results into the currently displayed collection.
- The scroll observer watches the active query/filter/catalogue state and reads the current displayed item count from the grid state.
- Prefetch begins near the end of the loaded items using a viewport-scaled threshold (approximately 1.5 visible screens, with a minimum item threshold).
- A failed next-page request exposes a retry action; it does not set `endReached`.
- A successful empty page is treated as the source's end-of-list signal.
- A non-empty page containing only duplicate paths advances the source page counter. Up to three consecutive duplicate-only pages are auto-followed; after that, the UI exposes a manual “continue loading” action rather than running an unbounded request loop.

Global search in `GlobalSearchScreen.kt` is separate from per-source catalogue search. It uses a 300 ms debounce, bounded concurrency of three sources, per-source loading/error/result state, and a generation guard. Results are published as each source completes rather than waiting for every source.

## Conclusion on infinite scrolling

**The current source screen has an implemented automatic pagination loop for normal paginated sources.** It is not a fixed one-page list. It continues requesting pages as the user approaches the end, until the source returns an empty page, a request fails, or repeated duplicate-only pages reach the bounded auto-continuation limit.

Important boundary: no client can force a website to supply additional novels if that website's plugin returns an empty page, repeats the same page, or does not implement page-based pagination. For duplicate-only pages, the current implementation offers manual continuation after three automatic attempts. Therefore the precise claim is “automatic infinite-scroll pagination with bounded duplicate-page recovery,” not “every source is guaranteed to return infinitely many unique novels.”

## Historical regression comparison

The older vcode7 implementation had a failed-next-page/end-of-list failure mode. The current source keeps page failure distinct from successful empty-page completion and has a retry path. The current `tests/search-flow-contracts.test.js` asserts these behaviors.

## Remaining source-screen risks

1. The catalogue page-1 failure sets `catalogEndReached = true` after the initial load error. The screen separately shows the initial error/reload path, but this is not the same state as a successfully empty catalogue.
2. A source that ignores its page argument can repeatedly return duplicate content. The implementation intentionally stops automatic duplicate-only continuation after three pages and requires manual continuation.
3. Chapter-count badges can trigger extra `parseNovel()` requests for visible catalogue cards. The cache limits concurrency to two and caches `UNKNOWN` failures for the process session, but large catalogue scrolling can still generate avoidable network traffic.
4. Actual page semantics differ by website. The app-level pagination logic cannot verify that each plugin increments its own page parameter correctly without its plugin bundle.

**Status:** core source pagination and search-state handling are present and contract-tested. Live behavior for every website remains unverified.

# 2. Novel websites and plugin compatibility

Relevant files:

- `app/src/main/java/com/lorelight/browse/js/JSPluginEngine.kt`
- `app/src/main/java/com/lorelight/browse/js/JSBridge.kt`
- `app/src/main/assets/browse-js/libs-shims.js`
- `app/src/main/assets/browse-js/polyfill.js`
- `app/src/main/assets/browse-js/page-plugin-shim.js`

The runtime checks required plugin methods (`popularNovels`, `searchNovels`, `parseNovel`, `parseChapter`) before activating a staged bundle. It provides a JavaScript fetch bridge, request headers/body handling, redirects, cookie integration with Android WebView cookies, URL/Headers/FormData/URLSearchParams support, Cheerio-related compatibility shims, and per-plugin storage.

## Confirmed compatibility gaps

- `@libs/fetch.fetchProto()` is explicitly unsupported in `libs-shims.js`; LNReader's helper uses protobuf schema parsing, request validation/encoding, binary POST framing and response decoding. Plugins that depend on this helper are not fully compatible.
- The plugin `localStorage` and `sessionStorage` exports are placeholders and do not reproduce LNReader's WebView-captured per-plugin storage state. Lorelight's separate namespaced `@libs/storage.storage` implementation is not the same feature.
- `customJS` and `customCSS` URLs are parsed and persisted from repository entries, but no matching download/injection path was found in the native reader runtime. LNReader has a WebView injection path; Lorelight's native reader would need an intentionally designed equivalent.
- `CheckboxGroup` plugin settings are not round-tripped as a string array in the settings dialog. The model/parser and UI path still need a proper multi-select control and array serialization.
- `page-plugin-shim.js` logs and swallows ordinary `parsePage()` failures while assembling a multi-page chapter list. This can return a partial list as if it were complete. Cancellation errors are rethrown, but ordinary page failures are not surfaced as incomplete details.

## Confirmed improvements

- QuickJS contexts have use leases and active-context tracking so LRU eviction does not destroy a context with an in-flight operation/fetch.
- Plugin operations are serialized per context with an operation mutex.
- Fetch cancellation tracks pending tokens and actual OkHttp calls.
- The older global 1.2-second per-host queue and automatic 429 retry/backoff path are absent from the current JSBridge request path. Independent source requests are no longer deliberately serialized by that old delay.
- Plugin install/update staging validates the bundle before activation and has rollback behavior if activation or metadata commit fails.

## Timeout and abort mitigation added in this update

- Default QuickJS plugin-operation timeout changed from 75 seconds to **120 seconds**. The full multi-page `parseNovel(loadAllPages = true)` path retains its explicit 300-second budget; the chapter-count badge path that explicitly requests `loadAllPages = false` retains its 75-second budget.
- The JSBridge plugin-fetch clients now use a **120-second read timeout and 120-second call timeout**, rather than inheriting the shared client's 30-second read timeout. This removes one confirmed premature-timeout condition for slow source responses.
- Abort errors now retain the `AbortSignal.reason` in the message while keeping the standard “The operation was aborted” prefix and `AbortError` name. Existing cancellation behavior is retained; the reason is now diagnosable in logs/UI.

**Important limitation:** the exact reported `The operation was aborted` error is generated when a plugin's AbortSignal fires. Raising the native read/operation timeouts addresses slow-response timeout pressure, but it does not override a plugin that intentionally aborts its own request. Without the individual affected plugin bundle and a live reproduction, it would be dishonest to claim this error is proven fixed for every site. The updated abort reason makes the next occurrence diagnosable instead of hiding the reason.

# 3. Novel covers and image loading

Relevant files:

- `JSPluginEngine.kt` cover parsing and `imageRequestInit` parsing.
- `SourceScreen.kt` catalogue cover requests.
- `GlobalSearchScreen.kt` global-search cover requests.

Source-specific image headers are fetched and applied to catalogue/global-search cover requests. However, the full LNReader `imageRequestInit` contract contains method, headers and body; Lorelight's current Coil request path passes headers but drops method/body. A source requiring a POST image request or body can still show a blank cover.

## Fixed in this update

Root-relative cover URL resolution no longer concatenates the full configured `site` string and a `/path` cover. `JSPluginEngine.resolveCoverUrl()` now resolves the cover against the source base URI, so a root-relative path resolves from the host origin even when the configured site URL contains a path. Protocol-relative paths inherit the configured source scheme.

## Remaining

The method/body gap remains. Full support requires a source-aware image fetcher that preserves method, headers and body and uses a cache key that differentiates request variants. This was not silently represented as fixed.

# 4. Novel details, chapter lists and metadata

Relevant files:

- `JSPluginEngine.kt` (`parseNovel`, `parseDetails`, `parseChapter`)
- `BrowseModels.kt` (`SourceNovelDetails`, `SourceChapter`)
- `NovelMapper.kt` (`SourceNovelDetails.toNovel`)
- `page-plugin-shim.js`

The details parser maps title/name, cover, genres, summary, author, artist, status, rating, rating count, arbitrary info rows, chapter name/path, release time, chapter number, page metadata and scanlator values. The mapper creates aligned chapter-name and `lnplugin://` chapter-URL arrays and carries chapter numbers, page metadata and scanlators into the app's `Novel` model.

The page shim supports the LNReader PagePlugin-style `parsePage(novelPath, pageNo)` contract, deduplicates chapters by path, and bounds the reported page count at 200. It requests pages sequentially.

## Remaining integrity issue

A failed non-abort page request is logged and swallowed, so a partial chapter list can be returned as a normal successful detail response. This is a confirmed defect. The appropriate correction is a structured partial/incomplete result with failed page numbers and retry, or an explicit failure; silently marking the partial list complete is not safe. It remains unresolved in this update.

The uploaded LNReader application source confirms the expected plugin model and helper contracts, but the separate plugin bundles are not present, so per-site metadata quality and pagination correctness are not verified.

# 5. Chapter reading: novel and manga

## 5A. Novel reader

Relevant files:

- `app/src/main/java/com/lorelight/ui/reader/ReaderScreen.kt`
- `ReaderToolbar.kt`
- `ReaderSettingsSheet.kt`
- `ReaderContent.kt`
- `TtsPlaybackManager.kt`
- `CrawlerEngine.kt`

Novel chapter text is loaded through the chapter URL path; plugin-backed URLs are routed to `JSPluginEngine.parseChapter()` through the crawler path. The reader stores detailed per-chapter paragraph/scroll position and restores the saved position when opening a novel/session initially.

### Confirmed defect corrected

The previous chapter-change effect called `scrollToItem(0, 0)` but also cleared the `restoredKey`. The subsequent position-restoration effect could then restore the saved paragraph offset for the newly selected chapter, undoing the top-of-chapter scroll. This means the old “always starts at the top” claim was not supported by the control flow.

**Fixed in this update:** after a chapter transition, the reader now marks the new novel/chapter key as already handled by the restore effect and scrolls to item zero. That prevents a saved offset from overriding the deliberate top anchor. The initial novel/session open still uses normal resume behavior.

### Horizontal chapter navigation added

- Right-to-left swipe: next chapter.
- Left-to-right swipe: previous chapter.
- Requires at least **96 dp** of horizontal drag after Compose's horizontal gesture recognition.
- Adds a **650 ms** cooldown to suppress accidental repeated chapter changes.
- The gesture is attached to the reader content surface, not the toolbar/settings overlays.
- It is disabled while a text selection is active.

### Split-panel feature removed from Novel Reader

The Novel Reader no longer has the split-panel preference state, settings switch, toolbar branch, or split-panel-only non-TTS chapter heading. Its top toolbar is a single compact solid AMOLED-black bar. The split-panel toolbar feature remains in Manga Reader only.

## 5B. Manga reader

Relevant files:

- `MangaReaderScreen.kt`
- `MangaReaderViewModel.kt`
- `MangaReaderFeed.kt`
- `MangaChapterWindow.kt`
- `MangaWebtoonViewer.kt`
- `MangaReaderChrome.kt`
- `MangaReaderPrefs.kt`
- `MangaReaderSettingsPanel.kt`

### Continuous chapter feed

The long-strip/webtoon feed contains previous, current and next chapter pages. The ViewModel maintains a bounded five-chapter cache window (two before/current/two after) and rebuilds the visible three-chapter feed as the active chapter changes. The `LazyColumn` uses stable per-page keys (`feedItemKey`), and `MangaWebtoonViewer` maintains a page-key/pixel-offset scroll anchor across feed rebuilds. This is the mechanism that prevents a chapter-window rebuild from changing the page under the user's viewport.

The manga reader's natural chapter-crossing path updates the active chapter from the visible page and shifts the window; it does **not** increment the explicit `jumpToken`. The one-shot anchor is keyed to explicit jump requests, not every active-chapter index change. Therefore normal vertical scrolling into the next loaded chapter should preserve the continuous feed position rather than jump to the top.

This is dynamic continuous pagination, not an attempt to keep every chapter's images resident in memory at once. The bounded window is deliberate for memory and image-load control.

### Split-panel default and toolbar styling

**Fixed in this update:** Manga Reader's split toolbar preference now defaults to enabled when no explicit user preference exists. The split toolbar remains in Manga Reader settings and its two independent panels remain implemented. The split panels are now solid AMOLED black, compact 44 dp controls; the status-bar backing is also black. The single-toolbar fallback is likewise black and compact.

An explicit existing user preference of “single toolbar” is preserved; only an unset preference receives the new split-panel default.

### Position behavior boundary

Natural long-strip chapter transitions preserve the existing viewport through stable keys and the explicit-jump token guard. An explicit chapter selection/next/previous action is still a deliberate navigation command and can anchor to the requested chapter/page. Paged modes remain page-based; they do not become a single unbounded vertical strip. The user's “no automatic position jump” requirement is applied to natural manga feed continuation, not used to break explicit page/chapter navigation.

# 6. Repository manager and plugin installation

Relevant files:

- `PluginRepositoryManager.kt`
- `PluginManager.kt`
- `PluginStore.kt`
- `BrowseViewModel.kt`
- `BrowseScreen.kt`

The repository manager validates HTTP(S) URLs and safe plugin IDs, bounds repository-index downloads to 8 MB, fetches up to four repositories in parallel, and isolates failures so one repository cannot block successful ones. Plugin downloads are staged and size-limited, validated before activation, and rolled back on activation/metadata failure.

## Fixed in this update

`PluginStore.save`, `remove` and `setPinned` now serialize their complete read-modify-write operation through a process-wide mutation lock. This removes the confirmed lost-update race when separate plugin operations mutate the same installed-plugin JSON list concurrently.

## Remaining

1. `fetchAllPlugins()` catches each repository failure and returns only successful entries. If every repository fails, the ViewModel can present an ordinary empty list rather than a repository error; partial failures are not surfaced individually.
2. `BrowseViewModel.install()` and `update()` ignore the returned `Result` from `PluginManager`. `updateAll()` similarly does not aggregate/report individual failures. The UI therefore lacks reliable operation-specific error reporting.
3. Duplicate plugin IDs use first-repository-wins in Lorelight. LNReader's current app code reverses combined repository results before `uniqBy`, producing last-configured-wins. This behavior difference should be documented or aligned intentionally.
4. `customJS`/`customCSS` URLs are stored but not consumed, as described in the runtime section.

# 7. Plugin runtime, fetch, cancellation and storage

Relevant files:

- `JSPluginEngine.kt`
- `JSBridge.kt`
- `libs-shims.js`
- `polyfill.js`
- `cheerio-shim.js`
- `page-plugin-shim.js`

The runtime has a per-plugin QuickJS context, context-use leases, serialized top-level evaluation, fetch-token tracking, native OkHttp call cancellation, cookie integration, and a 120-second operation budget for default plugin operations. Full chapter-list parsing keeps its explicit 300-second budget. The fetch bridge converts RequestInit fields into native request properties and supports text and binary response representations.

## Remaining runtime hardening

- Ordinary plugin fetch responses are read fully into memory, then represented as bytes, decoded text and Base64 in the result JSON. There is no explicit streaming response-size ceiling in this path.
- `fetchProto` is unsupported.
- `localStorage`/`sessionStorage` are placeholders.
- `AbortController` is a deliberately small compatibility shim, not a complete browser implementation. Plugins using unsupported AbortSignal APIs may still differ from WebView behavior.
- The native request response is currently materialized in multiple forms; large chapter/image/API responses can increase transient memory use.

## Error diagnosis

The literal `The operation was aborted` message originates in the JS fetch shim's AbortSignal abort handler. The updated timeout settings address the native 30-second read timeout and the default 75-second plugin-operation budget, and the updated shim now preserves `signal.reason`. This is a targeted mitigation and diagnostic improvement, not proof that an individual source plugin's own abort logic is correct.

# 8. Transfer system

Relevant files:

- `NovelSourceMigrator.kt`
- `MigrateSourceDialog.kt`

The transfer dialog searches all installed alternative sources concurrently, maintains separate per-source loading/results/errors/timing state, and publishes each source result as it completes. A slow source does not prevent faster sources from displaying their matches. It tries at most two title variants per source: the exact stored title and one cleaned title. Each source has a 120-second total deadline in the dialog.

Candidate selection is explicit; the app does not auto-migrate to the first result. Migration parses the selected target novel's details and maps the chapter list to new `lnplugin://` URLs.

Reading progress is re-anchored by chapter number where possible:

1. Exact chapter-number match.
2. Closest chapter at or below the old chapter number (to avoid skipping forward past unread material), with nearest-number fallback if none is below.
3. Same index if chapter numbers cannot be resolved.
4. Reset to the first chapter if no safe anchor exists.

Completed chapters are carried by chapter number, not by matching chapter-name strings. The existing cover is retained unless missing, then the target cover is used.

## Remaining transfer limitations

- Candidate search is title-query based; it does not compute a semantic similarity score or prove two entries are the same novel. Human confirmation is correctly required.
- The transfer uses at most two search attempts; a site that needs a different query strategy may not be found.
- It launches one coroutine per target source without a global transfer-specific semaphore. The HTTP dispatcher and per-plugin runtime serialization bound some work, but a large installed source set can still create a burst of source requests.
- A 120-second outer timeout covers both attempts together; a first slow attempt can leave little time for the fallback.
- The uploaded LNReader app source does not provide an equivalent source-migration implementation to compare against.

# 9. Regression checks and verification

## Current source pagination and runtime

The following local JavaScript contract suites passed:

- `tests/plugin-acceptance-contracts.test.js`
- `tests/plugin-runtime-contracts.test.js`
- `tests/search-flow-contracts.test.js`

All `.js` files under `app/src/main/assets/browse-js/` passed `node --check`.

## Added update-specific contracts

- `tests/reader-behavior-contracts.test.js` — verifies Novel Reader split-panel removal, chapter-start restore guard, horizontal gesture threshold/direction/cooldown, Manga split-panel default, black compact chrome, stable continuous-feed keys and non-jump natural chapter-crossing contract.
- `tests/fetch-timeout-contracts.test.js` — verifies 120-second plugin operation and native fetch budgets, explicit five-minute full novel pagination budget, abort reason preservation, URI-based cover resolution and serialized PluginStore mutations.

Both new suites passed in this environment.

## Build/device/live verification status

| Check | Status |
|---|---|
| Android `versionCode` / `versionName` | Confirmed: `7` / `1.0.7` |
| Current uploaded Lorelight archive integrity | Passed before editing: 1,430 entries |
| Uploaded LNReader archive integrity | Passed before editing: 1,535 entries |
| Existing JS contract suites | Passed |
| New reader/fetch/store contract suites | Passed |
| Browse-JS syntax | Passed |
| Full Android Gradle build | Not run: uploaded project has no `gradle-wrapper.jar`; no system Gradle executable is available |
| Kotlin/Compose compile | Not verified |
| Device/emulator reader gesture/scroll test | Not run |
| Live website plugin tests | Not run; individual site plugin bundle archive not supplied |
| Repository network refresh test | Not run live |

## Final factual status

- **Source pagination:** implemented and contract-tested, with bounded duplicate-page continuation. Not every site's pagination can be certified without its plugin bundle.
- **Search/abort error:** native timeout pressure was increased to the requested 120-second budget and abort reasons are now preserved. This is not a proven universal fix for plugin-initiated aborts; live source reproduction is still required.
- **Novel reader:** split-panel feature and its settings/heading removed; chapter changes now anchor at the beginning without saved-offset restoration overriding it; deliberate left/right chapter swipes added.
- **Manga reader:** split panel retained and made the default for unset preferences; black compact toolbar styling applied; continuous webtoon feed's stable-key/window behavior is retained and natural chapter crossing does not trigger the explicit-jump anchor.
- **Repository metadata race:** fixed with a serialized mutation lock.
- **Remaining known compatibility issues:** repository/install error visibility, CheckboxGroup settings, imageRequestInit method/body, partial multi-page detail errors, custom JS/CSS, fetchProto, local/session storage parity, and ordinary fetch response-size limits.

This report does not claim that all websites are working or that a Gradle APK build has passed. Those claims require the missing plugin bundles and an Android build/device run.
