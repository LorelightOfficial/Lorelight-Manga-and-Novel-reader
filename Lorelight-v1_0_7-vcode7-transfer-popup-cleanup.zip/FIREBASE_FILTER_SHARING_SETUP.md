# Firebase filter sharing setup (Lorelight 1.0.6)

Lorelight uses Firebase Anonymous Authentication only when a user uploads a large filter set. There is no sign-in screen. Receivers can read a share without signing in, but Firestore Security Rules reject reads after the one-hour expiry. Offline QR codes continue to work without Firebase.

## Firebase Console setup

1. Create a Firebase project.
2. Register an Android app using the exact application ID from `app/build.gradle.kts`. In this ZIP it is currently `com.lorelight.app.fncydd` (not `com.lorelight.app`). Do not register a different ID unless you intentionally change the app's applicationId.
3. Download `google-services.json` and put it at `app/google-services.json`. Do not rename it.
4. In Firebase Console → Authentication → Sign-in method, enable **Anonymous**.
5. In Firebase Console → Firestore Database, create a database (production mode is fine).
6. In Firestore → Rules, publish the contents of `firestore.rules` from this project. Do not use open/test rules.
7. Firestore TTL is optional and is not used by this free-plan setup. The app performs best-effort cleanup of expired shares owned by the current anonymous UID on app launch and during upload/download. It does not create an anonymous account just for cleanup. The rules allow owners to list and delete only their own expired documents.
8. Build the app. The first large-filter upload signs in anonymously in the background. No user-facing account is created.

## Important notes

- Small filter sets still use the existing offline `LLTF1:` QR and need no Firebase.
- Large sets use an `LLTFR:` QR with a random 128-bit ID. Only the ID is in the QR.
- The compressed payload is stored in Firestore, not Cloud Storage. The app limits the payload to 700,000 UTF-8 bytes to stay below Firestore's 1 MiB document limit. A larger set should use the existing copy-code/offline route or be split into smaller shares.
- Expired documents are unreadable as soon as `expiresAt` passes. The app opportunistically deletes expired documents belonging to the current anonymous UID when it launches and during later sharing activity. If that device never returns, its expired documents may remain stored; this cleanup is not a guaranteed scheduled purge.
- `google-services.json` contains project/app identifiers, not server credentials. Never put a service-account JSON or Admin SDK private key in the Android app.

## Per-share automatic cleanup (free-plan approach)

Each successful online share schedules a unique one-time WorkManager request for its `expiresAt` time. The worker requires a network connection and attempts to delete only that share if it is expired and its `ownerUid` still matches the device's current anonymous Firebase UID. WorkManager persists scheduled work across app restarts and reboots, but Android may delay execution due to battery/network constraints. The app also performs owner-only expired-share cleanup on startup and opportunistically during sharing/importing. Firestore rules independently reject reads after expiry.

No Firestore TTL policy is required for this approach. If a device never runs the app again, or its anonymous UID is deleted before cleanup, its old documents may remain. Account deletion does not automatically delete Firestore documents.
