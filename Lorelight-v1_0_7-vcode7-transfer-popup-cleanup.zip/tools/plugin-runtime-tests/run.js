const { spawnSync } = require('child_process');
const path = require('path');
for (const file of ['file-reader.test.js', 'url.test.js', 'fetch-body.test.js', 'cheerio-htmlparser.test.js']) {
  const result = spawnSync(process.execPath, [path.join(__dirname, file)], { stdio: 'inherit' });
  if (result.status !== 0) process.exit(result.status || 1);
}
