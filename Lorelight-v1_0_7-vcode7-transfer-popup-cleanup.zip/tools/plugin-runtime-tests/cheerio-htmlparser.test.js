const fs = require('fs');
const vm = require('vm');
const path = require('path');
const assets = path.resolve(__dirname, '../../app/src/main/assets/browse-js');
const modules = {};
const native = {
  log() {},
  cheerioParse() { return 1; },
  htmlparse() { return JSON.stringify([
    { t: 4, n: '!doctype', x: '!doctype html' },
    { t: 0, n: 'div', a: {} }, { t: 0, n: 'img', a: {} },
    { t: 1, x: 'x' }, { t: 2, n: 'div' }
  ]); },
  cheerioNodeInfo(handle) { return JSON.stringify({ type: handle === 2 ? 'text' : 'tag', name: handle === 2 ? '#text' : 'div', nodeType: handle === 2 ? 3 : 1, attribs: { id: 'x' }, data: handle === 2 ? 'txt' : null }); },
  cheerioParent(handle) { return handle === 1 ? 3 : -1; },
  cheerioContents(handle) { return handle === 1 ? '[2]' : '[]'; },
  cheerioPrevNode() { return -1; }, cheerioNextNode() { return -1; },
  cheerioSelect() { return '[1]'; }, cheerioText() { return 'hello'; },
  cheerioHtml() { return ''; }, cheerioAttr() { return 'x'; }, cheerioAttributes() { return '{}'; }
};
const context = { console, Promise, ArrayBuffer, Uint8Array, TextEncoder, TextDecoder, encodeURIComponent, decodeURIComponent, unescape, escape, Date, Math, JSON, Object, String, Array, Error, TypeError, RegExp, Number, parseInt, isNaN, globalThis: null, __native: native, __registerModule(name, factory) { modules[name] = factory; } };
context.globalThis = context;
vm.createContext(context);
for (const file of ['polyfill.js', 'cheerio-shim.js', 'htmlparser2-shim.js']) vm.runInContext(fs.readFileSync(path.join(assets, file), 'utf8'), context, { filename: file });
const htmlparser = modules.htmlparser2;
let events = [], parser;
parser = new htmlparser.Parser({
  onprocessinginstruction: (name, data) => events.push(['doctype', name, data]),
  onopentag: (name, attrs, isVoid) => { events.push(['open', name, isVoid]); if (name === 'div' && !parser._paused) parser.pause(); },
  ontext: text => events.push(['text', text]),
  onclosetag: name => events.push(['close', name]),
  onend: () => events.push(['end'])
});
parser.write('<!doctype html><div>');
parser.end('</div>');
if (events.length !== 2) throw new Error('pause did not stop callback dispatch: ' + JSON.stringify(events));
parser.resume();
const expected = [['doctype', '!doctype', '!doctype html'], ['open', 'div', false], ['open', 'img', true], ['text', 'x'], ['close', 'div'], ['end']];
if (JSON.stringify(events) !== JSON.stringify(expected)) throw new Error('parser callback mismatch: ' + JSON.stringify(events));
const factory = modules.cheerio;
const pluginModule = { exports: {} };
factory(pluginModule, pluginModule.exports, () => {});
const $ = pluginModule.exports.load('<div/>');
let callbackNode;
$('div').each(function (index, node) { callbackNode = node; if (this !== node) throw new Error('callback this is not the DOM node'); });
if (!callbackNode || callbackNode._lHandle !== 1 || callbackNode.parent == null || callbackNode.type !== 'tag') throw new Error('Cheerio callback did not receive a DOM-like node');
console.log('PASS htmlparser2 doctype/void/pause-resume callbacks and Cheerio DOM-node callback shape');
