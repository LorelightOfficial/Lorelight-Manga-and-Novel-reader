const fs = require('fs');
const vm = require('vm');
const path = require('path');
const assets = path.resolve(__dirname, '../../app/src/main/assets/browse-js');
const modules = {};
let context;
const native = {
  log() {}, setTimeoutNative() {}, storageGet() { return null; }, storageSet() {},
  storageDelete() {}, storageKeys() { return '[]'; }, storageClear() {}, cancelFetch() {},
  fetch(url, init, token) {
    Promise.resolve().then(() => context.__fetchResolve(token, JSON.stringify({
      status: 200, statusText: 'OK', url,
      headers: { 'content-type': 'image/png' }, body: '', bodyBase64: 'AAEC/w=='
    })));
  }
};
context = {
  console, Promise, ArrayBuffer, Uint8Array, TextEncoder, TextDecoder,
  encodeURIComponent, decodeURIComponent, unescape, escape, Date, Math,
  JSON, Object, String, Array, Error, TypeError, RegExp, Number, parseInt,
  isNaN, globalThis: null, __native: native,
  __registerModule(name, factory) { modules[name] = factory; }
};
context.globalThis = context;
vm.createContext(context);
for (const file of ['polyfill.js', 'url-polyfill.js', 'libs-shims.js']) {
  vm.runInContext(fs.readFileSync(path.join(assets, file), 'utf8'), context, { filename: file });
}
(async () => {
  const blob = new context.Blob([new Uint8Array([0, 1, 2, 255])], { type: 'image/png' });
  const direct = await new Promise((resolve, reject) => {
    const reader = new context.FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
  if (direct !== 'data:image/png;base64,AAEC/w==') throw new Error('Blob/FileReader data URL mismatch: ' + direct);
  const responseBlob = await context.fetch('https://example.test/cover').then(r => r.blob());
  const responseDataUrl = await new Promise((resolve, reject) => {
    const reader = new context.FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(responseBlob);
  });
  if (responseDataUrl !== direct) throw new Error('Response.blob() integration mismatch: ' + responseDataUrl);
  console.log('PASS Blob, FileReader.readAsDataURL and fetch Response.blob integration');
})().catch(error => { console.error(error); process.exitCode = 1; });
