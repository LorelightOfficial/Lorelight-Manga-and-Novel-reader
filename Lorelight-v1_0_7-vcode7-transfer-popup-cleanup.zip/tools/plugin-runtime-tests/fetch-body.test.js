const fs = require('fs');
const vm = require('vm');
const path = require('path');
const assets = path.resolve(__dirname, '../../app/src/main/assets/browse-js');
const modules = {};
const captured = [];
const native = {
  log() {}, setTimeoutNative() {}, storageGet() { return null; }, storageSet() {}, storageDelete() {}, storageKeys() { return '[]'; }, storageClear() {}, cancelFetch() {},
  fetch(url, initJson, token) { captured.push({ url, init: JSON.parse(initJson), token }); }
};
const context = { console, Promise, ArrayBuffer, Uint8Array, TextEncoder, TextDecoder, encodeURIComponent, decodeURIComponent, unescape, escape, Date, Math, JSON, Object, String, Array, Error, TypeError, RegExp, Number, parseInt, isNaN, globalThis: null, __native: native, __registerModule(name, factory) { modules[name] = factory; } };
context.globalThis = context;
vm.createContext(context);
for (const file of ['polyfill.js', 'libs-shims.js']) vm.runInContext(fs.readFileSync(path.join(assets, file), 'utf8'), context, { filename: file });
context.fetch('https://example.test/binary', { method: 'POST', body: new Uint8Array(new Uint8Array([9, 2, 3, 8]).buffer, 1, 2) });
context.fetch('https://example.test/form', { method: 'POST', body: new context.FormData() });
const form = new context.FormData(); form.append('name', 'Lorelight'); form.append('mode', 'test');
context.fetch('https://example.test/form-data', { method: 'POST', body: form });
context.fetch('https://example.test/urlencoded', { method: 'POST', body: new context.URLSearchParams({ q: 'two words' }) });
const binary = captured[0].init.body.__lorelightBinaryBody;
const bytes = Buffer.from(binary, 'base64');
if (bytes.toString('hex') !== '0203') throw new Error('Typed-array byteOffset/byteLength lost: ' + bytes.toString('hex'));
if (!Array.isArray(captured[2].init.body.__lorelightFormData) || captured[2].init.body.__lorelightFormData.length !== 2) throw new Error('FormData string entries not preserved');
if (captured[3].init.body.__lorelightUrlSearchParams !== 'q=two+words') throw new Error('URLSearchParams body not encoded');
console.log('PASS typed-array byte ranges, string FormData and URLSearchParams request-body serialization');
