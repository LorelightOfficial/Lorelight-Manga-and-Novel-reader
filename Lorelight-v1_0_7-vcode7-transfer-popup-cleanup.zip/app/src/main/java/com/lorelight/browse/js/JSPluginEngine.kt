package com.lorelight.browse.js

// ================= WRAPPER API CONTRACT (verify against quickjs-wrapper 3.2.3) =================
// Package:              com.whl.quickjs.wrapper
// QuickJSContext.create(): QuickJSContext
// ctx.getGlobalObject(): JSObject
// ctx.createNewJSObject(): JSObject
// ctx.evaluate(String): Any?      // MUST drain the pending promise-job queue afterward
// ctx.destroy()
// JSObject.setProperty(String, JSCallFunction)
// JSObject.setProperty(String, String)
// JSObject.setProperty(String, JSObject)
// JSCallFunction: functional interface -> Any? call(Array<out Any?> args)  [Java: Object call(Object... args)]
// If the base API differs, adjust ONLY the marked calls. pump() is the one README-dependent spot.
// ==============================================================================================

import android.content.Context
import android.util.Log
import android.util.LruCache
import com.lorelight.browse.model.FilterDef
import com.lorelight.browse.model.FilterOption
import com.lorelight.browse.model.SourceChapter
import com.lorelight.browse.model.SourceNovelDetails
import com.lorelight.browse.model.SourceNovelItem
import com.lorelight.browse.repo.PluginManager
import com.whl.quickjs.wrapper.JSCallFunction
import com.whl.quickjs.wrapper.QuickJSContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExecutorCoroutineDispatcher
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.nio.charset.Charset
import androidx.compose.material3.Switch
import android.util.Base64
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class PluginException(pluginId: String, message: String) : Exception("[$pluginId] $message")

data class PluginMeta(val id: String, val name: String, val site: String, val version: String, val hasFilters: Boolean)
data class PluginImageRequestInit(val method: String, val headers: Map<String, String>, val body: String? = null)
data class PluginSearchResponse(val novels: List<SourceNovelItem>, val imageRequestInit: PluginImageRequestInit)
data class PluginSettingOption(val label: String, val value: String)
data class PluginSettingDef(
    val key: String,
    val label: String,
    val type: String,
    val value: String,
    val options: List<PluginSettingOption> = emptyList()
)


/** AES-GCM adapter shared by the JS bridge and contract tests. Input/output are Base64 bytes. */
internal fun performAesGcm(mode: String, keyB64: String, ivB64: String, dataB64: String, aadB64: String): String {
    val key = Base64.decode(keyB64, Base64.DEFAULT)
    val iv = Base64.decode(ivB64, Base64.DEFAULT)
    val data = Base64.decode(dataB64, Base64.DEFAULT)
    require(key.size == 16 || key.size == 24 || key.size == 32) { "AES key must be 16, 24, or 32 bytes" }
    require(iv.isNotEmpty()) { "AES-GCM IV is empty" }
    val encrypt = mode.equals("encrypt", true)
    if (!encrypt) require(data.size >= 16) { "AES-GCM ciphertext is shorter than its authentication tag" }
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(if (encrypt) Cipher.ENCRYPT_MODE else Cipher.DECRYPT_MODE,
        SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
    if (aadB64.isNotEmpty()) cipher.updateAAD(Base64.decode(aadB64, Base64.DEFAULT))
    return Base64.encodeToString(cipher.doFinal(data), Base64.NO_WRAP)
}

private fun aStr(a: Array<out Any?>?, i: Int): String = a?.getOrNull(i)?.toString() ?: ""
private fun aInt(a: Array<out Any?>?, i: Int): Int = (a?.getOrNull(i) as? Number)?.toInt() ?: 0
private fun aLong(a: Array<out Any?>?, i: Int): Long = (a?.getOrNull(i) as? Number)?.toLong() ?: 0L

object JSPluginEngine {

    private const val IDLE_EVICT_MS = 60_000L
    private val assetShimCache = ConcurrentHashMap<String, String>()

    private fun getCachedAsset(appContext: Context, name: String): String =
        assetShimCache.getOrPut(name) {
            appContext.assets.open("browse-js/$name").bufferedReader().use { it.readText() }
        }

    private val idleScope = CoroutineScope(SupervisorJob() + kotlinx.coroutines.Dispatchers.Default)
    private val idleJobs = ConcurrentHashMap<String, kotlinx.coroutines.Job>()

    // More than one displaced generation of the same plugin may still be
    // draining fetches after rapid updates. Track contexts by instance, not ID.
    private val activeContexts = ConcurrentHashMap.newKeySet<PluginContext>()
    private val cache = object : LruCache<String, PluginContext>(5) {
        override fun entryRemoved(evicted: Boolean, key: String, oldValue: PluginContext, newValue: PluginContext?) {
            idleJobs.remove(key)?.cancel()
            if (oldValue !== newValue) {
                // A source search can still be awaiting HTTP while another source
                // is inserted into this small LRU. Never destroy a live QuickJS
                // context just because its cache entry was displaced.
                oldValue.markEvicted()
                if (oldValue.hasRuntimeActivity()) activeContexts.add(oldValue)
                else oldValue.destroy()
            }
        }
    }
    private val cacheLock = Any()
    private val creationLocks = java.util.concurrent.ConcurrentHashMap<String, Mutex>()

    fun evict(pluginId: String) {
        idleJobs.remove(pluginId)?.cancel()
        synchronized(cacheLock) { cache.remove(pluginId) }
        // A context already displaced from the LRU remains reachable until its
        // last in-flight operation/fetch drains; release callbacks destroy it.
    }

    private fun touchPluginLifecycle(pluginId: String) {
        val pc = synchronized(cacheLock) { cache.get(pluginId) } ?: return
        idleJobs.remove(pluginId)?.cancel()
        idleJobs[pluginId] = idleScope.launch {
            kotlinx.coroutines.delay(IDLE_EVICT_MS)
            synchronized(cacheLock) {
                if (cache.get(pluginId) === pc && !pc.hasRuntimeActivity()) {
                    cache.remove(pluginId)
                }
            }
            idleJobs.remove(pluginId)
        }
    }

    private fun acquireCachedContext(pluginId: String): PluginContext? = synchronized(cacheLock) {
        // activeContexts contains only displaced runtime instances kept alive
        // for their already-running operations. They may hold an older bundle
        // after an update, so never hand one to a newly-started operation.
        val pc = cache.get(pluginId)
        if (pc != null) {
            idleJobs.remove(pluginId)?.cancel()
            pc.acquireUse()
        }
        pc
    }

    private suspend fun getOrCreate(appContext: Context, pluginId: String): PluginContext {
        acquireCachedContext(pluginId)?.let { return it }
        val lock = creationLocks.getOrPut(pluginId) { Mutex() }
        return lock.withLock {
            acquireCachedContext(pluginId)?.let { return@withLock it }
            val dispatcher = Executors.newSingleThreadExecutor { r -> Thread(r, "lorelight-js-$pluginId") }.asCoroutineDispatcher()
            val app = appContext.applicationContext
            val pc = withContext(dispatcher) {
                try {
                    com.whl.quickjs.android.QuickJSLoader.init()
                } catch (e: Throwable) {
                    try {
                        System.loadLibrary("quickjs")
                    } catch (e2: Throwable) {
                        Log.w("JSPluginEngine", "QuickJS native library load warning: ${e.message} | ${e2.message}")
                    }
                }
                val ctx = QuickJSContext.create()          // WRAPPER
                val pcx = PluginContext(pluginId, ctx, dispatcher, CheerioBridge())
                // FIX A5: tell the bridge which plugin owns it, so storage
                // access cannot be redirected to another plugin's namespace.
                pcx.jsBridge = JSBridge(app, pcx, pluginId)
                pcx.install(app, pluginId)
                pcx
            }
            // Acquire before insertion: if insertion evicts another context,
            // this new context is already protected from immediate eviction.
            pc.acquireUse()
            synchronized(cacheLock) { cache.put(pluginId, pc) }
            pc
        }
    }

    private fun releasePluginContext(pc: PluginContext) {
        pc.releaseUse()
        val stillCached = synchronized(cacheLock) { cache.get(pc.pluginId) === pc }
        if (stillCached) touchPluginLifecycle(pc.pluginId)
    }

    private fun onEvictedContextMayBeDestroyed(pc: PluginContext) {
        val shouldDestroy = synchronized(cacheLock) {
            if (activeContexts.contains(pc) && pc.canDestroyAfterEviction()) {
                activeContexts.remove(pc)
                true
            } else false
        }
        if (shouldDestroy) pc.destroy()
    }

    private suspend fun <T> withPluginContext(
        appContext: Context,
        pluginId: String,
        block: suspend (PluginContext) -> T
    ): T {
        val pc = getOrCreate(appContext, pluginId)
        try {
            return block(pc)
        } finally {
            releasePluginContext(pc)
        }
    }

    private fun errWrap(token: Int) =
        ".catch(function(e){__native.deliverError($token,__errStr(e));});}" +
        "catch(e){__native.deliverError($token,__errStr(e));}})();"

    suspend fun popularNovels(appContext: Context, pluginId: String, page: Int, showLatest: Boolean, filterValuesJson: String? = null): List<SourceNovelItem> =
        withPluginContext(appContext, pluginId) { pc ->
            val site = try { pc.evalString("__plugin.site||''") } catch (_: Exception) { "" }
            val filters = filterValuesJson ?: "{}"
            val json = pc.invokeAsync { t ->
                "(function(){try{var __fv=$filters;" +
                "var __o={showLatestNovels:$showLatest,filters:(__fv&&Object.keys(__fv).length)?__fv:__defaultFilters()};" +
                "Promise.resolve(__plugin.popularNovels($page,__o))" +
                ".then(function(r){__native.deliver($t,JSON.stringify(r));})" + errWrap(t)
            }
            parseItems(json, site)
        }

    suspend fun searchNovels(appContext: Context, pluginId: String, query: String, page: Int): List<SourceNovelItem> =
        searchNovelsWithImageRequestInit(appContext, pluginId, query, page).novels

    /** Search plus source-specific cover request metadata from the same live plugin context. */
    suspend fun searchNovelsWithImageRequestInit(
        appContext: Context,
        pluginId: String,
        query: String,
        page: Int
    ): PluginSearchResponse = withPluginContext(appContext, pluginId) { pc ->
        val site = try { pc.evalString("__plugin.site||''") } catch (_: Exception) { "" }
        val q = JSONObject.quote(query)
        val json = pc.invokeAsync { t ->
            "(function(){try{Promise.resolve(__plugin.searchNovels($q,$page))" +
            ".then(function(r){__native.deliver($t,JSON.stringify(r));})" + errWrap(t)
        }
        PluginSearchResponse(parseItems(json, site), parseImageRequestInit(pc.imageRequestInitJson))
    }

    suspend fun parseNovel(appContext: Context, pluginId: String, path: String, loadAllPages: Boolean = true): SourceNovelDetails =
        withPluginContext(appContext, pluginId) { pc ->
            val site = try { pc.evalString("__plugin.site||''") } catch (_: Exception) { "" }
            val p = JSONObject.quote(path)
            val shouldLoadAllPages = loadAllPages.toString()
            val json = pc.invokeAsync(timeoutMs = if (loadAllPages) 300_000 else 75_000) { t ->
                "(function(){try{Promise.resolve(__plugin.parseNovel($p)).then(function(r){" +
                "if(!r||typeof r!=='object')r={};var total=Math.max(1,Math.min(200,Number(r.totalPages)||1));" +
                "if(!$shouldLoadAllPages||typeof __plugin.parsePage!=='function'||(total<=1&&Array.isArray(r.chapters)&&r.chapters.length>0))return r;" +
                "return __lorelightLoadPluginPages(__plugin,$p,r.chapters,total).then(function(chapters){r.chapters=chapters;return r;});" +
                "}).then(function(r){__native.deliver($t,JSON.stringify(r));})" + errWrap(t)
            }
            parseDetails(json, path, site)
        }

    suspend fun parseChapter(appContext: Context, pluginId: String, path: String): String =
        withPluginContext(appContext, pluginId) { pc ->
            val p = JSONObject.quote(path)
            val json = pc.invokeAsync { t ->
                "(function(){try{Promise.resolve(__plugin.parseChapter($p))" +
                ".then(function(r){__native.deliver($t,JSON.stringify(r));})" + errWrap(t)
            }
            decodeString(json)
        }

    /** Reads source-level cover/image request headers declared by LNReader plugins. */
    suspend fun getImageRequestInit(appContext: Context, pluginId: String): PluginImageRequestInit =
        withPluginContext(appContext, pluginId) { pc -> parseImageRequestInit(pc.imageRequestInitJson) }

    private fun parseImageRequestInit(json: String): PluginImageRequestInit {
        val root = try { JSONObject(json) } catch (_: Exception) { JSONObject() }
        val headersObj = root.optJSONObject("headers") ?: JSONObject()
        val headers = LinkedHashMap<String, String>()
        val keys = headersObj.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val value = headersObj.optString(key, "")
            if (value.isNotEmpty()) headers[if (key.equals("referrer", true)) "Referer" else key] = value
        }
        return PluginImageRequestInit(
            root.optString("method", "GET").uppercase(),
            headers,
            root.optString("body", "").ifEmpty { null }
        )
    }

    /** Returns a plugin's optional pluginSettings schema without changing its defaults. */
    suspend fun getPluginSettings(appContext: Context, pluginId: String): List<PluginSettingDef> =
        withPluginContext(appContext, pluginId) { pc ->
            val json = try { pc.evalString("(function(){var schema=__plugin.pluginSettings||{};var st=require('@libs/storage').storage;var out={};Object.keys(schema).forEach(function(k){var item=schema[k]||{};var saved=st.get(k);if(saved!==undefined)item.value=saved;out[k]=item;});return JSON.stringify(out);})()") } catch (_: Exception) { "{}" }
            val root = try { JSONObject(json) } catch (_: Exception) { JSONObject() }
            val out = ArrayList<PluginSettingDef>()
            val keys = root.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val item = root.optJSONObject(key) ?: continue
                val options = ArrayList<PluginSettingOption>()
                val arr = item.optJSONArray("options")
                if (arr != null) for (i in 0 until arr.length()) {
                    val option = arr.optJSONObject(i)
                    if (option != null) {
                        val value = option.optString("value", "")
                        options.add(PluginSettingOption(option.optString("label", value), value))
                    } else {
                        val value = arr.optString(i, "")
                        if (value.isNotEmpty()) options.add(PluginSettingOption(value, value))
                    }
                }
                val raw = item.opt("value")
                // Keep arrays/objects as JSON so CheckboxGroup settings remain
                // typed when displayed and round-trip through @libs/storage.
                val value = when (raw) {
                    null, JSONObject.NULL -> ""
                    is JSONArray, is JSONObject -> raw.toString()
                    is Boolean, is Number, is String -> raw.toString()
                    else -> raw.toString()
                }
                out.add(PluginSettingDef(key, item.optString("label", key), item.optString("type", "Text"), value, options))
            }
            out
        }

    /** Persists values through the same @libs/storage contract used by LNReader sources. */
    suspend fun savePluginSettings(appContext: Context, pluginId: String, valuesJson: String) {
        withPluginContext(appContext, pluginId) { pc ->
            val literal = JSONObject.quote(valuesJson)
            pc.evalString("(function(){var vals=JSON.parse($literal);var st=require('@libs/storage').storage;Object.keys(vals).forEach(function(k){st.set(k,vals[k]);});return 'ok';})()")
            // Some sources read settings in class field initializers, so recreate the
            // plugin instance on the next operation after persistence is complete.
            evict(pluginId)
        }
    }

    suspend fun getFilters(appContext: Context, pluginId: String): List<FilterDef> =
        withPluginContext(appContext, pluginId) { pc ->
            parseFilters(pc.evalString("JSON.stringify(__plugin.filters||{})"))
        }

    /**
     * LNReader-compatible optional autocomplete hook. Plugins that do not
     * implement getFilterSuggestions remain fully compatible and return [].
     * The result is bounded and normalized before it reaches Compose.
     */
    suspend fun getFilterSuggestions(
        appContext: Context,
        pluginId: String,
        filterKey: String,
        query: String
    ): List<FilterOption> {
        val trimmed = query.trim()
        if (trimmed.length < 2) return emptyList()
        return withTimeout(5_000) {
            withPluginContext(appContext, pluginId) { pc ->
                val keyJson = JSONObject.quote(filterKey)
                val queryJson = JSONObject.quote(trimmed)
                val json = pc.invokeAsync(timeoutMs = 4_500) { token ->
                    "(function(){try{var fn=__plugin&&__plugin.getFilterSuggestions;" +
                        "if(typeof fn!=='function'){__native.deliver($token,'[]');return;}" +
                        "Promise.resolve(fn.call(__plugin,$keyJson,$queryJson)).then(function(r){" +
                        "var a=Array.isArray(r)?r:[];var out=[];for(var i=0;i<a.length&&out.length<6;i++){" +
                        "var x=a[i]||{};if(x.label==null||x.value==null)continue;" +
                        "out.push({label:String(x.label),value:String(x.value)});}" +
                        "__native.deliver($token,JSON.stringify(out));})" + errWrap(token)
                }
                parseFilterSuggestions(json)
            }
        }
    }

    /** Validates the required LNReader plugin surface without making website requests. */
    suspend fun validatePluginContract(
        appContext: Context,
        stagingPluginId: String,
        expectedPluginId: String
    ): PluginMeta = withPluginContext(appContext, stagingPluginId) { pc ->
        val json = pc.evalString(
            "(function(){var p=__plugin||{};var required=['popularNovels','searchNovels','parseNovel','parseChapter'];" +
                "var missing=required.filter(function(k){return typeof p[k]!=='function';});" +
                "return JSON.stringify({id:String(p.id||''),name:String(p.name||''),site:String(p.site||'')," +
                "version:String(p.version||''),hasFilters:!!(p.filters&&Object.keys(p.filters).length),missing:missing});})()"
        )
        val data = try { JSONObject(json) } catch (e: Exception) {
            throw PluginException(stagingPluginId, "Plugin metadata could not be read")
        }
        val missingArray = data.optJSONArray("missing") ?: JSONArray()
        val missing = (0 until missingArray.length()).map { missingArray.optString(it) }
        if (missing.isNotEmpty()) {
            throw PluginException(stagingPluginId, "Missing required plugin methods: ${missing.joinToString()}")
        }
        val embeddedId = data.optString("id", "").trim()
        if (embeddedId.isNotEmpty() && embeddedId != expectedPluginId) {
            throw PluginException(stagingPluginId, "Plugin ID mismatch (repository: $expectedPluginId, bundle: $embeddedId)")
        }
        val version = data.optString("version", "").trim()
        if (version.isEmpty()) {
            throw PluginException(stagingPluginId, "Plugin version is missing")
        }
        PluginMeta(
            id = embeddedId.ifEmpty { expectedPluginId },
            name = data.optString("name", expectedPluginId),
            site = data.optString("site", ""),
            version = version,
            hasFilters = data.optBoolean("hasFilters", false)
        )
    }

    suspend fun resolveUrl(appContext: Context, pluginId: String, path: String, isNovel: Boolean): String =
        withPluginContext(appContext, pluginId) { pc ->
            val p = JSONObject.quote(path)
            val js = "(function(){var p=$p;return (typeof __plugin.resolveUrl==='function')?String(__plugin.resolveUrl(p,$isNovel)):String((__plugin.site||'')+p);})()"
            pc.evalString(js).ifEmpty { path }
        }

    suspend fun getMeta(appContext: Context, pluginId: String): PluginMeta =
        withPluginContext(appContext, pluginId) { pc ->
            val s = pc.evalString("JSON.stringify({id:__plugin.id,name:__plugin.name,site:__plugin.site,version:__plugin.version,hasFilters:!!(__plugin.filters&&Object.keys(__plugin.filters).length)})")
            val o = try { JSONObject(s) } catch (_: Exception) { JSONObject() }
            PluginMeta(o.optString("id", pluginId), o.optString("name", pluginId), o.optString("site", ""), o.optString("version", ""), o.optBoolean("hasFilters", false))
        }

    // ---------- result parsing ----------
    private fun parseItems(json: String, site: String = ""): List<SourceNovelItem> {
        val arr = try { JSONArray(json) } catch (e: Exception) { return emptyList() }
        val out = ArrayList<SourceNovelItem>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val name = o.optString("name", "")
            val path = o.optString("path", "")
            if (name.isEmpty() || path.isEmpty()) continue
            var cover = o.optString("cover", "").ifEmpty { null }
            cover = resolveCoverUrl(cover, site)
            out.add(SourceNovelItem(name, path, cover))
        }
        return out
    }

    /** Resolve source cover paths using URL semantics, not string concatenation.
     * Root-relative paths must resolve against the site's origin even when its
     * configured base URL contains a path component; protocol-relative URLs
     * inherit the source scheme.
     */
    private fun resolveCoverUrl(raw: String?, site: String): String? {
        if (raw.isNullOrBlank() || site.isBlank()) return raw
        return try {
            val base = java.net.URI(if (site.endsWith("/")) site else "$site/")
            base.resolve(raw).toString()
        } catch (_: Exception) {
            raw
        }
    }

    private fun parseDetails(json: String, fallbackPath: String, site: String = ""): SourceNovelDetails {
        val o = try { JSONObject(json) } catch (e: Exception) { JSONObject() }
        val chapters = ArrayList<SourceChapter>()
        val chArr = o.optJSONArray("chapters")
        if (chArr != null) {
            for (i in 0 until chArr.length()) {
                val c = chArr.optJSONObject(i) ?: continue
                val path = c.optString("path", "")
                if (path.isEmpty()) continue
                val num = if (c.has("chapterNumber") && !c.isNull("chapterNumber")) c.optDouble("chapterNumber").toFloat() else null
                val scanlators = ArrayList<String>()
                when (val rawScanlator = c.opt("scanlator")) {
                    is JSONArray -> for (j in 0 until rawScanlator.length()) rawScanlator.optString(j, "").takeIf { it.isNotBlank() }?.let(scanlators::add)
                    is String -> rawScanlator.split(",").map { it.trim() }.filter { it.isNotBlank() }.forEach(scanlators::add)
                }
                chapters.add(SourceChapter(
                    c.optString("name", ""), path,
                    c.optString("releaseTime", "").ifEmpty { null }, num,
                    c.optString("page", "").ifEmpty { null }, scanlators
                ))
            }
        }
        var cover = o.optString("cover", "").ifEmpty { null }
        cover = resolveCoverUrl(cover, site)
        val info = ArrayList<com.lorelight.browse.model.SourceNovelInfo>()
        o.optJSONArray("info")?.let { arr ->
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                info.add(com.lorelight.browse.model.SourceNovelInfo(item.optString("label", ""), item.optString("value", "")))
            }
        }
        return SourceNovelDetails(
            path = o.optString("path", fallbackPath).ifEmpty { fallbackPath },
            name = o.optString("name", ""),
            cover = cover,
            genres = o.optString("genres", "").ifEmpty { null },
            summary = o.optString("summary", "").ifEmpty { null },
            author = o.optString("author", "").ifEmpty { null },
            artist = o.optString("artist", "").ifEmpty { null },
            status = o.optString("status", "").ifEmpty { null },
            rating = if (o.has("rating") && !o.isNull("rating")) o.optDouble("rating").toFloat() else null,
            ratingCount = if (o.has("ratingCount") && !o.isNull("ratingCount")) o.optInt("ratingCount") else null,
            info = info,
            chapters = chapters,
            totalPages = o.optInt("totalPages", 1).coerceAtLeast(1)
        )
    }

    private fun decodeString(json: String): String =
        try { JSONTokener(json).nextValue()?.toString() ?: "" } catch (e: Exception) { "" }

    private fun parseOptions(arr: JSONArray?): List<Pair<String, String>> {
        if (arr == null) return emptyList()
        val out = ArrayList<Pair<String, String>>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i)
            if (o != null) out.add(o.optString("label", o.optString("value", "")) to o.optString("value", ""))
            else { val s = arr.optString(i, ""); if (s.isNotEmpty()) out.add(s to s) }
        }
        return out
    }

    private fun jsonStrList(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { arr.optString(it, "") }.filter { it.isNotEmpty() }
    }

    private fun parseFilterSuggestions(json: String): List<FilterOption> {
        val arr = try { JSONArray(json) } catch (_: Exception) { return emptyList() }
        val result = ArrayList<FilterOption>(minOf(arr.length(), 6))
        for (i in 0 until minOf(arr.length(), 6)) {
            val item = arr.optJSONObject(i) ?: continue
            if (item.isNull("label") || item.isNull("value")) continue
            val label = item.optString("label", "").trim()
            val value = item.optString("value", "")
            if (label.isNotEmpty()) result.add(FilterOption(label, value))
        }
        return result
    }

    private fun parseFilters(json: String): List<FilterDef> {
        val root = try { JSONObject(json) } catch (e: Exception) { return emptyList() }
        val out = ArrayList<FilterDef>()
        val keys = root.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val f = root.optJSONObject(key) ?: continue
            val label = f.optString("label", key)
            val options = parseOptions(f.optJSONArray("options"))
            when (f.optString("type", "")) {
                "Text" -> out.add(FilterDef.TextInput(
                    key, label, f.optString("value", ""), f.optBoolean("autocomplete", false)
                ))
                "Picker" -> out.add(FilterDef.Picker(key, label, options, f.optString("value", options.firstOrNull()?.second ?: "")))
                "Checkbox" -> out.add(FilterDef.CheckboxGroup(key, label, options, jsonStrList(f.optJSONArray("value"))))
                "Switch" -> out.add(FilterDef.Switch(key, label, f.optBoolean("value", false)))
                "XCheckbox" -> {
                    val v = f.optJSONObject("value")
                    out.add(FilterDef.ExcludableCheckboxGroup(key, label, options, jsonStrList(v?.optJSONArray("include")), jsonStrList(v?.optJSONArray("exclude"))))
                }
            }
        }
        return out
    }

    // ================= per-plugin QuickJS context =================
    private class PluginContext(
        val pluginId: String,
        val ctx: QuickJSContext,
        val dispatcher: ExecutorCoroutineDispatcher,
        val cheerio: CheerioBridge
    ) : JsRuntimeHost {

        private val supervisor = SupervisorJob()
        override val scope: CoroutineScope = CoroutineScope(dispatcher + supervisor)

        lateinit var jsBridge: JSBridge
        private val deferreds = ConcurrentHashMap<Int, CompletableDeferred<String>>()
        private val activeUsers = java.util.concurrent.atomic.AtomicInteger(0)
        @Volatile private var evictedFromCache = false
        // Static image request metadata is read once at plugin install time so
        // cover loading does not have to wait behind an in-flight source search.
        @Volatile var imageRequestInitJson: String = "{}"
            private set
        // QuickJS is a single-threaded context, but suspending one invocation
        // allows another caller to enter the same context while its first set
        // of fetch promises is still pending. Serializing top-level plugin
        // operations prevents one cancelled search from aborting another
        // search's HTTP requests through the shared JSBridge.
        private val operationMutex = Mutex()
        private var tokenSeq = 1

        fun install(appContext: Context, pluginId: String) {
            val global = ctx.getGlobalObject()          // WRAPPER
            val n = ctx.createNewJSObject()             // WRAPPER
            n.setProperty("log", JSCallFunction { a -> jsBridge.log(aStr(a, 0)); null })
            n.setProperty("fetch", JSCallFunction { a -> jsBridge.fetch(aStr(a, 0), aStr(a, 1), aInt(a, 2)); null })
            n.setProperty("cancelFetch", JSCallFunction { a -> jsBridge.cancelFetch(aInt(a, 0)); null })
            n.setProperty("aesGcm", JSCallFunction { a ->
                try {
                    performAesGcm(
                        aStr(a, 0), aStr(a, 1), aStr(a, 2), aStr(a, 3), aStr(a, 4)
                    )
                } catch (e: Exception) {
                    "!ERR:" + (e.message ?: e.javaClass.simpleName)
                }
            })
            // LNReader fetchText supports legacy encodings (e.g. GBK) through TextDecoder.
            n.setProperty("decodeBase64Text", JSCallFunction { a ->
                try {
                    val bytes = Base64.decode(aStr(a, 0), Base64.DEFAULT)
                    val charset = try { Charset.forName(aStr(a, 1).ifBlank { "UTF-8" }) } catch (_: Exception) { Charsets.UTF_8 }
                    String(bytes, charset)
                } catch (e: Exception) { "!ERR:" + (e.message ?: e.javaClass.simpleName) }
            })
            n.setProperty("setTimeoutNative", JSCallFunction { a -> jsBridge.setTimeoutNative(aInt(a, 0), aLong(a, 1)); null })
            n.setProperty("storageGet", JSCallFunction { a -> jsBridge.storageGet(aStr(a, 0), aStr(a, 1)) })
            n.setProperty("storageSet", JSCallFunction { a -> jsBridge.storageSet(aStr(a, 0), aStr(a, 1), aStr(a, 2)); null })
            n.setProperty("storageDelete", JSCallFunction { a -> jsBridge.storageDelete(aStr(a, 0), aStr(a, 1)); null })
            n.setProperty("storageKeys", JSCallFunction { a -> jsBridge.storageKeys(aStr(a, 0)) })
            n.setProperty("storageClear", JSCallFunction { a -> jsBridge.storageClear(aStr(a, 0)); null })
            n.setProperty("webStorageGet", JSCallFunction { a -> jsBridge.webStorageGet(aStr(a, 0), aStr(a, 1)) })
            n.setProperty("deliver", JSCallFunction { a -> deliver(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("deliverError", JSCallFunction { a -> deliverError(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioParse", JSCallFunction { a -> cheerio.parse(aStr(a, 0)) })
            n.setProperty("cheerioDispose", JSCallFunction { cheerio.disposeAll(); null })
            n.setProperty("htmlparse", com.whl.quickjs.wrapper.JSCallFunction { args ->
                htmlToEvents(if (args.isNotEmpty() && args[0] != null) args[0].toString() else "")
            })
            n.setProperty("cheerioSelect", JSCallFunction { a -> cheerio.select(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioChildren", JSCallFunction { a -> cheerio.children(aInt(a, 0)) })
            n.setProperty("cheerioChildrenSelector", JSCallFunction { a -> cheerio.childrenSelector(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioContents", JSCallFunction { a -> cheerio.contents(aInt(a, 0)) })
            n.setProperty("cheerioPrevNode", JSCallFunction { a -> cheerio.previousNode(aInt(a, 0)) })
            n.setProperty("cheerioNextNode", JSCallFunction { a -> cheerio.nextNode(aInt(a, 0)) })
            n.setProperty("cheerioText", JSCallFunction { a -> cheerio.text(aInt(a, 0)) })
            n.setProperty("cheerioHtml", JSCallFunction { a -> cheerio.html(aInt(a, 0)) })
            n.setProperty("cheerioOuterHtml", JSCallFunction { a -> cheerio.outerHtml(aInt(a, 0)) })
            n.setProperty("cheerioAttr", JSCallFunction { a -> cheerio.attr(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioNodeInfo", JSCallFunction { a -> cheerio.nodeInfo(aInt(a, 0)) })
            n.setProperty("cheerioAttributes", JSCallFunction { a -> cheerio.attributes(aInt(a, 0)) })
            n.setProperty("cheerioRemoveAttr", JSCallFunction { a -> cheerio.removeAttr(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioClone", JSCallFunction { a -> cheerio.clone(aInt(a, 0)) })
            n.setProperty("cheerioWrap", JSCallFunction { a -> cheerio.wrap(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioNextUntil", JSCallFunction { a -> cheerio.nextUntil(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioIndex", JSCallFunction { a -> cheerio.index(aInt(a, 0)) })
            n.setProperty("cheerioHas", JSCallFunction { a -> cheerio.has(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioSetAttr", JSCallFunction { a -> cheerio.setAttr(aInt(a, 0), aStr(a, 1), aStr(a, 2)); null })
            n.setProperty("cheerioProp", JSCallFunction { a -> cheerio.prop(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioData", JSCallFunction { a -> cheerio.data(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioVal", JSCallFunction { a -> cheerio.value(aInt(a, 0)) })
            n.setProperty("cheerioHasClass", JSCallFunction { a -> cheerio.hasClass(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioAddClass", JSCallFunction { a -> cheerio.addClass(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioRemoveClass", JSCallFunction { a -> cheerio.removeClass(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioRemove", JSCallFunction { a -> cheerio.remove(aInt(a, 0)); null })
            n.setProperty("cheerioParent", JSCallFunction { a -> cheerio.parent(aInt(a, 0)) })
            n.setProperty("cheerioParents", JSCallFunction { a -> cheerio.parents(aInt(a, 0)) })
            n.setProperty("cheerioClosest", JSCallFunction { a -> cheerio.closest(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioNext", JSCallFunction { a -> cheerio.next(aInt(a, 0)) })
            n.setProperty("cheerioNextAll", JSCallFunction { a -> cheerio.nextAll(aInt(a, 0)) })
            n.setProperty("cheerioPrev", JSCallFunction { a -> cheerio.prev(aInt(a, 0)) })
            n.setProperty("cheerioPrevAll", JSCallFunction { a -> cheerio.prevAll(aInt(a, 0)) })
            n.setProperty("cheerioSiblings", JSCallFunction { a -> cheerio.siblings(aInt(a, 0)) })
            n.setProperty("cheerioIs", JSCallFunction { a -> cheerio.isMatch(aInt(a, 0), aStr(a, 1)) })
            n.setProperty("cheerioFilter", JSCallFunction { a -> cheerio.filter(aStr(a, 0), aStr(a, 1), a.getOrNull(2) == true) })
            n.setProperty("cheerioReplaceWith", JSCallFunction { a -> cheerio.replaceWith(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioBefore", JSCallFunction { a -> cheerio.before(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioAfter", JSCallFunction { a -> cheerio.after(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioAppend", JSCallFunction { a -> cheerio.append(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioPrepend", JSCallFunction { a -> cheerio.prepend(aInt(a, 0), aStr(a, 1)); null })
            n.setProperty("cheerioEmpty", JSCallFunction { a -> cheerio.empty(aInt(a, 0)); null })
            n.setProperty("cheerioCss", JSCallFunction { a -> cheerio.css(aInt(a, 0), aStr(a, 1)) })
            global.setProperty("__native", n)

            ctx.evaluate(
                "globalThis.__errStr=function(e){try{var n=(e&&e.name)?e.name:'Error';" +
                "var m=(e&&e.message!==undefined&&e.message!==null)?String(e.message):String(e);" +
                "var s=(e&&e.stack)?('\\n'+e.stack):'';return n+': '+m+s;}catch(_){return String(e);}};",
                "errstr.js"
            )

            ctx.evaluate(
                "globalThis.__defaultFilters=function(){var out={};" +
                "var f=(typeof __plugin!=='undefined'&&__plugin)?__plugin.filters:null;" +
                "if(f){for(var k in f){if(f.hasOwnProperty(k)){out[k]={value:f[k].value,type:f[k].type};}}}" +
                "return out;};",
                "deffilters.js"
            )

            evalAsset(appContext, "polyfill.js")
            evalAsset(appContext, "url-polyfill.js")
            evalAsset(appContext, "require.js")
            evalAsset(appContext, "cheerio-shim.js")
            evalAsset(appContext, "protobuf-runtime.js")
            evalAsset(appContext, "libs-shims.js")
            evalAsset(appContext, "htmlparser2-shim.js")
            evalAsset(appContext, "page-plugin-shim.js")
            evalAsset(appContext, "plugin-settings-shim.js")
            evalAsset(appContext, "dayjs.min.js")
            ctx.evaluate("if (typeof dayjs !== 'undefined') { __registerModule('dayjs', function(m){ m.exports = dayjs; }); }")
            evalAsset(appContext, "urlencode.js")
            evalAsset(appContext, "qs-shim.js")

            global.setProperty("__pluginId", pluginId)

            val src = PluginManager.pluginFile(appContext, pluginId).readText()
            val wrapper = "var module={exports:{}};var exports=module.exports;\n" +
                "(function(module,exports,require){\n" + src + "\n})(module,exports,require);\n" +
                "globalThis.__plugin=module.exports.default||module.exports;"
            ctx.evaluate(wrapper, "plugin_" + pluginId + ".js")
            // LNReader sources often read storage-backed fields before their
            // pluginSettings object is initialized (class field order). Once
            // the first instance exposes the schema, seed missing defaults,
            // then recreate the instance so those defaults are visible to
            // source fields/constructors on the second pass. Existing saved
            // values are never overwritten.
            val seeded = try {
                ctx.evaluate(
                    "globalThis.__lorelightSeedPluginSettings(globalThis.__plugin)",
                    "plugin_settings_defaults.js"
                )?.toString() == "true"
            } catch (_: Exception) { false }
            if (seeded) ctx.evaluate(wrapper, "plugin_" + pluginId + "_settings.js")

            imageRequestInitJson = try {
                ctx.evaluate("(function(){var x=__plugin.imageRequestInit||{};var h=x.headers||{};if(h&&typeof h.toJSON==='function')h=h.toJSON();return JSON.stringify({method:x.method||'GET',headers:h,body:typeof x.body==='string'?x.body:null});})()")?.toString() ?: "{}"
            } catch (e: Exception) {
                Log.w("JSPluginEngine", "Could not read imageRequestInit for $pluginId: ${e.message}")
                "{}"
            }
            try {
                val webStorageMeta = JSONObject(
                    ctx.evaluate("(function(){return JSON.stringify({enabled:!!(__plugin&&__plugin.webStorageUtilized),site:String((__plugin&&__plugin.site)||'')});})()")?.toString() ?: "{}"
                )
                jsBridge.configureWebStorage(webStorageMeta.optBoolean("enabled", false), webStorageMeta.optString("site", ""))
            } catch (e: Exception) {
                jsBridge.configureWebStorage(false, null)
                Log.w("JSPluginEngine", "Could not read Web Storage metadata for $pluginId: ${e.message}")
            }
        }


        fun acquireUse() { activeUsers.incrementAndGet() }

        fun releaseUse() {
            val remaining = activeUsers.decrementAndGet()
            if (remaining < 0) {
                activeUsers.incrementAndGet()
                Log.w("JSPluginEngine", "Unbalanced plugin context release: $pluginId")
                return
            }
            if (remaining == 0) JSPluginEngine.onEvictedContextMayBeDestroyed(this)
        }

        fun markEvicted() { evictedFromCache = true }

        fun hasRuntimeActivity(): Boolean =
            activeUsers.get() > 0 || deferreds.isNotEmpty() || (this::jsBridge.isInitialized && jsBridge.hasPendingFetches())

        fun canDestroyAfterEviction(): Boolean =
            evictedFromCache && activeUsers.get() == 0 && deferreds.isEmpty() &&
                (!this::jsBridge.isInitialized || !jsBridge.hasPendingFetches())

        override fun onFetchesDrained() {
            JSPluginEngine.onEvictedContextMayBeDestroyed(this)
        }

        private fun evalAsset(appContext: Context, name: String) {
            val js = getCachedAsset(appContext, name)
            ctx.evaluate(js, name)   // WRAPPER
        }

        // README-DEPENDENT: assumes ctx.evaluate drains the promise-job queue.
        // If 3.2.3 exposes an explicit pending-job executor, loop it here instead.
        private fun pump() {
            try { ctx.evaluate("void 0") } catch (e: Exception) { Log.d("LorelightJS", "pump: ${e.message}") }
        }

        fun deliver(token: Int, json: String) { deferreds.remove(token)?.complete(json) }
        fun deliverError(token: Int, message: String) { deferreds.remove(token)?.completeExceptionally(PluginException(pluginId, message)) }

        @Volatile private var destroyed = false

        override fun postFetchResult(token: Int, rawJson: String) {
            scope.launch {
                if (destroyed) return@launch
                try {
                    // Passing the body as a global property avoids making QuickJS
                    // lex and parse the entire (potentially huge) response as
                    // source text on every single fetch.
                    ctx.getGlobalObject().setProperty("__pendingFetchJson", rawJson)
                    ctx.evaluate("globalThis.__fetchResolve($token,globalThis.__pendingFetchJson);")
                    pump()
                } catch (e: Exception) { deliverError(token, e.message ?: e.toString()) }
            }
        }
        override fun postFetchError(token: Int, message: String) {
            scope.launch { if (destroyed) return@launch; try { ctx.evaluate("globalThis.__fetchReject($token,${JSONObject.quote(message)});"); pump() } catch (e: Exception) { deliverError(token, message) } }
        }
        override fun postTimeout(id: Int) {
            scope.launch { if (destroyed) return@launch; try { ctx.evaluate("globalThis.__timeoutFire($id);"); pump() } catch (e: Exception) { Log.d("LorelightJS", "timeout: ${e.message}") } }
        }

        suspend fun invokeAsync(timeoutMs: Long = 120_000, build: (Int) -> String): String = withContext(dispatcher) {
            operationMutex.withLock {
                val token = tokenSeq++
                val d = CompletableDeferred<String>()
                deferreds[token] = d
                try {
                    try { ctx.evaluate(build(token)); pump() }
                    catch (e: Exception) {
                        jsBridge.cancelAllFetches("Plugin operation failed before its fetches completed")
                        throw PluginException(pluginId, e.message ?: e.toString())
                    }
                    try {
                        withTimeout(timeoutMs) { d.await() }
                    } catch (e: kotlinx.coroutines.TimeoutCancellationException) {
                        // Only this operation owns the context while the mutex is held.
                        jsBridge.cancelAllFetches("Plugin operation timed out after ${timeoutMs / 1000}s")
                        throw PluginException(pluginId, "Operation timed out after ${timeoutMs / 1000}s")
                    } catch (e: kotlinx.coroutines.CancellationException) {
                        jsBridge.cancelAllFetches("Plugin operation was cancelled")
                        throw e
                    }
                } finally {
                    deferreds.remove(token)
                    // Reset Cheerio only after the operation has settled and while
                    // no other Kotlin caller can concurrently evaluate this context.
                    try { cheerio.disposeAll() }
                    catch (e: Exception) { Log.w("JSPluginEngine", "Cheerio cleanup failed for $pluginId: ${e.message}") }
                }
            }
        }

        suspend fun evalString(js: String): String = withContext(dispatcher) {
            operationMutex.withLock { (ctx.evaluate(js) as? String) ?: "" }
        }

        private fun htmlToEvents(html: String): String {
            return try {
                val doc = org.jsoup.Jsoup.parse(html)
                val arr = org.json.JSONArray()
                val visitor = object : org.jsoup.select.NodeVisitor {
                    override fun head(node: org.jsoup.nodes.Node, depth: Int) {
                        when (node) {
                            is org.jsoup.nodes.Document -> {}
                            is org.jsoup.nodes.DocumentType -> {
                                val o = org.json.JSONObject(); o.put("t", 4); o.put("n", "!doctype")
                                o.put("x", "!doctype " + node.name()); arr.put(o)
                            }
                            is org.jsoup.nodes.Element -> {
                                val o = org.json.JSONObject()
                                o.put("t", 0); o.put("n", node.normalName())
                                val a = org.json.JSONObject()
                                for (attr in node.attributes()) a.put(attr.key, attr.value)
                                o.put("a", a)
                                arr.put(o)
                            }
                            is org.jsoup.nodes.TextNode -> {
                                val o = org.json.JSONObject(); o.put("t", 1); o.put("x", node.wholeText); arr.put(o)
                            }
                            is org.jsoup.nodes.DataNode -> {
                                // htmlparser2 reports script/style raw text through ontext.
                                val o = org.json.JSONObject(); o.put("t", 1); o.put("x", node.wholeData); arr.put(o)
                            }
                            is org.jsoup.nodes.Comment -> {
                                val o = org.json.JSONObject(); o.put("t", 3); o.put("x", node.data); arr.put(o)
                            }
                            else -> {}
                        }
                    }
                    override fun tail(node: org.jsoup.nodes.Node, depth: Int) {
                        if (node is org.jsoup.nodes.Element && node !is org.jsoup.nodes.Document) {
                            val o = org.json.JSONObject(); o.put("t", 2); o.put("n", node.normalName()); arr.put(o)
                        }
                    }
                }
                org.jsoup.select.NodeTraversor.traverse(visitor, doc)
                arr.toString()
            } catch (e: Exception) { "[]" }
        }

        fun destroy() {
            if (destroyed) return
            destroyed = true
            // Do not leave native calls running after an idle/LRU eviction.
            jsBridge.cancelAllFetches("Plugin runtime was closed")
            scope.launch { try { cheerio.disposeAll(); ctx.destroy() } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError("JSPluginEngine.destroy", e) } }
                .invokeOnCompletion {
                    try { dispatcher.close() } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError("JSPluginEngine.destroyDispatcher", e) }
                    scope.cancel()
                }
        }
    }
}
