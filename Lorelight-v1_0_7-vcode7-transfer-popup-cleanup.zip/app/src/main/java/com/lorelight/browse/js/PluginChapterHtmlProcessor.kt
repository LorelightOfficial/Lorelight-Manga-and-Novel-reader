package com.lorelight.browse.js

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import com.lorelight.browse.repo.PluginManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.jsoup.Jsoup
import org.json.JSONTokener
import java.io.ByteArrayInputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

/**
 * Applies plugin-shipped DOM transforms in an isolated, network-disabled WebView
 * before Lorelight converts chapter HTML to its native reader text blocks.
 * Compose remains the actual reader surface; CSS affects browser layout/visibility
 * during extraction, not Compose typography or colors.
 */
object PluginChapterHtmlProcessor {
    private const val TAG = "PluginChapterHTML"
    private const val PROCESS_TIMEOUT_MS = 5_000L
    private val mainHandler = Handler(Looper.getMainLooper())

    suspend fun process(
        context: Context,
        pluginId: String,
        baseUrl: String,
        html: String
    ): String? {
        val app = context.applicationContext
        val cssFile = PluginManager.customCssFile(app, pluginId)
        val jsFile = PluginManager.customJsFile(app, pluginId)
        if (!cssFile.isFile && !jsFile.isFile) return null

        val css = try { cssFile.takeIf { it.isFile }?.readText(Charsets.UTF_8).orEmpty() } catch (e: Exception) {
            Log.w(TAG, "Could not read custom CSS for $pluginId", e); ""
        }
        val js = try { jsFile.takeIf { it.isFile }?.readText(Charsets.UTF_8).orEmpty() } catch (e: Exception) {
            Log.w(TAG, "Could not read custom JS for $pluginId", e); ""
        }
        if (css.isBlank() && js.isBlank()) return null

        val htmlForWebView = try { buildDocument(html, css, js) } catch (e: Exception) {
            Log.w(TAG, "Could not prepare custom assets for $pluginId", e); return null
        }

        return withContext(Dispatchers.Main.immediate) {
            withTimeoutOrNull(PROCESS_TIMEOUT_MS) {
                suspendCancellableCoroutine { continuation ->
                    val completed = AtomicBoolean(false)
                    var webView: WebView? = null
                    var timeout: Runnable? = null

                    fun destroy() {
                        timeout?.let(mainHandler::removeCallbacks)
                        val view = webView
                        webView = null
                        try { view?.stopLoading() } catch (_: Exception) {}
                        try { view?.removeAllViews() } catch (_: Exception) {}
                        try { view?.destroy() } catch (_: Exception) {}
                    }

                    fun finish(value: String?) {
                        if (!completed.compareAndSet(false, true)) return
                        destroy()
                        if (continuation.isActive) continuation.resume(value)
                    }

                    continuation.invokeOnCancellation {
                        if (Looper.myLooper() == Looper.getMainLooper()) destroy()
                        else mainHandler.post { destroy() }
                    }

                    try {
                        val view = WebView(context).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = false
                            settings.databaseEnabled = false
                            settings.allowFileAccess = false
                            settings.allowContentAccess = false
                            settings.loadsImagesAutomatically = false
                            settings.blockNetworkLoads = true
                            settings.javaScriptCanOpenWindowsAutomatically = false
                            settings.setSupportMultipleWindows(false)
                            webViewClient = object : WebViewClient() {
                                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true
                                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse =
                                    WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(ByteArray(0)))
                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    view?.postDelayed({
                                        view.evaluateJavascript(
                                            "(function(){try{return JSON.stringify({text:(document.body&&document.body.innerText)||''});}catch(e){return JSON.stringify({text:''});}})()"
                                        ) { raw ->
                                            try {
                                                val decoded = JSONTokener(raw ?: "null").nextValue()
                                                val payload = org.json.JSONObject(decoded as? String ?: "{}")
                                                val text = payload.optString("text", "")
                                                finish(text.takeIf { it.isNotBlank() })
                                            } catch (e: Exception) {
                                                Log.w(TAG, "Could not extract transformed chapter for $pluginId", e)
                                                finish(null)
                                            }
                                        }
                                    }, 100L)
                                }
                            }
                        }
                        webView = view
                        timeout = Runnable { finish(null) }.also { mainHandler.postDelayed(it, PROCESS_TIMEOUT_MS - 250L) }
                        view.loadDataWithBaseURL(
                            baseUrl.takeIf { it.startsWith("https://") || it.startsWith("http://") } ?: "https://localhost/",
                            htmlForWebView,
                            "text/html",
                            "UTF-8",
                            null
                        )
                    } catch (e: Exception) {
                        Log.w(TAG, "Custom chapter processing failed for $pluginId", e)
                        finish(null)
                    }
                }
            }
        }
    }

    private fun buildDocument(source: String, css: String, js: String): String {
        val document = Jsoup.parse(source)
        document.select("script, iframe, object, embed, base").remove()
        document.head().append(
            "<meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; font-src data:; connect-src 'none'; frame-src 'none'; object-src 'none'; form-action 'none'\">"
        )
        if (css.isNotBlank()) {
            val safeCss = css.replace(Regex("(?i)</style"), "<\\/style")
            document.head().append("<style id=\"lorelight-plugin-css\">$safeCss</style>")
        }
        if (js.isNotBlank()) {
            val safeJs = js.replace(Regex("(?i)</script"), "<\\/script")
            document.body().append("<script id=\"lorelight-plugin-js\">$safeJs</script>")
        }
        document.outputSettings().prettyPrint(false)
        return "<!doctype html>\n" + document.outerHtml()
    }
}
