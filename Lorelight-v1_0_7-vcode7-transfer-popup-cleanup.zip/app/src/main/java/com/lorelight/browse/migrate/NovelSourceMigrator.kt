package com.lorelight.browse.migrate

import android.content.Context
import android.os.SystemClock
import com.lorelight.browse.js.JSPluginEngine
import com.lorelight.browse.model.InstalledPlugin
import com.lorelight.browse.model.SourceNovelDetails
import com.lorelight.browse.model.pluginChapterUrl
import com.lorelight.browse.repo.PluginStore
import com.lorelight.data.model.Novel
import com.lorelight.data.db.ProgressStore
import com.lorelight.data.chapters.ChapterReadStore
import com.lorelight.util.ChapterNumbering
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Source transfer / migration.
 *
 * When a site dies its novels can no longer fetch chapter text. This moves a
 * novel to a different installed source: the extraction link (pluginId,
 * pluginNovelPath, sourceUrl, chapterUrls) is replaced while reading progress
 * and history are carried over.
 *
 * THE TRAP THIS FILE EXISTS TO AVOID:
 * Novel.currentChapter and Novel.completedChapters are chapter NAME strings and
 * the reader resolves them with chapters.indexOf(name). Chapter names are NOT
 * stable between sites ("Chapter 67" vs "Ch. 67 - The Duel"), so simply
 * swapping the chapter list makes indexOf() return -1 and silently drops the
 * reader back to chapter 1. Progress is therefore re-anchored by PARSED
 * CHAPTER NUMBER, with same-index as a fallback.
 */

/** Live status for one search attempt on a target source. */
data class MigrationSearchProgress(
    val query: String,
    val attempt: Int,
    val elapsedMs: Long? = null,
    val matchCount: Int? = null
)

/** One possible match for a novel on a target source. */
data class MigrationCandidate(
    val pluginId: String,
    val pluginName: String,
    val name: String,
    val path: String,
    val cover: String? = null
)

/** How the reading position was carried across. */
enum class AnchorMethod {
    EXACT_NUMBER,
    NEAREST_NUMBER,
    SAME_INDEX,
    RESET
}

/** Outcome of a migration, used to render a confirmation summary. */
data class MigrationResult(
    val novel: Novel,
    val oldChapterCount: Int,
    val newChapterCount: Int,
    val oldChapterName: String,
    val newChapterName: String,
    val anchorMethod: AnchorMethod,
    val completedCarried: Int,
    val completedTotal: Int
)

object NovelSourceMigrator {

    /** Installed sources that can be migration targets, current source excluded. */
    fun installedTargets(context: Context, excludePluginId: String?): List<InstalledPlugin> =
        PluginStore.getInstalled(context)
            .filter { it.info.id.isNotBlank() && it.info.id != excludePluginId }
            .sortedBy { it.info.name.lowercase() }

    /**
     * Progressively looser search terms. Transfer intentionally uses at most
     * two: the exact stored title, then one cleaned/shortened fallback. The
     * Source screen performs one exact-title request, so several sequential
     * fallbacks here were the main avoidable source of extra latency.
     */
    fun searchQueries(title: String): List<String> {
        val base = title.trim()
        if (base.isEmpty()) return emptyList()
        val out = LinkedHashSet<String>()
        out.add(base)
        val noBrackets = base
            .replace(Regex("""[\(\[\{].*?[\)\]\}]"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
        if (noBrackets.isNotEmpty()) out.add(noBrackets)
        val beforeSep = noBrackets.split(":", " - ", "|").firstOrNull()?.trim().orEmpty()
        if (beforeSep.length >= 4) out.add(beforeSep)
        val words = noBrackets.split(" ").filter { it.isNotBlank() }
        if (words.size > 4) out.add(words.take(4).joinToString(" "))
        return out.filter { it.length >= 2 }.toList()
    }

    /**
     * Searches one target source for a novel, trying looser queries until
     * something comes back. Never auto-picks: the caller always confirms.
     */
    suspend fun searchCandidates(
        context: Context,
        pluginId: String,
        pluginName: String,
        title: String,
        onProgress: (MigrationSearchProgress) -> Unit = {}
    ): List<MigrationCandidate> {
        val appContext = context.applicationContext
        var completedAttempt = false
        var lastFailure: Exception? = null
        // One exact request plus at most one fallback keeps Transfer close to
        // the Source screen's single-request behaviour without losing the
        // common title-cleanup recovery path.
        for ((attemptIndex, q) in searchQueries(title).take(2).withIndex()) {
            val attempt = attemptIndex + 1
            val startedAt = SystemClock.elapsedRealtime()
            onProgress(MigrationSearchProgress(query = q, attempt = attempt))
            val items = try {
                JSPluginEngine.searchNovels(appContext, pluginId, q, 1).also {
                    completedAttempt = true
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lastFailure = e
                onProgress(
                    MigrationSearchProgress(
                        query = q,
                        attempt = attempt,
                        elapsedMs = SystemClock.elapsedRealtime() - startedAt,
                        matchCount = 0
                    )
                )
                continue
            }
            val mapped = items
                .filter { it.path.isNotBlank() }
                .map {
                    MigrationCandidate(
                        pluginId = pluginId,
                        pluginName = pluginName,
                        name = it.name.ifBlank { q },
                        path = it.path,
                        cover = it.cover
                    )
                }
            onProgress(
                MigrationSearchProgress(
                    query = q,
                    attempt = attempt,
                    elapsedMs = SystemClock.elapsedRealtime() - startedAt,
                    matchCount = mapped.size
                )
            )
            if (mapped.isNotEmpty()) return mapped.distinctBy { it.path }
        }
        if (!completedAttempt && lastFailure != null) throw lastFailure
        return emptyList()
    }

    /**
     * Numeric value per chapter on the new source. Source-provided numbers win,
     * otherwise the number is parsed out of the chapter name. -1f = unknown.
     */
    private fun numbersFor(details: SourceNovelDetails, names: List<String>): List<Float> =
        names.mapIndexed { index, name ->
            val provided = details.chapters.getOrNull(index)?.chapterNumber
            val fromSource = if (provided != null && provided >= 0) provided.toFloat() else null
            fromSource ?: ChapterNumbering.parseChapterNumberFromName(name) ?: -1f
        }

    /** Index of the chapter whose number equals [target], or -1. */
    private fun exactIndexOf(numbers: List<Float>, target: Float): Int =
        numbers.indexOfFirst { it >= 0f && it == target }

    /**
     * Closest chapter at or below [target] so the reader never skips forward
     * past unread content; falls back to the closest number either way.
     */
    private fun nearestIndexOf(numbers: List<Float>, target: Float): Int {
        var bestBelow = -1
        var bestBelowVal = -1f
        var bestAny = -1
        var bestAnyDist = Float.MAX_VALUE
        numbers.forEachIndexed { index, value ->
            if (value >= 0f) {
                if (value <= target && value > bestBelowVal) {
                    bestBelowVal = value
                    bestBelow = index
                }
                val dist = kotlin.math.abs(value - target)
                if (dist < bestAnyDist) {
                    bestAnyDist = dist
                    bestAny = index
                }
            }
        }
        return if (bestBelow >= 0) bestBelow else bestAny
    }

    /**
     * Performs the transfer. Returns the rewritten Novel plus a summary of how
     * the reading position was carried across. Throws if the target entry has
     * no chapters, so the caller can keep the old source untouched.
     */
    suspend fun migrate(
        context: Context,
        novel: Novel,
        candidate: MigrationCandidate
    ): MigrationResult {
        val appContext = context.applicationContext
        val details = JSPluginEngine.parseNovel(appContext, candidate.pluginId, candidate.path)

        val newNames = details.chapters.mapIndexed { index, ch ->
            ch.name.takeIf { it.isNotBlank() } ?: "Chapter ${index + 1}"
        }
        if (newNames.isEmpty()) {
            throw IllegalStateException("That entry has no chapters on the new source.")
        }
        val newUrls = details.chapters.map { pluginChapterUrl(candidate.pluginId, it.path) }
        val newNumbers = numbersFor(details, newNames)

        val oldNames = novel.chapters
        // The reading_progress row is updated on page turns/TTS independently
        // of the library Novel snapshot. Use whichever copy is newer BEFORE
        // resolving the old chapter number, otherwise a stale Novel object can
        // migrate the reader to an earlier chapter even though we later stamp
        // the migration newer than the database row.
        val storedProgress = withContext(Dispatchers.IO) {
            ProgressStore.loadProgress(appContext, novel.id)
        }
        val positionNovel = if (
            storedProgress != null && storedProgress.lastReadTimestamp >= novel.lastReadTimestamp
        ) {
            novel.copy(
                currentChapter = storedProgress.currentChapter,
                currentChapterIndex = if (storedProgress.currentChapterIndex >= 0) {
                    storedProgress.currentChapterIndex
                } else novel.currentChapterIndex,
                currentParagraphIndex = storedProgress.currentParagraphIndex,
                currentScrollOffset = storedProgress.currentScrollOffset,
                currentWordIndex = storedProgress.currentWordIndex,
                lastReadTimestamp = storedProgress.lastReadTimestamp
            )
        } else novel

        // currentChapterIndex is the durable position. Use the name only for
        // older rows that predate the index field; duplicate/re-titled chapter
        // names must not silently send a transfer back to chapter one.
        val rawOldIndex = positionNovel.currentChapterIndex.takeIf { it in oldNames.indices }
            ?: oldNames.indexOf(positionNovel.currentChapter)
        val oldIndex = if (rawOldIndex >= 0) rawOldIndex else 0
        val oldNumber = ChapterNumbering.resolveChapterNumber(
            positionNovel, oldIndex, positionNovel.currentChapter
        )

        var method = AnchorMethod.RESET
        var newIndex = 0
        if (oldNumber != null && oldNumber >= 0f) {
            val exact = exactIndexOf(newNumbers, oldNumber)
            if (exact >= 0) {
                newIndex = exact
                method = AnchorMethod.EXACT_NUMBER
            } else {
                val near = nearestIndexOf(newNumbers, oldNumber)
                if (near >= 0) {
                    newIndex = near
                    method = AnchorMethod.NEAREST_NUMBER
                }
            }
        }
        if (method == AnchorMethod.RESET && oldIndex >= 0 && oldIndex < newNames.size) {
            newIndex = oldIndex
            method = AnchorMethod.SAME_INDEX
        }
        newIndex = newIndex.coerceIn(0, newNames.size - 1)

        // Carry finished chapters across by number, not by name.
        val numberToIndex = HashMap<Float, Int>()
        newNumbers.forEachIndexed { index, value ->
            if (value >= 0f && !numberToIndex.containsKey(value)) {
                numberToIndex[value] = index
            }
        }
        val carried = ArrayList<String>()
        for (done in novel.completedChapters) {
            val doneIndex = oldNames.indexOf(done)
            val doneNumber = if (doneIndex >= 0) {
                ChapterNumbering.resolveChapterNumber(novel, doneIndex, done)
            } else {
                ChapterNumbering.parseChapterNumberFromName(done)
            }
            val target = if (doneNumber != null && doneNumber >= 0f) numberToIndex[doneNumber] else null
            if (target != null) {
                val name = newNames[target]
                if (!carried.contains(name)) carried.add(name)
            }
        }

        // Completed chapter marks and bookmarks are keyed by chapter URL in
        // ChapterReadStore. Carry them only where the chapter number (or an
        // unambiguous identical title) proves the chapter identity across sites.
        val oldToNewIndex = LinkedHashMap<Int, Int>()
        oldNames.forEachIndexed { oldChapterIndex, oldName ->
            val oldChapterNumber = ChapterNumbering.resolveChapterNumber(novel, oldChapterIndex, oldName)
            val newChapterIndex = if (oldChapterNumber != null && oldChapterNumber >= 0f) {
                exactIndexOf(newNumbers, oldChapterNumber)
            } else {
                val candidateIndex = newNames.indexOf(oldName)
                if (candidateIndex >= 0 && newNames.count { it == oldName } == 1) candidateIndex else -1
            }
            if (newChapterIndex >= 0) oldToNewIndex[oldChapterIndex] = newChapterIndex
        }

        // A newer reading_progress row overlays the Novel row on every library
        // load/save. Stamp this migration strictly after both copies so that the
        // old source's chapter name/index cannot overwrite the re-anchored state.
        val storedProgressTimestamp = storedProgress?.lastReadTimestamp ?: 0L
        val newestProgressTimestamp = maxOf(novel.lastReadTimestamp, storedProgressTimestamp)
        val nextProgressTimestamp = if (newestProgressTimestamp == Long.MAX_VALUE) {
            Long.MAX_VALUE
        } else newestProgressTimestamp + 1L
        val migrationTimestamp = maxOf(System.currentTimeMillis(), nextProgressTimestamp)

        // Keep the cover the user already sees; only fall back to the new site.
        val cover = novel.coverImageBase64 ?: details.cover ?: candidate.cover

        val migrated = novel.copy(
            pluginId = candidate.pluginId,
            pluginNovelPath = candidate.path,
            sourceUrl = candidate.path,
            isOnline = true,
            chapters = newNames,
            chapterUrls = newUrls,
            chapterNumbers = newNumbers,
            totalChapters = newNames.size,
            coverImageBase64 = cover,
            currentChapter = newNames[newIndex],
            currentChapterIndex = newIndex,
            currentParagraphIndex = 0,
            currentMangaPageIndex = 0,
            currentScrollOffset = 0,
            currentWordIndex = 0,
            lastReadTimestamp = migrationTimestamp,
            dateModified = migrationTimestamp,
            completedChapters = carried
        )

        val carriedIndices = carried.mapNotNull { name ->
            newNames.indexOf(name).takeIf { it >= 0 }
        }.toSet()
        ChapterReadStore.remapForSourceMigration(
            context = appContext,
            oldNovel = novel,
            newNovel = migrated,
            oldToNewIndex = oldToNewIndex,
            migratedCompletedIndices = carriedIndices
        )

        return MigrationResult(
            novel = migrated,
            oldChapterCount = oldNames.size,
            newChapterCount = newNames.size,
            oldChapterName = positionNovel.currentChapter,
            newChapterName = newNames[newIndex],
            anchorMethod = method,
            completedCarried = carried.size,
            completedTotal = novel.completedChapters.size
        )
    }
}
