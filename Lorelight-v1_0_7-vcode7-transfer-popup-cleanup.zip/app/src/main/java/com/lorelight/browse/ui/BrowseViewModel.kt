package com.lorelight.browse.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.lorelight.browse.js.JSPluginEngine
import com.lorelight.browse.model.InstalledPlugin
import com.lorelight.browse.model.PluginInfo
import com.lorelight.browse.repo.PluginManager
import com.lorelight.browse.repo.PluginRepositoryManager
import com.lorelight.browse.repo.PluginStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/*
- Plain ViewModel (no DI), matching the app's manual-state style.
- Context is passed into each function from the composable (LocalContext).
*/
class BrowseViewModel : ViewModel() {

    private val _available = MutableStateFlow<List<PluginInfo>>(emptyList())
    val available: StateFlow<List<PluginInfo>> = _available.asStateFlow()

    private val _installed = MutableStateFlow<List<InstalledPlugin>>(emptyList())
    val installed: StateFlow<List<InstalledPlugin>> = _installed.asStateFlow()

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    private val _partialWarning = MutableStateFlow<String?>(null)
    val partialWarning: StateFlow<String?> = _partialWarning.asStateFlow()

    private val _operationMessage = MutableStateFlow<String?>(null)
    val operationMessage: StateFlow<String?> = _operationMessage.asStateFlow()

    private val _busyIds = MutableStateFlow<Set<String>>(emptySet())
    val busyIds: StateFlow<Set<String>> = _busyIds.asStateFlow()

    private val _selectedLangs = MutableStateFlow<Set<String>>(emptySet())
    val selectedLangs: StateFlow<Set<String>> = _selectedLangs.asStateFlow()

    private var langsLoaded = false

    private fun prefs(context: Context) =
        context.getSharedPreferences("lorelight_browse_prefs", Context.MODE_PRIVATE)

    fun loadInstalled(context: Context) {
        _installed.value = PluginStore.getInstalled(context.applicationContext)
    }

    /** Call once when the Browse tab opens. */
    fun ensureLoaded(context: Context) {
        val appContext = context.applicationContext
        if (!langsLoaded) {
            langsLoaded = true
            val saved = prefs(appContext).getString("selected_langs", null)
            _selectedLangs.value = if (saved == null) setOf("English")
            else saved.split("\u0001").filter { it.isNotBlank() }.toSet()
        }
        loadInstalled(appContext)
        if (_available.value.isEmpty() && !_loading.value) refresh(appContext)
    }

    fun refresh(context: Context) {
        val appContext = context.applicationContext
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            _partialWarning.value = null
            try {
                val result = withContext(Dispatchers.IO) {
                    PluginRepositoryManager.fetchAllPlugins(appContext)
                }
                _available.value = result.plugins
                _partialWarning.value = result.warnings.take(3).takeIf { it.isNotEmpty() }?.let { failures ->
                    "Some repositories could not be refreshed (${result.warnings.size}). The source list may be incomplete. " +
                        failures.joinToString("; ")
                }
                _installed.value = PluginStore.getInstalled(appContext)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _error.value = e.message ?: "Failed to load plugins"
            } finally {
                _loading.value = false
            }
        }
    }

    fun setLangSelected(context: Context, lang: String, selected: Boolean) {
        val cur = _selectedLangs.value.toMutableSet()
        if (selected) cur.add(lang) else cur.remove(lang)
        _selectedLangs.value = cur
        prefs(context.applicationContext).edit()
            .putString("selected_langs", cur.joinToString("\u0001")).apply()
    }

    fun dismissOperationMessage() {
        _operationMessage.value = null
    }

    fun install(context: Context, info: PluginInfo) {
        val appContext = context.applicationContext
        viewModelScope.launch {
            _busyIds.value = _busyIds.value + info.id
            _operationMessage.value = null
            try {
                val result = PluginManager.installPlugin(appContext, info)
                result.fold(
                    onSuccess = {
                        _installed.value = PluginStore.getInstalled(appContext)
                    },
                    onFailure = { failure ->
                        _operationMessage.value = "Could not install ${info.name}: ${failure.message ?: "installation failed"}"
                    }
                )
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _operationMessage.value = "Could not install ${info.name}: ${e.message ?: "installation failed"}"
            } finally {
                _busyIds.value = _busyIds.value - info.id
            }
        }
    }

    fun update(context: Context, info: PluginInfo) {
        val appContext = context.applicationContext
        viewModelScope.launch {
            _busyIds.value = _busyIds.value + info.id
            _operationMessage.value = null
            try {
                val result = PluginManager.updatePlugin(appContext, info)
                result.fold(
                    onSuccess = {
                        JSPluginEngine.evict(info.id)
                        _installed.value = PluginStore.getInstalled(appContext)
                    },
                    onFailure = { failure ->
                        _operationMessage.value = "Could not update ${info.name}: ${failure.message ?: "update failed"}"
                    }
                )
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _operationMessage.value = "Could not update ${info.name}: ${e.message ?: "update failed"}"
            } finally {
                _busyIds.value = _busyIds.value - info.id
            }
        }
    }

    fun updateAll(context: Context) {
        val appContext = context.applicationContext
        viewModelScope.launch {
            _operationMessage.value = null
            val avail = _available.value.associateBy { it.id }
            val failures = ArrayList<String>()
            val toUpdate = _installed.value.mapNotNull { ip ->
                val latest = avail[ip.info.id]
                if (latest != null && !ip.pinned && PluginManager.hasUpdate(ip, latest)) latest else null
            }
            for (info in toUpdate) {
                _busyIds.value = _busyIds.value + info.id
                try {
                    val result = PluginManager.updatePlugin(appContext, info)
                    result.fold(
                        onSuccess = { JSPluginEngine.evict(info.id) },
                        onFailure = { failure -> failures.add("${info.name}: ${failure.message ?: "update failed"}") }
                    )
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    failures.add("${info.name}: ${e.message ?: "update failed"}")
                } finally {
                    _busyIds.value = _busyIds.value - info.id
                }
            }
            _installed.value = PluginStore.getInstalled(appContext)
            if (failures.isNotEmpty()) {
                _operationMessage.value = "Some source updates failed: " + failures.take(4).joinToString("; ")
            }
        }
    }

    fun uninstall(context: Context, id: String) {
        val appContext = context.applicationContext
        if (id in _busyIds.value) return
        viewModelScope.launch {
            _busyIds.value = _busyIds.value + id
            try {
                val installed = withContext(Dispatchers.IO) {
                    PluginManager.uninstallPlugin(appContext, id)
                    JSPluginEngine.evict(id)
                    PluginStore.getInstalled(appContext)
                }
                _installed.value = installed
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _operationMessage.value = "Couldn't remove source: ${e.message ?: "storage error"}"
            } finally {
                _busyIds.value = _busyIds.value - id
            }
        }
    }

    fun setPinned(context: Context, id: String, pinned: Boolean) {
        val appContext = context.applicationContext
        viewModelScope.launch {
            try {
                val installed = withContext(Dispatchers.IO) {
                    PluginStore.setPinned(appContext, id, pinned)
                    PluginStore.getInstalled(appContext)
                }
                _installed.value = installed
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _operationMessage.value = "Couldn't save source setting: ${e.message ?: "storage error"}"
            }
        }
    }
}
