package com.lorelight.browse.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.lorelight.browse.js.JSPluginEngine
import com.lorelight.browse.model.FilterOption
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay

private object FilterSuggestionCache {
    private const val MAX_ENTRIES = 200
    private val values = object : LinkedHashMap<String, List<FilterOption>>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, List<FilterOption>>?): Boolean =
            size > MAX_ENTRIES
    }
    private val failures = HashMap<String, Int>()

    fun get(key: String): List<FilterOption>? = values[key]
    fun put(key: String, options: List<FilterOption>) { values[key] = options.toList() }
    fun failureCount(target: String): Int = failures[target] ?: 0
    fun recordSuccess(target: String) { failures.remove(target) }
    fun recordFailure(target: String) { failures[target] = (failures[target] ?: 0) + 1 }
}

/** LNReader-compatible dynamic autocomplete for Text filters marked autocomplete=true. */
@Composable
internal fun FilterAutocompleteField(
    pluginId: String,
    filterKey: String,
    label: String,
    value: String,
    onValueChange: (String) -> Unit
) {
    val context = LocalContext.current.applicationContext
    val trimmedQuery = value.trim()
    val cacheKey = "$pluginId\u0000$filterKey\u0000$trimmedQuery"
    val targetKey = "$pluginId\u0000$filterKey"
    var focused by remember(pluginId, filterKey) { mutableStateOf(false) }
    var suppressed by remember(pluginId, filterKey) { mutableStateOf(false) }
    var suggestions by remember(pluginId, filterKey) { mutableStateOf<List<FilterOption>>(emptyList()) }
    var loading by remember(pluginId, filterKey) { mutableStateOf(false) }

    LaunchedEffect(pluginId, filterKey, trimmedQuery) {
        loading = false
        if (trimmedQuery.length < 2) {
            suggestions = emptyList()
            return@LaunchedEffect
        }
        val cached = FilterSuggestionCache.get(cacheKey)
        if (cached != null) {
            suggestions = cached
            return@LaunchedEffect
        }
        suggestions = emptyList()
        val failures = FilterSuggestionCache.failureCount(targetKey).coerceAtMost(5)
        val debounceMs = (250L * (1L shl failures)).coerceAtMost(8_000L)
        delay(debounceMs)
        loading = true
        try {
            val result = JSPluginEngine.getFilterSuggestions(
                context,
                pluginId,
                filterKey,
                trimmedQuery
            ).take(6)
            FilterSuggestionCache.recordSuccess(targetKey)
            FilterSuggestionCache.put(cacheKey, result)
            suggestions = result
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            FilterSuggestionCache.recordFailure(targetKey)
            suggestions = emptyList()
        } finally {
            loading = false
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(
            value = value,
            onValueChange = {
                suppressed = false
                onValueChange(it)
            },
            modifier = Modifier
                .fillMaxWidth()
                .onFocusChanged { state ->
                    focused = state.isFocused
                    if (state.isFocused) suppressed = false
                },
            label = { Text(label) },
            singleLine = true,
            trailingIcon = {
                if (loading) CircularProgressIndicator(
                    modifier = Modifier.padding(10.dp),
                    strokeWidth = 2.dp
                )
            }
        )
        if (focused && !suppressed && suggestions.isNotEmpty()) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surfaceVariant,
                contentColor = MaterialTheme.colorScheme.onSurfaceVariant,
                shape = RoundedCornerShape(12.dp),
                tonalElevation = 3.dp
            ) {
                Column {
                    suggestions.forEach { option ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onValueChange(option.value)
                                    suppressed = true
                                }
                                .padding(horizontal = 12.dp, vertical = 10.dp)
                        ) {
                            Text(
                                text = option.label,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }
        }
    }
}
