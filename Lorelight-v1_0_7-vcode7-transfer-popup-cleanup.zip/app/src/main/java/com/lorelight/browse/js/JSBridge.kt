package com.lorelight.browse.js

import android.content.Context
import android.webkit.CookieManager
import com.lorelight.crawler.CrawlerEngine
import com.lorelight.network.PublicInternetDns
import com.lorelight.webstorage.WebStorageSnapshotStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.Call
import okhttp3.HttpUrl
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.MultipartBody
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.io.ByteArrayOutputStream

/**
 * Capabilities the QuickJS engine (JSPluginEngine) provides to the bridge.
 * All "post*" methods MUST hop onto the context's single JS thread, invoke the
 * matching JS global, and pump pending promise jobs. Implemented in JSPluginEngine.
 */
interface JsRuntimeHost {
    val scope: CoroutineScope
    fun postFetchResult(token: Int, rawJson: String)
    fun postFetchError(token: Int, message: String)
    fun postTimeout(id: Int)
    fun onFetchesDrained()
}

/**
 * Kotlin functions exposed to JS as __native.* (fetch, storage, log, timers).
 * One instance per QuickJS context. Cheerio ops are wired separately (CheerioBridge).
 */
/**
 * Namespace for a plugin's private key/value storage.
 *
 * FIX A5: shared by JSBridge and PluginManager so install, use and uninstall
 * always agree on the file name, and so a hostile id cannot escape it.
 */
internal fun pluginStoragePrefsName(pluginId: String): String =
    "lorelight_plugin_storage_" + sanitizePluginId(pluginId)

/** Reduces a repo-supplied plugin id to a safe single file-name component. */
internal fun sanitizePluginId(pluginId: String): String {
    val cleaned = pluginId.filter { it.isLetterOrDigit() || it == '.' || it == '_' || it == '-' }
        .replace("..", "")
    return if (cleaned.isEmpty()) "unknown_plugin" else cleaned.take(100)
}

class JSBridge(
    private val appContext: Context,
    private val host: JsRuntimeHost,
    // FIX A5: the plugin that owns this bridge. Storage calls are pinned to it
    // instead of trusting the id supplied by the running script.
    private val ownerPluginId: String? = null
) {
    // FIX B11 + C17: keeps this bridge's WebView-backed cookie jar, but now
    // reuses the shared connection pool and the Cloudflare interceptor instead
    // of building a private client.
    private val client: OkHttpClient by lazy {
        com.lorelight.network.HttpClients.sharedBuilder()
            // Isolate the guarded plugin client from the app-wide pool; a pooled
            // connection created by an unguarded client must not bypass DNS checks.
            .connectionPool(okhttp3.ConnectionPool(4, 5, java.util.concurrent.TimeUnit.MINUTES))
            .cookieJar(WebViewCookieJar())
            .dns(PublicInternetDns)
            // Source hosts can be materially slower than the app API. Match
            // the 120-second plugin-operation budget rather than letting the
            // shared 30-second read timeout abort a valid slow response.
            .readTimeout(120, java.util.concurrent.TimeUnit.SECONDS)
            .callTimeout(120, java.util.concurrent.TimeUnit.SECONDS)
            .build()
    }
    private val noCookiesClient: OkHttpClient by lazy {
        com.lorelight.network.HttpClients.sharedBuilder()
            .connectionPool(okhttp3.ConnectionPool(4, 5, java.util.concurrent.TimeUnit.MINUTES))
            .cookieJar(object : CookieJar {
                override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) = Unit
                override fun loadForRequest(url: HttpUrl): List<Cookie> = emptyList()
            })
            .dns(PublicInternetDns)
            .readTimeout(120, java.util.concurrent.TimeUnit.SECONDS)
            .callTimeout(120, java.util.concurrent.TimeUnit.SECONDS)
            .build()
    }

    private val activeCalls = java.util.concurrent.ConcurrentHashMap<Int, Call>()
    private val pendingFetches = java.util.concurrent.ConcurrentHashMap.newKeySet<Int>()
    private val cancelledFetches = java.util.concurrent.ConcurrentHashMap.newKeySet<Int>()
    @Volatile private var webStorageEnabled: Boolean = false
    @Volatile private var webStorageOrigin: String? = null

    /** Called only after the installed plugin object has been evaluated. */
    fun configureWebStorage(enabled: Boolean, site: String?) {
        webStorageEnabled = enabled
        webStorageOrigin = if (enabled) WebStorageSnapshotStore.normalizeOrigin(site ?: "") else null
        if (enabled && webStorageOrigin == null) {
            log("webStorageUtilized is true, but plugin site is not a valid HTTP(S) origin")
            webStorageEnabled = false
        }
    }

    /** Read-only origin snapshot supplied by an app-owned WebView session. */
    fun webStorageGet(requestedPluginId: String, kind: String): String {
        if (!webStorageEnabled) return "{}"
        if (kind != "localStorage" && kind != "sessionStorage") return "{}"
        // The requested ID is intentionally ignored: a plugin cannot inspect
        // another source's WebView-origin storage through a forged argument.
        return WebStorageSnapshotStore.read(appContext, webStorageOrigin, kind)
    }

    /** Mark a token only while its native request is pending. The second check
     * closes the race where the request drains between contains() and add(). */
    private fun markCancelledIfPending(token: Int): Boolean {
        if (!pendingFetches.contains(token)) return false
        cancelledFetches.add(token)
        if (!pendingFetches.contains(token)) {
            cancelledFetches.remove(token)
            return false
        }
        return true
    }

    /** Cancels the actual OkHttp call associated with an AbortController token. */
    fun cancelFetch(token: Int) {
        // Do not retain cancellation markers for tokens whose native request
        // has already drained; the JS callback may simply be waiting to run.
        if (markCancelledIfPending(token)) activeCalls.remove(token)?.cancel()
    }

    /** Used by PluginContext eviction logic to avoid destroying a runtime mid-fetch. */
    fun hasPendingFetches(): Boolean = pendingFetches.isNotEmpty()

    /** Cancels all pending native requests when the owning plugin operation is cancelled/timed out. */
    fun cancelAllFetches(reason: String = "Plugin operation was cancelled") {
        // Include requests between bridge registration and OkHttp call setup.
        // The second check before execute() closes the race between this snapshot
        // and activeCalls registration.
        val tokens = pendingFetches.toList()
        if (tokens.isNotEmpty()) {
            log("[fetch-cancel-all] plugin=${ownerPluginId ?: "unknown"} pending=${tokens.size} reason=$reason")
        }
        tokens.forEach { token ->
            // The request may have drained after the snapshot above. Only post
            // an error when this call successfully claims a still-pending token;
            // otherwise a late cancellation callback can race a success callback
            // already queued on the JS thread and turn a completed fetch into an
            // AbortError.
            if (markCancelledIfPending(token)) {
                activeCalls.remove(token)?.cancel()
                // Reject the JS promise too; otherwise a cancelled page operation
                // can remain suspended forever without reaching its next-page guard.
                host.postFetchError(token, reason)
            }
        }
    }

    fun log(msg: String) { BrowseDebugLog.log(msg) }

    private fun isSafeFetchUrl(urlStr: String): Boolean {
        return try {
            val uri = android.net.Uri.parse(urlStr)
            val scheme = uri.scheme?.lowercase() ?: return false
            if (scheme != "http" && scheme != "https") return false
            if (uri.encodedAuthority?.contains("@") == true) return false
            val host = uri.host?.trimEnd('.')?.lowercase() ?: return false
            if (host.isBlank() || host == "localhost" || host.endsWith(".localhost") ||
                host.endsWith(".local") || host.endsWith(".internal") || host.endsWith(".test")
            ) return false
            // Literal IPs are rejected early; DNS names are checked again by
            // PublicInternetDns at the actual connection and on each redirect.
            if (host.contains(':') || host.matches(Regex("^[0-9.]+$"))) {
                val address = java.net.InetAddress.getByName(host)
                if (address.isAnyLocalAddress || address.isLoopbackAddress ||
                    address.isLinkLocalAddress || address.isSiteLocalAddress || address.isMulticastAddress
                ) return false
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun readResponseBounded(body: okhttp3.ResponseBody): ByteArray {
        val declared = body.contentLength()
        if (declared > MAX_FETCH_RESPONSE_BYTES) {
            throw IllegalStateException("Plugin response is too large (limit ${MAX_FETCH_RESPONSE_BYTES / (1024 * 1024)} MiB)")
        }
        val initialCapacity = if (declared in 0..MAX_FETCH_RESPONSE_BYTES) minOf(declared.toInt(), 64 * 1024) else 8 * 1024
        val output = ByteArrayOutputStream(initialCapacity)
        body.byteStream().use { input ->
            val buffer = ByteArray(8 * 1024)
            var total = 0L
            while (true) {
                val count = input.read(buffer)
                if (count < 0) break
                total += count
                if (total > MAX_FETCH_RESPONSE_BYTES) {
                    throw IllegalStateException("Plugin response is too large (limit ${MAX_FETCH_RESPONSE_BYTES / (1024 * 1024)} MiB)")
                }
                output.write(buffer, 0, count)
            }
        }
        return output.toByteArray()
    }

    private companion object {
        const val MAX_FETCH_RESPONSE_BYTES = 12L * 1024L * 1024L
        // A per-response cap alone does not bound aggregate memory when one
        // source fans out many fetches. Limit concurrent plugin downloads app-wide.
        val pluginFetchSemaphore = kotlinx.coroutines.sync.Semaphore(4)
    }

    /** Called from the JS thread. Runs HTTP off-thread, delivers back via host. */
    fun fetch(url: String, initJson: String, token: Int) {
        if (!isSafeFetchUrl(url)) {
            host.postFetchError(token, "Security error: URL scheme or target host disallowed ($url)")
            return
        }
        pendingFetches.add(token)
        host.scope.launch(Dispatchers.IO) {
            var acquiredFetchPermit = false
            try {
                if (cancelledFetches.remove(token)) return@launch
                pluginFetchSemaphore.acquire()
                acquiredFetchPermit = true
                if (cancelledFetches.remove(token)) return@launch
                val init = try { JSONObject(initJson) } catch (e: Exception) { JSONObject() }
                val method = init.optString("method", "GET").uppercase()
                val builder = Request.Builder().url(url)

                var hasUA = false
                val headers = init.optJSONObject("headers")
                fun requestHeader(name: String): String? {
                    if (headers == null) return null
                    val keys = headers.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        if (key.equals(name, ignoreCase = true)) {
                            return headers.optString(key).takeIf { it.isNotEmpty() }
                        }
                    }
                    return null
                }
                if (headers != null) {
                    val keys = headers.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        builder.header(k, headers.optString(k))
                        if (k.equals("User-Agent", true)) hasUA = true
                    }
                }
                if (!hasUA) builder.header("User-Agent", CrawlerEngine.mobileUserAgent(appContext))

                // Fetch RequestInit.referrer/referrerPolicy are translated into the
                // actual HTTP Referer header. Do not silently drop source-provided values.
                val credentials = init.optString("credentials", "")
                if (credentials == "omit") builder.removeHeader("Cookie")
                val referrer = init.optString("referrer", "")
                val referrerPolicy = init.optString("referrerPolicy", "strict-origin-when-cross-origin").lowercase()
                if (referrerPolicy == "no-referrer") {
                    builder.removeHeader("Referer")
                } else if (referrer.isNotBlank() && referrer != "about:client") {
                    try {
                        val ref = android.net.Uri.parse(referrer)
                        val target = android.net.Uri.parse(url)
                        if (ref.scheme.isNullOrBlank() || ref.encodedAuthority.isNullOrBlank()) throw IllegalArgumentException("Invalid referrer URL")
                        val origin = "${ref.scheme}://${ref.encodedAuthority}/"
                        val targetOrigin = "${target.scheme}://${target.encodedAuthority}/"
                        val sameOrigin = origin.equals(targetOrigin, true)
                        val downgrade = ref.scheme.equals("https", true) && target.scheme.equals("http", true)
                        val sendReferrer = when (referrerPolicy) {
                            "origin" -> origin
                            "strict-origin" -> if (downgrade) "" else origin
                            "same-origin" -> if (sameOrigin) referrer else ""
                            "origin-when-cross-origin" -> if (sameOrigin) referrer else origin
                            "strict-origin-when-cross-origin" -> if (downgrade) "" else if (sameOrigin) referrer else origin
                            "no-referrer-when-downgrade" -> if (downgrade) "" else referrer
                            else -> referrer
                        }
                        builder.removeHeader("Referer")
                        if (sendReferrer.isNotBlank()) builder.header("Referer", sendReferrer)
                    } catch (_: Exception) { /* malformed referrer is ignored */ }
                }

                val bodyValue = if (init.has("body") && !init.isNull("body")) init.opt("body") else null
                val formEntries = (bodyValue as? JSONObject)?.optJSONArray("__lorelightFormData")
                val reqBody = if (method != "GET" && method != "HEAD") {
                    val urlEncodedBody = (bodyValue as? JSONObject)?.let { if (it.has("__lorelightUrlSearchParams")) it.optString("__lorelightUrlSearchParams") else null }
                    val binaryBody = (bodyValue as? JSONObject)?.optString("__lorelightBinaryBody")
                    if (bodyValue is JSONObject && bodyValue.has("__lorelightBinaryBody")) {
                        val bytes = try { android.util.Base64.decode(binaryBody, android.util.Base64.DEFAULT) } catch (_: Exception) { ByteArray(0) }
                        val ctRaw = requestHeader("Content-Type")
                        bytes.toRequestBody((if (ctRaw.isNullOrEmpty()) "application/octet-stream" else ctRaw).toMediaTypeOrNull())
                    } else if (formEntries != null) {
                        // Browser-compatible multipart/form-data for plugin FormData fields.
                        builder.removeHeader("Content-Type")
                        val multipart = MultipartBody.Builder().setType(MultipartBody.FORM)
                        for (i in 0 until formEntries.length()) {
                            val entry = formEntries.optJSONArray(i) ?: continue
                            val field = entry.optString(0, "")
                            val value = entry.optString(1, "")
                            if (field.isNotEmpty()) multipart.addFormDataPart(field, value)
                        }
                        multipart.build()
                    } else if (urlEncodedBody != null) {
                        val ctRaw = requestHeader("Content-Type")
                        val ct = if (ctRaw.isNullOrEmpty()) "application/x-www-form-urlencoded; charset=utf-8" else ctRaw
                        urlEncodedBody.toRequestBody(ct.toMediaTypeOrNull())
                    } else {
                        val bodyStr = when (bodyValue) {
                            null -> ""
                            is String -> bodyValue
                            else -> bodyValue.toString()
                        }
                        val ctRaw = requestHeader("Content-Type")
                        val ct = if (ctRaw.isNullOrEmpty()) "text/plain; charset=utf-8" else ctRaw
                        bodyStr.toRequestBody(ct.toMediaTypeOrNull())
                    }
                } else null
                builder.method(method, reqBody)

                // Match LNReader's fetch helper: issue the request immediately and
                // return the server's response (including 429) to the plugin. The
                // previous global 1.2s per-host queue plus automatic 429 backoff
                // serialized independent requests and could make a plugin search
                // exceed its invocation timeout before it received any results.
                val request = builder.build()
                if (cancelledFetches.remove(token)) return@launch
                val activeClient = if (credentials == "omit") noCookiesClient else client
                val call = activeClient.newCall(request)
                activeCalls[token] = call
                if (cancelledFetches.remove(token)) {
                    activeCalls.remove(token, call)
                    return@launch
                }
                val response = call.execute()
                if (cancelledFetches.remove(token)) {
                    response.close()
                    activeCalls.remove(token, call)
                    return@launch
                }
                response.use { resp ->
                    val responseBody = resp.body
                    val bytes = responseBody?.let(::readResponseBounded) ?: ByteArray(0)
                    val charset = responseBody?.contentType()?.charset(Charsets.UTF_8) ?: Charsets.UTF_8
                    val body = try { String(bytes, charset) } catch (_: Exception) { String(bytes, Charsets.UTF_8) }
                    val headersObj = JSONObject()
                    for (name in resp.headers.names()) headersObj.put(name, resp.header(name) ?: "")
                    val raw = JSONObject()
                        .put("status", resp.code)
                        .put("statusText", resp.message)
                        .put("url", resp.request.url.toString())
                        .put("redirected", resp.priorResponse != null)
                        .put("headers", headersObj)
                        .put("body", body)
                        .put("bodyBase64", android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP))
                    if (cancelledFetches.remove(token)) return@launch
                    host.postFetchResult(token, raw.toString())
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                if (!cancelledFetches.remove(token)) {
                    BrowseDebugLog.log("Plugin fetch failed for ${runCatching { android.net.Uri.parse(url).host }.getOrNull() ?: "unknown-host"}: ${e.javaClass.simpleName}: ${e.message ?: e.toString()}")
                    host.postFetchError(token, e.message ?: e.toString())
                }
            } finally {
                if (acquiredFetchPermit) pluginFetchSemaphore.release()
                cancelledFetches.remove(token)
                activeCalls.remove(token)
                pendingFetches.remove(token)
                if (pendingFetches.isEmpty()) host.onFetchesDrained()
            }
        }
    }

    fun setTimeoutNative(id: Int, delayMs: Long) {
        host.scope.launch {
            if (delayMs > 0) delay(delayMs)
            host.postTimeout(id)
        }
    }

    // ---- storage: namespaced SharedPreferences per plugin ----
    // FIX A5: every storage call used to take the plugin id straight from the
    // JS caller. A plugin could therefore read, overwrite or wipe ANY other
    // plugin's stored data (including its session cookies or tokens) simply by
    // passing a different id, and an id containing path characters escaped the
    // namespace altogether. The namespace is now pinned to the plugin that owns
    // this bridge, and sanitised in every case.
    private fun resolveNamespace(requested: String): String {
        val owner = ownerPluginId
        if (owner != null) {
            if (requested.isNotEmpty() && requested != owner) {
                log("storage: ignoring cross-plugin id '$requested' (owner=$owner)")
            }
            return pluginStoragePrefsName(owner)
        }
        return pluginStoragePrefsName(requested)
    }

    private fun storagePrefs(pluginId: String) =
        appContext.getSharedPreferences(resolveNamespace(pluginId), Context.MODE_PRIVATE)

    fun storageGet(pluginId: String, key: String): String? = storagePrefs(pluginId).getString(key, null)
    fun storageSet(pluginId: String, key: String, value: String) {
        check(storagePrefs(pluginId).edit().putString(key, value).commit()) { "Plugin storage write failed" }
    }
    fun storageDelete(pluginId: String, key: String) {
        check(storagePrefs(pluginId).edit().remove(key).commit()) { "Plugin storage delete failed" }
    }
    fun storageClear(pluginId: String) {
        check(storagePrefs(pluginId).edit().clear().commit()) { "Plugin storage clear failed" }
    }
    fun storageKeys(pluginId: String): String {
        val arr = JSONArray()
        storagePrefs(pluginId).all.keys.forEach { arr.put(it) }
        return arr.toString()
    }
}

/**
 * Bridges OkHttp cookies to android.webkit.CookieManager so cookies obtained by
 * "Open in WebView" (e.g. Cloudflare clearance) flow into plugin HTTP requests.
 */
private class WebViewCookieJar : CookieJar {
    private val cm: CookieManager? = try { CookieManager.getInstance() } catch (e: Exception) { null }

    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        val manager = cm ?: return
        if (cookies.isEmpty()) return
        val u = url.toString()
        for (c in cookies) manager.setCookie(u, c.toString())
        // Without an explicit flush, freshly-set cookies (e.g. Cloudflare
        // clearance from "Open in WebView") can be lost if the process dies
        // before Android's own periodic flush runs.
        try { manager.flush() } catch (_: Exception) {}
    }

    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        val manager = cm ?: return emptyList()
        val header = manager.getCookie(url.toString()) ?: return emptyList()
        val out = ArrayList<Cookie>()
        for (part in header.split(";")) {
            val c = Cookie.parse(url, part.trim())
            if (c != null) out.add(c)
        }
        return out
    }
}

/** Optional on-screen sink for JS logs (used by the temporary Gate 2 screen). Harmless in production (sink stays null). */
object BrowseDebugLog {
    @Volatile var sink: ((String) -> Unit)? = null
    fun log(msg: String) { android.util.Log.d("LorelightJS", msg); sink?.invoke(msg) }
}
