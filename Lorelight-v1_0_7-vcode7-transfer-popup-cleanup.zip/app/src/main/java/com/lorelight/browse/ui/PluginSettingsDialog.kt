package com.lorelight.browse.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.lorelight.browse.js.JSPluginEngine
import com.lorelight.browse.js.PluginSettingDef
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

@Composable
fun PluginSettingsDialog(
    pluginId: String,
    pluginName: String,
    onDismiss: () -> Unit,
    onSaved: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var settings by remember(pluginId) { mutableStateOf<List<PluginSettingDef>?>(null) }
    var values by remember(pluginId) { mutableStateOf<Map<String, String>>(emptyMap()) }
    var loading by remember(pluginId) { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(pluginId) {
        loading = true
        error = null
        try {
            val loaded = withContext(Dispatchers.IO) {
                JSPluginEngine.getPluginSettings(context.applicationContext, pluginId)
            }
            settings = loaded
            values = loaded.associate { it.key to it.value }
        } catch (e: Exception) {
            error = e.message ?: "Could not load source settings"
            settings = emptyList()
        } finally {
            loading = false
        }
    }

    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text("$pluginName settings") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (loading) {
                    Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                } else {
                    if (!error.isNullOrBlank()) Text(error!!, color = MaterialTheme.colorScheme.error)
                    if (settings.isNullOrEmpty()) {
                        Text("This source does not expose configurable plugin settings.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else settings!!.forEach { setting ->
                        val current = values[setting.key] ?: setting.value
                        when (setting.type.lowercase().replace("_", "").replace("-", "")) {
                            "checkbox", "checkboxgroup", "multiselect", "multiplechoice" -> {
                                val selected = remember(setting.key, current) {
                                    try {
                                        val arr = JSONArray(current)
                                        (0 until arr.length()).map { arr.optString(it) }.toSet()
                                    } catch (_: Exception) {
                                        current.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
                                    }
                                }
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(setting.label, style = MaterialTheme.typography.bodyMedium)
                                    setting.options.forEach { option ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Checkbox(
                                                checked = option.value in selected,
                                                onCheckedChange = { checked ->
                                                    val updated = selected.toMutableSet().apply {
                                                        if (checked) add(option.value) else remove(option.value)
                                                    }
                                                    val orderedValues = setting.options.map { it.value }.filter { it in updated }
                                                    values = values + (setting.key to JSONArray(orderedValues).toString())
                                                }
                                            )
                                            Text(option.label, style = MaterialTheme.typography.bodyMedium)
                                        }
                                    }
                                }
                            }
                            "switch", "boolean" -> Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(setting.label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                                Spacer(Modifier.width(8.dp))
                                Switch(
                                    checked = current.equals("true", true),
                                    onCheckedChange = { values = values + (setting.key to it.toString()) }
                                )
                            }
                            "select", "picker" -> {
                                var expanded by remember(setting.key) { mutableStateOf(false) }
                                Column {
                                    Text(setting.label, style = MaterialTheme.typography.bodyMedium)
                                    Spacer(Modifier.height(4.dp))
                                    Box {
                                        Button(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                                            Text(setting.options.firstOrNull { it.value == current }?.label ?: current.ifBlank { "Choose" })
                                        }
                                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                            setting.options.forEach { option ->
                                                DropdownMenuItem(
                                                    text = { Text(option.label) },
                                                    onClick = {
                                                        values = values + (setting.key to option.value)
                                                        expanded = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                            else -> {
                                val secret = setting.type.equals("password", true) ||
                                    setting.key.contains("password", true) ||
                                    setting.key.contains("token", true) ||
                                    setting.key.contains("cookie", true) ||
                                    setting.key.contains("secret", true) ||
                                    setting.label.contains("password", true) ||
                                    setting.label.contains("session cookie", true)
                                OutlinedTextField(
                                    value = current,
                                    onValueChange = { values = values + (setting.key to it) },
                                    label = { Text(setting.label) },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = secret,
                                    visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !loading && !saving && !settings.isNullOrEmpty(),
                onClick = {
                    saving = true
                    error = null
                    scope.launch {
                        try {
                            val payload = JSONObject()
                            settings.orEmpty().forEach { setting ->
                                val raw = values[setting.key] ?: setting.value
                                val normalizedType = setting.type.lowercase().replace("_", "").replace("-", "")
                                val value: Any = when (normalizedType) {
                                    "switch", "boolean" -> raw.equals("true", true)
                                    "checkbox", "checkboxgroup", "multiselect", "multiplechoice" -> try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
                                    else -> raw
                                }
                                payload.put(setting.key, value)
                            }
                            withContext(Dispatchers.IO) {
                                JSPluginEngine.savePluginSettings(context.applicationContext, pluginId, payload.toString())
                            }
                            onSaved()
                        } catch (e: Exception) {
                            error = e.message ?: "Could not save source settings"
                        } finally {
                            saving = false
                        }
                    }
                }
            ) { Text(if (saving) "Saving…" else "Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !saving) { Text("Cancel") }
        }
    )
}
