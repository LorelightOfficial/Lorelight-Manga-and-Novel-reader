package com.lorelight.browse.repo

import android.content.Context
import android.net.Uri
import com.lorelight.browse.model.PluginInfo
import com.lorelight.crawler.CrawlerEngine
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.io.ByteArrayOutputStream
import java.util.LinkedHashMap
import java.util.concurrent.Callable
import java.util.concurrent.Executors

data class PluginRepositoryFetchResult(
    val plugins: List<PluginInfo>,
    val warnings: List<String>
)

object PluginRepositoryManager {
    private const val PREFS = "lorelight_browse_prefs"
    private const val KEY_REPOS = "repo_urls"
    private const val MAX_REPOSITORIES_IN_PARALLEL = 4
    private val repoMutationLock = Any()
    const val DEFAULT_REPO =
        "https://raw.githubusercontent.com/LNReader/lnreader-plugins/plugins/v3.0.0/.dist/plugins.min.json"

    private val client: OkHttpClient
        get() = com.lorelight.network.HttpClients.shared()

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getRepoUrls(context: Context?): List<String> {
        if (context == null) return listOf(DEFAULT_REPO)
        val raw = prefs(context).getString(KEY_REPOS, null)
        if (raw.isNullOrEmpty()) {
            // Treat the built-in repository as a read-time default. Do not do
            // disk I/O while a Compose screen is being initialized.
            return listOf(DEFAULT_REPO)
        }
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { arr.optString(it, "") }
                .filter { isHttpUrl(it) }.distinct()
        } catch (_: Exception) {
            listOf(DEFAULT_REPO)
        }
    }

    private fun saveRepoUrls(context: Context, urls: List<String>) {
        val arr = JSONArray()
        urls.forEach { arr.put(it) }
        check(prefs(context).edit().putString(KEY_REPOS, arr.toString()).commit()) {
            "Could not durably save plugin repository list"
        }
    }

    /** Accept only a reachable HTTP(S) URL containing a JSON plugin array. */
    fun addRepo(context: Context, url: String): Result<Int> {
        val normalized = url.trim()
        if (!isHttpUrl(normalized)) return Result.failure(Exception("Repository URL must use HTTP or HTTPS"))
        return try {
            val body = fetch(normalized) ?: return Result.failure(Exception("Repository returned an empty response"))
            val parsed = parseRepo(body, normalized)
            if (parsed.isEmpty()) return Result.failure(Exception("Repository contains no valid plugin entries"))
            synchronized(repoMutationLock) {
                val current = getRepoUrls(context).toMutableList()
                if (!current.contains(normalized)) {
                    current.add(normalized)
                    saveRepoUrls(context, current)
                }
            }
            Result.success(parsed.size)
        } catch (e: Exception) {
            Result.failure(Exception("Could not accept repository: ${e.message ?: "invalid index"}"))
        }
    }

    fun removeRepo(context: Context, url: String) = synchronized(repoMutationLock) {
        val current = getRepoUrls(context).toMutableList()
        current.remove(url)
        saveRepoUrls(context, current)
    }

    /**
     * Fetches enabled repositories independently (LNReader's all-settled model).
     * One unavailable or malformed repository cannot block other repositories.
     * A small pool avoids serial network latency without flooding the device.
     */
    fun fetchAllPlugins(context: Context?): PluginRepositoryFetchResult {
        val repoUrls = getRepoUrls(context)
        if (repoUrls.isEmpty()) return PluginRepositoryFetchResult(emptyList(), emptyList())
        val executor = Executors.newFixedThreadPool(minOf(repoUrls.size, MAX_REPOSITORIES_IN_PARALLEL))
        try {
            val tasks = repoUrls.map { repoUrl ->
                executor.submit(Callable {
                    val body = fetch(repoUrl) ?: throw IllegalStateException("Empty repository response")
                    repoUrl to parseRepo(body, repoUrl)
                })
            }
            val seen = LinkedHashMap<String, PluginInfo>()
            val failures = ArrayList<String>()
            var successfulRepositories = 0
            tasks.forEachIndexed { index, future ->
                try {
                    val (_, plugins) = future.get()
                    successfulRepositories += 1
                    plugins.forEach { plugin -> if (!seen.containsKey(plugin.id)) seen[plugin.id] = plugin }
                } catch (e: Exception) {
                    val detail = e.cause?.message ?: e.message ?: "unknown error"
                    failures.add("${repoUrls[index]}: $detail")
                    android.util.Log.w("PluginRepository", "Repository failed: ${repoUrls[index]}: $detail")
                }
            }
            // A legitimate empty index is different from every configured
            // repository failing. Do not turn a total network/parse failure
            // into a successful empty catalogue in Browse.
            if (successfulRepositories == 0 && failures.isNotEmpty()) {
                throw IllegalStateException(
                    "Could not load any configured plugin repository (${failures.size}/${repoUrls.size} failed): " +
                        failures.take(3).joinToString("; ")
                )
            }
            return PluginRepositoryFetchResult(
                plugins = seen.values.sortedWith(compareBy({ it.lang }, { it.name.lowercase() })),
                warnings = failures
            )
        } finally {
            executor.shutdownNow()
        }
    }

    private fun parseRepo(body: String, repoUrl: String): List<PluginInfo> {
        val arr = JSONArray(body)
        val result = ArrayList<PluginInfo>(arr.length())
        val seen = HashSet<String>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id", "").trim()
            val name = o.optString("name", id).trim()
            val version = o.optString("version", "").trim()
            val bundleUrl = o.optString("url", "").trim()
            if (!isSafePluginId(id) || name.isBlank() || version.isBlank() || !isHttpUrl(bundleUrl)) continue
            val customJs = o.optString("customJS", "").trim().ifEmpty { null }
            val customCss = o.optString("customCSS", "").trim().ifEmpty { null }
            if (customJs != null && !isHttpUrl(customJs)) continue
            if (customCss != null && !isHttpUrl(customCss)) continue
            if (!seen.add(id)) continue
            val icon = o.optString("iconUrl", "").trim()
            result.add(
                PluginInfo(
                    id = id,
                    name = name,
                    site = o.optString("site", "").trim(),
                    lang = o.optString("lang", "Unknown").trim().ifEmpty { "Unknown" },
                    version = version,
                    url = bundleUrl,
                    iconUrl = icon.takeIf { isHttpUrl(it) } ?: "",
                    hasSettings = o.optBoolean("hasSettings", false),
                    hasUpdate = o.optBoolean("hasUpdate", false),
                    repoUrl = repoUrl,
                    customJS = customJs,
                    customCSS = customCss
                )
            )
        }
        return result
    }

    private fun isSafePluginId(value: String): Boolean =
        value.length in 1..100 && value.matches(Regex("[A-Za-z0-9][A-Za-z0-9._-]*")) && !value.contains("..")

    private fun isHttpUrl(value: String): Boolean = try {
        val uri = Uri.parse(value.trim())
        (uri.scheme.equals("https", true) || uri.scheme.equals("http", true)) && !uri.host.isNullOrBlank()
    } catch (_: Exception) { false }

    private fun fetch(url: String): String? {
        require(isHttpUrl(url)) { "Unsupported repository URL" }
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", CrawlerEngine.MOBILE_UA)
            .header("Accept", "application/json, */*;q=0.8")
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw Exception("HTTP ${resp.code}")
            val body = resp.body ?: return null
            val bytes = body.byteStream().use { input ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(8 * 1024)
                var total = 0L
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > MAX_REPOSITORY_BYTES) throw Exception("Repository index is too large")
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            }
            return bytes.toString(Charsets.UTF_8)
        }
    }

    private const val MAX_REPOSITORY_BYTES = 8L * 1024L * 1024L
}
