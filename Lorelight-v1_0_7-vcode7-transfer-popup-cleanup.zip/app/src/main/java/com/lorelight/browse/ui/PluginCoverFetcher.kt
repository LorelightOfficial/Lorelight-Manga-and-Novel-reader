package com.lorelight.browse.ui

import coil.ImageLoader
import coil.decode.DataSource
import coil.decode.ImageSource
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.fetch.SourceResult
import coil.request.Options
import com.lorelight.browse.js.PluginImageRequestInit
import com.lorelight.network.HttpClients
import com.lorelight.network.PublicInternetDns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okio.Buffer
import okio.ForwardingSource
import okio.buffer

/** Coil model retaining the full LNReader ImageRequestInit, not just headers. */
data class PluginCoverRequestData(
    val url: String,
    val method: String,
    val headers: Map<String, String>,
    val body: String?
)

/** Fetches plugin covers with the source's configured method, headers and body. */
class PluginCoverFetcher(
    private val data: PluginCoverRequestData,
    private val options: Options
) : Fetcher {

    override suspend fun fetch(): FetchResult? = withContext(Dispatchers.IO) {
        val url = data.url.trim()
        require(url.startsWith("https://", true) || url.startsWith("http://", true)) {
            "Plugin cover URL must use HTTP or HTTPS"
        }
        val method = data.method.uppercase().ifBlank { "GET" }
        require(method.matches(Regex("[A-Z]{3,12}"))) { "Unsupported plugin cover request method" }

        val requestBuilder = Request.Builder().url(url)
        data.headers.forEach { (name, value) -> requestBuilder.header(name, value) }
        if (data.headers.keys.none { it.equals("User-Agent", true) }) {
            requestBuilder.header("User-Agent", "Mozilla/5.0 (Android)")
        }
        val contentType = data.headers.entries.firstOrNull { it.key.equals("Content-Type", true) }
            ?.value?.toMediaTypeOrNull()
        val requestBody = if (method == "GET" || method == "HEAD") null
            else (data.body ?: "").toRequestBody(contentType)
        val request = requestBuilder.method(method, requestBody).build()
        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            val code = response.code
            val message = response.message
            response.close()
            throw IllegalStateException("Plugin cover request failed: HTTP $code $message")
        }
        val body = response.body
        if (body == null) {
            response.close()
            throw IllegalStateException("Plugin cover response has no image body")
        }
        val length = body.contentLength()
        if (length > MAX_COVER_RESPONSE_BYTES) {
            response.close()
            throw IllegalStateException("Plugin cover response exceeds the 20 MiB limit")
        }
        // Content-Length may be absent or dishonest; enforce the cap while
        // Coil consumes the stream, not only against the response header.
        var totalRead = 0L
        val boundedSource = object : ForwardingSource(body.source()) {
            override fun read(sink: Buffer, byteCount: Long): Long {
                val allowance = minOf(byteCount, MAX_COVER_RESPONSE_BYTES - totalRead + 1L)
                val read = super.read(sink, allowance)
                if (read > 0L) {
                    totalRead += read
                    if (totalRead > MAX_COVER_RESPONSE_BYTES) {
                        throw java.io.IOException("Plugin cover response exceeds the 20 MiB limit")
                    }
                }
                return read
            }
        }
        SourceResult(
            source = ImageSource(source = boundedSource.buffer(), context = options.context),
            mimeType = body.contentType()?.toString(),
            dataSource = DataSource.NETWORK
        )
    }

    class Factory : Fetcher.Factory<PluginCoverRequestData> {
        override fun create(data: PluginCoverRequestData, options: Options, imageLoader: ImageLoader): Fetcher =
            PluginCoverFetcher(data, options)
    }

    private companion object {
        const val MAX_COVER_RESPONSE_BYTES = 20L * 1024L * 1024L
        val client by lazy {
            HttpClients.sharedBuilder()
                .connectionPool(okhttp3.ConnectionPool(4, 5, java.util.concurrent.TimeUnit.MINUTES))
                .dns(PublicInternetDns)
                .build()
        }
    }
}

fun PluginCoverRequestData.cacheKey(): String {
    val canonical = buildString {
        append(url).append('\n').append(method.uppercase()).append('\n')
        headers.entries.sortedBy { it.key.lowercase() }.forEach { append(it.key.lowercase()).append(':').append(it.value).append('\n') }
        append(body.orEmpty())
    }
    val digest = java.security.MessageDigest.getInstance("SHA-256")
        .digest(canonical.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it) }
    return "plugin-cover:$digest"
}

fun PluginImageRequestInit.toCoverRequestData(url: String): PluginCoverRequestData =
    PluginCoverRequestData(url, method, headers, body)
