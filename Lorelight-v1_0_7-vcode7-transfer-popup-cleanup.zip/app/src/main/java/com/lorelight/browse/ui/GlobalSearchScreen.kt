package com.lorelight.browse.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.Priority
import com.lorelight.browse.js.JSPluginEngine
import com.lorelight.crawler.CrawlerEngine
import com.lorelight.browse.model.SourceNovelItem
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import androidx.compose.ui.semantics.Role

private const val GLOBAL_SEARCH_CONCURRENCY = 3

private data class SourceSearchState(
    val pluginId: String,
    val name: String,
    val site: String,
    val loading: Boolean,
    val items: List<SourceNovelItem>,
    val error: String?,
    val imageRequestInit: com.lorelight.browse.js.PluginImageRequestInit =
        com.lorelight.browse.js.PluginImageRequestInit("GET", emptyMap(), null)
)

/** Global search across all installed sources, grouped per source. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlobalSearchScreen(
    onBack: () -> Unit,
    onOpenNovel: (String, SourceNovelItem) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val keyboardController = LocalSoftwareKeyboardController.current
    val vm: BrowseViewModel = viewModel()
    val installed by vm.installed.collectAsState()

    LaunchedEffect(Unit) { vm.loadInstalled(context) }

    var query by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf(false) }
    var showResultsOnly by remember { mutableStateOf(false) }
    var completedCount by remember { mutableStateOf(0) }
    val results = remember { mutableStateListOf<SourceSearchState>() }
    var searchJob by remember { mutableStateOf<Job?>(null) }
    var searchGeneration by remember { mutableStateOf(0) }
    var lastTriggeredQuery by remember { mutableStateOf<String?>(null) }

    fun cancelCurrentSearch(clearResults: Boolean) {
        searchGeneration += 1
        searchJob?.cancel()
        searchJob = null
        if (clearResults) results.clear()
        completedCount = 0
        submitted = false
        lastTriggeredQuery = null
    }

    fun runSearch(rawQuery: String = query) {
        val q = rawQuery.trim()
        if (q.isBlank() || installed.isEmpty()) return

        // Every explicit submission starts a fresh generation, even if the text
        // is identical to the previous search. Old child jobs cannot publish
        // results into the new generation.
        searchJob?.cancel()
        val generation = ++searchGeneration
        lastTriggeredQuery = q
        submitted = true
        showResultsOnly = false
        completedCount = 0
        val sourceSnapshot = installed.sortedBy { it.info.name.lowercase() }
        results.clear()
        results.addAll(sourceSnapshot.map {
            SourceSearchState(it.info.id, it.info.name, it.info.site, true, emptyList(), null)
        })

        searchJob = scope.launch {
            val permits = Semaphore(GLOBAL_SEARCH_CONCURRENCY)
            supervisorScope {
                sourceSnapshot.forEach { source ->
                    launch {
                        try {
                            val response = permits.withPermit {
                                JSPluginEngine.searchNovelsWithImageRequestInit(
                                    context.applicationContext,
                                    source.info.id,
                                    q,
                                    1
                                )
                            }
                            if (generation == searchGeneration) {
                                val index = results.indexOfFirst { it.pluginId == source.info.id }
                                if (index >= 0) {
                                    results[index] = results[index].copy(
                                        loading = false,
                                        items = response.novels.distinctBy { it.path },
                                        error = null,
                                        imageRequestInit = response.imageRequestInit
                                    )
                                }
                            }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            if (generation == searchGeneration) {
                                val index = results.indexOfFirst { it.pluginId == source.info.id }
                                if (index >= 0) {
                                    results[index] = results[index].copy(
                                        loading = false,
                                        error = e.message ?: "Search failed"
                                    )
                                }
                            }
                        } finally {
                            if (generation == searchGeneration) completedCount += 1
                        }
                    }
                }
            }
        }
    }

    // LNReader's global search is debounced. Text edits invalidate the previous
    // generation immediately; the new query is submitted after a short pause.
    LaunchedEffect(query, installed) {
        val q = query.trim()
        if (q.isBlank() || installed.isEmpty()) return@LaunchedEffect
        delay(300)
        if (q == query.trim() && q != lastTriggeredQuery) runSearch(q)
    }

    DisposableEffect(Unit) {
        onDispose {
            searchGeneration += 1
            searchJob?.cancel()
        }
    }

    val orderedResults = results.sortedWith(
        compareBy<SourceSearchState> {
            when {
                it.items.isNotEmpty() -> 0
                it.loading -> 1
                else -> 2
            }
        }.thenBy { it.name.lowercase() }
    )
    val visibleResults = if (showResultsOnly) {
        orderedResults.filter { !it.loading && it.error == null && it.items.isNotEmpty() }
    } else orderedResults
    val totalSources = results.size
    val searchProgress = if (totalSources == 0) 0f else completedCount.toFloat() / totalSources.toFloat()

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                windowInsets = WindowInsets(0, 0, 0, 0),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    TextField(
                        value = query,
                        onValueChange = { newValue ->
                            query = newValue
                            cancelCurrentSearch(clearResults = true)
                        },
                        singleLine = true,
                        placeholder = { Text("Search all sources") },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = {
                            runSearch(query)
                            keyboardController?.hide()
                        }),
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                actions = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = {
                            query = ""
                            cancelCurrentSearch(clearResults = true)
                        }) { Icon(Icons.Filled.Close, contentDescription = "Clear") }
                    }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (submitted && totalSources > 0) {
                LinearProgressIndicator(
                    progress = { searchProgress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (completedCount >= totalSources) "Searched $totalSources sources"
                        else "Searching $completedCount of $totalSources sources",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = showResultsOnly,
                        onClick = { showResultsOnly = !showResultsOnly },
                        label = { Text("Has results") }
                    )
                }
            }
            Box(Modifier.fillMaxSize()) {
                when {
                    installed.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Install a source first", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    !submitted -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("Type a title to search all sources", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    else -> LazyColumn(
                        Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        if (showResultsOnly && visibleResults.isEmpty()) {
                            item {
                                Box(
                                    Modifier.fillMaxWidth().padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "No sources have returned results yet",
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        } else {
                            items(visibleResults.size, key = { i -> visibleResults[i].pluginId }) { i ->
                                SourceResultBlock(visibleResults[i], onOpenNovel)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SourceResultBlock(r: SourceSearchState, onOpenNovel: (String, SourceNovelItem) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(r.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (r.loading) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
        }
        when {
            r.error != null -> Text(
                r.error,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            !r.loading && r.items.isEmpty() -> Text(
                "No results",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            else -> {
                val context = LocalContext.current
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(r.items.size) { i ->
                        val novel = r.items[i]
                        val request = remember(novel.cover, r.site, r.imageRequestInit) {
                            val coverUrl = novel.cover
                            if (coverUrl.isNullOrBlank()) null
                            else {
                                val requestHeaders = r.imageRequestInit.headers.toMutableMap()
                                if (requestHeaders.keys.none { it.equals("User-Agent", true) }) {
                                    requestHeaders["User-Agent"] = CrawlerEngine.mobileUserAgent(context)
                                }
                                if (requestHeaders.keys.none { it.equals("Referer", true) } && r.site.isNotBlank()) {
                                    requestHeaders["Referer"] = r.site
                                }
                                val requestData = r.imageRequestInit.copy(headers = requestHeaders)
                                    .toCoverRequestData(coverUrl)
                                val cacheKey = requestData.cacheKey()
                                ImageRequest.Builder(context)
                                    .data(requestData)
                                    .memoryCacheKey(cacheKey)
                                    .diskCacheKey(cacheKey)
                                    .placeholderMemoryCacheKey(cacheKey)
                                    .priority(Priority.HIGH)
                                    .crossfade(true)
                                    .build()
                            }
                        }
                        Column(
                            Modifier
                                .width(100.dp)
                                .clickable(role = Role.Button) { onOpenNovel(r.pluginId, novel) }
                        ) {
                            AsyncImage(
                                model = request,
                                contentDescription = novel.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .width(100.dp)
                                    .aspectRatio(0.7f)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(novel.name, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}
