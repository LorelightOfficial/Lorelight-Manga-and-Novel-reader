package com.lorelight.browse.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInParent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.ui.theme.getThemedButtonProps
import kotlin.math.roundToInt
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.Priority
import com.lorelight.browse.js.JSPluginEngine
import com.lorelight.crawler.CrawlerEngine
import com.lorelight.browse.model.FilterDef
import com.lorelight.browse.model.FilterValue
import com.lorelight.browse.model.FilterValues
import com.lorelight.browse.model.SourceNovelItem
import com.lorelight.browse.repo.SourceChapterCountCache
import com.lorelight.ui.animation.BookGridSkeleton
import com.lorelight.ui.animation.StaggeredItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.lorelight.ui.components.browse.BrowseActionButton
import com.lorelight.ui.components.browse.BrowseCoverBadge
import com.lorelight.ui.components.browse.BrowseGridCard
import com.lorelight.ui.components.browse.BrowseListRow
import androidx.compose.ui.semantics.Role
import kotlin.math.ceil

/**
 * A source can occasionally return a non-empty page that contains only items
 * already seen on earlier pages. Those pages must advance pagination rather
 * than falsely marking the source as exhausted. We automatically step through
 * a small run of such pages, then expose an explicit continuation control so
 * a broken source cannot create an unbounded request loop.
 */
private const val SOURCE_DUPLICATE_PAGE_AUTO_CONTINUE_LIMIT = 3

private data class SourcePaginationSnapshot(
    val searchMode: Boolean,
    val itemCount: Int,
    val lastVisibleNovelIndex: Int,
    val visibleNovelCount: Int,
    val firstVisibleItemIndex: Int,
    val firstVisibleItemScrollOffset: Int,
    val loadedPage: Int,
    val duplicateOnlyPages: Int,
    val loading: Boolean,
    val loadingMore: Boolean,
    val endReached: Boolean
)

/**
 * LNReader-style source catalog screen, restyled to match Lorelight's
 * pill/card visual language (same as Library and the Browse root).
 * Public signature unchanged.
 */
@Composable
fun SourceScreen(
    pluginId: String,
    pluginName: String,
    site: String,
    startLatest: Boolean,
    onBack: () -> Unit,
    onOpenNovel: (String, SourceNovelItem) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val keyboardController = LocalSoftwareKeyboardController.current

    var showLatest by remember(pluginId) { mutableStateOf(startLatest) }

    // Search has its own query, result list, request generation and pagination.
    // The catalogue continues to own its independent listing state.
    var searchActive by remember(pluginId) { mutableStateOf(false) }
    var searchField by remember(pluginId) { mutableStateOf("") }
    var activeQuery by remember(pluginId) { mutableStateOf<String?>(null) }

    var filterDefs by remember(pluginId) { mutableStateOf<List<FilterDef>>(emptyList()) }
    var filterValues by remember(pluginId) { mutableStateOf<FilterValues?>(null) }
    var showFilters by remember { mutableStateOf(false) }

    val catalogItems = remember(pluginId) { mutableStateListOf<SourceNovelItem>() }
    val searchItems = remember(pluginId) { mutableStateListOf<SourceNovelItem>() }
    var catalogPage by remember(pluginId) { mutableStateOf(1) }
    var searchPage by remember(pluginId) { mutableStateOf(1) }
    // Track successfully consumed pages separately from the visible novel
    // count. A non-empty page containing only duplicates still advances the
    // source page, otherwise several real sources stop after page 2.
    var catalogDuplicateOnlyPages by remember(pluginId) { mutableStateOf(0) }
    var searchDuplicateOnlyPages by remember(pluginId) { mutableStateOf(0) }
    // Prevent scroll/layout updates from requesting the same page repeatedly.
    // A failed request can be explicitly retried through the footer action.
    var catalogLastAutoRequestedPage by remember(pluginId) { mutableStateOf(1) }
    var searchLastAutoRequestedPage by remember(pluginId) { mutableStateOf(1) }
    var catalogLoading by remember(pluginId) { mutableStateOf(true) }
    var catalogLoadingMore by remember(pluginId) { mutableStateOf(false) }
    var searchLoading by remember(pluginId) { mutableStateOf(false) }
    var searchLoadingMore by remember(pluginId) { mutableStateOf(false) }
    var catalogEndReached by remember(pluginId) { mutableStateOf(false) }
    var searchEndReached by remember(pluginId) { mutableStateOf(false) }
    var catalogError by remember(pluginId) { mutableStateOf<String?>(null) }
    var searchError by remember(pluginId) { mutableStateOf<String?>(null) }
    var catalogPageError by remember(pluginId) { mutableStateOf<String?>(null) }
    var searchPageError by remember(pluginId) { mutableStateOf<String?>(null) }
    var catalogGeneration by remember(pluginId) { mutableStateOf(0) }
    var searchGeneration by remember(pluginId) { mutableStateOf(0) }
    var catalogReloadJob by remember(pluginId) { mutableStateOf<Job?>(null) }
    var catalogPageJob by remember(pluginId) { mutableStateOf<Job?>(null) }
    var searchJob by remember(pluginId) { mutableStateOf<Job?>(null) }
    var searchPageJob by remember(pluginId) { mutableStateOf<Job?>(null) }
    var catalogNeedsReload by remember(pluginId) { mutableStateOf(false) }

    val gridState = rememberLazyGridState()

    val settingsVersion by com.lorelight.data.local.AppSettingsSignal.version.collectAsState()
    var imageRequestInit by remember(pluginId) {
        mutableStateOf(com.lorelight.browse.js.PluginImageRequestInit("GET", emptyMap(), null))
    }
    LaunchedEffect(pluginId) {
        imageRequestInit = withContext(Dispatchers.IO) {
            try { JSPluginEngine.getImageRequestInit(context.applicationContext, pluginId) }
            catch (_: Exception) { com.lorelight.browse.js.PluginImageRequestInit("GET", emptyMap(), null) }
        }
    }

    // Catalog display preferences (layout, covers per row, badges...). Stored in
    // the canonical settings file, so the choice sticks across sources/restarts.
    var display by remember(settingsVersion) { mutableStateOf(SourceDisplayPrefs.load(context)) }
    var showDisplaySettings by remember { mutableStateOf(false) }

    // Whether the user flagged THIS source as adult. Drives blur / hide.
    var adultSource by remember(pluginId, settingsVersion) { mutableStateOf(AdultSources.isAdult(context, pluginId)) }

    // Novel paths from THIS source that already live in the library, plus the
    // subset marked Completed. Read off the main thread; failures are silent.
    var libraryPaths by remember { mutableStateOf<Set<String>>(emptySet()) }
    var finishedPaths by remember { mutableStateOf<Set<String>>(emptySet()) }
    val needsLibraryLookup = display.showLibraryBadge ||
        display.dimFinished ||
        display.libraryFilter != SourceLibraryFilter.NORMAL
    LaunchedEffect(pluginId, needsLibraryLookup) {
        if (!needsLibraryLookup) {
            libraryPaths = emptySet()
            finishedPaths = emptySet()
        } else {
            val loaded = withContext(Dispatchers.IO) {
                try {
                    val mine = com.lorelight.data.local.NovelPreferences
                        .loadNovelsFromPrefs(context)
                        .filter { it.pluginId == pluginId }
                    val all = mine.mapNotNull { it.pluginNovelPath }.toSet()
                    val done = mine
                        .filter { it.readingStatus == "Completed" }
                        .mapNotNull { it.pluginNovelPath }
                        .toSet()
                    all to done
                } catch (e: Exception) {
                    emptySet<String>() to emptySet<String>()
                }
            }
            libraryPaths = loaded.first
            finishedPaths = loaded.second
        }
    }

    // Keep the selected result collection separate from the data source that fills it.
    val showingSearchResults = activeQuery != null
    val items = if (showingSearchResults) searchItems else catalogItems
    val loading = if (showingSearchResults) searchLoading else catalogLoading
    val loadingMore = if (showingSearchResults) searchLoadingMore else catalogLoadingMore
    val currentError = if (showingSearchResults) searchError else catalogError
    val currentPageError = if (showingSearchResults) searchPageError else catalogPageError
    val currentDuplicateOnlyPages = if (showingSearchResults) searchDuplicateOnlyPages else catalogDuplicateOnlyPages
    val currentEndReached = if (showingSearchResults) searchEndReached else catalogEndReached
    val currentNeedsManualContinuation = currentDuplicateOnlyPages >= SOURCE_DUPLICATE_PAGE_AUTO_CONTINUE_LIMIT &&
        !loading && !loadingMore && !currentEndReached

    // The grid actually draws after the library/adult-content preferences are applied.
    val displayItemsState = remember(items, libraryPaths, finishedPaths, adultSource, display) {
        derivedStateOf {
            when {
                adultSource && display.nsfwMode == SourceNsfwMode.HIDE -> emptyList()
                display.libraryFilter == SourceLibraryFilter.HIDE_LIBRARY -> items.filter { it.path !in libraryPaths }
                display.libraryFilter == SourceLibraryFilter.LIBRARY_FIRST -> items.sortedByDescending { it.path in libraryPaths }
                else -> items.toList()
            }
        }
    }
    val displayItems = displayItemsState.value
    val blurCovers = adultSource && display.nsfwMode == SourceNsfwMode.BLUR

    LaunchedEffect(pluginId) {
        filterDefs = try {
            JSPluginEngine.getFilters(context.applicationContext, pluginId)
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun fetchCatalog(
        page: Int,
        latest: Boolean,
        filtersJson: String?
    ): List<SourceNovelItem> = JSPluginEngine.popularNovels(
        context.applicationContext,
        pluginId,
        page,
        latest,
        filtersJson
    )

    suspend fun fetchSearch(query: String, p: Int): List<SourceNovelItem> =
        JSPluginEngine.searchNovels(context.applicationContext, pluginId, query, p)

    fun reloadCatalog() {
        val token = ++catalogGeneration
        catalogReloadJob?.cancel()
        catalogPageJob?.cancel()
        catalogLoading = true
        catalogLoadingMore = false
        catalogError = null
        catalogPageError = null
        catalogEndReached = false
        catalogPage = 1
        catalogDuplicateOnlyPages = 0
        catalogLastAutoRequestedPage = 1
        val latestSnapshot = showLatest
        val filtersSnapshot = filterValues?.toJson()?.toString()
        catalogReloadJob = scope.launch {
            try {
                val result = fetchCatalog(1, latestSnapshot, filtersSnapshot)
                if (token != catalogGeneration) return@launch
                catalogItems.clear()
                catalogItems.addAll(result.distinctBy { it.path })
                catalogPage = 1
                catalogEndReached = result.isEmpty()
                catalogNeedsReload = false
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (token == catalogGeneration) {
                    catalogError = e.message ?: "Failed to load"
                    catalogItems.clear()
                    catalogEndReached = true
                }
            } finally {
                if (token == catalogGeneration) catalogLoading = false
            }
        }
    }

    fun loadNextCatalogPage(force: Boolean = false) {
        if (catalogLoading || catalogLoadingMore || catalogEndReached || catalogPageJob?.isActive == true) return
        val token = catalogGeneration
        val nextPage = catalogPage + 1
        if (force) {
            // Explicit retry/continue re-arms the next page even after a
            // transient error or a run of duplicate-only pages.
            catalogDuplicateOnlyPages = 0
            catalogLastAutoRequestedPage = catalogPage
        } else if (catalogLastAutoRequestedPage >= nextPage) {
            return
        }
        catalogLastAutoRequestedPage = nextPage
        val latestSnapshot = showLatest
        val filtersSnapshot = filterValues?.toJson()?.toString()
        catalogLoadingMore = true
        catalogPageError = null
        catalogPageJob = scope.launch {
            try {
                val result = fetchCatalog(nextPage, latestSnapshot, filtersSnapshot)
                if (token != catalogGeneration) return@launch
                if (result.isEmpty()) {
                    // Only a genuinely empty successful response is a reliable
                    // end-of-catalogue signal. Duplicate-only pages are not.
                    catalogEndReached = true
                    catalogPageError = null
                } else {
                    val existing = catalogItems.mapTo(HashSet()) { it.path }
                    val fresh = result.distinctBy { it.path }.filter { it.path !in existing }
                    if (fresh.isNotEmpty()) {
                        catalogItems.addAll(fresh)
                        catalogDuplicateOnlyPages = 0
                    } else {
                        catalogDuplicateOnlyPages += 1
                    }
                    // Advance even when this page overlaps an earlier page.
                    // Some sources deliberately overlap page boundaries.
                    catalogPage = nextPage
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (token == catalogGeneration) catalogPageError = e.message ?: "Could not load the next page"
            } finally {
                if (token == catalogGeneration) catalogLoadingMore = false
            }
        }
    }

    fun startSearch(rawQuery: String) {
        val query = rawQuery.trim()
        searchJob?.cancel()
        searchPageJob?.cancel()
        val token = ++searchGeneration
        if (query.isBlank()) {
            activeQuery = null
            searchItems.clear()
            searchPage = 1
            searchDuplicateOnlyPages = 0
            searchLastAutoRequestedPage = 1
            searchLoading = false
            searchLoadingMore = false
            searchEndReached = false
            searchError = null
            searchPageError = null
            if (catalogNeedsReload) reloadCatalog()
            return
        }

        // A catalogue request for this same plugin can occupy its single QuickJS
        // context. Cancel it so an explicitly submitted search gets priority.
        if (catalogLoading || catalogLoadingMore) {
            catalogReloadJob?.cancel()
            catalogPageJob?.cancel()
            catalogGeneration += 1
            catalogLoading = false
            catalogLoadingMore = false
            catalogNeedsReload = true
        }

        activeQuery = query
        scope.launch { gridState.scrollToItem(0) }
        searchItems.clear()
        searchPage = 1
        searchDuplicateOnlyPages = 0
        searchLastAutoRequestedPage = 1
        searchLoading = true
        searchLoadingMore = false
        searchEndReached = false
        searchError = null
        searchPageError = null
        searchJob = scope.launch {
            try {
                val result = fetchSearch(query, 1)
                if (token != searchGeneration) return@launch
                searchItems.addAll(result.distinctBy { it.path })
                searchPage = 1
                searchEndReached = result.isEmpty()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (token == searchGeneration) {
                    searchError = e.message ?: "Search failed"
                    searchEndReached = true
                }
            } finally {
                if (token == searchGeneration) searchLoading = false
            }
        }
    }

    fun clearSearch() {
        searchJob?.cancel()
        searchPageJob?.cancel()
        searchGeneration += 1
        activeQuery = null
        scope.launch { gridState.scrollToItem(0) }
        searchItems.clear()
        searchPage = 1
        searchDuplicateOnlyPages = 0
        searchLastAutoRequestedPage = 1
        searchLoading = false
        searchLoadingMore = false
        searchEndReached = false
        searchError = null
        searchPageError = null
        if (catalogNeedsReload) reloadCatalog()
    }

    fun loadNextSearchPage(force: Boolean = false) {
        val query = activeQuery ?: return
        if (searchLoading || searchLoadingMore || searchEndReached || searchPageJob?.isActive == true) return
        val token = searchGeneration
        val nextPage = searchPage + 1
        if (force) {
            searchDuplicateOnlyPages = 0
            searchLastAutoRequestedPage = searchPage
        } else if (searchLastAutoRequestedPage >= nextPage) {
            return
        }
        searchLastAutoRequestedPage = nextPage
        searchLoadingMore = true
        searchPageError = null
        searchPageJob = scope.launch {
            try {
                val result = fetchSearch(query, nextPage)
                if (token != searchGeneration || query != activeQuery) return@launch
                if (result.isEmpty()) {
                    searchEndReached = true
                    searchPageError = null
                } else {
                    val existing = searchItems.mapTo(HashSet()) { it.path }
                    val fresh = result.distinctBy { it.path }.filter { it.path !in existing }
                    if (fresh.isNotEmpty()) {
                        searchItems.addAll(fresh)
                        searchDuplicateOnlyPages = 0
                    } else {
                        searchDuplicateOnlyPages += 1
                    }
                    searchPage = nextPage
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (token == searchGeneration) searchPageError = e.message ?: "Could not load the next page"
            } finally {
                if (token == searchGeneration) searchLoadingMore = false
            }
        }
    }

    fun retryNextPage() {
        if (showingSearchResults) loadNextSearchPage(force = true) else loadNextCatalogPage(force = true)
    }

    LaunchedEffect(filterValues, showLatest, pluginId) {
        if (activeQuery == null) reloadCatalog()
    }

    LaunchedEffect(gridState, pluginId, activeQuery, filterValues, showLatest, displayItemsState) {
        snapshotFlow {
            val layoutInfo = gridState.layoutInfo
            val visibleItems = layoutInfo.visibleItemsInfo
            val currentCount = displayItemsState.value.size
            val visibleFooter = visibleItems.any { it.index >= currentCount }
            val lastNovelIndex = when {
                currentCount <= 0 -> -1
                // The loading/retry/continue footer is after the final novel.
                // If it is visible by itself, the user has already reached the
                // end of the novel cells and pagination must still be eligible.
                visibleFooter -> currentCount - 1
                else -> visibleItems
                    .asSequence()
                    .filter { it.index < currentCount }
                    .maxOfOrNull { it.index } ?: -1
            }
            val visibleNovelCells = visibleItems.count { it.index < currentCount }
            val searchMode = activeQuery != null
            SourcePaginationSnapshot(
                searchMode = searchMode,
                itemCount = currentCount,
                lastVisibleNovelIndex = lastNovelIndex,
                visibleNovelCount = visibleNovelCells,
                firstVisibleItemIndex = gridState.firstVisibleItemIndex,
                firstVisibleItemScrollOffset = gridState.firstVisibleItemScrollOffset,
                loadedPage = if (searchMode) searchPage else catalogPage,
                duplicateOnlyPages = if (searchMode) searchDuplicateOnlyPages else catalogDuplicateOnlyPages,
                loading = if (searchMode) searchLoading else catalogLoading,
                loadingMore = if (searchMode) searchLoadingMore else catalogLoadingMore,
                endReached = if (searchMode) searchEndReached else catalogEndReached
            )
        }.collect { state ->
            if (state.itemCount <= 0 || state.lastVisibleNovelIndex < 0 || state.loading ||
                state.loadingMore || state.endReached
            ) return@collect

            // LNReader starts prefetching at roughly 1.5 viewport heights from
            // the bottom. In a LazyGrid, visible cells are a useful proxy for
            // that distance and scale naturally with list/grid column count.
            val remainingNovelItems = (state.itemCount - 1 - state.lastVisibleNovelIndex).coerceAtLeast(0)
            val prefetchThreshold = maxOf(6, ceil(state.visibleNovelCount.coerceAtLeast(1) * 1.5).toInt())
            if (remainingNovelItems > prefetchThreshold) return@collect

            if (state.searchMode) {
                // A short run of duplicate-only pages is automatically stepped
                // through. A hard ceiling prevents a malformed source from
                // creating an endless background request loop.
                if (state.duplicateOnlyPages < SOURCE_DUPLICATE_PAGE_AUTO_CONTINUE_LIMIT) {
                    loadNextSearchPage()
                }
            } else if (state.duplicateOnlyPages < SOURCE_DUPLICATE_PAGE_AUTO_CONTINUE_LIMIT) {
                loadNextCatalogPage()
            }
        }
    }

    // The site's listing selector = its first Picker filter (options differ per site). Null if none.
    val listingFilter = filterDefs.firstOrNull { it is FilterDef.Picker } as? FilterDef.Picker
    val listingCurrentValue = (filterValues?.map?.get(listingFilter?.key)?.value as? String)
        ?: listingFilter?.default

    // Build the dropdown entries (label, isSelected, onSelect). Real site listings when available,
    // otherwise the Popular/Latest fallback.
    fun defaultFilterMap(): MutableMap<String, FilterValue> {
        val map = mutableMapOf<String, FilterValue>()
        filterDefs.forEach { f ->
            map[f.key] = when (f) {
                is FilterDef.Picker -> FilterValue("Picker", f.default)
                is FilterDef.TextInput -> FilterValue("Text", f.default)
                is FilterDef.Switch -> FilterValue("Switch", f.default)
                is FilterDef.CheckboxGroup -> FilterValue("Checkbox", f.defaults.toList())
                is FilterDef.ExcludableCheckboxGroup ->
                    FilterValue("XCheckbox", Pair(f.includedDefaults.toList(), f.excludedDefaults.toList()))
            }
        }
        return map
    }

    val listingEntries: List<Triple<String, Boolean, () -> Unit>> = if (listingFilter != null) {
        listingFilter.options.map { opt ->
            Triple(opt.first, listingCurrentValue == opt.second) {
                // start from all defaults, keep any existing user selections, then apply the chosen listing
                val map = defaultFilterMap()
                filterValues?.map?.forEach { (k, v) -> map[k] = v }
                map[listingFilter.key] = FilterValue("Picker", opt.second)
                filterValues = FilterValues(map)
            }
        }
    } else {
        listOf(
            Triple("Popular", !showLatest) { showLatest = false },
            Triple("Latest", showLatest) { showLatest = true }
        )
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // ── Header: back pill + title + action pills (matches Browse root / Library) ──
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 12.dp)
                .heightIn(min = 48.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            BrowseActionButton(
                icon = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                onClick = onBack
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = pluginName,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = MaterialTheme.typography.headlineLarge.fontFamily,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (!activeQuery.isNullOrBlank()) {
                    Text(
                        "Search: $activeQuery",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BrowseActionButton(
                    icon = Icons.Filled.Search,
                    contentDescription = "Search $pluginName",
                    active = searchActive,
                    onClick = {
                        if (searchActive) {
                            searchActive = false
                            searchField = ""
                            clearSearch()
                        } else {
                            searchActive = true
                        }
                    }
                )
                if (filterDefs.isNotEmpty() && activeQuery == null) {
                    BrowseActionButton(
                        icon = Icons.Filled.FilterList,
                        contentDescription = "Filters",
                        onClick = { showFilters = true }
                    )
                }
                BrowseActionButton(
                    icon = Icons.Filled.Tune,
                    contentDescription = "Display settings",
                    active = showDisplaySettings,
                    onClick = { showDisplaySettings = true }
                )
            }
        }

        // ── Inline search field (rounded, themed) ──
        if (searchActive) {
            val focusRequester = remember { FocusRequester() }
            LaunchedEffect(Unit) { focusRequester.requestFocus() }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 8.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Filled.Search,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(10.dp))
                BasicTextField(
                    value = searchField,
                    onValueChange = { searchField = it },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = {
                        startSearch(searchField)
                        keyboardController?.hide()
                    }),
                    modifier = Modifier
                        .weight(1f)
                        .focusRequester(focusRequester),
                    decorationBox = { inner ->
                        Box {
                            if (searchField.isEmpty()) {
                                Text(
                                    "Search $pluginName",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            inner()
                        }
                    }
                )
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Close search",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .size(18.dp)
                        .clickable(role = Role.Button) {
                            searchActive = false
                            searchField = ""
                            clearSearch()
                        }
                )
            }
        }

        // ── Listing selector pill row ──
        if (listingEntries.isNotEmpty() && activeQuery == null) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                items(listingEntries.size) { i ->
                    val entry = listingEntries[i]
                    val label = entry.first
                    val selected = entry.second
                    val onSelect = entry.third
                    // TINT FIX: the pill is FILLED with the theme's own light
                    // "container" colour (the same soft, pre-tuned tone each
                    // theme ships for exactly this kind of tinted surface),
                    // instead of a raw alpha-blended primary that read as an
                    // off/muddy wash on some themes. Selected state is carried
                    // by how strong that container tint is.
                    val pillTint = if (selected) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
                    // The outline stays theme-specific (drawn from the active
                    // theme's primary colour), never a fixed green. Selected
                    // pills get the full strength outline, unselected ones a
                    // softer version.
                    val pillOutline = if (selected) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.primary.copy(alpha = 0.60f)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(pillTint)
                            .border(
                                1.dp,
                                pillOutline,
                                RoundedCornerShape(14.dp)
                            )
                            .clickable { onSelect() }
                    ) {
                        Text(
                            text = label,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (selected) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // ── Content ──
        Box(Modifier.fillMaxSize()) {
            when {
                loading -> BookGridSkeleton(columns = if (display.columns > 0) display.columns else 3)
                currentError != null -> com.lorelight.ui.components.LorelightError(
                    message = currentError,
                    onRetry = {
                        val query = activeQuery
                        if (query != null) startSearch(query) else reloadCatalog()
                    },
                    onOpenWebsite = null,
                    modifier = Modifier.fillMaxSize()
                )
                displayItems.isEmpty() -> Box(Modifier.fillMaxSize()) {
                    com.lorelight.ui.components.LorelightEmpty(
                        icon = Icons.Filled.SearchOff,
                        title = if (items.isNotEmpty()) "Everything is in your library" else "No novels found",
                        message = if (adultSource && display.nsfwMode == SourceNsfwMode.HIDE)
                            "Covers from this source are hidden by your adult content setting"
                        else if (items.isNotEmpty())
                            "Everything here is already in your library"
                        else "Try a different search or filter.",
                        modifier = Modifier.fillMaxSize()
                    )
                    // When the local Hide Library filter removes every loaded
                    // card, there is no scrollable grid to reach the normal
                    // pagination trigger. Keep a continuation path available
                    // instead of making the source appear permanently empty.
                    if (items.isNotEmpty() &&
                        display.libraryFilter == SourceLibraryFilter.HIDE_LIBRARY &&
                        !(adultSource && display.nsfwMode == SourceNsfwMode.HIDE) &&
                        !currentEndReached
                    ) {
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            if (loadingMore) {
                                com.lorelight.ui.components.LorelightLoading(
                                    shape = com.lorelight.ui.components.LoadingShape.INLINE
                                )
                            } else {
                                TextButton(onClick = { retryNextPage() }) {
                                    Text(
                                        if (currentPageError != null) "Couldn't load more. Tap to retry"
                                        else if (currentNeedsManualContinuation) "This source repeated earlier novels. Tap to continue"
                                        else "Load more novels"
                                    )
                                }
                            }
                        }
                    }
                }
                else -> LazyVerticalGrid(
                    // List mode is a single-column grid so paging keeps working
                    // off the same scroll state as every other layout.
                    columns = when {
                        display.layout == SourceLayoutMode.LIST -> GridCells.Fixed(1)
                        display.columns > 0 -> GridCells.Fixed(display.columns)
                        display.layout == SourceLayoutMode.COMPACT_GRID -> GridCells.Adaptive(88.dp)
                        else -> GridCells.Adaptive(112.dp)
                    },
                    state = gridState,
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(display.spacing.gap),
                    verticalArrangement = Arrangement.spacedBy(display.spacing.gap),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(items = displayItems, key = { _, novel -> novel.path }) { i, novel ->
                        StaggeredItem(index = i, key = novel.path) {
                            if (display.layout == SourceLayoutMode.LIST) {
                                SourceListRow(
                                    item = novel,
                                    pluginId = pluginId,
                                    site = site,
                                    coverRatio = display.coverShape.ratio,
                                    cornerRadius = display.coverCorner.dp,
                                    titleSizeSp = display.titleSize.sp,
                                    showChapterBadge = display.showChapterBadge,
                                    inLibrary = novel.path in libraryPaths,
                                    showLibraryBadge = display.showLibraryBadge,
                                    dim = display.dimFinished && novel.path in finishedPaths,
                                    blurCover = blurCovers,
                                    dataSaver = display.dataSaver,
                                    imageRequestInit = imageRequestInit,
                                    onClick = { onOpenNovel(pluginId, novel) }
                                )
                            } else {
                                NovelCover(
                                    item = novel,
                                    pluginId = pluginId,
                                    site = site,
                                    aspectRatio = display.coverShape.ratio,
                                    cornerRadius = display.coverCorner.dp,
                                    showTitle = display.titlesVisible,
                                    titleLines = display.titleLines,
                                    titleSizeSp = display.titleSize.sp,
                                    showChapterBadge = display.showChapterBadge,
                                    inLibrary = novel.path in libraryPaths,
                                    showLibraryBadge = display.showLibraryBadge,
                                    dim = display.dimFinished && novel.path in finishedPaths,
                                    blurCover = blurCovers,
                                    dataSaver = display.dataSaver,
                                    imageRequestInit = imageRequestInit,
                                    onClick = { onOpenNovel(pluginId, novel) }
                                )
                            }
                        }
                    }
                    if (loadingMore) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            com.lorelight.ui.components.LorelightLoading(
                                shape = com.lorelight.ui.components.LoadingShape.INLINE
                            )
                        }
                    } else if (currentPageError != null) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            TextButton(onClick = { retryNextPage() }, modifier = Modifier.fillMaxWidth()) {
                                Text("Couldn't load more. Tap to retry", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    } else if (currentNeedsManualContinuation) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            TextButton(onClick = { retryNextPage() }, modifier = Modifier.fillMaxWidth()) {
                                Text("This source repeated earlier novels. Tap to continue loading", color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }

    FilterBottomSheet(
        pluginId = pluginId,
        filters = filterDefs,
        initial = filterValues,
        visible = showFilters,
        onApply = { fv ->
            filterValues = fv
            showFilters = false
        },
        onDismiss = { showFilters = false }
    )

        SourceDisplaySettingsSheet(
            visible = showDisplaySettings,
            initial = display,
            sourceName = pluginName,
            isAdultSource = adultSource,
            onAdultSourceChange = { flagged ->
                adultSource = flagged
                AdultSources.setAdult(context, pluginId, flagged)
            },
            onApply = { updated ->
                display = updated
                SourceDisplayPrefs.save(context, updated)
            },
            onDismiss = { showDisplaySettings = false }
        )
    }
}

@Composable
private fun NovelCover(
    item: SourceNovelItem,
    pluginId: String,
    site: String = "",
    aspectRatio: Float = 0.7f,
    cornerRadius: Dp = 12.dp,
    showTitle: Boolean = true,
    titleLines: Int = 2,
    titleSizeSp: Int = 11,
    showChapterBadge: Boolean = true,
    inLibrary: Boolean = false,
    showLibraryBadge: Boolean = true,
    dim: Boolean = false,
    blurCover: Boolean = false,
    dataSaver: Boolean = false,
    imageRequestInit: com.lorelight.browse.js.PluginImageRequestInit = com.lorelight.browse.js.PluginImageRequestInit("GET", emptyMap(), null),
    onClick: () -> Unit
) {
    val chapterCount = rememberSourceChapterCount(pluginId, item.path, showChapterBadge)
    val request = rememberNovelCoverRequest(item.cover, site, dataSaver, imageRequestInit)

    BrowseGridCard(
        title = item.name,
        aspectRatio = aspectRatio,
        cornerRadius = cornerRadius,
        showTitle = showTitle,
        titleLines = titleLines,
        titleSizeSp = titleSizeSp,
        inLibrary = inLibrary,
        showLibraryBadge = showLibraryBadge,
        dim = dim,
        blurCover = blurCover,
        onClick = onClick,
        overlay = {
            // Chapter count is novel-only: the manga extensions report it as
            // part of the listing, plugins do not.
            if (showChapterBadge && chapterCount != null && chapterCount > 0) {
                BrowseCoverBadge(
                    text = "$chapterCount ch",
                    alignment = Alignment.BottomEnd,
                    background = Color.Black.copy(alpha = 0.72f),
                    contentColor = Color.White
                )
            }
        }
    ) { coverModifier ->
        NovelCoverPixels(
            request = request,
            contentDescription = item.name,
            modifier = coverModifier,
            placeholderIconSize = 32.dp
        )
    }
}

@Composable
private fun SourceListRow(
    item: SourceNovelItem,
    pluginId: String,
    site: String = "",
    coverRatio: Float = 0.7f,
    cornerRadius: Dp = 12.dp,
    titleSizeSp: Int = 13,
    showChapterBadge: Boolean = true,
    inLibrary: Boolean = false,
    showLibraryBadge: Boolean = true,
    dim: Boolean = false,
    blurCover: Boolean = false,
    dataSaver: Boolean = false,
    imageRequestInit: com.lorelight.browse.js.PluginImageRequestInit = com.lorelight.browse.js.PluginImageRequestInit("GET", emptyMap(), null),
    onClick: () -> Unit
) {
    val chapterCount = rememberSourceChapterCount(pluginId, item.path, showChapterBadge)
    val request = rememberNovelCoverRequest(item.cover, site, dataSaver, imageRequestInit)

    BrowseListRow(
        title = item.name,
        coverRatio = coverRatio,
        cornerRadius = cornerRadius,
        titleSizeSp = titleSizeSp,
        dim = dim,
        blurCover = blurCover,
        onClick = onClick,
        details = {
            // The novel side states library and chapter state as one joined
            // caption; the manga side uses a pill. Kept per-side on purpose.
            val subtitle = buildList {
                if (showLibraryBadge && inLibrary) add("In library")
                if (showChapterBadge && chapterCount != null && chapterCount > 0) add("$chapterCount chapters")
            }.joinToString("  -  ")
            if (subtitle.isNotBlank()) {
                Spacer(Modifier.height(2.dp))
                Text(
                    subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    ) { coverModifier ->
        NovelCoverPixels(
            request = request,
            contentDescription = item.name,
            modifier = coverModifier,
            placeholderIconSize = 20.dp
        )
    }
}

/**
 * Chapter counts are NOT part of a plugin listing response, so each one is
 * fetched per novel and cached. The cache caps itself to two concurrent
 * fetches and remembers failures, so scrolling a long grid cannot stampede
 * the source site.
 *
 * The grid card and the list row each used to carry their own copy of this
 * logic, including the same bug where a cache that nothing ever filled was
 * only PEEKED inside a remember that never re-ran - so the badge could never
 * draw anything at all.
 */
@Composable
private fun rememberSourceChapterCount(
    pluginId: String,
    path: String,
    enabled: Boolean
): Int? {
    val context = LocalContext.current
    var count by remember(pluginId, path) {
        mutableStateOf(SourceChapterCountCache.peek(pluginId, path))
    }
    LaunchedEffect(pluginId, path, enabled) {
        if (!enabled || count != null) return@LaunchedEffect
        val fetched = SourceChapterCountCache.fetch(context.applicationContext, pluginId, path)
        if (fetched != SourceChapterCountCache.UNKNOWN) count = fetched
    }
    return count
}

/**
 * Novel covers need a per-plugin request: a Referer derived from the plugin
 * site, because many sources reject cover requests without one. This is the
 * part of catalog presentation that genuinely cannot be shared with manga,
 * which resolves covers through the extension network stack instead.
 */
@Composable
private fun rememberNovelCoverRequest(
    coverUrl: String?,
    site: String,
    dataSaver: Boolean,
    imageRequestInit: com.lorelight.browse.js.PluginImageRequestInit
): ImageRequest? {
    val context = LocalContext.current
    return remember(coverUrl, site, dataSaver, imageRequestInit) {
        if (coverUrl.isNullOrBlank()) null
        else {
            val requestHeaders = imageRequestInit.headers.toMutableMap()
            if (requestHeaders.keys.none { it.equals("User-Agent", true) }) {
                requestHeaders["User-Agent"] = CrawlerEngine.mobileUserAgent(context)
            }
            if (requestHeaders.keys.none { it.equals("Referer", true) } && site.isNotBlank()) {
                requestHeaders["Referer"] = site
            }
            val requestData = imageRequestInit.copy(headers = requestHeaders).toCoverRequestData(coverUrl)
            val cacheKey = requestData.cacheKey()
            ImageRequest.Builder(context)
                .data(requestData)
                .memoryCacheKey(cacheKey)
                .diskCacheKey(cacheKey)
                .placeholderMemoryCacheKey(cacheKey)
                // Catalogue covers are immediately visible content; prioritize
                // them over background/low-priority image work in the shared pool.
                .priority(Priority.HIGH)
                .crossfade(true)
                .apply {
                    // Headers are applied by PluginCoverFetcher together with
                    // method/body. The default Referer/User-Agent are added to
                    // the immutable request-init before it is handed to Coil.
                    if (dataSaver) {
                        // Small RGB_565 bitmap: far fewer bytes over the wire
                        // and roughly half the memory once decoded.
                        size(240, 360)
                        bitmapConfig(android.graphics.Bitmap.Config.RGB_565)
                    }
                }
                .build()
        }
    }
}

/** The cover pixels for a novel, or a book glyph when there is no cover. */
@Composable
private fun NovelCoverPixels(
    request: ImageRequest?,
    contentDescription: String,
    modifier: Modifier,
    placeholderIconSize: Dp
) {
    if (request != null) {
        AsyncImage(
            model = request,
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
    } else {
        Box(modifier, contentAlignment = Alignment.Center) {
            Icon(
                imageVector = Icons.Filled.MenuBook,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                modifier = Modifier.size(placeholderIconSize)
            )
        }
    }
}
