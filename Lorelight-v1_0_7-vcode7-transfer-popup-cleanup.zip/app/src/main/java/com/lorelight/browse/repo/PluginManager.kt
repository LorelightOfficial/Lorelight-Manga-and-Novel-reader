package com.lorelight.browse.repo

import android.content.Context
import com.lorelight.browse.model.InstalledPlugin
import com.lorelight.browse.model.PluginInfo
import com.lorelight.browse.js.JSPluginEngine
import com.lorelight.crawler.CrawlerEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import java.util.LinkedHashMap
import java.util.concurrent.CancellationException

object PluginManager {
    // FIX B11 + C17: shared, Cloudflare-aware, pooled client instead of a
    // private per-object OkHttpClient.
    private val client: OkHttpClient by lazy {
        // Plugin bundles and their custom page assets are repository-controlled
        // URLs. Resolve them through the same public-address DNS guard as plugin
        // fetches, with an isolated pool so a previously pooled connection cannot
        // bypass the guarded DNS lookup.
        com.lorelight.network.HttpClients.sharedBuilder()
            .connectionPool(okhttp3.ConnectionPool(4, 5, java.util.concurrent.TimeUnit.MINUTES))
            .dns(com.lorelight.network.PublicInternetDns)
            .build()
    }

    private fun pluginsDir(context: Context): File {
        val dir = File(context.filesDir, "plugins")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    // FIX A5: a repo-supplied id containing path separators ("../../evil")
    // used to write outside the plugins directory. Ids are now reduced to a
    // single safe file-name component. Ordinary ids are unchanged.
    fun pluginFile(context: Context, pluginId: String): File =
        File(pluginsDir(context), com.lorelight.browse.js.sanitizePluginId(pluginId) + ".js")

    fun customJsFile(context: Context, pluginId: String): File =
        File(pluginsDir(context), com.lorelight.browse.js.sanitizePluginId(pluginId) + ".custom.js")

    fun customCssFile(context: Context, pluginId: String): File =
        File(pluginsDir(context), com.lorelight.browse.js.sanitizePluginId(pluginId) + ".custom.css")

    suspend fun installPlugin(context: Context, info: PluginInfo): Result<InstalledPlugin> =
        installValidated(context, info, preservePinned = false)

    fun uninstallPlugin(context: Context, id: String) {
        JSPluginEngine.evict(id)
        val previous = PluginStore.getInstalled(context).firstOrNull { it.info.id == id }
        // Commit metadata first. If that commit fails, keep the bundle intact
        // so the still-installed entry is not left pointing at a missing file.
        PluginStore.remove(context, id)
        previous?.info?.site?.let { site ->
            val removedOrigin = com.lorelight.webstorage.WebStorageSnapshotStore.normalizeOrigin(site)
            val stillUsed = removedOrigin != null && PluginStore.getInstalled(context).any { installed ->
                com.lorelight.webstorage.WebStorageSnapshotStore.normalizeOrigin(installed.info.site) == removedOrigin
            }
            // More than one source can legitimately share a website origin.
            // Preserve its Web Storage snapshot until the final such source is removed.
            if (removedOrigin != null && !stillUsed) {
                com.lorelight.webstorage.WebStorageSnapshotStore.clear(context, removedOrigin)
            }
        }
        pluginFile(context, id).delete()
        customJsFile(context, id).delete()
        customCssFile(context, id).delete()
        // Delete this plugin's namespaced storage prefs after its engine context is evicted.
        val storageCleared = context.getSharedPreferences(
            com.lorelight.browse.js.pluginStoragePrefsName(id), Context.MODE_PRIVATE
        ).edit().clear().commit()
        if (!storageCleared) {
            android.util.Log.w("PluginManager", "Removed plugin but could not clear its namespaced storage: $id")
        }
    }

    suspend fun updatePlugin(context: Context, info: PluginInfo): Result<InstalledPlugin> =
        installValidated(context, info, preservePinned = true)

    private suspend fun installValidated(
        context: Context,
        info: PluginInfo,
        preservePinned: Boolean
    ): Result<InstalledPlugin> = withContext(Dispatchers.IO) {
        var stagedFile: File? = null
        var stagedCustomJs: File? = null
        var stagedCustomCss: File? = null
        var stagingId: String? = null
        try {
            require(isSafePluginId(info.id)) { "Invalid plugin ID" }
            require(isHttpUrl(info.url)) { "Plugin bundle URL must use HTTP or HTTPS" }
            val js = download(info.url)
                ?: return@withContext Result.failure(Exception("Download failed: empty plugin bundle"))
            require(js.isNotBlank()) { "Plugin bundle is empty" }

            val stageId = "__stage_${UUID.randomUUID().toString().replace("-", "")}"
            stagingId = stageId
            val staged = pluginFile(context, stageId)
            stagedFile = staged
            staged.writeText(js, Charsets.UTF_8)

            // Custom assets are executable/rendering inputs, so require HTTPS
            // rather than accepting a manifest downgrade to cleartext HTTP.
            stagedCustomJs = info.customJS?.let { url ->
                require(isHttpsUrl(url)) { "Plugin customJS must use HTTPS" }
                val file = File(pluginsDir(context), "$stageId.custom.js")
                file.writeText(downloadTextAsset(url, "custom JavaScript"), Charsets.UTF_8)
                file
            }
            stagedCustomCss = info.customCSS?.let { url ->
                require(isHttpsUrl(url)) { "Plugin customCSS must use HTTPS" }
                val file = File(pluginsDir(context), "$stageId.custom.css")
                file.writeText(downloadTextAsset(url, "custom CSS"), Charsets.UTF_8)
                file
            }

            // Run the same QuickJS-compatible plugin bootstrap used at runtime,
            // but against a temporary file and temporary plugin namespace.
            val meta = JSPluginEngine.validatePluginContract(
                context.applicationContext,
                stageId,
                info.id
            )
            require(meta.version.isNotBlank()) { "Plugin bundle has no version" }

            val destination = pluginFile(context, info.id)
            val previous = PluginStore.getInstalled(context).firstOrNull { it.info.id == info.id }
            val installed = InstalledPlugin(
                info = info.copy(version = meta.version),
                filePath = destination.absolutePath,
                installedVersion = meta.version,
                pinned = if (preservePinned) previous?.pinned ?: false else false
            )
            // Keep the previous bundle available until both activation and metadata
            // persistence complete. A failed commit restores the old file.
            replaceFileSafely(staged, destination) {
                replaceAuxiliaryFilesSafely(
                    listOf(
                        stagedCustomJs to customJsFile(context, info.id),
                        stagedCustomCss to customCssFile(context, info.id)
                    )
                ) {
                    PluginStore.save(context, installed)
                }
            }
            JSPluginEngine.evict(info.id)
            Result.success(installed)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            stagingId?.let { id ->
                JSPluginEngine.evict(id)
                // Plugin bootstrap can seed default settings even in the staged
                // validation context. Do not leave one preferences namespace per update.
                context.getSharedPreferences(
                    com.lorelight.browse.js.pluginStoragePrefsName(id),
                    Context.MODE_PRIVATE
                ).edit().clear().commit().also { cleared ->
                    if (!cleared) android.util.Log.w("PluginManager", "Could not clear temporary plugin storage: $id")
                }
            }
            stagedFile?.delete()
            stagedCustomJs?.delete()
            stagedCustomCss?.delete()
        }
    }

    private fun replaceFileSafely(
        staged: File,
        destination: File,
        commitMetadata: () -> Unit
    ) {
        val backup = File(destination.parentFile, destination.name + ".backup-" + UUID.randomUUID())
        val movedOld = destination.exists()
        if (movedOld && !destination.renameTo(backup)) {
            throw IllegalStateException("Could not stage the previous plugin bundle")
        }
        var activated = false
        try {
            if (!staged.renameTo(destination)) {
                throw IllegalStateException("Could not activate the validated plugin bundle")
            }
            activated = true
            commitMetadata()
            if (movedOld) backup.delete()
        } catch (e: Exception) {
            if (activated) destination.delete()
            if (movedOld && backup.exists() && !backup.renameTo(destination)) {
                throw IllegalStateException(
                    "Plugin update failed and the previous bundle could not be restored: ${e.message}", e
                )
            }
            throw e
        }
    }

    private fun replaceAuxiliaryFilesSafely(
        replacements: List<Pair<File?, File>>,
        commitMetadata: () -> Unit
    ) {
        val backups = LinkedHashMap<File, File>()
        val activated = ArrayList<File>()
        try {
            // Move every old asset aside first. A missing staged asset means
            // the new manifest intentionally removed that asset.
            replacements.forEach { (_, destination) ->
                if (destination.exists()) {
                    val backup = File(destination.parentFile, destination.name + ".backup-" + UUID.randomUUID())
                    if (!destination.renameTo(backup)) {
                        throw IllegalStateException("Could not stage previous plugin asset: ${destination.name}")
                    }
                    backups[destination] = backup
                }
            }
            replacements.forEach { (staged, destination) ->
                if (staged != null) {
                    if (!staged.renameTo(destination)) {
                        throw IllegalStateException("Could not activate plugin asset: ${destination.name}")
                    }
                    activated.add(destination)
                }
            }
            commitMetadata()
            backups.values.forEach { it.delete() }
        } catch (e: Exception) {
            activated.forEach { it.delete() }
            backups.forEach { (destination, backup) ->
                if (backup.exists() && !backup.renameTo(destination)) {
                    throw IllegalStateException(
                        "Plugin asset update failed and previous asset could not be restored: ${destination.name}", e
                    )
                }
            }
            throw e
        }
    }

    private fun isHttpsUrl(value: String): Boolean = try {
        val uri = android.net.Uri.parse(value.trim())
        uri.scheme.equals("https", true) && !uri.host.isNullOrBlank()
    } catch (_: Exception) { false }

    private fun downloadTextAsset(url: String, kind: String): String {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", CrawlerEngine.MOBILE_UA)
            .header("Accept", "text/javascript, application/javascript, text/css, */*;q=0.5")
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.request.url.isHttps) throw IllegalStateException("Plugin $kind redirected to a non-HTTPS URL")
            if (!resp.isSuccessful) throw IllegalStateException("Could not download plugin $kind (HTTP ${resp.code})")
            val body = resp.body ?: throw IllegalStateException("Plugin $kind response was empty")
            val bytes = body.byteStream().use { input ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(8 * 1024)
                var total = 0L
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > MAX_PLUGIN_ASSET_BYTES) throw IllegalStateException("Plugin $kind exceeds the 1 MiB limit")
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            }
            val text = bytes.toString(Charsets.UTF_8)
            require(text.isNotBlank()) { "Plugin $kind is empty" }
            return text
        }
    }

    private fun isSafePluginId(value: String): Boolean =
        value.length in 1..100 && value.matches(Regex("[A-Za-z0-9][A-Za-z0-9._-]*")) &&
            !value.contains("..")

    private fun isHttpUrl(value: String): Boolean = try {
        val url = android.net.Uri.parse(value.trim())
        (url.scheme.equals("https", true) || url.scheme.equals("http", true)) && !url.host.isNullOrBlank()
    } catch (_: Exception) { false }

    fun hasUpdate(installed: InstalledPlugin, available: PluginInfo): Boolean =
        PluginVersion.isNewer(available.version, installed.installedVersion)

    private fun download(url: String): String? {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", CrawlerEngine.MOBILE_UA)
            .header("Accept", "application/javascript, text/javascript, */*;q=0.8")
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw Exception("HTTP ${resp.code}")
            val body = resp.body ?: return null
            val bytes = body.byteStream().use { input ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(8 * 1024)
                var total = 0L
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    total += count
                    if (total > MAX_PLUGIN_BYTES) throw Exception("Plugin bundle exceeds the 12 MB limit")
                    output.write(buffer, 0, count)
                }
                output.toByteArray()
            }
            return bytes.toString(Charsets.UTF_8)
        }
    }

    private const val MAX_PLUGIN_BYTES = 12L * 1024L * 1024L
    private const val MAX_PLUGIN_ASSET_BYTES = 1L * 1024L * 1024L
}
