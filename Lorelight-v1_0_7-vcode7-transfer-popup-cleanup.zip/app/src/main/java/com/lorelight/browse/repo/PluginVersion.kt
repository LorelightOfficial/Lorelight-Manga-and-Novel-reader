package com.lorelight.browse.repo

/** Semantic-ish version ordering for repository versions such as v3.0.0 and 3.1.0-beta. */
object PluginVersion {
    private data class Parsed(val numbers: List<Long>, val prerelease: List<String>?)

    private fun parse(raw: String): Parsed? {
        val value = raw.trim().removePrefix("v").removePrefix("V").substringBefore('+')
        if (value.isEmpty()) return null
        val pieces = value.split('-', limit = 2)
        val numeric = pieces[0].split('.')
        if (numeric.isEmpty() || numeric.any { it.isEmpty() || it.any { ch -> !ch.isDigit() } }) return null
        val numbers = numeric.map { it.toLongOrNull() ?: return null }
        val prerelease = if (pieces.size == 2) {
            pieces[1].split('.').takeIf { parts -> parts.all { it.isNotBlank() } }
        } else null
        return Parsed(numbers, prerelease)
    }

    /** Returns null for malformed versions rather than guessing an upgrade. */
    fun compare(a: String, b: String): Int? {
        val left = parse(a) ?: return null
        val right = parse(b) ?: return null
        val size = maxOf(left.numbers.size, right.numbers.size)
        for (index in 0 until size) {
            val l = left.numbers.getOrElse(index) { 0L }
            val r = right.numbers.getOrElse(index) { 0L }
            if (l != r) return l.compareTo(r)
        }
        if (left.prerelease == null && right.prerelease != null) return 1
        if (left.prerelease != null && right.prerelease == null) return -1
        if (left.prerelease == null && right.prerelease == null) return 0
        val lParts = left.prerelease.orEmpty()
        val rParts = right.prerelease.orEmpty()
        for (index in 0 until maxOf(lParts.size, rParts.size)) {
            if (index >= lParts.size) return -1
            if (index >= rParts.size) return 1
            val l = lParts[index]
            val r = rParts[index]
            val ln = l.toLongOrNull()
            val rn = r.toLongOrNull()
            val result = when {
                ln != null && rn != null -> ln.compareTo(rn)
                ln != null -> -1
                rn != null -> 1
                else -> l.compareTo(r, ignoreCase = true)
            }
            if (result != 0) return result
        }
        return 0
    }

    fun isNewer(candidate: String, installed: String): Boolean =
        compare(candidate, installed)?.let { it > 0 } ?: false
}
