package com.lorelight.browse.js

import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.nodes.Node
import org.jsoup.nodes.TextNode
import org.jsoup.nodes.Comment
import org.jsoup.nodes.DataNode

/**
 * Jsoup-backed, handle-based DOM operations behind the cheerio shim.
 * One instance per QuickJS context; accessed only on that context's single JS thread.
 * Selection ops return a JSON array string of int handles (parsed in JS).
 * Scalar ops return Int handle (-1 = none), String (null = missing), or Boolean.
 */
class CheerioBridge {
    private val handles = HashMap<Int, Node>()
    private var counter = 1

    private fun put(node: Node): Int { val id = counter++; handles[id] = node; return id }
    private fun get(handle: Int): Node? = handles[handle]
    private fun asElement(handle: Int): Element? = handles[handle] as? Element

    private fun toHandleArray(nodes: List<Node>): String {
        val arr = JSONArray()
        for (n in nodes) arr.put(put(n))
        return arr.toString()
    }

    fun parse(html: String): Int = put(Jsoup.parse(html))

    /**
     * Jsoup and Cheerio share most CSS selectors, but Cheerio also exposes the
     * jQuery positional filters :first, :last, :eq(n), :lt(n), and :gt(n).
     * Apply those filters to the selected result set rather than incorrectly
     * rewriting :first as :first-of-type (which is not equivalent).
     *
     * Positional filters are applied at the selector compound where they
     * occur, including common descendant/child/sibling chains used by sources.
     */
    private fun selectCompat(el: Element, selector: String): List<Element> {
        fun splitOutside(value: String, separators: Set<Char>): List<String> {
            val out = ArrayList<String>(); var depth = 0; var quote: Char? = null; var start = 0
            value.forEachIndexed { index, ch ->
                if (quote != null) { if (ch == quote) quote = null }
                else when (ch) {
                    '\'', '"' -> quote = ch
                    '(' , '[' -> depth++
                    ')' , ']' -> if (depth > 0) depth--
                    else -> if (depth == 0 && ch in separators) { out.add(value.substring(start, index)); start = index + 1 }
                }
            }
            out.add(value.substring(start))
            return out
        }
        fun splitGroups(value: String): List<String> = splitOutside(value, setOf(',')).map { it.trim() }.filter { it.isNotEmpty() }
        fun splitSteps(value: String): List<Pair<Char, String>> {
            val out = ArrayList<Pair<Char, String>>()
            var depth = 0; var quote: Char? = null; var token = StringBuilder(); var pending = ' '
            fun flush() { val part = token.toString().trim(); if (part.isNotEmpty()) { out.add(pending to part); token = StringBuilder(); pending = ' ' } }
            value.forEach { ch ->
                if (quote != null) { token.append(ch); if (ch == quote) quote = null }
                else when (ch) {
                    '\'', '"' -> { quote = ch; token.append(ch) }
                    '(' , '[' -> { depth++; token.append(ch) }
                    ')' , ']' -> { if (depth > 0) depth--; token.append(ch) }
                    else -> {
                        if (depth == 0 && ch.isWhitespace()) { flush(); if (pending == ' ') pending = ' ' }
                        else if (depth == 0 && ch in setOf('>', '+', '~')) { flush(); pending = ch }
                        else token.append(ch)
                    }
                }
            }
            flush()
            return out
        }
        val positional = Regex(""":(first|last|eq\((-?\d+)\)|lt\((-?\d+)\)|gt\((-?\d+)\))\s*$""", RegexOption.IGNORE_CASE)
        fun applyPositions(input: List<Element>, filters: List<Pair<String, Int?>>): List<Element> {
            var selected = input
            for ((kind, n) in filters) {
                val size = selected.size
                selected = when (kind) {
                    "first" -> selected.take(1)
                    "last" -> selected.takeLast(1)
                    "eq" -> { val idx = n ?: -1; val actual = if (idx < 0) size + idx else idx; selected.getOrNull(actual)?.let { listOf(it) } ?: emptyList() }
                    "lt" -> { val idx = n ?: 0; val actual = if (idx < 0) size + idx else idx; selected.take(actual.coerceAtLeast(0)) }
                    "gt" -> { val idx = n ?: -1; val actual = if (idx < 0) size + idx else idx; selected.drop((actual + 1).coerceAtLeast(0)) }
                    else -> selected
                }
            }
            return selected
        }
        val combined = LinkedHashSet<Element>()
        for (group in splitGroups(selector)) {
            var current: List<Element> = emptyList()
            val steps = splitSteps(group)
            for ((stepIndex, step) in steps.withIndex()) {
                val combinator = step.first
                var base = step.second
                val filters = ArrayList<Pair<String, Int?>>()
                while (true) {
                    val match = positional.find(base) ?: break
                    val token = match.groupValues[1].lowercase()
                    val kind = when { token == "first" -> "first"; token == "last" -> "last"; token.startsWith("eq") -> "eq"; token.startsWith("lt") -> "lt"; else -> "gt" }
                    val number = match.groupValues.drop(2).firstOrNull { it.isNotEmpty() }?.toIntOrNull()
                    filters.add(0, kind to number)
                    base = base.substring(0, match.range.first).trimEnd()
                }
                if (base.isBlank()) base = "*"
                val matches = LinkedHashSet<Element>()
                if (stepIndex == 0) {
                    matches.addAll(runCatching { el.select(base).toList() }.getOrDefault(emptyList()))
                } else {
                    for (parent in current) {
                        when (combinator) {
                            '>' -> matches.addAll(parent.children().filter { runCatching { it.`is`(base) }.getOrDefault(false) })
                            '+' -> parent.nextElementSibling()?.let { if (runCatching { it.`is`(base) }.getOrDefault(false)) matches.add(it) }
                            '~' -> { var sibling = parent.nextElementSibling(); while (sibling != null) { if (runCatching { sibling.`is`(base) }.getOrDefault(false)) matches.add(sibling); sibling = sibling.nextElementSibling() } }
                            else -> matches.addAll(runCatching { parent.select(base).toList() }.getOrDefault(emptyList()))
                        }
                    }
                }
                current = applyPositions(matches.toList(), filters)
            }
            combined.addAll(current)
        }
        return combined.toList()
    }

    fun select(handle: Int, css: String): String {
        val el = asElement(handle) ?: return "[]"
        return toHandleArray(selectCompat(el, css))
    }

    fun selectOne(handle: Int, css: String): Int {
        val el = asElement(handle) ?: return -1
        val found = selectCompat(el, css).firstOrNull() ?: return -1
        return put(found)
    }

    fun children(handle: Int): String {
        val el = asElement(handle) ?: return "[]"
        return toHandleArray(el.children().toList())
    }

    fun childrenSelector(handle: Int, css: String): String {
        val el = asElement(handle) ?: return "[]"
        val children = el.children().toList()
        val positional = Regex(""":(first|last|eq\((-?\d+)\)|lt\((-?\d+)\)|gt\((-?\d+)\))\s*$""", RegexOption.IGNORE_CASE).find(css)
        if (positional == null) return toHandleArray(children.filter { runCatching { matchesSelector(it, css) }.getOrDefault(false) })
        val base = css.substring(0, positional.range.first).trimEnd().ifBlank { "*" }
        val kind = when { positional.groupValues[1].equals("first", true) -> "first"; positional.groupValues[1].equals("last", true) -> "last"; positional.groupValues[1].startsWith("eq", true) -> "eq"; positional.groupValues[1].startsWith("lt", true) -> "lt"; else -> "gt" }
        val n = positional.groupValues.drop(2).firstOrNull { it.isNotEmpty() }?.toIntOrNull() ?: 0
        var selected = children.filter { runCatching { it.`is`(base) }.getOrDefault(false) }
        val idx = if (n < 0) selected.size + n else n
        selected = when (kind) { "first" -> selected.take(1); "last" -> selected.takeLast(1); "eq" -> listOfNotNull(selected.getOrNull(idx)); "lt" -> selected.take(idx.coerceAtLeast(0)); else -> selected.drop((idx + 1).coerceAtLeast(0)) }
        return toHandleArray(selected)
    }

    /** Cheerio .filter(selector) applies positional filters to the current set, not
     * to the first element of each tag type. Preserve the incoming order and
     * handles so callback node identity remains stable across chained calls. */
    fun filter(handlesJson: String, selector: String, invert: Boolean = false): String {
        val ids = try {
            val arr = JSONArray(handlesJson)
            (0 until arr.length()).map { arr.optInt(it, -1) }.filter { it >= 0 }
        } catch (_: Exception) { emptyList() }
        if (ids.isEmpty()) return "[]"

        fun splitGroups(value: String): List<String> {
            val groups = ArrayList<String>()
            var quote: Char? = null
            var depth = 0
            var start = 0
            value.forEachIndexed { index, ch ->
                if (quote != null) { if (ch == quote) quote = null }
                else when (ch) {
                    '\'', '"' -> quote = ch
                    '(', '[' -> depth++
                    ')', ']' -> if (depth > 0) depth--
                    ',' -> if (depth == 0) { groups.add(value.substring(start, index).trim()); start = index + 1 }
                }
            }
            groups.add(value.substring(start).trim())
            return groups.filter { it.isNotEmpty() }
        }

        val positional = Regex(""":(first|last|eq\((-?\d+)\)|lt\((-?\d+)\)|gt\((-?\d+)\))\s*$""", RegexOption.IGNORE_CASE)
        val matched = LinkedHashSet<Int>()
        for (group in splitGroups(selector)) {
            var base = group
            val filters = ArrayList<Pair<String, Int?>>()
            while (true) {
                val match = positional.find(base) ?: break
                val token = match.groupValues[1].lowercase()
                val kind = when { token == "first" -> "first"; token == "last" -> "last"; token.startsWith("eq") -> "eq"; token.startsWith("lt") -> "lt"; else -> "gt" }
                val number = match.groupValues.drop(2).firstOrNull { it.isNotEmpty() }?.toIntOrNull()
                filters.add(0, kind to number)
                base = base.substring(0, match.range.first).trimEnd()
            }
            val candidates: List<Pair<Int, Element>> = ids.mapNotNull { id ->
                val element = get(id) as? Element
                if (element == null) null else Pair(id, element)
            }.filter { candidate ->
                val element = candidate.second
                if (base.isBlank()) true
                else if (filters.isEmpty()) matchesSelector(element, base)
                else runCatching { element.`is`(base) }.getOrDefault(false)
            }
            var selected: List<Pair<Int, Element>> = candidates
            for ((kind, number) in filters) {
                val size = selected.size
                val index = number ?: if (kind == "eq" || kind == "gt") -1 else 0
                val actual = if (index < 0) size + index else index
                selected = when (kind) {
                    "first" -> selected.take(1)
                    "last" -> selected.takeLast(1)
                    "eq" -> listOfNotNull(selected.getOrNull(actual))
                    "lt" -> selected.take(actual.coerceAtLeast(0))
                    else -> selected.drop((actual + 1).coerceAtLeast(0))
                }
            }
            selected.forEach { pair -> matched.add(pair.first) }
        }
        val result = if (invert) ids.filterNot { matched.contains(it) } else ids.filter { matched.contains(it) }
        val arr = JSONArray()
        result.forEach { arr.put(it) }
        return arr.toString()
    }

    private fun matchesSelector(element: Element, selector: String): Boolean {
        if (selector.isBlank()) return false
        var root: Node = element
        while (root.parent() != null) root = root.parent()!!
        val context = root as? Element ?: element
        return runCatching { selectCompat(context, selector).any { it === element } }
            .getOrDefault(runCatching { element.`is`(selector) }.getOrDefault(false))
    }

    fun contents(handle: Int): String {
        val el = asElement(handle) ?: return "[]"
        return toHandleArray(el.childNodes())
    }

    fun previousNode(handle: Int): Int { val n = get(handle)?.previousSibling() ?: return -1; return put(n) }
    fun nextNode(handle: Int): Int { val n = get(handle)?.nextSibling() ?: return -1; return put(n) }

    fun text(handle: Int): String {
        return when (val node = get(handle)) {
            is Element -> node.text()
            is TextNode -> node.text()
            is DataNode -> node.wholeData
            is Comment -> ""
            null -> ""
            else -> node.toString()
        }
    }

    fun ownText(handle: Int): String = asElement(handle)?.ownText() ?: ""

    fun html(handle: Int): String {
        return when (val node = get(handle)) {
            is Document -> node.html()
            is Element -> node.html()
            else -> ""
        }
    }

    fun outerHtml(handle: Int): String = get(handle)?.outerHtml() ?: ""

    fun nodeInfo(handle: Int): String {
        val node = get(handle) ?: return "{}"
        val out = JSONObject()
        when (node) {
            is Document -> {
                out.put("name", "#document")
                out.put("tagName", "#document")
                out.put("type", "root")
                out.put("nodeType", 9)
                out.put("attribs", JSONObject())
            }
            is Element -> {
                val attrs = JSONObject()
                for (attr in node.attributes()) attrs.put(attr.key, attr.value)
                out.put("attribs", attrs)
                out.put("name", node.tagName())
                out.put("tagName", node.tagName().uppercase())
                out.put("type", "tag")
                out.put("nodeType", 1)
                out.put("data", JSONObject.NULL)
            }
            is TextNode -> {
                out.put("name", "#text")
                out.put("tagName", "#text")
                out.put("type", "text")
                out.put("nodeType", 3)
                out.put("data", node.getWholeText())
                out.put("attribs", JSONObject())
            }
            is DataNode -> {
                out.put("name", "#text")
                out.put("tagName", "#text")
                out.put("type", "text")
                out.put("nodeType", 3)
                out.put("data", node.wholeData)
                out.put("attribs", JSONObject())
            }
            is Comment -> {
                out.put("name", "#comment")
                out.put("tagName", "#comment")
                out.put("type", "comment")
                out.put("nodeType", 8)
                out.put("data", node.data)
                out.put("attribs", JSONObject())
            }
            else -> {
                out.put("name", "#node")
                out.put("tagName", "#node")
                out.put("type", "root")
                out.put("nodeType", 0)
                out.put("attribs", JSONObject())
            }
        }
        return out.toString()
    }

    fun attributes(handle: Int): String {
        val out = JSONObject()
        asElement(handle)?.attributes()?.forEach { out.put(it.key, it.value) }
        return out.toString()
    }

    fun removeAttr(handle: Int, name: String) { asElement(handle)?.removeAttr(name) }

    fun clone(handle: Int): Int {
        val node = get(handle) ?: return -1
        return put(node.clone())
    }

    fun wrap(handle: Int, html: String) { asElement(handle)?.wrap(html) }

    fun nextUntil(handle: Int, selector: String): String {
        val el = asElement(handle) ?: return "[]"
        val list = ArrayList<Node>()
        var cur = el.nextElementSibling()
        while (cur != null && (selector.isBlank() || !cur.`is`(selector))) {
            list.add(cur)
            cur = cur.nextElementSibling()
        }
        return toHandleArray(list)
    }

    fun index(handle: Int): Int {
        val el = asElement(handle) ?: return -1
        return el.elementSiblingIndex()
    }

    fun has(handle: Int, selector: String): Boolean {
        val el = asElement(handle) ?: return false
        return runCatching { selectCompat(el, selector).isNotEmpty() }.getOrDefault(false)
    }

    fun attr(handle: Int, name: String): String? {
        val el = asElement(handle) ?: return null
        return if (el.hasAttr(name)) el.attr(name) else null
    }

    fun setAttr(handle: Int, name: String, value: String) { asElement(handle)?.attr(name, value) }

    fun prop(handle: Int, name: String): String? {
        val el = asElement(handle) ?: return null
        return when (name.lowercase()) {
            "tagname" -> el.tagName().uppercase()
            "outerhtml" -> el.outerHtml()
            "innerhtml" -> el.html()
            "href", "src" -> el.absUrl(name).ifEmpty { if (el.hasAttr(name)) el.attr(name) else null }
            else -> if (el.hasAttr(name)) el.attr(name) else null
        }
    }

    fun data(handle: Int, key: String): String? = attr(handle, "data-$key")

    fun value(handle: Int): String = asElement(handle)?.`val`() ?: ""

    fun hasClass(handle: Int, cls: String): Boolean = asElement(handle)?.hasClass(cls) ?: false
    fun addClass(handle: Int, cls: String) { asElement(handle)?.addClass(cls) }
    fun removeClass(handle: Int, cls: String) { asElement(handle)?.removeClass(cls) }
    fun className(handle: Int): String = asElement(handle)?.className() ?: ""

    fun remove(handle: Int) { get(handle)?.remove() }

    fun parent(handle: Int): Int { val p = get(handle)?.parent() ?: return -1; return put(p) }

    fun parents(handle: Int): String {
        val el = asElement(handle) ?: return "[]"
        return toHandleArray(el.parents().toList())
    }

    fun closest(handle: Int, css: String): Int {
        var cur: Element? = asElement(handle)
        while (cur != null) { if (cur.`is`(css)) return put(cur); cur = cur.parent() }
        return -1
    }

    fun next(handle: Int): Int { val n = asElement(handle)?.nextElementSibling() ?: return -1; return put(n) }
    fun prev(handle: Int): Int { val n = asElement(handle)?.previousElementSibling() ?: return -1; return put(n) }

    fun nextAll(handle: Int): String {
        val el = asElement(handle) ?: return "[]"
        val list = ArrayList<Node>()
        var cur = el.nextElementSibling()
        while (cur != null) { list.add(cur); cur = cur.nextElementSibling() }
        return toHandleArray(list)
    }

    fun prevAll(handle: Int): String {
        val el = asElement(handle) ?: return "[]"
        val list = ArrayList<Node>()
        var cur = el.previousElementSibling()
        while (cur != null) { list.add(cur); cur = cur.previousElementSibling() }
        return toHandleArray(list)
    }

    fun siblings(handle: Int): String {
        val el = asElement(handle) ?: return "[]"
        val parent = el.parent() ?: return "[]"
        return toHandleArray(parent.children().filter { it !== el })
    }

    fun isMatch(handle: Int, css: String): Boolean = asElement(handle)?.let { matchesSelector(it, css) } ?: false

    fun replaceWith(handle: Int, html: String) { val el = asElement(handle) ?: return; el.before(html); el.remove() }
    fun before(handle: Int, html: String) { asElement(handle)?.before(html) }
    fun after(handle: Int, html: String) { asElement(handle)?.after(html) }
    fun append(handle: Int, html: String) { asElement(handle)?.append(html) }
    fun prepend(handle: Int, html: String) { asElement(handle)?.prepend(html) }
    fun empty(handle: Int) { asElement(handle)?.empty() }

    fun css(handle: Int, prop: String): String {
        val style = asElement(handle)?.attr("style") ?: return ""
        for (part in style.split(";")) {
            val kv = part.split(":", limit = 2)
            if (kv.size == 2 && kv[0].trim().equals(prop, ignoreCase = true)) return kv[1].trim()
        }
        return ""
    }

    fun count(handle: Int): Int = asElement(handle)?.children()?.size ?: 0

    // Do NOT reset counter. Two entry points (e.g. the reader and the TTS
    // background prefetch) can share one plugin context and interleave calls.
    // Resetting the counter lets a disposed call's stale handle numbers get
    // silently reissued to a different call's new nodes, returning wrong data.
    // Leaving the counter monotonic means a stale handle simply misses (get()
    // returns null) instead of aliasing something else.
    fun disposeAll() { handles.clear() }
}
