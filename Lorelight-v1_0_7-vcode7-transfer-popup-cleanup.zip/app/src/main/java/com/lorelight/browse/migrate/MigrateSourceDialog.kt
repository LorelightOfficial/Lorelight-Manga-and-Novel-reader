package com.lorelight.browse.migrate

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.lorelight.data.model.Novel
import com.lorelight.ui.components.LorelightDialog
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job

/**
 * Searches every installed alternative source for the current novel at once.
 * Results remain grouped by source and are never auto-selected: the user
 * explicitly chooses the matching entry before migration is applied.
 */
@Composable
fun MigrateSourceDialog(
    novels: List<Novel>,
    onDismiss: () -> Unit,
    onApplied: (List<Novel>) -> Unit
) {
    if (novels.isEmpty()) {
        LorelightDialog(
            onDismissRequest = onDismiss,
            title = "Transfer source",
            text = "Select at least one novel first.",
            icon = Icons.Filled.SwapHoriz,
            confirmText = "OK",
            onConfirm = onDismiss
        )
        return
    }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var index by remember { mutableStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var transferring by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var searchedTitle by remember { mutableStateOf("") }
    val groupedCandidates = remember { mutableStateMapOf<String, List<MigrationCandidate>>() }
    val sourceNames = remember { mutableStateMapOf<String, String>() }
    val sourceErrors = remember { mutableStateMapOf<String, String>() }
    val pendingSources = remember { mutableStateListOf<String>() }
    var searchGeneration by remember { mutableStateOf(0) }
    var searchJob by remember { mutableStateOf<Job?>(null) }
    var transferJob by remember { mutableStateOf<Job?>(null) }
    val latestSearchJob by rememberUpdatedState(searchJob)
    val latestTransferJob by rememberUpdatedState(transferJob)
    val results = remember { mutableStateListOf<MigrationResult>() }
    val skipped = remember { mutableStateListOf<String>() }

    val current = novels.getOrNull(index)
    val currentPluginId = current?.pluginId
    val targets = remember(currentPluginId) {
        NovelSourceMigrator.installedTargets(context, currentPluginId)
    }

    DisposableEffect(Unit) {
        onDispose {
            // Read the latest jobs rather than the null values captured when
            // this one-shot effect was first installed.
            latestSearchJob?.cancel()
            latestTransferJob?.cancel()
        }
    }

    fun runSearch(term: String) {
        val novel = current ?: return
        val title = term.trim().ifBlank { novel.title }
        query = title
        searchedTitle = title
        searchJob?.cancel()
        val generation = searchGeneration + 1
        searchGeneration = generation
        loading = targets.isNotEmpty()
        error = null
        groupedCandidates.clear()
        sourceNames.clear()
        sourceErrors.clear()
        pendingSources.clear()
        pendingSources.addAll(targets.map { it.info.id })

        if (targets.isEmpty()) {
            loading = false
            return
        }

        searchJob = scope.launch {
            // Mirror GlobalSearchScreen: every installed source gets its own
            // result row and completes independently. A per-source deadline
            // prevents one stalled plugin from holding the dialog forever.
            targets.forEach { target ->
                launch {
                    val id = target.info.id
                    val name = target.info.name
                    var found: List<MigrationCandidate> = emptyList()
                    var failure: String? = null
                    try {
                        val outcome = withTimeoutOrNull(120_000L) {
                            NovelSourceMigrator.searchCandidates(
                                context.applicationContext, id, name, title
                            )
                        }
                        if (outcome == null) failure = "Timed out after 120 seconds"
                        else found = outcome
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        failure = e.message?.take(180) ?: "Search failed"
                    }

                    // Ignore stale completions after the user changes the title
                    // or advances to another novel.
                    if (searchGeneration == generation) {
                        sourceNames[id] = name
                        groupedCandidates[id] = found
                        if (failure != null) sourceErrors[id] = failure!!
                        pendingSources.remove(id)
                        loading = pendingSources.isNotEmpty()
                        if (!loading && groupedCandidates.values.sumOf { it.size } == 0) {
                            error = "No matches found. Try a shorter or alternate title. Sources that timed out or failed are listed below."
                        }
                    }
                }
            }
        }
    }

    fun advance() {
        searchJob?.cancel()
        searchGeneration += 1
        loading = false
        transferring = false
        pendingSources.clear()
        groupedCandidates.clear()
        sourceErrors.clear()
        error = null
        if (index + 1 < novels.size) {
            index += 1
        } else {
            onApplied(results.map { it.novel })
        }
    }

    fun transfer(candidate: MigrationCandidate) {
        val novel = current ?: return
        transferring = true
        error = null
        transferJob?.cancel()
        transferJob = scope.launch {
            try {
                val migrated = NovelSourceMigrator.migrate(context, novel, candidate)
                results.add(migrated)
                transferring = false
                advance()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                transferring = false
                error = e.message ?: "Transfer failed. The original novel was not changed."
            }
        }
    }

    LaunchedEffect(index, current?.title, targets) {
        val novel = current ?: return@LaunchedEffect
        query = novel.title
        runSearch(novel.title)
    }

    val divider = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f)

    LorelightDialog(
        // Do not allow the dialog to leave while its transfer is committing.
        // If the user closes after one or more novels have already migrated,
        // commit that completed subset instead of discarding the results after
        // their chapter-state keys have been remapped.
        onDismissRequest = {
            if (!transferring) {
                val completed = results.map { it.novel }
                if (completed.isEmpty()) onDismiss() else onApplied(completed)
            }
        },
        title = "Transfer to another source",
        text = "${index + 1} of ${novels.size}: ${current?.title.orEmpty()}",
        icon = Icons.Filled.SwapHoriz,
        dismissButton = {
            TextButton(
                enabled = !transferring,
                onClick = {
                    current?.let { skipped.add(it.title) }
                    advance()
                }
            ) {
                Text("Skip", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        content = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Search title") }
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        enabled = !loading && !transferring,
                        onClick = { runSearch(query) }
                    ) {
                        Text("Search all sources", fontSize = 12.sp)
                    }
                }

                if (transferring) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Text("  Transferring selected novel…", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                if (loading) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(17.dp), strokeWidth = 2.dp)
                        Text(
                            "  Searching ${pendingSources.size} of ${targets.size} sources…",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else if (targets.isEmpty()) {
                    Text(
                        "No other novel sources are installed. Add a source from Browse first.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 10.dp)
                    )
                }

                error?.let {
                    Text(
                        it,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 360.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Promote completed sources to the top immediately. This
                    // makes incremental results obvious even when an early
                    // source in the installed list is slow to respond.
                    targets.sortedBy { it.info.id in pendingSources }.forEach { target ->
                        val sourceId = target.info.id
                        val sourceName = sourceNames[sourceId] ?: target.info.name
                        val candidates = groupedCandidates[sourceId].orEmpty()
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                sourceName,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f)
                            )
                            if (sourceId in pendingSources) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    strokeWidth = 1.8.dp
                                )
                            }
                        }
                        // Keep the source list quiet: successful empty searches
                        // need no extra copy, while genuine failures remain visible.
                        sourceErrors[sourceId]?.let { sourceError ->
                            Text(
                                "Search failed: $sourceError",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier.padding(bottom = 5.dp)
                            )
                        }
                        if (candidates.isNotEmpty()) {
                            // Each source owns a horizontal result shelf. Covers
                            // are deliberately larger, with the title underneath,
                            // matching the source site's book-card presentation.
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                                    .padding(bottom = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                candidates.forEach { candidate ->
                                    Column(
                                        modifier = Modifier
                                            .width(112.dp)
                                            .clickable(enabled = !transferring) { transfer(candidate) }
                                            .padding(vertical = 6.dp, horizontal = 2.dp),
                                        horizontalAlignment = Alignment.Start
                                    ) {
                                        AsyncImage(
                                            model = candidate.cover,
                                            contentDescription = candidate.name,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .size(width = 104.dp, height = 146.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                        )
                                        Spacer(Modifier.height(7.dp))
                                        Text(
                                            candidate.name,
                                            fontSize = 12.sp,
                                            lineHeight = 16.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 3
                                        )
                                    }
                                }
                            }
                            Box(
                                modifier = Modifier.fillMaxWidth().height(0.7.dp).background(divider)
                            )
                        }
                    }

                    }
                if (results.isNotEmpty() || skipped.isNotEmpty()) {
                    Text(
                        "${results.size} transferred · ${skipped.size} skipped",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }
    )
}
