package com.lorelight.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.Constraints
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Best-effort deletion of one expired Lorelight filter share. */
class FilterShareCleanupWorker(
    appContext: Context,
    params: WorkerParameters,
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val shareId = inputData.getString(KEY_SHARE_ID)
            ?: return Result.failure()
        return try {
            com.lorelight.utils.TextFilterRelay.cleanupShareIfExpired(shareId)
            Result.success()
        } catch (_: Exception) {
            if (runAttemptCount < 5) Result.retry() else Result.failure()
        }
    }

    companion object {
        const val KEY_SHARE_ID = "share_id"
    }
}

object FilterShareCleanupScheduler {
    fun schedule(context: Context, shareId: String, expiresAtMillis: Long) {
        val delay = (expiresAtMillis - System.currentTimeMillis()).coerceAtLeast(0L)
        val request = OneTimeWorkRequestBuilder<FilterShareCleanupWorker>()
            .setInputData(Data.Builder().putString(FilterShareCleanupWorker.KEY_SHARE_ID, shareId).build())
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setConstraints(
                Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build(),
            )
            .addTag("lorelight_filter_share_cleanup")
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            "lorelight_filter_share_cleanup_$shareId",
            ExistingWorkPolicy.REPLACE,
            request,
        )
    }
}
