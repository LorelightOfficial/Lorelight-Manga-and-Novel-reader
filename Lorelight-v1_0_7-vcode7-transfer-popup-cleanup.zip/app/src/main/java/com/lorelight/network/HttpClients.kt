package com.lorelight.network

import android.content.Context
import okhttp3.ConnectionPool
import okhttp3.Dispatcher
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

object HttpClients {

    private const val CONNECT_TIMEOUT_S = 30L
    private const val READ_TIMEOUT_S = 30L
    private const val CALL_TIMEOUT_S = 120L

    val sharedDispatcher: Dispatcher = Dispatcher().apply {
        maxRequests = 64
        maxRequestsPerHost = 8
    }

    val sharedConnectionPool: ConnectionPool = ConnectionPool(12, 5, TimeUnit.MINUTES)

    @Volatile private var appContext: Context? = null
    @Volatile private var cached: OkHttpClient? = null
    @Volatile private var cachedIsCloudflareAware: Boolean = false

    fun init(context: Context) {
        appContext = context.applicationContext
        NetworkThrottle.init(context)
        synchronized(this) {
            if (cached != null && !cachedIsCloudflareAware) {
                cached = null
            }
        }
    }

    fun isCloudflareAware(): Boolean = cachedIsCloudflareAware

    fun shared(): OkHttpClient {
        cached?.let { return it }
        return synchronized(this) {
            cached ?: build().also { cached = it }
        }
    }

    fun sharedBuilder(): OkHttpClient.Builder = shared().newBuilder()

    private fun build(): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .dispatcher(sharedDispatcher)
            .connectionPool(sharedConnectionPool)
            .followRedirects(true)
            .retryOnConnectionFailure(true)
            .connectTimeout(CONNECT_TIMEOUT_S, TimeUnit.SECONDS)
            .readTimeout(READ_TIMEOUT_S, TimeUnit.SECONDS)
            .callTimeout(CALL_TIMEOUT_S, TimeUnit.SECONDS)
            .addNetworkInterceptor(NetworkThrottle.createNetworkInterceptor())

        val ctx = appContext
        cachedIsCloudflareAware = if (ctx != null) {
            try {
                builder.addInterceptor(CloudflareInterceptor(ctx))
                true
            } catch (e: Throwable) {
                false
            }
        } else {
            false
        }

        return builder.build()
    }
}
