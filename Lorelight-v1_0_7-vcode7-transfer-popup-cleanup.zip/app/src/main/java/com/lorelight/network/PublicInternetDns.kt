package com.lorelight.network

import okhttp3.Dns
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress

/**
 * DNS guard used only by untrusted plugin-originated HTTP requests.
 * It resolves at connection time (including redirects), then rejects the
 * entire answer set if any address is loopback, private, link-local, shared,
 * multicast, or otherwise reserved. This prevents DNS names from bypassing
 * the URL-string checks and reduces DNS-rebinding exposure.
 */
object PublicInternetDns : Dns {
    override fun lookup(hostname: String): List<InetAddress> {
        val normalized = hostname.trim().trimEnd('.').lowercase()
        require(normalized.isNotEmpty()) { "Empty host name" }
        require(
            normalized != "localhost" &&
                !normalized.endsWith(".localhost") &&
                !normalized.endsWith(".local") &&
                !normalized.endsWith(".internal") &&
                !normalized.endsWith(".test")
        ) { "Plugin requests to local host names are blocked" }

        val addresses = Dns.SYSTEM.lookup(hostname)
        require(addresses.isNotEmpty()) { "Host did not resolve to an address" }
        val blocked = addresses.firstOrNull(::isNonPublicAddress)
        require(blocked == null) {
            "Plugin request blocked because $hostname resolves to a non-public address"
        }
        return addresses
    }

    private fun isNonPublicAddress(address: InetAddress): Boolean {
        if (address.isAnyLocalAddress || address.isLoopbackAddress ||
            address.isLinkLocalAddress || address.isSiteLocalAddress || address.isMulticastAddress
        ) return true

        val bytes = address.address.map { it.toInt() and 0xff }
        return when (address) {
            is Inet4Address -> isReservedIpv4(bytes)
            is Inet6Address -> isReservedIpv6(bytes)
            else -> true
        }
    }

    private fun isReservedIpv4(b: List<Int>): Boolean {
        if (b.size != 4) return true
        val a = b[0]; val c = b[1]; val d = b[2]
        return when {
            a == 0 || a == 10 || a == 127 || a >= 224 -> true
            a == 100 && c in 64..127 -> true // shared carrier-grade NAT space
            a == 169 && c == 254 -> true
            a == 172 && c in 16..31 -> true
            a == 192 && c == 168 -> true
            a == 192 && c == 0 && d == 0 -> true
            a == 192 && c == 0 && d in 0..2 -> true // IETF protocol assignments and TEST-NET-1
            a == 192 && c == 88 && d == 99 -> true // deprecated 6to4 relay anycast
            a == 198 && (c == 18 || c == 19) -> true // benchmark networks
            a == 198 && c == 51 && d == 100 -> true // TEST-NET-2
            a == 203 && c == 0 && d == 113 -> true // TEST-NET-3
            else -> false
        }
    }

    private fun isReservedIpv6(b: List<Int>): Boolean {
        if (b.size != 16) return true
        // IPv4-mapped IPv6 addresses must be checked using their embedded IPv4.
        val mapped = b.take(10).all { it == 0 } && b[10] == 255 && b[11] == 255
        if (mapped) return isReservedIpv4(b.takeLast(4))
        // Only 2000::/3 is global unicast. Reject all other special-purpose
        // ranges, plus documentation and benchmark blocks inside that space.
        if ((b[0] and 0xe0) != 0x20) return true
        val is2001Special = b[0] == 0x20 && b[1] == 0x01 &&
            (b[2] == 0x00 || b[2] == 0x02 || b[2] == 0x10 || b[2] == 0x0d)
        return is2001Special || (b[0] and 0xfe) == 0xfc ||
            (b[0] == 0xfe && (b[1] and 0xc0) == 0x80) ||
            (b[0] == 0xfe && (b[1] and 0xc0) == 0xc0) ||
            b[0] == 0xff ||
            (b[0] == 0x20 && b[1] == 0x01 && b[2] == 0x0d && b[3] == 0xb8)
    }
}
