package com.lorelight.companion

import com.lorelight.ui.theme.modeswitch.celestial.CelestialFaceState
import kotlinx.coroutines.delay

/*
 * Talking is intentionally NOT part of this build.
 *
 * The v23 talk engine drove the mouth frame by frame through pinnedSnapshot
 * while a line was on screen. It was removed on request: the speech bubble
 * still appears and still reveals its words, but the face is left alone and
 * keeps running its own idle life underneath.
 *
 * The cadence constants stay because the word-by-word reveal reads them, and
 * playTalk stays with its original signature so CompanionHost needs no
 * changes -- it now simply holds the line for its natural duration.
 */

const val TALK_CADENCE_SUN_MS = 280L
const val TALK_CADENCE_MOON_MS = 420L

@Suppress("UNUSED_PARAMETER")
suspend fun CelestialFaceState.playTalk(
    mood: Mood,
    speakMs: Long,
    reduceMotion: Boolean = false
) {
    // No mouth performance, no pinning: just let the bubble live out its life.
    delay(speakMs.coerceAtLeast(0L))
}
