package com.lorelight.webstorage

import android.content.Context
import android.net.Uri
import android.util.Log
import org.json.JSONObject
import org.json.JSONTokener
import java.security.MessageDigest

/**
 * Captures the read-only Web Storage snapshots exposed to LNReader-style source
 * plugins. Snapshots are keyed by exact web origin, never by an arbitrary URL
 * supplied by JavaScript. localStorage is retained; sessionStorage expires
 * after 30 minutes because its originating WebView session may have ended.
 */
object WebStorageSnapshotStore {
    private const val TAG = "WebStorageSnapshot"
    private const val SESSION_TTL_MS = 30L * 60L * 1000L
    private const val MAX_SNAPSHOT_CHARS = 512 * 1024
    private const val MAX_KEYS = 2048

    const val CAPTURE_SCRIPT = """
        (function(){
          function dump(store){
            var out={};
            try { for(var i=0;i<store.length && i<2048;i++){ var k=store.key(i); if(k!==null) out[k]=store.getItem(k); } }
            catch(e) {}
            return out;
          }
          var payload={origin:location.origin,local:{},session:{}};
          try { payload.local=dump(window.localStorage); } catch(e) {}
          try { payload.session=dump(window.sessionStorage); } catch(e) {}
          return JSON.stringify(payload);
        })();
    """.trimIndent()

    fun captureJavascriptResult(context: Context, rawResult: String?) {
        if (rawResult.isNullOrBlank() || rawResult == "null") return
        try {
            val decoded = try { JSONTokener(rawResult).nextValue() } catch (_: Exception) { rawResult }
            val jsonText = decoded as? String ?: decoded.toString()
            val payload = JSONObject(jsonText)
            val origin = normalizeOrigin(payload.optString("origin", "")) ?: return
            val local = sanitizeSnapshot(payload.optJSONObject("local"))
            val session = sanitizeSnapshot(payload.optJSONObject("session"))
            val prefs = prefs(context, origin)
            val ok = prefs.edit()
                .putString("local", local.toString())
                .putString("session", session.toString())
                .putLong("session_at", System.currentTimeMillis())
                .commit()
            if (!ok) Log.w(TAG, "Could not persist Web Storage snapshot for $origin")
        } catch (e: Exception) {
            Log.d(TAG, "Ignored invalid Web Storage snapshot: ${e.message}")
        }
    }

    fun clear(context: Context, origin: String?) {
        val safeOrigin = normalizeOrigin(origin ?: "") ?: return
        prefs(context, safeOrigin).edit().clear().commit()
    }

    fun read(context: Context, origin: String?, kind: String): String {
        val safeOrigin = normalizeOrigin(origin ?: "") ?: return "{}"
        val prefs = prefs(context, safeOrigin)
        val key = when (kind) {
            "localStorage" -> "local"
            "sessionStorage" -> "session"
            else -> return "{}"
        }
        if (key == "session" && System.currentTimeMillis() - prefs.getLong("session_at", 0L) > SESSION_TTL_MS) {
            prefs.edit().remove("session").remove("session_at").apply()
            return "{}"
        }
        return prefs.getString(key, "{}") ?: "{}"
    }

    fun normalizeOrigin(raw: String): String? = try {
        val uri = Uri.parse(raw.trim())
        val scheme = uri.scheme?.lowercase() ?: return null
        val host = uri.host?.lowercase()?.trimEnd('.') ?: return null
        if ((scheme != "http" && scheme != "https") || host.isBlank() || uri.userInfo != null) return null
        val port = if (uri.port >= 0 && !((scheme == "https" && uri.port == 443) || (scheme == "http" && uri.port == 80))) ":${uri.port}" else ""
        "$scheme://$host$port"
    } catch (_: Exception) { null }

    private fun sanitizeSnapshot(input: JSONObject?): JSONObject {
        val out = JSONObject()
        if (input == null) return out
        val keys = input.keys()
        var count = 0
        while (keys.hasNext() && count < MAX_KEYS) {
            val key = keys.next()
            val value = input.opt(key)
            if (key.length <= 2048 && value is String && value.length <= 64 * 1024) {
                out.put(key, value)
                count++
            }
            if (out.toString().length > MAX_SNAPSHOT_CHARS) {
                out.remove(key)
                break
            }
        }
        return out
    }

    private fun prefs(context: Context, origin: String) =
        context.applicationContext.getSharedPreferences("lorelight_webstorage_${sha256(origin)}", Context.MODE_PRIVATE)

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .take(16)
        .joinToString("") { "%02x".format(it) }
}
