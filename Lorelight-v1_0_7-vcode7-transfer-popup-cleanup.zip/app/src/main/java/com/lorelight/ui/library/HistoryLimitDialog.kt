package com.lorelight.ui.library

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.data.local.NovelPreferences
import com.lorelight.ui.components.LorelightDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val HISTORY_LIMIT_PRESETS = listOf(50, 100, 200, 500, 1000, 0) // 0 = no limit
private const val MIN_CUSTOM_LIMIT = 10
private const val MAX_CUSTOM_LIMIT = 100_000

/**
 * Lets the user choose how many titles History keeps. A lower limit means a lighter
 * app (every entry holds a copy of its novel's data) and a smaller backup. If the new
 * limit is below what is stored, the dialog says how many of the oldest entries will
 * be removed before the user confirms.
 */
@Composable
fun HistoryLimitDialog(
    onDismiss: () -> Unit,
    onApplied: () -> Unit
) {
    val context = LocalContext.current
    val current = remember { NovelPreferences.getHistoryLimit(context) }

    var selected by remember { mutableStateOf(current) }
    var custom by remember {
        mutableStateOf(if (current == 0 || current in HISTORY_LIMIT_PRESETS) "" else current.toString())
    }
    var storedCount by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(Unit) {
        storedCount = withContext(Dispatchers.IO) { NovelPreferences.historyCount(context) }
    }

    val customValue = custom.toIntOrNull()
    val effective: Int = if (custom.isNotBlank()) (customValue ?: -1) else selected
    val valid = effective == 0 || effective in MIN_CUSTOM_LIMIT..MAX_CUSTOM_LIMIT
    val removing = storedCount?.let { count ->
        if (valid && effective > 0 && count > effective) count - effective else 0
    } ?: 0

    LorelightDialog(
        onDismissRequest = onDismiss,
        title = { Text("History limit") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "How many titles should History remember? When it's full, the oldest are dropped. " +
                        "A lower limit makes the app lighter and backups smaller.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                storedCount?.let {
                    Text(
                        text = "Right now: $it stored \u00b7 limit " + (if (current == 0) "none" else current.toString()),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }

                HISTORY_LIMIT_PRESETS.chunked(3).forEach { rowItems ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowItems.forEach { preset ->
                            val isSelected = custom.isBlank() && selected == preset
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(
                                        if (isSelected) MaterialTheme.colorScheme.primaryContainer
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                                    )
                                    .clickable(role = Role.RadioButton) {
                                        selected = preset
                                        custom = ""
                                    }
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (preset == 0) "No limit" else preset.toString(),
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer
                                    else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = custom,
                    onValueChange = { custom = it.filter(Char::isDigit).take(6) },
                    label = { Text("Or type your own ($MIN_CUSTOM_LIMIT\u2013$MAX_CUSTOM_LIMIT)") },
                    singleLine = true,
                    isError = custom.isNotBlank() && !valid,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                if (removing > 0) {
                    Text(
                        text = "This will remove the $removing oldest entr${if (removing == 1) "y" else "ies"} from History. " +
                            "Your library and reading progress are not affected.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
            }
        },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = {
                    NovelPreferences.setHistoryLimit(context, effective)
                    onApplied()
                    onDismiss()
                }
            ) {
                Text(if (removing > 0) "Apply & remove $removing" else "Apply")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
