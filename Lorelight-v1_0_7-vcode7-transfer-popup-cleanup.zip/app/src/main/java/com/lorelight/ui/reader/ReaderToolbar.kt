package com.lorelight.ui.reader

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.graphics.Paint as NativePaint
import android.graphics.Typeface as NativeTypeface
import com.lorelight.data.model.Novel
import com.lorelight.ui.theme.GlassDropdownMenu

@Composable
fun ReaderToolbar(
    activeNovel: Novel?,
    chapters: List<String>,
    activeChapterIndex: Int,
    readerMode: String,
    sleepTimerMinutes: Int?,
    sleepTimerRemainingSeconds: Int?,
    isAutoScrollActive: Boolean,
    readerHighlightColor: Color,
    onClose: () -> Unit,
    onSetSleepTimer: (Int?) -> Unit,
    onToggleChapters: () -> Unit,
    onToggleAutoScroll: () -> Unit,
    onOpenSettings: () -> Unit,
    aiIsProcessing: Boolean = false,
    visible: Boolean = true,
    modifier: Modifier = Modifier
) {
    // Novel Reader has one compact, solid AMOLED toolbar. Split panels and
    // their setting are intentionally exclusive to Manga Reader.
    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically(initialOffsetY = { -it }, animationSpec = tween(230)) + fadeIn(tween(180)),
        exit = slideOutVertically(targetOffsetY = { -it }, animationSpec = tween(210)) + fadeOut(tween(160)),
        modifier = modifier.fillMaxWidth()
    ) {
        Box(modifier = Modifier.fillMaxWidth().background(Color.Black)) {
            Row(
                modifier = Modifier.fillMaxWidth()
                    .statusBarsPadding()
                    .padding(start = 8.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onClose, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Close reader", tint = Color.White, modifier = Modifier.size(20.dp))
                }
                val activeChapterName = chapters.getOrNull(activeChapterIndex)
                    ?: (activeNovel?.title ?: "Reading")
                val sourceChapterNumber = activeNovel?.chapterNumbers
                    ?.getOrNull(activeChapterIndex)
                    ?.takeIf { it.isFinite() && it >= 0f }
                val chapterNumber = sourceChapterNumber ?: (activeChapterIndex.coerceAtLeast(0) + 1).toFloat()
                val chapterNumberLabel = if (chapterNumber % 1f == 0f) {
                    chapterNumber.toInt().toString()
                } else {
                    chapterNumber.toString()
                }
                Column(
                    modifier = Modifier.weight(1f).padding(start = 8.dp, end = 8.dp),
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "CHAPTER $chapterNumberLabel",
                        color = Color.White.copy(alpha = 0.68f),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    Text(
                        text = activeChapterName,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                }
                ReaderToolbarActions(
                    readerMode, sleepTimerRemainingSeconds, isAutoScrollActive,
                    readerHighlightColor, Color.White, aiIsProcessing, onSetSleepTimer,
                    onToggleChapters, onToggleAutoScroll, onOpenSettings,
                    modifier = Modifier,
                    compact = true
                )
            }
        }
    }
}

@Composable
private fun ReaderToolbarActions(
    readerMode: String,
    sleepTimerRemainingSeconds: Int?,
    isAutoScrollActive: Boolean,
    readerHighlightColor: Color,
    ink: Color,
    aiIsProcessing: Boolean,
    onSetSleepTimer: (Int?) -> Unit,
    onToggleChapters: () -> Unit,
    onToggleAutoScroll: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    val controlSize = if (compact) 36.dp else 40.dp
    var showSleepTimerMenu by remember { mutableStateOf(false) }
    var selectedTimerHours by remember { mutableIntStateOf(0) }
    var selectedTimerMinutePart by remember { mutableIntStateOf(30) }

    Row(
        modifier = modifier.height(if (compact) 36.dp else 46.dp).padding(horizontal = if (compact) 0.dp else 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        IconButton(onClick = onToggleChapters, modifier = Modifier.size(controlSize)) {
            Icon(Icons.Default.MenuBook, "Contents", tint = ink, modifier = Modifier.size(20.dp))
        }
        if (readerMode == "Read") {
            IconButton(onClick = onToggleAutoScroll, modifier = Modifier.size(controlSize)) {
                Icon(Icons.Default.KeyboardArrowDown, "Autoscroll panel", tint = if (isAutoScrollActive) readerHighlightColor else ink, modifier = Modifier.size(21.dp))
            }
        } else {
            Box {
                IconButton(
                    onClick = {
                        if (sleepTimerRemainingSeconds == null) {
                            selectedTimerHours = 0
                            selectedTimerMinutePart = 30
                        }
                        showSleepTimerMenu = true
                    },
                    modifier = Modifier.size(controlSize)
                ) {
                    if (sleepTimerRemainingSeconds != null) {
                        val totalMinutes = (sleepTimerRemainingSeconds + 59) / 60
                        Text("%02d:%02d".format(totalMinutes / 60, totalMinutes % 60), color = readerHighlightColor, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    } else {
                        Icon(Icons.Default.AccessTime, "Sleep timer", tint = ink, modifier = Modifier.size(20.dp))
                    }
                }
                GlassDropdownMenu(expanded = showSleepTimerMenu, onDismissRequest = { showSleepTimerMenu = false }, modifier = Modifier.width(268.dp)) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                            Icon(Icons.Default.AccessTime, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
                            Spacer(Modifier.width(7.dp))
                            Text("Sleep timer", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        }
                        Spacer(Modifier.height(10.dp))
                        if (sleepTimerRemainingSeconds != null) {
                            val remaining = sleepTimerRemainingSeconds.coerceAtLeast(0)
                            Text("%02d:%02d:%02d".format(remaining / 3600, (remaining % 3600) / 60, remaining % 60), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, letterSpacing = 1.sp)
                            Spacer(Modifier.height(8.dp))
                            Button(onClick = { onSetSleepTimer(null); showSleepTimerMenu = false }, modifier = Modifier.fillMaxWidth().height(40.dp), contentPadding = PaddingValues(vertical = 4.dp)) { Text("Stop timer", style = MaterialTheme.typography.labelLarge) }
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Hours", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                                    TimerWheelColumn(selectedTimerHours, 12, MaterialTheme.colorScheme.onSurface) { selectedTimerHours = it }
                                }
                                Text(":", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 2.dp))
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("Minutes", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                                    TimerWheelColumn(selectedTimerMinutePart, 59, MaterialTheme.colorScheme.onSurface) { selectedTimerMinutePart = it }
                                }
                            }
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                TextButton(onClick = { onSetSleepTimer(null); showSleepTimerMenu = false }, modifier = Modifier.weight(1f).height(40.dp), contentPadding = PaddingValues(horizontal = 4.dp)) { Text("Off", style = MaterialTheme.typography.labelLarge) }
                                Button(
                                    onClick = {
                                        val totalMinutes = selectedTimerHours * 60 + selectedTimerMinutePart
                                        onSetSleepTimer(totalMinutes.takeIf { it > 0 })
                                        showSleepTimerMenu = false
                                    },
                                    modifier = Modifier.weight(1.5f).height(40.dp),
                                    contentPadding = PaddingValues(horizontal = 4.dp)
                                ) { Text("Start", style = MaterialTheme.typography.labelLarge) }
                            }
                        }
                    }
                }
            }
        }
        Box {
            IconButton(onClick = onOpenSettings, modifier = Modifier.size(controlSize)) {
                Icon(Icons.Default.Settings, "Settings", tint = ink, modifier = Modifier.size(20.dp))
            }
            if (aiIsProcessing) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.TopEnd).size(10.dp), color = readerHighlightColor, strokeWidth = 1.5.dp)
            }
        }
    }
}

@Composable
private fun TimerWheelColumn(
    value: Int,
    maxValue: Int,
    textColor: Color,
    onValueChange: (Int) -> Unit
) {
    val density = androidx.compose.ui.platform.LocalDensity.current
    val rowHeight = with(density) { 34.dp.toPx() }
    var dragRemainder by remember(maxValue) { mutableFloatStateOf(0f) }
    val currentValue by rememberUpdatedState(value)
    val updateValue by rememberUpdatedState(onValueChange)
    val selectedColor = MaterialTheme.colorScheme.primaryContainer

    Canvas(
        modifier = Modifier
            .width(104.dp)
            .height(132.dp)
            .pointerInput(maxValue, rowHeight) {
                detectVerticalDragGestures(
                    onVerticalDrag = { change, dragAmount ->
                        change.consume()
                        dragRemainder += dragAmount
                        var nextValue = currentValue
                        while (dragRemainder <= -rowHeight) {
                            nextValue = if (nextValue >= maxValue) 0 else nextValue + 1
                            dragRemainder += rowHeight
                        }
                        while (dragRemainder >= rowHeight) {
                            nextValue = if (nextValue <= 0) maxValue else nextValue - 1
                            dragRemainder -= rowHeight
                        }
                        if (nextValue != currentValue) updateValue(nextValue)
                    },
                    onDragEnd = { dragRemainder = 0f },
                    onDragCancel = { dragRemainder = 0f }
                )
            }
            .pointerInput(maxValue) {
                detectTapGestures { position ->
                    val next = if (position.y < size.height / 2f) currentValue - 1 else currentValue + 1
                    onValueChange(if (next < 0) maxValue else if (next > maxValue) 0 else next)
                }
            }
    ) {
        val centerY = size.height / 2f
        val centerX = size.width / 2f
        drawRoundRect(
            color = selectedColor.copy(alpha = 0.62f),
            topLeft = androidx.compose.ui.geometry.Offset(4.dp.toPx(), centerY - rowHeight / 2f),
            size = androidx.compose.ui.geometry.Size(size.width - 8.dp.toPx(), rowHeight),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(12.dp.toPx())
        )
        drawIntoCanvas { canvas ->
            val native = canvas.nativeCanvas
            val paint = NativePaint(NativePaint.ANTI_ALIAS_FLAG).apply {
                textAlign = NativePaint.Align.CENTER
                color = textColor.toArgb()
            }
            for (offset in -2..2) {
                val raw = value + offset
                val shown = if (maxValue > 0) ((raw % (maxValue + 1)) + (maxValue + 1)) % (maxValue + 1) else 0
                val distance = kotlin.math.abs(offset)
                paint.textSize = when (distance) { 0 -> 25.sp.toPx(); 1 -> 17.sp.toPx(); else -> 14.sp.toPx() }
                paint.typeface = if (distance == 0) NativeTypeface.create("sans-serif", NativeTypeface.BOLD)
                    else NativeTypeface.create("sans-serif-medium", NativeTypeface.NORMAL)
                paint.alpha = when (distance) { 0 -> 255; 1 -> 145; else -> 72 }
                val baseline = centerY + offset * rowHeight - (paint.ascent() + paint.descent()) / 2f
                native.drawText("%02d".format(shown), centerX, baseline, paint)
            }
        }
    }
}
