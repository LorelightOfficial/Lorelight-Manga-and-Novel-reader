package com.lorelight.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import com.lorelight.data.local.CoverStorage
import com.lorelight.data.model.Novel
import com.lorelight.data.model.isManga
import com.lorelight.data.model.mangaSourceId
import com.lorelight.manga.ui.MangaCoverImage

/**
 * The one cover renderer every library surface should use.
 *
 * ## Why this exists
 *
 * Library cards used to call [NovelCoverImage] directly with
 * `novel.coverImageBase64`, while the details page picked between three
 * different loaders depending on what the cover actually was. That difference
 * is what made adult manga covers show up blank in the library but load fine
 * the moment you opened the same title's details page.
 *
 * A manga cover URL is not an ordinary image URL. Many manga hosts -- adult
 * ones almost always -- reject a bare GET and only serve the image when the
 * request carries the source's own `Referer`, user agent and Cloudflare
 * cookies. [NovelCoverImage] uses the plain app-wide Coil loader, which has
 * none of those, so the host answered 403 and the card fell back to the empty
 * book placeholder. [MangaCoverImage] goes through
 * `MangaImageLoaderProvider.getCoverImageLoader`, which routes the request
 * through the source's own HTTP client, which is why details worked.
 *
 * The same 403 also silently defeats `CoverStorage.downloadAndSaveCover` when
 * the title is first added, so there is no local file to fall back on either.
 * That is why the card stayed blank permanently instead of self-healing.
 *
 * ## Order of preference
 *
 * 1. A cover already saved to local storage -- always cheapest and always works
 *    offline.
 * 2. An explicitly local value (a `file://` path or Base64 blob) held in the
 *    novel record.
 * 3. A manga title with a remote URL -> [MangaCoverImage], with the source id
 *    so the right headers are attached.
 * 4. Anything else -> [NovelCoverImage].
 */
@Composable
fun LibraryCoverImage(
    novel: Novel,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop
) {
    val context = LocalContext.current

    // Hitting the filesystem is cheap but not free, and a library grid can ask
    // this question for dozens of cards on a single scroll, so the answer is
    // cached per novel id for as long as the card stays composed.
    val coverValue = novel.coverImageBase64
    val localCoverPath = remember(novel.id, coverValue) {
        val explicitFile = coverValue
            ?.takeIf { CoverStorage.isFilePath(it) }
            ?.removePrefix(CoverStorage.FILE_PREFIX)
            ?.let { java.io.File(it) }
            ?.takeIf { it.exists() && it.length() > 0 }
        // A newly selected Base64 cover must win over any old downloaded
        // cover file. Remote covers may still use the cached local copy.
        when {
            explicitFile != null -> explicitFile.absolutePath
            !coverValue.isNullOrBlank() &&
                !coverValue.startsWith("http://", true) &&
                !coverValue.startsWith("https://", true) &&
                !CoverStorage.isFilePath(coverValue) -> null
            else -> CoverStorage.coverFile(context, novel.id)
                .takeIf { it.exists() && it.length() > 0 }
                ?.absolutePath
        }
    }

    val isRemote = coverValue != null && (
        coverValue.startsWith("http://", ignoreCase = true) ||
            coverValue.startsWith("https://", ignoreCase = true)
        )

    when {
        localCoverPath != null -> {
            NovelCoverImage(
                coverBase64 = "file://$localCoverPath",
                title = novel.title,
                placeholderKey = if (isRemote) coverValue else null,
                modifier = modifier
            )
        }

        novel.isManga && isRemote -> {
            MangaCoverImage(
                coverUrl = coverValue,
                sourceId = novel.mangaSourceId,
                title = novel.title,
                modifier = modifier,
                contentScale = contentScale
            )
        }

        else -> {
            NovelCoverImage(
                coverBase64 = coverValue,
                title = novel.title,
                placeholderKey = if (isRemote) coverValue else null,
                modifier = modifier
            )
        }
    }
}
