package com.lorelight.ui.reader

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.lorelight.ui.theme.GlassPanel
import androidx.compose.foundation.background
import androidx.compose.ui.draw.alpha

@Composable
fun ReaderBottomControls(
    isPlaying: Boolean,
    readerBgColor: Color,
    readerTextColor: Color,
    readerHighlightColor: Color,
    themeState: String,
    activeChapterIndex: Int,
    chaptersCount: Int,
    onPrevChapter: () -> Unit,
    onNextChapter: () -> Unit,
    onSkipBackward: () -> Unit,
    onSkipForward: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onSwitchToReadMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(true) }
    Surface(
        color = Color.Transparent,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // ALWAYS-DARK READER PANEL FIX: GlassPanel looks at the ambient
            // MaterialTheme.colorScheme to decide whether to render its light
            // or dark glass treatment. The reader's own reading surface is
            // always dark regardless of the app's light/dark mode setting, so
            // this bottom controls bar must not inherit the app-wide scheme -
            // otherwise it flips to a light glass panel whenever the app is in
            // light mode. Forcing a dark background/surface here (derived from
            // the reader's own colors) makes GlassPanel's isLight check always
            // resolve to false for this panel.
            val appColors = MaterialTheme.colorScheme
            val forcedDarkScheme = appColors.copy(
                background = readerBgColor,
                surface = readerBgColor,
                onSurface = appColors.onSurface,
                onSurfaceVariant = appColors.onSurfaceVariant,
                primary = appColors.primary
            )
            MaterialTheme(colorScheme = forcedDarkScheme) {
            // The expand/collapse affordance is always its own floating button.
            // The playback dock grows out from that button and retracts back toward
            // it, creating a connected transition without merging the surfaces.
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 14.dp, top = 8.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // R is the quick switch from Listen to Read, opposite the
                // playback dock's collapse control.
                GlassPanel(
                    shape = RoundedCornerShape(22.dp),
                    tintAlpha = 0.78f,
                    modifier = Modifier.size(46.dp)
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize().clickable(onClick = onSwitchToReadMode),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "R",
                            color = MaterialTheme.colorScheme.onSurface,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                AnimatedVisibility(
                    visible = expanded,
                    enter = expandHorizontally(
                        expandFrom = Alignment.End,
                        animationSpec = tween(260)
                    ) + fadeIn(animationSpec = tween(180)),
                    exit = shrinkHorizontally(
                        shrinkTowards = Alignment.End,
                        animationSpec = tween(220)
                    ) + fadeOut(animationSpec = tween(140))
                ) {
                    GlassPanel(
                        shape = RoundedCornerShape(28.dp),
                        tintAlpha = 0.78f,
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .widthIn(max = 300.dp)
                            .width(286.dp)
                            .height(54.dp)
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            // Fixed-width group keeps Play/Pause at the exact centre
                            // of the main dock, independent of the separate arrow.
                            Row(
                                modifier = Modifier.width(260.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = onPrevChapter, enabled = activeChapterIndex > 0, modifier = Modifier.size(36.dp)) {
                                    Icon(Icons.Default.FastRewind, "Prev chapter", modifier = Modifier.size(18.dp),
                                        tint = if (activeChapterIndex > 0) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f))
                                }
                                IconButton(onClick = onSkipBackward, modifier = Modifier.size(36.dp)) {
                                    Icon(Icons.Default.SkipPrevious, "Prev sentence", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurface)
                                }
                                FilledIconButton(
                                    onClick = onTogglePlayPause,
                                    colors = IconButtonDefaults.filledIconButtonColors(
                                        containerColor = MaterialTheme.colorScheme.primary,
                                        contentColor = MaterialTheme.colorScheme.onPrimary
                                    ),
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause", modifier = Modifier.size(19.dp))
                                }
                                IconButton(onClick = onSkipForward, modifier = Modifier.size(36.dp)) {
                                    Icon(Icons.Default.SkipNext, "Next sentence", modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurface)
                                }
                                IconButton(onClick = onNextChapter, enabled = activeChapterIndex < chaptersCount - 1, modifier = Modifier.size(36.dp)) {
                                    Icon(Icons.Default.FastForward, "Next chapter", modifier = Modifier.size(18.dp),
                                        tint = if (activeChapterIndex < chaptersCount - 1) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.35f))
                                }
                            }
                        }
                    }
                }

                GlassPanel(
                    shape = RoundedCornerShape(22.dp),
                    tintAlpha = 0.78f,
                    modifier = Modifier
                        .size(width = 46.dp, height = 46.dp)
                        .clickable { expanded = !expanded }
                ) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Icon(
                            imageVector = if (expanded) Icons.Default.ChevronRight else Icons.Default.ChevronLeft,
                            contentDescription = if (expanded) "Collapse player controls" else "Expand player controls",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                }
            }
            } // end forcedDarkScheme MaterialTheme
        }
    }
}
