package com.lorelight.ui.reader

import com.lorelight.R
import androidx.compose.ui.res.stringResource
import com.lorelight.ui.theme.*
import com.lorelight.ui.reader.ReaderViewModel
import com.lorelight.data.model.Novel
import com.lorelight.utils.TextFilter
import com.lorelight.utils.FilterRule
import com.lorelight.utils.Token
import com.lorelight.core.getSafeFloat
import com.lorelight.tts.TtsPlaybackManager
import com.lorelight.crawler.CrawlerEngine

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import com.lorelight.ui.components.LorelightDialog
import com.lorelight.ui.components.readerSafeTopPadding
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.distinctUntilChanged
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.zIndex
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import android.content.Context
import android.content.Intent
import android.app.SearchManager
import android.widget.Toast
import androidx.compose.ui.graphics.toArgb

import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.verticalScroll
import kotlin.math.roundToInt
import com.lorelight.data.repository.LibraryRepository
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalView

@OptIn(ExperimentalAnimationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    viewModel: ReaderViewModel,
    onClose: () -> Unit,
    onOpenFontManager: () -> Unit
) {
    val context = LocalContext.current
    val activeNovelState by viewModel.activeNovel.collectAsState()

    // FIX #10: the old code read activeNovelState during the FIRST composition,
    // when it is still null, so novelId was "" and load() always returned null.
    // It therefore always seeded (0,0) and this restore path was dead code.
    // Start at 0 and let the restore effect below do the real work once the
    // chapter content actually exists.
    val listState = rememberLazyListState()

    // FIX #1: nothing may be persisted until the position has been restored for
    // the current novel+chapter. Holds "novelId#chapterIndex" once restored.
    var restoredKey by remember { mutableStateOf<String?>(null) }

    // FIX #12: typography fingerprint, kept in state so the save callbacks
    // declared below can reference it.
    var layoutSigState by remember { mutableStateOf(0) }

    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val textFilterRules by viewModel.textFilterRules.collectAsState()
    var selRange by remember { mutableStateOf<WordRange?>(null) }
    var selSentenceIndex by remember { mutableStateOf(-1) }
    var selectionVersion by remember { mutableStateOf(0) }
    var isSelectionPanelCollapsed by remember { mutableStateOf(true) }
    // The expanded selection shortcut occupies real reader space. Measure it and
    // reserve the same height in the reader viewport so chapter text reflows above it.
    var selectionPanelHeightPx by remember { mutableIntStateOf(0) }
    val selectionPanelDensity = LocalDensity.current
    val selectionPanelInset by animateDpAsState(
        targetValue = if (selRange != null && !isSelectionPanelCollapsed) {
            with(selectionPanelDensity) { selectionPanelHeightPx.toDp() } + 10.dp + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
        } else 0.dp,
        animationSpec = tween(260, easing = FastOutSlowInEasing),
        label = "selectionPanelReaderInset"
    )
    var aiErrorMessage by remember { mutableStateOf<String?>(null) }

    androidx.activity.compose.BackHandler(onBack = {
        if (selRange != null) {
            selRange = null
            selSentenceIndex = -1
            selectionVersion++
            return@BackHandler
        }
        persistReaderPosition(
            context = context,
            novelId = viewModel.activeNovel.value?.id ?: "",
            chapterIndex = viewModel.activeChapterIndex.value,
            listState = listState,
            layoutSig = layoutSigState,
            wordIndex = viewModel.activeSentenceIndex.value,
            recordDetailedProgress = viewModel::saveDetailedProgress
        )
        onClose()
    })
    
    LaunchedEffect(selRange) {
        if (selRange != null) {
            isSelectionPanelCollapsed = true
        } else {
            selSentenceIndex = -1
        }
    }
    val wordPositions = remember { mutableStateMapOf<Int, WordPosition>() }
    var showTextFilterPanel by remember { mutableStateOf(false) }
    var magnifierText by remember { mutableStateOf<String?>(null) }
    
    val activeNovel by viewModel.activeNovel.collectAsState()
    val chapters by viewModel.chapters.collectAsState()
    val activeChapterIndex by viewModel.activeChapterIndex.collectAsState()
    val activeSentenceIndexState = viewModel.activeSentenceIndex.collectAsState()
    val activeSentenceIndex by activeSentenceIndexState
    val filteredSentences by viewModel.filteredSentences.collectAsState()
    val rawChapterBlocks by viewModel.sentences.collectAsState()

    // ---- Companion signals ------------------------------------------------
    // Any real finger scroll counts as motion. He waits for a still screen
    // before speaking, so this is what stops a bubble landing mid-flick.
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress }.collect { scrolling ->
            if (scrolling) com.lorelight.companion.CompanionBus.noteMotion()
        }
    }

    // A chapter that would not load at all. Keyed on the content, so it fires
    // when the failure text arrives rather than on every recomposition, and
    // the bus rate limits him on top of that. "Loading chapter..." is not a
    // failure text, so this does not fire while a fetch is still in flight.
    LaunchedEffect(filteredSentences) {
        val only = filteredSentences.singleOrNull() as? ReaderBlock.TextBlock
        if (only != null &&
            only.text.isNotBlank() &&
            com.lorelight.crawler.CrawlerEngine.isFailureText(only.text)
        ) {
            com.lorelight.companion.CompanionBus.onLoadFailed()
        }
    }
    val cachedChapterIndices by viewModel.cachedChapterIndices.collectAsState()
    val maxPlayableIndex by viewModel.maxPlayableIndex.collectAsState()
    val showBatteryOptimizationDialog by viewModel.showBatteryOptimizationDialog.collectAsState()

    val wordIndexMap by produceState(initialValue = emptyMap<Int, String>(), filteredSentences) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            val map = mutableMapOf<Int, String>()
            var currentIdx = 0
            filteredSentences.forEach { sentence ->
                val sentenceText = when (sentence) {
                    is ReaderBlock.TextBlock -> sentence.text
                    is ReaderBlock.ImageBlock -> ""
                }
                val (tokens, nextIdx) = TextFilter.tokenize(sentenceText, currentIdx)
                tokens.forEach { tok ->
                    if (tok.isWord && tok.wordIdx >= 0) {
                        map[tok.wordIdx] = tok.raw
                    }
                }
                currentIdx = nextIdx
            }
            map
        }
    }
    val isPlaying by viewModel.isPlaying.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    // Chapter failures are sometimes delivered as the only content block,
    // while speech failures use errorMessage. Present both through one simple,
    // user-facing message instead of exposing engine/network internals.
    val chapterLoadError = remember(filteredSentences) {
        // A failure message is not always a single block: an error that
        // contains a line break is split into several, and the old
        // singleOrNull() check then saw "real chapter text" and showed the
        // raw message in the page with no way to retry. A real chapter is
        // never this short, so scanning the first few blocks is safe.
        if (filteredSentences.size > 3) {
            null
        } else {
            filteredSentences
                .filterIsInstance<ReaderBlock.TextBlock>()
                .map { it.text }
                .firstOrNull {
                    CrawlerEngine.isFailureText(it) || it.startsWith("Couldn't load chapter")
                }
        }
    }
    // Chapter failures are shown ONLY inside the page (icon + message + Retry).
    // There used to be a popup on top of that showing the same thing twice.
    val displayedReaderError = remember(chapterLoadError) {
        chapterLoadError?.let(::friendlyReaderError)
    }
    // Read-aloud problems have no in-page spot, so show them as a short toast
    // (not a popup) and clear them so they don't repeat.
    LaunchedEffect(errorMessage, chapterLoadError) {
        val msg = errorMessage
        if (msg != null) {
            if (chapterLoadError == null) {
                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            }
            viewModel.clearErrorMessage()
        }
    }

    val fontSize by viewModel.readerFontSize.collectAsState()
    val lineSpacing by viewModel.readerLineSpacing.collectAsState()
    val paragraphSpacing by viewModel.readerParagraphSpacing.collectAsState()
    val textAlignment by viewModel.readerTextAlignment.collectAsState()
    val readerBgColorRaw by viewModel.readerBgColor.collectAsState()
    val readerTextColorRaw by viewModel.readerTextColor.collectAsState()
    val sleepTimerMinutes by viewModel.sleepTimerMinutes.collectAsState()
    val sleepTimerRemainingSeconds by viewModel.sleepTimerRemainingSeconds.collectAsState()

    LaunchedEffect(fontSize, lineSpacing, paragraphSpacing) {
        layoutSigState = LibraryRepository.layoutSignature(
            fontSize, lineSpacing, paragraphSpacing
        )
    }

    val readerFontFamily by viewModel.readerFontFamily.collectAsState()
    val tokensBySentence by viewModel.tokensBySentence.collectAsState()
    val isFetchingChapter by viewModel.isFetchingChapter.collectAsState()
    val readerMode by viewModel.readerMode.collectAsState()
    val immersive by viewModel.immersiveMode.collectAsState()
    // Read mode starts with chrome visible; deliberate finger scrolling controls
    // visibility without changing the LazyColumn's measured viewport.
    var readerChromeVisible by remember { mutableStateOf(true) }
    val toolbarVisible = readerMode != "Read" || readerChromeVisible
    val isDefaultHighlight by viewModel.isDefaultHighlight.collectAsState()
    val customHighlightColorRaw by viewModel.customHighlightColor.collectAsState()
    val readerBackgroundType by viewModel.readerBackgroundType.collectAsState()
    val themeState by viewModel.appTheme.collectAsState()
    val highlights by viewModel.highlights.collectAsState()
    val aiTempQueue by com.lorelight.utils.AiTextFilterAssistant.tempQueue.collectAsState()
    val aiIsProcessing by com.lorelight.utils.AiTextFilterAssistant.isProcessing.collectAsState()
    val aiStatusText by com.lorelight.utils.AiTextFilterAssistant.statusText.collectAsState()
    val aiShowFirstUsePanel by com.lorelight.utils.AiTextFilterAssistant.showFirstUseBottomPanel.collectAsState()
    val aiShowPreviewDrawer by com.lorelight.utils.AiTextFilterAssistant.showPreviewDrawer.collectAsState()
    val aiPreviewSuggestions by com.lorelight.utils.AiTextFilterAssistant.previewSuggestions.collectAsState()
    val autoAiRevision by com.lorelight.utils.AiTextFilterAssistant.autoAssistRevision.collectAsState()
    val aiScope = rememberCoroutineScope()
    LaunchedEffect(activeNovel?.id, activeChapterIndex, rawChapterBlocks, isFetchingChapter, autoAiRevision) {
        val novel = activeNovel
        if (novel == null || isFetchingChapter ||
            !com.lorelight.utils.AiTextFilterAssistant.isAutoAssistEnabled(context, novel.id)
        ) return@LaunchedEffect

        // Snapshot the chapter, then let the remembered reader scope finish its
        // scan even if the reader navigates. Otherwise navigation could cancel
        // the result after it was marked pending and permanently stall the queue.
        val chapterIndex = activeChapterIndex
        val chapterUrl = novel.chapterUrls.getOrNull(chapterIndex)
        val rawTextSnapshot = rawChapterBlocks
            .filterIsInstance<ReaderBlock.TextBlock>()
            .joinToString("\\n\\n") { it.text }
            .trim()

        aiScope.launch {
            val cachedOriginalText = if (!chapterUrl.isNullOrBlank()) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    com.lorelight.crawler.CrawlerEngine.getCachedChapterText(context, chapterUrl)
                }
            } else null
            val chapterText = (cachedOriginalText ?: rawTextSnapshot).trim()
            if (chapterText.isBlank() || chapterText == "Loading chapter..." ||
                chapterText.contains("This chapter isn't available yet", ignoreCase = true) ||
                chapterText.contains("Loading next chapter...", ignoreCase = true) ||
                chapterText.contains("Chapter content is empty", ignoreCase = true) ||
                com.lorelight.crawler.CrawlerEngine.isFailureText(chapterText)
            ) return@launch

            val bookRules = com.lorelight.utils.TextFilter.visibleRulesFor(
                viewModel.textFilterRules.value, novel.id, novel.title
            )
            val result = com.lorelight.utils.AiTextFilterAssistant.processAutoChapter(
                context = context,
                novelId = novel.id,
                chapterIndex = chapterIndex,
                chapterText = chapterText,
                existingBookRules = bookRules,
                allLibraryRules = viewModel.textFilterRules.value
            )

            if (!com.lorelight.utils.AiTextFilterAssistant.isAutoAssistEnabled(context, novel.id)) {
                com.lorelight.utils.AiTextFilterAssistant.markAutoPreviewHandled(
                    context, novel.id, chapterIndex
                )
                return@launch
            }

            result.onSuccess { suggestions ->
                if (suggestions.isEmpty()) return@onSuccess
                if (com.lorelight.utils.AiTextFilterAssistant.isAutoPreviewBlocked(
                        context, novel.id, chapterIndex
                    )
                ) return@onSuccess

                if (com.lorelight.utils.AiTextFilterAssistant.getApplyMode(context) ==
                    com.lorelight.utils.AiTextFilterAssistant.MODE_PREVIEW
                ) {
                    if (!com.lorelight.utils.AiTextFilterAssistant.isAutoPreviewDismissed(
                            context, novel.id, chapterIndex, suggestions
                        ) && activeNovel?.id == novel.id
                    ) {
                        com.lorelight.utils.AiTextFilterAssistant.openPreviewDrawer(
                            suggestions, context, novel.id, chapterIndex
                        )
                    }
                    // If the user switched to another novel, keep the cached
                    // preview pending; returning to this novel will reopen it.
                } else {
                    val latestRules = viewModel.textFilterRules.value
                    val merged = com.lorelight.utils.AiTextFilterAssistant.mergeSuggestionsIntoRules(
                        existingRules = latestRules,
                        suggestions = suggestions,
                        bookId = novel.id,
                        bookTitle = novel.title
                    )
                    viewModel.saveRules(merged)
                    com.lorelight.utils.AiTextFilterAssistant.markAutoPreviewHandled(
                        context, novel.id, chapterIndex
                    )
                }
            }.onFailure { error ->
                if (activeNovel?.id == novel.id) {
                    aiErrorMessage = error.message?.takeIf { it.isNotBlank() }
                        ?: "Automatic AI Assist failed. Check your connection and configured AI provider keys, then retry."
                }
                android.util.Log.w("LorelightAutoAI", "Automatic chapter analysis failed", error)
            }
        }
    }

    LaunchedEffect(activeNovel?.id, activeChapterIndex) {
        com.lorelight.utils.AiTextFilterAssistant.syncChapterScope(
            novelId = activeNovel?.id ?: "",
            chapterIndex = activeChapterIndex
        )
    }

    fun triggerAiLocalization() {
        val novelVal = activeNovel ?: return
        // AI must inspect the ORIGINAL chapter, never the already-filtered display.
        // Otherwise an existing replacement (e.g. Miao -> Victor) can be mistaken
        // for a fresh source name and get replaced again (Victor -> Bailey).
        val chapterIndexSnapshot = activeChapterIndex
        val chapterUrlSnapshot = novelVal.chapterUrls.getOrNull(chapterIndexSnapshot)
        val rawChapterTextSnapshot = rawChapterBlocks
            .filterIsInstance<ReaderBlock.TextBlock>()
            .joinToString("\n\n") { block -> block.text }
            .trim()
        val queuedSnapshot = aiTempQueue.toList()
        aiErrorMessage = null
        val bookRules = com.lorelight.utils.TextFilter.visibleRulesFor(
            textFilterRules,
            novelVal.id,
            novelVal.title
        )
        selRange = null
        selSentenceIndex = -1
        selectionVersion++
        isSelectionPanelCollapsed = true

        aiScope.launch {
            // A deliberate Send-to-AI action is the only way to regenerate a
            // preview after the user permanently dismissed the previous one.
            com.lorelight.utils.AiTextFilterAssistant.clearAutoPreviewDismissal(
                context, novelVal.id, chapterIndexSnapshot
            )
            // Load the original cached chapter here; cachedOriginalText from the
            // auto-assist LaunchedEffect is intentionally local to that effect.
            val cachedSourceText = if (!chapterUrlSnapshot.isNullOrBlank()) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    com.lorelight.crawler.CrawlerEngine.getCachedChapterText(context, chapterUrlSnapshot)
                }
            } else null
            val fullChapterText = (cachedSourceText ?: rawChapterTextSnapshot).trim()
            if (fullChapterText.isBlank()) {
                android.widget.Toast.makeText(context, "Chapter text is empty", android.widget.Toast.LENGTH_SHORT).show()
                return@launch
            }
            val modeToast = if (queuedSnapshot.isEmpty()) {
                "Sending full chapter to AI..."
            } else {
                "Sending ${queuedSnapshot.size} queued name(s) + chapter to AI..."
            }
            android.widget.Toast.makeText(context, modeToast, android.widget.Toast.LENGTH_SHORT).show()
            val result = com.lorelight.utils.AiTextFilterAssistant.processChapterWithAi(
                context = context,
                novelId = novelVal.id,
                chapterText = fullChapterText,
                queuedWords = queuedSnapshot,
                existingBookRules = bookRules,
                allLibraryRules = textFilterRules
            )
            result.onSuccess { suggestions ->
                com.lorelight.utils.AiTextFilterAssistant.clearQueue()
                if (suggestions.isEmpty()) {
                    android.widget.Toast.makeText(context, "AI found no new Chinese names to replace.", android.widget.Toast.LENGTH_SHORT).show()
                    return@onSuccess
                }
                if (com.lorelight.utils.AiTextFilterAssistant.getApplyMode(context) == com.lorelight.utils.AiTextFilterAssistant.MODE_PREVIEW) {
                    com.lorelight.utils.AiTextFilterAssistant.openPreviewDrawer(
                        suggestions, context, novelVal.id, chapterIndexSnapshot
                    )
                } else {
                    val merged = com.lorelight.utils.AiTextFilterAssistant.mergeSuggestionsIntoRules(
                        existingRules = viewModel.textFilterRules.value,
                        suggestions = suggestions,
                        bookId = novelVal.id,
                        bookTitle = novelVal.title
                    )
                    viewModel.saveRules(merged)
                    android.widget.Toast.makeText(context, "AI added ${suggestions.size} name rule(s)!", android.widget.Toast.LENGTH_SHORT).show()
                }
            }.onFailure { err ->
                val message = err.message?.takeIf { it.isNotBlank() }
                    ?: "AI request failed. Check your connection and API key, then retry."
                aiErrorMessage = message
                android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    // Resolve themed colors
    val themeBgColor = remember(themeState) { getThemeBgColor(themeState) }
    val themeTextColor = remember(themeState) { getThemeTextColor(themeState) }

    val readerBgColor = remember(readerBackgroundType, readerBgColorRaw, themeBgColor) {
        if (readerBackgroundType == "AMOLED Black") {
            Color.Black
        } else if (readerBackgroundType == "Theme") {
            themeBgColor
        } else {
            if (readerBgColorRaw == 0xFF1C1B1FL) themeBgColor else Color(readerBgColorRaw)
        }
    }

    val readerTextColor = remember(readerBgColor, readerBackgroundType, readerTextColorRaw, themeTextColor, themeState) {
        if (readerTextColorRaw != 0xFFE6E1E5L) {
            Color(readerTextColorRaw)
        } else if (readerBackgroundType == "Theme") {
            themeTextColor
        } else if (readerBgColor == Color.Black) {
            if (themeState == "readerwhite") Color(0xFFE4E4E7) else {
                when (themeState) {
                    "blackgold" -> Color(0xFFE9C484)
                    "Satin Pink" -> Color(0xFFEBC7D5)
                    "cyne" -> Color(0xFFC2F3F8)
                    else -> Color(0xFFE4E4E7)
                }
            }
        } else {
            themeTextColor
        }
    }

    val defaultHighlightColor = remember(themeState) { getDefaultHighlightColor(themeState) }

    val readerHighlightColor = remember(themeState, isDefaultHighlight, defaultHighlightColor, customHighlightColorRaw) {
        if (themeState == "readerblacknew") {
            Color(0xFF888888)
        } else if (isDefaultHighlight) {
            defaultHighlightColor
        } else {
            Color(customHighlightColorRaw)
        }
    }

    // Keep reader content edge-to-edge with fixed layout geometry. The opaque
    // AMOLED-black top chrome overlays the content and is removed only by the
    // deliberate Read-mode swipe gesture.
    val view = androidx.compose.ui.platform.LocalView.current
    if (!view.isInEditMode) {
        val activity = remember(context) {
            var currentContext = context
            while (currentContext is android.content.ContextWrapper) {
                if (currentContext is android.app.Activity) break
                currentContext = currentContext.baseContext
            }
            currentContext as? android.app.Activity
        }
        activity?.let { act ->
            SideEffect {
                act.window.statusBarColor = android.graphics.Color.BLACK
                androidx.core.view.WindowCompat.getInsetsController(act.window, view).isAppearanceLightStatusBars = false
            }
            DisposableEffect(immersive) {
                val controller = androidx.core.view.WindowCompat.getInsetsController(act.window, view)
                // The status bar remains present with a solid AMOLED-black background.
                controller.show(androidx.core.view.WindowInsetsCompat.Type.statusBars())
                if (immersive) {
                    controller.systemBarsBehavior =
                        androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    controller.hide(androidx.core.view.WindowInsetsCompat.Type.navigationBars())
                } else {
                    controller.show(androidx.core.view.WindowInsetsCompat.Type.navigationBars())
                }
                onDispose { controller.show(androidx.core.view.WindowInsetsCompat.Type.systemBars()) }
            }
        }
    }

    val volumeKeysEnabled by viewModel.volumeKeysEnabled.collectAsState()

    // S5: while the reader is on screen, policy downloads stand down.
    //
    // A claim held for the LIFETIME of the screen, released in onDispose, so
    // an early return or a crash out of the reader cannot leave the claim
    // stuck - which would silently disable policy downloads until the app was
    // restarted. Reading is the one thing this feature exists to serve, so it
    // must never be the thing it slows down.
    DisposableEffect(Unit) {
        com.lorelight.data.download.DownloadPolicyScheduler.enterUserActivity()
        onDispose {
            com.lorelight.data.download.DownloadPolicyScheduler.exitUserActivity()
        }
    }

    DisposableEffect(volumeKeysEnabled, readerMode) {
        VolumeKeyBus.active = volumeKeysEnabled && readerMode != "Listen"
        onDispose { VolumeKeyBus.active = false }
    }

    var showChapterDrawer by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showFloatingStylePanel by remember { mutableStateOf(false) }

    val chaptersListState = rememberLazyListState()

    // Autoscroll premium states
    val readerPrefs = remember { context.getSharedPreferences("reader_prefs", android.content.Context.MODE_PRIVATE) }
    // FIX #19: honour the keep-screen-on preference. Stored in reader_prefs
    // alongside the other reader settings.
    val keepScreenOnPref = remember { readerPrefs.getBoolean("reader_keep_screen_on", true) }
    
    var isAutoScrollActive by remember { mutableStateOf(false) }
    var autoScrollSpeed by remember {
        mutableStateOf(readerPrefs.getSafeFloat("reader_autoscroll_speed", 30f).coerceIn(1f, 100f))
    }
    var showAutoScrollPanel by remember { mutableStateOf(false) }
    var autoScrollInteractionTrigger by remember { mutableStateOf(0) }

    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(isPlaying) {
        VolumeKeyBus.events.collect { dir ->
            if (isPlaying) return@collect
            val info = listState.layoutInfo
            val viewport = (info.viewportEndOffset - info.viewportStartOffset).toFloat()
            if (viewport <= 0f) return@collect
            // ~8% overlap so no line is skipped across the seam
            val step = viewport * 0.92f * dir
            coroutineScope.launch { listState.animateScrollBy(step) }
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    val slideOffset = remember { Animatable(0f) }   // in pixels
    var containerWidthPx by remember { mutableStateOf(0f) }

    LaunchedEffect(Unit) {
        var prevIndex = activeChapterIndex
        snapshotFlow { activeChapterIndex }.collect { newIndex ->
            if (newIndex != prevIndex) {
                val forward = newIndex > prevIndex          // Next = true, Previous = false
                val inForeground =
                    lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
                if (inForeground && containerWidthPx > 0f) {
                    val start = if (forward) containerWidthPx else -containerWidthPx   // new page enters from that side
                    slideOffset.snapTo(start)
                    slideOffset.animateTo(0f, tween(durationMillis = 260, easing = FastOutSlowInEasing))
                } else {
                    slideOffset.snapTo(0f)
                }
                prevIndex = newIndex
            }
        }
    }
    


    LaunchedEffect(readerMode) {
        if (readerMode == "Read") {
            viewModel.pauseSpeaking()
        } else if (readerMode == "Listen") {
            isAutoScrollActive = false
            showAutoScrollPanel = false
        }
    }

    LaunchedEffect(showChapterDrawer) {
        if (showChapterDrawer) {
            viewModel.recomputeCachedChapters()
        }
    }

    // Auto-dismiss short-lived panel after 5 seconds of inactivity
    LaunchedEffect(showAutoScrollPanel, autoScrollSpeed, isAutoScrollActive, autoScrollInteractionTrigger) {
        if (showAutoScrollPanel) {
            kotlinx.coroutines.delay(5000L)
            showAutoScrollPanel = false
        }
    }

    // smooth autoscroll animation loop
    val density = androidx.compose.ui.platform.LocalDensity.current.density
    LaunchedEffect(isAutoScrollActive, autoScrollSpeed) {
        if (isAutoScrollActive) {
            var lastTimeNanos = System.nanoTime()
            while (true) {
                androidx.compose.runtime.withFrameNanos { }
                val currentTimeNanos = System.nanoTime()
                val elapsedSeconds = (currentTimeNanos - lastTimeNanos).coerceAtLeast(0L) / 1_000_000_000f
                lastTimeNanos = currentTimeNanos
                if (elapsedSeconds > 0f) {
                    val speedPx = autoScrollSpeed * density
                    val deltaPx = speedPx * elapsedSeconds
                    val consumed = listState.scrollBy(deltaPx)
                    if (consumed == 0f && deltaPx > 0.05f && !listState.canScrollForward) {
                        isAutoScrollActive = false
                    }
                }
            }
        }
    }

    LaunchedEffect(autoScrollSpeed) {
        readerPrefs.edit().putFloat("reader_autoscroll_speed", autoScrollSpeed).apply()
    }

    // FIX #1 / #2 / #7 / #8: this collector used to start immediately and write
    // unconditionally, so it persisted (0,0) BEFORE the restore effect ever ran -
    // which is what silently reset everyone's reading position to the top of the
    // chapter. It now refuses to write until restoredKey matches the current
    // novel+chapter.
    // FIX #6: conflate + a settle delay instead of a blocking write per frame.
    LaunchedEffect(listState) {
        snapshotFlow {
            val nId = viewModel.activeNovel.value?.id ?: ""
            val cIdx = viewModel.activeChapterIndex.value
            Triple(
                "$nId#$cIdx",
                listState.firstVisibleItemIndex,
                listState.firstVisibleItemScrollOffset
            )
        }
            .distinctUntilChanged()
            .conflate()
            .collect { (key, _, _) ->
                kotlinx.coroutines.delay(250L)
                if (restoredKey != key) return@collect
                persistReaderPosition(
                    context,
                    viewModel.activeNovel.value?.id ?: "",
                    viewModel.activeChapterIndex.value,
                    listState,
                    layoutSigState
                )
            }
    }

    LaunchedEffect(listState) {
        listState.interactionSource.interactions.collect { interaction ->
            if (interaction is androidx.compose.foundation.interaction.DragInteraction.Start) {
                isAutoScrollActive = false
            }
        }
    }

    // Read-mode chrome follows deliberate finger scrolling only. LazyList
    // DragInteraction excludes programmatic scroll/autoscroll and text-selection
    // drags handled by child text nodes. Positive list movement means the
    // finger moved upward; negative movement means it moved downward.
    val toolbarSwipeThresholdPx = with(LocalDensity.current) { 56.dp.toPx() }
    LaunchedEffect(listState, readerMode, toolbarSwipeThresholdPx) {
        if (readerMode != "Read") {
            readerChromeVisible = true
            return@LaunchedEffect
        }
        var fingerDragging = false
        var toolbarToggledThisDrag = false
        var previousPosition = listState.firstVisibleItemIndex.toLong() * 1_000_000L + listState.firstVisibleItemScrollOffset
        var accumulatedDelta = 0f
        kotlinx.coroutines.coroutineScope {
            launch {
                listState.interactionSource.interactions.collect { interaction ->
                    when (interaction) {
                        is androidx.compose.foundation.interaction.DragInteraction.Start -> {
                            fingerDragging = true
                            toolbarToggledThisDrag = false
                            accumulatedDelta = 0f
                            previousPosition = listState.firstVisibleItemIndex.toLong() * 1_000_000L + listState.firstVisibleItemScrollOffset
                        }
                        is androidx.compose.foundation.interaction.DragInteraction.Stop,
                        is androidx.compose.foundation.interaction.DragInteraction.Cancel -> {
                            fingerDragging = false
                            toolbarToggledThisDrag = false
                            accumulatedDelta = 0f
                        }
                    }
                }
            }
            launch {
                snapshotFlow {
                    listState.firstVisibleItemIndex.toLong() * 1_000_000L + listState.firstVisibleItemScrollOffset
                }.collect { currentPosition ->
                    val delta = (currentPosition - previousPosition).toFloat()
                    previousPosition = currentPosition
                    if (!fingerDragging || toolbarToggledThisDrag || delta == 0f) return@collect
                    accumulatedDelta += delta
                    if (accumulatedDelta >= toolbarSwipeThresholdPx) {
                        readerChromeVisible = false
                        toolbarToggledThisDrag = true
                    } else if (accumulatedDelta <= -toolbarSwipeThresholdPx) {
                        readerChromeVisible = true
                        toolbarToggledThisDrag = true
                    }
                }
            }
        }
    }

    val lifecycleState by lifecycleOwner.lifecycle.currentStateFlow.collectAsState()
    val isResumed = lifecycleState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)
    var isFirstScroll by remember { mutableStateOf(true) }
    var lastChapterSwipeAtMs by remember { mutableLongStateOf(0L) }

    var lastChapterIdx by remember { mutableStateOf(-1) }
    LaunchedEffect(activeChapterIndex) {
        selRange = null
        selSentenceIndex = -1
        selectionVersion++
        wordPositions.clear()
        if (activeChapterIndex != lastChapterIdx && lastChapterIdx != -1) {
            // A chapter transition is an intentional fresh start in the
            // Novel Reader. Do not let the position-restoration effect below
            // replace this top anchor with a previously saved paragraph offset.
            // The first chapter opened in a session still uses normal resume;
            // only subsequent chapter changes are forced to the beginning.
            restoredKey = "${activeNovel?.id.orEmpty()}#$activeChapterIndex"
            try {
                listState.scrollToItem(0, 0)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        lastChapterIdx = activeChapterIndex
    }

    LaunchedEffect(activeSentenceIndex, filteredSentences, isResumed, activeChapterIndex, isFetchingChapter) {
        if (isResumed && filteredSentences.isNotEmpty()) {
            val targetIdx = activeSentenceIndex.coerceIn(0, filteredSentences.lastIndex)
            val novelId = viewModel.activeNovel.value?.id ?: ""
            val chapterIdx = activeChapterIndex
            val key = "$novelId#$chapterIdx"
            if (restoredKey != key) {
                isFirstScroll = false
                if (novelId.isEmpty() || chapterIdx < 0) return@LaunchedEffect
                // FIX #17: while a chapter is being fetched, filteredSentences
                // holds a single "Loading chapter..." placeholder block. It is
                // non-empty, so without these two guards the restore runs against
                // a 1-item list, clamps the position to 0, AND sets restoredKey -
                // meaning the real content never gets restored at all.
                // CRITICAL: return WITHOUT assigning restoredKey, so this effect
                // runs again when the real content arrives.
                if (isFetchingChapter) return@LaunchedEffect
                if (isPlaceholderContent(filteredSentences)) return@LaunchedEffect
                // FIX #14: wait until the list has actually laid out items.
                // Restoring against an empty list clamped everything to 0.
                snapshotFlow { listState.layoutInfo.totalItemsCount }.first { it > 0 }
                val total = listState.layoutInfo.totalItemsCount
                // Two stores can answer "where was I", and choosing between
                // them needs their write times - a data-layer question. The
                // repository owns it now, FIX #12's fraction fallback included.
                // Passing targetIdx as the row's paragraph index when there is
                // no novel preserves the old null fallback exactly.
                val novelNow = viewModel.activeNovel.value
                val resolved = LibraryRepository.resolveReaderPosition(
                    context = context,
                    novelId = novelId,
                    chapterIndex = chapterIdx,
                    totalItems = total,
                    layoutSig = layoutSigState,
                    novelChapterIndex = novelNow?.currentChapterIndex ?: -1,
                    novelParagraphIndex = novelNow?.currentParagraphIndex ?: targetIdx,
                    novelScrollOffset = novelNow?.currentScrollOffset ?: 0,
                    novelLastReadAt = novelNow?.lastReadTimestamp ?: 0L,
                    fallbackIndex = targetIdx
                )
                val para = resolved.index
                val offset = resolved.offset
                try {
                    listState.scrollToItem(para, offset)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                restoredKey = key   // FIX #1: only NOW may the saver run
                return@LaunchedEffect
            }
            if (isPlaying && !listState.isScrollInProgress) {
                kotlinx.coroutines.delay(200)
                if (!listState.isScrollInProgress) {
                    val layoutInfo = listState.layoutInfo
                    val viewportHeight = layoutInfo.viewportEndOffset - layoutInfo.viewportStartOffset
                    if (viewportHeight > 0) {
                        // Skip the scroll animation entirely if the sentence is already comfortably on screen.
                        val visibleItem = layoutInfo.visibleItemsInfo.firstOrNull { it.index == targetIdx }
                        val comfortZoneTop = layoutInfo.viewportStartOffset + viewportHeight / 8
                        val comfortZoneBottom = layoutInfo.viewportStartOffset + (viewportHeight * 2) / 3
                        val alreadyComfortable = visibleItem != null &&
                            visibleItem.offset >= comfortZoneTop &&
                            (visibleItem.offset + visibleItem.size) <= comfortZoneBottom
                        if (!alreadyComfortable) {
                            val centerOffset = -(viewportHeight / 3)
                            try {
                                listState.animateScrollToItem(targetIdx, centerOffset)
                            } catch (e: Exception) { e.printStackTrace() }
                        }
                    }
                }
            }
        }
    }

    val localView = androidx.compose.ui.platform.LocalView.current
    DisposableEffect(isPlaying, keepScreenOnPref) {
        // FIX #19: screen-on now follows the user preference while the reader is
        // open, and still forces on during TTS playback regardless of the
        // preference (audio playback with the screen sleeping is the expected
        // case, but the reader was previously the ONLY thing keeping it awake).
        localView.keepScreenOn = isPlaying || keepScreenOnPref
        onDispose {
            localView.keepScreenOn = false
        }
    }

    LaunchedEffect(showChapterDrawer) {
        if (showChapterDrawer && activeChapterIndex in chapters.indices) {
            kotlinx.coroutines.delay(120)
            val viewportSize = chaptersListState.layoutInfo.viewportEndOffset - chaptersListState.layoutInfo.viewportStartOffset
            if (viewportSize > 0) {
                chaptersListState.scrollToItem(activeChapterIndex, -(viewportSize / 2 - 120))
            } else {
                chaptersListState.scrollToItem((activeChapterIndex - 3).coerceAtLeast(0))
            }
        }
    }

    // PERF: the library list behind the reader isn't visible, so hold back its
    // refreshes while this screen is open (the manga reader already does this).
    // One refresh is delivered when the reader closes, so Continue Reading and
    // History are correct as soon as you leave.
    DisposableEffect(Unit) {
        com.lorelight.data.local.ReadingProgressSignal.beginDeferred()
        onDispose { com.lorelight.data.local.ReadingProgressSignal.endDeferred() }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                TtsPlaybackManager.isAppInBackground.value = false
            } else if (event == androidx.lifecycle.Lifecycle.Event.ON_STOP) {
                TtsPlaybackManager.isAppInBackground.value = true
                persistReaderPosition(
                    context = context,
                    novelId = viewModel.activeNovel.value?.id ?: "",
                    chapterIndex = viewModel.activeChapterIndex.value,
                    listState = listState,
                    layoutSig = layoutSigState,
                    wordIndex = viewModel.activeSentenceIndex.value,
                    recordDetailedProgress = viewModel::saveDetailedProgress
                )
                // The position above is debounced. This runs AFTER it was scheduled
                // (MainActivity's flush at ON_PAUSE/ON_STOP may have run before),
                // so promote it to the writer queue now.
                com.lorelight.data.db.DbWriter.flushDebounced()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(readerBgColor)
            .pointerInput(readerMode, readerChromeVisible) {
                if (readerMode == "Read" && !readerChromeVisible) {
                    detectTapGestures(onTap = { readerChromeVisible = true })
                }
            }
    ) {
        // Decorative Hero Background images for specialized styled themes.
        // Guarded on the RESOLVED color, not just the "AMOLED Black" chip:
        // the AMOLED app theme also resolves to pure black, and painting a
        // texture over black is what turned it grey. Alpha matches the reader
        // content layer so the two do not stack into a washed-out grey.
        if (readerBgColor != Color.Black && (readerBackgroundType == "Theme" || readerBgColorRaw == 0xFF1C1B1FL)) {
            val bgRes = when (themeState) {
                "blackgold" -> R.drawable.readergold
                "Satin Pink" -> R.drawable.readerpink
                "Ocean Blue" -> R.drawable.readerblue
                "cyne" -> R.drawable.readercyne
                "readerpurple" -> R.drawable.readerpurple
                "readerblood" -> R.drawable.readerred
                else -> R.drawable.readergreen
            }
            Image(
                painter = painterResource(id = bgRes),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(0.20f)
            )
        }



        Box(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
            ) {
                Scaffold(
                    containerColor = Color.Transparent,
                    contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                if (readerMode == "Listen") {
                    ReaderBottomControls(
                        isPlaying = isPlaying,
                        readerBgColor = readerBgColor,
                        readerTextColor = readerTextColor,
                        readerHighlightColor = readerHighlightColor,
                        themeState = themeState,
                        activeChapterIndex = activeChapterIndex,
                        chaptersCount = chapters.size,
                        onPrevChapter = {
                            if (activeChapterIndex > 0) {
                                viewModel.prevChapter()
                            }
                        },
                        onNextChapter = {
                            if (activeChapterIndex < chapters.size - 1) {
                                viewModel.nextChapter()
                            }
                        },
                        onSkipBackward = { viewModel.skipBackward() },
                        onSkipForward = { viewModel.skipForward() },
                        onTogglePlayPause = { viewModel.togglePlayPause() },
                        onSwitchToReadMode = { viewModel.readerMode.value = "Read" }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(
                        top = innerPadding.calculateTopPadding(),
                        bottom = selectionPanelInset
                    )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .onSizeChanged { containerWidthPx = it.width.toFloat() }
                        .graphicsLayer { translationX = slideOffset.value }
                        .pointerInput(activeChapterIndex, chapters, selRange) {
                            if (selRange != null) return@pointerInput
                            var horizontalDistance = 0f
                            val commitThreshold = 96.dp.toPx()
                            detectHorizontalDragGestures(
                                onDragStart = { horizontalDistance = 0f },
                                onHorizontalDrag = { _, dragAmount ->
                                    horizontalDistance += dragAmount
                                },
                                onDragEnd = {
                                    val now = android.os.SystemClock.uptimeMillis()
                                    if (abs(horizontalDistance) >= commitThreshold &&
                                        now - lastChapterSwipeAtMs >= 650L
                                    ) {
                                        val target = if (horizontalDistance < 0f) {
                                            activeChapterIndex + 1
                                        } else {
                                            activeChapterIndex - 1
                                        }
                                        if (target in chapters.indices) {
                                            lastChapterSwipeAtMs = now
                                            viewModel.selectChapter(target)
                                        }
                                    }
                                    horizontalDistance = 0f
                                },
                                onDragCancel = { horizontalDistance = 0f }
                            )
                        }
                ) {
                    ReaderContent(
                        listState = listState,
                        readerBackgroundType = readerBackgroundType,
                        themeState = themeState,
                        readerBgColor = readerBgColor,
                        readerTextColor = readerTextColor,
                        readerHighlightColor = readerHighlightColor,
                        filteredSentences = filteredSentences,
                        novelId = activeNovel?.id ?: "",
                        tokensBySentence = tokensBySentence,
                        activeSentenceIndexState = activeSentenceIndexState,
                        readerMode = readerMode,
                        fontSize = fontSize,
                        lineSpacing = lineSpacing,
                        paragraphSpacing = paragraphSpacing,
                        textAlignment = textAlignment,
                        readerFontFamily = readerFontFamily,
                        // The toolbar is drawn above the reader content. Reserve its
                        // full status-bar + toolbar height in the LazyColumn so the
                        // opening lines never render underneath the opaque top panel.
                        // Keep the inset while the chrome is visible and release it
                        // when the reader toolbar is hidden by the normal scroll gesture.
                        topContentPadding = if (toolbarVisible) {
                            WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 56.dp
                        } else {
                            0.dp
                        },
                        selRange = selRange,
                        selectionVersion = selectionVersion,
                        wordPositions = wordPositions,
                        wordIndexMap = wordIndexMap,
                        activeChapterIndex = activeChapterIndex,
                        chapters = chapters,
                        highlights = highlights,
                        onSentenceClick = { index ->
                            viewModel.jumpToSentence(index)
                        },
                        onWordSelected = { range, isDragging ->
                            selRange = range
                        },
                        onPositioned = { idx, left, right ->
                            wordPositions[idx] = WordPosition(left, right)
                        },
                        onParagraphLongClick = { index ->
                            selSentenceIndex = index
                        },
                        onChapterSelect = { index ->
                            viewModel.selectChapter(index)
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // In-page recovery: the only place a failed chapter is reported.
                if (chapterLoadError != null && !isFetchingChapter) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CloudOff,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(40.dp)
                            )
                            Text(
                                text = displayedReaderError
                                    ?: "Couldn't load this chapter. Please try again.",
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 15.sp,
                                textAlign = TextAlign.Center
                            )
                            Button(
                                onClick = { viewModel.retryCurrentChapter() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = readerHighlightColor,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Retry", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                val isTapNavigationEnabled by viewModel.isTapNavigationEnabled.collectAsState()
                if (isTapNavigationEnabled) {
                    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                        val width = constraints.maxWidth
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(Unit) {
                                    detectTapGestures { offset ->
                                        val x = offset.x
                                        val leftThreshold = width * 0.2f
                                        val rightThreshold = width * 0.8f
                                        
                                        coroutineScope.launch {
                                            if (x < leftThreshold) {
                                                val targetIndex = (listState.firstVisibleItemIndex - 3).coerceAtLeast(0)
                                                listState.scrollToItem(targetIndex)
                                            } else if (x > rightThreshold) {
                                                val targetIndex = (listState.firstVisibleItemIndex + 3).coerceAtMost(filteredSentences.size - 1)
                                                listState.scrollToItem(targetIndex)
                                            } else {
                                                showSettingsDialog = !showSettingsDialog
                                            }
                                        }
                                    }
                                }
                        )
                    }
                }


            }
        }

                // Auto-Scroll Speed Adjustment Panel
                AnimatedVisibility(
                    visible = showAutoScrollPanel && readerMode == "Read",
                    enter = slideInVertically(initialOffsetY = { -it / 2 }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { -it / 2 }) + fadeOut(),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(
                            top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() +
                                (if (toolbarVisible) 52.dp else 8.dp),
                            end = 12.dp
                        )
                        .zIndex(1002f)
                ) {
                    GlassPanel(
                        modifier = Modifier.width(260.dp),
                        cornerRadius = 16.dp,
                        tintAlpha = 0.88f,
                        borderAlpha = 0.18f
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Play/Pause button (takes 30% of the row space)
                            Box(
                                modifier = Modifier
                                    .weight(0.3f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                FilledIconButton(
                                    onClick = { 
                                        isAutoScrollActive = !isAutoScrollActive 
                                        autoScrollInteractionTrigger++
                                    },
                                    colors = IconButtonDefaults.filledIconButtonColors(
                                        containerColor = readerHighlightColor,
                                        contentColor = if (themeState == "blackgold") Color(0xFF2E1901) else Color.White
                                    ),
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isAutoScrollActive) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play/Pause Auto-scroll",
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            // Slider area (takes 70% of the row space)
                            Row(
                                modifier = Modifier
                                    .weight(0.7f)
                                    .fillMaxHeight(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Slider(
                                    value = autoScrollSpeed,
                                    onValueChange = { 
                                        autoScrollSpeed = it
                                        autoScrollInteractionTrigger++
                                    },
                                    valueRange = 1f..150f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = readerHighlightColor,
                                        activeTrackColor = readerHighlightColor,
                                        inactiveTrackColor = readerTextColor.copy(alpha = 0.15f)
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(24.dp)
                                        .padding(horizontal = 4.dp)
                                )
                                Text(
                                    text = "${autoScrollSpeed.toInt()}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = readerTextColor,
                                    modifier = Modifier
                                        .padding(end = 4.dp)
                                        .width(22.dp)
                                )
                            }
                        }
                    }
                }

        // Stable opaque AMOLED status-bar background; the text remains
        // underneath instead of being pushed down when the toolbar changes.
        val statusBarHeight = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
        // Keep the system status bar visually independent from the reader
        // toolbar. The toolbar may slide away, but the status bar stays visible
        // over a fixed AMOLED-black backing at the top of the screen.
        if (statusBarHeight > 0.dp) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .height(statusBarHeight)
                    .background(Color.Black)
                    .zIndex(1002f)
            )
        }

        ReaderToolbar(
            activeNovel = activeNovel,
            chapters = chapters,
            activeChapterIndex = activeChapterIndex,
            readerMode = readerMode,
            sleepTimerMinutes = sleepTimerMinutes,
            sleepTimerRemainingSeconds = sleepTimerRemainingSeconds,
            isAutoScrollActive = isAutoScrollActive,
            readerHighlightColor = readerHighlightColor,
            onClose = {
                persistReaderPosition(
                    context = context,
                    novelId = viewModel.activeNovel.value?.id ?: "",
                    chapterIndex = viewModel.activeChapterIndex.value,
                    listState = listState,
                    layoutSig = layoutSigState,
                    wordIndex = viewModel.activeSentenceIndex.value,
                    recordDetailedProgress = viewModel::saveDetailedProgress
                )
                onClose()
            },
            onSetSleepTimer = { minutes -> viewModel.setSleepTimer(minutes); Unit },
            onToggleChapters = { showChapterDrawer = !showChapterDrawer },
            onToggleAutoScroll = { showAutoScrollPanel = !showAutoScrollPanel },
            onOpenSettings = { showSettingsDialog = true },
            aiIsProcessing = aiIsProcessing,
            visible = toolbarVisible,
            modifier = Modifier.align(Alignment.TopCenter).zIndex(1001f)
        )

        // Floating shortcut settings toolbar
        AnimatedVisibility(
            visible = showFloatingStylePanel,
            enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it / 2 }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 96.dp)
                .padding(horizontal = 24.dp)
                .zIndex(98f)
        ) {
            FloatingStylePanel(
                fontSize = fontSize,
                lineSpacing = lineSpacing,
                paragraphSpacing = paragraphSpacing,
                textAlignment = textAlignment,
                onClose = { showFloatingStylePanel = false },
                onFontSizeChange = { viewModel.readerFontSize.value = it },
                onLineSpacingChange = { viewModel.readerLineSpacing.value = it },
                onParagraphSpacingChange = { viewModel.readerParagraphSpacing.value = it },
                onAlignmentChange = { viewModel.readerTextAlignment.value = it }
            )
        }

        // Selection Draggable Handles Overlay & Floating Action Bar
        val selectedTextPreview = remember(selRange, filteredSentences) {
            val range = selRange
            if (range == null) "" else {
                val minIdx = minOf(range.start, range.end)
                val maxIdx = maxOf(range.start, range.end)
                val allRawTokens = mutableListOf<Token>()
                var currentWordIdx = 0
                filteredSentences.forEach { sentence ->
                    val sentenceText = when (sentence) {
                        is ReaderBlock.TextBlock -> sentence.text
                        is ReaderBlock.ImageBlock -> ""
                    }
                    val (raw, nextIdx) = TextFilter.tokenize(sentenceText, currentWordIdx)
                    allRawTokens.addAll(raw)
                    currentWordIdx = nextIdx
                }
                val firstTokIdx = allRawTokens.indexOfFirst { it.wordIdx == minIdx }
                val lastTokIdx = allRawTokens.indexOfLast { it.wordIdx == maxIdx }
                if (firstTokIdx != -1 && lastTokIdx != -1 && firstTokIdx <= lastTokIdx) {
                    allRawTokens.subList(firstTokIdx, lastTokIdx + 1)
                        .joinToString("") { it.raw }
                        .trim()
                } else {
                    allRawTokens.filter { it.wordIdx in minIdx..maxIdx }
                        .joinToString("") { it.raw }
                        .trim()
                }
            }
        }

        selRange?.let { range ->
            var overlayRootOffset by remember { mutableStateOf(Offset.Zero) }
            
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .zIndex(998f)
                    .onGloballyPositioned { overlayRootOffset = it.localToRoot(Offset.Zero) }
            ) {
                val selMin = minOf(range.start, range.end)
                val selMax = maxOf(range.start, range.end)
                // The opposite end of the selection, snapshotted when a drag begins
                // so it stays fixed for the whole gesture.
                var dragFixedEnd by remember { mutableStateOf(selMax) }
                var dragFixedStart by remember { mutableStateOf(selMin) }
                val startAnchor = wordPositions[selMin]?.leftAnchor
                val endAnchor = wordPositions[selMax]?.rightAnchor
                
                val handleRadiusDp = 11.dp
                val touchPaddingDp = 12.dp
                val density = LocalDensity.current
                val handleRadiusPx = with(density) { handleRadiusDp.toPx() }
                val touchPaddingPx = with(density) { touchPaddingDp.toPx() }

                // Start Handle (Left / Top-Right teardrop)
                startAnchor?.let { anchor ->
                    var accumulatedStartDrag by remember { mutableStateOf(Offset.Zero) }
                    
                    Box(
                        modifier = Modifier
                            .offset {
                                IntOffset(
                                    (anchor.x - overlayRootOffset.x - handleRadiusPx - touchPaddingPx).roundToInt(),
                                    (anchor.y - overlayRootOffset.y - touchPaddingPx).roundToInt()
                                )
                            }
                            .size(46.dp)
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = {
                                        // Read live state at drag start. pointerInput(Unit)
                                        // never restarts, so captured values would go stale.
                                        val live = selRange
                                        val liveMin = live?.let { minOf(it.start, it.end) } ?: 0
                                        dragFixedEnd = live?.let { maxOf(it.start, it.end) } ?: liveMin
                                        accumulatedStartDrag = wordPositions[liveMin]?.leftAnchor ?: anchor
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        accumulatedStartDrag += dragAmount
                                        var closestIdx = -1
                                        var minDistance = Float.MAX_VALUE
                                        for ((idx, wPos) in wordPositions) {
                                            val wordCenter = Offset(
                                                (wPos.leftAnchor.x + wPos.rightAnchor.x) / 2f,
                                                (wPos.leftAnchor.y + wPos.rightAnchor.y) / 2f
                                            )
                                            val distX = accumulatedStartDrag.x - wordCenter.x
                                            val distY = accumulatedStartDrag.y - wordCenter.y
                                            val dist = distX * distX + distY * distY
                                            if (dist < minDistance) {
                                                minDistance = dist
                                                closestIdx = idx
                                            }
                                        }
                                        if (closestIdx != -1) {
                                            val newMin = minOf(closestIdx, dragFixedEnd)
                                            val newMax = maxOf(closestIdx, dragFixedEnd)
                                            if (selRange?.start != newMin || selRange?.end != newMax) {
                                                selRange = WordRange(newMin, newMax)
                                                try {
                                                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                                                } catch (_: Exception) {}
                                            }
                                        }
                                    },
                                    onDragEnd = {},
                                    onDragCancel = {}
                                )
                            }
                            .padding(touchPaddingDp)
                    ) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .shadow(2.dp, shape = CircleShape)
                        ) {
                            val r = size.width / 2f
                            val path = Path().apply {
                                moveTo(r, 0f)
                                arcTo(
                                    rect = Rect(0f, 0f, 2 * r, 2 * r),
                                    startAngleDegrees = -90f,
                                    sweepAngleDegrees = 270f,
                                    forceMoveTo = false
                                )
                                close()
                            }
                            drawPath(path = path, color = readerHighlightColor)
                        }
                    }
                }

                // End Handle (Right / Top-Left teardrop)
                endAnchor?.let { anchor ->
                    var accumulatedEndDrag by remember { mutableStateOf(Offset.Zero) }
                    
                    Box(
                        modifier = Modifier
                            .offset {
                                IntOffset(
                                    (anchor.x - overlayRootOffset.x - handleRadiusPx - touchPaddingPx).roundToInt(),
                                    (anchor.y - overlayRootOffset.y - touchPaddingPx).roundToInt()
                                )
                            }
                            .size(46.dp)
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = {
                                        val live = selRange
                                        val liveMax = live?.let { maxOf(it.start, it.end) } ?: 0
                                        dragFixedStart = live?.let { minOf(it.start, it.end) } ?: liveMax
                                        accumulatedEndDrag = wordPositions[liveMax]?.rightAnchor ?: anchor
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        accumulatedEndDrag += dragAmount
                                        var closestIdx = -1
                                        var minDistance = Float.MAX_VALUE
                                        for ((idx, wPos) in wordPositions) {
                                            val wordCenter = Offset(
                                                (wPos.leftAnchor.x + wPos.rightAnchor.x) / 2f,
                                                (wPos.leftAnchor.y + wPos.rightAnchor.y) / 2f
                                            )
                                            val distX = accumulatedEndDrag.x - wordCenter.x
                                            val distY = accumulatedEndDrag.y - wordCenter.y
                                            val dist = distX * distX + distY * distY
                                            if (dist < minDistance) {
                                                minDistance = dist
                                                closestIdx = idx
                                            }
                                        }
                                        if (closestIdx != -1) {
                                            val newMin = minOf(dragFixedStart, closestIdx)
                                            val newMax = maxOf(dragFixedStart, closestIdx)
                                            if (selRange?.start != newMin || selRange?.end != newMax) {
                                                selRange = WordRange(newMin, newMax)
                                                try {
                                                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                                                } catch (_: Exception) {}
                                            }
                                        }
                                    },
                                    onDragEnd = {},
                                    onDragCancel = {}
                                )
                            }
                            .padding(touchPaddingDp)
                    ) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .shadow(2.dp, shape = CircleShape)
                        ) {
                            val r = size.width / 2f
                            val path = Path().apply {
                                moveTo(r, 0f)
                                arcTo(
                                    rect = Rect(0f, 0f, 2 * r, 2 * r),
                                    startAngleDegrees = -90f,
                                    sweepAngleDegrees = -270f,
                                    forceMoveTo = false
                                )
                                close()
                            }
                            drawPath(path = path, color = readerHighlightColor)
                        }
                    }
                }
            }
        }

        // Modal input shield for reader overlays. Empty/transparent areas of a
        // panel must never pass taps through to ReaderContent (which would move
        // the text highlight or trigger paragraph actions). Actual panel controls
        // are drawn above this shield and remain interactive.
        val readerOverlayOpen =
            (selRange != null && !isSelectionPanelCollapsed) ||
            aiShowFirstUsePanel ||
            aiShowPreviewDrawer ||
            showChapterDrawer ||
            showSettingsDialog ||
            showTextFilterPanel

        if (readerOverlayOpen) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .zIndex(998f)
                    .pointerInput(readerOverlayOpen) {
                        awaitPointerEventScope {
                            while (true) {
                                val event = awaitPointerEvent(PointerEventPass.Final)
                                event.changes.forEach { it.consume() }
                            }
                        }
                    }
            )
        }

        // Sliding Bottom Action Bar on Selection
        AnimatedVisibility(
            visible = selRange != null && !isSelectionPanelCollapsed,
            enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(300)) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(200)) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 10.dp)
                .zIndex(999f)
        ) {
            val cleanedMatch = remember(selectedTextPreview) {
                val base = selectedTextPreview.trim().replace(Regex("\\s+"), " ")
                val stripped = base.trim('"', '\u201C', '\u201D', ',', '.', ';', ':', '!', '?')
                // If the selection is only punctuation, stripping would empty it and
                // disable the Add button. Keep the raw selection in that case.
                if (stripped.isBlank()) base else stripped
            }
            
            var isVanish by remember { mutableStateOf(true) }
            var replacementText by remember { mutableStateOf("") }
            val generatedCharacterNames = remember { mutableStateListOf<String>() }
            var selectedScope by remember { mutableStateOf("All Books") }

            // Text Filter Studio palette follows the active reader theme while keeping
            // surfaces quiet and opaque; the accent is reserved for selected states/actions.
            val filterPanelIsLight = (0.299f * readerBgColor.red + 0.587f * readerBgColor.green + 0.114f * readerBgColor.blue) > 0.52f
            val filterFieldSurface = if (filterPanelIsLight) {
                blendColors(readerBgColor, Color.Black, 0.035f)
            } else {
                blendColors(readerBgColor, Color.White, 0.025f)
            }
            // Keep the shortcut UI independent from the novel's custom text colour.
            val filterPanelTextColor = if (filterPanelIsLight) Color(0xFF171717) else Color(0xFFF2F2F2)
            // Use the active app theme's primary colour, not the reader's custom
            // highlighted-text colour, for Text Filter Studio controls.
            val filterAccentStrong = MaterialTheme.colorScheme.primary
            val filterAccentSoft = filterAccentStrong.copy(alpha = if (filterPanelIsLight) 0.20f else 0.24f)
            val filterAccentBorder = filterAccentStrong.copy(alpha = 0.48f)
            val filterAccentContent = if ((0.299f * filterAccentStrong.red + 0.587f * filterAccentStrong.green + 0.114f * filterAccentStrong.blue) > 0.52f) Color.Black else Color.White
            // Reuse Lorelight's own theme-aware button gradient (the same palette
            // used by selected Library/History controls). This must never depend on
            // the novel's custom reading-text colour.
            val (_, filterActionGradient, _) = getThemedButtonProps(
                filterAccentStrong,
                MaterialTheme.colorScheme.onPrimaryContainer
            )
            // Add Rule remains the primary action, using a subtly darker gradient
            // derived from the active theme's own primary/secondary/tertiary colours.
            val filterAddRuleGradient = Brush.linearGradient(
                colors = listOf(
                    blendColors(filterAccentStrong, Color.Black, 0.20f),
                    blendColors(MaterialTheme.colorScheme.secondary, Color.Black, 0.16f),
                    blendColors(MaterialTheme.colorScheme.tertiary, Color.Black, 0.12f)
                )
            )

            GlassPanel(
                modifier = Modifier
                    .fillMaxWidth()
                    .onSizeChanged { selectionPanelHeightPx = it.height },
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
                tintAlpha = 0.86f,
                borderAlpha = 0.16f
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Compact studio header: title on the left, utility controls on the right.
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(9.dp))
                                    .background(filterAccentSoft)
                                    .border(1.dp, filterAccentBorder, RoundedCornerShape(9.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Tune, contentDescription = null, tint = filterAccentStrong, modifier = Modifier.size(17.dp))
                            }
                            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                                Text("Create Filter Rule", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = filterPanelTextColor, maxLines = 1)
                                Text("LORELIGHT TEXT STUDIO", fontSize = 8.sp, letterSpacing = 1.sp, color = filterAccentStrong, maxLines = 1)
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Selected Text", cleanedMatch))
                                    Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                                    selRange = null
                                    selSentenceIndex = -1
                                    selectionVersion++
                                },
                                modifier = Modifier.size(30.dp)
                            ) { Icon(Icons.Default.ContentCopy, contentDescription = "Copy selected text", tint = filterPanelTextColor.copy(alpha = 0.72f), modifier = Modifier.size(15.dp)) }
                            IconButton(onClick = { isSelectionPanelCollapsed = true }, modifier = Modifier.size(30.dp)) {
                                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Collapse panel", tint = filterPanelTextColor.copy(alpha = 0.72f), modifier = Modifier.size(19.dp))
                            }
                            IconButton(onClick = { selRange = null; selSentenceIndex = -1; selectionVersion++ }, modifier = Modifier.size(30.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Close panel", tint = filterPanelTextColor.copy(alpha = 0.72f), modifier = Modifier.size(17.dp))
                            }
                        }
                    }

                    // Selected phrase and its length share one compact row.
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(11.dp))
                            .background(filterFieldSurface)
                            .border(1.dp, filterAccentBorder, RoundedCornerShape(11.dp))
                            .padding(horizontal = 11.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(7.dp)
                    ) {
                        Text("Match:", color = filterPanelTextColor.copy(alpha = 0.62f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        Text("\"$cleanedMatch\"", color = filterAccentStrong, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Text("${cleanedMatch.length} chars", color = filterAccentStrong, fontSize = 9.sp, maxLines = 1)
                    }

                    // Action and scope are paired horizontally, as in the supplied studio reference.
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(
                            modifier = Modifier.weight(1f)
                                .clip(RoundedCornerShape(11.dp))
                                .background(filterFieldSurface)
                                .border(1.dp, filterAccentBorder, RoundedCornerShape(11.dp))
                                .padding(3.dp)
                        ) {
                            Row {
                                listOf("Vanish" to true, "Replace" to false).forEach { (label, vanish) ->
                                    val selected = isVanish == vanish
                                    Box(
                                        modifier = Modifier.weight(1f).height(32.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .then(if (selected) Modifier.background(filterActionGradient) else Modifier.background(Color.Transparent))
                                            .clickable { isVanish = vanish },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(if (vanish) "Vanish" else "Replace", color = if (selected) filterAccentContent else filterPanelTextColor.copy(alpha = 0.82f), fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                                    }
                                }
                            }
                        }
                        Column(
                            modifier = Modifier.weight(1f)
                                .clip(RoundedCornerShape(11.dp))
                                .background(filterFieldSurface)
                                .border(1.dp, filterAccentBorder, RoundedCornerShape(11.dp))
                                .padding(3.dp)
                        ) {
                            Row {
                                listOf("All Books" to "All Books", "This Book" to "This Book").forEach { (label, scope) ->
                                    val selected = selectedScope == scope
                                    Box(
                                        modifier = Modifier.weight(1f).height(32.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .then(if (selected) Modifier.background(filterActionGradient) else Modifier.background(Color.Transparent))
                                            .clickable { selectedScope = scope },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(label, color = if (selected) filterAccentContent else filterPanelTextColor.copy(alpha = 0.82f), fontSize = 9.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                        }
                    }

                    // Replacement field with local gender-specific name suggestions.
                    // The M/F controls belong beside this shortcut-panel field (not only
                    // in Manage Text Filter), so they are visible where users enter a replacement.
                    AnimatedVisibility(visible = !isVanish, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedTextField(
                                value = replacementText,
                                onValueChange = { replacementText = it },
                                placeholder = { Text(stringResource(R.string.reader_filter_replacement_placeholder_generic), fontSize = 12.sp, color = filterPanelTextColor.copy(alpha = 0.4f)) },
                                leadingIcon = { Text("With", color = filterAccentStrong, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                                trailingIcon = {
                                    if (replacementText.isNotEmpty()) IconButton(onClick = { replacementText = "" }, modifier = Modifier.size(28.dp)) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear replacement", tint = filterPanelTextColor.copy(alpha = 0.55f), modifier = Modifier.size(15.dp))
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = filterAccentStrong,
                                    unfocusedBorderColor = filterAccentBorder,
                                    focusedTextColor = filterPanelTextColor,
                                    unfocusedTextColor = filterPanelTextColor
                                ),
                                shape = RoundedCornerShape(11.dp),
                                singleLine = true,
                                modifier = Modifier.weight(1f).height(54.dp)
                            )

                            OutlinedButton(
                                onClick = {
                                    val novelId = activeNovel?.id ?: ""
                                    val usedNames = TextFilter.usedReplacementsFor(
                                        textFilterRules, novelId, activeNovel?.title ?: ""
                                    ) + generatedCharacterNames + listOf(replacementText.trim()).filter { it.isNotBlank() }
                                    val generated = com.lorelight.utils.LocalCharacterNameEngine.suggestRandom(
                                        context = context,
                                        novelId = novelId,
                                        gender = "male",
                                        alreadyUsed = usedNames.toSet()
                                    )
                                    if (generated != null) {
                                        replacementText = generated
                                        generatedCharacterNames.add(generated)
                                    } else {
                                        Toast.makeText(context, "No unused male names remain", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.size(width = 40.dp, height = 48.dp),
                                contentPadding = PaddingValues(0.dp),
                                shape = RoundedCornerShape(9.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = Color(0xFF1976D2),
                                    contentColor = Color.White
                                )
                            ) { Text("M", fontWeight = FontWeight.Bold, fontSize = 14.sp) }

                            OutlinedButton(
                                onClick = {
                                    val novelId = activeNovel?.id ?: ""
                                    val usedNames = TextFilter.usedReplacementsFor(
                                        textFilterRules, novelId, activeNovel?.title ?: ""
                                    ) + generatedCharacterNames + listOf(replacementText.trim()).filter { it.isNotBlank() }
                                    val generated = com.lorelight.utils.LocalCharacterNameEngine.suggestRandom(
                                        context = context,
                                        novelId = novelId,
                                        gender = "female",
                                        alreadyUsed = usedNames.toSet()
                                    )
                                    if (generated != null) {
                                        replacementText = generated
                                        generatedCharacterNames.add(generated)
                                    } else {
                                        Toast.makeText(context, "No unused female names remain", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.size(width = 40.dp, height = 48.dp),
                                contentPadding = PaddingValues(0.dp),
                                shape = RoundedCornerShape(9.dp),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = Color(0xFFE91E63),
                                    contentColor = Color.White
                                )
                            ) { Text("F", fontWeight = FontWeight.Bold, fontSize = 14.sp) }
                        }
                    }

                    // AI tools and primary save action form one balanced footer block.
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (com.lorelight.utils.AiTextFilterAssistant.isAiAssistEnabled(context)) {
                            val isWordInQueue = remember(cleanedMatch, aiTempQueue) {
                                cleanedMatch.isNotBlank() && aiTempQueue.any { it.equals(cleanedMatch, ignoreCase = true) }
                            }
                            Column(
                                modifier = Modifier.weight(0.60f)
                                    .heightIn(min = 76.dp)
                                    .clip(RoundedCornerShape(11.dp))
                                    .background(filterFieldSurface)
                                    .border(1.dp, filterAccentBorder, RoundedCornerShape(11.dp))
                                    .padding(8.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = filterAccentStrong, modifier = Modifier.size(13.dp))
                                        Text("AI Assist", color = filterAccentStrong, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Icon(Icons.Default.Info, contentDescription = "AI queue information", tint = filterPanelTextColor.copy(alpha = 0.42f), modifier = Modifier.size(13.dp))
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
                                    OutlinedButton(
                                        onClick = {
                                            if (cleanedMatch.isNotBlank()) {
                                                val added = com.lorelight.utils.AiTextFilterAssistant.toggleOrAddWord(cleanedMatch)
                                                val msg = if (added) "Added \"$cleanedMatch\" to chapter AI list (${com.lorelight.utils.AiTextFilterAssistant.tempQueue.value.size})" else "Removed \"$cleanedMatch\" from chapter AI list"
                                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                            }
                                        },
                                        enabled = cleanedMatch.isNotBlank() && !aiIsProcessing,
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, if (isWordInQueue) filterAccentStrong else filterPanelTextColor.copy(alpha = 0.38f)),
                                        colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.Transparent, contentColor = if (isWordInQueue) filterAccentContent else filterPanelTextColor),
                                        modifier = Modifier.weight(1f).height(32.dp)
                                            .then(if (isWordInQueue) Modifier.clip(RoundedCornerShape(8.dp)).background(filterActionGradient) else Modifier),
                                        contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp)
                                    ) { Text(if (aiTempQueue.isEmpty()) "+ Add" else "+ Add (${aiTempQueue.size})", fontWeight = FontWeight.Bold, fontSize = 9.sp, maxLines = 1) }
                                    Button(
                                        onClick = {
                                            if (!com.lorelight.utils.AiTextFilterAssistant.hasAnyProviderKey(context)) {
                                                Toast.makeText(context, "Add an AI provider key in Manage Text Filter → AI Assist first", Toast.LENGTH_LONG).show()
                                                showTextFilterPanel = true
                                            } else if (!com.lorelight.utils.AiTextFilterAssistant.hasChosenFirstUseMode(context)) {
                                                com.lorelight.utils.AiTextFilterAssistant.openFirstUsePanel()
                                            } else {
                                                triggerAiLocalization()
                                            }
                                        },
                                        enabled = !aiIsProcessing,
                                        shape = RoundedCornerShape(8.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent, contentColor = filterAccentContent),
                                        contentPadding = PaddingValues(horizontal = 5.dp, vertical = 0.dp),
                                        modifier = Modifier.weight(1f).height(32.dp)
                                            .clip(RoundedCornerShape(8.dp)).background(filterActionGradient)
                                    ) { Text(if (aiIsProcessing) "AI..." else "Send AI", fontWeight = FontWeight.ExtraBold, fontSize = 9.sp, maxLines = 1) }
                                }
                            }
                            Box(modifier = Modifier.weight(0.40f), contentAlignment = Alignment.Center) {
                                                Button(
                    onClick = {
                        if (cleanedMatch.isNotBlank()) {
                            val activeNovelVal = activeNovel
                            val bookIdVal = if (selectedScope == "This Book") (activeNovelVal?.id ?: "") else ""
                            // Only a rule for this same book (or for all
                            // books) counts as a duplicate, so a rule for
                            // another novel is never overwritten.
                            val existingRule = TextFilter.findDuplicate(
                                textFilterRules,
                                cleanedMatch,
                                selectedScope,
                                activeNovelVal?.id ?: "",
                                activeNovelVal?.title ?: ""
                            )
                            if (existingRule != null) {
                                val updatedRule = existingRule.copy(
                                    original = cleanedMatch,
                                    replacement = if (isVanish) "" else replacementText,
                                    isVanish = isVanish,
                                    scope = selectedScope,
                                    bookId = bookIdVal,
                                    action = if (isVanish) TextFilter.ACTION_ERASE_TEXT else TextFilter.ACTION_REPLACE,
                                    strictMatch = false
                                )
                                val updatedList = textFilterRules.map { if (it.id == existingRule.id) updatedRule else it }
                                viewModel.saveRules(updatedList)
                                Toast.makeText(context, "Updated existing rule", Toast.LENGTH_SHORT).show()
                            } else {
                                val newRule = FilterRule(
                                    id = java.util.UUID.randomUUID().toString(),
                                    original = cleanedMatch,
                                    replacement = if (isVanish) "" else replacementText,
                                    isVanish = isVanish,
                                    scope = selectedScope,
                                    bookId = bookIdVal,
                                    action = if (isVanish) TextFilter.ACTION_ERASE_TEXT else TextFilter.ACTION_REPLACE,
                                    strictMatch = false
                                )
                                viewModel.saveRules(textFilterRules + newRule)
                            }
                            selRange = null
                            selSentenceIndex = -1
                            selectionVersion++
                            isSelectionPanelCollapsed = true
                            replacementText = ""
                        }
                    },
                    enabled = cleanedMatch.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Transparent,
                        contentColor = filterAccentContent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 76.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(filterAddRuleGradient)
                        .border(1.dp, filterAccentStrong.copy(alpha = 0.52f), RoundedCornerShape(8.dp)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(17.dp))
                        Text(stringResource(R.string.reader_filter_add_rule), fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 2, textAlign = TextAlign.Center)
                    }
                }
                            }
                        } else {
                                            Button(
                    onClick = {
                        if (cleanedMatch.isNotBlank()) {
                            val activeNovelVal = activeNovel
                            val bookIdVal = if (selectedScope == "This Book") (activeNovelVal?.id ?: "") else ""
                            // Only a rule for this same book (or for all
                            // books) counts as a duplicate, so a rule for
                            // another novel is never overwritten.
                            val existingRule = TextFilter.findDuplicate(
                                textFilterRules,
                                cleanedMatch,
                                selectedScope,
                                activeNovelVal?.id ?: "",
                                activeNovelVal?.title ?: ""
                            )
                            if (existingRule != null) {
                                val updatedRule = existingRule.copy(
                                    original = cleanedMatch,
                                    replacement = if (isVanish) "" else replacementText,
                                    isVanish = isVanish,
                                    scope = selectedScope,
                                    bookId = bookIdVal,
                                    action = if (isVanish) TextFilter.ACTION_ERASE_TEXT else TextFilter.ACTION_REPLACE,
                                    strictMatch = false
                                )
                                val updatedList = textFilterRules.map { if (it.id == existingRule.id) updatedRule else it }
                                viewModel.saveRules(updatedList)
                                Toast.makeText(context, "Updated existing rule", Toast.LENGTH_SHORT).show()
                            } else {
                                val newRule = FilterRule(
                                    id = java.util.UUID.randomUUID().toString(),
                                    original = cleanedMatch,
                                    replacement = if (isVanish) "" else replacementText,
                                    isVanish = isVanish,
                                    scope = selectedScope,
                                    bookId = bookIdVal,
                                    action = if (isVanish) TextFilter.ACTION_ERASE_TEXT else TextFilter.ACTION_REPLACE,
                                    strictMatch = false
                                )
                                viewModel.saveRules(textFilterRules + newRule)
                            }
                            selRange = null
                            selSentenceIndex = -1
                            selectionVersion++
                            isSelectionPanelCollapsed = true
                            replacementText = ""
                        }
                    },
                    enabled = cleanedMatch.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = filterAccentStrong,
                        contentColor = filterAccentContent
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 76.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(filterAddRuleGradient),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(17.dp))
                        Text(stringResource(R.string.reader_filter_add_rule), fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 2, textAlign = TextAlign.Center)
                    }
                }
                        }
                    }

                    if (aiIsProcessing && aiStatusText.isNotBlank()) {
                        Text(aiStatusText, fontSize = 10.sp, color = filterAccentStrong, modifier = Modifier.align(Alignment.CenterHorizontally), maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }

        // First-Use AI Mode Choice Bottom Panel (same area/style as the Text Filter Shortcut Panel)
        AnimatedVisibility(
            visible = aiShowFirstUsePanel,
            enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(300)) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(200)) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .zIndex(1001f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .background(readerBgColor)
                    .border(1.dp, readerHighlightColor.copy(alpha = 0.35f), RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "AI Assist — Choose How Results Apply",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = readerTextColor
                    )
                    IconButton(onClick = { com.lorelight.utils.AiTextFilterAssistant.closeFirstUsePanel() }) {
                        Icon(
                            Icons.Default.Close,
                            contentDescription = "Close",
                            tint = readerTextColor.copy(alpha = 0.6f)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Do you want AI name replacements saved automatically to this novel's filter, or previewed in a side panel first? (You can change this anytime in Manage Text Filter → AI Assist.)",
                    fontSize = 12.sp,
                    color = readerTextColor.copy(alpha = 0.75f),
                    lineHeight = 17.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            com.lorelight.utils.AiTextFilterAssistant.setApplyMode(
                                context,
                                com.lorelight.utils.AiTextFilterAssistant.MODE_PREVIEW
                            )
                            com.lorelight.utils.AiTextFilterAssistant.closeFirstUsePanel()
                            triggerAiLocalization()
                        },
                        shape = RoundedCornerShape(10.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, readerHighlightColor),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = readerHighlightColor),
                        modifier = Modifier.weight(1f).height(44.dp)
                    ) {
                        Text("Preview First 👁️", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Button(
                        onClick = {
                            com.lorelight.utils.AiTextFilterAssistant.setApplyMode(
                                context,
                                com.lorelight.utils.AiTextFilterAssistant.MODE_INSTANT
                            )
                            com.lorelight.utils.AiTextFilterAssistant.closeFirstUsePanel()
                            triggerAiLocalization()
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = readerHighlightColor,
                            contentColor = Color.Black
                        ),
                        modifier = Modifier.weight(1f).height(44.dp)
                    ) {
                        Text("Instant Save ⚡", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        // Right-Side Slide-In AI Results Preview Drawer (slides from right like Settings drawer)
        AnimatedVisibility(
            visible = aiShowPreviewDrawer,
            enter = slideInHorizontally(initialOffsetX = { it }, animationSpec = tween(300, easing = FastOutSlowInEasing)) + fadeIn(),
            exit = slideOutHorizontally(targetOffsetX = { it }, animationSpec = tween(250)) + fadeOut(),
            modifier = Modifier
                .fillMaxSize()
                .zIndex(1002f)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.55f))
                    .clickable(role = androidx.compose.ui.semantics.Role.Button) {
                        com.lorelight.utils.AiTextFilterAssistant.closePreviewDrawer()
                    }
            ) {
                com.lorelight.ui.theme.GlassPanel(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .fillMaxHeight()
                        .fillMaxWidth(0.6f)
                        .clickable(enabled = false) { },
                    cornerRadius = 0.dp,
                    tintAlpha = 0.92f,
                    borderAlpha = 0.18f
                ) {
                    val sheetText = MaterialTheme.colorScheme.onSurface
                    val sheetAccent = MaterialTheme.colorScheme.primary
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .statusBarsPadding()
                            .navigationBarsPadding()
                            .padding(16.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "AI Name Suggestions (${aiPreviewSuggestions.count { it.selected }}/${aiPreviewSuggestions.size})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = sheetText,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { com.lorelight.utils.AiTextFilterAssistant.closePreviewDrawer() }) {
                                Icon(Icons.Default.Close, contentDescription = "Close preview", tint = sheetText)
                            }
                        }
                        Text(
                            text = "Uncheck any mapping you don't want or edit the US replacement name before saving to this novel's Text Filter.",
                            fontSize = 11.sp,
                            color = sheetText.copy(alpha = 0.6f),
                            lineHeight = 15.sp,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.weight(1f).fillMaxWidth()
                        ) {
                            itemsIndexed(aiPreviewSuggestions) { idx, item ->
                                val cardShape = RoundedCornerShape(11.dp)
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(cardShape)
                                        .background(sheetText.copy(alpha = if (item.selected) 0.075f else 0.035f))
                                        .border(
                                            width = if (item.selected) 1.dp else 0.5.dp,
                                            color = if (item.selected) sheetAccent.copy(alpha = 0.55f) else sheetText.copy(alpha = 0.10f),
                                            shape = cardShape
                                        )
                                        .clickable {
                                            val updated = aiPreviewSuggestions.toMutableList()
                                            updated[idx] = item.copy(selected = !item.selected)
                                            com.lorelight.utils.AiTextFilterAssistant.updatePreviewSuggestions(updated)
                                        }
                                        .padding(horizontal = 9.dp, vertical = 7.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text(
                                                text = item.original,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                lineHeight = 15.sp,
                                                color = sheetText,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        if (item.category == "character") {
                                            IconButton(
                                                onClick = {
                                                    val novelVal = activeNovel
                                                    if (novelVal != null) {
                                                        val usedNames = viewModel.textFilterRules.value
                                                            .filter { it.action == TextFilter.ACTION_REPLACE && it.replacement.isNotBlank() }
                                                            .map { it.replacement }
                                                            .toMutableSet()
                                                        // Exclude the current US name too, guaranteeing that refresh changes it.
                                                        if (item.replacement.isNotBlank()) usedNames.add(item.replacement)
                                                        aiPreviewSuggestions.forEachIndexed { otherIndex, other ->
                                                            if (otherIndex != idx && other.replacement.isNotBlank()) {
                                                                usedNames.add(other.replacement)
                                                            }
                                                        }
                                                        val replacement = com.lorelight.utils.LocalCharacterNameEngine.suggestRandom(
                                                            context = context,
                                                            novelId = novelVal.id,
                                                            gender = item.gender,
                                                            alreadyUsed = usedNames
                                                        )
                                                        if (replacement != null) {
                                                            val updated = aiPreviewSuggestions.toMutableList()
                                                            updated[idx] = item.copy(replacement = replacement)
                                                            com.lorelight.utils.AiTextFilterAssistant.updatePreviewSuggestions(updated)
                                                        } else {
                                                            android.widget.Toast.makeText(context, "No unused names remain for this gender", android.widget.Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                },
                                                modifier = Modifier.size(30.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Refresh,
                                                    contentDescription = "Generate a different US name",
                                                    tint = sheetAccent,
                                                    modifier = Modifier.size(17.dp)
                                                )
                                            }
                                        }
                                        if (item.selected) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = "Selected",
                                                tint = sheetAccent,
                                                modifier = Modifier.size(17.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(3.dp))
                                    OutlinedTextField(
                                        value = item.replacement,
                                        onValueChange = { newRepl ->
                                            val updated = aiPreviewSuggestions.toMutableList()
                                            updated[idx] = item.copy(replacement = newRepl)
                                            com.lorelight.utils.AiTextFilterAssistant.updatePreviewSuggestions(updated)
                                        },
                                        singleLine = true,
                                        textStyle = MaterialTheme.typography.bodySmall.copy(
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold
                                        ),
                                        label = { Text("US Name", fontSize = 9.sp) },
                                        modifier = Modifier.fillMaxWidth().height(53.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                val novelVal = activeNovel
                                if (novelVal != null) {
                                    val merged = com.lorelight.utils.AiTextFilterAssistant.mergeSuggestionsIntoRules(
                                        existingRules = viewModel.textFilterRules.value,
                                        suggestions = aiPreviewSuggestions,
                                        bookId = novelVal.id,
                                        bookTitle = novelVal.title
                                    )
                                    viewModel.saveRules(merged)
                                    val count = aiPreviewSuggestions.count { it.selected }
                                    android.widget.Toast.makeText(context, "Saved $count AI rule(s) to Text Filter!", android.widget.Toast.LENGTH_SHORT).show()
                                }
                                com.lorelight.utils.AiTextFilterAssistant.closePreviewDrawer()
                            },
                            enabled = aiPreviewSuggestions.any { it.selected && it.replacement.isNotBlank() },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = sheetAccent,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            ),
                            modifier = Modifier.fillMaxWidth().height(46.dp)
                        ) {
                            Text("Save Selected to Text Filter", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = aiErrorMessage != null && !aiIsProcessing,
            enter = fadeIn(tween(180)) + slideInVertically(initialOffsetY = { -it / 3 }),
            exit = fadeOut(tween(140)),
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 72.dp, start = 16.dp, end = 16.dp).zIndex(1003f)
        ) {
            GlassPanel(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 14.dp,
                tintAlpha = 0.94f,
                borderAlpha = 0.22f
            ) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Error notifications must remain readable regardless of the
                    // custom colour selected for novel chapter text.
                    // Notifications are app UI, never novel content: keep their
                    // text explicitly white even when the reader text is customized.
                    Text(aiErrorMessage.orEmpty(), color = Color.White, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.align(Alignment.End)) {
                        TextButton(
                            onClick = { aiErrorMessage = null },
                            colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
                        ) { Text("Dismiss", color = Color.White) }
                        Button(onClick = { aiErrorMessage = null; triggerAiLocalization() }) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("Retry")
                        }
                    }
                }
            }
        }

        // Floating Action Button/Badge for Selection Collapse (Bottom Right)
        AnimatedVisibility(
            visible = selRange != null && isSelectionPanelCollapsed,
            enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it / 2 }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 104.dp, end = 20.dp)
                .navigationBarsPadding()
                .zIndex(999f)
        ) {
            Box(
                modifier = Modifier.wrapContentSize(),
                contentAlignment = Alignment.TopEnd
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = readerBgColor.copy(alpha = 0.95f)),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, readerHighlightColor),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .padding(top = 10.dp, end = 10.dp)
                        .clickable(role = Role.Button) { isSelectionPanelCollapsed = false }
                        .wrapContentSize()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 15.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(9.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FilterList,
                            contentDescription = "Open Filter Rules Panel",
                            tint = readerHighlightColor,
                            modifier = Modifier.size(23.dp)
                        )
                        Text(
                            text = "Create Filter",
                            color = readerTextColor,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.errorContainer)
                        .border(1.dp, MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.4f), CircleShape)
                        .clickable(role = Role.Button) { 
                            selRange = null 
                            selectionVersion++
                        }
                        .align(Alignment.TopEnd),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cancel filtering",
                        tint = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
            }
        }

        // CHAPTER CONTENTS LEFT SLIDEOUT DRAWER
        AnimatedVisibility(
            visible = showChapterDrawer,
            enter = slideInHorizontally(
                initialOffsetX = { -it },
                animationSpec = tween(260, easing = FastOutSlowInEasing)
            ) + fadeIn(tween(200)),
            exit = slideOutHorizontally(
                targetOffsetX = { -it },
                animationSpec = tween(240)
            ) + fadeOut(tween(180))
        ) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(0.55f)).clickable(role = Role.Button) { showChapterDrawer = false }) {
                GlassPanel(
                    shape = RoundedCornerShape(topEnd = 24.dp, bottomEnd = 24.dp),
                    tintAlpha = 0.88f,
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .fillMaxHeight()
                        .fillMaxWidth(0.70f)
                        // Match the Display settings drawer and consume taps inside.
                        .clickable(role = Role.Button) {}
                ) {
                    Column(modifier = Modifier.fillMaxSize().padding(top = readerSafeTopPadding()).padding(16.dp)) {
                        // CHAPTER SEARCH: hidden behind the magnifier until tapped.
                        // Filtering keeps the ORIGINAL chapter index next to the title
                        // so tapping a filtered row still opens the correct chapter.
                        // Mirrored 1:1 in the manga reader's Contents drawer.
                        var chapterSearchOpen by remember { mutableStateOf(false) }
                        var chapterQuery by remember { mutableStateOf("") }
                        val filteredChapters = remember(chapters, chapterQuery) {
                            val q = chapterQuery.trim()
                            if (q.isEmpty()) chapters.withIndex().toList()
                            else chapters.withIndex().filter { it.value.contains(q, ignoreCase = true) }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(22.dp), tint = readerHighlightColor)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(stringResource(R.string.reader_contents_title), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = readerTextColor, modifier = Modifier.weight(1f))
                            IconButton(onClick = {
                                chapterSearchOpen = !chapterSearchOpen
                                if (!chapterSearchOpen) chapterQuery = ""
                            }) {
                                Icon(
                                    Icons.Default.Search,
                                    contentDescription = "Search chapters",
                                    tint = if (chapterSearchOpen) readerHighlightColor else readerTextColor
                                )
                            }
                            IconButton(onClick = { showChapterDrawer = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = readerTextColor)
                            }
                        }
                        HorizontalDivider(color = readerTextColor.copy(alpha = 0.15f), modifier = Modifier.padding(vertical = 12.dp))
                        AnimatedVisibility(visible = chapterSearchOpen) {
                            OutlinedTextField(
                                value = chapterQuery,
                                onValueChange = { chapterQuery = it },
                                singleLine = true,
                                placeholder = {
                                    Text(
                                        "Search chapters",
                                        fontSize = 14.sp,
                                        color = readerTextColor.copy(alpha = 0.5f)
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        Icons.Default.Search,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                        tint = readerHighlightColor
                                    )
                                },
                                trailingIcon = {
                                    if (chapterQuery.isNotEmpty()) {
                                        IconButton(onClick = { chapterQuery = "" }) {
                                            Icon(
                                                Icons.Default.Close,
                                                contentDescription = "Clear search",
                                                modifier = Modifier.size(16.dp),
                                                tint = readerTextColor.copy(alpha = 0.7f)
                                            )
                                        }
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = readerHighlightColor,
                                    unfocusedBorderColor = readerTextColor.copy(alpha = 0.25f),
                                    focusedTextColor = readerTextColor,
                                    unfocusedTextColor = readerTextColor,
                                    cursorColor = readerHighlightColor
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp)
                            )
                        }
                        // Novel-side dim comes from the same store as the details
                        // list now, instead of a list of chapter NAME strings that
                        // only the TTS path ever appended to.
                        val tocStateFlow = remember(activeNovel?.id) {
                            com.lorelight.data.chapters.ChapterReadStore
                                .observe(context, activeNovel?.id ?: "")
                        }
                        val tocState by tocStateFlow.collectAsState()
                        val completedChapterIndices = remember(tocState, activeNovel) {
                            val n = activeNovel
                            if (n == null) {
                                emptySet()
                            } else {
                                val completed = com.lorelight.data.chapters.ChapterReadStore.completedIndices(n, tocState)
                                // The current reading position means every chapter up to
                                // and including it has already been reached. Keep those
                                // rows dim even if the reader has not hit the chapter's
                                // final page yet; chapters after it stay bright.
                                val currentIndex = com.lorelight.data.chapters.ChapterReadStore.currentIndex(n, tocState)
                                if (currentIndex >= 0) completed + (0..currentIndex).toSet() else completed
                            }
                        }
                        com.lorelight.ui.components.VerticalFastScroller(
                            listState = chaptersListState,
                            thumbColor = readerHighlightColor,
                            modifier = Modifier.weight(1f)
                        ) {
                            LazyColumn(state = chaptersListState, verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxSize()) {
                                if (filteredChapters.isEmpty()) {
                                    item {
                                        Text(
                                            text = "No chapters match \"${chapterQuery.trim()}\"",
                                            fontSize = 13.sp,
                                            color = readerTextColor.copy(alpha = 0.6f),
                                            modifier = Modifier.padding(vertical = 24.dp)
                                        )
                                    }
                                }
                                itemsIndexed(filteredChapters) { _, entry ->
                                    val index = entry.index
                                    val chTitle = entry.value
                                    val isActive = index == activeChapterIndex
                                    val isCompleted = completedChapterIndices.contains(index)
                                    val isCached = cachedChapterIndices.contains(index)
                                    ChapterRowItem(
                                        index = index,
                                        chTitle = chTitle,
                                        isActive = isActive,
                                        isCompleted = isCompleted,
                                        isCached = isCached,
                                        readerHighlightColor = readerHighlightColor,
                                        readerTextColor = readerTextColor,
                                        onClick = { 
                                            viewModel.selectChapter(index)
                                            showChapterDrawer = false 
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Animated Bottom Settings Sheet Drawer containing layout formatting, voice selections, and text filters
        ReaderSettingsSheet(
            showSettingsDialog = showSettingsDialog,
            onDismissSettings = { showSettingsDialog = false },
            showTextFilterPanel = showTextFilterPanel,
            onSetTextFilterPanelVisible = { showTextFilterPanel = it },
            viewModel = viewModel,
            activeNovel = activeNovel,
            readerTextColor = readerTextColor,
            readerHighlightColor = readerHighlightColor,
            themeState = themeState,
            onOpenFontManager = onOpenFontManager,
            onResetSelection = {
                selRange = null
                selectionVersion++
                isSelectionPanelCollapsed = true
            }
        )

        if (showBatteryOptimizationDialog) {
            LorelightDialog(
                onDismissRequest = {
                    viewModel.dismissBatteryOptimizationDialog(dontAskAgain = false)
                },
                title = {
                    Text(
                        text = "Uninterrupted Reading",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = "Lorelight requires battery exemption to provide continuous, uninterruptible background text-to-speech reading sessions even when your screen is off.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.launchBatteryExemptionIntent(context)
                            viewModel.dismissBatteryOptimizationDialog(dontAskAgain = true)
                        }
                    ) {
                        Text(stringResource(R.string.reader_permission_allow))
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            viewModel.dismissBatteryOptimizationDialog(dontAskAgain = false)
                        }
                    ) {
                        Text(stringResource(R.string.reader_permission_keep_default))
                    }
                }
            )
        }
    }
}

@Composable
fun ChapterRowItem(
    index: Int,
    chTitle: String,
    isActive: Boolean,
    isCompleted: Boolean,
    isCached: Boolean,
    readerHighlightColor: Color,
    readerTextColor: Color,
    onClick: () -> Unit
) {
    val textWeight = if (isActive && !isCompleted) FontWeight.Bold else if (isCompleted) FontWeight.Medium else FontWeight.Normal
    // Read/watched chapters are dim; chapters beyond the reading position stay bright.
    val titleColor = if (isCompleted) readerTextColor.copy(alpha = 0.48f) else if (isActive) readerHighlightColor else readerTextColor
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = if (isActive) readerHighlightColor.copy(alpha = 0.15f) else Color.Transparent),
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = chTitle,
                fontWeight = textWeight,
                fontStyle = if (isCompleted) FontStyle.Italic else FontStyle.Normal,
                fontSize = 14.sp,
                color = titleColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            if (isCached) {
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.Download,
                    tint = readerHighlightColor,
                    contentDescription = "Downloaded",
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

/**
 * Single place that writes the reader's scroll position. Computes the
 * last-visible fraction the same way Grimoire does, so progress survives a
 * later font-size change (FIX #12).
 */
/**
 * Hand the reader's position to the library repository.
 *
 * This used to be half the job. Three of the four call sites also had to
 * remember to call saveDetailedProgress straight afterwards, because a reader
 * position has two destinations: an immediate exact-position write, and a
 * buffered one that coalesces and flushes on its own schedule. Nothing
 * enforced that pairing, so getting it right was left to whoever edited next.
 *
 * The fourth call site - the debounced save a beat after scrolling settles -
 * deliberately does NOT want the buffered write, which is why
 * recordDetailedProgress is optional rather than always-on. Firing it on every
 * scroll settle is the battery regression TtsPlaybackManager warns about.
 *
 * What stays here is only the part that genuinely belongs to the UI: reading
 * the numbers out of the Compose list state.
 */
private fun persistReaderPosition(
    context: android.content.Context,
    novelId: String,
    chapterIndex: Int,
    listState: androidx.compose.foundation.lazy.LazyListState,
    layoutSig: Int,
    wordIndex: Int = -1,
    recordDetailedProgress: ((Int, Int, Int) -> Unit)? = null
) {
    val info = listState.layoutInfo
    LibraryRepository.recordReaderPosition(
        context = context,
        novelId = novelId,
        chapterIndex = chapterIndex,
        itemIndex = listState.firstVisibleItemIndex,
        offset = listState.firstVisibleItemScrollOffset,
        totalItems = info.totalItemsCount,
        lastVisibleIndex = info.visibleItemsInfo.lastOrNull()?.index
            ?: listState.firstVisibleItemIndex,
        layoutSig = layoutSig,
        wordIndex = wordIndex,
        recordDetailedProgress = recordDetailedProgress
    )
}

/**
 * FIX #17: the chapter loader injects status messages into the CONTENT list as
 * real ReaderBlock.TextBlock items instead of using separate UI state. They must
 * never be treated as chapter text when restoring a scroll position.
 *
 * Keep this in sync with the updateSentences(...) calls in TtsPlaybackManager
 * (currently around lines 967, 1016, 1034, 1037 and 1077) and with
 * isChapterFetchFailure() in the same file.
 */
private fun friendlyReaderError(raw: String): String {
    val trimmed = raw.trim()
    // The crawler already writes a plain, specific reason after this prefix
    // (offline vs. site blocked vs. site down, etc.). Show it as-is instead of
    // squashing different problems into one "check your internet" message.
    val prefixes = listOf("Couldn't load chapter:", "Couldn't load this chapter:")
    prefixes.firstOrNull { trimmed.startsWith(it) }?.let { prefix ->
        val reason = trimmed.removePrefix(prefix).trim()
        if (reason.isNotEmpty()) return reason
    }
    return when (trimmed) {
        "No content extracted.", "Failed to load chapter content.",
        "This chapter came back empty from the source." ->
            "The site sent this chapter without any readable text. Try again later, or open it in Browse."
        "Invalid chapter link." ->
            "This chapter's link is broken. Try refreshing the chapter list."
        "Chapter text not found or cleared from cache.",
        "Chapter text could not be loaded from EPUB." ->
            "This chapter's text isn't saved on this device anymore."
        "This chapter isn't available yet. It may still be downloading — please try again." ->
            "This chapter isn't available yet. It may still be downloading. Please try again."
        else -> when {
            trimmed.startsWith("EPUB file not found on disk") ->
                "The EPUB file for this book is missing from this device."
            trimmed.startsWith("Chapter entry not found in EPUB") ||
                trimmed.startsWith("Failed to lazy load chapter") ->
                "This chapter couldn't be read from the EPUB file."
            else -> "Lorelight couldn't load this chapter. Please try again."
        }
    }
}

private val READER_PLACEHOLDER_TEXTS = setOf(
    "Loading chapter...",
    "Loading next chapter...",
    "Chapter content is empty.",
    "Chapter content is empty or could not be loaded.",
    "This chapter isn't available yet. Please try again.",
    "Failed to load chapter content.",
    "No content extracted."
)

private fun isPlaceholderContent(blocks: List<ReaderBlock>): Boolean {
    if (blocks.size != 1) return false
    val b = blocks.firstOrNull()
    return b is ReaderBlock.TextBlock &&
        (b.text in READER_PLACEHOLDER_TEXTS || com.lorelight.crawler.CrawlerEngine.isFailureText(b.text))
}


