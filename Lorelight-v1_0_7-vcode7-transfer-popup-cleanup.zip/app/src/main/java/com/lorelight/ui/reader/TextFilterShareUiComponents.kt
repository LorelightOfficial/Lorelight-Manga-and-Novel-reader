package com.lorelight.ui.reader

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.Manifest
import android.content.pm.PackageManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Image as GalleryIcon
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Surface
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import com.journeyapps.barcodescanner.DecoratedBarcodeView
import com.journeyapps.barcodescanner.BarcodeCallback
import com.journeyapps.barcodescanner.BarcodeResult
import com.lorelight.utils.ClashItem
import com.lorelight.utils.ClashType
import com.lorelight.utils.FilterRule
import com.lorelight.utils.ImportPlan
import com.lorelight.utils.SharedFilterPackage
import com.lorelight.utils.TextFilter
import com.lorelight.utils.TextFilterImportPlanner
import com.lorelight.utils.TextFilterRelay
import com.lorelight.utils.TextFilterShareEncoder
import com.lorelight.ui.theme.GlassPanel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.lorelight.ui.theme.GlassDropdownMenu
import com.lorelight.ui.components.LorelightDialog

// ---------------------------------------------------------------------------------
// Entry point: one composable the filter panel's header drops in.
// ---------------------------------------------------------------------------------

/**
 * The share/receive button for the "Manage Text Filter" header, plus every dialog it
 * opens. It owns all of its own state, so the panel only has to pass the rules in and
 * a way to save them back.
 *
 * @param allRules     every stored rule (used to find conflicts)
 * @param visibleRules the rules shown in the panel for the open novel (what can be shared)
 * @param onSaveRules  persists the full rule list
 */
@Composable
fun TextFilterShareActions(
    novelId: String,
    novelTitle: String,
    allRules: List<FilterRule>,
    visibleRules: List<FilterRule>,
    onSaveRules: (List<FilterRule>) -> Unit,
    tint: Color
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var pageOpen by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<Pair<SharedFilterPackage, ImportPlan>?>(null) }

    fun toast(message: String) = Toast.makeText(context, message, Toast.LENGTH_LONG).show()

    fun handleCode(raw: String) {
        // Claim the scan synchronously: continuous QR callbacks can arrive several
        // times before the coroutine gets scheduled.
        if (busy) return
        busy = true
        scope.launch {
            try {
                val code = raw.trim()
                val payload = if (code.startsWith(TextFilterShareEncoder.PREFIX_RELAY)) {
                    TextFilterRelay.download(code)
                } else code
                if (payload == null) {
                    toast("Couldn't download those filters. Check your connection and try again.")
                    return@launch
                }
                val pkg = withContext(Dispatchers.Default) { TextFilterShareEncoder.decodePayload(payload) }
                if (pkg == null) {
                    toast("That isn't a Lorelight filter code.")
                    return@launch
                }
                val plan = withContext(Dispatchers.Default) {
                    TextFilterImportPlanner.plan(pkg, allRules, novelId, novelTitle)
                }
                if (plan.clean.isEmpty() && plan.clashes.isEmpty()) {
                    toast(if (plan.alreadyHave > 0) "You already have all of these rules." else "That code has no rules in it.")
                } else {
                    pending = pkg to plan
                    pageOpen = false
                }
            } catch (_: Exception) {
                toast("Couldn't read that filter share. Please try again.")
            } finally {
                busy = false
            }
        }
    }

    IconButton(onClick = { pageOpen = true }) {
        Icon(Icons.Default.Share, contentDescription = "Share or receive filters", tint = tint)
    }

    if (pageOpen) {
        TextFilterSharePage(
            novelTitle = novelTitle,
            rules = visibleRules,
            busy = busy,
            onReceiveCode = { handleCode(it) },
            onDismiss = { if (!busy) pageOpen = false }
        )
    }

    pending?.let { (pkg, plan) ->
        ClashResolutionDialog(
            sourceTitle = pkg.novelTitle,
            plan = plan,
            onAccept = { applyClashes ->
                onSaveRules(TextFilterImportPlanner.apply(plan, allRules, applyClashes))
                val added = plan.clean.size + if (applyClashes) plan.clashes.size else 0
                toast("Imported $added rule${if (added == 1) "" else "s"}")
                pending = null
            },
            onDismiss = { pending = null }
        )
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TextFilterSharePage(
    novelTitle: String,
    rules: List<FilterRule>,
    busy: Boolean,
    onReceiveCode: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    var selectedTab by remember { mutableStateOf(0) }
    var includeAi by remember { mutableStateOf(true) }
    var includeThisBook by remember { mutableStateOf(true) }
    var includeAllBooks by remember { mutableStateOf(false) }
    var relayCode by remember { mutableStateOf<String?>(null) }
    var uploading by remember { mutableStateOf(false) }
    var pasted by remember { mutableStateOf("") }
    var cameraGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    var cameraRequestDenied by remember { mutableStateOf(false) }
    var scanResultHandled by remember { mutableStateOf(false) }
    var galleryBusy by remember { mutableStateOf(false) }

    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        cameraGranted = granted
        cameraRequestDenied = !granted
    }
    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            scope.launch {
                galleryBusy = true
                val code = withContext(Dispatchers.IO) { decodeQrFromImage(context, uri) }
                galleryBusy = false
                if (code == null) Toast.makeText(context, "No readable QR code found in that image.", Toast.LENGTH_LONG).show()
                else onReceiveCode(code)
            }
        }
    }

    val chosen = remember(rules, includeAi, includeThisBook, includeAllBooks) {
        rules.filter { rule ->
            val scopeOk = if (rule.scope == TextFilter.SCOPE_ALL) includeAllBooks else includeThisBook
            val aiOk = rule.source != TextFilter.SOURCE_AI || includeAi
            scopeOk && aiOk
        }
    }
    val offlineCode = remember(chosen, novelTitle) {
        if (chosen.isEmpty()) "" else TextFilterShareEncoder.encodeRules(novelTitle, chosen)
    }
    val tooBigForOfflineQr = offlineCode.length > TextFilterShareEncoder.MAX_OFFLINE_QR_CHARS
    val tooBigForFirebase = offlineCode.toByteArray(Charsets.UTF_8).size > TextFilterRelay.MAX_FIRESTORE_PAYLOAD_BYTES
    val qrText = if (!tooBigForOfflineQr) offlineCode.takeIf { it.isNotBlank() } else relayCode
    val qrBitmap = remember(qrText) { qrText?.let { makeQrBitmap(it, 800) } }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
    ) {
        GlassPanel(
            modifier = Modifier.fillMaxSize(),
            cornerRadius = 0.dp,
            tintAlpha = 0.92f,
            borderAlpha = 0.16f
        ) {
            Column(
                modifier = Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Share Text Filters", style = MaterialTheme.typography.headlineSmall)
                        Text("Move your rules between Lorelight devices", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onDismiss, enabled = !busy) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Surface(
                    shape = RoundedCornerShape(28.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.35f))
                ) {
                    Row(Modifier.padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("Share", "Receive").forEachIndexed { index, label ->
                            Surface(
                                modifier = Modifier.weight(1f).clickable { selectedTab = index },
                                shape = RoundedCornerShape(24.dp),
                                color = if (selectedTab == index) MaterialTheme.colorScheme.primary else Color.Transparent
                            ) {
                                Box(Modifier.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                                    Text(label, color = if (selectedTab == index) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.titleSmall)
                                }
                            }
                        }
                    }
                }

                if (selectedTab == 0) {
                    Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("Choose what to include", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            FilterChip(selected = includeAi, onClick = { includeAi = !includeAi }, label = { Text("AI ✨") })
                            FilterChip(selected = includeThisBook, onClick = { includeThisBook = !includeThisBook }, label = { Text("This book") })
                            FilterChip(selected = includeAllBooks, onClick = { includeAllBooks = !includeAllBooks }, label = { Text("All books") })
                        }
                        Surface(
                            modifier = Modifier.fillMaxWidth().weight(1f).widthIn(max = 440.dp),
                            shape = RoundedCornerShape(28.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.78f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.28f))
                        ) {
                            Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                when {
                                    chosen.isEmpty() -> Text("Select at least one filter group that contains rules.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    qrBitmap != null -> {
                                        Surface(shape = RoundedCornerShape(20.dp), color = Color.White, modifier = Modifier.widthIn(max = 290.dp).fillMaxWidth().aspectRatio(1f)) {
                                            Image(bitmap = qrBitmap.asImageBitmap(), contentDescription = "Shareable Lorelight filter QR code", modifier = Modifier.fillMaxSize().padding(12.dp))
                                        }
                                        Spacer(Modifier.height(12.dp))
                                        Text("Ready to scan", style = MaterialTheme.typography.titleMedium)
                                        Text("Anyone scanning this QR can import the selected rules.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    uploading -> CircularProgressIndicator()
                                    tooBigForFirebase -> Text("This package is too large for a single share. Reduce the selected filters and try again.", color = MaterialTheme.colorScheme.error)
                                    tooBigForOfflineQr -> {
                                        Text("${chosen.size} rules need a temporary online share.", style = MaterialTheme.typography.bodyMedium)
                                        Button(
                                            enabled = !uploading,
                                            onClick = {
                                                uploading = true
                                                scope.launch {
                                                    val code = TextFilterRelay.upload(offlineCode)
                                                    uploading = false
                                                    if (code == null) Toast.makeText(context, "Upload failed. Check your connection and Firebase setup.", Toast.LENGTH_LONG).show()
                                                    else relayCode = code
                                                }
                                            }
                                        ) { Text("Create QR (valid for 1 hour)") }
                                    }
                                    else -> Text("Preparing QR code…")
                                }
                            }
                        }
                        Text("${chosen.size} rule${if (chosen.size == 1) "" else "s"} selected", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                enabled = qrBitmap != null,
                                onClick = {
                                    copyToClipboard(context, offlineCode)
                                    Toast.makeText(context, "Share code copied.", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("Copy code")
                            }
                            Button(
                                enabled = qrBitmap != null,
                                onClick = {
                                    qrBitmap?.let { bitmap ->
                                        try {
                                            val shareDir = File(context.cacheDir, "shared_qr").apply { mkdirs() }
                                            val imageFile = File(shareDir, "lorelight-filter-qr.png")
                                            FileOutputStream(imageFile).use { stream ->
                                                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
                                            }
                                            val imageUri = FileProvider.getUriForFile(
                                                context,
                                                "${context.packageName}.fileprovider",
                                                imageFile
                                            )
                                            val intent = Intent(Intent.ACTION_SEND).apply {
                                                type = "image/png"
                                                putExtra(Intent.EXTRA_STREAM, imageUri)
                                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                            }
                                            context.startActivity(Intent.createChooser(intent, "Share QR image"))
                                        } catch (_: Exception) {
                                            Toast.makeText(context, "Couldn't share the QR image. You can still scan it from this screen.", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("Share")
                            }
                        }
                    }
                } else {
                    Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Scan a Lorelight QR code", style = MaterialTheme.typography.titleMedium)
                        Surface(
                            modifier = Modifier.fillMaxWidth().weight(1f).widthIn(max = 480.dp).align(Alignment.CenterHorizontally),
                            shape = RoundedCornerShape(28.dp),
                            color = Color(0xFF07120F),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                        ) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                when {
                                    cameraGranted -> InAppFilterQrScanner(
                                        modifier = Modifier.fillMaxSize().padding(12.dp),
                                        onCode = { code -> if (!scanResultHandled) { scanResultHandled = true; onReceiveCode(code) } }
                                    )
                                    else -> Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(24.dp)) {
                                        Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(48.dp))
                                        Text("Camera access is needed to scan a QR code.", color = Color.White)
                                        Button(onClick = { cameraPermission.launch(Manifest.permission.CAMERA) }) { Text(if (cameraRequestDenied) "Allow camera access" else "Enable scanner") }
                                    }
                                }
                            }
                        }
                        Text("Align the QR code inside the frame. Scanning starts automatically.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = { galleryLauncher.launch("image/*") }, enabled = !galleryBusy && !busy, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.GalleryIcon, contentDescription = null)
                                Spacer(Modifier.width(7.dp))
                                Text("Choose from gallery")
                            }
                            OutlinedButton(onClick = { scanResultHandled = false; pasted = "" }, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                                Spacer(Modifier.width(7.dp))
                                Text("Reset scanner")
                            }
                        }
                        OutlinedTextField(
                            value = pasted,
                            onValueChange = { pasted = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("Or paste a share code") },
                            singleLine = true,
                            enabled = !busy
                        )
                        Button(
                            onClick = { onReceiveCode(pasted) },
                            enabled = !busy && TextFilterShareEncoder.isShareCode(pasted),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                            else Text("Import pasted code")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InAppFilterQrScanner(
    modifier: Modifier = Modifier,
    onCode: (String) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val latestOnCode by rememberUpdatedState(onCode)
    val barcodeView = remember {
        DecoratedBarcodeView(context).apply {
            setStatusText("")
            viewFinder.setLaserVisibility(false)
        }
    }
    AndroidView(
        modifier = modifier,
        factory = { barcodeView },
        update = { view ->
            view.decodeContinuous(object : BarcodeCallback {
                override fun barcodeResult(result: BarcodeResult?) {
                    val text = result?.text
                    if (!text.isNullOrBlank()) latestOnCode(text)
                }
                override fun possibleResultPoints(resultPoints: List<com.google.zxing.ResultPoint>?) = Unit
            })
        }
    )
    DisposableEffect(lifecycleOwner, barcodeView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> barcodeView.resume()
                Lifecycle.Event.ON_PAUSE -> barcodeView.pause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
            barcodeView.resume()
        }
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            barcodeView.pause()
        }
    }
    val transition = rememberInfiniteTransition(label = "qr-scan")
    val scanY by transition.animateFloat(
        initialValue = 0.12f,
        targetValue = 0.88f,
        animationSpec = infiniteRepeatable(tween(1700), repeatMode = RepeatMode.Reverse),
        label = "scan-line"
    )
    Canvas(modifier = Modifier.fillMaxSize().padding(34.dp)) {
        val left = size.width * 0.08f
        val right = size.width * 0.92f
        val y = size.height * scanY
        drawLine(
            color = Color(0xFF8DBB5D),
            start = Offset(left, y),
            end = Offset(right, y),
            strokeWidth = 3.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun ShareReceiveDropdownMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    onShareClicked: () -> Unit,
    onReceiveClicked: () -> Unit
) {
    GlassDropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(
            text = { Text("Share Filters") },
            leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) },
            onClick = { onDismiss(); onShareClicked() }
        )
        DropdownMenuItem(
            text = { Text("Receive Filters") },
            leadingIcon = { Icon(Icons.Default.Download, contentDescription = null) },
            onClick = { onDismiss(); onReceiveClicked() }
        )
    }
}

// ---------------------------------------------------------------------------------
// Share: choose what to include, show the QR
// ---------------------------------------------------------------------------------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GenerateQrCodeDialog(
    novelTitle: String,
    rules: List<FilterRule>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var includeAi by remember { mutableStateOf(true) }
    var includeThisBook by remember { mutableStateOf(true) }
    var includeAllBooks by remember { mutableStateOf(false) }

    val chosen = remember(rules, includeAi, includeThisBook, includeAllBooks) {
        rules.filter { rule ->
            val scopeOk = if (rule.scope == TextFilter.SCOPE_ALL) includeAllBooks else includeThisBook
            val aiOk = rule.source != TextFilter.SOURCE_AI || includeAi
            scopeOk && aiOk
        }
    }

    val offlineCode = remember(chosen, novelTitle) {
        if (chosen.isEmpty()) "" else TextFilterShareEncoder.encodeRules(novelTitle, chosen)
    }
    val tooBigForOfflineQr = offlineCode.length > TextFilterShareEncoder.MAX_OFFLINE_QR_CHARS
    val tooBigForFirebase = offlineCode.toByteArray(Charsets.UTF_8).size > TextFilterRelay.MAX_FIRESTORE_PAYLOAD_BYTES

    var relayCode by remember(offlineCode) { mutableStateOf<String?>(null) }
    var uploading by remember { mutableStateOf(false) }
    var showUploadConfirm by remember { mutableStateOf(false) }

    val qrText = when {
        chosen.isEmpty() -> null
        !tooBigForOfflineQr -> offlineCode
        else -> relayCode
    }
    val qrBitmap = remember(qrText) { qrText?.let { makeQrBitmap(it) } }

    LorelightDialog(
        onDismissRequest = onDismiss,
        title = { Text("Share Text Filters") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Include:", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilterChip(selected = includeAi, onClick = { includeAi = !includeAi }, label = { Text("AI \u2728") })
                    FilterChip(selected = includeThisBook, onClick = { includeThisBook = !includeThisBook }, label = { Text("This book") })
                    FilterChip(selected = includeAllBooks, onClick = { includeAllBooks = !includeAllBooks }, label = { Text("All books") })
                }
                Spacer(Modifier.height(12.dp))

                when {
                    chosen.isEmpty() -> Text(
                        "Nothing selected. Pick at least one group that has rules.",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                    qrBitmap != null -> Box(
                        modifier = Modifier
                            .size(220.dp)
                            .background(Color.White, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(bitmap = qrBitmap.asImageBitmap(), contentDescription = "QR code", modifier = Modifier.size(204.dp))
                    }
                    tooBigForOfflineQr && uploading -> Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(10.dp))
                        Text("Uploading\u2026", style = MaterialTheme.typography.bodyMedium)
                    }
                    tooBigForOfflineQr && tooBigForFirebase -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "This package exceeds the Firebase share-size limit. Split the filters into smaller groups or copy the code instead.",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    tooBigForOfflineQr -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "${chosen.size} rules is too much for one offline QR code.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(Modifier.height(6.dp))
                        Button(onClick = { showUploadConfirm = true }) { Text("Create share QR (1 hour)") }
                    }
                    else -> Text("Couldn't make a QR code.", color = MaterialTheme.colorScheme.error)
                }

                Spacer(Modifier.height(8.dp))
                Text("${chosen.size} rule${if (chosen.size == 1) "" else "s"} included", style = MaterialTheme.typography.labelMedium)

                if (chosen.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(onClick = {
                        copyToClipboard(context, offlineCode)
                        Toast.makeText(context, "Code copied. Paste it in Receive Filters on the other device.", Toast.LENGTH_LONG).show()
                    }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Copy code instead")
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } }
    )

    if (showUploadConfirm) {
        LorelightDialog(
            onDismissRequest = { showUploadConfirm = false },
            title = { Text("Upload these filters?") },
            text = {
                Text(
                    "The selected filters will be uploaded to Lorelight's Firebase share database. Anyone with the QR code can import them for 1 hour. The share then becomes unreadable automatically. No account or sign-in screen is shown. You can use \"Copy code instead\" to keep sharing offline."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showUploadConfirm = false
                    uploading = true
                    scope.launch {
                        val code = TextFilterRelay.upload(offlineCode)
                        uploading = false
                        if (code == null) {
                            Toast.makeText(context, "Firebase share failed. Check your connection and Firebase setup, or copy the code instead.", Toast.LENGTH_LONG).show()
                        } else {
                            relayCode = code
                        }
                    }
                }) { Text("Create QR") }
            },
            dismissButton = { TextButton(onClick = { showUploadConfirm = false }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------------------------
// Receive: scan / gallery / paste
// ---------------------------------------------------------------------------------

@Composable
fun ReceiveFiltersDialog(
    busy: Boolean,
    onScan: () -> Unit,
    onGallery: () -> Unit,
    onSubmitCode: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var pasted by remember { mutableStateOf("") }

    LorelightDialog(
        onDismissRequest = onDismiss,
        title = { Text("Receive Filters") },
        text = {
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Scan the QR code on the other device. \"This book\" rules are attached to the novel you have open now.",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(onClick = onScan, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Scan QR code")
                }
                OutlinedButton(onClick = onGallery, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.GalleryIcon, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Scan from gallery")
                }
                OutlinedTextField(
                    value = pasted,
                    onValueChange = { pasted = it },
                    label = { Text("Or paste a code") },
                    singleLine = true,
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(
                        onClick = { onSubmitCode(pasted) },
                        enabled = !busy && TextFilterShareEncoder.isShareCode(pasted)
                    ) { Text("Import pasted code") }
                    if (busy) {
                        Spacer(Modifier.width(8.dp))
                        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss, enabled = !busy) { Text("Close") } }
    )
}

// ---------------------------------------------------------------------------------
// Review what will change before anything is saved
// ---------------------------------------------------------------------------------

@Composable
fun ClashResolutionDialog(
    sourceTitle: String,
    plan: ImportPlan,
    onAccept: (applyClashes: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    var applyClashes by remember { mutableStateOf(false) }
    val clashes = plan.clashes
    val willImport = plan.clean.size + if (applyClashes) clashes.size else 0

    LorelightDialog(
        onDismissRequest = onDismiss,
        title = { Text("Import filters from \u201C$sourceTitle\u201D") },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("${plan.clean.size} new rule${if (plan.clean.size == 1) "" else "s"} ready to import.")
                if (plan.alreadyHave > 0) {
                    Text(
                        "${plan.alreadyHave} you already have will be skipped.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (clashes.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .clickable { expanded = !expanded }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "${clashes.size} conflict${if (clashes.size == 1) "" else "s"}",
                            modifier = Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = if (expanded) "Hide" else "Show")
                    }

                    if (expanded) {
                        Spacer(Modifier.height(8.dp))
                        LazyColumn(modifier = Modifier.height(170.dp)) {
                            items(clashes) { clash -> ClashRow(clash) }
                        }
                    }

                    Spacer(Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { applyClashes = !applyClashes }
                    ) {
                        Checkbox(checked = applyClashes, onCheckedChange = { applyClashes = it })
                        Column {
                            Text("Also apply the conflicting rules", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                "Same original text replaces your rule. Same name is added next to yours.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onAccept(applyClashes) }, enabled = willImport > 0) {
                Text("Import $willImport")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun ClashRow(clash: ClashItem) {
    val incomingText = if (clash.incoming.action == TextFilter.ACTION_REPLACE) {
        "${clash.incoming.original} \u2192 ${clash.incoming.replacement}"
    } else {
        "${clash.incoming.original} \u2192 (hide)"
    }
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text("Incoming: $incomingText", style = MaterialTheme.typography.labelMedium)
            Text(
                (if (clash.clashType == ClashType.INITIAL) "Same original \u2014 " else "Same name \u2014 ") + clash.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

// ---------------------------------------------------------------------------------
// QR helpers
// ---------------------------------------------------------------------------------

private fun makeQrBitmap(text: String, size: Int = 640): Bitmap? = try {
    val hints = mapOf(
        EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.L, // most room for data
        EncodeHintType.CHARACTER_SET to "UTF-8",
        EncodeHintType.MARGIN to 2
    )
    val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
    val w = matrix.width
    val h = matrix.height
    val pixels = IntArray(w * h)
    for (y in 0 until h) {
        for (x in 0 until w) {
            pixels[y * w + x] = if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE
        }
    }
    Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
} catch (e: Exception) {
    null
}

/** Reads a QR code out of a picked image (screenshot or photo). Null when none is found. */
private fun decodeQrFromImage(context: Context, uri: Uri): String? {
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 2000) sample *= 2
        val bitmap = context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample })
        } ?: return null
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        bitmap.recycle()

        val source = RGBLuminanceSource(w, h, pixels)
        val reader = MultiFormatReader().apply {
            setHints(
                mapOf(
                    DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
                    DecodeHintType.TRY_HARDER to true
                )
            )
        }
        try {
            reader.decodeWithState(BinaryBitmap(HybridBinarizer(source))).text
        } catch (e: Exception) {
            // Dark-mode screenshots: the code is light on dark, so try it inverted.
            reader.decodeWithState(BinaryBitmap(HybridBinarizer(source.invert()))).text
        }
    } catch (e: Exception) {
        null
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Lorelight filters", text))
}
