package com.lorelight.ui.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.data.download.DownloadJobState
import com.lorelight.data.download.DownloadProgressBus
import kotlinx.coroutines.launch

// ───────────────────────── Filter enum ─────────────────────────

private enum class QueueFilter(val label: String) {
    ACTIVE("Active"), FAILED("Failed"), FINISHED("Finished")
}

/**
 * Three tabs, and every job belongs to exactly one of them.
 *
 *  - Active: still on its way -- downloading, waiting its turn, or paused.
 *  - Failed: stopped on an error.
 *  - Finished: the history. Completed and stopped jobs stay here until they
 *    are deleted by hand.
 */
private fun DownloadJobState.matches(f: QueueFilter) = when (f) {
    QueueFilter.ACTIVE   -> !isFinished
    QueueFilter.FAILED   -> isFailed
    QueueFilter.FINISHED -> isDone || isCancelled
}

// ───────────────────────── Entry point ─────────────────────────

/**
 * Download Manager — full redesign from scratch.
 *
 * [onOpenDetails] is called with the job's novelId when a completed
 * entry is tapped. Pass an empty lambda (the default) to disable navigation.
 * All DownloadProgressBus wiring is preserved.
 */
@Composable
fun DownloadsQueueScreen(
    onBack: () -> Unit,
    onOpenDetails: (novelId: String) -> Unit = {}
) {
    val queue = DownloadProgressBus.queue
    val scope   = rememberCoroutineScope()
    var filter  by remember { mutableStateOf(QueueFilter.ACTIVE) }

    val visible by remember(queue, filter) { derivedStateOf { queue.filter { it.matches(filter) } } }
    val running by remember(queue) { derivedStateOf { queue.count { !it.isFinished && !it.isPaused } } }

    com.lorelight.ui.theme.GlassPanel(
        modifier = Modifier.fillMaxSize(),
        cornerRadius = 0.dp,
        tintAlpha = 1f
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
        // ───────────────────────── Header ─────────────────────────
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.38f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(start = 8.dp, end = 8.dp, top = 6.dp, bottom = 8.dp)) {
                // Title row
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Close, "Close", tint = MaterialTheme.colorScheme.onSurface, modifier = Modifier.size(20.dp))
                    }
                    Spacer(Modifier.width(4.dp))
                    // The title and its status line sit in one tight Column.
                    // The line height of the 19sp title used to be left at the
                    // default, which reserved a band of empty space under it
                    // before the status line began; both are pinned now so the
                    // two rows read as one block.
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "Download Manager",
                                fontSize = 19.sp, fontWeight = FontWeight.Bold,
                                lineHeight = 22.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (running > 0) LiveIndicator()
                        }
                        val total = queue.size
                        Text(
                            when {
                                total == 0   -> "No jobs queued"
                                running > 0  -> "$running running · $total total"
                                else         -> "$total job${if (total == 1) "" else "s"}"
                            },
                            fontSize = 11.sp,
                            lineHeight = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f)
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))

                // Filter pills
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(QueueFilter.entries) { f ->
                        val active = filter == f
                        val count  = queue.count { it.matches(f) }
                        val bg by animateColorAsState(
                            if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                            else MaterialTheme.colorScheme.surface.copy(alpha = 0.55f),
                            label = "fBg"
                        )
                        val bd by animateColorAsState(
                            if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
                            else MaterialTheme.colorScheme.outline.copy(alpha = 0.20f),
                            label = "fBd"
                        )
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(bg)
                                .border(1.dp, bd, CircleShape)
                                .clickable(role = Role.Button) { filter = f }
                                .padding(horizontal = 14.dp, vertical = 7.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                                Text(
                                    f.label,
                                    fontSize = 12.sp,
                                    fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
                                    color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (count > 0) {
                                    Text(
                                        "$count",
                                        fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                        color = if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.75f)
                                               else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.50f)
                                    )
                                }
                            }
                        }
                    }
                }

                // History housekeeping. Finished is a record, so it gets one
                // bulk action instead of making you delete rows one at a time.
                // It clears only what this tab shows -- failed jobs are left
                // alone so nothing you might still want to retry disappears.
                if (filter == QueueFilter.FINISHED && visible.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 12.dp, end = 12.dp, top = 6.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Text(
                            "Clear history",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.error.copy(alpha = 0.80f),
                            modifier = Modifier
                                .clip(CircleShape)
                                .clickable(role = Role.Button) {
                                    visible.map { it.id }.forEach { DownloadProgressBus.deleteJob(it) }
                                }
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // ───────────────────────── Job list ─────────────────────────
        if (visible.isEmpty()) {
            EmptyQueueState(
                filter = filter,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.navigationBars),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(visible, key = { it.id }) { job ->
                    JobCard(
                        job           = job,
                        onPause       = { scope.launch { DownloadProgressBus.pauseJob(job.id) } },
                        onResume      = { scope.launch { DownloadProgressBus.resumeJob(job.id) } },
                        onCancel      = { scope.launch { DownloadProgressBus.cancelJob(job.id) } },
                        onRetry       = { scope.launch { DownloadProgressBus.retryJob(job.id) } },
                        onDelete      = { DownloadProgressBus.deleteJob(job.id) },
                        onOpenDetails = onOpenDetails
                    )
                }
            }
        }
    }
}
}

// ───────────────────────── Job card ─────────────────────────

@Composable
private fun JobCard(
    job: DownloadJobState,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
    onDelete: () -> Unit,
    onOpenDetails: (novelId: String) -> Unit
) {
    // A cancelled job used to count as "active" here, so a stopped download
    // kept a live progress bar and live-looking buttons.
    val isActive    = !job.isFinished && !job.isPaused
    val isHistory   = job.isDone || job.isCancelled
    val canNavigate = job.isDone && job.novelId.isNotEmpty()

    // Per-chapter breakdown, collapsed by default so a 400-chapter manga does
    // not bury every other job in the list.
    var expanded by remember(job.id) { mutableStateOf(false) }
    val canExpand = job.items.isNotEmpty() && !job.isFinished

    val cardBg = when {
        isHistory    -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.20f)
        job.isFailed -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.16f)
        else         -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.34f)
    }
    val cardBd = when {
        isHistory    -> MaterialTheme.colorScheme.outline.copy(alpha = 0.10f)
        job.isFailed -> MaterialTheme.colorScheme.error.copy(alpha = 0.25f)
        isActive     -> MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
        else         -> MaterialTheme.colorScheme.outline.copy(alpha = 0.14f)
    }

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = cardBg,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, cardBd, RoundedCornerShape(18.dp))
            .then(
                if (canNavigate) Modifier.clickable(role = Role.Button) { onOpenDetails(job.novelId) }
                else Modifier
            )
    ) {
        Column(Modifier.padding(14.dp)) {
            // Top row
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // Status icon
                Box(
                    modifier = Modifier.size(38.dp).clip(CircleShape).background(
                        when {
                            job.isDone      -> MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)
                            job.isCancelled -> MaterialTheme.colorScheme.surfaceVariant
                            job.isFailed -> MaterialTheme.colorScheme.error.copy(alpha = 0.12f)
                            job.isPaused -> MaterialTheme.colorScheme.surfaceVariant
                            else         -> MaterialTheme.colorScheme.primary.copy(alpha = 0.13f)
                        }
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when {
                            job.isDone      -> Icons.Default.CheckCircle
                            job.isCancelled -> Icons.Default.Cancel
                            job.isFailed -> Icons.Default.Error
                            job.isPaused -> Icons.Default.PauseCircle
                            else         -> Icons.Default.Downloading
                        },
                        contentDescription = null,
                        tint = when {
                            job.isDone      -> MaterialTheme.colorScheme.primary
                            job.isCancelled -> MaterialTheme.colorScheme.onSurfaceVariant
                            job.isFailed -> MaterialTheme.colorScheme.error
                            job.isPaused -> MaterialTheme.colorScheme.onSurfaceVariant
                            else         -> MaterialTheme.colorScheme.primary
                        },
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Title + kind badge
                Column(Modifier.weight(1f)) {
                    Text(
                        job.title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        // Kind badge
                        Text(
                            job.kind,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.10f))
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                        // Chapter count / item count
                        val doneItems  = job.items.count { it.isDone }
                        val totalItems = job.items.size
                        if (totalItems > 0) {
                            Text(
                                "$doneItems / $totalItems",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f)
                            )
                        }
                    }
                }

                // Navigate arrow for completed
                if (canNavigate) {
                    Icon(
                        Icons.Default.ChevronRight, null,
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.55f),
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Only buttons that actually do something for this state.
                // History rows (finished or stopped) get Delete alone -- no
                // Stop that stops nothing, and no Retry on a job the user
                // deliberately stopped.
                when {
                    isHistory -> {
                        SmallIconBtn(Icons.Default.Delete, "Delete", MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.70f), onDelete)
                    }
                    job.isFailed -> {
                        SmallIconBtn(Icons.Default.Refresh, "Retry", MaterialTheme.colorScheme.primary, onRetry)
                        SmallIconBtn(Icons.Default.Delete, "Delete", MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.70f), onDelete)
                    }
                    job.isPaused -> {
                        SmallIconBtn(Icons.Default.PlayArrow, "Resume", MaterialTheme.colorScheme.primary, onResume)
                        SmallIconBtn(Icons.Default.Cancel, "Stop", MaterialTheme.colorScheme.error.copy(alpha = 0.70f), onCancel)
                    }
                    else -> {
                        SmallIconBtn(Icons.Default.Pause, "Pause", MaterialTheme.colorScheme.onSurfaceVariant, onPause)
                        SmallIconBtn(Icons.Default.Cancel, "Stop", MaterialTheme.colorScheme.error.copy(alpha = 0.70f), onCancel)
                    }
                }
            }

            // Progress bar for jobs that are still on their way only
            if (!job.isFinished) {
                val totalItems = job.items.size
                val doneItems  = job.items.count { it.isDone }
                val rawProg    = if (totalItems > 0) doneItems.toFloat() / totalItems else job.overallProgress
                val progress   by animateFloatAsState(rawProg.coerceIn(0f, 1f),
                    animationSpec = spring(stiffness = Spring.StiffnessLow), label = "prog")

                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress    = { progress },
                    modifier    = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                    color       = if (job.isPaused) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.40f)
                                  else MaterialTheme.colorScheme.primary,
                    trackColor  = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
                    strokeCap   = StrokeCap.Round
                )

                // Current item label, plus the toggle into the full chapter list.
                val current = job.items.firstOrNull { !it.isDone && it.isDownloading }
                if (current != null || canExpand) {
                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .then(
                                if (canExpand) Modifier.clickable(role = Role.Button) { expanded = !expanded }
                                else Modifier
                            ),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            current?.label ?: "Waiting to start",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f),
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (canExpand) {
                            Text(
                                if (expanded) "Hide chapters" else "Show chapters",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f)
                            )
                            Icon(
                                if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                // Chapter breakdown: what is downloading right now, and what is
                // queued behind it.
                AnimatedVisibility(
                    visible = expanded && canExpand,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut()
                ) {
                    ChapterBreakdown(job)
                }
            }

            // Stopped-by-you note
            if (job.isCancelled) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Stopped", fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f)
                )
            }

            // Error message
            if (job.isFailed && !job.errorMessage.isNullOrBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(
                    job.errorMessage!!, fontSize = 11.sp, lineHeight = 15.sp,
                    color = MaterialTheme.colorScheme.error.copy(alpha = 0.80f)
                )
            }
        }
    }
}

// ───────────────────────── Chapter breakdown ─────────────────────────

/**
 * The per-chapter list behind "Show chapters".
 *
 * Ordering is deliberate: whatever is downloading right now sits on top,
 * everything still waiting follows in queue order, and anything already
 * finished or failed is summarised rather than listed, because the useful
 * question here is "what is happening now and what is next".
 */
@Composable
private fun ChapterBreakdown(job: DownloadJobState) {
    val running  = job.items.filter { it.isDownloading }
    val waiting  = job.items.filter { !it.isFinished && !it.isDownloading }
    val doneN    = job.items.count { it.isDone }
    val failedN  = job.items.count { it.isFailed }
    val shownWaiting = waiting.take(6)

    Column(Modifier.fillMaxWidth().padding(top = 10.dp)) {
        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.12f))
        Spacer(Modifier.height(8.dp))

        running.forEach { item ->
            ChapterLine(
                name      = item.label,
                state     = if (item.total > 0L) "${item.current} / ${item.total} pages" else "Downloading",
                accent    = MaterialTheme.colorScheme.primary,
                highlight = true,
                fraction  = if (item.total > 0L) item.fraction else null
            )
        }

        if (running.isEmpty() && shownWaiting.isNotEmpty()) {
            ChapterLine(
                name      = shownWaiting.first().label,
                state     = "Up next",
                accent    = MaterialTheme.colorScheme.onSurfaceVariant,
                highlight = false,
                fraction  = null
            )
        }

        val queueTail = if (running.isEmpty()) shownWaiting.drop(1) else shownWaiting
        queueTail.forEach { item ->
            ChapterLine(
                name      = item.label,
                state     = "Waiting",
                accent    = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f),
                highlight = false,
                fraction  = null
            )
        }

        val hiddenWaiting = waiting.size - shownWaiting.size
        if (hiddenWaiting > 0) {
            Text(
                "+ $hiddenWaiting more waiting",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.50f),
                modifier = Modifier.padding(top = 4.dp, start = 2.dp)
            )
        }

        if (doneN > 0 || failedN > 0) {
            Text(
                buildString {
                    append("$doneN done")
                    if (failedN > 0) append(" · $failedN failed")
                },
                fontSize = 10.sp,
                color = if (failedN > 0) MaterialTheme.colorScheme.error.copy(alpha = 0.75f)
                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f),
                modifier = Modifier.padding(top = 6.dp, start = 2.dp)
            )
        }
    }
}

@Composable
private fun ChapterLine(
    name: String,
    state: String,
    accent: Color,
    highlight: Boolean,
    fraction: Float?
) {
    Column(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(accent.copy(alpha = if (highlight) 0.95f else 0.40f))
            )
            Text(
                name,
                fontSize = 11.sp,
                fontWeight = if (highlight) FontWeight.SemiBold else FontWeight.Normal,
                color = if (highlight) MaterialTheme.colorScheme.onSurface
                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Text(
                state,
                fontSize = 10.sp,
                color = accent.copy(alpha = if (highlight) 0.90f else 0.60f),
                maxLines = 1
            )
        }
        if (fraction != null) {
            Spacer(Modifier.height(3.dp))
            LinearProgressIndicator(
                progress   = { fraction.coerceIn(0f, 1f) },
                modifier   = Modifier.fillMaxWidth().height(3.dp).clip(CircleShape).padding(start = 14.dp),
                color      = MaterialTheme.colorScheme.primary.copy(alpha = 0.75f),
                trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.10f),
                strokeCap  = StrokeCap.Round
            )
        }
    }
}

// ───────────────────────── Empty state ─────────────────────────

@Composable
private fun EmptyQueueState(filter: QueueFilter, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            imageVector = when (filter) {
                QueueFilter.FAILED   -> Icons.Default.Error
                QueueFilter.FINISHED -> Icons.Default.CheckCircle
                QueueFilter.ACTIVE   -> Icons.Default.CloudDownload
            },
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.28f),
            modifier = Modifier.size(56.dp)
        )
        Spacer(Modifier.height(14.dp))
        Text(
            when (filter) {
                QueueFilter.ACTIVE   -> "Nothing downloading right now"
                QueueFilter.FAILED   -> "No failed downloads"
                QueueFilter.FINISHED -> "No finished downloads yet"
            },
            fontSize = 15.sp, fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.55f)
        )
        Spacer(Modifier.height(6.dp))
        Text(
            when (filter) {
                QueueFilter.ACTIVE   -> "Downloading, queued and paused jobs appear here."
                QueueFilter.FAILED   -> "Downloads that stop on an error show up here."
                QueueFilter.FINISHED -> "Completed downloads are kept here until you delete them."
            },
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.38f)
        )
        }
    }

// ───────────────────────── Small helpers ─────────────────────────

@Composable
private fun SmallIconBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, tint: androidx.compose.ui.graphics.Color, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(32.dp)) {
        Icon(icon, desc, tint = tint, modifier = Modifier.size(18.dp))
    }
}

/** Animated pulsing live indicator dot shown while downloads are running. */
@Composable
private fun LiveIndicator() {
    val pulse = rememberInfiniteTransition(label = "live")
    val alpha by pulse.animateFloat(
        0.4f, 1f,
        animationSpec = infiniteRepeatable(tween(700, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "a"
    )
    Box(
        modifier = Modifier.size(7.dp).clip(CircleShape)
            .background(MaterialTheme.colorScheme.primary.copy(alpha = alpha))
    )
}
