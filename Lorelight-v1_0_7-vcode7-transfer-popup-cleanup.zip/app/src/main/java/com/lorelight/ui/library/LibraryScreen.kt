package com.lorelight.ui.library

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.ui.graphics.Shadow
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import kotlin.math.absoluteValue
import androidx.compose.ui.window.Dialog
import com.lorelight.R
import androidx.compose.ui.res.stringResource
import com.lorelight.core.getSafeBoolean
import com.lorelight.core.getSafeFloat
import com.lorelight.core.getSafeInt
import com.lorelight.crawler.CrawlerEngine
import com.lorelight.data.local.NovelPreferences
import com.lorelight.data.repository.LibraryRepository
import com.lorelight.data.model.Novel
import com.lorelight.ui.components.LibraryCoverImage
import com.lorelight.ui.components.NovelCoverImage
import com.lorelight.ui.reader.ReaderViewModel
import com.lorelight.ui.theme.*
import com.lorelight.utils.EpubExtractor
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.distinctUntilChangedBy
import java.text.SimpleDateFormat
import java.util.*
import androidx.compose.ui.semantics.Role

/** Display label for a library sort-mode option; currently a pass-through of the stored value. */
private fun librarySortLabel(option: String): String = option

/** Display label for a library source-filter option; currently a pass-through of the stored value. */
private fun librarySourceLabel(option: String): String = option

private val Novel.isManga: Boolean get() = pluginId?.let { com.lorelight.manga.util.MangaNamingUtils.isMangaPluginId(it) } == true

fun formatLastReadTime(timestamp: Long): String =
    NovelPreferences.formatLastReadTime(timestamp)

private fun formatLastReadTimeUnusedLegacy(timestamp: Long): String {
    val now = System.currentTimeMillis()
    val sdfTime = SimpleDateFormat("h:mm a", Locale.US)
    val sdfFull = SimpleDateFormat("d MMMM h:mm a", Locale.US)
    
    val cal1 = Calendar.getInstance()
    cal1.timeInMillis = now
    val cal2 = Calendar.getInstance()
    cal2.timeInMillis = timestamp
    
    val isSameDay = cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                    cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
                    
    cal1.add(Calendar.DAY_OF_YEAR, -1)
    val isYesterday = cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                      cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
                      
    return when {
        isSameDay -> "Today, ${sdfTime.format(Date(timestamp))}"
        isYesterday -> "Yesterday, ${sdfTime.format(Date(timestamp))}"
        else -> sdfFull.format(Date(timestamp))
    }
}

fun getFileName(context: Context, uri: Uri): String {
    var result: String? = null
    if (uri.scheme == "content") {
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        try {
            if (cursor != null && cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index != -1) {
                    result = cursor.getString(index)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            cursor?.close()
        }
    }
    if (result == null) {
        result = uri.path
        val cut = result?.lastIndexOf('/')
        if (cut != null && cut != -1) {
            result = result.substring(cut + 1)
        }
    }
    return result ?: context.getString(R.string.library_unknown_novel)
}

@Composable
fun LibraryScreen(
    currentNovel: Novel?,
    importedNovels: List<Novel>,
    onCurrentNovelChange: (Novel?) -> Unit,
    onImportedNovelsChange: (List<Novel>) -> Unit,
    onSelectNovelForDetails: (Novel) -> Unit,
    onReadCurrent: () -> Unit = {},
    readerViewModel: ReaderViewModel,
    heroImageRes: Int = R.drawable.darklibrarygreen,
    libraryLoaded: Boolean = true,
    pendingEpubUri: Uri? = null,
    onPendingEpubHandled: () -> Unit = {},
    onOpenNotifications: () -> Unit = {}
) {
    val context = LocalContext.current
    val isPlaying by readerViewModel.isPlaying.collectAsState()
    // Ignore word/paragraph-only TTS progress in the bookshelf shell. Those
    // updates remain durable but no longer invalidate the whole horizontal shelf.
    val libraryActiveNovelFlow = remember(readerViewModel) {
        readerViewModel.activeNovel.distinctUntilChangedBy { novel ->
            Triple(novel?.id, novel?.currentChapterIndex, novel?.currentChapter)
        }
    }
    val activeNovel by libraryActiveNovelFlow.collectAsState(
        initial = readerViewModel.activeNovel.value
    )
    val showCelestialNavigation by readerViewModel.showCelestialNavigation.collectAsState()

    var ttsSessionShown by remember(activeNovel?.id) { mutableStateOf(false) }
    LaunchedEffect(activeNovel?.id, isPlaying) {
        if (isPlaying) ttsSessionShown = true
        val an = activeNovel
        if (an != null && !an.isManga) {
            LibraryRepository.setLastMode(context, an.id, isPlaying || ttsSessionShown)
        }
    }
    val activeChapterIndex by readerViewModel.activeChapterIndex.collectAsState()
    val chapters by readerViewModel.chapters.collectAsState()
    // FIX C15: the library screen was the ONLY user of the orphan
    // "lorelight_settings" file, so shelf layout, sort mode, media filter and
    // source filter lived outside backup/restore and outside every other
    // settings read. AppPrefs returns the canonical store and folds the old
    // file's keys in exactly once.
    val settingsVersion by com.lorelight.data.local.AppSettingsSignal.version.collectAsState()
    val sharedPrefs = remember(context, settingsVersion) { com.lorelight.data.local.AppPrefs.get(context) }
    
    var isManageMode by remember { mutableStateOf(false) }
    var selectedNovelTitles by remember { mutableStateOf(setOf<String>()) }
    var showEditDialog by remember { mutableStateOf(false) }
    var showMigrateDialog by remember { mutableStateOf(false) }
    if (showMigrateDialog) {
        val migrateTargets = importedNovels.filter { it.title in selectedNovelTitles }
        com.lorelight.browse.migrate.MigrateSourceDialog(
            novels = migrateTargets,
            onDismiss = { showMigrateDialog = false },
            onApplied = { migrated ->
                if (migrated.isNotEmpty()) {
                    val byId = migrated.associateBy { it.id }
                    onImportedNovelsChange(importedNovels.map { byId[it.id] ?: it })
                }
                showMigrateDialog = false
                selectedNovelTitles = emptySet()
                isManageMode = false
            }
        )
    }
    
    var bookshelfCoverScale by remember(settingsVersion) {
        val scale = sharedPrefs.getSafeFloat("bookshelf_cover_scale", 1.0f)
        mutableStateOf(scale)
    }
    var bookshelfRows by remember(settingsVersion) {
        val rows = sharedPrefs.getSafeInt("bookshelf_rows", 2)
        mutableStateOf(rows.coerceIn(1, 3))
    }
    var bookshelfBookDesign by remember(settingsVersion) {
        val enabled = sharedPrefs.getSafeBoolean("bookshelf_book_design", true)
        mutableStateOf(enabled)
    }
    var bookshelfShelfDesign by remember(settingsVersion) {
        val enabled = sharedPrefs.getSafeBoolean("bookshelf_shelf_design", true)
        mutableStateOf(enabled)
    }
    var bookshelfMixMedia by remember(settingsVersion) {
        val mix = sharedPrefs.getSafeBoolean("bookshelf_mix_media", false)
        mutableStateOf(mix)
    }
    // S8: stored values are now stable lowercase constants ("novels" / "manga").
    // Old installs may have title-cased values from before this change; we
    // normalize on read so the migration is silent and needs no data wipe.
    var libraryMediaFilter by remember(settingsVersion) {
        mutableStateOf(
            when (sharedPrefs.getString("library_media_filter", "novels") ?: "novels") {
                "Novels", "novels" -> "novels"
                "Manga",  "manga"  -> "manga"
                else                 -> "novels"
            }
        )
    }
    LaunchedEffect(importedNovels) {
        if (importedNovels.isNotEmpty()) {
            val hasManga = importedNovels.any { it.isManga }
            val hasNovel = importedNovels.any { !it.isManga }
            if (hasManga && !hasNovel) {
                if (libraryMediaFilter != "manga") libraryMediaFilter = "manga"
            } else if (hasNovel && !hasManga) {
                if (libraryMediaFilter != "novels") libraryMediaFilter = "novels"
            }
        }
    }
    var isEpubLoading by remember { mutableStateOf(false) }

    // Library sort & filter state
    var librarySortMode by remember(settingsVersion) { mutableStateOf(sharedPrefs.getString("library_sort_mode", "Last read") ?: "Last read") }
    var librarySourceFilter by remember(settingsVersion) { mutableStateOf(sharedPrefs.getString("library_source_filter", "All") ?: "All") }
    var showSortMenu by remember { mutableStateOf(false) }
    val displayedNovels = remember(importedNovels, librarySortMode, librarySourceFilter, libraryMediaFilter, bookshelfMixMedia) {
        importedNovels
            .filter { novel ->
                if (bookshelfMixMedia) {
                    true
                } else if (libraryMediaFilter == "manga") {
                    novel.isManga
                } else {
                    !novel.isManga
                }
            }
            .filter { novel ->
                when (librarySourceFilter) {
                    "Online" -> novel.isOnline
                    "Local" -> !novel.isOnline
                    else -> true
                }
            }
            .let { list ->
                when (librarySortMode) {
                    "Title (A-Z)" -> list.sortedBy { it.title.lowercase() }
                    "Recently added" -> list.sortedByDescending { it.dateAdded }
                    else -> list.sortedByDescending { it.lastReadTimestamp }
                }
            }
    }
    
    val gridState = rememberLazyGridState()
    val listState = rememberLazyListState()
    
    LaunchedEffect(bookshelfCoverScale, bookshelfRows, bookshelfBookDesign, bookshelfShelfDesign, bookshelfMixMedia) {
        sharedPrefs.edit()
            .putFloat("bookshelf_cover_scale", bookshelfCoverScale)
            .putInt("bookshelf_rows", bookshelfRows)
            .putBoolean("bookshelf_book_design", bookshelfBookDesign)
            .putBoolean("bookshelf_shelf_design", bookshelfShelfDesign)
            .putBoolean("bookshelf_mix_media", bookshelfMixMedia)
            .apply()
    }
    
    LaunchedEffect(Unit) {
        if (CoverFetchSession.done) return@LaunchedEffect
        CoverFetchSession.done = true
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val current = importedNovels
            var changed = false
            val updated = current.map { novel ->
                val cover = novel.coverImageBase64
                if (!cover.isNullOrEmpty() && (cover.startsWith("http://") || cover.startsWith("https://"))) {
                    try {
                        val bytes = org.jsoup.Jsoup.connect(cover)
                            .ignoreContentType(true)
                            .userAgent("Mozilla/5.0")
                            .timeout(12000)
                            .execute()
                            .bodyAsBytes()
                        val path = if (bytes != null && bytes.isNotEmpty())
                            com.lorelight.data.local.CoverStorage.saveCoverBytes(context, novel.id, bytes) else null
                        if (path != null) { changed = true; novel.copy(coverImageBase64 = path) } else novel
                    } catch (e: Exception) { novel }
                } else novel
            }
            if (changed) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    onImportedNovelsChange(updated)
                }
            }
        }
    }
    
    val coroutineScope = rememberCoroutineScope()

    var editedTitle by remember(selectedNovelTitles.firstOrNull()) {
        mutableStateOf("")
    }
    var editedCoverBase64 by remember(selectedNovelTitles.firstOrNull()) {
        mutableStateOf<String?>(null)
    }
    
    val targetNovel = remember(showEditDialog, selectedNovelTitles.firstOrNull()) {
        importedNovels.find { it.title == selectedNovelTitles.firstOrNull() }
    }
    
    LaunchedEffect(targetNovel) {
        if (targetNovel != null) {
            editedTitle = targetNovel.title
            editedCoverBase64 = targetNovel.coverImageBase64
        }
    }
    
    val coverPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                try {
                    val inputStream = context.contentResolver.openInputStream(uri)
                    val bytes = inputStream?.readBytes()
                    inputStream?.close()
                    if (bytes != null) {
                        val base64Str = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                        editedCoverBase64 = base64Str
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    Toast.makeText(context, context.getString(R.string.library_toast_cover_load_failed), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    
    // Single import path, shared by the in-app picker and external triggers.
    suspend fun importEpubFromUri(uri: Uri, fromExternalApp: Boolean = false) {
        isEpubLoading = true
        try {
            val fileName = getFileName(context, uri)
            if (!fileName.endsWith(".epub", ignoreCase = true) &&
                !fileName.endsWith(".cbz", ignoreCase = true) &&
                !fileName.endsWith(".loremanga", ignoreCase = true) &&
                !fromExternalApp
            ) {
                Toast.makeText(context, "Select an EPUB, CBZ or .loremanga file", Toast.LENGTH_LONG).show()
                isEpubLoading = false
                return
            }
            
            val result = com.lorelight.service.NovelImportManager.importEpub(context, uri)
            when (result) {
                is com.lorelight.service.EpubImportResult.Success -> {
                    val novel = result.novel
                    val freshNovels = LibraryRepository.loadLibrary(context)
                    onImportedNovelsChange(freshNovels)
                    onCurrentNovelChange(novel)
                    onSelectNovelForDetails(novel)
                    val firstChapter = novel.chapters.firstOrNull() ?: novel.currentChapter
                    readerViewModel.startReading(novel, firstChapter)
                    onReadCurrent()
                    Toast.makeText(
                        context,
                        if (result.isNew) "Successfully imported \u201C${novel.title}\u201D" else "Opened \u201C${novel.title}\u201D",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                is com.lorelight.service.EpubImportResult.Error -> {
                    Toast.makeText(context, result.message, Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to import EPUB: ${e.localizedMessage ?: e.message}", Toast.LENGTH_LONG).show()
        } finally {
            isEpubLoading = false
        }
    }

    // OpenDocument and broad MIME aliases keep CBZ files selectable even
    // when a provider labels them as ZIP, binary, or an unknown file type.
    val epubLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch { importEpubFromUri(uri) }
        }
    }

    // S6: Command Palette "Import EPUB" command. EpubImportTrigger.requestLaunch
    // is set to true by the palette action; we observe it here because the
    // launcher must live in a Composable scope. Same one-shot pattern as the
    // CommandPaletteTrigger used to open the palette itself.
    LaunchedEffect(com.lorelight.ui.components.EpubImportTrigger.requestLaunch) {
        if (com.lorelight.ui.components.EpubImportTrigger.requestLaunch) {
            com.lorelight.ui.components.EpubImportTrigger.requestLaunch = false
            epubLauncher.launch(arrayOf(
                "application/epub+zip",
                "application/vnd.comicbook+zip",
                "application/x-cbz",
                "application/zip",
                "application/octet-stream",
                "*/*"
            ))
        }
    }

    // "Open with Lorelight" / share-sheet hand-off is owned solely by MainActivity.
    // This screen must NOT import it as well - running both importers in parallel
    // raced on the extracted epub file and the saved novel list, which is what made
    // books occasionally not land in the library and made a successful import still
    // report "failed". The in-app picker below is the only import this screen starts.

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        val configuration = androidx.compose.ui.platform.LocalConfiguration.current
        val isTablet = configuration.screenWidthDp >= 600
        val heroHeight = if (isTablet) 240.dp else 280.dp

        // TABLET FADE-DISTANCE FIX. The banner's "disappear" gradient used to
        // be defined as a FRACTION of heroHeight (0.45f -> 0.85f). Because the
        // tablet banner is shorter (240dp vs 280dp), the fade began 18dp higher
        // there, while the Continue Reading card below was ALSO pushed further
        // down - so the visible gap between where the banner starts fading and
        // where the card starts was ~172dp on tablets against ~54dp on phones.
        // The fade is now pinned to ABSOLUTE dp taken from the phone geometry
        // (starts 126dp down, completes 112dp later), converted back into
        // gradient stops against whatever heroHeight is in use. Phones keep
        // exactly their previous 0.45f/0.85f stops; tablets land on the same
        // absolute fade position, giving both form factors an identical 54dp
        // distance to the Continue Reading card.
        val heroFadeStartDp = 126.dp
        val heroFadeSpanDp = 112.dp
        val heroFadeStart = (heroFadeStartDp / heroHeight).coerceIn(0f, 1f)
        val heroFadeEnd = ((heroFadeStartDp + heroFadeSpanDp) / heroHeight)
            .coerceIn(heroFadeStart + 0.001f, 1f)

        // TABLET PUSH-DOWN (intentional, kept). On tablets the Continue
        // Reading / audio section is offset downward by an amount equal to the
        // section's OWN measured height. The height is measured on the inner
        // box (before any extra padding), then applied as top padding on the
        // outer box, so there's no feedback loop. Phones are unaffected.
        //
        // These are hoisted up here (instead of being declared right at the
        // section) because the header spacer further down also needs the
        // push-down amount in order to compensate for it - see the spacer.
        val continueSectionDensity = LocalDensity.current
        val continueSectionHeightPx = remember { mutableStateOf(0) }
        val continueSectionPushDown = if (isTablet) {
            with(continueSectionDensity) { continueSectionHeightPx.value.toDp() }
        } else {
            0.dp
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 680.dp)
                .height(heroHeight)
        ) {
            Image(
                painter = painterResource(id = heroImageRes),
                contentDescription = stringResource(R.string.library_hero_banner_desc),
                contentScale = ContentScale.Crop,
                // TOP-CROP FIX (tablets only). Crop defaulted to centering,
                // which cropped the top and bottom evenly. Aligning to
                // TopCenter on tablets keeps the top edge of the banner art
                // always fully visible, matching the Details screen's hero
                // banner fix. Phones keep the original center crop (previous
                // mobile hero banner setting).
                alignment = if (isTablet) Alignment.TopCenter else Alignment.Center,
                modifier = Modifier.fillMaxSize()
            )
            
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colorStops = arrayOf(
                                0.0f to Color.Transparent,
                                heroFadeStart to Color.Transparent,
                                heroFadeEnd to MaterialTheme.colorScheme.background,
                                1.0f to MaterialTheme.colorScheme.background
                            )
                        )
                    )
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 680.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clipToBounds()
            ) {
                val appThemeName by readerViewModel.appTheme.collectAsState()
                WindAndFirefliesBackground(
                    themeName = appThemeName,
                    primaryColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.matchParentSize()
                )

                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 32.dp)
                            .height(48.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.library_title),
                            fontSize = 32.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = MaterialTheme.typography.headlineLarge.fontFamily,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Glass, matching the source-page buttons and the
                            // bottom nav panes rather than a flat filled pill.
                            com.lorelight.ui.theme.GlassPanel(
                                cornerRadius = 12.dp,
                                tintAlpha = 0.65f,
                                modifier = Modifier
                                    .clickable(role = Role.Button) {
                                        try {
                                            epubLauncher.launch(arrayOf(
                "application/epub+zip",
                "application/vnd.comicbook+zip",
                "application/x-cbz",
                "application/zip",
                "application/octet-stream",
                "*/*"
            ))
                                        } catch (e: Exception) {
                                            epubLauncher.launch(arrayOf(
                "application/epub+zip",
                "application/vnd.comicbook+zip",
                "application/x-cbz",
                "application/zip",
                "application/octet-stream",
                "*/*"
            ))
                                        }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.MenuBook,
                                        contentDescription = stringResource(R.string.library_import_desc),
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = stringResource(R.string.library_import_label),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
 
                    // TABLET GAP FIX. The distance from where the hero banner
                    // starts fading out to the top of the Continue Reading card
                    // was ~172dp on tablets against ~54dp on phones. 18dp of
                    // that came from the shorter tablet banner (handled by the
                    // absolute-dp fade stops above) and the remaining ~100dp
                    // came from the intentional tablet push-down below. The
                    // push-down is deliberately left intact; instead this
                    // header spacer gives back exactly what the push-down takes
                    // on tablets, so the card lands at the phone's position and
                    // both form factors show the same ~54dp distance. On phones
                    // continueSectionPushDown is 0.dp, so this stays 100.dp.
                    Spacer(
                        modifier = Modifier.height(
                            (100.dp - continueSectionPushDown).coerceAtLeast(0.dp)
                        )
                    )
                }
            }

            // Tablet push-down applied here (declared near heroHeight above).
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = continueSectionPushDown)
            ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .onSizeChanged { continueSectionHeightPx.value = it.height }
            ) {
                // MEDIA-SCOPED CONTINUE READING.
                //
                // The library's Novels/Manga toggle now decides what this box is
                // about. It used to answer "the last thing you opened" no matter
                // which shelf was on screen, so a library filtered to Manga
                // could sit under a card offering the novel from yesterday --
                // and the play button beside it started that novel's audio.
                //
                // "Mix manga and novels" switches the toggle off, and with it
                // this scoping: the box then behaves exactly as it always has.
                val mediaScoped: (Novel) -> Boolean = { n ->
                    bookshelfMixMedia || (libraryMediaFilter == "manga") == n.isManga
                }

                val actNovel = activeNovel
                val showAudioCard = actNovel != null &&
                    !actNovel.isManga &&
                    mediaScoped(actNovel) &&
                    (isPlaying || ttsSessionShown)
                if (actNovel != null && showAudioCard) {
                    AudioControllerCard(
                        novel = actNovel,
                        isPlaying = isPlaying,
                        onPlayPause = { readerViewModel.togglePlayPause() },
                        onSkipBackward = { readerViewModel.skipBackward() },
                        onSkipForward = { readerViewModel.skipForward() },
                        onPrevChapter = {
                            if (activeChapterIndex > 0) {
                                readerViewModel.selectChapter(activeChapterIndex - 1)
                            }
                        },
                        onNextChapter = {
                            if (activeChapterIndex < chapters.size - 1) {
                                readerViewModel.selectChapter(activeChapterIndex + 1)
                            }
                        },
                        hasPrevChapter = activeChapterIndex > 0,
                        hasNextChapter = activeChapterIndex < chapters.size - 1,
                        onStop = {
                            readerViewModel.stopSpeaking()
                            ttsSessionShown = false
                            LibraryRepository.setLastMode(context, actNovel.id, false)
                        },
                        onCardClick = {
                            onCurrentNovelChange(actNovel)
                            onReadCurrent()
                        }
                    )
                } else {
                    val resumeNovel = remember(
                        currentNovel,
                        importedNovels,
                        isPlaying,
                        ttsSessionShown,
                        // Both are keys, not captures: a remembered predicate
                        // would keep answering with the filter that was in force
                        // the first time this card composed.
                        libraryMediaFilter,
                        bookshelfMixMedia
                    ) {
                        val inScope = importedNovels.filter { n ->
                            bookshelfMixMedia || (libraryMediaFilter == "manga") == n.isManga
                        }
                        // The live row for whatever is open, but only when it
                        // belongs to the shelf being shown. Reading a manga and
                        // then flipping the toggle to Novels has to fall through
                        // to the last novel instead of still pointing at manga.
                        val cur = currentNovel
                        val live = if (cur != null) {
                            importedNovels.firstOrNull { it.id == cur.id } ?: cur
                        } else {
                            null
                        }
                        if (live != null && (bookshelfMixMedia || (libraryMediaFilter == "manga") == live.isManga)) {
                            live
                        } else {
                            // Most recently read entry of this media type. Null
                            // when nothing of the type has been opened yet,
                            // which the card already draws as its empty state --
                            // better an honest blank than a novel on the manga
                            // shelf.
                            LibraryRepository.pickResumeEntry(inScope)
                        }
                    }
                    val resumeIsManga = resumeNovel?.isManga == true
                    ContinueReadingCard(
                        novel = resumeNovel,
                        isManga = resumeIsManga,
                        showPlayButton = !resumeIsManga,
                        onReadClick = {
                            resumeNovel?.let {
                                onCurrentNovelChange(it)
                                LibraryRepository.setLastMode(context, it.id, false)
                                onReadCurrent()
                            }
                        },
                        onPlayTtsClick = {
                            resumeNovel?.let {
                                onCurrentNovelChange(it)
                                LibraryRepository.setLastMode(context, it.id, true)
                                readerViewModel.startReadingAndPlay(it)
                            }
                        }
                    )
                }
            }
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
            Column(modifier = Modifier.fillMaxSize()) {
            Spacer(modifier = Modifier.height(12.dp))

            if (isManageMode) {
                LibrarySelectionToolbar(
                    selectedCount = selectedNovelTitles.size,
                    hasItems = importedNovels.isNotEmpty(),
                    allSelected = selectedNovelTitles.size == importedNovels.size,
                    onClose = {
                        isManageMode = false
                        selectedNovelTitles = emptySet()
                    },
                    onSelectAll = {
                        val allSelected = selectedNovelTitles.size == importedNovels.size
                        selectedNovelTitles = if (allSelected) emptySet() else importedNovels.map { it.title }.toSet()
                    },
                    onEdit = { showEditDialog = true },
                    onMigrate = { showMigrateDialog = true },
                    onDelete = {
                        val selectedNovels = importedNovels.filter { it.title in selectedNovelTitles }
                        selectedNovels.forEach { novelToRemove ->
                            com.lorelight.data.local.NovelRemovalManager.removeNovelFromLibrary(context, novelToRemove)
                        }
                        val remainingNovels = importedNovels.filter { it.title !in selectedNovelTitles }
                        onImportedNovelsChange(remainingNovels)
                        if (currentNovel != null && currentNovel.title in selectedNovelTitles) {
                            onCurrentNovelChange(LibraryRepository.pickResumeEntry(remainingNovels))
                        }
                        selectedNovelTitles = emptySet()
                        isManageMode = false
                    }
                )
            } else {
                LibraryBookshelfHeader(
                    title = stringResource(R.string.library_my_bookshelf),
                    mediaOptions = listOf(
                        "novels" to stringResource(R.string.library_filter_novels),
                        "manga" to stringResource(R.string.library_filter_manga)
                    ),
                    selectedMedia = libraryMediaFilter,
                    showMediaFilter = !bookshelfMixMedia,
                    onMediaSelected = { value ->
                        libraryMediaFilter = value
                        sharedPrefs.edit().putString("library_media_filter", value).apply()
                    }
                ) {
                    Box {
                        // Notifications. Opens the page that lists the chapters the
                        // scanner added automatically; the badge counts what is new
                        // since that page was last opened.
                        val unreadNotifications by com.lorelight.service.NewChaptersManager.unreadCount.collectAsState()
                        IconButton(onClick = onOpenNotifications, modifier = Modifier.size(48.dp)) {
                            BadgedBox(
                                badge = {
                                    if (unreadNotifications > 0) {
                                        Badge {
                                            Text(if (unreadNotifications > 9) "9+" else unreadNotifications.toString())
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Notifications,
                                    contentDescription = "Notifications",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    Box {
                        var showThreeDotMenu by remember { mutableStateOf(false) }
                        var showDisplayDialog by remember { mutableStateOf(false) }

                        IconButton(onClick = { showThreeDotMenu = true }, modifier = Modifier.size(48.dp)) {
                            Icon(
                                imageVector = Icons.Filled.MoreVert,
                                contentDescription = stringResource(R.string.library_bookshelf_options_desc),
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        GlassDropdownMenu(
                            expanded = showThreeDotMenu,
                            onDismissRequest = { showThreeDotMenu = false },
                        ) {
                            DropdownMenuItem(
                                text = { Text("Sort", color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp) },
                                onClick = {
                                    showThreeDotMenu = false
                                    showSortMenu = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.library_display_settings), color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp) },
                                onClick = {
                                    showThreeDotMenu = false
                                    showDisplayDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.library_edit_manage_novels), color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp) },
                                onClick = {
                                    showThreeDotMenu = false
                                    isManageMode = true
                                    selectedNovelTitles = emptySet()
                                }
                            )
                        }

                        // Sort / filter menu. Reached from the "Sort" item above, and
                        // anchored to this same button.
                        GlassDropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false },
                        ) {
                            Text(stringResource(R.string.library_sort_by_label), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                            listOf("Last read", "Title (A-Z)", "Recently added").forEach { opt ->
                                DropdownMenuItem(
                                    text = { Text(if (librarySortMode == opt) "${librarySortLabel(opt)}  ✓" else librarySortLabel(opt), color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp) },
                                    onClick = {
                                        librarySortMode = opt
                                        sharedPrefs.edit().putString("library_sort_mode", opt).apply()
                                        showSortMenu = false
                                    }
                                )
                            }
                            HorizontalDivider()
                            Text(stringResource(R.string.library_show_label), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                            listOf("All", "Online", "Local").forEach { opt ->
                                DropdownMenuItem(
                                    text = { Text(if (librarySourceFilter == opt) "${librarySourceLabel(opt)}  ✓" else librarySourceLabel(opt), color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp) },
                                    onClick = {
                                        librarySourceFilter = opt
                                        sharedPrefs.edit().putString("library_source_filter", opt).apply()
                                        showSortMenu = false
                                    }
                                )
                            }
                        }

                        BookshelfDisplaySettingsDialog(
                            showDialog = showDisplayDialog,
                            bookshelfCoverScale = bookshelfCoverScale,
                            onBookshelfCoverScaleChange = { bookshelfCoverScale = it },
                            bookshelfRows = bookshelfRows,
                            onBookshelfRowsChange = { bookshelfRows = it },
                            bookDesignEnabled = bookshelfBookDesign,
                            onBookDesignChange = { bookshelfBookDesign = it },
                            shelfDesignEnabled = bookshelfShelfDesign,
                            onShelfDesignChange = { bookshelfShelfDesign = it },
                            mixMangaAndNovels = bookshelfMixMedia,
                            onMixMangaAndNovelsChange = { bookshelfMixMedia = it },
                            showCelestialNavigation = showCelestialNavigation,
                            onShowCelestialNavigationChange = {
                                readerViewModel.showCelestialNavigation.value = it
                            },
                            onDismissRequest = { showDisplayDialog = false }
                        )
                    }
                }
            }

            // No screen-level entrance animation here. The tab transition in
            // MainActivity already plays the fade-through; this second 350ms
            // translate + fade replayed on every single return to Library and
            // competed for the same frames the shelf needed to compose. The
            // reference reader's library screen has no entrance of its own
            // either -- the navigation layer owns that motion.
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                BookGrid(
                    importedNovels = displayedNovels,
                    currentNovel = currentNovel,
                    isManageMode = isManageMode,
                    selectedNovelTitles = selectedNovelTitles,
                    bookshelfCoverScale = bookshelfCoverScale,
                    bookshelfRows = bookshelfRows,
                    bookDesign = bookshelfBookDesign,
                    shelfDesign = bookshelfShelfDesign,
                    gridState = gridState,
                    libraryLoaded = libraryLoaded,
                    modifier = Modifier.fillMaxSize(),
                    onNovelSelect = { novel ->
                        if (isManageMode) {
                            selectedNovelTitles = if (novel.title in selectedNovelTitles) {
                                selectedNovelTitles - novel.title
                            } else {
                                selectedNovelTitles + novel.title
                            }
                        } else {
                            onSelectNovelForDetails(novel)
                        }
                    },
                    onNovelLongPress = { novel ->
                        if (!isManageMode) {
                            isManageMode = true
                            selectedNovelTitles = setOf(novel.title)
                        }
                    }
                )
            }
            }
            }
        }
    }

    BookEditDetailsDialog(
        showDialog = showEditDialog,
        targetNovel = targetNovel,
        importedNovels = importedNovels,
        currentNovel = currentNovel,
        editedTitle = editedTitle,
        onEditedTitleChange = { editedTitle = it },
        editedCoverBase64 = editedCoverBase64,
        onCoverPickerLaunch = { coverPickerLauncher.launch("image/*") },
        onImportedNovelsChange = onImportedNovelsChange,
        onCurrentNovelChange = onCurrentNovelChange,
        onDismissRequest = { showEditDialog = false },
        onSuccess = {
            selectedNovelTitles = emptySet()
            showEditDialog = false
            isManageMode = false
        }
    )
}

// Runs the online-cover migration at most once per app process.
private object CoverFetchSession {
    @Volatile var done = false
}
