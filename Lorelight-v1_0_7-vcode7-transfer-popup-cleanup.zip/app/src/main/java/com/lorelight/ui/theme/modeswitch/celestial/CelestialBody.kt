/*
 * =============================================================================
 * CelestialBody.kt — Phase 1: procedurally drawn "half-cute anime" sun & moon
 * Package: com.lorelight.ui.theme.modeswitch.celestial
 *
 * PUBLIC API (contract for later phases — do not rename):
 *
 *   enum class CelestialForm { SUN, MOON }
 *       Discrete form tag (the drawing itself is driven by a continuous Float).
 *
 *   enum class CelestialExpression { NEUTRAL, BLINK, DOUBLE_BLINK, TWITCH,
 *       BROW_RAISE, SURPRISE, WINK, LOOK_AROUND, SLEEPY, SHIVER }
 *       Every expression the face can play.
 *
 *   data class CelestialFaceSnapshot(...)
 *       Immutable per-frame face values, all normalised 0f..1f (pupils/tilt/squash
 *       are -1f..1f). Produced by CelestialFaceState.snapshot(), consumed by
 *       drawCelestialBody().
 *
 *   @Stable class CelestialFaceState
 *       fun snapshot(): CelestialFaceSnapshot   — current animated face values
 *       suspend fun play(expression)            — plays one expression, eased,
 *                                                 serialized (never two at once)
 *
 *   @Composable fun rememberCelestialFaceState(autoIdle: Boolean = true)
 *       Remembers a CelestialFaceState. ALWAYS runs the heartbeat blink loop
 *       (a jittered blink every ~3-5s, occasionally a double). When autoIdle,
 *       also runs the randomized expressive idle loop (brow raises, looks,
 *       winks, shivers...).
 *
 *   fun DrawScope.drawCelestialBody(center, radius, form, face, timeSec, alpha)
 *       Pure drawing function. form is CONTINUOUS: 0f = full moon, 1f = full
 *       sun, intermediate values blend. Scale-invariant: everything derives
 *       from radius.
 *
 *   @Composable fun CelestialBodyView(form, modifier, face, hover)
 *       Fully self-driving animated character view. hover adds idle bob/sway.
 *
 * Zero dependencies, zero image assets. 100% Canvas/DrawScope.
 * =============================================================================
 */
package com.lorelight.ui.theme.modeswitch.celestial

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.isActive
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/* ============================================================================
 * PUBLIC TYPES
 * ==========================================================================*/

/**
 * Body radius as a fraction of the glyph box. Tuned so the character sits in
 * the altar opening with a little stone visible around him.
 *
 * Single source of truth: the seated character, the flight body in
 * ModeSwitch.kt and the prop overlay in CompanionProps.kt all scale from this,
 * so changing it here resizes every appearance at once.
 */
const val CELESTIAL_BODY_RADIUS_FRACTION = 0.34f

enum class CelestialForm { SUN, MOON }

enum class CelestialExpression {
    NEUTRAL, BLINK, DOUBLE_BLINK, TWITCH, BROW_RAISE, SURPRISE,
    WINK, LOOK_AROUND, SLEEPY, SHIVER
}

/** Immutable per-frame face values, all normalised 0f..1f unless noted. */
data class CelestialFaceSnapshot(
    val lidLeft: Float,      // 0 = open, 1 = fully closed
    val lidRight: Float,
    val browLeft: Float,     // 0 = neutral, 1 = fully raised
    val browRight: Float,
    val pupilX: Float,       // -1 = left, 0 = centre, +1 = right
    val pupilY: Float,       // -1 = up,   0 = centre, +1 = down
    val mouthOpen: Float,
    val mouthSmile: Float,   // 0 = flat, 1 = full smile
    val headTilt: Float,     // -1 = tilt left, +1 = tilt right
    val squash: Float        // -1 = stretched tall, +1 = squashed wide
)

/** The resting face: a contented little smirk. */
private val RestSnapshot = CelestialFaceSnapshot(
    lidLeft = 0.06f, lidRight = 0.06f,
    browLeft = 0f, browRight = 0f,
    pupilX = 0f, pupilY = 0f,
    mouthOpen = 0f, mouthSmile = 0.55f,
    headTilt = 0f, squash = 0f
)

/* ============================================================================
 * FACE STATE + EXPRESSION ENGINE
 * ==========================================================================*/

/** Holds the animated face state and runs the autonomous idle behaviour. */
@Stable
class CelestialFaceState {

    // One Animatable per channel so expressions can drive channels concurrently
    // with independent easing. Reading .value inside a draw lambda invalidates
    // ONLY the draw phase — no recomposition per frame.
    private val lidL = Animatable(RestSnapshot.lidLeft)
    private val lidR = Animatable(RestSnapshot.lidRight)
    private val browL = Animatable(0f)
    private val browR = Animatable(0f)
    private val pupX = Animatable(0f)
    private val pupY = Animatable(0f)
    private val open = Animatable(0f)
    private val smile = Animatable(RestSnapshot.mouthSmile)
    private val tilt = Animatable(0f)
    private val sq = Animatable(0f)

    /** Guarantees expressions never overlap. */
    private val mutex = Mutex()

    /** Test/preview hook: when set, snapshot() returns exactly this. */
    internal var pinnedSnapshot: CelestialFaceSnapshot? = null

    /**
     * True while something else owns the face frame by frame -- a gesture, or
     * a preview pin. The heartbeat blink checks this so it never queues up
     * behind a performance and fires a burst of blinks the moment it ends.
     */
    internal val isPinned: Boolean get() = pinnedSnapshot != null

    fun snapshot(): CelestialFaceSnapshot {
        pinnedSnapshot?.let { return it }
        return CelestialFaceSnapshot(
            lidLeft = lidL.value, lidRight = lidR.value,
            browLeft = browL.value, browRight = browR.value,
            pupilX = pupX.value, pupilY = pupY.value,
            mouthOpen = open.value, mouthSmile = smile.value,
            headTilt = tilt.value, squash = sq.value
        )
    }

    suspend fun play(expression: CelestialExpression) {
        mutex.withLock {
            // RANDOMNESS RULE: roll every random value ONCE, here, up front.
            val side = if (Random.nextBoolean()) 1 else -1
            val lookFirstLeft = Random.nextBoolean()
            val holdJitter = Random.nextLong(0L, 300L)

            when (expression) {
                CelestialExpression.NEUTRAL -> settle(280)

                CelestialExpression.BLINK -> {
                    both(lidL, lidR, 1f, 70, LinearEasing)
                    both(lidL, lidR, RestSnapshot.lidLeft, 130, EaseOutBack01)
                }

                CelestialExpression.DOUBLE_BLINK -> {
                    // A real double-blink: the eye barely reopens between beats.
                    both(lidL, lidR, 1f, 65, LinearEasing)
                    both(lidL, lidR, 0.32f, 60, LinearEasing)
                    both(lidL, lidR, 1f, 60, LinearEasing)
                    both(lidL, lidR, RestSnapshot.lidLeft, 160, EaseOutBack01)
                }

                CelestialExpression.TWITCH -> coroutineScope {
                    val b = if (side > 0) browR else browL
                    launch {
                        b.animateTo(0.55f, tween(60, easing = LinearEasing))
                        b.animateTo(0f, tween(120, easing = FastOutSlowInEasing))
                    }
                    launch {
                        tilt.animateTo(0.07f * side, tween(70))
                        tilt.animateTo(0f, tween(140, easing = FastOutSlowInEasing))
                    }
                }

                CelestialExpression.BROW_RAISE -> {
                    // The signature look: ONE brow up, sly smirk, glance that way.
                    val b = if (side > 0) browR else browL
                    coroutineScope {
                        launch { b.animateTo(1f, tween(260, easing = FastOutSlowInEasing)) }
                        launch { pupX.animateTo(0.35f * side, tween(260)) }
                        launch { smile.animateTo(0.72f, tween(260)) }
                        launch { tilt.animateTo(-0.08f * side, tween(260)) }
                    }
                    delay(650 + holdJitter)
                    settle(320)
                }

                CelestialExpression.SURPRISE -> {
                    coroutineScope {
                        launch { browL.animateTo(1f, tween(120)) }
                        launch { browR.animateTo(1f, tween(120)) }
                        launch { both(lidL, lidR, 0f, 100, LinearEasing) }
                        launch { open.animateTo(0.55f, tween(140, easing = FastOutSlowInEasing)) }
                        launch { smile.animateTo(0.15f, tween(140)) }
                        launch { sq.animateTo(-0.28f, tween(130, easing = FastOutSlowInEasing)) }
                    }
                    delay(550 + holdJitter)
                    settle(360)
                }

                CelestialExpression.WINK -> {
                    val lid = if (side > 0) lidR else lidL
                    coroutineScope {
                        launch { lid.animateTo(1f, tween(110, easing = LinearEasing)) }
                        launch { tilt.animateTo(0.3f * side, tween(180, easing = FastOutSlowInEasing)) }
                        launch { smile.animateTo(0.9f, tween(180)) }
                    }
                    delay(480 + holdJitter)
                    settle(300)
                }

                CelestialExpression.LOOK_AROUND -> {
                    val d1 = if (lookFirstLeft) -1f else 1f
                    look(0.8f * d1, -0.15f, 0.12f * d1); delay(380 + holdJitter / 2)
                    look(-0.8f * d1, -0.1f, -0.12f * d1); delay(380)
                    look(0f, -0.5f, 0f); delay(300)
                    settle(340)
                }

                CelestialExpression.SLEEPY -> {
                    // Heavy lids, a small yawn, one slow blink.
                    coroutineScope {
                        launch { both(lidL, lidR, 0.55f, 650, FastOutSlowInEasing) }
                        launch { smile.animateTo(0.2f, tween(500)) }
                        launch { pupY.animateTo(0.3f, tween(600)) }
                    }
                    open.animateTo(0.7f, tween(480, easing = FastOutSlowInEasing)) // yawn
                    delay(350 + holdJitter)
                    open.animateTo(0f, tween(420, easing = FastOutSlowInEasing))
                    both(lidL, lidR, 1f, 420, FastOutSlowInEasing)   // one slow blink
                    both(lidL, lidR, 0.5f, 520, FastOutSlowInEasing)
                    delay(300)
                    settle(750)
                }

                CelestialExpression.SHIVER -> {
                    // Whole-body squash-and-stretch wobble, decaying.
                    val amps = floatArrayOf(0.32f, -0.26f, 0.18f, -0.11f, 0.05f, 0f)
                    coroutineScope {
                        launch {
                            for (a in amps) sq.animateTo(a, tween(90, easing = LinearEasing))
                            sq.animateTo(0f, tween(140, easing = FastOutSlowInEasing))
                        }
                        launch {
                            for (a in amps) tilt.animateTo(a * 0.28f * side, tween(90, easing = LinearEasing))
                            tilt.animateTo(0f, tween(140, easing = FastOutSlowInEasing))
                        }
                    }
                }
            }
        }
    }

    /* --- private helpers ------------------------------------------------- */

    private suspend fun both(a: Animatable<Float, *>, b: Animatable<Float, *>, target: Float, ms: Int, easing: Easing) =
        coroutineScope {
            launch { a.animateTo(target, tween(ms, easing = easing)) }
            launch { b.animateTo(target, tween(ms, easing = easing)) }
        }

    private suspend fun look(x: Float, y: Float, t: Float) = coroutineScope {
        launch { pupX.animateTo(x, tween(320, easing = FastOutSlowInEasing)) }
        launch { pupY.animateTo(y, tween(320, easing = FastOutSlowInEasing)) }
        launch { tilt.animateTo(t, tween(360, easing = FastOutSlowInEasing)) }
    }

    /** Ease everything back to the contented resting pose. */
    private suspend fun settle(ms: Int) = coroutineScope {
        val e = FastOutSlowInEasing
        launch { lidL.animateTo(RestSnapshot.lidLeft, tween(ms, easing = e)) }
        launch { lidR.animateTo(RestSnapshot.lidRight, tween(ms, easing = e)) }
        launch { browL.animateTo(0f, tween(ms, easing = e)) }
        launch { browR.animateTo(0f, tween(ms, easing = e)) }
        launch { pupX.animateTo(0f, tween(ms, easing = e)) }
        launch { pupY.animateTo(0f, tween(ms, easing = e)) }
        launch { open.animateTo(0f, tween(ms, easing = e)) }
        launch { smile.animateTo(RestSnapshot.mouthSmile, tween(ms, easing = e)) }
        launch { tilt.animateTo(0f, tween(ms, easing = e)) }
        launch { sq.animateTo(0f, tween(ms, easing = e)) }
    }
}

private val EaseOutBack01 = CubicBezierEasing(0.34f, 1.3f, 0.64f, 1f)

/* --- heartbeat blink -----------------------------------------------------
 *
 * Blinking is not an idle behaviour any more: it is a vital sign. It runs on
 * its OWN loop, always, whether or not the randomized idle pool is enabled
 * and whether or not the companion is driving the face -- so he blinks while
 * he is standing still, while a line is on screen, and while nothing at all
 * is happening.
 *
 * The cadence is a human one: roughly every three to five seconds, jittered
 * every single time, because a metronome blink reads as a machine. Every
 * seventh-ish blink is a double, which is what real eyes do.
 *
 * It goes through play(), so the shared mutex still guarantees it can never
 * overlap another expression, and it skips its turn entirely while a gesture
 * owns the face rather than queueing up behind it.
 */
private const val BLINK_GAP_MIN_MS = 2800L
private const val BLINK_GAP_MAX_MS = 5200L

@Composable
fun rememberCelestialFaceState(autoIdle: Boolean = true): CelestialFaceState {
    val state = remember { CelestialFaceState() }

    // ALWAYS ON. Not gated on autoIdle: a face that does not blink looks dead.
    LaunchedEffect(state) {
        // Offset the first one so two characters on screen never blink in
        // lockstep, which is unnervingly noticeable.
        delay(Random.nextLong(400L, 1600L))
        var sinceDouble = 0
        while (isActive) {
            if (!state.isPinned) {
                sinceDouble++
                val double = sinceDouble >= 6 && Random.nextFloat() < 0.5f
                if (double) sinceDouble = 0
                state.play(
                    if (double) CelestialExpression.DOUBLE_BLINK
                    else CelestialExpression.BLINK
                )
            }
            delay(Random.nextLong(BLINK_GAP_MIN_MS, BLINK_GAP_MAX_MS))
        }
    }

    if (autoIdle) {
        LaunchedEffect(state) {
            // The blink heartbeat above owns blinking now, so this pool is
            // only the expressive stuff -- looks, smirks, the odd shiver.
            val pool = listOf(
                CelestialExpression.TWITCH, CelestialExpression.BROW_RAISE,
                CelestialExpression.BROW_RAISE, CelestialExpression.WINK,
                CelestialExpression.LOOK_AROUND, CelestialExpression.LOOK_AROUND,
                CelestialExpression.SURPRISE,
                CelestialExpression.SLEEPY, CelestialExpression.SHIVER
            )
            var last: CelestialExpression? = null
            while (isActive) {
                delay(Random.nextLong(4000L, 11000L))
                if (state.isPinned) continue
                var pick = pool.random()
                // Never the same big expression twice running.
                if (pick == last) pick = CelestialExpression.LOOK_AROUND
                last = pick
                state.play(pick)
            }
        }
    }
    return state
}

/* ============================================================================
 * DRAWING — pure, scale-invariant, no state reads, no side effects
 * ==========================================================================*/

/* Hoisted, reused scratch paths (main-thread only, like all DrawScope work).
 * NO Path/List allocation happens inside the draw pass. */
private val bodyClipPath = Path()
private val mouthPath = Path()
private val browPath = Path()
private val rayPath = Path()

/* Deterministic pseudo-random in 0..1 — seeds static features (ray lengths,
 * crater layout, star speckle) so nothing ever jitters frame to frame. */
private fun hash01(i: Int): Float {
    val s = sin(i * 127.1f + 311.7f) * 43758.5453f
    return s - kotlin.math.floor(s)
}

private const val RAY_COUNT = 12
private const val STAR_COUNT = 9

/* Fixed crater layout: (x, y, size) in body-radius units. */
private val CRATERS = floatArrayOf(
    -0.42f, -0.30f, 0.16f,
    0.30f, -0.52f, 0.10f,
    0.52f, 0.16f, 0.13f,
    -0.18f, 0.55f, 0.09f,
    -0.62f, 0.18f, 0.07f
)

/* Palettes */
private val SunCore = Color(0xFFFFF3C4)
private val SunMid = Color(0xFFFFCF54)
private val SunEdge = Color(0xFFF59E2B)
private val SunRay = Color(0xFFFFD866)
private val SunInk = Color(0xFF54331A)
private val SunBlush = Color(0xFFF07B3F)

private val MoonCore = Color(0xFFF2F5FC)
private val MoonMid = Color(0xFFC9D5E8)
private val MoonEdge = Color(0xFF8DA2C4)
private val MoonInk = Color(0xFF283350)
private val MoonBlush = Color(0xFF7E96C9)
private val MoonHalo = Color(0xFFA9BEE8)
private val StarColor = Color(0xFFDCE6FA)

/**
 * Draws the living body. `form` is CONTINUOUS: 0f = full moon, 1f = full sun,
 * and intermediate values render a sensible blend.
 */
fun DrawScope.drawCelestialBody(
    center: Offset,
    radius: Float,
    form: Float,
    face: CelestialFaceSnapshot,
    timeSec: Float,
    alpha: Float = 1f
) {
    if (alpha <= 0.001f || radius <= 0f) return
    val f = form.coerceIn(0f, 1f)
    val r = radius
    val ink = lerp(MoonInk, SunInk, f)

    /* ---- squash & stretch (volume-ish preserving) ---- */
    val sqx = 1f + face.squash * 0.10f
    val sqy = 1f - face.squash * 0.10f

    /* ================= MOON-SIDE BACKDROP: halo + stars ================= */
    val moonA = (1f - f) * alpha
    if (moonA > 0.01f) {
        drawCircle(
            brush = Brush.radialGradient(
                0.55f to Color.Transparent,
                0.72f to MoonHalo.copy(alpha = 0.14f * moonA),
                1f to Color.Transparent,
                center = center, radius = r * 1.55f
            ),
            radius = r * 1.55f, center = center
        )
        for (i in 0 until STAR_COUNT) {
            val ang = hash01(i) * 2f * PI.toFloat()
            val dist = r * (1.22f + 0.38f * hash01(i + 40))
            val tw = 0.35f + 0.65f * abs(sin(timeSec * (0.8f + hash01(i + 80)) + i * 2.1f))
            val sr = r * (0.018f + 0.02f * hash01(i + 120))
            drawCircle(
                color = StarColor.copy(alpha = tw * moonA * 0.9f),
                radius = sr,
                center = Offset(center.x + cos(ang) * dist, center.y + sin(ang) * dist)
            )
        }
    }

    /* ================= SUN-SIDE BACKDROP: corona + rays ================= */
    val sunA = f * alpha
    if (sunA > 0.01f) {
        drawCircle(
            brush = Brush.radialGradient(
                0.5f to Color.Transparent,
                0.7f to SunRay.copy(alpha = 0.20f * sunA),
                1f to Color.Transparent,
                center = center, radius = r * 1.6f
            ),
            radius = r * 1.6f, center = center
        )
        val spin = timeSec * 5f // deg/sec, slow drift
        for (i in 0 until RAY_COUNT) {
            val baseAng = i * (360f / RAY_COUNT) + spin +
                sin(timeSec * 0.5f + i) * 2.5f
            // Organic, per-ray length: static seed + gentle breathing.
            val len = r * (0.30f + 0.34f * hash01(i)) *
                (1f + 0.10f * sin(timeSec * 0.9f + i * 1.7f))
            val halfW = r * (0.055f + 0.03f * hash01(i + 17))
            val a = baseAng * PI.toFloat() / 180f
            val dirX = cos(a); val dirY = sin(a)
            val px = -dirY; val py = dirX
            val baseR = r * 1.02f
            val bx = center.x + dirX * baseR
            val by = center.y + dirY * baseR
            val tx = center.x + dirX * (baseR + len)
            val ty = center.y + dirY * (baseR + len)
            rayPath.rewind()
            rayPath.moveTo(bx + px * halfW, by + py * halfW)
            rayPath.lineTo(tx, ty)
            rayPath.lineTo(bx - px * halfW, by - py * halfW)
            rayPath.close()
            drawPath(rayPath, SunRay.copy(alpha = 0.85f * sunA))
        }
    }

    /* ============================ THE BODY ============================== */
    withTransform({
        rotate(face.headTilt * 8f, pivot = center)
        scale(sqx, sqy, pivot = center)
    }) {
        val glowCenter = Offset(center.x - r * 0.28f, center.y - r * 0.32f)
        drawCircle(
            brush = Brush.radialGradient(
                0f to lerp(MoonCore, SunCore, f),
                0.62f to lerp(MoonMid, SunMid, f),
                1f to lerp(MoonEdge, SunEdge, f),
                center = glowCenter, radius = r * 1.5f
            ),
            radius = r, center = center, alpha = alpha
        )

        bodyClipPath.rewind()
        bodyClipPath.addOval(
            androidx.compose.ui.geometry.Rect(
                center.x - r, center.y - r, center.x + r, center.y + r
            )
        )
        clipPath(bodyClipPath) {
            /* Moon features: crescent shade + craters */
            if (moonA > 0.01f) {
                drawCircle(
                    color = MoonEdge.copy(alpha = 0.40f * moonA),
                    radius = r * 1.02f,
                    center = Offset(center.x + r * 0.42f, center.y - r * 0.18f)
                )
                var ci = 0
                while (ci < CRATERS.size) {
                    val cx = center.x + CRATERS[ci] * r
                    val cy = center.y + CRATERS[ci + 1] * r
                    val cr = CRATERS[ci + 2] * r
                    drawCircle(MoonEdge.copy(alpha = 0.35f * moonA), cr, Offset(cx, cy))
                    drawCircle(
                        MoonCore.copy(alpha = 0.30f * moonA), cr * 0.72f,
                        Offset(cx - cr * 0.18f, cy - cr * 0.18f)
                    )
                    ci += 3
                }
            }
            /* Sun features: soft inner freckle-blotches of heat */
            if (sunA > 0.01f) {
                drawCircle(
                    SunCore.copy(alpha = 0.30f * sunA), r * 0.5f,
                    Offset(center.x - r * 0.25f, center.y - r * 0.3f)
                )
            }
            /* Rim light — one side, both forms */
            drawArc(
                brush = Brush.radialGradient(
                    0.82f to Color.Transparent,
                    0.97f to Color.White.copy(alpha = 0.35f * alpha),
                    1f to Color.Transparent,
                    center = center, radius = r
                ),
                startAngle = 165f, sweepAngle = 130f, useCenter = true,
                topLeft = Offset(center.x - r, center.y - r),
                size = Size(r * 2f, r * 2f)
            )
            /* Bottom shadow to give the ball weight */
            drawCircle(
                brush = Brush.radialGradient(
                    0.6f to Color.Transparent,
                    1f to ink.copy(alpha = 0.16f * alpha),
                    center = Offset(center.x, center.y - r * 0.25f),
                    radius = r * 1.35f
                ),
                radius = r, center = center
            )
        }

        /* ============================ FACE =============================== */
        drawFace(center, r, f, face, ink, alpha)
    }
}

private fun DrawScope.drawFace(
    center: Offset,
    r: Float,
    f: Float,
    face: CelestialFaceSnapshot,
    ink: Color,
    alpha: Float
) {
    val eyeDX = r * 0.36f
    val eyeY = center.y - r * 0.10f
    val eyeW = r * 0.19f
    val eyeH = r * 0.30f
    val pupilShiftX = face.pupilX * r * 0.06f
    val pupilShiftY = face.pupilY * r * 0.05f
    val blush = lerp(MoonBlush, SunBlush, f)

    /* blush */
    drawCircle(blush.copy(alpha = 0.22f * alpha), r * 0.11f, Offset(center.x - eyeDX - r * 0.06f, eyeY + r * 0.30f))
    drawCircle(blush.copy(alpha = 0.22f * alpha), r * 0.11f, Offset(center.x + eyeDX + r * 0.06f, eyeY + r * 0.30f))

    /* eyes */
    drawEye(Offset(center.x - eyeDX + pupilShiftX, eyeY + pupilShiftY), eyeW, eyeH, face.lidLeft, ink, alpha)
    drawEye(Offset(center.x + eyeDX + pupilShiftX, eyeY + pupilShiftY), eyeW, eyeH, face.lidRight, ink, alpha)

    /* brows — independently animated, thick anime strokes */
    drawBrow(Offset(center.x - eyeDX, eyeY - eyeH * 0.85f), r, face.browLeft, isLeft = true, ink, alpha)
    drawBrow(Offset(center.x + eyeDX, eyeY - eyeH * 0.85f), r, face.browRight, isLeft = false, ink, alpha)

    /* mouth */
    val mouthY = center.y + r * 0.34f
    val mouthW = r * (0.26f + 0.16f * face.mouthSmile)
    val smileDip = face.mouthSmile * r * 0.14f
    val openH = face.mouthOpen * r * 0.24f

    mouthPath.rewind()
    if (face.mouthOpen < 0.06f) {
        mouthPath.moveTo(center.x - mouthW, mouthY - smileDip * 0.35f)
        mouthPath.quadraticBezierTo(center.x, mouthY + smileDip, center.x + mouthW, mouthY - smileDip * 0.35f)
        drawPath(
            mouthPath, ink.copy(alpha = alpha),
            style = Stroke(width = r * 0.045f, cap = StrokeCap.Round)
        )
    } else {
        mouthPath.moveTo(center.x - mouthW, mouthY - smileDip * 0.3f)
        mouthPath.quadraticBezierTo(center.x, mouthY + smileDip * 0.6f, center.x + mouthW, mouthY - smileDip * 0.3f)
        mouthPath.quadraticBezierTo(center.x, mouthY + smileDip * 0.6f + openH, center.x - mouthW, mouthY - smileDip * 0.3f)
        mouthPath.close()
        drawPath(mouthPath, ink.copy(alpha = alpha))
        // little tongue
        drawCircle(
            lerp(MoonBlush, SunBlush, f).copy(alpha = 0.8f * alpha * face.mouthOpen),
            radius = mouthW * 0.4f,
            center = Offset(center.x, mouthY + smileDip * 0.5f + openH * 0.75f)
        )
    }
}

private fun DrawScope.drawEye(
    c: Offset, w: Float, h: Float, lid: Float, ink: Color, alpha: Float
) {
    if (lid > 0.9f) {
        // Fully closed: a cute downward arc.
        browPath.rewind()
        browPath.moveTo(c.x - w, c.y)
        browPath.quadraticBezierTo(c.x, c.y + h * 0.35f, c.x + w, c.y)
        drawPath(browPath, ink.copy(alpha = alpha), style = Stroke(width = w * 0.28f, cap = StrokeCap.Round))
        return
    }
    val openH = h * (1f - lid)
    // Iris/pupil: tall dark oval, anime-style.
    drawOval(
        color = ink.copy(alpha = alpha),
        topLeft = Offset(c.x - w, c.y - openH),
        size = Size(w * 2f, openH * 2f)
    )
    // Specular highlights — the "alive" sparkle.
    drawCircle(Color.White.copy(alpha = 0.95f * alpha), w * 0.38f, Offset(c.x - w * 0.32f, c.y - openH * 0.42f))
    drawCircle(Color.White.copy(alpha = 0.65f * alpha), w * 0.16f, Offset(c.x + w * 0.34f, c.y + openH * 0.35f))
}

private fun DrawScope.drawBrow(
    base: Offset, r: Float, raise: Float, isLeft: Boolean, ink: Color, alpha: Float
) {
    val lift = raise * r * 0.12f
    val arch = r * (0.03f + raise * 0.05f)
    val w = r * 0.15f
    val tiltOut = raise * r * 0.03f * (if (isLeft) -1f else 1f)
    browPath.rewind()
    browPath.moveTo(base.x - w, base.y - lift + (if (isLeft) tiltOut else -tiltOut) * 0f + arch * 0.3f)
    browPath.quadraticBezierTo(
        base.x, base.y - lift - arch,
        base.x + w, base.y - lift + arch * 0.3f + tiltOut
    )
    drawPath(
        browPath, ink.copy(alpha = alpha),
        style = Stroke(width = r * 0.05f, cap = StrokeCap.Round)
    )
}

/* ============================================================================
 * SELF-DRIVING VIEW
 * ==========================================================================*/

/**
 * Ready-to-use view of the character. The face is fully self-driving --
 * blinks, brow raises, looks around -- but the BODY never moves: he is seated
 * in the altar bowl, so the old idle bob and sway are gone for good.
 *
 * [hover] is accepted for source compatibility and deliberately ignored.
 */
@Composable
@Suppress("UNUSED_PARAMETER")
fun CelestialBodyView(
    form: Float,
    modifier: Modifier = Modifier,
    face: CelestialFaceState = rememberCelestialFaceState(),
    hover: Boolean = false
) {
    // Frame clock: updates a Float state each frame. It is read ONLY inside the
    // Canvas draw lambda, so per-frame updates invalidate draw, not composition.
    val timeSec = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (isActive) {
            withFrameNanos { now -> timeSec.floatValue = (now - start) / 1_000_000_000f }
        }
    }

    Canvas(modifier = modifier) {
        val t = timeSec.floatValue
        val snap = face.snapshot()
        val r = size.minDimension * CELESTIAL_BODY_RADIUS_FRACTION
        // Dead centre, always. The bowl holds him; he does not float in it.
        val c = Offset(size.width / 2f, size.height / 2f)
        drawCelestialBody(c, r, form, snap, t)
    }
}

/** Representative pinned pose per expression, for static preview inspection. */
internal fun previewSnapshotFor(expression: CelestialExpression): CelestialFaceSnapshot =
    when (expression) {
        CelestialExpression.NEUTRAL -> RestSnapshot
        CelestialExpression.BLINK -> RestSnapshot.copy(lidLeft = 1f, lidRight = 1f)
        CelestialExpression.DOUBLE_BLINK -> RestSnapshot.copy(lidLeft = 0.32f, lidRight = 0.32f)
        CelestialExpression.TWITCH -> RestSnapshot.copy(browRight = 0.55f, headTilt = 0.07f)
        CelestialExpression.BROW_RAISE -> RestSnapshot.copy(
            browRight = 1f, pupilX = 0.35f, mouthSmile = 0.72f, headTilt = -0.08f
        )
        CelestialExpression.SURPRISE -> RestSnapshot.copy(
            browLeft = 1f, browRight = 1f, lidLeft = 0f, lidRight = 0f,
            mouthOpen = 0.55f, mouthSmile = 0.15f, squash = -0.28f
        )
        CelestialExpression.WINK -> RestSnapshot.copy(
            lidRight = 1f, headTilt = 0.3f, mouthSmile = 0.9f
        )
        CelestialExpression.LOOK_AROUND -> RestSnapshot.copy(
            pupilX = -0.8f, pupilY = -0.15f, headTilt = -0.12f
        )
        CelestialExpression.SLEEPY -> RestSnapshot.copy(
            lidLeft = 0.55f, lidRight = 0.55f, pupilY = 0.3f,
            mouthOpen = 0.7f, mouthSmile = 0.2f
        )
        CelestialExpression.SHIVER -> RestSnapshot.copy(squash = 0.32f, headTilt = 0.09f)
    }
