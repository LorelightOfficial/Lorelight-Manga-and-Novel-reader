package com.lorelight.manga.reader
import com.lorelight.R
import androidx.compose.ui.res.stringResource


import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.animation.core.animateDpAsState
import com.lorelight.ui.theme.tweenSpec
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListItemInfo
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.zIndex
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.lorelight.ui.animation.ShimmerBox
import com.lorelight.ui.reader.VolumeKeyBus
import eu.kanade.tachiyomi.source.model.Page
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import net.engawapg.lib.zoomable.rememberZoomState
import net.engawapg.lib.zoomable.zoomable

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlin.math.abs
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Size

private fun friendlyMangaReaderError(raw: String?): String {
    val message = raw.orEmpty().lowercase()
    return when {
        "extension not installed" in message || "source" in message && "installed" in message ->
            "This manga source is not installed. Reinstall it from Browse and try again."
        "timeout" in message || "timed out" in message ->
            "The source took too long to respond. Check your connection and try again."
        "network" in message || "unable to resolve" in message || "unknown host" in message ||
            "connection" in message ->
            "Lorelight couldn't connect. Check your internet connection and try again."
        "403" in message || "forbidden" in message || "blocked" in message ->
            "The source blocked this request. Open it in Browse, then try again."
        "404" in message || "not found" in message ->
            "This chapter is no longer available from the source."
        else -> "Lorelight couldn't load this chapter. Please try again."
    }
}

fun pagerIndexToTruePage(pagerIndex: Int, total: Int): Int {
    return if (total > 0) (total - 1 - pagerIndex).coerceIn(0, total - 1) else 0
}

fun truePageToPagerIndex(truePage: Int, total: Int): Int {
    return if (total > 0) (total - 1 - truePage).coerceIn(0, total - 1) else 0
}

fun computeInitialFeedIndex(prevPageCount: Int, hasPrevTransition: Boolean, savedPageIndex: Int): Int {
    return prevPageCount + (if (hasPrevTransition) 1 else 0) + savedPageIndex
}

@Composable
fun MangaReaderScreen(
    viewModel: MangaReaderViewModel,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val state by viewModel.uiState.collectAsState()
    // Shared motion policy (Settings > Appearance > Motion & Performance).
    // Captured once here so every page-turn/scroll/fade below can defer to
    // it instead of hardcoding its own animation behaviour.
    val motionLevel = com.lorelight.ui.theme.LocalMotionLevel.current

    // SMOOTH SCROLL: hold library UI refreshes while the reader is on screen.
    //
    // Each page-progress save of an entry that has a library row notifies
    // ReadingProgressSignal; MainActivity then reloads the library and
    // reassigns its root state, recomposing the whole tree in the middle of a
    // fling. That is why an in-library manga stuttered roughly twice a second
    // while the identical file opened from History scrolled smoothly. Progress
    // still reaches disk on the same schedule -- only the refresh of screens
    // that are not visible is postponed, and endDeferred delivers one bump so
    // they are all up to date the instant this reader closes.
    DisposableEffect(Unit) {
        com.lorelight.data.local.ReadingProgressSignal.beginDeferred()
        onDispose { com.lorelight.data.local.ReadingProgressSignal.endDeferred() }
    }

    val rawNovelId = state.novel?.id ?: ""
    val novelId = rawNovelId
    var lastNovelId by remember { mutableStateOf(rawNovelId) }
    var activeReadingMode by remember {
        mutableStateOf(
            if (rawNovelId.isNotBlank()) MangaReaderPrefs.getEffectiveReadingMode(context, rawNovelId)
            else MangaReaderPrefs.getReadingMode(context)
        )
    }

    LaunchedEffect(rawNovelId) {
        if (rawNovelId.isNotBlank() && rawNovelId != lastNovelId) {
            lastNovelId = rawNovelId
            activeReadingMode = MangaReaderPrefs.getEffectiveReadingMode(context, rawNovelId)
        }
    }

    val settingsVersion by com.lorelight.data.local.AppSettingsSignal.version.collectAsState()
    val splitToolbarEnabled = remember(context, settingsVersion) {
        MangaReaderPrefs.getSplitToolbarEnabled(context)
    }

    val readerPrefs = remember(context, settingsVersion) { context.getSharedPreferences("reader_prefs", Context.MODE_PRIVATE) }
    // FIX C18: the manga settings panel writes its custom background colour
    // into MangaReaderPrefs, but the reader only ever read the NOVEL reader's
    // "reader_prefs" store, so picking a custom colour in the manga reader did
    // nothing at all. Prefer the manga value; fall back to the novel reader's
    // value when the manga store has never been written.
    val readerBgColorRaw = remember(context, settingsVersion) {
        val mangaBg = MangaReaderPrefs.getReaderBgColor(context)
        if (mangaBg != 0xFF1C1B1FL) mangaBg
        else readerPrefs.getLong("reader_bg_color", 0xFF1C1B1FL)
    }
    // The manga settings panel writes its own background override into
    // MangaReaderPrefs. The reader used to read only "reader_prefs", which is
    // the novel reader's store, so the Background chip could never take effect.
    // Fall back to the app theme when no manga-specific choice has been made.
    val readerBackgroundType = remember(context, settingsVersion) {
        MangaReaderPrefs.getReaderBackgroundTypeOrNull(context)
            ?: readerPrefs.getString("reader_background_type", "Theme")
            ?: "Theme"
    }
    val appTheme = remember(context, settingsVersion) { readerPrefs.getString("app_theme", "Forest Green") ?: "Forest Green" }

    val themeBgColor = remember(appTheme) { com.lorelight.ui.reader.getThemeBgColor(appTheme) }
    val themeTextColor = remember(appTheme) { com.lorelight.ui.reader.getThemeTextColor(appTheme) }

    val bgColor = remember(readerBackgroundType, readerBgColorRaw, themeBgColor) {
        if (readerBackgroundType == "AMOLED Black") {
            Color.Black
        } else if (readerBackgroundType == "Theme") {
            themeBgColor
        } else {
            if (readerBgColorRaw == 0xFF1C1B1FL) themeBgColor else Color(readerBgColorRaw)
        }
    }

    val textColor = remember(bgColor, readerBackgroundType, themeTextColor) {
        if (readerBackgroundType == "AMOLED Black" || bgColor == Color.Black) {
            Color.White
        } else if (readerBackgroundType == "Theme") {
            themeTextColor
        } else {
            val isDark = (0.299f * bgColor.red + 0.587f * bgColor.green + 0.114f * bgColor.blue) < 0.5f
            if (isDark) Color.White else Color.Black
        }
    }

    // SINGLE-LAYER THEME BG, per request. "Theme" mode now shows ONLY the
    // image for that theme, at full opacity, as the entire background -- no
    // flat colour layer underneath it, and no separate "Background texture"
    // opt-in setting blended on top. That setting has been removed entirely,
    // matching the novel reader.
    val showReaderBgImage = readerBackgroundType == "Theme"
    val readerBgImageRes = remember(appTheme) {
        when (appTheme) {
            "blackgold" -> com.lorelight.R.drawable.readergold
            "Satin Pink" -> com.lorelight.R.drawable.readerpink
            "readerblacknew" -> com.lorelight.R.drawable.readerblack
            "Ocean Blue" -> com.lorelight.R.drawable.readerblue
            "cyne" -> com.lorelight.R.drawable.readercyne
            "readerpurple" -> com.lorelight.R.drawable.readerpurple
            "readerblood" -> com.lorelight.R.drawable.readerred
            else -> com.lorelight.R.drawable.readergreen
        }
    }

    val keepScreenOn = remember(context, settingsVersion) { MangaReaderPrefs.getKeepScreenOn(context) }
    val showPageNumber = remember(context, settingsVersion) { MangaReaderPrefs.getShowPageNumber(context) }
    val orientationPref = remember(context, settingsVersion) { MangaReaderPrefs.getOrientation(context) }
    val volumeKeyNav = remember(context, settingsVersion) { MangaReaderPrefs.getVolumeKeyNav(context) }

    LaunchedEffect(orientationPref) {
        val activity = context as? Activity
        activity?.requestedOrientation = when (orientationPref) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            2 -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            (context as? Activity)?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    // YIELD WHILE READING. The novel ReaderScreen has always claimed this for
    // its whole lifetime; the manga reader never did, so background offline
    // policy sweeps kept running (and toasting) while pages were being read or
    // autoscrolled. Claimed for the lifetime of the screen and released in
    // onDispose, so an early return or a crash out of the reader cannot leave
    // the claim stuck and silently disable policy downloads until restart.
    DisposableEffect(Unit) {
        com.lorelight.data.download.DownloadPolicyScheduler.enterUserActivity()
        onDispose {
            com.lorelight.data.download.DownloadPolicyScheduler.exitUserActivity()
        }
    }
    val sidePaddingPercent = remember(context, settingsVersion) { MangaReaderPrefs.getSidePadding(context) }
    val disableZoomOut = remember(context, settingsVersion) { MangaReaderPrefs.getDisableZoomOut(context) }
    val doubleTapToZoom = remember(context, settingsVersion) { MangaReaderPrefs.getDoubleTapToZoom(context) }
    val grayscale = remember(context, settingsVersion) { MangaReaderPrefs.getGrayscale(context) }
    val invertColors = remember(context, settingsVersion) { MangaReaderPrefs.getInvertColors(context) }
    val brightnessOverlay = remember(context, settingsVersion) { MangaReaderPrefs.getBrightnessOverlay(context) }
    val fullscreenPref = remember(context, settingsVersion) { MangaReaderPrefs.getFullscreen(context) }
    val invertVolumeKeys = remember(context, settingsVersion) { MangaReaderPrefs.getInvertVolumeKeys(context) }
    val pageGap = remember(context, settingsVersion) { MangaReaderPrefs.getPageGap(context) }
    val maxZoomPref = remember(context, settingsVersion) { MangaReaderPrefs.getMaxZoom(context) }
    val doubleTapZoomPref = remember(context, settingsVersion) { MangaReaderPrefs.getDoubleTapZoom(context) }
    val scaleTypePref = remember(context, settingsVersion) { MangaReaderPrefs.getScaleType(context) }
    val cropBorders = remember(context, settingsVersion) { MangaReaderPrefs.getCropBorders(context) }
    val pageContentScale = remember(scaleTypePref) {
        when (scaleTypePref) {
            "Fit height" -> ContentScale.Fit
            "Fit screen" -> ContentScale.Fit
            "Stretch" -> ContentScale.FillBounds
            "Original size" -> ContentScale.Inside
            else -> ContentScale.FillWidth
        }
    }
    val pageColorFilter = remember(grayscale, invertColors) {
        if (!grayscale && !invertColors) {
            null
        } else {
            val m = androidx.compose.ui.graphics.ColorMatrix()
            if (grayscale) {
                m.setToSaturation(0f)
            }
            if (invertColors) {
                m.timesAssign(
                    androidx.compose.ui.graphics.ColorMatrix(
                        floatArrayOf(
                            -1f, 0f, 0f, 0f, 255f,
                            0f, -1f, 0f, 0f, 255f,
                            0f, 0f, -1f, 0f, 255f,
                            0f, 0f, 0f, 1f, 0f
                        )
                    )
                )
            }
            androidx.compose.ui.graphics.ColorFilter.colorMatrix(m)
        }
    }

    var showChrome by remember { mutableStateOf(true) }
    var showContentsSheet by remember { mutableStateOf(false) }
    var showSettingsPanel by remember { mutableStateOf(false) }
    val showPageSlider = remember(context, settingsVersion) { MangaReaderPrefs.getShowPageSlider(context) }
    var showModePanel by remember { mutableStateOf(false) }
    var isAutoscrolling by remember { mutableStateOf(false) }
    var autoscrollSpeed by remember(context, settingsVersion) { mutableIntStateOf(MangaReaderPrefs.getAutoscrollSpeed(context)) }
    val followVoiceTts = remember(context, settingsVersion) { MangaReaderPrefs.getFollowVoiceTts(context) }

    // STALE-PREFERENCE FIX. These four were read either inside a tap lambda or
    // through remember(context). A remember keyed on context is only
    // invalidated when the Activity context changes -- never when a setting
    // changes. Every other reader preference above is keyed on settingsVersion,
    // which AppSettingsSignal bumps on any preference write, so these four were
    // the only ones still serving the value captured when the reader opened.
    // That is exactly why changing them appeared to do nothing until the reader
    // was closed and reopened, and why the tap zones stayed on RIGHT_AND_LEFT
    // no matter what was selected: RIGHT_AND_LEFT is the migration default that
    // getTapZoneLayout writes on first run.
    val pauseOnTap = remember(context, settingsVersion) { MangaReaderPrefs.getAutoscrollPauseOnTap(context) }
    val tapZonesEnabled = remember(context, settingsVersion) { MangaReaderPrefs.getTapZonesEnabled(context) }
    val tapZoneLayout = remember(context, settingsVersion) { MangaReaderPrefs.getTapZoneLayout(context) }
    val tapZoneInvert = remember(context, settingsVersion) { MangaReaderPrefs.getTapZoneInvert(context) }

    // Temporary autoscroll speed panel, mirroring the reading-mode popup.
    // autoscrollPanelNudge restarts the auto-hide timer, so the panel stays up
    // while the slider is actually being used.
    var showAutoscrollPanel by remember { mutableStateOf(false) }
    var autoscrollPanelNudge by remember { mutableIntStateOf(0) }

    // ADAPTIVE PANEL POSITION.
    //
    // The panel was pinned to the very top of the screen at all times, so with
    // the chrome up it sat on top of the very bar holding the button that
    // raises it. Now it drops to just under the top bar while the chrome is
    // visible, and rises to the top only once there is no bar left to clear.
    //
    // Animated rather than switched, because a panel that teleports the
    // instant the chrome toggles reads as a glitch.
    val autoscrollBarInset = WindowInsets.statusBars
        .asPaddingValues()
        .calculateTopPadding()
    val autoscrollPanelTop by animateDpAsState(
        targetValue = autoscrollBarInset + if (showChrome) 52.dp else 8.dp,
        label = "autoscrollPanelTop"
    )

    // Bumped when a finger lifts while "pause on tap" is OFF, so the autoscroll
    // scroll session that the finger cancelled gets started again.
    var autoscrollResumeToken by remember { mutableIntStateOf(0) }

    // MANUAL-SCROLL GRACE. autoscrollResumeToken is only a *request* to resume.
    // The autoscroll loop keys on autoscrollRunToken instead, which is bumped
    // once the finger has been off the glass for autoscrollResumeDelay
    // milliseconds. Every fresh lift restarts that wait, so scrolling to a spot
    // by hand is never fought by the machine part-way through the gesture.
    var autoscrollRunToken by remember { mutableIntStateOf(0) }
    var autoscrollTouching by remember { mutableStateOf(false) }
    val autoscrollResumeDelay = remember(context, settingsVersion) { MangaReaderPrefs.getAutoscrollResumeDelay(context) }

    // ONE autoscroll toggle, shared by every top bar this screen puts up.
    //
    // The bar drawn while the first chapter is still loading passed an empty
    // lambda for this button and for the contents button, so both were dead
    // controls -- and on a tablet that bar stays up noticeably longer, because
    // a page fitted to a tablet's width is a much bigger decode. Pressing
    // autoscroll there did nothing whatsoever, which is exactly what "the
    // button does not work" looks like from the outside.
    //
    // The gate on LONG_STRIP that used to live inside this lambda is gone too:
    // paged modes have their own autoscroll now, so the button means the same
    // thing in every reading mode instead of silently doing nothing in three
    // of the four.
    val toggleAutoscroll: () -> Unit = {
        isAutoscrolling = !isAutoscrolling
        // The panel comes up on every press rather than toggling, so the speed
        // slider is always one drag away, and its own play button is unchanged.
        showAutoscrollPanel = true
        autoscrollPanelNudge++
    }

    // A stalled page is usually a symptom of a stalled chapter fetch, so the
    // "restart stuck page loads" button asks the chapter loader to try again too.
    val pageRetryVersion by MangaPageRetryBus.version.collectAsState()
    LaunchedEffect(pageRetryVersion) {
        if (pageRetryVersion > 0) viewModel.ensureNextChapterLoading()
    }

    // Nothing to push in any more. Download concurrency and preload depth are
    // fixed constants, matching mihon, so there is no per-reader tuning state.
    var showZoneOverlay by remember { mutableStateOf(false) }

    // BACK ALIGNMENT: the manga reader had NO back handler of its own, so the
    // system/gesture Back went straight to MainActivity and closed the reader
    // even while the settings panel, contents sheet, mode popup or tap-zone
    // overlay was covering the page - the in-app arrow was unreachable at that
    // moment, so the two gestures could never agree. Back now peels off one
    // layer at a time and only then does what the toolbar arrow does.
    androidx.activity.compose.BackHandler {
        when {
            showZoneOverlay -> showZoneOverlay = false
            showAutoscrollPanel -> showAutoscrollPanel = false
            showSettingsPanel -> showSettingsPanel = false
            showModePanel -> showModePanel = false
            showContentsSheet -> showContentsSheet = false
            else -> onClose()
        }
    }

    // Screen-based TTS (experimental). Hidden entirely unless the user turns on
    // the toggle in Settings > EXPERIMENTAL.
    val ttsExperimentalOn = remember(context, settingsVersion) { MangaReaderPrefs.getExperimentalTts(context) }
    val showDetectedText = remember(context, settingsVersion) { MangaReaderPrefs.getShowOcrBoxes(context) }
    val ttsController = remember { MangaTtsController() }

    val isTtsReadingActive = ttsController.sessionOn && !ttsController.isPaused
    // One slider now drives both plain autoscroll and read-aloud autoscroll.
    val targetAutoscrollSpeed = autoscrollSpeed.toFloat()
    val animatedAutoscrollSpeed by androidx.compose.animation.core.animateFloatAsState(
        targetValue = targetAutoscrollSpeed,
        animationSpec = motionLevel.tweenSpec(durationMillis = 250),
        label = "autoscroll_speed_anim"
    )

    // A THIRD prefetcher used to live here. Between this one, the paged-mode
    // warmer and the webtoon viewer's own window, a single scroll could put
    // eighteen equal-priority requests in flight -- and Coil has no notion of
    // priority, so the page actually on screen queued behind all of them.
    // Preloading now happens in exactly one place per viewer, mihon-style.

    LaunchedEffect(Unit) {
        if (MangaReaderPrefs.getShowZoneOverlayOnOpen(context) &&
            MangaReaderPrefs.getTapZonesEnabled(context)
        ) {
            showZoneOverlay = true
        }
    }

    val listState = rememberLazyListState()
    // Keyed on the explicit-jump token, NOT on activeChapterIndex.
    //
    // activeChapterIndex changes during ordinary reading: scrolling from the end
    // of chapter 4 into chapter 5 calls onActivePageChanged(5, ...). Because this
    // flag used to be keyed on it, remember() dropped its value, the effect below
    // re-armed, and scrollToItem() fired in the middle of the gesture. If the new
    // chapter's pages were not in the feed yet it fell through to
    // firstActivePageIdx and yanked the list to the chapter start -- the "sticks
    // to the start of a chapter" bug. The forced re-anchor then made the very
    // next flick land inside chapter 6, which is the "goes to 6 automatically"
    // bug. Both come from this one key.
    var hasScrolledInitial by remember(state.jumpToken) { mutableStateOf(false) }

    // MIHON PARITY: any scroll hides the chrome so nothing covers the page while
    // reading. A tap still toggles it straight back on. Gated on
    // hasScrolledInitial so the programmatic open-the-reader scroll below does
    // not immediately hide the bars the user has not seen yet.
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress }.collect { scrolling ->
            // TAP-REVEAL FIX. Autoscroll runs inside its own listState.scroll
            // session. A tap takes the mutator mutex away from that session and
            // then, with "pause on tap" OFF, a replacement session starts a
            // moment later -- so isScrollInProgress goes false -> true and this
            // flow re-emits, hiding the chrome the tap had just revealed. That
            // is exactly why a single tap did nothing while autoscrolling. Only
            // a real finger scroll should hide the bars, and DragInteraction
            // below already covers that case.
            // The companion waits for a still screen before speaking, so a
            // bubble never lands mid-flick. Autoscroll deliberately does NOT
            // count as motion here -- no finger is on the glass, and treating
            // it as motion would silence him for a whole autoscroll session.
            if (scrolling && !isAutoscrolling) {
                com.lorelight.companion.CompanionBus.noteMotion()
            }
            if (scrolling && showChrome && hasScrolledInitial && !isAutoscrolling) {
                showChrome = false
            }
        }
    }

    LaunchedEffect(state.jumpToken, state.feedItems, state.isLoading, listState.isScrollInProgress) {
        // Never re-anchor while a finger, or a fling, is still moving the list.
        // isScrollInProgress is a key as well as a guard, so the anchor still
        // happens once the list settles.
        if (listState.isScrollInProgress) return@LaunchedEffect
        if (!hasScrolledInitial && state.feedItems.isNotEmpty()) {
            val targetIndex = state.feedItems.indexOfFirst {
                it is MangaFeedItem.Page && it.chapterIndex == state.activeChapterIndex && it.pageIndex == state.currentPageIndex
            }
            if (targetIndex != -1) {
                listState.scrollToItem(targetIndex)
                hasScrolledInitial = true
            } else {
                // Target page not found in feed yet. If active chapter has ANY page in feed, fallback to its first page.
                val firstActivePageIdx = state.feedItems.indexOfFirst {
                    it is MangaFeedItem.Page && it.chapterIndex == state.activeChapterIndex
                }
                if (firstActivePageIdx != -1) {
                    listState.scrollToItem(firstActivePageIdx)
                    hasScrolledInitial = true
                } else if (!state.isLoading) {
                    // Chapter finished loading but has no active chapter pages in feed: bail out.
                    hasScrolledInitial = true
                }
            }
        }
    }

    // Switching reading mode no longer kills a run. It used to have to: the
    // scroll loop below is long-strip only, so a run left on in a paged mode
    // showed Pause on the icon with nothing moving. Paged modes autoscroll on
    // their own now, so the flag simply carries across a mode change.

    // Autoscroll Loop - continuous scrolling, dynamically ramping speed when read-aloud is active
    //
    // AUTOSCROLL SMOOTHNESS FIX. The old loop called listState.scrollBy() once
    // per frame. That helper expands to `scroll { scrollBy(it) }`, so every
    // single frame opened and closed a fresh scroll session on the mutator
    // mutex. Three separate problems fell out of that:
    //
    //  1. isScrollInProgress flipped true -> false sixty times a second. The
    //     re-anchor LaunchedEffect above is *keyed* on isScrollInProgress, so it
    //     was torn down and restarted every frame for as long as autoscroll ran,
    //     and the chrome snapshotFlow re-emitted just as often. That is the lag.
    //  2. dt was sampled with System.nanoTime() *after* the frame callback
    //     returned, so each frame's own layout and draw cost leaked into the
    //     next delta. Speed then wobbled with rendering load rather than holding
    //     steady. That is the inconsistency.
    //  3. One slow frame (page decode, GC pause) produced a correspondingly
    //     huge delta and the page lurched.
    //
    // Now: a single scroll session for the whole run, deltas taken from the
    // frame clock itself, and dt clamped so a stall cannot teleport the page.
    // Starting autoscroll still hides the chrome once, exactly as before. This
    // is now stated outright instead of being a side effect of
    // isScrollInProgress, which the tap-reveal fix above stopped listening to.
    LaunchedEffect(isAutoscrolling) {
        if (isAutoscrolling) showChrome = false
    }

    val density = LocalDensity.current.density
    LaunchedEffect(isAutoscrolling, activeReadingMode, autoscrollRunToken) {
        if (!isAutoscrolling || activeReadingMode != MangaReadingMode.LONG_STRIP) return@LaunchedEffect
        // SELF-HEALING SESSION.
        //
        // The whole run used to be ONE listState.scroll {} session, and a
        // cancellation of that session was caught, swallowed, and the effect
        // then simply finished. Every programmatic scroller in this file takes
        // the very same mutator mutex and therefore cancels it: the opening
        // re-anchor, a tap-zone jump, a page-slider seek, read-aloud centring a
        // bubble, a chapter picked out of the drawer. Any one of them ended
        // autoscroll for good while isAutoscrolling stayed true -- so the
        // toolbar icon sat on Pause, the page never moved again, and the button
        // looked broken when in fact the run had already died. The session is
        // re-acquired now. Only a finger (which has its own resume path), a
        // torn-down effect, or something that will not let go at all ends a run.
        var reacquires = 0
        while (isAutoscrolling) {
            val tokenAtStart = autoscrollResumeToken
            val sessionStart = System.currentTimeMillis()
            try {
                listState.scroll {
                    var lastFrameNanos = 0L
                    while (true) {
                        val frameNanos = withFrameNanos { it }
                        if (lastFrameNanos == 0L) {
                            // First tick only establishes the clock baseline.
                            lastFrameNanos = frameNanos
                            continue
                        }
                        // Cap at ~50ms (three dropped frames). Past that we
                        // would be compensating for a stall the reader never
                        // perceived.
                        val dt = ((frameNanos - lastFrameNanos).coerceAtLeast(0L) / 1_000_000_000f)
                            .coerceAtMost(0.05f)
                        lastFrameNanos = frameNanos
                        if (dt <= 0f) continue

                        val delta = animatedAutoscrollSpeed * density * dt
                        if (delta <= 0f) continue
                        // LazyListState carries its own sub-pixel remainder
                        // between calls within one session, so slow speeds keep
                        // advancing instead of being rounded away frame after
                        // frame.
                        val consumed = scrollBy(delta)
                        if (consumed < 0.01f && !listState.canScrollForward) {
                            val isAtLastChapter = state.activeChapterIndex >= state.chapterUrls.size - 1
                            if (isAtLastChapter) {
                                isAutoscrolling = false
                                break
                            }
                        }
                    }
                }
                // Came back on its own terms: the strip ran out at the last
                // chapter and the loop above cleared the flag.
                break
            } catch (_: kotlinx.coroutines.CancellationException) {
                // A finger takes the mutex at UserInput priority and cancels
                // this session; the drag listener is what clears
                // isAutoscrolling or schedules the resume, so swallowing here
                // still just avoids a noisy throw on a normal interaction.
                // Anything else that cancelled us was a programmatic scroll,
                // and that is what the re-acquire below exists for. A session
                // that survived a second was doing its job, so it does not
                // count against the retry budget.
                if (System.currentTimeMillis() - sessionStart > 1_000L) {
                    reacquires = 0
                } else {
                    reacquires++
                }
            }
            // Being fought by something that is not going to stop. Give up
            // rather than spin.
            if (reacquires > 12) break
            // Cancellation checkpoint as well as a beat: if this effect was
            // torn down (mode change, leaving the reader) delay throws here and
            // the run ends exactly as it used to.
            kotlinx.coroutines.delay(140L)
            // A finger was involved after all -- autoscrollTouching while it is
            // still down, autoscrollResumeToken once it has lifted. The
            // manual-scroll grace below owns the restart in that case, and
            // re-acquiring here would fight the reader mid-gesture.
            if (autoscrollTouching || autoscrollResumeToken != tokenAtStart) break
            // Whatever else took the page may still be animating. Let it finish
            // instead of yanking the mutex straight back out of its hands.
            var settleWaits = 0
            while (listState.isScrollInProgress && settleWaits < 20) {
                kotlinx.coroutines.delay(100L)
                settleWaits++
            }
        }
    }

    // Two unrelated jobs live here, and both were broken by the same three lines.
    //
    //  * "Pause on tap" -- a tap on a lazy list arrives as DragInteraction.Start,
    //    because the scrollable claims the finger-down to measure drag slop
    //    before it can know the gesture was only a tap. The old code stopped
    //    autoscroll on every Start and never consulted the preference at all, so
    //    the feature behaved as though it were permanently on. It is honoured
    //    now, and when it is off the scroll session the finger cancelled is
    //    restarted on lift instead of being left dead.
    //
    //  * "Hide the bars while reading" -- this used to hang off
    //    isScrollInProgress gated on hasScrolledInitial, and hasScrolledInitial
    //    only becomes true once the opening anchor scroll lands. On a weak
    //    connection the anchor never lands, so the gate never opened and the
    //    bars sat on top of the page for the whole session. A real finger drag
    //    is unambiguous evidence of reading, so it hides them directly and can
    //    no longer be blocked by a chapter that is still loading.
    LaunchedEffect(listState, pauseOnTap) {
        listState.interactionSource.interactions.collect { interaction ->
            when (interaction) {
                is DragInteraction.Start -> {
                    showChrome = false
                    autoscrollTouching = true
                    if (pauseOnTap) isAutoscrolling = false
                }
                is DragInteraction.Stop, is DragInteraction.Cancel -> {
                    autoscrollTouching = false
                    if (!pauseOnTap && isAutoscrolling) autoscrollResumeToken++
                }
            }
        }
    }

    // MANUAL-SCROLL GRACE (see autoscrollRunToken above). Keyed on the request
    // token, so every new finger lift cancels the previous wait and starts a
    // fresh one. Hold the page, scroll where you want, and autoscroll only picks
    // up again once you have actually settled -- it no longer snatches the page
    // back the instant your finger leaves.
    LaunchedEffect(autoscrollResumeToken, autoscrollResumeDelay) {
        if (autoscrollResumeToken == 0) return@LaunchedEffect
        kotlinx.coroutines.delay(autoscrollResumeDelay.toLong())
        if (!autoscrollTouching) autoscrollRunToken++
    }

    // --- Screen-based TTS (Page drives speech) -------------------------------
    // Read-aloud never moves the page by itself. It reads whatever text is currently
    // visible on screen in top-to-bottom order. Movement is controlled by the user
    // or by the Autoscroll feature.

    /** Optional bubble centering (only active if Follow Voice is enabled). */
    suspend fun focusTtsBlock(pageItem: MangaFeedItem.Page, block: MangaTextBlock) {
        if (!followVoiceTts) return
        if (activeReadingMode != MangaReadingMode.LONG_STRIP) return
        val items = viewModel.uiState.value.feedItems
        val targetKey = feedItemKey(pageItem)
        val idx = items.indexOfFirst { it is MangaFeedItem.Page && feedItemKey(it) == targetKey }
        if (idx < 0) return

        ttsController.autoScrolling = true
        try {
            val info = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == idx } ?: return
            val viewportStart = listState.layoutInfo.viewportStartOffset
            val viewportEnd = listState.layoutInfo.viewportEndOffset
            val viewportH = (viewportEnd - viewportStart).coerceAtLeast(1)

            val isImageTotallyVisible = (info.offset >= viewportStart) && ((info.offset + info.size) <= viewportEnd)
            if (isImageTotallyVisible) return

            val bubbleTop = if (block.pageHeight > 0) {
                info.offset + ((block.top.toFloat() / block.pageHeight.toFloat()) * info.size)
            } else {
                info.offset + (info.size * block.verticalFraction)
            }
            val bubbleBottom = if (block.pageHeight > 0) {
                info.offset + ((block.bottom.toFloat() / block.pageHeight.toFloat()) * info.size)
            } else {
                bubbleTop + (info.size * 0.05f)
            }

            val isBubbleComfortablyVisible = (bubbleTop >= viewportStart + (viewportH * 0.08f)) &&
                (bubbleBottom <= viewportEnd - (viewportH * 0.08f))
            if (isBubbleComfortablyVisible) return

            val blockCenter = (bubbleTop + bubbleBottom) / 2f
            val delta = blockCenter - (viewportH * 0.38f)

            if (kotlin.math.abs(delta) < viewportH * 0.10f) return

            val durationMillis = (kotlin.math.abs(delta) / viewportH.toFloat() * 500f).toInt().coerceIn(180, 650)
            try {
                listState.animateScrollBy(
                    delta,
                    tween(durationMillis = durationMillis, easing = FastOutSlowInEasing)
                )
            } catch (e: CancellationException) {
                if (!currentCoroutineContext().isActive) {
                    throw e
                }
            }
        } finally {
            withFrameNanos { }
            ttsController.autoScrolling = false
        }
    }

    /** Move one page forward/back. In paged modes this auto-flips the page. */
    suspend fun advanceTtsPage(delta: Int): Boolean {
        val s = viewModel.uiState.value
        val pageItems = s.feedItems.filterIsInstance<MangaFeedItem.Page>()
        if (pageItems.isEmpty()) return false
        // Step relative to the page READ-ALOUD is on, not the page the user
        // happens to have scrolled to. Otherwise skimming ahead by hand makes
        // "next page" leap from the user's position instead of the voice's.
        val currentIdx = ttsController.ttsPageKey
            ?.let { key -> pageItems.indexOfFirst { feedItemKey(it) == key } }
            ?.takeIf { it >= 0 }
            ?: pageItems.indexOfFirst {
                it.chapterIndex == s.activeChapterIndex && it.pageIndex == s.currentPageIndex
            }
        val nextIdx = (if (currentIdx < 0) 0 else currentIdx) + delta
        if (nextIdx < 0 || nextIdx >= pageItems.size) return false
        val target = pageItems[nextIdx]
        viewModel.onPageChanged(target.pageIndex)
        when (activeReadingMode) {
            MangaReadingMode.LONG_STRIP -> {
                val targetKey = feedItemKey(target)
                val itemIdx = s.feedItems.indexOfFirst { it is MangaFeedItem.Page && feedItemKey(it) == targetKey }
                if (itemIdx >= 0) {
                    try {
                        listState.animateScrollToItem(itemIdx)
                    } catch (e: CancellationException) {
                        if (!currentCoroutineContext().isActive) {
                            throw e
                        }
                    }
                }
            }
            MangaReadingMode.PAGED_LTR,
            MangaReadingMode.PAGED_VERTICAL,
            MangaReadingMode.PAGED_RTL -> {
                // The pager lives in a narrower scope, so post a request and let
                // the pager consume it rather than reaching into it from here.
                ttsController.pageFlipTarget = target.pageIndex
            }
        }
        ttsController.loadedPageKey = null
        ttsController.blockIndex = 0
        return true
    }

    val ttsLifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(ttsLifecycleOwner, ttsController) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_STOP) {
                // Screen off or app backgrounded: this feature must not continue.
                ttsController.stop()
                // Page progress is debounced; don't leave it waiting if we get killed.
                com.lorelight.data.db.DbWriter.flushDebounced()
            }
        }
        ttsLifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            ttsLifecycleOwner.lifecycle.removeObserver(observer)
            ttsController.shutdown()
        }
    }

    // Voice, speed and pitch changed in reader settings mid-session used to be
    // ignored until the next session. Re-apply them live.
    //
    // This used to watch TtsPlaybackManager's live flows, which are the NOVEL
    // reader's session state -- the last thread tying the two readers together.
    // It now keys on the manga settings signal, which bumps whenever a manga
    // pref is written, so novel playback and manga read-aloud no longer nudge
    // each other in either direction.
    LaunchedEffect(ttsController.sessionOn, settingsVersion) {
        if (!ttsController.sessionOn) return@LaunchedEffect
        ttsController.applyVoiceSettings()
    }

    // Pre-warm OCR engine and pre-fetch first/current page text in background
    LaunchedEffect(state.activeChapterIndex, state.feedItems) {
        val s = state
        val pageItems = s.feedItems.filterIsInstance<MangaFeedItem.Page>()
        val startPage = pageItems.firstOrNull {
            it.chapterIndex == s.activeChapterIndex && it.pageIndex == s.currentPageIndex
        } ?: pageItems.firstOrNull { it.chapterIndex == s.activeChapterIndex } ?: pageItems.firstOrNull() ?: return@LaunchedEffect

        kotlinx.coroutines.withContext(Dispatchers.IO) {
            MangaPageOcr.warmRecognizer()
            val startKey = feedItemKey(startPage)
            if (ttsController.cachedBlocks(startKey) == null) {
                val pageObj = startPage.sourcePage ?: Page(startPage.pageIndex, startPage.imageUrl, startPage.imageUrl)
                val ocrRes = MangaPageOcr.processPageOcr(
                    context,
                    s.sourceId ?: 0L,
                    pageObj,
                    activeReadingMode == MangaReadingMode.PAGED_RTL,
                    MangaPageOcr.seamNeighbors(pageItems, startPage)
                )
                if (ocrRes is MangaPageOcrResult.Success && ocrRes.blocks.isNotEmpty()) {
                    ttsController.cacheBlocks(startKey, ocrRes.blocks)
                }
            }
        }
    }

    // Silent pre-scan.
    //
    // With read-aloud switched on, the pages around you are recognised quietly
    // in the background whether or not the voice is running, so pressing play
    // speaks immediately instead of sitting on "Scanning page...". Keyed on the
    // page you are actually on, so it keeps rolling forward as you read rather
    // than scanning once on entry and stopping.
    //
    // Skipped entirely while a session is live: the speech loop runs its own
    // lookahead, and two scanners would queue against the same recognizer.
    LaunchedEffect(
        ttsExperimentalOn,
        ttsController.sessionOn,
        state.activeChapterIndex,
        state.currentPageIndex,
        state.feedItems
    ) {
        if (!ttsExperimentalOn || ttsController.sessionOn) return@LaunchedEffect
        val s = state
        val pageItems = s.feedItems.filterIsInstance<MangaFeedItem.Page>()
        if (pageItems.isEmpty()) return@LaunchedEffect

        // Let the page settle first. Recognising during a fling competes for
        // exactly the frames that must not be dropped, and the key changes
        // again on every page anyway, so an in-flight scan would be thrown
        // away mid-scroll regardless.
        kotlinx.coroutines.delay(700)

        val rtl = activeReadingMode == MangaReadingMode.PAGED_RTL
        val startIdx = pageItems.indexOfFirst {
            it.chapterIndex == s.activeChapterIndex && it.pageIndex == s.currentPageIndex
        }.let { if (it >= 0) it else 0 }
        // Current page plus the same lookahead the speech loop uses.
        val ahead = MangaReaderPrefs.getOcrLookahead(context).coerceAtLeast(1)

        kotlinx.coroutines.withContext(Dispatchers.IO) {
            MangaPageOcr.warmRecognizer()
            var scanned = 0
            var i = startIdx
            while (i <= pageItems.lastIndex && scanned <= ahead) {
                if (!isActive || ttsController.sessionOn) return@withContext
                val item = pageItems[i]
                val key = feedItemKey(item)
                if (ttsController.cachedBlocks(key) == null) {
                    try {
                        val pageObj = item.sourcePage
                            ?: Page(item.pageIndex, item.imageUrl, item.imageUrl)
                        val res = MangaPageOcr.processPageOcr(
                            context,
                            s.sourceId ?: 0L,
                            pageObj,
                            rtl,
                            MangaPageOcr.seamNeighbors(pageItems, item)
                        )
                        if (res is MangaPageOcrResult.Success && res.blocks.isNotEmpty()) {
                            ttsController.cacheBlocks(key, res.blocks)
                        }
                    } catch (t: Throwable) {
                        // Best effort. A page that will not scan now is simply
                        // scanned again when the voice actually reaches it.
                    }
                    scanned++
                    // Breathe between pages so a background scan can never
                    // starve the decode of the page being looked at.
                    kotlinx.coroutines.delay(250)
                }
                i++
            }
        }
    }

    // Load infinity.
    //
    // Loading used to be driven purely by what was on screen: the visible
    // page plus four ahead, and nothing at all on a timer. Sit on chapter one
    // for five minutes and nothing more arrived; you had to scroll to wake it
    // up. This keeps going on its own until the whole loaded feed is on disk,
    // then asks for the next chapter and carries on into that.
    //
    // Three things keep it out of the way of actual reading:
    //  - download only, never decoded, so it cannot evict the page on screen
    //    from the bitmap cache;
    //  - MANGA_PRIORITY_IDLE, below every preload, so scrolling always takes
    //    the next free download slot ahead of it;
    //  - strictly one page in flight, with a pause between pages.
    LaunchedEffect(state.sourceId) {
        val sid = state.sourceId ?: return@LaunchedEffect
        kotlinx.coroutines.withContext(Dispatchers.IO) {
            var settledRounds = 0
            while (isActive) {
                kotlinx.coroutines.delay(1200)
                val s = viewModel.uiState.value
                if (s.sourceId != sid) return@withContext
                val pageItems = s.feedItems.filterIsInstance<MangaFeedItem.Page>()
                if (pageItems.isEmpty()) continue

                // Always re-derive the position from live state instead of
                // keying the effect on the current page. Keying on it would
                // restart this loop on every page turn and throw away a
                // download that was already half finished.
                val fromIdx = pageItems.indexOfFirst {
                    it.chapterIndex == s.activeChapterIndex && it.pageIndex == s.currentPageIndex
                }.let { if (it >= 0) it else 0 }

                var target: MangaFeedItem.Page? = null
                for (i in fromIdx..pageItems.lastIndex) {
                    val item = pageItems[i]
                    val pageObj = item.sourcePage
                        ?: Page(item.pageIndex, item.imageUrl, item.imageUrl)
                    val f = getMangaPageDiskCacheFile(context, sid, pageObj)
                    if (!f.exists() || f.length() <= 0L) {
                        target = item
                        break
                    }
                }

                // Copied into a val so the null check below is a plain
                // smart cast with nothing for the compiler to argue about.
                val hit = target
                if (hit == null) {
                    // Everything ahead is cached. Pull in the next chapter's
                    // page list once so there is more to fetch, then back
                    // right off rather than spinning on a full cache.
                    settledRounds++
                    if (settledRounds == 1) {
                        kotlinx.coroutines.withContext(Dispatchers.Main) {
                            viewModel.ensureNextChapterLoading()
                        }
                    }
                    kotlinx.coroutines.delay(if (settledRounds > 3) 6000 else 2000)
                    continue
                }

                settledRounds = 0
                val pageObj = hit.sourcePage
                    ?: Page(hit.pageIndex, hit.imageUrl, hit.imageUrl)
                prefetchMangaPageFile(context, sid, pageObj)
            }
        }
    }

    val spokenBlockIds = remember { mutableSetOf<String>() }
    val spokenHistory = remember { mutableListOf<String>() }

    LaunchedEffect(state.activeChapterIndex) {
        spokenBlockIds.clear()
        spokenHistory.clear()
    }

    LaunchedEffect(ttsController.sessionOn, activeReadingMode, state.activeChapterIndex) {
        if (!ttsController.sessionOn) {
            spokenBlockIds.clear()
            spokenHistory.clear()
            return@LaunchedEffect
        }
        if (!ttsController.ensureEngine(context)) {
            // stop() clears the status, so setting the message first meant the
            // session ended with no explanation on screen at all.
            val reason = ttsController.engineError ?: "Text-to-speech unavailable"
            ttsController.stop()
            ttsController.updateStatus(reason, MangaTtsStatusCategory.ERROR)
            return@LaunchedEffect
        }
        ttsController.applyVoiceSettings()
        val rtl = activeReadingMode == MangaReadingMode.PAGED_RTL

        var prefetchJob: kotlinx.coroutines.Job? = null
        var ttsLoadFailKey: String? = null
        var ttsLoadFailCount = 0
        var engineRecoveries = 0
        // When the visible pages first turned out to be undrawn, 0 while any
        // are drawn. See step 1b.
        var unrenderedSince = 0L
        val renderWaitGiveUpMs = 8_000L

        while (ttsController.sessionOn) {
            if (ttsController.isPaused) {
                // Paused means the user is in charge again, so the engine gets a
                // fresh recovery budget for when they press play.
                engineRecoveries = 0
                kotlinx.coroutines.delay(150)
                continue
            }

            val s = viewModel.uiState.value
            val pageItems = s.feedItems.filterIsInstance<MangaFeedItem.Page>()
            if (pageItems.isEmpty()) {
                kotlinx.coroutines.delay(200)
                continue
            }

            // User explicit control: Next Page / Prev Page button
            if (ttsController.pendingPageDelta != 0) {
                val delta = ttsController.pendingPageDelta
                ttsController.pendingPageDelta = 0
                if (advanceTtsPage(delta)) {
                    ttsController.ttsPageKey = null
                } else {
                    ttsController.updateStatus("No more pages", MangaTtsStatusCategory.INFORMATIONAL)
                }
                continue
            }

            // 1. Identify which Page items are currently visible on screen
            val visiblePageItemsWithInfo = mutableListOf<Pair<MangaFeedItem.Page, LazyListItemInfo?>>()
            if (activeReadingMode == MangaReadingMode.LONG_STRIP) {
                val visibleInfos = listState.layoutInfo.visibleItemsInfo
                for (info in visibleInfos) {
                    val feedItem = s.feedItems.getOrNull(info.index) as? MangaFeedItem.Page ?: continue
                    visiblePageItemsWithInfo.add(feedItem to info)
                }
            } else {
                // Paged mode
                val curPage = s.currentPageIndex
                val p = pageItems.firstOrNull { it.pageIndex == curPage } ?: pageItems.firstOrNull()
                if (p != null) {
                    visiblePageItemsWithInfo.add(p to null)
                }
            }

            if (visiblePageItemsWithInfo.isEmpty()) {
                ttsController.updateStatus("Waiting for page...", MangaTtsStatusCategory.INFORMATIONAL)
                kotlinx.coroutines.delay(200)
                continue
            }

            // 1b. Never speak a page the reader has not drawn yet.
            //
            // "Visible" above is pure geometry. A page row takes its final
            // height from the aspect cache the instant it scrolls in, so it is
            // reported as visible while it is still nothing but a spinner, and
            // the block positions in step 4 come from OCR coordinates rather
            // than from anything actually on the glass. An undecoded page
            // therefore scored as 60% visible and got spoken.
            //
            // OCR fetches pages through its own request, so the text is ready
            // well before the artwork -- which is how the voice ended up a page
            // or more ahead of the picture. Narrow this to the pages that are
            // genuinely rendered, using the same probe the viewer uses to
            // decide whether to show its spinner.
            //
            // renderWaitGiveUpMs is the safety valve. If nothing renders for
            // that long -- a page that will never decode, or a probe that
            // somehow disagrees with the viewer -- read-aloud carries on rather
            // than going silent forever.
            val visibleSourceId = s.sourceId ?: 0L
            val displayLoader = MangaImageLoaderProvider.getImageLoader(context)
            val renderedVisible = visiblePageItemsWithInfo.filter { (pItem, _) ->
                val pageObj = pItem.sourcePage
                    ?: Page(pItem.pageIndex, pItem.imageUrl, pItem.imageUrl)
                val displayKey = mangaPageCacheKey(visibleSourceId, pageObj, cropBorders)
                pageObj.status == Page.State.Ready ||
                    MangaStripCache.contains(displayKey) ||
                    displayLoader.memoryCache?.get(coil.memory.MemoryCache.Key(displayKey)) != null
            }
            if (renderedVisible.isNotEmpty()) {
                unrenderedSince = 0L
                visiblePageItemsWithInfo.retainAll(renderedVisible)
            } else {
                val nowMs = System.currentTimeMillis()
                if (unrenderedSince == 0L) unrenderedSince = nowMs
                if (nowMs - unrenderedSince < renderWaitGiveUpMs) {
                    ttsController.updateStatus("Loading page image...", MangaTtsStatusCategory.WORKING)
                    kotlinx.coroutines.delay(200)
                    continue
                }
            }

            // 2. Scan / OCR any visible pages that are not cached yet
            var needsScan = false
            for ((pItem, _) in visiblePageItemsWithInfo) {
                val key = feedItemKey(pItem)
                if (ttsController.cachedBlocks(key) == null) {
                    needsScan = true
                    ttsController.updateStatus("Scanning page...", MangaTtsStatusCategory.WORKING)
                    val pageObj = pItem.sourcePage ?: Page(pItem.pageIndex, pItem.imageUrl, pItem.imageUrl)
                    val ocrResult = MangaPageOcr.processPageOcr(context, s.sourceId ?: 0L, pageObj, rtl, MangaPageOcr.seamNeighbors(pageItems, pItem))
                    when (ocrResult) {
                        is MangaPageOcrResult.Success -> {
                            ttsController.cacheBlocks(key, ocrResult.blocks)
                            ttsLoadFailKey = null
                            ttsLoadFailCount = 0
                        }
                        is MangaPageOcrResult.ImageLoadError -> {
                            if (ttsLoadFailKey != key) {
                                ttsLoadFailKey = key
                                ttsLoadFailCount = 0
                            }
                            ttsLoadFailCount++
                            if (ttsLoadFailCount <= 6) {
                                // A page that is still downloading legitimately
                                // takes longer than 3 x 600ms on a slow link, and
                                // giving up there paused read-aloud on a page that
                                // was about to arrive. Back off instead.
                                ttsController.updateStatus("Loading page image...", MangaTtsStatusCategory.WORKING)
                                kotlinx.coroutines.delay((400L * ttsLoadFailCount).coerceAtMost(2500L))
                                break
                            }
                            ttsController.updateStatus("Unable to load page image", MangaTtsStatusCategory.ERROR)
                            ttsController.pause()
                            break
                        }
                        is MangaPageOcrResult.RecognizerError -> {
                            ttsController.updateStatus("OCR error: ${ocrResult.message}", MangaTtsStatusCategory.ERROR)
                            ttsController.pause()
                            break
                        }
                        is MangaPageOcrResult.Cancelled -> {
                            // Without a breather this re-enters OCR immediately
                            // and can spin on heavy work for as long as the
                            // cancellations keep coming.
                            kotlinx.coroutines.delay(150)
                            break
                        }
                    }
                }
            }
            if (needsScan) {
                // Loop back to evaluate with the freshly cached blocks
                continue
            }

            // 3. Prefetch nearby upcoming pages
            run {
                val lookahead = MangaReaderPrefs.getOcrLookahead(context)
                if (lookahead > 0 && prefetchJob?.isActive != true) {
                    val highestVisibleIdx = if (activeReadingMode == MangaReadingMode.LONG_STRIP) {
                        val lastVisibleItem = visiblePageItemsWithInfo.lastOrNull()?.first
                        if (lastVisibleItem != null) pageItems.indexOfFirst { feedItemKey(it) == feedItemKey(lastVisibleItem) } else -1
                    } else {
                        pageItems.indexOfFirst { it.pageIndex == s.currentPageIndex }
                    }

                    if (highestVisibleIdx >= 0) {
                        val uncachedNear = mutableListOf<MangaFeedItem.Page>()
                        for (i in (highestVisibleIdx + 1)..pageItems.lastIndex) {
                            val item = pageItems[i]
                            val itemKey = feedItemKey(item)
                            if (ttsController.cachedBlocks(itemKey) == null) {
                                uncachedNear.add(item)
                                if (uncachedNear.size >= lookahead) break
                            }
                        }
                        if (uncachedNear.isNotEmpty()) {
                            prefetchJob = launch(Dispatchers.IO) {
                                uncachedNear.forEach { targetItem ->
                                    if (!ttsController.sessionOn || !isActive) return@forEach
                                    try {
                                        val targetKey = feedItemKey(targetItem)
                                        val targetPage = targetItem.sourcePage ?: Page(targetItem.pageIndex, targetItem.imageUrl, targetItem.imageUrl)
                                        val prefetched = MangaPageOcr.processPageOcr(context, s.sourceId ?: 0L, targetPage, rtl, MangaPageOcr.seamNeighbors(pageItems, targetItem))
                                        if (prefetched is MangaPageOcrResult.Success && ttsController.sessionOn) {
                                            ttsController.cacheBlocks(targetKey, prefetched.blocks)
                                        }
                                    } catch (t: Throwable) {
                                        // Best-effort prefetch
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4. Compute visible-block queue (~60% visible inside viewport)
            val visibleBlocks = mutableListOf<VisibleSpeechBlock>()
            if (activeReadingMode == MangaReadingMode.LONG_STRIP) {
                val viewportStart = listState.layoutInfo.viewportStartOffset
                val viewportEnd = listState.layoutInfo.viewportEndOffset
                for ((pItem, info) in visiblePageItemsWithInfo) {
                    if (info == null) continue
                    val key = feedItemKey(pItem)
                    val blocks = ttsController.cachedBlocks(key) ?: emptyList()
                    for ((bIdx, b) in blocks.withIndex()) {
                        val bubbleTop = if (b.pageHeight > 0) {
                            info.offset + ((b.top.toFloat() / b.pageHeight.toFloat()) * info.size)
                        } else {
                            info.offset + (info.size * b.verticalFraction)
                        }
                        val bubbleBottom = if (b.pageHeight > 0) {
                            info.offset + ((b.bottom.toFloat() / b.pageHeight.toFloat()) * info.size)
                        } else {
                            bubbleTop + (info.size * 0.05f)
                        }
                        val blockH = (bubbleBottom - bubbleTop).coerceAtLeast(1f)
                        val visTop = maxOf(bubbleTop, viewportStart.toFloat())
                        val visBottom = minOf(bubbleBottom, viewportEnd.toFloat())
                        val visH = maxOf(0f, visBottom - visTop)
                        val visFraction = visH / blockH

                        // Block must be at least ~60% vertically inside the viewport before speaking it
                        if (visFraction >= 0.60f) {
                            visibleBlocks.add(
                                VisibleSpeechBlock(
                                    pageItem = pItem,
                                    block = b,
                                    blockIndex = bIdx,
                                    itemIndex = info.index,
                                    id = "$key#$bIdx"
                                )
                            )
                        }
                    }
                }
                visibleBlocks.sortWith(compareBy({ it.itemIndex }, { it.blockIndex }))
            } else {
                // Paged mode
                val pItem = visiblePageItemsWithInfo.firstOrNull()?.first
                if (pItem != null) {
                    val key = feedItemKey(pItem)
                    val blocks = ttsController.cachedBlocks(key) ?: emptyList()
                    for ((bIdx, b) in blocks.withIndex()) {
                        visibleBlocks.add(
                            VisibleSpeechBlock(
                                pageItem = pItem,
                                block = b,
                                blockIndex = bIdx,
                                itemIndex = 0,
                                id = "$key#$bIdx"
                            )
                        )
                    }
                }
            }

            // Helper to build a merged utterance group from consecutive unspoken blocks
            fun buildSpeechGroup(
                unspoken: List<VisibleSpeechBlock>,
                allVisible: List<VisibleSpeechBlock>
            ): List<VisibleSpeechBlock> {
                if (unspoken.isEmpty()) return emptyList()

                val first = unspoken.first()
                val group = mutableListOf(first)
                val firstKey = feedItemKey(first.pageItem)
                var current = first
                var charCount = first.block.text.length

                for (i in 1 until unspoken.size) {
                    val next = unspoken[i]

                    // 1. Must be on the exact same page boundary
                    if (feedItemKey(next.pageItem) != firstKey) break

                    // 2. Must be consecutive in visibleBlocks
                    val currentVisibleIdx = allVisible.indexOf(current)
                    val nextVisibleIdx = allVisible.indexOf(next)
                    if (nextVisibleIdx != currentVisibleIdx + 1) break

                    // 3. Does current block end a sentence?
                    if (MangaPageOcr.endsSentence(current.block.text)) break

                    // 4. Cap size check (max 4 blocks or 300 characters)
                    if (group.size >= 4 || charCount + next.block.text.length > 300) break

                    group.add(next)
                    current = next
                    charCount += next.block.text.length
                }

                return group
            }

            // User explicit control: Next Line / Prev Line button
            if (ttsController.pendingSkip != 0) {
                val skip = ttsController.pendingSkip
                ttsController.pendingSkip = 0
                if (skip > 0) {
                    // Skip to next unspoken visible group
                    val remainingUnspoken = visibleBlocks.filter { it.id !in spokenBlockIds }
                    if (remainingUnspoken.isNotEmpty()) {
                        val groupToSkip = buildSpeechGroup(remainingUnspoken, visibleBlocks)
                        for (b in groupToSkip) {
                            spokenBlockIds.add(b.id)
                            spokenHistory.add(b.id)
                        }
                    }
                } else if (skip < 0) {
                    // Step back: unmark previous spoken group so it is re-read
                    if (spokenHistory.isNotEmpty()) {
                        val lastId = spokenHistory.removeAt(spokenHistory.lastIndex)
                        spokenBlockIds.remove(lastId)

                        while (spokenHistory.isNotEmpty()) {
                            val prevId = spokenHistory.last()
                            val prevItem = visibleBlocks.find { it.id == prevId }
                            val lastItem = visibleBlocks.find { it.id == lastId }
                            if (prevItem != null && lastItem != null &&
                                feedItemKey(prevItem.pageItem) == feedItemKey(lastItem.pageItem) &&
                                !MangaPageOcr.endsSentence(prevItem.block.text)
                            ) {
                                spokenHistory.removeAt(spokenHistory.lastIndex)
                                spokenBlockIds.remove(prevId)
                            } else {
                                break
                            }
                        }
                    }
                }
                ttsController.stopSpeaking()
                continue
            }

            val unspokenBlocks = visibleBlocks.filter { it.id !in spokenBlockIds }

            if (unspokenBlocks.isNotEmpty()) {
                val group = buildSpeechGroup(unspokenBlocks, visibleBlocks)
                val target = group.first()
                val targetKey = feedItemKey(target.pageItem)
                ttsController.loadedPageKey = targetKey
                ttsController.ttsPageKey = targetKey
                ttsController.blocks = ttsController.cachedBlocks(targetKey) ?: emptyList()
                ttsController.blockIndex = target.blockIndex

                // PART C item 1: Launch scroll concurrently so scroll overlaps speech instead of delaying it
                coroutineScope.launch {
                    try {
                        focusTtsBlock(target.pageItem, target.block)
                    } catch (e: CancellationException) {
                        // Ignore cancelled scroll so speech continues unaffected
                    }
                }

                // Voice-only autocorrect. This is the single point where OCR text
                // becomes speech, so the disk cache and the detected-text overlay
                // keep the pristine recognizer output and can never be corrupted.
                // Filter first, then autocorrect. In this order a site name is
                // removed while it still looks like a site name; autocorrect can
                // otherwise reshape it into something the filter no longer
                // recognises.
                val filtered = MangaTtsTextFilter.apply(
                    context,
                    MangaPageOcr.joinGroupTexts(group.map { it.block }),
                    novelId
                )
                val spoken = MangaOcrAutocorrect.correct(
                    context,
                    filtered,
                    MangaReaderPrefs.getOcrAutocorrectLevel(context)
                )
                val completed = if (spoken.isNotBlank()) {
                    ttsController.clearStatus()
                    ttsController.ensureAudioFocus(context)
                    ttsController.speak(spoken)
                } else {
                    true
                }

                if (completed) {
                    engineRecoveries = 0
                    for (b in group) {
                        spokenBlockIds.add(b.id)
                        spokenHistory.add(b.id)
                    }
                    while (spokenHistory.size > 100) {
                        spokenHistory.removeAt(0)
                    }
                } else {
                    // Utterance was interrupted mid-speech (e.g. paused by user or transient loss).
                    // We do not mark any block in group as spoken, so when unpaused/resumed, the
                    // whole group will be re-spoken rather than skipped or permanently stuck.
                    //
                    // An interruption the user asked for leaves the controller's
                    // failure count at zero. Anything else is the engine itself
                    // failing, and retrying the same bubble every 100ms forever
                    // was a silent spin with nothing shown on screen. Rebuild the
                    // engine a couple of times, then say so and pause.
                    when {
                        ttsController.speakFailureStreak < 3 -> {
                            kotlinx.coroutines.delay(120)
                        }
                        engineRecoveries < 2 -> {
                            engineRecoveries++
                            ttsController.updateStatus("Restarting speech engine...", MangaTtsStatusCategory.WORKING)
                            if (ttsController.recoverEngine(context)) {
                                ttsController.clearStatus()
                            }
                            kotlinx.coroutines.delay(250)
                        }
                        else -> {
                            ttsController.updateStatus(
                                ttsController.engineError ?: "Speech engine is not responding",
                                MangaTtsStatusCategory.ERROR
                            )
                            ttsController.pause()
                        }
                    }
                }
            } else {
                // No unspoken block is currently visible in the viewport: IDLE
                // Never move the page by itself. Wait for user scroll or autoscroll.
                if (!ttsController.isSpeaking) {
                    ttsController.updateStatus("Waiting for text...", MangaTtsStatusCategory.INFORMATIONAL)
                }
                kotlinx.coroutines.delay(120)
            }
        }

        prefetchJob?.cancel()
    }

    val currentChapterName = state.chapterNames.getOrNull(state.activeChapterIndex)
        ?: state.novel?.currentChapter
        ?: "Chapter ${state.activeChapterIndex + 1}"

    // Screen Keep-On Flag. Read-aloud is hands-free by nature: without this,
    // the display times out mid-chapter and ON_STOP kills the session. The
    // flag is window-scoped (not a wake lock), so pressing power still stops
    // everything -- the "screen-bound" contract is preserved.
    DisposableEffect(keepScreenOn, ttsController.sessionOn) {
        val window = (context as? Activity)?.window
        if (keepScreenOn || ttsController.sessionOn) {
            window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose {
            window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // Scrolling now takes the status and navigation bars down with the reader
    // chrome, and a tap brings all three back. The scroll observer above already
    // clears showChrome, so keying this effect on it gives immersive-while-
    // reading behaviour without adding a second gesture detector. The explicit
    // fullscreen preference still wins outright.
    DisposableEffect(fullscreenPref, showChrome) {
        val window = (context as? Activity)?.window
        val w = window
        if (w != null) {
            val controller = androidx.core.view.WindowCompat.getInsetsController(w, w.decorView)
            if (fullscreenPref || !showChrome) {
                controller.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                controller.systemBarsBehavior =
                    androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            } else {
                controller.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose {
            val w2 = (context as? Activity)?.window
            if (w2 != null) {
                androidx.core.view.WindowCompat
                    .getInsetsController(w2, w2.decorView)
                    .show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    // Volume Key Nav
    DisposableEffect(volumeKeyNav) {
        if (volumeKeyNav) {
            VolumeKeyBus.active = true
        }
        onDispose {
            VolumeKeyBus.active = false
        }
    }

    // Volume-key events are consumed inside the content block below, where the
    // pager and list state exist. The old handler here only wrote the new page
    // index into the ViewModel -- the counter updated but the reader never
    // actually moved.

    // Toast Messages
    LaunchedEffect(state.toastMessage) {
        state.toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .then(if (showReaderBgImage) Modifier else Modifier.background(bgColor))
    ) {
        if (state.isLoading && state.feedItems.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize()) {
                // SINGLE-LAYER THEME BG: the theme image is now the entire
                // background at full opacity -- the parent Box no longer
                // paints a flat colour underneath it in Theme mode.
                if (showReaderBgImage) {
                    Image(
                        painter = painterResource(id = readerBgImageRes),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(top = 56.dp, bottom = 16.dp)
                        .padding(horizontal = (16 * sidePaddingPercent / 100).coerceAtLeast(8).dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ShimmerBox(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        cornerRadius = 8
                    )
                    ShimmerBox(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        cornerRadius = 8
                    )
                }

                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(32.dp),
                        color = textColor,
                        strokeWidth = 3.dp
                    )
                }

                MangaReaderTopBar(
                    visible = showChrome,
                    splitPanelsEnabled = splitToolbarEnabled,
                    isAutoscrolling = isAutoscrolling,
                    contentColor = textColor,
                    statusBarColor = Color.Black,
                    onBack = {
                        viewModel.onDismiss()
                        onClose()
                    },
                    onOpenContents = { showContentsSheet = true },
                    onToggleAutoscroll = toggleAutoscroll,
                    onOpenSettings = { showSettingsPanel = true },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        } else if (state.error != null && state.feedItems.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = friendlyMangaReaderError(state.error),
                    color = textColor,
                    fontSize = 16.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { viewModel.loadChapter(state.activeChapterIndex, state.currentPageIndex) }
                ) {
                    Text(stringResource(R.string.manga_reader_retry_chapter))
                }
                Spacer(modifier = Modifier.height(8.dp))
                TextButton(onClick = {
                    viewModel.onDismiss()
                    onClose()
                }) {
                    Text(stringResource(R.string.manga_reader_close_reader), color = textColor)
                }
            }
        } else if (state.feedItems.isNotEmpty() || state.pages.isNotEmpty()) {
            val totalPages = state.pages.size

            LaunchedEffect(state.sourceId, state.currentPageIndex) {
                val sid = state.sourceId ?: return@LaunchedEffect
                MangaViewerPositionTracker.updateVisiblePage(sid, state.currentPageIndex)
            }

            val pagedPagerState = rememberPagerState(
                initialPage = if (activeReadingMode == MangaReadingMode.PAGED_RTL) {
                    truePageToPagerIndex(state.currentPageIndex, totalPages)
                } else {
                    state.currentPageIndex.coerceIn(0, (totalPages - 1).coerceAtLeast(0))
                },
                pageCount = { totalPages }
            )

            LaunchedEffect(pagedPagerState, activeReadingMode, totalPages) {
                snapshotFlow { pagedPagerState.currentPage }.collect { pIdx ->
                    val truePage = if (activeReadingMode == MangaReadingMode.PAGED_RTL) {
                        pagerIndexToTruePage(pIdx, totalPages)
                    } else {
                        pIdx
                    }
                    state.sourceId?.let { sid ->
                        MangaViewerPositionTracker.updateVisiblePage(sid, truePage)
                    }
                    viewModel.onPageChanged(truePage)

                    // Mihon-style preload: exactly the next four pages, ranked
                    // below the page on screen. The old window warmed the
                    // current page plus an adaptive depth ahead plus two behind,
                    // all at equal priority, so each page flip put its own
                    // request at the back of a queue the previous flip had just
                    // filled.
                    run {
                        val sid = state.sourceId ?: 0L
                        val loader = MangaImageLoaderProvider.getImageLoader(context)
                        val last = (state.pages.size - 1).coerceAtLeast(0)
                        val forwardTo =
                            (truePage + MangaImageLoaderProvider.prefetchWindow()).coerceAtMost(last)
                        for (i in (truePage + 1)..forwardTo) {
                            val p = state.pages.getOrNull(i) ?: continue
                            val prefetchKey = mangaPageCacheKey(sid, p, cropBorders)
                            loader.enqueue(
                                ImageRequest.Builder(context)
                                    .data(MangaPageKey(sid, p))
                                    .setParameter(MANGA_PRIORITY_PARAM, MANGA_PRIORITY_ADJACENT)
                                    .memoryCacheKey(prefetchKey)
                                    .diskCacheKey(prefetchKey)
                                    .build()
                            )
                        }
                    }
                }
            }

            // Screen-based TTS auto-flips pages in paged modes, where no
            // autoscroll exists to carry the reader forward.
            LaunchedEffect(pagedPagerState, activeReadingMode, totalPages, ttsController.pageFlipTarget) {
                val requested = ttsController.pageFlipTarget ?: return@LaunchedEffect
                val pagerIdx = if (activeReadingMode == MangaReadingMode.PAGED_RTL) {
                    truePageToPagerIndex(requested, totalPages)
                } else {
                    requested
                }
                pagedPagerState.animateScrollToPage(pagerIdx.coerceIn(0, (totalPages - 1).coerceAtLeast(0)))
                ttsController.pageFlipTarget = null
            }

            // When the chapter changes (or the reading mode switches into a
            // paged mode) the pager still holds its index from the previous
            // chapter, so the reader landed mid-chapter instead of on the saved
            // page. Snap the pager to the state's current page whenever either
            // changes. Writing the same index back through the currentPage
            // collector is harmless, so no feedback loop.
            LaunchedEffect(state.activeChapterIndex, totalPages, activeReadingMode) {
                if (totalPages <= 0 || activeReadingMode == MangaReadingMode.LONG_STRIP) return@LaunchedEffect
                val target = if (activeReadingMode == MangaReadingMode.PAGED_RTL) {
                    truePageToPagerIndex(state.currentPageIndex, totalPages)
                } else {
                    state.currentPageIndex
                }
                val safe = target.coerceIn(0, totalPages - 1)
                if (pagedPagerState.currentPage != safe) {
                    pagedPagerState.scrollToPage(safe)
                }
            }

            // Volume-key navigation, mode aware: paged modes actually flip the
            // page, long-strip scrolls by most of a viewport like the tap
            // zones do (jumping a full page in a continuous strip is jarring).
            LaunchedEffect(volumeKeyNav, invertVolumeKeys, activeReadingMode, pagedPagerState) {
                if (!volumeKeyNav) return@LaunchedEffect
                VolumeKeyBus.events.collect { rawDirection ->
                    val direction = if (invertVolumeKeys) -rawDirection else rawDirection
                    if (direction == 0) return@collect
                    when (activeReadingMode) {
                        MangaReadingMode.LONG_STRIP -> {
                            val vpH = listState.layoutInfo.viewportSize.height.coerceAtLeast(1)
                            val dist = (vpH * 3 / 4).toFloat()
                            listState.animateScrollBy(if (direction > 0) dist else -dist)
                        }
                        MangaReadingMode.PAGED_LTR, MangaReadingMode.PAGED_VERTICAL -> {
                            val target = pagedPagerState.currentPage + direction
                            if (target in 0 until state.pages.size) {
                                pagedPagerState.animateScrollToPage(target)
                            }
                        }
                        MangaReadingMode.PAGED_RTL -> {
                            // Pager index runs opposite to reading order in RTL.
                            val target = pagedPagerState.currentPage - direction
                            if (target in 0 until state.pages.size) {
                                pagedPagerState.animateScrollToPage(target)
                            }
                        }
                    }
                }
            }

            // AUTOSCROLL IN PAGED MODES.
            //
            // Autoscroll was long-strip only: the toolbar button, the speed
            // panel and the floating pause were all gated on LONG_STRIP, and the
            // toggle itself did nothing in the other three modes. A tablet is
            // precisely where that bites -- a wide screen makes a whole fitted
            // page readable, so the reading mode gets set to one of the paged
            // ones, and from then on the autoscroll button was inert with no
            // panel and no message to explain itself.
            //
            // Paged autoscroll is an auto page-turn driven by the same slider.
            // The slider is in dp per second, so one screen height is converted
            // into how long a page is held before the next flip and the same
            // number reads at the same pace in either mode. RTL walks the pager
            // backwards, matching every other navigation path here, and the end
            // of a chapter hands off to the next chapter rather than stopping.
            LaunchedEffect(
                isAutoscrolling,
                activeReadingMode,
                autoscrollRunToken,
                totalPages,
                state.activeChapterIndex
            ) {
                if (!isAutoscrolling) return@LaunchedEffect
                if (activeReadingMode == MangaReadingMode.LONG_STRIP) return@LaunchedEffect
                if (totalPages <= 0) return@LaunchedEffect
                val rtl = activeReadingMode == MangaReadingMode.PAGED_RTL
                while (isAutoscrolling) {
                    // Read fresh every tick: the speed slider is live while the
                    // panel is open, and screenHeightDp follows a rotation.
                    val pageDistanceDp = context.resources.configuration.screenHeightDp
                        .toFloat()
                        .coerceIn(320f, 1600f)
                    val dwellMs = (pageDistanceDp / animatedAutoscrollSpeed.coerceAtLeast(1f) * 1000f)
                        .toLong()
                        .coerceIn(500L, 60_000L)
                    // Also the cancellation checkpoint for the whole loop.
                    kotlinx.coroutines.delay(dwellMs)
                    if (!isAutoscrolling || autoscrollTouching) break
                    val here = pagedPagerState.currentPage
                    val atEnd = if (rtl) here <= 0 else here >= totalPages - 1
                    if (atEnd) {
                        if (state.activeChapterIndex >= state.chapterUrls.size - 1) {
                            isAutoscrolling = false
                        } else {
                            // This effect is keyed on the chapter index, so it
                            // restarts on the new chapter and keeps flipping.
                            viewModel.nextChapter()
                        }
                        break
                    }
                    try {
                        pagedPagerState.animateScrollToPage(
                            (if (rtl) here - 1 else here + 1).coerceIn(0, totalPages - 1)
                        )
                    } catch (_: kotlinx.coroutines.CancellationException) {
                        // A finger took the pager mid-flip. Nothing to undo --
                        // the next tick flips on from wherever the reader
                        // landed. If this effect is the thing going away, the
                        // delay at the top of the loop throws and the run ends.
                    }
                }
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .readerTapZones(
                        // All four now come from settingsVersion-keyed state, so a
                        // change in Settings takes effect on the next tap. The
                        // enabled flag in particular used to hit SharedPreferences
                        // on every recomposition of this Box, which during a scroll
                        // means a lock and a map lookup per frame.
                        enabled = tapZonesEnabled,
                        isScrollSettling = { listState.isScrollInProgress },
                        layout = tapZoneLayout,
                        invert = tapZoneInvert,
                        onMenuTap = {
                            if (pauseOnTap) {
                                isAutoscrolling = false
                            }
                            showChrome = !showChrome
                        },
                        onRegionTap = { region ->
                            if (pauseOnTap) {
                                isAutoscrolling = false
                            }
                            when (activeReadingMode) {
                                MangaReadingMode.LONG_STRIP -> {
                                    val vpH = listState.layoutInfo.viewportSize.height.coerceAtLeast(1)
                                    val visibleItems = listState.layoutInfo.visibleItemsInfo
                                    val pageInfo = visibleItems.firstOrNull { state.feedItems.getOrNull(it.index) is MangaFeedItem.Page }
                                    when (region) {
                                        MangaNavRegion.MENU -> showChrome = !showChrome
                                        MangaNavRegion.NEXT, MangaNavRegion.RIGHT -> {
                                            val scrollDist = if (pageInfo != null) {
                                                val remDown = computeRemainingDown(pageInfo.offset, pageInfo.size, listState.layoutInfo.viewportStartOffset)
                                                nextImageScroll(remDown, vpH).toFloat()
                                            } else {
                                                (vpH * 3 / 4).toFloat()
                                            }
                                            coroutineScope.launch { listState.animateScrollBy(scrollDist) }
                                        }
                                        MangaNavRegion.PREV, MangaNavRegion.LEFT -> {
                                            val scrollDist = if (pageInfo != null) {
                                                val remUp = computeRemainingUp(pageInfo.offset, listState.layoutInfo.viewportEndOffset)
                                                nextImageScroll(remUp, vpH).toFloat()
                                            } else {
                                                (vpH * 3 / 4).toFloat()
                                            }
                                            coroutineScope.launch { listState.animateScrollBy(-scrollDist) }
                                        }
                                    }
                                }
                                MangaReadingMode.PAGED_LTR, MangaReadingMode.PAGED_VERTICAL -> {
                                    when (region) {
                                        MangaNavRegion.MENU -> showChrome = !showChrome
                                        MangaNavRegion.NEXT, MangaNavRegion.RIGHT -> {
                                            if (pagedPagerState.currentPage < totalPages - 1) {
                                                coroutineScope.launch { pagedPagerState.animateScrollToPage(pagedPagerState.currentPage + 1) }
                                            }
                                        }
                                        MangaNavRegion.PREV, MangaNavRegion.LEFT -> {
                                            if (pagedPagerState.currentPage > 0) {
                                                coroutineScope.launch { pagedPagerState.animateScrollToPage(pagedPagerState.currentPage - 1) }
                                            }
                                        }
                                    }
                                }
                                MangaReadingMode.PAGED_RTL -> {
                                    when (region) {
                                        MangaNavRegion.MENU -> showChrome = !showChrome
                                        MangaNavRegion.NEXT, MangaNavRegion.LEFT -> {
                                            if (pagedPagerState.currentPage > 0) {
                                                coroutineScope.launch { pagedPagerState.animateScrollToPage(pagedPagerState.currentPage - 1) }
                                            }
                                        }
                                        MangaNavRegion.PREV, MangaNavRegion.RIGHT -> {
                                            if (pagedPagerState.currentPage < totalPages - 1) {
                                                coroutineScope.launch { pagedPagerState.animateScrollToPage(pagedPagerState.currentPage + 1) }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    )
            ) {
                // SINGLE-LAYER THEME BG: the theme image is now the entire
                // background at full opacity -- the parent Box no longer
                // paints a flat colour underneath it in Theme mode.
                if (showReaderBgImage) {
                    Image(
                        painter = painterResource(id = readerBgImageRes),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                when (activeReadingMode) {
                    MangaReadingMode.LONG_STRIP -> {
                        MangaWebtoonViewer(
                            sourceId = state.sourceId ?: 0L,
                            pages = state.pages,
                            currentPageIndex = state.currentPageIndex,
                            textColor = textColor,
                            sidePaddingPercent = sidePaddingPercent,
                            disableZoomOut = disableZoomOut,
                            doubleTapToZoom = doubleTapToZoom,
                            feedItems = state.feedItems,
                            listState = listState,
                            onActivePageChanged = { chIdx, pIdx ->
                                state.sourceId?.let { sid ->
                                    MangaViewerPositionTracker.updateVisiblePage(sid, pIdx)
                                }
                                // Ignore positions produced by read-aloud's own
                                // scrolling, which otherwise re-triggers OCR.
                                if (!ttsController.autoScrolling) {
                                    viewModel.onActivePageChanged(chIdx, pIdx)
                                }
                            },
                            onVisibleChapterIdsChanged = { visibleIds ->
                                viewModel.updateVisibleChapterIds(visibleIds)
                            },
                            onNearEndOrBoundary = {
                                viewModel.ensureNextChapterLoading()
                            },
                            onPageChanged = {
                                if (!ttsController.autoScrolling) viewModel.onPageChanged(it)
                            },
                            onSingleTap = { showChrome = !showChrome },
                            pageGapDp = pageGap,
                            maxZoom = maxZoomPref,
                            doubleTapScale = doubleTapZoomPref.toFloat(),
                            pageContentScale = pageContentScale,
                            readerBgColor = if (showReaderBgImage) Color.Transparent else bgColor,
                            pageColorFilter = pageColorFilter,
                            cropBorders = cropBorders,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    MangaReadingMode.PAGED_LTR -> {
                        HorizontalPager(
                            state = pagedPagerState,
                            // Compose neighbours off-screen so a flip lands on a
                            // page that is already decoding instead of a spinner.
                            beyondViewportPageCount = 2,
                            modifier = Modifier.fillMaxSize()
                        ) { pageIdx ->
                            MangaPageItem(
                                sourceId = state.sourceId ?: 0L,
                                page = state.pages[pageIdx],
                                mode = MangaReadingMode.PAGED_LTR,
                                textColor = textColor,
                                pageContentScale = pageContentScale,
                                pageColorFilter = pageColorFilter,
                                cropBorders = cropBorders,
                                maxZoom = maxZoomPref,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                    MangaReadingMode.PAGED_RTL -> {
                        HorizontalPager(
                            state = pagedPagerState,
                            beyondViewportPageCount = 2,
                            modifier = Modifier.fillMaxSize()
                        ) { pIdx ->
                            val truePage = pagerIndexToTruePage(pIdx, totalPages)
                            MangaPageItem(
                                sourceId = state.sourceId ?: 0L,
                                page = state.pages[truePage],
                                mode = MangaReadingMode.PAGED_RTL,
                                textColor = textColor,
                                pageContentScale = pageContentScale,
                                pageColorFilter = pageColorFilter,
                                cropBorders = cropBorders,
                                maxZoom = maxZoomPref,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                    MangaReadingMode.PAGED_VERTICAL -> {
                        VerticalPager(
                            state = pagedPagerState,
                            beyondViewportPageCount = 2,
                            modifier = Modifier.fillMaxSize()
                        ) { pageIdx ->
                            MangaPageItem(
                                sourceId = state.sourceId ?: 0L,
                                page = state.pages[pageIdx],
                                mode = MangaReadingMode.PAGED_VERTICAL,
                                textColor = textColor,
                                pageContentScale = pageContentScale,
                                pageColorFilter = pageColorFilter,
                                cropBorders = cropBorders,
                                maxZoom = maxZoomPref,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }

                if (brightnessOverlay != 0) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                if (brightnessOverlay < 0) {
                                    androidx.compose.ui.graphics.Color.Black.copy(
                                        alpha = ((-brightnessOverlay).coerceIn(0, 100) / 100f) * 0.9f
                                    )
                                } else {
                                    androidx.compose.ui.graphics.Color.White.copy(
                                        alpha = (brightnessOverlay.coerceIn(0, 100) / 100f) * 0.4f
                                    )
                                }
                            )
                    )
                }

                // Page Overlay Indicator when chrome is hidden
                if (showPageNumber && !showChrome) {
                    MangaPageOverlayIndicator(
                        currentPage = state.currentPageIndex,
                        totalPages = state.pages.size,
                        bgColor = bgColor,
                        textColor = textColor,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(bottom = 16.dp, end = 16.dp)
                    )
                }

                // Experimental: what the OCR picked up, in reading order.
                if (ttsExperimentalOn && ttsController.sessionOn) {
                    Column(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(top = 96.dp, start = 12.dp)
                    ) {
                        val shouldShowChip = ttsController.statusText != null && (
                            ttsController.statusCategory == MangaTtsStatusCategory.WORKING ||
                            ttsController.statusCategory == MangaTtsStatusCategory.ERROR
                        )

                        AnimatedVisibility(
                            visible = shouldShowChip,
                            enter = fadeIn(motionLevel.tweenSpec(durationMillis = 180)),
                            exit = fadeOut(motionLevel.tweenSpec(durationMillis = 180))
                        ) {
                            ttsController.statusText?.let { status ->
                                val isError = ttsController.statusCategory == MangaTtsStatusCategory.ERROR
                                Card(
                                    shape = RoundedCornerShape(50),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isError) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.95f)
                                        else bgColor.copy(alpha = 0.85f)
                                    ),
                                    modifier = Modifier.clickable(
                                        enabled = isError,
                                        role = Role.Button,
                                        onClickLabel = "Retry page"
                                    ) {
                                        val pageItems = state.feedItems.filterIsInstance<MangaFeedItem.Page>()
                                        val activePageItem = pageItems.firstOrNull {
                                            it.chapterIndex == state.activeChapterIndex && it.pageIndex == state.currentPageIndex
                                        } ?: pageItems.firstOrNull()
                                        val curPage = activePageItem?.sourcePage
                                            ?: activePageItem?.let { Page(it.pageIndex, it.imageUrl, it.imageUrl) }
                                        val curKey = activePageItem?.let { feedItemKey(it) }
                                        val rtl = activeReadingMode == MangaReadingMode.PAGED_RTL
                                        if (curPage != null && curKey != null) {
                                            coroutineScope.launch {
                                                ttsController.rescanPage(context, state.sourceId ?: 0L, curPage, curKey, rtl)
                                            }
                                        }
                                    }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    ) {
                                        Text(
                                            text = status,
                                            color = if (isError) MaterialTheme.colorScheme.onErrorContainer else textColor,
                                            fontSize = 11.sp
                                        )
                                        if (isError) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Icon(
                                                Icons.Default.Refresh,
                                                contentDescription = stringResource(R.string.manga_reader_rescan_page),
                                                tint = MaterialTheme.colorScheme.onErrorContainer,
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Text(
                                                text = "Tap to retry",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onErrorContainer,
                                                modifier = Modifier.padding(start = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        if (showDetectedText && ttsController.blocks.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = bgColor.copy(alpha = 0.85f)),
                                modifier = Modifier
                                    .widthIn(max = 240.dp)
                                    .heightIn(max = 220.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = "Detected (${ttsController.blocks.size})",
                                            color = textColor,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        IconButton(
                                            onClick = {
                                                val pageItems = state.feedItems.filterIsInstance<MangaFeedItem.Page>()
                                                val activePageItem = pageItems.firstOrNull {
                                                    it.chapterIndex == state.activeChapterIndex && it.pageIndex == state.currentPageIndex
                                                } ?: pageItems.firstOrNull()
                                                val curPage = activePageItem?.sourcePage
                                                    ?: activePageItem?.let { Page(it.pageIndex, it.imageUrl, it.imageUrl) }
                                                val curKey = activePageItem?.let { feedItemKey(it) }
                                                val rtl = activeReadingMode == MangaReadingMode.PAGED_RTL
                                                if (curPage != null && curKey != null) {
                                                    coroutineScope.launch {
                                                        ttsController.rescanPage(context, state.sourceId ?: 0L, curPage, curKey, rtl)
                                                    }
                                                }
                                            },
                                            modifier = Modifier.size(20.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Refresh,
                                                contentDescription = stringResource(R.string.manga_reader_rescan_page),
                                                tint = textColor,
                                                modifier = Modifier.size(13.dp)
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    ttsController.blocks.forEachIndexed { i, b ->
                                        Text(
                                            text = "${i + 1}. ${b.text}",
                                            color = if (i == ttsController.blockIndex) textColor else textColor.copy(alpha = 0.5f),
                                            fontSize = 10.sp,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Top Bar
                MangaReaderTopBar(
                    visible = showChrome,
                    splitPanelsEnabled = splitToolbarEnabled,
                    isAutoscrolling = isAutoscrolling,
                    contentColor = textColor,
                    statusBarColor = Color.Black,
                    onBack = {
                        viewModel.onDismiss()
                        onClose()
                    },
                    onOpenContents = { showContentsSheet = true },
                    onToggleAutoscroll = toggleAutoscroll,
                    onOpenSettings = { showSettingsPanel = true },
                    modifier = Modifier.fillMaxWidth()
                )



                // Bottom Bar
                AnimatedVisibility(
                    visible = showChrome,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                    modifier = Modifier.align(Alignment.BottomCenter)
                ) {
                    MangaReaderBottomBar(
                        currentPage = state.currentPageIndex,
                        totalPages = state.pages.size,
                        currentChapterIndex = state.activeChapterIndex,
                        totalChapters = state.chapterUrls.size,
                        readingMode = activeReadingMode,
                        showPageSlider = showPageSlider,
                        onPageSeek = { targetPageIndex ->
                            viewModel.onPageChanged(targetPageIndex)
                            coroutineScope.launch {
                                when (activeReadingMode) {
                                    MangaReadingMode.LONG_STRIP -> {
                                        val itemIdx = state.feedItems.indexOfFirst {
                                            it is MangaFeedItem.Page && it.chapterIndex == state.activeChapterIndex && it.pageIndex == targetPageIndex
                                        }.let {
                                            if (it >= 0) it else state.feedItems.indexOfFirst { item -> item is MangaFeedItem.Page && item.pageIndex == targetPageIndex }
                                        }
                                        if (itemIdx >= 0) {
                                            listState.scrollToItem(itemIdx)
                                        }
                                    }
                                    MangaReadingMode.PAGED_LTR, MangaReadingMode.PAGED_VERTICAL -> {
                                        val safeIndex = targetPageIndex.coerceIn(0, (state.pages.size - 1).coerceAtLeast(0))
                                        pagedPagerState.scrollToPage(safeIndex)
                                    }
                                    MangaReadingMode.PAGED_RTL -> {
                                        val pagerIdx = truePageToPagerIndex(targetPageIndex, state.pages.size)
                                        val safeIndex = pagerIdx.coerceIn(0, (state.pages.size - 1).coerceAtLeast(0))
                                        pagedPagerState.scrollToPage(safeIndex)
                                    }
                                }
                            }
                        },
                        onPrevChapter = { viewModel.previousChapter() },
                        onNextChapter = { viewModel.nextChapter() },
                        onOpenReadingMode = { showModePanel = true },
                        onCycleOrientation = {
                            val activity = context as? Activity
                            val currentOrientation = MangaReaderPrefs.getOrientation(context)
                            val nextOrientation = (currentOrientation + 1) % 3
                            MangaReaderPrefs.setOrientation(context, nextOrientation)
                            activity?.requestedOrientation = when (nextOrientation) {
                                1 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                                2 -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                                else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                            }
                        },
                        ttsAvailable = ttsExperimentalOn,
                        ttsSessionOn = ttsController.sessionOn,
                        ttsPaused = ttsController.isPaused,
                        onToggleTtsSession = {
                            if (ttsController.sessionOn) {
                                ttsController.stop()
                            } else {
                                val s = viewModel.uiState.value
                                val pageItems = s.feedItems.filterIsInstance<MangaFeedItem.Page>()
                                val startPage = pageItems.firstOrNull {
                                    it.chapterIndex == s.activeChapterIndex && it.pageIndex == s.currentPageIndex
                                } ?: pageItems.firstOrNull { it.chapterIndex == s.activeChapterIndex } ?: pageItems.firstOrNull()
                                if (startPage != null) {
                                    ttsController.ttsPageKey = feedItemKey(startPage)
                                    ttsController.blockIndex = 0
                                    ttsController.loadedPageKey = null
                                }
                                ttsController.start(context)
                            }
                        },
                        onTtsPlayPause = { ttsController.togglePause() },
                        onStopTtsSession = { ttsController.stop() },
                        bgColor = bgColor,
                        textColor = textColor
                    )
                }

                // MangaModePanel
                if (showModePanel) {
                    MangaModePanel(
                        current = activeReadingMode,
                        highlightColor = textColor,
                        onSelect = { mode ->
                            activeReadingMode = mode
                            MangaReaderPrefs.setReadingMode(context, mode)
                            if (novelId.isNotBlank()) {
                                MangaReaderPrefs.setModeOverride(context, novelId, mode)
                            }
                            showModePanel = false
                        },
                        onDismiss = { showModePanel = false },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        // Autoscroll speed panel. Hides itself a few seconds after the last
        // interaction; moving the slider restarts that timer via the nudge.
        LaunchedEffect(showAutoscrollPanel, autoscrollPanelNudge) {
            if (!showAutoscrollPanel) return@LaunchedEffect
            kotlinx.coroutines.delay(3500)
            showAutoscrollPanel = false
        }

        if (showAutoscrollPanel) {
            MangaAutoscrollPanel(
                speed = autoscrollSpeed,
                running = isAutoscrolling,
                highlightColor = textColor,
                bgColor = bgColor,
                textColor = textColor,
                onToggleRunning = {
                    isAutoscrolling = !isAutoscrolling
                    autoscrollPanelNudge++
                },
                onSpeedChange = { newSpeed ->
                    // Live, unpersisted: the running scroll picks this up on the
                    // next frame through animatedAutoscrollSpeed.
                    autoscrollSpeed = newSpeed
                    autoscrollPanelNudge++
                },
                onSpeedCommit = {
                    // One write per drag, on release.
                    MangaReaderPrefs.setAutoscrollSpeed(context, autoscrollSpeed)
                },
                topPadding = autoscrollPanelTop,
                modifier = Modifier.fillMaxSize().zIndex(1002f)
            )
        }

        // The one autoscroll control that survives the chrome hiding itself.
        // With "pause on touch" OFF a tap deliberately does not stop the run,
        // and the chrome auto-hides right after a run starts, so previously the
        // only way to stop was to tap to bring the whole top bar back. This
        // button exists for exactly that combination and nothing else.
        if (isAutoscrolling && !showChrome && !pauseOnTap) {
            Box(modifier = Modifier.fillMaxSize()) {
                MangaAutoscrollFloatingPause(
                    highlightColor = textColor,
                    bgColor = bgColor,
                    onPause = { isAutoscrolling = false },
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .navigationBarsPadding()
                        .padding(bottom = 58.dp, end = 16.dp)
                )
            }
        }

        // Tap Zone Overlay Demo
        if (showZoneOverlay) {
            MangaTapZoneDemoOverlay(
                visible = showZoneOverlay,
                layout = tapZoneLayout,
                invert = tapZoneInvert,
                onDismiss = { showZoneOverlay = false },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Contents Sheet
        //
        // DIM FIX. The drawer has always had a "completed" parameter and this
        // call never passed it, so the reader's own chapter list dimmed nothing
        // at all while the details page dimmed correctly from the chapters
        // table. Feed it that same table, and refresh whenever a page turn is
        // recorded so the list is right the moment it is opened.
        // Same store as the details list, collected live, so the reader's own
        // contents drawer can no longer disagree with it about what is finished.
        val tocStateFlow = remember(state.novel?.id) {
            com.lorelight.data.chapters.ChapterReadStore.observe(context, state.novel?.id ?: "")
        }
        val tocState by tocStateFlow.collectAsState()
        val tocCompletedIndices = remember(tocState, state.novel, state.activeChapterIndex) {
            val n = state.novel
            if (n == null) {
                emptySet()
            } else {
                val completed = com.lorelight.data.chapters.ChapterReadStore.completedIndices(n, tocState)
                // Dim every chapter reached so far, including the current one.
                // Later chapters remain bright until the reading position reaches them.
                val reachedIndex = state.activeChapterIndex
                if (reachedIndex >= 0) completed + (0..reachedIndex).toSet() else completed
            }
        }

        MangaContentsDrawer(
            visible = showContentsSheet,
            chapterNames = state.chapterNames,
            currentChapterIndex = state.activeChapterIndex,
            completedIndices = tocCompletedIndices,
            readerHighlightColor = textColor,
            readerTextColor = textColor,
            onSelectChapter = { idx ->
                viewModel.loadChapter(idx, 0)
                showContentsSheet = false
            },
            onDismiss = { showContentsSheet = false }
        )

        // Settings Panel
        MangaReaderSettingsPanel(
            show = showSettingsPanel,
            mangaKey = novelId,
            onDismiss = { showSettingsPanel = false },
            onShowDemoOverlay = { showZoneOverlay = true },
            settingsVersion = settingsVersion,
            activeReadingMode = activeReadingMode,
            onSettingsChanged = {
                activeReadingMode = MangaReaderPrefs.getEffectiveReadingMode(context, novelId)
                com.lorelight.data.local.AppSettingsSignal.notifyChanged()
            }
        )
    }
}

@Composable
fun MangaPageItem(
    sourceId: Long,
    page: Page,
    mode: MangaReadingMode,
    textColor: Color,
    pageContentScale: ContentScale = ContentScale.FillWidth,
    pageColorFilter: androidx.compose.ui.graphics.ColorFilter? = null,
    cropBorders: Boolean = false,
    maxZoom: Float = 3f,
    modifier: Modifier = Modifier
) {
    var retryKey by remember { mutableIntStateOf(0) }
    var autoRetryCount by remember(page) { mutableIntStateOf(0) }
    var currentState by remember(page, retryKey) { mutableStateOf(page.status) }
    val context = LocalContext.current
    val zoomState = rememberZoomState(maxScale = maxZoom)

    // Global "restart stuck page loads" from Settings > Advanced. A page that
    // already decoded keeps its bitmap; only unfinished ones are re-requested.
    val globalRetry by MangaPageRetryBus.version.collectAsState()
    LaunchedEffect(globalRetry) {
        if (globalRetry == 0) return@LaunchedEffect
        if (currentState is Page.State.Ready) return@LaunchedEffect
        autoRetryCount = 0
        clearMangaPageTempFilesAsync(context, sourceId, page)
        page.status = Page.State.Queue
        currentState = Page.State.Queue
        retryKey++
    }

    // Auto-retry when a previously failed or missing page is revisited
    LaunchedEffect(page, currentState) {
        if (currentState is Page.State.Error && autoRetryCount < 2) {
            autoRetryCount++
            clearMangaPageTempFilesAsync(context, sourceId, page)
            page.status = Page.State.Queue
            currentState = Page.State.Queue
            retryKey++
        }
    }

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        when (val s = currentState) {
            is Page.State.Error -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Couldn't load page ${page.number}. Check your connection and try again.",
                        color = textColor,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            autoRetryCount = 0
                            clearMangaPageTempFilesAsync(context, sourceId, page)
                            page.status = Page.State.Queue
                            currentState = Page.State.Queue
                            retryKey++
                        }
                    ) {
                        Text(stringResource(R.string.manga_reader_retry))
                    }
                }
            }
            else -> {
                var isImageLoading by remember { mutableStateOf(true) }

                Box(
                    contentAlignment = Alignment.Center
                ) {
                    val pageCacheKey = remember(sourceId, page, cropBorders) {
                        mangaPageCacheKey(sourceId, page, cropBorders)
                    }
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(MangaPageKey(sourceId, page))
                            .setParameter("retry", retryKey)
                            // Stable keys => Coil returns the already decoded
                            // bitmap instead of reloading, and reuses it as the
                            // placeholder so a flipped-to page draws instantly.
                            .memoryCacheKey(pageCacheKey)
                            .diskCacheKey(pageCacheKey)
                            .placeholderMemoryCacheKey(pageCacheKey)
                            // Decode at the source's own resolution instead of
                            // letting the layout size decide it. Without this,
                            // Coil sizes the bitmap to the view, so a page wider
                            // than the screen was thrown away down to screen
                            // width -- fine while the page sits at 1x, soft the
                            // moment it is zoomed, and the reason double-page
                            // spreads and high-resolution scans looked worse here
                            // than in mihon. Enormous pages are still bounded:
                            // MangaTallImageDecoder claims anything tall or over
                            // budget and applies its own ceiling.
                            .size(coil.size.Size.ORIGINAL)
                            .crossfade(false)
                            .apply {
                                if (cropBorders) transformations(CropBordersTransformation())
                            }
                            .build(),
                        imageLoader = MangaImageLoaderProvider.getImageLoader(context),
                        contentDescription = stringResource(R.string.manga_reader_page_number, page.number.toString()),
                        contentScale = pageContentScale,
                        colorFilter = pageColorFilter,
                        onLoading = {
                            isImageLoading = true
                            page.status = Page.State.LoadPage
                        },
                        onSuccess = {
                            autoRetryCount = 0
                            isImageLoading = false
                            page.status = Page.State.Ready
                            currentState = Page.State.Ready
                        },
                        onError = { result ->
                            isImageLoading = false
                            val err = result.result.throwable
                            if (autoRetryCount < 2) {
                                autoRetryCount++
                                clearMangaPageTempFilesAsync(context, sourceId, page)
                                page.status = Page.State.Queue
                                currentState = Page.State.Queue
                                retryKey++
                            } else {
                                page.status = Page.State.Error(err)
                                currentState = Page.State.Error(err)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .zoomable(zoomState, enableOneFingerZoom = false)
                    )

                    if (isImageLoading && currentState != Page.State.Ready) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(300.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = textColor)
                        }
                    }
                }
            }
        }
    }
}

private data class VisibleSpeechBlock(
    val pageItem: MangaFeedItem.Page,
    val block: MangaTextBlock,
    val blockIndex: Int,
    val itemIndex: Int,
    val id: String
)
