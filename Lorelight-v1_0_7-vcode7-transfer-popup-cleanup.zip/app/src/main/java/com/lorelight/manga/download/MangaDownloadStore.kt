package com.lorelight.manga.download

import android.content.Context
import eu.kanade.tachiyomi.source.model.Page
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/**
 * PERMANENT storage for downloaded manga pages.
 *
 * Why this exists: "Download" used to mean nothing more than warming Coil's
 * image cache in cacheDir. That is a CACHE, so the pages it held were:
 *  - evictable by Android whenever the device got tight on space,
 *  - pruned by the reader itself once the folder passed 512 MB,
 *  - wiped by the "Free images" button in Downloads & Storage,
 *  - and invisible to the library, which had no way to ask "is this chapter
 *    downloaded?" because nothing recorded that a chapter ever finished.
 *
 * So a manga could report "Downloaded 1,240 pages" and still show no download
 * marks in the chapter list and still demand a connection to read.
 *
 * Layout, per source:
 *   filesDir/manga_downloads/<sourceId>/pages/<hash(pageKey)>.img
 *   filesDir/manga_downloads/<sourceId>/chapters/<hash(chapterUrl)>.json
 *
 * Pages are stored FLAT and addressed by page key rather than nested under a
 * chapter, because the image fetcher only ever knows the page it was asked
 * for - it has no idea which chapter that page belongs to. The chapter
 * manifest records which page keys make up a chapter, which is what lets the
 * library answer "downloaded?" and lets the reader open a chapter offline.
 */
object MangaDownloadStore {

    const val DIR_NAME = "manga_downloads"
    private const val MANIFEST_VERSION = 1

    fun rootDir(context: Context): File =
        File(context.applicationContext.filesDir, DIR_NAME)

    private fun sha(input: String): String =
        MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray())
            .joinToString("") { "%02x".format(it) }

    /**
     * Stable identity for a page. Matches the convention the OCR cache already
     * uses, so both stores agree on what "the same page" means.
     */
    fun pageKey(page: Page): String =
        page.imageUrl?.takeIf { it.isNotBlank() }
            ?: page.url.takeIf { it.isNotBlank() }?.let { "$it#${page.index}" }
            ?: "page_${page.index}"

    private fun sourceDir(context: Context, sourceId: Long): File =
        File(rootDir(context), sourceId.toString())

    fun pageFile(context: Context, sourceId: Long, page: Page): File =
        File(File(sourceDir(context, sourceId), "pages"), sha(pageKey(page)) + ".img")

    private fun pageFileForKey(context: Context, sourceId: Long, key: String): File =
        File(File(sourceDir(context, sourceId), "pages"), sha(key) + ".img")

    private fun manifestFile(context: Context, sourceId: Long, chapterUrl: String): File =
        File(File(sourceDir(context, sourceId), "chapters"), sha(chapterUrl) + ".json")

    /** True when this page is already saved permanently. */
    fun hasPage(context: Context, sourceId: Long, page: Page): Boolean =
        try {
            val f = pageFile(context, sourceId, page)
            f.exists() && f.length() > 0L
        } catch (_: Throwable) {
            false
        }

    /**
     * Copies an already-fetched page image into permanent storage. Writes to a
     * temp file first so a kill mid-copy cannot leave a truncated page that
     * later reads as "downloaded".
     */
    fun savePage(context: Context, sourceId: Long, page: Page, source: File): Boolean {
        return try {
            if (!source.exists() || source.length() <= 0L) return false
            val dest = pageFile(context, sourceId, page)
            if (dest.exists() && dest.length() == source.length()) return true
            dest.parentFile?.mkdirs()
            val tmp = File(dest.absolutePath + ".part")
            source.copyTo(tmp, overwrite = true)
            if (dest.exists()) dest.delete()
            val ok = tmp.renameTo(dest)
            if (!ok) tmp.delete()
            ok
        } catch (_: Throwable) {
            false
        }
    }

    /** Records that these pages make up a chapter. Called once it finishes cleanly. */
    fun writeManifest(context: Context, sourceId: Long, chapterUrl: String, pages: List<Page>) {
        if (pages.isEmpty()) return
        try {
            val file = manifestFile(context, sourceId, chapterUrl)
            file.parentFile?.mkdirs()
            val arr = JSONArray()
            for (p in pages) {
                arr.put(
                    JSONObject()
                        .put("i", p.index)
                        .put("u", p.url)
                        .put("iu", p.imageUrl ?: "")
                        .put("k", pageKey(p))
                )
            }
            file.writeText(
                JSONObject()
                    .put("v", MANIFEST_VERSION)
                    .put("pages", arr)
                    .toString()
            )
        } catch (_: Throwable) {
            // A missing manifest only costs the download mark, never data.
        }
    }

    private fun readManifest(context: Context, sourceId: Long, chapterUrl: String): JSONArray? {
        return try {
            val file = manifestFile(context, sourceId, chapterUrl)
            if (!file.exists()) return null
            val root = JSONObject(file.readText())
            if (root.optInt("v", 0) != MANIFEST_VERSION) return null
            root.optJSONArray("pages")?.takeIf { it.length() > 0 }
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * True only when every page named in the manifest is still on disk, so a
     * partially deleted chapter stops claiming to be downloaded.
     */
    fun isChapterDownloaded(context: Context, sourceId: Long, chapterUrl: String): Boolean {
        val arr = readManifest(context, sourceId, chapterUrl) ?: return false
        return try {
            for (i in 0 until arr.length()) {
                val key = arr.getJSONObject(i).optString("k", "")
                if (key.isEmpty()) return false
                val f = pageFileForKey(context, sourceId, key)
                if (!f.exists() || f.length() <= 0L) return false
            }
            true
        } catch (_: Throwable) {
            false
        }
    }

    /** The saved page list for a chapter, so the reader can open it offline. */
    fun pages(context: Context, sourceId: Long, chapterUrl: String): List<Page>? {
        val arr = readManifest(context, sourceId, chapterUrl) ?: return null
        return try {
            val out = ArrayList<Page>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Page(
                        o.optInt("i", i),
                        o.optString("u", ""),
                        o.optString("iu", "").takeIf { it.isNotBlank() }
                    )
                )
            }
            out.takeIf { it.isNotEmpty() }
        } catch (_: Throwable) {
            null
        }
    }

    /** Deletes one chapter's manifest and its page images. Returns bytes freed. */
    fun deleteChapter(context: Context, sourceId: Long, chapterUrl: String): Long {
        var freed = 0L
        try {
            val arr = readManifest(context, sourceId, chapterUrl)
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val key = arr.getJSONObject(i).optString("k", "")
                    if (key.isEmpty()) continue
                    val f = pageFileForKey(context, sourceId, key)
                    if (f.exists()) {
                        freed += f.length()
                        f.delete()
                    }
                }
            }
            manifestFile(context, sourceId, chapterUrl).delete()
        } catch (_: Throwable) {
        }
        return freed
    }

    /** How many of these chapters are downloaded. */
    fun downloadedCount(context: Context, sourceId: Long, chapterUrls: List<String>): Int =
        chapterUrls.count { it.isNotEmpty() && isChapterDownloaded(context, sourceId, it) }

    /** File count and bytes on disk, for the Downloads and Storage monitor. */
    fun stats(context: Context): Pair<Int, Long> {
        return try {
            val root = rootDir(context)
            if (!root.exists()) return 0 to 0L
            var count = 0
            var bytes = 0L
            root.walkTopDown().forEach { f ->
                if (f.isFile) {
                    count++
                    bytes += f.length()
                }
            }
            count to bytes
        } catch (_: Throwable) {
            0 to 0L
        }
    }
}
