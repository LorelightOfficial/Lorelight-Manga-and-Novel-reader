package com.lorelight.manga.transfer

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.lorelight.data.chapters.ChapterReadStore
import com.lorelight.data.local.CoverStorage
import com.lorelight.data.local.NovelPreferences
import com.lorelight.data.model.Novel
import com.lorelight.data.model.encodeMangaChapterUrl
import com.lorelight.data.model.toJSONObject
import com.lorelight.data.model.toNovel
import com.lorelight.manga.download.MangaDownloadStore
import com.lorelight.manga.download.MangaOcrCache
import com.lorelight.service.EpubImportResult
import eu.kanade.tachiyomi.source.model.Page
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.absoluteValue

/**
 * THE .loremanga ARCHIVE: Lorelight's own manga transfer format.
 *
 * WHY IT EXISTS ALONGSIDE CBZ
 * ---------------------------
 * MangaCbzTransfer writes a STANDARD comic archive. That is its whole value:
 * any comic reader can open it. The cost is that everything Lorelight knows
 * about a series beyond its page images has to be squeezed into a side-car
 * manifest that other readers ignore, and several things do not survive at
 * all - per-chapter read marks, resume pages, bookmarks, and the OCR text
 * cache that read-aloud depends on. Re-importing a CBZ therefore gives the
 * pages back and nothing else: every chapter reads as unread, and the first
 * read-aloud pass has to OCR every page again from scratch.
 *
 * A .loremanga file is a plain ZIP too, but it is OURS, so it carries the
 * whole title:
 *
 *   loremanga.json          manifest: format, novel row, per-chapter state
 *   pages/0001/000001.jpg   page images, chapter-major, in reading order
 *   ocr/0001/000001.json    that page's cached OCR blocks, when present
 *   cover.jpg               the stored cover art
 *
 * Restoring one rebuilds the library row, the download store, the cover, the
 * read/bookmark/resume state and the OCR cache, so the series comes back in
 * the state it left - including read-aloud being instant on pages that were
 * already recognised.
 */
object MangaLoreTransfer {

    const val EXTENSION = "loremanga"
    private const val MANIFEST = "loremanga.json"
    private const val FORMAT = "lorelight-manga-archive"
    private const val FORMAT_VERSION = 1

    /**
     * True when this file is one of ours. Checked BEFORE the CBZ sniffer,
     * because a .loremanga is a ZIP full of images too and would otherwise be
     * imported as a plain comic archive, silently dropping everything the
     * format exists to carry.
     */
    fun looksLikeLoremanga(context: Context, uri: Uri): Boolean = try {
        context.contentResolver.openInputStream(uri)?.use { input ->
            var found = false
            ZipInputStream(input.buffered()).use { zip ->
                var entry = zip.nextEntry
                var checked = 0
                while (entry != null && checked++ < 500 && !found) {
                    if (!entry.isDirectory && entry.name == MANIFEST) {
                        val text = zip.readBytes().toString(Charsets.UTF_8)
                        found = runCatching {
                            JSONObject(text).optString("format") == FORMAT
                        }.getOrDefault(false)
                    }
                    entry = zip.nextEntry
                }
            }
            found
        } ?: false
    } catch (_: Throwable) {
        false
    }

    /** How many complete chapters a backup would contain right now. */
    fun downloadedChapterCount(context: Context, novel: Novel): Int =
        MangaCbzTransfer.downloadedChapterCount(context, novel)

    // -----------------------------------------------------------------
    // Export
    // -----------------------------------------------------------------

    suspend fun export(context: Context, novel: Novel): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val sourceId = novel.pluginId?.removePrefix("manga:")?.toLongOrNull()
                ?: error("This title is not a manga")

            // Only complete chapters go in. A half-downloaded chapter would
            // restore as a chapter that claims to be offline and then fails to
            // open, which is worse than not exporting it at all.
            val downloaded = novel.chapterUrls.mapIndexedNotNull { index, encoded ->
                val raw = com.lorelight.data.model.decodeMangaChapterUrl(encoded)?.second ?: encoded
                val pages = MangaDownloadStore.pages(context, sourceId, raw)
                    ?.takeIf { list -> list.all { MangaDownloadStore.hasPage(context, sourceId, it) } }
                pages?.let { Triple(index, raw, it) }
            }
            if (downloaded.isEmpty()) error("Download at least one manga chapter before saving a backup")

            // Read state is keyed by chapter URL, and those URLs are rewritten
            // on import, so it travels as per-chapter fields instead of keys.
            // Wait for the store's disk read first, or a backup taken seconds
            // after launch would record an empty history.
            val state = withTimeoutOrNull(4000L) {
                ChapterReadStore.observe(context, novel.id).first { it.loaded }
            } ?: ChapterReadStore.snapshot(novel.id)

            val safeName = novel.title
                .map { ch -> if (ch.isLetterOrDigit() || ch == ' ' || ch == '-' || ch == '_') ch else '_' }
                .joinToString("")
                .trim()
                .ifBlank { "Manga" }
            val fileName = "$safeName.$EXTENSION"

            openDownloadsOutput(context, fileName).use { rawOut ->
                ZipOutputStream(rawOut.buffered()).use { zip ->
                    val chapterArr = JSONArray()
                    downloaded.forEachIndexed { exportIndex, triple ->
                        val novelIndex = triple.first
                        val pages = triple.third
                        val files = JSONArray()
                        pages.sortedBy { it.index }.forEachIndexed { pageOrder, page ->
                            val source = MangaDownloadStore.pageFile(context, sourceId, page)
                            val ext = extensionFor(source)
                            val entryName = "pages/%04d/%06d.%s".format(exportIndex + 1, pageOrder + 1, ext)
                            zip.putNextEntry(ZipEntry(entryName))
                            source.inputStream().use { it.copyTo(zip) }
                            zip.closeEntry()

                            val ocrFile = ocrFileFor(context, sourceId, page)
                            val ocrName = if (ocrFile != null) {
                                "ocr/%04d/%06d.json".format(exportIndex + 1, pageOrder + 1)
                            } else {
                                null
                            }
                            if (ocrFile != null && ocrName != null) {
                                zip.putNextEntry(ZipEntry(ocrName))
                                ocrFile.inputStream().use { it.copyTo(zip) }
                                zip.closeEntry()
                            }

                            val pageObj = JSONObject().put("file", entryName)
                            if (ocrName != null) pageObj.put("ocr", ocrName)
                            files.put(pageObj)
                        }

                        val key = ChapterReadStore.keyFor(novel, novelIndex)
                        val entry = state.entries[key]
                        chapterArr.put(
                            JSONObject()
                                .put("name", novel.chapters.getOrNull(novelIndex) ?: "Chapter ${novelIndex + 1}")
                                .put(
                                    "number",
                                    novel.chapterNumbers.getOrNull(novelIndex)?.toDouble()
                                        ?: (novelIndex + 1).toDouble()
                                )
                                .put("completed", entry?.completed == true)
                                .put("page", entry?.page ?: 0)
                                .put("bookmark", entry?.bookmark == true)
                                .put("current", key.isNotEmpty() && key == state.currentKey)
                                .put("pages", files)
                        )
                    }

                    // The chapter arrays are rebuilt on import from the
                    // manifest above, and the cover travels as a real file, so
                    // both are cleared here rather than duplicated.
                    val portableNovel = novel.toJSONObject().apply {
                        put("chapters", JSONArray())
                        put("chapterUrls", JSONArray())
                        put("chapterNumbers", JSONArray())
                        put("coverImageBase64", JSONObject.NULL)
                    }
                    val manifest = JSONObject()
                        .put("format", FORMAT)
                        .put("formatVersion", FORMAT_VERSION)
                        .put("app", "Lorelight")
                        .put("exportedAt", System.currentTimeMillis())
                        .put("novel", portableNovel)
                        .put("chapters", chapterArr)
                    putText(zip, MANIFEST, manifest.toString())

                    val cover = CoverStorage.coverFile(context, novel.id)
                    if (cover.exists() && cover.length() > 0) {
                        zip.putNextEntry(ZipEntry("cover." + extensionFor(cover)))
                        cover.inputStream().use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
            }
            fileName
        }
    }

    // -----------------------------------------------------------------
    // Import
    // -----------------------------------------------------------------

    suspend fun import(context: Context, uri: Uri): EpubImportResult = withContext(Dispatchers.IO) {
        val temp = File(context.cacheDir, "loremanga_import_${UUID.randomUUID()}.zip")
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(temp).use { input.copyTo(it) }
            } ?: return@withContext EpubImportResult.Error("Could not open this .loremanga file")
            if (temp.length() <= 0L) return@withContext EpubImportResult.Error("The .loremanga file is empty")

            ZipFile(temp).use { zip ->
                val entries = zip.entries().asSequence().filter { !it.isDirectory }.toList()
                if (entries.any { unsafe(it.name) }) {
                    return@withContext EpubImportResult.Error("Unsafe archive paths were rejected")
                }
                val manifestEntry = zip.getEntry(MANIFEST)
                    ?: return@withContext EpubImportResult.Error("This file is not a Lorelight manga backup")
                val manifest = runCatching {
                    JSONObject(zip.getInputStream(manifestEntry).bufferedReader().use { it.readText() })
                }.getOrNull()
                    ?: return@withContext EpubImportResult.Error("The backup manifest is unreadable")
                if (manifest.optString("format") != FORMAT) {
                    return@withContext EpubImportResult.Error("This file is not a Lorelight manga backup")
                }
                if (manifest.optInt("formatVersion", 1) > FORMAT_VERSION) {
                    return@withContext EpubImportResult.Error("This backup was made by a newer version of Lorelight")
                }
                val chaptersArr = manifest.optJSONArray("chapters")
                if (chaptersArr == null || chaptersArr.length() == 0) {
                    return@withContext EpubImportResult.Error("The backup contains no chapters")
                }

                val baseNovel = manifest.optJSONObject("novel")?.let { runCatching { it.toNovel() }.getOrNull() }
                val title = baseNovel?.title?.takeIf { it.isNotBlank() }
                    ?: temp.nameWithoutExtension.replace('_', ' ').ifBlank { "Imported Manga" }
                val author = baseNovel?.author ?: "Unknown Author"
                val existing = NovelPreferences.loadNovelsFromPrefs(context).toMutableList()
                val existingIndex = existing.indexOfFirst {
                    it.title.equals(title, true) && it.author.equals(author, true)
                }
                val novelId = existing.getOrNull(existingIndex)?.id ?: UUID.randomUUID().toString()
                // Negative ids are local-only sources, so a restored title can
                // never collide with an installed extension's source id.
                val sourceId = -(novelId.hashCode().toLong().absoluteValue + 1L)

                val chapterNames = mutableListOf<String>()
                val chapterUrls = mutableListOf<String>()
                val chapterNumbers = mutableListOf<Float>()
                val completedIndices = mutableListOf<Int>()
                val bookmarkIndices = mutableListOf<Int>()
                val resumePages = mutableListOf<Pair<Int, Int>>()
                var currentIndex = -1

                for (c in 0 until chaptersArr.length()) {
                    val chapter = chaptersArr.optJSONObject(c) ?: continue
                    val pageArr = chapter.optJSONArray("pages") ?: continue
                    val rawUrl = "loremanga://$novelId/chapter/$c"
                    val pages = mutableListOf<Page>()
                    for (p in 0 until pageArr.length()) {
                        val pageObj = pageArr.optJSONObject(p) ?: continue
                        val name = pageObj.optString("file")
                        if (name.isEmpty()) continue
                        val entry = zip.getEntry(name) ?: continue
                        val pageUrl = "loremanga://$novelId/$c/$p"
                        val page = Page(p, pageUrl, pageUrl)
                        val part = File(context.cacheDir, "loremanga_page_${UUID.randomUUID()}")
                        try {
                            zip.getInputStream(entry).use { input ->
                                FileOutputStream(part).use { input.copyTo(it) }
                            }
                            if (!MangaDownloadStore.savePage(context, sourceId, page, part)) {
                                error("Failed to store page ${p + 1}")
                            }
                        } finally {
                            part.delete()
                        }

                        // Cached OCR is copied verbatim, versioned exactly as
                        // MangaOcrCache wrote it, so a stale schema is dropped
                        // by the cache's own version check rather than trusted.
                        val ocrName = pageObj.optString("ocr", "")
                        if (ocrName.isNotEmpty()) {
                            val ocrEntry = zip.getEntry(ocrName)
                            if (ocrEntry != null) {
                                runCatching {
                                    val target = MangaOcrCache.fileFor(context, sourceId, pageUrl)
                                    target.parentFile?.mkdirs()
                                    zip.getInputStream(ocrEntry).use { input ->
                                        FileOutputStream(target).use { input.copyTo(it) }
                                    }
                                }
                            }
                        }
                        pages.add(page)
                    }
                    if (pages.isEmpty()) continue
                    MangaDownloadStore.writeManifest(context, sourceId, rawUrl, pages)

                    val index = chapterNames.size
                    chapterNames += chapter.optString("name", "Chapter ${index + 1}")
                    chapterNumbers += chapter.optDouble("number", (index + 1).toDouble()).toFloat()
                    chapterUrls += encodeMangaChapterUrl(sourceId, rawUrl)
                    if (chapter.optBoolean("completed")) completedIndices += index
                    if (chapter.optBoolean("bookmark")) bookmarkIndices += index
                    val resume = chapter.optInt("page", 0)
                    if (resume > 0) resumePages += index to resume
                    if (chapter.optBoolean("current")) currentIndex = index
                }
                if (chapterNames.isEmpty()) {
                    return@withContext EpubImportResult.Error("No readable chapters were found in this backup")
                }

                val resolvedCurrent = if (currentIndex in chapterNames.indices) currentIndex else 0
                val imported = (
                    baseNovel ?: Novel(
                        title = title,
                        currentChapter = chapterNames.first(),
                        lastReadTimestamp = 0L,
                        author = author
                    )
                    ).copy(
                    id = novelId,
                    title = title,
                    author = author,
                    status = "Imported",
                    isOnline = false,
                    sourceUrl = null,
                    pluginId = "manga:$sourceId",
                    pluginNovelPath = null,
                    chapters = chapterNames,
                    chapterUrls = chapterUrls,
                    chapterNumbers = chapterNumbers,
                    totalChapters = chapterNames.size,
                    currentChapter = chapterNames[resolvedCurrent],
                    currentChapterIndex = resolvedCurrent,
                    currentMangaPageIndex = baseNovel?.currentMangaPageIndex ?: 0,
                    coverImageBase64 = null,
                    dateModified = System.currentTimeMillis()
                )

                val coverEntry = entries.firstOrNull {
                    it.name.substringAfterLast('/').startsWith("cover.", true)
                }
                val finalNovel = if (coverEntry != null) {
                    val coverFile = CoverStorage.coverFile(context, novelId)
                    coverFile.parentFile?.mkdirs()
                    zip.getInputStream(coverEntry).use { input ->
                        FileOutputStream(coverFile).use { input.copyTo(it) }
                    }
                    imported.copy(coverImageBase64 = coverFile.absolutePath)
                } else {
                    imported
                }

                if (existingIndex >= 0) existing[existingIndex] = finalNovel else existing.add(0, finalNovel)
                NovelPreferences.saveNovelsToPrefsSync(context, existing)

                // Read state last: the store keys off chapter URLs, which only
                // exist once the row above has been written with its new list.
                if (completedIndices.isNotEmpty()) {
                    ChapterReadStore.setCompleted(context, finalNovel, completedIndices, true)
                }
                bookmarkIndices.forEach { ChapterReadStore.setBookmark(context, finalNovel, it, true) }
                // pageCount 0 means "unknown", so restoring a resume point can
                // never be mistaken for finishing the chapter.
                resumePages.forEach { (index, page) ->
                    ChapterReadStore.notePage(context, finalNovel, index, page, 0)
                }
                if (currentIndex >= 0) ChapterReadStore.setCurrent(context, finalNovel, currentIndex)

                EpubImportResult.Success(finalNovel, existingIndex < 0)
            }
        } catch (t: Throwable) {
            EpubImportResult.Error(
                "Failed to import backup: ${t.localizedMessage ?: t.message ?: "invalid file"}"
            )
        } finally {
            temp.delete()
        }
    }

    // -----------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------

    private fun ocrFileFor(context: Context, sourceId: Long, page: Page): File? {
        val candidates = listOfNotNull(
            page.imageUrl?.takeIf { it.isNotBlank() },
            page.url.takeIf { it.isNotBlank() }
        )
        for (key in candidates) {
            val f = MangaOcrCache.fileFor(context, sourceId, key)
            if (f.exists() && f.length() > 0L) return f
        }
        return null
    }

    private fun openDownloadsOutput(context: Context, name: String): OutputStream {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                // Deliberately generic: a specific MIME makes MediaStore
                // "correct" the extension, which would rename the backup to
                // .zip and hide it from the importer's own file filter.
                put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Lorelight")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("Could not create the backup in Downloads")
            val stream = context.contentResolver.openOutputStream(uri) ?: error("Could not write the backup")
            return object : OutputStream() {
                override fun write(b: Int) = stream.write(b)
                override fun write(b: ByteArray, off: Int, len: Int) = stream.write(b, off, len)
                override fun flush() = stream.flush()
                override fun close() {
                    stream.close()
                    context.contentResolver.update(
                        uri,
                        ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) },
                        null,
                        null
                    )
                }
            }
        }
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        return FileOutputStream(File(dir, name))
    }

    private fun extensionFor(file: File): String = file.inputStream().use { input ->
        val b = ByteArray(12)
        val n = input.read(b)
        when {
            n >= 3 && b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte() -> "jpg"
            n >= 8 && b.sliceArray(0..7).contentEquals(
                byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
            ) -> "png"
            n >= 12 && String(b, 0, 4) == "RIFF" && String(b, 8, 4) == "WEBP" -> "webp"
            n >= 6 && String(b, 0, 3) == "GIF" -> "gif"
            else -> "jpg"
        }
    }

    private fun unsafe(name: String): Boolean =
        name.startsWith('/') || name.startsWith('\\') || name.split('/', '\\').any { it == ".." }

    private fun putText(zip: ZipOutputStream, name: String, text: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(text.toByteArray())
        zip.closeEntry()
    }
}
