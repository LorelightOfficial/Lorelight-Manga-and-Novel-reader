package com.lorelight.manga.reader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import androidx.core.graphics.drawable.toDrawable
import coil.ImageLoader
import coil.decode.DecodeResult
import coil.decode.Decoder
import coil.decode.ImageSource
import coil.fetch.SourceResult
import coil.request.Options

/**
 * Request parameter that opts a page into TILED long-strip decoding.
 *
 * The value is the page's cache key, which doubles as the key for the decoded
 * tiles (see [MangaStripCache]). Only the long-strip viewer sets it, and only
 * when border cropping is off, because a tiled strip is not a `BitmapDrawable`:
 *
 *  - Coil transformations (border cropping) only run on a `BitmapDrawable`.
 *  - The paged reader, the chapter downloader and the OCR/TTS pipeline all read
 *    `result.drawable` expecting real bitmap pixels.
 *
 * None of those set this parameter, so they keep the exact whole-bitmap
 * behaviour they had before tiling existed.
 */
const val MANGA_SLICE_PARAM = "mp_slice"

/**
 * Decoder for oversized manga / manhwa pages.
 *
 * WHY THIS CLASS EXISTS
 * ---------------------
 * Webtoon sources serve single vertical strips 10,000-20,000 px tall. Coil's
 * stock decoder sizes from the layout width only, so for an 800 x 20,000 strip
 * it decodes the whole thing at ARGB_8888 -- 64 MB for ONE page -- which evicts
 * the memory cache and then throws OutOfMemoryError. Something has to impose a
 * budget.
 *
 * WHAT CHANGED, AND WHY THE OLD VERSION LOOKED WORSE THAN MIHON
 * -------------------------------------------------------------
 * The previous implementation defended memory with two blunt instruments, both
 * applied to EVERY tall page:
 *
 *   1. inPreferredConfig = RGB_565, unconditionally. 16-bit colour (5-6-5) is
 *      genuinely lossless for black-and-white line art, which is what the old
 *      comment claimed. But long strip mode is precisely where COLOURED manhwa
 *      lives, and 5 bits of red across a skin-tone or sky gradient bands
 *      visibly.
 *
 *   2. A flat 8,000,000-pixel budget with power-of-two downsampling. A very
 *      ordinary 800 x 12,000 strip is 9.6M pixels, so it tripped the budget and
 *      was sampled to 400 x 6,000 -- then stretched back up to fill a 1080 px
 *      wide screen. A 2.7x upscale of a half-resolution image is exactly the
 *      softness being compared against mihon.
 *
 * Mihon does neither. It keeps full resolution and lets SubsamplingScaleImageView
 * tile the strip, decoding only the region actually on screen. So this decoder
 * inverts both decisions:
 *
 *   1. RESOLUTION FLOOR. Never sample below the physical screen width. A
 *      720-900 px wide source on a 1080 px screen now decodes 1:1 instead of
 *      being halved.
 *
 *   2. FULL COLOUR FIRST. ARGB_8888 is the default. RGB_565 is the FIRST memory
 *      fallback, tried before any resolution is thrown away. Downsampling is
 *      the last resort rather than the first.
 *
 *   3. REAL BUDGET. The limit is bytes derived from the actual heap, not a fixed
 *      pixel count, so a device with headroom gets full quality instead of being
 *      held to the same ceiling as a 2 GB phone.
 *
 * AND WHY IT SCROLLED WORSE THAN MIHON -- the tiling half
 * -------------------------------------------------------
 * Quality was only half the story. Handing Compose one 20,000 px tall bitmap is
 * what made long strip mode stutter: no GPU can hold a texture that tall (the
 * limit is 4096 px on older devices, 8192-16384 on newer ones), so Skia gave up
 * on caching it and re-uploaded the visible slice of that bitmap from CPU memory
 * on every single frame. Tens of megabytes of pixel traffic per frame, only
 * while the finger was moving -- which is exactly the symptom.
 *
 *   4. TILING. When the long-strip viewer asks for a page (see
 *      [MANGA_SLICE_PARAM]) and the decoded strip would still be taller than
 *      [TALL_THRESHOLD_PX], it is decoded with [BitmapRegionDecoder] as a stack
 *      of slices at most [SlicedStripDrawable.MAX_SLICE_HEIGHT_PX] tall, wrapped
 *      in a [SlicedStripDrawable]. Every slice is a legal texture that uploads
 *      once, and slices off screen are never drawn. If region decoding is not
 *      possible for the format, the whole-bitmap path below still runs, so a
 *      page always renders.
 *
 *   5. WIDTH CEILING (strips only). A strip is read fit-width, so decoding one
 *      far wider than the screen buys nothing and costs memory that would push
 *      the budget into RGB_565 or downsampling. Strips are capped at twice the
 *      screen width, and at [MAX_STRIP_WIDTH_PX] so a slice is always textureable
 *      in both dimensions. The paged reader keeps full source resolution, which
 *      is what makes zooming into a spread sharp.
 *
 * Net effect on a typical 800 x 12,000 colour strip:
 *   before -> 400 x 6,000 @ RGB_565, one un-textureable bitmap re-uploaded per
 *             frame
 *   after  -> 800 x 12,000 @ ARGB_8888 on a roomy device, drawn as six cached
 *             tiles of which two or three are on screen
 */
class MangaTallImageDecoder(
    private val source: ImageSource,
    private val options: Options,
    private val sampleSize: Int,
    private val preferredConfig: Bitmap.Config,
    private val sourceWidth: Int = 0,
    private val sourceHeight: Int = 0,
    /** Slice height in decoded pixels, or 0 to decode as a single bitmap. */
    private val sliceHeightPx: Int = 0,
    /** Cache key for the decoded tiles, or null when not tiling. */
    private val stripCacheKey: String? = null
) : Decoder {

    override suspend fun decode(): DecodeResult {
        // Already-decoded tiles. Coil cannot memory-cache a tiled strip, so
        // without this, scrolling back up a chapter would re-decode every strip
        // from disk -- which is when the reader is busiest.
        if (stripCacheKey != null) {
            val cached = MangaStripCache.get(stripCacheKey)
            if (cached != null) {
                return DecodeResult(
                    drawable = cached.asDrawable(),
                    isSampled = sampleSize > 1
                )
            }
        }

        // Prefer the page's FILE on disk. MangaPageFetcher always hands back a
        // file-backed ImageSource, so this is the normal case, and it removes
        // two real costs: reading the whole encoded page into a ByteArray
        // before the first frame can be drawn, and then KEEPING that array
        // alive for as long as the strip stays cached (ten cached strips meant
        // ten pages of encoded bytes pinned in the heap, for nothing).
        val stripFile: java.io.File? = if (sliceHeightPx > 0) {
            try {
                source.fileOrNull()?.let { java.io.File(it.toString()) }
            } catch (t: Throwable) {
                null
            }
        } else {
            null
        }

        // Only fall back to buffering the bytes when there is no file to read.
        // An ImageSource cannot be consumed twice, so reading them up front is
        // what allows tiling to fail and still fall back to a whole-bitmap
        // decode.
        val encoded: ByteArray? = if (sliceHeightPx > 0 && stripFile == null) {
            try {
                source.source().readByteArray()
            } catch (t: Throwable) {
                null
            }
        } else {
            null
        }

        if (stripFile != null || encoded != null) {
            val tiles = decodeTiles(stripFile, encoded)
            if (tiles != null) {
                if (stripCacheKey != null) MangaStripCache.put(stripCacheKey, tiles)
                return DecodeResult(
                    drawable = tiles.asDrawable(),
                    isSampled = sampleSize > 1
                )
            }
        }

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = preferredConfig
            inMutable = false
        }
        val bitmap = if (encoded != null) {
            BitmapFactory.decodeByteArray(encoded, 0, encoded.size, opts)
        } else {
            source.source().inputStream().use { stream ->
                BitmapFactory.decodeStream(stream, null, opts)
            }
        } ?: throw IllegalStateException("Could not decode manga page image")

        return DecodeResult(
            drawable = bitmap.toDrawable(options.context.resources),
            isSampled = sampleSize > 1
        )
    }

    /**
     * Opens the strip for tiled, ON-DEMAND decoding. Returns null if the format
     * does not support region decoding, so the caller can fall back to a single
     * bitmap.
     *
     * This used to decode EVERY slice before returning, which is why a long
     * page sat on a spinner: a 15,000 px strip is eight full-width decodes, of
     * which the reader then drew two, and the ~65 MB result was too large for
     * the strip cache to keep. Now only the top [PRIME_SLICES] slices are
     * decoded here -- enough to fill the first screen with real pixels -- plus
     * a tiny whole-strip preview that covers everything below until the real
     * slices land. The region decoder stays open inside [MangaStripTiles], so
     * the rest of the page decodes as the reader scrolls into it.
     */
    private fun decodeTiles(file: java.io.File?, encoded: ByteArray?): MangaStripTiles? {
        if (sourceWidth <= 0 || sourceHeight <= 0 || sliceHeightPx <= 0) return null
        if (file == null && encoded == null) return null

        val handle = MangaStripTiles.openRegion(file, encoded) ?: return null
        val region = handle.decoder

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = preferredConfig
            inMutable = false
        }
        // decodeRegion applies inSampleSize itself, so the region asked for is
        // in SOURCE pixels and comes back sliceHeightPx tall.
        val srcSliceHeight = (sliceHeightPx * sampleSize).coerceAtLeast(1)
        val primed = HashMap<Int, Bitmap>(PRIME_SLICES)
        val rect = Rect()
        for (i in 0 until PRIME_SLICES) {
            val top = i.toLong() * srcSliceHeight
            if (top >= sourceHeight) break
            val h = minOf(srcSliceHeight.toLong(), sourceHeight - top).toInt()
            if (h <= 0) break
            rect.set(0, top.toInt(), sourceWidth, top.toInt() + h)
            val slice = try {
                region.decodeRegion(rect, opts)
            } catch (t: Throwable) {
                null
            }
            if (slice == null) break
            primed[i] = slice
        }

        // Nothing decoded at all means this format cannot be region decoded
        // here; let the caller fall back to a whole-bitmap decode.
        if (primed.isEmpty()) {
            handle.close()
            return null
        }

        val tiles = MangaStripTiles.open(
            handle = handle,
            file = file,
            encoded = encoded,
            sourceWidth = sourceWidth,
            sourceHeight = sourceHeight,
            sampleSize = sampleSize,
            config = preferredConfig,
            sliceHeightPx = sliceHeightPx,
            preview = decodePreviewFrom(file, encoded),
            primed = primed,
        )
        if (tiles == null) handle.close()
        return tiles
    }

    /** Preview from whichever source the page came from. */
    private fun decodePreviewFrom(file: java.io.File?, encoded: ByteArray?): Bitmap? {
        if (encoded != null) return decodePreview(encoded)
        if (file == null) return null

        var sample = 1
        while (sample < MAX_PREVIEW_SAMPLE && (sourceWidth / sample) > PREVIEW_WIDTH_PX) {
            sample *= 2
        }
        if (sample < 2) return null

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
            inMutable = false
        }
        return try {
            BitmapFactory.decodeFile(file.absolutePath, opts)
        } catch (t: Throwable) {
            null
        }
    }

    /**
     * A whole-strip thumbnail, decoded at a heavy sample size into 16-bit
     * colour. A few hundred kilobytes and a couple of milliseconds, drawn
     * stretched wherever a real slice is not resident yet -- which is what
     * replaces the spinner with the actual page on the very first frame.
     */
    private fun decodePreview(encoded: ByteArray): Bitmap? {
        var sample = 1
        while (sample < MAX_PREVIEW_SAMPLE && (sourceWidth / sample) > PREVIEW_WIDTH_PX) {
            sample *= 2
        }
        // A page small enough that the preview would be near full size is not
        // worth decoding twice.
        if (sample < 2) return null

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
            inMutable = false
        }
        return try {
            BitmapFactory.decodeByteArray(encoded, 0, encoded.size, opts)
        } catch (t: Throwable) {
            null
        }
    }

    private fun recycleQuietly(region: BitmapRegionDecoder) {
        try {
            region.recycle()
        } catch (t: Throwable) {
            // Nothing to do; the decoder is being discarded anyway.
        }
    }

    class Factory : Decoder.Factory {
        override fun create(
            result: SourceResult,
            options: Options,
            imageLoader: ImageLoader
        ): Decoder? {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            try {
                // Peek the source to read image bounds without closing or consuming the underlying ImageSource.
                // Do NOT call .use {} or close the peeked stream, as that can close the underlying okio source.
                val stream = result.source.source().peek().inputStream()
                BitmapFactory.decodeStream(stream, null, bounds)
            } catch (t: Throwable) {
                return null
            }

            val width = bounds.outWidth
            val height = bounds.outHeight
            if (width <= 0 || height <= 0) return null

            val budget = decodeByteBudget()
            val screenWidth = screenWidthPx(options.context)

            // Set only by the long-strip viewer. Its presence means the page
            // will be drawn fit-width as part of a continuous strip, which is
            // what makes tiling and the width ceiling safe to apply.
            val stripCacheKey = options.parameters.value(MANGA_SLICE_PARAM) as? String

            val widthCeiling = if (stripCacheKey != null) {
                minOf(screenWidth * 2, MAX_STRIP_WIDTH_PX)
            } else {
                Int.MAX_VALUE
            }

            // An ordinary page that fits comfortably at full colour is handed
            // back to Coil's own decoder, which already sizes from the layout.
            if (height <= TALL_THRESHOLD_PX &&
                width <= widthCeiling &&
                estimatedBytes(width, height, 1, Bitmap.Config.ARGB_8888) <= budget
            ) {
                return null
            }

            // 1. Resolution floor. Halve only while the result would still be at
            //    least as wide as the screen, so the reader never upscales.
            var sample = 1
            while (sample < MAX_SAMPLE && (width / (sample * 2)) >= screenWidth) {
                sample *= 2
            }

            // 1b. Strip width ceiling. Never applies outside long strip mode,
            //     where widthCeiling is unbounded.
            while (sample < MAX_SAMPLE && (width / sample) > widthCeiling) {
                sample *= 2
            }

            // 2. Memory fallbacks, least visible first: full colour, then 16-bit
            //    colour, and only then start discarding resolution.
            var config = Bitmap.Config.ARGB_8888
            while (estimatedBytes(width, height, sample, config) > budget) {
                if (config == Bitmap.Config.ARGB_8888) {
                    config = Bitmap.Config.RGB_565
                    continue
                }
                if (sample >= MAX_SAMPLE) break
                sample *= 2
            }

            // 3. Tile, but only a genuine strip in the long-strip viewer.
            //    Shorter pages stay a single bitmap: they are well within every
            //    texture limit, and Coil's memory cache (which cannot hold a
            //    tiled strip) serves them better.
            val sliceHeight = if (stripCacheKey != null &&
                (height / sample) > TALL_THRESHOLD_PX
            ) {
                SlicedStripDrawable.MAX_SLICE_HEIGHT_PX
            } else {
                0
            }

            return MangaTallImageDecoder(
                source = result.source,
                options = options,
                sampleSize = sample,
                preferredConfig = config,
                sourceWidth = width,
                sourceHeight = height,
                sliceHeightPx = sliceHeight,
                stripCacheKey = if (sliceHeight > 0) stripCacheKey else null
            )
        }
    }

    companion object {
        /**
         * Slices decoded before the page is handed to the reader. Two covers a
         * phone viewport, so the first frame is real pixels; everything below
         * starts as the preview and sharpens as it scrolls in.
         */
        private const val PRIME_SLICES = 2

        /** Target width of the instant preview, in decoded pixels. */
        private const val PREVIEW_WIDTH_PX = 320

        private const val MAX_PREVIEW_SAMPLE = 64

        /** Above this height a page is treated as a strip and budgeted explicitly. */
        const val TALL_THRESHOLD_PX = 4000

        /** Hard floor on quality: never sample more aggressively than 1/8. */
        private const val MAX_SAMPLE = 8

        /**
         * Width ceiling for tiled strips, so a slice is textureable in both
         * dimensions on every supported device. Only strips are capped; the
         * paged reader still decodes at full source resolution.
         */
        private const val MAX_STRIP_WIDTH_PX = 2048

        /** Used only if display metrics are unavailable for some reason. */
        private const val FALLBACK_SCREEN_WIDTH_PX = 1080

        private const val MIN_BUDGET_BYTES = 24L * 1024 * 1024

        /**
         * A heap this big means largeHeap was honoured and the device has room
         * to spare. Anything below it gets the old conservative ceiling.
         */
        private const val ROOMY_HEAP_BYTES = 384L * 1024 * 1024

        /** Per-page ceiling on a roomy heap. See decodeByteBudget. */
        private const val ROOMY_MAX_BUDGET_BYTES = 72L * 1024 * 1024

        /**
         * Lowered from 96 MB. This is a PER-PAGE ceiling, and several pages
         * are alive at once (the visible one, its preloaded neighbours, and
         * whatever the memory cache is still holding). At 96 MB a handful of
         * colour strips could reserve more than the entire heap, which ends
         * as an OS low-memory kill rather than a catchable OutOfMemoryError.
         */
        private const val MAX_BUDGET_BYTES = 48L * 1024 * 1024

        private fun screenWidthPx(context: Context): Int {
            val w = try {
                context.resources.displayMetrics.widthPixels
            } catch (t: Throwable) {
                0
            }
            return if (w > 0) w else FALLBACK_SCREEN_WIDTH_PX
        }

        private fun bytesPerPixel(config: Bitmap.Config): Int =
            if (config == Bitmap.Config.RGB_565) 2 else 4

        private fun estimatedBytes(
            width: Int,
            height: Int,
            sample: Int,
            config: Bitmap.Config
        ): Long {
            val w = (width / sample).coerceAtLeast(1).toLong()
            val h = (height / sample).coerceAtLeast(1).toLong()
            return w * h * bytesPerPixel(config)
        }

        /**
         * Per-page decode budget in bytes, derived from the real heap rather
         * than a fixed pixel count. Roughly an eighth of max heap, clamped so
         * small devices stay safe and large ones actually benefit.
         */
        private fun decodeByteBudget(): Long {
            val maxHeap = try {
                Runtime.getRuntime().maxMemory()
            } catch (t: Throwable) {
                0L
            }
            if (maxHeap <= 0L) return MIN_BUDGET_BYTES

            // This number decides picture quality, not just memory. Every page
            // that does not fit inside it is decoded at 16-bit colour, and a
            // page that does not fit even then loses resolution. So on a phone
            // with a 512 MB heap the old flat eighth-of-heap ceiling was the
            // single biggest reason colour strips came out banded and soft: it
            // capped one page at 48 MB while hundreds of megabytes sat unused.
            //
            // largeHeap is on in the manifest, so a modern device reports
            // 384-512 MB here and gets a sixth of it, up to 72 MB -- enough for
            // a full-resolution ARGB_8888 colour strip around 1200 x 15000.
            // Small devices keep the old conservative numbers untouched, which
            // is where the low-memory kills came from in the first place.
            val roomy = maxHeap >= ROOMY_HEAP_BYTES
            val divisor = if (roomy) 6L else 8L
            val cap = if (roomy) ROOMY_MAX_BUDGET_BYTES else MAX_BUDGET_BYTES
            return (maxHeap / divisor).coerceIn(MIN_BUDGET_BYTES, cap)
        }
    }
}
