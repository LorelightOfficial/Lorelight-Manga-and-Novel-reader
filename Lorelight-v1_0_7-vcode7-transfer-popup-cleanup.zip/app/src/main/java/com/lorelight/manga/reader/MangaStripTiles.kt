package com.lorelight.manga.reader

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Tiled rendering for long-strip (webtoon) pages.
 *
 * WHY THIS EXISTS -- the real cause of "scrolling long strip mode lags a lot".
 *
 * Webtoon sources serve one page as a single vertical strip 10,000-20,000 px
 * tall. The reader decoded that into ONE bitmap and handed it to Compose to
 * draw. Every GPU has a maximum texture size -- 4096 px on older devices,
 * 8192-16384 px on newer ones -- and a bitmap taller than that CANNOT be
 * uploaded as a texture. Skia then falls back to re-uploading the visible
 * region of that bitmap from CPU memory on EVERY SINGLE FRAME. That is tens of
 * megabytes of pixel traffic per frame while the finger is moving, which is why
 * the strip crawled no matter how fast the device was. (The image loader
 * already had to set `allowHardware(false)` for the same reason -- a HARDWARE
 * bitmap over the limit silently drew nothing at all.)
 *
 * Mihon never hits this: SubsamplingScaleImageView cuts the strip into tiles
 * and draws only the tiles on screen. [SlicedStripDrawable] is that idea in the
 * form Coil and Compose can use -- the strip is drawn as a stack of slices,
 * each at most [SlicedStripDrawable.MAX_SLICE_HEIGHT_PX] tall, so every slice is
 * a legal texture that uploads once and is then cached by the GPU. Slices
 * outside the clip are skipped outright, so a frame touches two or three small
 * textures instead of re-uploading a 20,000 px image.
 *
 * WHY IT IS NOW LAZY -- the cause of "images load slow in the reader".
 *
 * The first version of this decoded EVERY slice before the page could be shown.
 * A 15,000 px strip is eight slices, so the reader sat on a spinner while eight
 * full-width regions were decoded, of which the reader then drew two. Worse,
 * the finished strip was ~65 MB of pixels -- larger than the whole strip cache
 * -- so preloading the next page evicted the previous one and nothing was ever
 * reused. Preloading four pages ahead was almost pure wasted work.
 *
 * Now a strip is a lazy tile set, exactly like SubsamplingScaleImageView:
 *
 *  - the [BitmapRegionDecoder] is opened once and KEPT OPEN for the page,
 *  - a tiny [preview] of the whole strip is decoded up front (a couple of
 *    milliseconds) and drawn wherever a real slice is not resident yet, so the
 *    page appears instantly instead of showing a spinner,
 *  - the slices actually inside the clip are decoded on demand, off the UI
 *    thread, and the drawable invalidates itself as each one lands,
 *  - resident slices are capped by [liveBudgetBytes] and the ones furthest from
 *    the viewport are dropped first.
 *
 * A page therefore costs a preview plus the two or three slices on screen,
 * instead of the entire strip -- which is what makes both the first paint and
 * the preload cheap enough to feel instant.
 */
class SlicedStripDrawable(private val tiles: MangaStripTiles) : Drawable() {

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val clipRect = Rect()
    private val previewSrc = Rect()
    private val dst = RectF()

    /**
     * Posted to the main thread as each slice lands. Coil's Compose painter
     * registers a Drawable.Callback, so `invalidateSelf` is what repaints the
     * page with the real pixels once the preview has already been shown.
     */
    private val onSliceReady: () -> Unit = {
        mainHandler.post { invalidateSelf() }
    }

    override fun getIntrinsicWidth(): Int = tiles.decodedWidth

    override fun getIntrinsicHeight(): Int = tiles.decodedHeight

    override fun draw(canvas: Canvas) {
        val b = bounds
        val totalWidth = tiles.decodedWidth
        val totalHeight = tiles.decodedHeight
        if (b.isEmpty || totalWidth <= 0 || totalHeight <= 0) return

        val scaleX = b.width().toFloat() / totalWidth.toFloat()
        val scaleY = b.height().toFloat() / totalHeight.toFloat()
        val hasClip = canvas.getClipBounds(clipRect)
        val preview = tiles.preview()

        var visibleFirst = -1
        var visibleLast = -1

        for (i in 0 until tiles.sliceCount) {
            val sliceTop = tiles.sliceTop(i)
            val sliceHeight = tiles.sliceHeight(i)
            if (sliceHeight <= 0) continue

            val top = b.top + sliceTop * scaleY
            val bottom = b.top + (sliceTop + sliceHeight) * scaleY

            // Skip slices the frame cannot see. When a clip is not available
            // this simply draws them all and Skia rejects the off-screen ones,
            // so correctness never depends on the clip being there.
            if (hasClip && (bottom < clipRect.top.toFloat() || top > clipRect.bottom.toFloat())) {
                continue
            }

            if (visibleFirst < 0) visibleFirst = i
            visibleLast = i

            dst.set(
                b.left.toFloat(),
                top,
                b.left + totalWidth * scaleX,
                // Half a pixel of overlap between neighbours. Bilinear
                // filtering at a fractional scale would otherwise leave a
                // hairline seam where two slices meet.
                if (i == tiles.sliceCount - 1) bottom else bottom + 0.5f,
            )

            val bmp = tiles.resident(i)
            if (bmp != null && !bmp.isRecycled) {
                canvas.drawBitmap(bmp, null, dst, paint)
                continue
            }

            // Not decoded yet: fill from the whole-strip preview so the reader
            // shows the page immediately, slightly soft, instead of a gap or a
            // spinner. The real slice replaces it a few milliseconds later.
            if (preview != null && !preview.isRecycled && totalHeight > 0) {
                val pTop = (sliceTop.toLong() * preview.height / totalHeight).toInt()
                val pBottom =
                    ((sliceTop + sliceHeight).toLong() * preview.height / totalHeight).toInt()
                if (pBottom > pTop) {
                    previewSrc.set(0, pTop, preview.width, pBottom)
                    canvas.drawBitmap(preview, previewSrc, dst, paint)
                }
            }

        }

        // Ask for everything on screen PLUS a slice either side. request()
        // ignores slices that are already resident or already being decoded, so
        // calling it every frame costs nothing -- and the read-ahead is what
        // stops a steady scroll from walking into the preview: the slice below
        // the fold is already decoding before it is reached.
        if (visibleFirst >= 0) {
            tiles.request(
                (visibleFirst - READ_AHEAD_SLICES).coerceAtLeast(0),
                (visibleLast + READ_AHEAD_SLICES).coerceAtMost(tiles.sliceCount - 1),
                onSliceReady,
            )
        }
    }

    override fun setAlpha(alpha: Int) {
        if (paint.alpha != alpha) {
            paint.alpha = alpha
            invalidateSelf()
        }
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
        invalidateSelf()
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    companion object {
        /**
         * How many slices beyond the viewport to decode ahead, in each
         * direction. One is enough to stay ahead of a fling at 60fps while
         * keeping resident memory close to what is actually on screen.
         */
        private const val READ_AHEAD_SLICES = 1

        /**
         * Slice height ceiling, in decoded pixels.
         *
         * 2048 is the smallest maximum texture size any device the app supports
         * reports, so a slice is guaranteed to be uploadable everywhere. Larger
         * slices would mean fewer draw calls, but a single slice that a device
         * cannot texture brings back the whole problem this class exists to fix.
         */
        const val MAX_SLICE_HEIGHT_PX = 2048
    }
}

/**
 * Slice decoding threads.
 *
 * Separate from the page decode pool on purpose: a slice is wanted by a frame
 * that is already on screen, so it must never queue behind a preloaded page's
 * full decode. Two threads, just below normal priority, so filling in the strip
 * cannot starve the UI thread drawing it.
 */
private val sliceDecodeExecutor by lazy {
    Executors.newFixedThreadPool(2) { runnable ->
        Thread(runnable, "manga-slice").apply {
            priority = (Thread.NORM_PRIORITY - 1).coerceAtLeast(Thread.MIN_PRIORITY)
        }
    }
}

private val mainHandler by lazy { Handler(Looper.getMainLooper()) }

/**
 * An open region decoder plus whatever has to stay open with it.
 *
 * When the page is decoded straight from its cache FILE, the stream must stay
 * open for the life of the decoder -- `BitmapRegionDecoder` keeps reading from
 * it -- and must be closed when the strip is released.
 */
class MangaRegionHandle internal constructor(
    internal val decoder: BitmapRegionDecoder,
    private val stream: java.io.Closeable?,
) {
    internal fun close() {
        try {
            decoder.recycle()
        } catch (t: Throwable) {
            // Nothing to do; the decoder is being discarded anyway.
        }
        try {
            stream?.close()
        } catch (t: Throwable) {
            // Same.
        }
    }
}

/**
 * One long-strip page, held as an open region decoder plus the slices that are
 * currently resident, so the same pixels can back several short-lived
 * [SlicedStripDrawable] instances.
 *
 * Build one with [MangaStripTiles.open]. Geometry (slice count, tops, heights)
 * is known from the source dimensions alone, so the drawable can lay the strip
 * out correctly before a single slice has been decoded.
 */
class MangaStripTiles private constructor(
    private var handle: MangaRegionHandle?,
    /**
     * The page's cache file. Preferred source for reopening the decoder, and
     * the reason a cached strip no longer pins its encoded bytes in memory.
     */
    private val file: java.io.File?,
    /** Only used when the page was NOT backed by a file on disk. */
    private val encoded: ByteArray?,
    private val sourceWidth: Int,
    private val sourceHeight: Int,
    private val sampleSize: Int,
    private val config: Bitmap.Config,
    /** Slice height in SOURCE pixels. */
    private val srcSliceHeight: Int,
    private val previewBitmap: Bitmap?,
    private val tops: IntArray,
    private val heights: IntArray,
    val decodedWidth: Int,
    val decodedHeight: Int,
    primed: Map<Int, Bitmap>,
) {

    private val lock = Any()

    /** Guards the native decoder, which is not documented as thread safe. */
    private val decodeLock = Any()

    private val slices = arrayOfNulls<Bitmap>(tops.size)
    private val inFlight = HashSet<Int>()

    private var windowStart = 0
    private var windowEnd = 0

    init {
        for ((index, bitmap) in primed) {
            if (index in slices.indices) slices[index] = bitmap
        }
        windowEnd = (primed.keys.maxOrNull() ?: 0)
    }

    val sliceCount: Int get() = tops.size

    fun sliceTop(index: Int): Int = tops.getOrElse(index) { 0 }

    fun sliceHeight(index: Int): Int = heights.getOrElse(index) { 0 }

    fun preview(): Bitmap? = previewBitmap

    fun resident(index: Int): Bitmap? = synchronized(lock) {
        slices.getOrNull(index)
    }

    /** Live pixel memory: the preview plus whatever slices are resident. */
    val byteCount: Long
        get() = synchronized(lock) {
            var total = previewBitmap?.allocationByteCount?.toLong() ?: 0L
            for (bitmap in slices) {
                if (bitmap != null && !bitmap.isRecycled) {
                    total += bitmap.allocationByteCount.toLong()
                }
            }
            total
        }

    /**
     * Asks for the slices between [first] and [last] inclusive. Returns
     * immediately; [onSliceReady] fires once per slice that lands. Slices
     * already resident or already being decoded are not requested twice, so
     * this is safe to call from every frame of a scroll.
     */
    fun request(first: Int, last: Int, onSliceReady: () -> Unit) {
        if (file == null && encoded == null && handle == null) return

        val todo = ArrayList<Int>()
        synchronized(lock) {
            windowStart = first
            windowEnd = last
            for (i in first..last) {
                if (i !in slices.indices) continue
                if (slices[i] != null) continue
                if (inFlight.add(i)) todo.add(i)
            }
        }
        if (todo.isEmpty()) return

        for (index in todo) {
            sliceDecodeExecutor.execute {
                val bitmap = decodeSlice(index)
                synchronized(lock) {
                    inFlight.remove(index)
                    if (bitmap != null) {
                        slices[index] = bitmap
                        evictLocked()
                    }
                }
                if (bitmap != null) onSliceReady()
            }
        }
    }

    private fun decodeSlice(index: Int): Bitmap? {
        val decoder = regionOrReopen() ?: return null
        val top = index.toLong() * srcSliceHeight
        if (top >= sourceHeight) return null
        val height = minOf(srcSliceHeight.toLong(), sourceHeight - top).toInt()
        if (height <= 0) return null

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = config
            inMutable = false
        }
        val rect = Rect(0, top.toInt(), sourceWidth, top.toInt() + height)
        return try {
            synchronized(decodeLock) {
                if (decoder.isRecycled) null else decoder.decodeRegion(rect, opts)
            }
        } catch (t: Throwable) {
            // Out of memory here means too many slices are resident. Drop the
            // ones outside the viewport and let the next frame ask again.
            if (t is OutOfMemoryError) {
                synchronized(lock) { dropDistantLocked(forceAll = false) }
            }
            null
        }
    }

    private fun regionOrReopen(): BitmapRegionDecoder? {
        synchronized(decodeLock) {
            val current = handle?.decoder
            if (current != null && !current.isRecycled) return current
            handle?.close()
            val reopened = openRegion(file, encoded)
            handle = reopened
            return reopened?.decoder
        }
    }

    /**
     * Keeps resident pixels under budget by dropping the slices furthest from
     * the viewport first. Slices inside the requested window are never dropped
     * -- those are the ones a frame is about to draw.
     */
    private fun evictLocked() {
        var live = byteCountLocked()
        if (live <= liveBudgetBytes) return
        while (live > liveBudgetBytes) {
            val victim = farthestResidentLocked() ?: break
            val bitmap = slices[victim] ?: break
            slices[victim] = null
            live -= bitmap.allocationByteCount.toLong()
        }
    }

    private fun dropDistantLocked(forceAll: Boolean) {
        for (i in slices.indices) {
            if (!forceAll && i in windowStart..windowEnd) continue
            slices[i] = null
        }
    }

    private fun byteCountLocked(): Long {
        var total = previewBitmap?.allocationByteCount?.toLong() ?: 0L
        for (bitmap in slices) {
            if (bitmap != null && !bitmap.isRecycled) {
                total += bitmap.allocationByteCount.toLong()
            }
        }
        return total
    }

    private fun farthestResidentLocked(): Int? {
        val center = (windowStart + windowEnd) / 2
        var best: Int? = null
        var bestDistance = -1
        for (i in slices.indices) {
            if (slices[i] == null) continue
            if (i in windowStart..windowEnd) continue
            val distance = abs(i - center)
            if (distance > bestDistance) {
                bestDistance = distance
                best = i
            }
        }
        return best
    }

    /**
     * A Drawable is stateful -- it carries bounds, alpha, a colour filter and a
     * single invalidation callback -- so each use gets its own wrapper over the
     * shared tiles rather than the same instance being handed out twice.
     */
    fun asDrawable(): SlicedStripDrawable = SlicedStripDrawable(this)

    /**
     * Releases the native decoder and lets the resident slices go.
     *
     * The bitmaps are dropped, NOT recycled: a drawable evicted from the cache
     * can still be mid-draw on the UI thread, and recycling underneath it would
     * crash. Dropping the references lets the collector take them once nothing
     * is drawing them.
     */
    fun release() {
        synchronized(lock) {
            for (i in slices.indices) slices[i] = null
        }
        synchronized(decodeLock) {
            handle?.close()
            handle = null
        }
    }

    companion object {

        /**
         * Resident pixel ceiling for ONE strip. Two or three full-width slices
         * -- everything a viewport can show plus a neighbour -- with the rest
         * re-decoded on demand from the open region decoder, which is far
         * cheaper than keeping a whole 60 MB strip alive.
         */
        private val liveBudgetBytes: Long by lazy {
            val heap = try {
                Runtime.getRuntime().maxMemory()
            } catch (t: Throwable) {
                0L
            }
            if (heap <= 0L) {
                16L * 1024 * 1024
            } else {
                (heap / 16L).coerceIn(12L * 1024 * 1024, 40L * 1024 * 1024)
            }
        }

        /**
         * Builds a lazy strip around an already-open region decoder.
         *
         * [primed] are the slices the decoder already produced (the top of the
         * page), so the very first frame draws real pixels rather than the
         * preview.
         */
        /**
         * Opens a region decoder for a page, preferring its cache FILE.
         *
         * Decoding from the file is the structural win: the strip no longer has
         * to read the whole encoded page into a ByteArray before the first
         * frame, and a cached strip no longer pins one or two megabytes of
         * encoded bytes per page for as long as it lives. The byte-array path
         * remains for sources that are not file backed.
         */
        @Suppress("DEPRECATION")
        fun openRegion(file: java.io.File?, encoded: ByteArray?): MangaRegionHandle? {
            if (file != null && file.exists() && file.length() > 0L) {
                var stream: java.io.FileInputStream? = null
                try {
                    val opened = java.io.FileInputStream(file)
                    stream = opened
                    val decoder = BitmapRegionDecoder.newInstance(opened, false)
                    if (decoder != null) return MangaRegionHandle(decoder, opened)
                } catch (t: Throwable) {
                    // Fall through to the byte-array path.
                }
                try {
                    stream?.close()
                } catch (t: Throwable) {
                    // Nothing to do.
                }
            }
            if (encoded != null) {
                try {
                    val decoder = BitmapRegionDecoder.newInstance(encoded, 0, encoded.size, false)
                    if (decoder != null) return MangaRegionHandle(decoder, null)
                } catch (t: Throwable) {
                    // No region decoding available for this page.
                }
            }
            return null
        }

        fun open(
            handle: MangaRegionHandle,
            file: java.io.File?,
            encoded: ByteArray?,
            sourceWidth: Int,
            sourceHeight: Int,
            sampleSize: Int,
            config: Bitmap.Config,
            sliceHeightPx: Int,
            preview: Bitmap?,
            primed: Map<Int, Bitmap>,
        ): MangaStripTiles? {
            if (sourceWidth <= 0 || sourceHeight <= 0 || sliceHeightPx <= 0) return null
            val sample = sampleSize.coerceAtLeast(1)
            val srcSliceHeight = (sliceHeightPx * sample).coerceAtLeast(1)

            val count = ((sourceHeight + srcSliceHeight - 1) / srcSliceHeight).coerceAtLeast(1)
            val tops = IntArray(count)
            val heights = IntArray(count)

            // Trust a real decoded slice for the exact decoded dimensions --
            // decodeRegion's own rounding is what the drawable has to match --
            // and fall back to the arithmetic when nothing was primed.
            val sampleSlice = primed[0]
            val fullSliceHeight = sampleSlice?.height
                ?: ((srcSliceHeight + sample - 1) / sample)
            val width = sampleSlice?.width ?: ((sourceWidth + sample - 1) / sample)

            var y = 0
            for (i in 0 until count) {
                tops[i] = y
                val srcTop = i.toLong() * srcSliceHeight
                val srcHeight = minOf(srcSliceHeight.toLong(), sourceHeight - srcTop).toInt()
                val decodedHeight = if (srcHeight >= srcSliceHeight) {
                    fullSliceHeight
                } else {
                    ((srcHeight + sample - 1) / sample)
                }
                heights[i] = decodedHeight.coerceAtLeast(0)
                y += heights[i]
            }

            if (width <= 0 || y <= 0) return null

            return MangaStripTiles(
                handle = handle,
                file = file,
                encoded = encoded,
                sourceWidth = sourceWidth,
                sourceHeight = sourceHeight,
                sampleSize = sample,
                config = config,
                srcSliceHeight = srcSliceHeight,
                previewBitmap = preview,
                tops = tops,
                heights = heights,
                decodedWidth = width,
                decodedHeight = y,
                primed = primed,
            )
        }
    }
}

/**
 * Small LRU of strips, keyed by page cache key.
 *
 * Coil's own memory cache can only hold `BitmapDrawable`s, so a tiled strip is
 * not eligible for it. Without a cache here, scrolling back up a chapter would
 * re-open and re-decode every strip from disk -- which is precisely when the
 * reader is busiest.
 *
 * Now that a strip is lazy, an entry is cheap: a preview plus at most
 * [MangaStripTiles.liveBudgetBytes] of resident slices, and an entry that is
 * not being drawn drops back to roughly its preview. That is what makes
 * preloading pages ahead worth doing -- the old eager strips were each larger
 * than this whole cache, so every preload evicted the page before it.
 */
object MangaStripCache {

    private val lock = Any()

    // Access-ordered, so the iterator yields least-recently-used first.
    private val entries = LinkedHashMap<String, MangaStripTiles>(8, 0.75f, true)

    private val maxBytes: Long by lazy {
        val heap = try {
            Runtime.getRuntime().maxMemory()
        } catch (t: Throwable) {
            0L
        }
        if (heap <= 0L) {
            MIN_CACHE_BYTES
        } else {
            (heap / 6L).coerceIn(MIN_CACHE_BYTES, MAX_CACHE_BYTES)
        }
    }

    fun get(key: String): MangaStripTiles? = synchronized(lock) { entries[key] }

    fun contains(key: String): Boolean = synchronized(lock) { entries.containsKey(key) }

    fun put(key: String, value: MangaStripTiles) {
        val released = ArrayList<MangaStripTiles>()
        synchronized(lock) {
            entries.remove(key)?.let { if (it !== value) released.add(it) }
            entries[key] = value

            // Resident bytes move as slices come and go, so the total is
            // recomputed rather than tracked incrementally.
            var total = liveBytesLocked()
            val iterator = entries.entries.iterator()
            while ((total > maxBytes || entries.size > MAX_ENTRIES) &&
                entries.size > 1 &&
                iterator.hasNext()
            ) {
                val entry = iterator.next()
                if (entry.key == key) continue
                total -= entry.value.byteCount
                released.add(entry.value)
                iterator.remove()
            }
        }
        // Released outside the lock: release() touches the native decoder.
        for (strip in released) strip.release()
    }

    private fun liveBytesLocked(): Long {
        var total = 0L
        for (strip in entries.values) total += strip.byteCount
        return total
    }

    /** Called when the system asks for memory back. */
    fun clear() {
        val released = synchronized(lock) {
            val all = entries.values.toList()
            entries.clear()
            all
        }
        for (strip in released) strip.release()
    }

    private const val MIN_CACHE_BYTES = 24L * 1024 * 1024
    private const val MAX_CACHE_BYTES = 96L * 1024 * 1024

    /** Enough for the page on screen plus a full preload window either side. */
    private const val MAX_ENTRIES = 10
}

/**
 * Per-viewer scroll bookkeeping that must NOT live in snapshot state.
 *
 * The webtoon viewer records the row it is anchored to, and the set of chapters
 * on screen, from flows that run while the list is moving. Holding those in
 * `mutableStateOf` meant every update published a snapshot write from the
 * scroll path, for values nothing in composition ever reads. Plain fields cost
 * nothing and are only ever touched from the main thread.
 */
internal class MangaWebtoonScrollState {
    var anchorKey: String? = null
    var anchorOffset: Int = 0
    var visibleChapterIds: Set<String> = emptySet()
}
