package com.lorelight.manga.transfer

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.lorelight.data.local.CoverStorage
import com.lorelight.data.local.NovelPreferences
import com.lorelight.data.model.Novel
import com.lorelight.data.model.encodeMangaChapterUrl
import com.lorelight.data.model.toJSONObject
import com.lorelight.data.model.toNovel
import com.lorelight.manga.download.MangaDownloadStore
import com.lorelight.service.EpubImportResult
import eu.kanade.tachiyomi.source.model.Page
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.absoluteValue

/** Standard CBZ transfer with optional Lorelight metadata that other readers ignore. */
object MangaCbzTransfer {
    private const val MANIFEST = "lorelight.json"
    private val imageExt = setOf("jpg", "jpeg", "png", "webp", "gif", "avif")

    fun looksLikeCbz(context: Context, uri: Uri): Boolean = try {
        context.contentResolver.openInputStream(uri)?.use { input ->
            var hasImage = false
            var isEpub = false
            ZipInputStream(input.buffered()).use { zip ->
                var entry = zip.nextEntry
                var checked = 0
                while (entry != null && checked++ < 500) {
                    val name = entry.name.lowercase()
                    if (name == "meta-inf/container.xml" || name == "mimetype") isEpub = true
                    if (!entry.isDirectory && name.substringAfterLast('.', "") in imageExt) hasImage = true
                    entry = zip.nextEntry
                }
            }
            hasImage && !isEpub
        } ?: false
    } catch (_: Throwable) { false }

    suspend fun export(context: Context, novel: Novel): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val sourceId = novel.pluginId?.removePrefix("manga:")?.toLongOrNull()
                ?: error("This title is not a manga")
            val downloaded = novel.chapterUrls.mapIndexedNotNull { index, encoded ->
                val raw = com.lorelight.data.model.decodeMangaChapterUrl(encoded)?.second ?: encoded
                val pages = MangaDownloadStore.pages(context, sourceId, raw)
                    ?.takeIf { list -> list.all { MangaDownloadStore.hasPage(context, sourceId, it) } }
                pages?.let { Triple(index, raw, it) }
            }
            if (downloaded.isEmpty()) error("Download at least one manga chapter before saving a CBZ")

            val safeName = novel.title.replace(Regex("[\\/:*?\"<>|]"), "_").trim().ifBlank { "Manga" }
            val fileName = "$safeName.cbz"
            openDownloadsOutput(context, fileName).use { rawOut ->
                ZipOutputStream(rawOut.buffered()).use { zip ->
                    val manifestChapters = JSONArray()
                    var pageTotal = 0
                    downloaded.forEachIndexed { exportChapterIndex, (novelIndex, rawUrl, pages) ->
                        val files = JSONArray()
                        pages.sortedBy { it.index }.forEachIndexed { pageOrder, page ->
                            val source = MangaDownloadStore.pageFile(context, sourceId, page)
                            val ext = extensionFor(source)
                            val entryName = "%04d-%06d.%s".format(exportChapterIndex + 1, pageOrder + 1, ext)
                            zip.putNextEntry(ZipEntry(entryName))
                            source.inputStream().use { it.copyTo(zip) }
                            zip.closeEntry()
                            files.put(entryName)
                            pageTotal++
                        }
                        manifestChapters.put(JSONObject()
                            .put("name", novel.chapters.getOrNull(novelIndex) ?: "Chapter ${novelIndex + 1}")
                            .put("number", novel.chapterNumbers.getOrNull(novelIndex)?.toDouble() ?: (novelIndex + 1).toDouble())
                            .put("files", files))
                    }
                    val portableNovel = novel.toJSONObject().apply {
                        put("chapters", JSONArray())
                        put("chapterUrls", JSONArray())
                        put("chapterNumbers", JSONArray())
                        put("coverImageBase64", JSONObject.NULL)
                    }
                    val manifest = JSONObject()
                        .put("format", "lorelight-cbz")
                        .put("formatVersion", 1)
                        .put("novel", portableNovel)
                        .put("chapters", manifestChapters)
                    putText(zip, MANIFEST, manifest.toString())
                    putText(zip, "ComicInfo.xml", comicInfo(novel, downloaded.size, pageTotal))
                    val cover = CoverStorage.coverFile(context, novel.id)
                    if (cover.exists() && cover.length() > 0) {
                        zip.putNextEntry(ZipEntry("cover.${extensionFor(cover)}"))
                        cover.inputStream().use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
            }
            fileName
        }
    }

    suspend fun import(context: Context, uri: Uri): EpubImportResult = withContext(Dispatchers.IO) {
        val temp = File(context.cacheDir, "cbz_import_${UUID.randomUUID()}.cbz")
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(temp).use { input.copyTo(it) }
            } ?: return@withContext EpubImportResult.Error("Could not open this CBZ file")
            if (temp.length() <= 0L) return@withContext EpubImportResult.Error("The CBZ file is empty")

            ZipFile(temp).use { zip ->
                val safeEntries = zip.entries().asSequence().filter { !it.isDirectory }.toList()
                if (safeEntries.any { unsafe(it.name) }) return@withContext EpubImportResult.Error("Unsafe CBZ paths were rejected")
                val images = safeEntries.filter { it.name.lowercase().substringAfterLast('.', "") in imageExt }
                    .filterNot { it.name.substringAfterLast('/').startsWith("cover.", true) }
                    .sortedBy { naturalKey(it.name) }
                if (images.isEmpty()) return@withContext EpubImportResult.Error("No readable manga pages were found in this CBZ")

                val embedded = zip.getEntry(MANIFEST)?.let { entry ->
                    runCatching { JSONObject(zip.getInputStream(entry).bufferedReader().use { it.readText() }) }.getOrNull()
                }?.takeIf { it.optString("format") == "lorelight-cbz" && it.optInt("formatVersion") == 1 }

                val baseNovel = embedded?.optJSONObject("novel")?.let { runCatching { it.toNovel() }.getOrNull() }
                val title = baseNovel?.title?.takeIf { it.isNotBlank() }
                    ?: temp.nameWithoutExtension.replace('_', ' ').ifBlank { "Imported Manga" }
                val author = baseNovel?.author ?: "Unknown Author"
                val existing = NovelPreferences.loadNovelsFromPrefs(context).toMutableList()
                val existingIndex = existing.indexOfFirst {
                    it.title.equals(title, true) && it.author.equals(author, true)
                }
                val novelId = existing.getOrNull(existingIndex)?.id ?: UUID.randomUUID().toString()
                val sourceId = -(novelId.hashCode().toLong().absoluteValue + 1L)

                val groups = chapterGroups(embedded, images.map { it.name })
                val chapterNames = mutableListOf<String>()
                val chapterUrls = mutableListOf<String>()
                val chapterNumbers = mutableListOf<Float>()
                groups.forEachIndexed { chapterIndex, group ->
                    val rawUrl = "cbz://$novelId/chapter/$chapterIndex"
                    val pages = group.files.mapIndexed { pageIndex, name ->
                        val entry = zip.getEntry(name) ?: error("Missing page $name")
                        val page = Page(pageIndex, "cbz://$novelId/$chapterIndex/$pageIndex", "cbz://$novelId/$chapterIndex/$pageIndex")
                        val part = File(context.cacheDir, "cbz_page_${UUID.randomUUID()}")
                        try {
                            zip.getInputStream(entry).use { input -> FileOutputStream(part).use { input.copyTo(it) } }
                            if (!MangaDownloadStore.savePage(context, sourceId, page, part)) error("Failed to store page ${pageIndex + 1}")
                        } finally { part.delete() }
                        page
                    }
                    MangaDownloadStore.writeManifest(context, sourceId, rawUrl, pages)
                    chapterNames += group.name
                    chapterNumbers += group.number
                    chapterUrls += encodeMangaChapterUrl(sourceId, rawUrl)
                }

                val imported = (baseNovel ?: Novel(
                    title = title,
                    currentChapter = chapterNames.first(),
                    lastReadTimestamp = 0L,
                    author = author
                )).copy(
                    id = novelId,
                    title = title,
                    author = author,
                    status = "Imported",
                    isOnline = false,
                    sourceUrl = null,
                    pluginId = "manga:$sourceId",
                    pluginNovelPath = null,
                    chapters = chapterNames,
                    chapterUrls = chapterUrls,
                    chapterNumbers = chapterNumbers,
                    totalChapters = chapterNames.size,
                    currentChapter = chapterNames.getOrElse(baseNovel?.currentChapterIndex ?: 0) { chapterNames.first() },
                    currentChapterIndex = (baseNovel?.currentChapterIndex ?: 0).coerceIn(0, chapterNames.lastIndex),
                    currentMangaPageIndex = baseNovel?.currentMangaPageIndex ?: 0,
                    coverImageBase64 = null,
                    dateModified = System.currentTimeMillis()
                )

                val coverEntry = safeEntries.firstOrNull { it.name.substringAfterLast('/').startsWith("cover.", true) }
                val finalNovel = if (coverEntry != null) {
                    val coverFile = CoverStorage.coverFile(context, novelId)
                    coverFile.parentFile?.mkdirs()
                    zip.getInputStream(coverEntry).use { input -> FileOutputStream(coverFile).use { input.copyTo(it) } }
                    imported.copy(coverImageBase64 = coverFile.absolutePath)
                } else imported

                if (existingIndex >= 0) existing[existingIndex] = finalNovel else existing.add(0, finalNovel)
                NovelPreferences.saveNovelsToPrefsSync(context, existing)
                EpubImportResult.Success(finalNovel, existingIndex < 0)
            }
        } catch (t: Throwable) {
            EpubImportResult.Error("Failed to import CBZ: ${t.localizedMessage ?: t.message ?: "invalid file"}")
        } finally { temp.delete() }
    }

    fun downloadedChapterCount(context: Context, novel: Novel): Int {
        val sourceId = novel.pluginId?.removePrefix("manga:")?.toLongOrNull() ?: return 0
        return novel.chapterUrls.count { encoded ->
            val raw = com.lorelight.data.model.decodeMangaChapterUrl(encoded)?.second ?: encoded
            MangaDownloadStore.isChapterDownloaded(context, sourceId, raw)
        }
    }

    private data class Group(val name: String, val number: Float, val files: List<String>)

    private fun chapterGroups(manifest: JSONObject?, imageNames: List<String>): List<Group> {
        val arr = manifest?.optJSONArray("chapters")
        if (arr != null && arr.length() > 0) {
            val groups = mutableListOf<Group>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val files = o.optJSONArray("files")?.let { a ->
                    (0 until a.length()).mapNotNull { j -> a.optString(j).takeIf { it in imageNames } }
                }.orEmpty()
                if (files.isNotEmpty()) groups += Group(o.optString("name", "Chapter ${i + 1}"), o.optDouble("number", (i + 1).toDouble()).toFloat(), files)
            }
            if (groups.isNotEmpty()) return groups
        }
        val byFolder = imageNames.groupBy { it.substringBeforeLast('/', "") }
        return if (byFolder.size > 1 && byFolder.keys.none { it.isEmpty() }) {
            byFolder.entries.sortedBy { naturalKey(it.key) }.mapIndexed { i, e -> Group(e.key.substringAfterLast('/').ifBlank { "Chapter ${i + 1}" }, (i + 1).toFloat(), e.value.sortedBy(::naturalKey)) }
        } else listOf(Group("Chapter 1", 1f, imageNames.sortedBy(::naturalKey)))
    }

    private fun openDownloadsOutput(context: Context, name: String): OutputStream {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/vnd.comicbook+zip")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Lorelight")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("Could not create the CBZ in Downloads")
            val stream = context.contentResolver.openOutputStream(uri) ?: error("Could not write the CBZ")
            return object : OutputStream() {
                override fun write(b: Int) = stream.write(b)
                override fun write(b: ByteArray, off: Int, len: Int) = stream.write(b, off, len)
                override fun flush() = stream.flush()
                override fun close() {
                    stream.close()
                    context.contentResolver.update(uri, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
                }
            }
        }
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        return FileOutputStream(File(dir, name))
    }

    private fun extensionFor(file: File): String = file.inputStream().use { input ->
        val b = ByteArray(12); val n = input.read(b)
        when {
            n >= 3 && b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte() -> "jpg"
            n >= 8 && b.sliceArray(0..7).contentEquals(byteArrayOf(0x89.toByte(),0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A)) -> "png"
            n >= 12 && String(b, 0, 4) == "RIFF" && String(b, 8, 4) == "WEBP" -> "webp"
            n >= 6 && String(b, 0, 3) == "GIF" -> "gif"
            else -> "jpg"
        }
    }

    private fun unsafe(name: String): Boolean = name.startsWith('/') || name.startsWith('\\') || name.split('/', '\\').any { it == ".." }
    private fun naturalKey(s: String) = s.lowercase().replace(Regex("(\\d+)")) { it.value.padStart(12, '0') }
    private fun putText(zip: ZipOutputStream, name: String, text: String) { zip.putNextEntry(ZipEntry(name)); zip.write(text.toByteArray()); zip.closeEntry() }
    private fun comicInfo(n: Novel, chapters: Int, pages: Int): String = """<?xml version="1.0" encoding="UTF-8"?><ComicInfo><Title>${xml(n.title)}</Title><Series>${xml(n.title)}</Series><Writer>${xml(n.author)}</Writer><Summary>${xml(n.description)}</Summary><Genre>${xml(n.genres.joinToString(", "))}</Genre><LanguageISO>${xml(n.language)}</LanguageISO><Manga>YesAndRightToLeft</Manga><PageCount>$pages</PageCount><Count>$chapters</Count></ComicInfo>"""
    private fun xml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")
}
