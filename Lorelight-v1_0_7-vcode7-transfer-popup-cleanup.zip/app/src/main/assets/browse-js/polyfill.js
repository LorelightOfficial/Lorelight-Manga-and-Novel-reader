(function(){
  var G = globalThis;
  function fmt(args){ return Array.prototype.map.call(args, function(a){
    if (a && typeof a === 'object'){ try { return JSON.stringify(a); } catch(e){ return String(a); } }
    return String(a);
  }).join(' '); }
  G.console = {
    log: function(){ __native.log(fmt(arguments)); },
    info: function(){ __native.log(fmt(arguments)); },
    debug: function(){ __native.log(fmt(arguments)); },
    warn: function(){ __native.log('[warn] ' + fmt(arguments)); },
    error: function(){ __native.log('[error] ' + fmt(arguments)); }
  };

  var timers = {}; var timerSeq = 1;
  G.setTimeout = function(fn, ms){ var id = timerSeq++; timers[id] = fn; __native.setTimeoutNative(id, ms||0); return id; };
  G.clearTimeout = function(id){ delete timers[id]; };
  G.setInterval = function(){ __native.log('[polyfill] setInterval not supported'); return 0; };
  G.clearInterval = function(){};
  G.__timeoutFire = function(id){ var fn = timers[id]; if (fn){ delete timers[id]; try { fn(); } catch(e){ __native.log('[setTimeout cb] ' + (e && e.stack || e)); } } };

  var B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  function b64encode(str){
    str=String(str); var out='', i=0;
    while(i<str.length){
      var c1=str.charCodeAt(i++), c2=i<str.length?str.charCodeAt(i++):NaN, c3=i<str.length?str.charCodeAt(i++):NaN;
      var e1=c1>>2, e2=((c1&3)<<4)|(isNaN(c2)?0:(c2>>4));
      var e3=isNaN(c2)?64:(((c2&15)<<2)|(isNaN(c3)?0:(c3>>6)));
      var e4=isNaN(c3)?64:(c3&63);
      out+=B64.charAt(e1)+B64.charAt(e2)+(e3===64?'=':B64.charAt(e3))+(e4===64?'=':B64.charAt(e4));
    }
    return out;
  }
  function b64decode(str){
    str=String(str).replace(/[^A-Za-z0-9+/=]/g,''); var out='', i=0;
    while(i<str.length){
      var e1=B64.indexOf(str.charAt(i++)), e2=B64.indexOf(str.charAt(i++));
      var c3ch=str.charAt(i++), c4ch=str.charAt(i++);
      var e3=c3ch==='='?-1:B64.indexOf(c3ch), e4=c4ch==='='?-1:B64.indexOf(c4ch);
      if(e1<0||e2<0) continue;
      out+=String.fromCharCode((e1<<2)|(e2>>4));
      if(e3>=0) out+=String.fromCharCode(((e2&15)<<4)|(e3>>2));
      if(e4>=0) out+=String.fromCharCode(((e3&3)<<6)|e4);
    }
    return out;
  }
  G.atob = function(s){ return b64decode(s); };
  G.btoa = function(s){ return b64encode(s); };

  function toUtf8(str){ return unescape(encodeURIComponent(String(str))); }
  function fromUtf8(bytes){ return decodeURIComponent(escape(bytes)); }

  G.TextEncoder = function(){};
  G.TextEncoder.prototype.encode = function(str){ var u=toUtf8(str); var a=new Uint8Array(u.length); for(var i=0;i<u.length;i++) a[i]=u.charCodeAt(i)&0xff; return a; };
  G.TextDecoder = function(label, options){ this.encoding=String(label||'utf-8').toLowerCase(); this.fatal=!!(options&&options.fatal); this.ignoreBOM=!!(options&&options.ignoreBOM); };
  G.TextDecoder.prototype.decode = function(bytes){
    var a = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes||[]);
    var bin=''; for(var i=0;i<a.length;i++) bin+=String.fromCharCode(a[i]);
    var b64=b64encode(bin);
    if(typeof __native.decodeBase64Text==='function'){
      var decoded=__native.decodeBase64Text(b64,this.encoding);
      if(typeof decoded==='string' && decoded.indexOf('!ERR:')!==0) return decoded;
      if(this.fatal) throw new TypeError(decoded);
    }
    if(this.encoding==='utf-8'||this.encoding==='utf8'||this.encoding==='unicode-1-1-utf-8') return fromUtf8(bin);
    return bin;
  };

  G.Buffer = {
    from: function(data, enc){
      enc = enc || 'utf8'; var bin;
      if (enc === 'base64') bin = b64decode(String(data));
      else if (enc === 'hex'){ bin=''; var s=String(data); for(var i=0;i<s.length;i+=2) bin+=String.fromCharCode(parseInt(s.substr(i,2),16)); }
      else bin = toUtf8(data);
      return {
        _bin: bin,
        toString: function(e){
          e = e || 'utf8';
          if (e === 'base64') return b64encode(this._bin);
          if (e === 'hex'){ var h=''; for(var i=0;i<this._bin.length;i++){ var v=this._bin.charCodeAt(i).toString(16); h+=(v.length<2?'0':'')+v; } return h; }
          return fromUtf8(this._bin);
        }
      };
    }
  };

  G.URLSearchParams = function(init, onChange){
    this._p = []; this._onChange = typeof onChange==='function'?onChange:null;
    if (typeof init === 'string'){
      init = init.replace(/^\?/, '');
      if (init){ var parts = init.split('&'); for (var i=0;i<parts.length;i++){ var kv=parts[i].split('='); this._p.push([decodeURIComponent((kv[0]||'').replace(/\+/g,' ')), decodeURIComponent((kv.slice(1).join('=')||'').replace(/\+/g,' '))]); } }
    } else if (init && typeof init === 'object'){
      for (var k in init){ if(init.hasOwnProperty(k)) this._p.push([k, String(init[k])]); }
    }
  };
  G.URLSearchParams.prototype._changed = function(){ if(this._onChange) this._onChange(this.toString()); };
  G.URLSearchParams.prototype.append = function(k,v){ this._p.push([String(k),String(v)]); this._changed(); };
  G.URLSearchParams.prototype.set = function(k,v){ this._p=this._p.filter(function(e){return e[0]!==String(k);}); this._p.push([String(k),String(v)]); this._changed(); };
  G.URLSearchParams.prototype.get = function(k){ for(var i=0;i<this._p.length;i++){ if(this._p[i][0]===k) return this._p[i][1]; } return null; };
  G.URLSearchParams.prototype.getAll = function(k){ var r=[]; for(var i=0;i<this._p.length;i++){ if(this._p[i][0]===k) r.push(this._p[i][1]); } return r; };
  G.URLSearchParams.prototype.has = function(k){ return this.get(k)!==null; };
  G.URLSearchParams.prototype.delete = function(k){ this._p = this._p.filter(function(e){ return e[0]!==String(k); }); this._changed(); };
  G.URLSearchParams.prototype.sort = function(){ this._p.sort(function(a,b){return a[0]<b[0]?-1:(a[0]>b[0]?1:0);}); this._changed(); };
  G.URLSearchParams.prototype.forEach = function(fn,thisArg){ this._p.slice().forEach(function(e){fn.call(thisArg,e[1],e[0],this);},this); };
  G.URLSearchParams.prototype.toString = function(){ return this._p.map(function(e){ return encodeURIComponent(e[0]).replace(/%20/g,'+')+'='+encodeURIComponent(e[1]).replace(/%20/g,'+'); }).join('&'); };
  G.URLSearchParams.prototype.toJSON = function(){ return { __lorelightUrlSearchParams:this.toString() }; };

  // FormData subset for plugin POST requests (string fields). Native bridge
  // converts this marker into a real multipart/form-data request.
  // Fetch Headers subset used by published plugin sources.
  G.Headers = function(init){ this._headers={}; if(init instanceof G.Headers){var self=this;init.forEach(function(v,k){self.append(k,v);});}else if(Array.isArray(init)){for(var i=0;i<init.length;i++)this.append(init[i][0],init[i][1]);}else if(init){for(var k in init)if(Object.prototype.hasOwnProperty.call(init,k))this.append(k,init[k]);} };
  G.Headers.prototype.append=function(k,v){k=String(k).toLowerCase();this._headers[k]=this._headers[k]===undefined?String(v):this._headers[k]+', '+String(v);};
  G.Headers.prototype.set=function(k,v){this._headers[String(k).toLowerCase()]=String(v);};
  G.Headers.prototype.get=function(k){var v=this._headers[String(k).toLowerCase()];return v===undefined?null:v;};
  G.Headers.prototype.has=function(k){return this.get(k)!==null;};
  G.Headers.prototype.delete=function(k){delete this._headers[String(k).toLowerCase()];};
  G.Headers.prototype.forEach=function(fn,thisArg){var self=this;Object.keys(this._headers).forEach(function(k){fn.call(thisArg,self._headers[k],k,self);});};
  G.Headers.prototype.toJSON=function(){var out={};for(var k in this._headers)out[k]=this._headers[k];return out;};

  G.FormData = function(){ this._entries=[]; };
  G.FormData.prototype.append = function(name,value){ this._entries.push([String(name), String(value == null ? '' : value)]); };
  G.FormData.prototype.set = function(name,value){ this.delete(name); this.append(name,value); };
  G.FormData.prototype.delete = function(name){ this._entries=this._entries.filter(function(e){return e[0]!==String(name);}); };
  G.FormData.prototype.get = function(name){ for(var i=0;i<this._entries.length;i++) if(this._entries[i][0]===String(name)) return this._entries[i][1]; return null; };
  G.FormData.prototype.getAll = function(name){ return this._entries.filter(function(e){return e[0]===String(name);}).map(function(e){return e[1];}); };
  G.FormData.prototype.has = function(name){ return this.get(name)!==null; };
  G.FormData.prototype.toJSON = function(){ return { __lorelightFormData:this._entries }; };


  // Minimal Blob/FileReader compatibility used by the active Madara multisource
  // template. Bytes are kept as Uint8Array so data URLs preserve binary data.
  G.Blob = function(parts, options){
    options = options || {}; var chunks = [], total = 0;
    (parts || []).forEach(function(part){
      var bytes;
      if (part && part._blobBytes) bytes = new Uint8Array(part._blobBytes);
      else if (part instanceof ArrayBuffer) bytes = new Uint8Array(part);
      else if (ArrayBuffer.isView(part)) bytes = new Uint8Array(part.buffer, part.byteOffset, part.byteLength);
      else { var encoded = toUtf8(String(part == null ? '' : part)); bytes = new Uint8Array(encoded.length); for(var i=0;i<encoded.length;i++) bytes[i]=encoded.charCodeAt(i)&255; }
      chunks.push(bytes); total += bytes.length;
    });
    var data = new Uint8Array(total), offset = 0;
    chunks.forEach(function(chunk){ data.set(chunk, offset); offset += chunk.length; });
    this._blobBytes = data; this.size = data.length; this.type = String(options.type || '').toLowerCase();
  };
  G.Blob.prototype.arrayBuffer = function(){ var copy=new Uint8Array(this._blobBytes); return Promise.resolve(copy.buffer); };
  G.Blob.prototype.text = function(){ var bin=''; for(var i=0;i<this._blobBytes.length;i++)bin+=String.fromCharCode(this._blobBytes[i]); return Promise.resolve(fromUtf8(bin)); };
  G.Blob.prototype.slice = function(start,end,type){ var a=this._blobBytes; var s=start==null?0:(start<0?Math.max(a.length+start,0):Math.min(start,a.length)); var e=end==null?a.length:(end<0?Math.max(a.length+end,0):Math.min(end,a.length)); return new G.Blob([a.slice(s,Math.max(s,e))],{type:type||this.type}); };

  G.FileReader = function(){ this.readyState=0; this.result=null; this.error=null; this.onload=null; this.onloadend=null; this.onerror=null; this.onabort=null; this.onloadstart=null; this._aborted=false; };
  G.FileReader.EMPTY=0; G.FileReader.LOADING=1; G.FileReader.DONE=2;
  G.FileReader.prototype._read = function(blob, mode, encoding){
    var self=this; if(this.readyState===1) throw new Error('InvalidStateError');
    this.readyState=1; this.result=null; this.error=null; this._aborted=false;
    if(typeof this.onloadstart==='function')this.onloadstart({type:'loadstart',target:this});
    var promise = blob && typeof blob.arrayBuffer==='function' ? blob.arrayBuffer() : Promise.resolve(new G.Blob([blob]).arrayBuffer());
    promise.then(function(buffer){
      if(self._aborted)return;
      var bytes=new Uint8Array(buffer), value;
      if(mode==='dataurl'){var bin='';for(var i=0;i<bytes.length;i++)bin+=String.fromCharCode(bytes[i]);value='data:'+(blob.type||'application/octet-stream')+';base64,'+b64encode(bin);}
      else if(mode==='arraybuffer'){value=bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength);}
      else {var bin2='';for(var j=0;j<bytes.length;j++)bin2+=String.fromCharCode(bytes[j]);value=new G.TextDecoder(encoding||'utf-8').decode(bytes);}
      self.result=value;self.readyState=2;
      if(typeof self.onload==='function')self.onload({type:'load',target:self});
      if(typeof self.onloadend==='function')self.onloadend({type:'loadend',target:self});
    }).catch(function(err){if(self._aborted)return;self.error=err;self.readyState=2;if(typeof self.onerror==='function')self.onerror({type:'error',target:self});if(typeof self.onloadend==='function')self.onloadend({type:'loadend',target:self});});
  };
  G.FileReader.prototype.readAsDataURL=function(blob){this._read(blob,'dataurl');};
  G.FileReader.prototype.readAsArrayBuffer=function(blob){this._read(blob,'arraybuffer');};
  G.FileReader.prototype.readAsText=function(blob,encoding){this._read(blob,'text',encoding);};
  G.FileReader.prototype.abort=function(){if(this.readyState!==1)return;this._aborted=true;this.readyState=2;this.result=null;if(typeof this.onabort==='function')this.onabort({type:'abort',target:this});if(typeof this.onloadend==='function')this.onloadend({type:'loadend',target:this});};

  // Minimal AbortController/AbortSignal support for plugin request timeouts.
  G.AbortController = function(){
    var listeners=[]; this.signal={aborted:false,reason:undefined,addEventListener:function(type,fn){if(type==='abort'&&typeof fn==='function')listeners.push(fn);},removeEventListener:function(type,fn){if(type==='abort')listeners=listeners.filter(function(x){return x!==fn;});}};
    this.abort=function(reason){if(this.signal.aborted)return;this.signal.aborted=true;this.signal.reason=reason;var ev={type:'abort',target:this.signal};listeners.slice().forEach(function(fn){try{fn(ev);}catch(e){}});if(typeof this.signal.onabort==='function')this.signal.onabort(ev);};
  };

  G.__fetchCallbacks = {};
  G.__fetchResolve = function(token, rawJson){ var cb = G.__fetchCallbacks[token]; if(!cb) return; delete G.__fetchCallbacks[token]; try { cb.resolve(JSON.parse(rawJson)); } catch(e){ cb.reject(e); } };
  G.__fetchReject = function(token, msg){ var cb = G.__fetchCallbacks[token]; if(!cb) return; delete G.__fetchCallbacks[token]; cb.reject(new Error(String(msg))); };

  G.window = G.window || G;
  G.global = G.global || G;
})();
