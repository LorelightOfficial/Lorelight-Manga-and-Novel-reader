// Bounded sequential pagination helper for the LNReader PagePlugin contract.
// Page 1 may already be present in parseNovel(). When it is absent, request
// page 1 as well; this matters for sources that expose only totalPages.
(function (G) {
  G.__lorelightLoadPluginPages = function (plugin, novelPath, initialChapters, totalPages) {
    var chapters = Array.isArray(initialChapters) ? initialChapters.slice() : [];
    var seen = Object.create(null);
    chapters.forEach(function (chapter) {
      if (chapter && chapter.path != null) seen[String(chapter.path)] = true;
    });

    var requestedTotal = Number(totalPages) || 1;
    if (requestedTotal > 200) {
      return Promise.reject(new Error('Chapter list exceeds the 200-page safety limit'));
    }
    var total = Math.max(1, Math.floor(requestedTotal));
    var firstPage = chapters.length === 0 ? 1 : 2;
    var chain = Promise.resolve();

    for (var page = firstPage; page <= total; page++) {
      (function (pageNo) {
        chain = chain.then(function () {
          // Defer invocation so both synchronous throws and rejected promises
          // flow through the same page-specific error handler below.
          return Promise.resolve()
            .then(function () { return plugin.parsePage(novelPath, String(pageNo)); })
            .then(function (pageResult) {
              var list = pageResult && Array.isArray(pageResult.chapters)
                ? pageResult.chapters : [];
              for (var i = 0; i < list.length; i++) {
                var chapter = list[i];
                if (!chapter || chapter.path == null) continue;
                var key = String(chapter.path);
                if (!seen[key]) {
                  seen[key] = true;
                  chapters.push(chapter);
                }
              }
              if (G.__native && typeof G.__native.cheerioDispose === 'function') {
                G.__native.cheerioDispose();
              }
            })
            .catch(function (error) {
              if (G.__native && typeof G.__native.cheerioDispose === 'function') {
                G.__native.cheerioDispose();
              }
              var message = error && error.message ? error.message : String(error);
              if ((error && error.name === 'AbortError') || /abort|cancel/i.test(message)) {
                throw error;
              }
              if (G.__native && typeof G.__native.log === 'function') {
                G.__native.log('[PagePlugin] page ' + pageNo + ' failed: ' + message);
              }
              // A partial chapter list must never masquerade as a complete
              // novel. Reject the whole parse so the details screen can show
              // a retryable error instead of silently losing later chapters.
              var pageError = new Error('Chapter list page ' + pageNo + ' failed: ' + message);
              pageError.name = 'PagePluginPageError';
              pageError.page = pageNo;
              throw pageError;
            });
        });
      })(page);
    }
    return chain.then(function () { return chapters; });
  };
})(globalThis);
