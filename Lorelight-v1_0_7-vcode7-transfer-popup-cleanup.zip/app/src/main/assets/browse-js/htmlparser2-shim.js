(function () {
  function toEvents(html) {
    try { return JSON.parse(__native.htmlparse(html == null ? '' : String(html))); }
    catch (e) { return []; }
  }

  // ---------- Streaming Parser (htmlparser2-compatible) ----------
  function Parser(handler, options) {
    this._cbs = handler || {};
    this._buffer = '';
    this._options = options || {};
    this._paused = false;
    this._endRequested = false;
    this._ended = false;
    this._events = null;
    this._eventIndex = 0;
  }
  Parser.prototype.write = function (chunk) {
    if (this._ended) throw new Error('Cannot write after parser.end()');
    if (chunk != null) this._buffer += String(chunk);
  };
  Parser.prototype.parseChunk = Parser.prototype.write;
  Parser.prototype._flush = function () {
    if (this._paused || this._ended) return;
    if (this._events) { this._dispatchEvents(); return; }
    if (!this._endRequested) return;
    var html = this._buffer; this._buffer = ''; this._endRequested = false;
    this.parseComplete(html);
  };
  Parser.prototype.end = function (chunk) {
    if (this._ended) return;
    if (chunk != null) this._buffer += String(chunk);
    this._endRequested = true;
    this._flush();
  };
  Parser.prototype.done = Parser.prototype.end;
  Parser.prototype.reset = function () { this._buffer = ''; this._paused = false; this._endRequested = false; this._ended = false; this._events = null; this._eventIndex = 0; };
  Parser.prototype.pause = function () { this._paused = true; };
  Parser.prototype.resume = function () { if (!this._paused) return; this._paused = false; this._flush(); };
  var VOID_ELEMENTS = { area: 1, base: 1, br: 1, col: 1, command: 1, embed: 1, hr: 1, img: 1, input: 1, keygen: 1, link: 1, meta: 1, param: 1, source: 1, track: 1, wbr: 1 };
  Parser.prototype.isVoidElement = function (name) { return !!VOID_ELEMENTS[String(name == null ? '' : name).toLowerCase()]; };
  Parser.prototype._dispatchEvents = function () {
    var h = this._cbs, evs = this._events || [];
    while (!this._paused && this._eventIndex < evs.length) {
      var e = evs[this._eventIndex++], k;
      if (e.t === 0) {
        if (h.onopentagname) h.onopentagname(e.n);
        if (h.onattribute) { for (k in e.a) { if (Object.prototype.hasOwnProperty.call(e.a, k)) h.onattribute(k, e.a[k], undefined); } }
        if (h.onopentag) h.onopentag(e.n, e.a || {}, this.isVoidElement(e.n));
      } else if (e.t === 1) {
        if (h.ontext) h.ontext(e.x == null ? '' : e.x);
      } else if (e.t === 2) {
        if (!this.isVoidElement(e.n) && h.onclosetag) h.onclosetag(e.n, false);
      } else if (e.t === 3) {
        if (h.oncomment) h.oncomment(e.x == null ? '' : e.x);
        if (h.oncommentend) h.oncommentend();
      } else if (e.t === 4) {
        if (h.onprocessinginstruction) h.onprocessinginstruction(e.n || '!doctype', e.x || '');
      }
    }
    if (!this._paused && this._events && this._eventIndex >= this._events.length) {
      this._events = null; this._eventIndex = 0; this._ended = true;
      if (h.onend) h.onend();
    }
  };
  Parser.prototype.parseComplete = function (html) {
    this._events = toEvents(html); this._eventIndex = 0; this._dispatchEvents();
  };


  // ---------- DomHandler (builds a tree, calls back) ----------
  function DomHandler(callback, options) {
    this._cb = (typeof callback === 'function') ? callback : null;
    this.dom = [];
    this.root = { type: 'root', name: 'root', children: this.dom, parent: null };
    this._stack = [];
  }
  DomHandler.prototype._add = function (node) {
    var parent = this._stack.length ? this._stack[this._stack.length - 1] : this.root;
    node.parent = parent;
    var sib = parent.children;
    if (sib.length) { var last = sib[sib.length - 1]; last.next = node; node.prev = last; }
    sib.push(node);
  };
  DomHandler.prototype.onopentag = function (name, attribs, isVoid) {
    var nm=String(name||'').toLowerCase(); var el = { type: nm==='script'?'script':(nm==='style'?'style':'tag'), name: nm, attribs: attribs || {}, children: [], parent: null, prev: null, next: null };
    this._add(el); if(!isVoid) this._stack.push(el);
  };
  DomHandler.prototype.ontext = function (text) {
    this._add({ type: 'text', data: text == null ? '' : text, children: [], parent: null, prev: null, next: null });
  };
  DomHandler.prototype.oncomment = function (data) {
    this._add({ type: 'comment', data: data == null ? '' : data, children: [], parent: null, prev: null, next: null });
  };
  DomHandler.prototype.onprocessinginstruction = function (name, data) {
    this._add({ type: 'directive', name: name || '!doctype', data: data || '', children: [], parent: null, prev: null, next: null });
  };
  DomHandler.prototype.onclosetag = function (name) {
    var target = String(name || '').toLowerCase();
    for (var i = this._stack.length - 1; i >= 0; i--) {
      if (this._stack[i].name === target) { this._stack.length = i; return; }
    }
    // htmlparser2 may emit a close callback for malformed input that has no
    // matching open node; do not corrupt the current tree in that case.
  };
  DomHandler.prototype.onend = function () { if (this._cb) this._cb(null, this.dom); };
  DomHandler.prototype.onerror = function (err) { if (this._cb) this._cb(err); };

  // ---------- parseDocument / parseDOM ----------
  function buildDom(html) {
    var dh = new DomHandler(null);
    var p = new Parser(dh);
    p.end(html);
    dh.root.children = dh.dom;
    return dh.root;
  }
  function parseDocument(html) { return buildDom(html); }
  function parseDOM(html) { return buildDom(html).children; }

  // ---------- DomUtils subset ----------
  function getChildren(n) { return (n && n.children) || []; }
  function getParent(n) { return n ? n.parent : null; }
  function getName(el) { return el ? el.name : undefined; }
  function getAttributeValue(el, name) { return (el && el.attribs) ? el.attribs[name] : undefined; }
  function hasAttrib(el, name) { return !!(el && el.attribs && Object.prototype.hasOwnProperty.call(el.attribs, name)); }
  function getText(node) {
    if (!node) return '';
    if (Array.isArray(node)) { var s = '', i; for (i = 0; i < node.length; i++) s += getText(node[i]); return s; }
    if (node.type === 'text') return node.data || '';
    if (node.type === 'comment') return '';
    return getText(node.children || []);
  }
  function find(test, nodes, recurse, limit) {
    var result = [];
    if (limit == null) limit = Infinity;
    (function walk(list) {
      for (var i = 0; i < list.length && result.length < limit; i++) {
        var n = list[i];
        if (test(n)) result.push(n);
        if (recurse && n.children && n.children.length) walk(n.children);
      }
    })(nodes);
    return result;
  }
  function asList(nodes) { return Array.isArray(nodes) ? nodes : getChildren(nodes); }
  function findAll(test, nodes) { return find(test, asList(nodes), true, Infinity); }
  function findOne(test, nodes, recurse) { var r = find(test, asList(nodes), recurse !== false, 1); return r.length ? r[0] : null; }
  function existsOne(test, nodes) { return !!findOne(test, nodes, true); }
  function getElementsByTagName(name, nodes, recurse, limit) {
    var nm = (name == null) ? null : String(name).toLowerCase();
    return find(function (n) { return (n.type === 'tag' || n.type === 'script' || n.type === 'style') && (nm == null || n.name === nm); }, asList(nodes), recurse !== false, limit == null ? Infinity : limit);
  }
  function getElementById(id, nodes, recurse) {
    return findOne(function (n) { return (n.type === 'tag' || n.type === 'script' || n.type === 'style') && n.attribs && n.attribs.id === id; }, nodes, recurse !== false);
  }

  var DomUtils = {
    getChildren: getChildren, getParent: getParent, getName: getName,
    getAttributeValue: getAttributeValue, hasAttrib: hasAttrib,
    getText: getText, textContent: getText, innerText: getText,
    find: findAll, findAll: findAll, findOne: findOne, existsOne: existsOne,
    getElements: findAll, getElementsByTagName: getElementsByTagName, getElementById: getElementById,
    getSiblings: function (n) { return (n && n.parent) ? n.parent.children : (n ? [n] : []); },
    nextElementSibling: function (n) { var c = n && n.next; while (c && c.type !== 'tag') c = c.next; return c || null; },
    prevElementSibling: function (n) { var c = n && n.prev; while (c && c.type !== 'tag') c = c.prev; return c || null; },
    isTag: function (n) { return !!n && (n.type === 'tag' || n.type === 'script' || n.type === 'style'); }
  };

  var VOID = { area:1,base:1,br:1,col:1,embed:1,hr:1,img:1,input:1,link:1,meta:1,param:1,source:1,track:1,wbr:1 };
  function escapeText(s){return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
  function escapeAttr(s){return escapeText(s).replace(/\"/g,'&quot;');}
  function serialize(node){
    if(!node)return '';
    if(Array.isArray(node)){var all='';for(var i=0;i<node.length;i++)all+=serialize(node[i]);return all;}
    if(node.type==='text'){
      var parent=node.parent&&node.parent.name;
      return parent==='script'||parent==='style'?(node.data||''):escapeText(node.data||'');
    }
    if(node.type==='comment')return '<!--'+(node.data||'')+'-->';
    if(node.type==='root')return serialize(node.children||[]);
    if(node.type==='directive'||node.type==='doctype')return '<'+(node.data||node.name||'')+'>';
    var name=String(node.name||'').toLowerCase(), attrs=node.attribs||{}, out='<'+name;
    Object.keys(attrs).forEach(function(k){out+=' '+k+'=\"'+escapeAttr(attrs[k])+'\"';});
    out+='>';
    if(VOID[name])return out;
    out+=serialize(node.children||[]);
    return out+'</'+name+'>';
  }

  var ElementType = { Root: 'root', Text: 'text', Directive: 'directive', Comment: 'comment', Script: 'script', Style: 'style', Tag: 'tag', CDATA: 'cdata', Doctype: 'doctype' };

  var api = {
    Parser: Parser, DomHandler: DomHandler, DefaultHandler: DomHandler,
    parseDocument: parseDocument, parseDOM: parseDOM,
    DomUtils: DomUtils, ElementType: ElementType,
    getOuterHTML: function (node) { return serialize(node); },
    getInnerHTML: function (node) { var children=getChildren(node), out=''; for(var i=0;i<children.length;i++) out+=serialize(children[i]); return out; }
  };
  api.default = api;

  // Register so require('htmlparser2') resolves here. Use the SAME registration
  // call the other modules in libs-shims.js use (this project uses __registerModule):
  __registerModule('htmlparser2', api);
})();
