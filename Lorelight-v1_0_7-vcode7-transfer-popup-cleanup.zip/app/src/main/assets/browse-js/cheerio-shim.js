__registerModule('cheerio', function(module, exports, require){
  var N = __native;
  function parseHandleArray(json){ try { return JSON.parse(json) || []; } catch(e){ return []; } }

  function CheerioSet(handles, prev){ this._h = handles || []; this._prev = prev || null; this.length = this._h.length; }

  function rawMake(handles, prev){ return new CheerioSet(handles, prev); }
  function nodeRef(handle, shallow){
    if (handle == null || handle < 0) return null;
    var info = {};
    try { info = JSON.parse(N.cheerioNodeInfo(handle) || '{}'); } catch(e) {}
    var ref = {
      _lHandle: handle,
      type: info.type || 'tag',
      name: info.name || '',
      tagName: info.tagName || (info.name || '').toUpperCase(),
      nodeType: info.nodeType || 1,
      attribs: info.attribs || {},
      data: info.data == null ? undefined : info.data,
      parent: null,
      children: [],
      prev: null,
      next: null,
      prevSibling: null,
      nextSibling: null
    };
    // Callback arguments in Cheerio are DOM nodes, not internal numeric
    // handles. Supply a shallow DOM relationship graph; shallow references
    // avoid recursively expanding the entire document tree on each callback.
    if (!shallow) {
      var parent = N.cheerioParent(handle);
      if (parent >= 0) ref.parent = nodeRef(parent, true);
      var children = parseHandleArray(N.cheerioContents(handle));
      ref.children = children.map(function(child){ return nodeRef(child, true); });
      var prev = N.cheerioPrevNode(handle), next = N.cheerioNextNode(handle);
      ref.prev = ref.prevSibling = prev >= 0 ? nodeRef(prev, true) : null;
      ref.next = ref.nextSibling = next >= 0 ? nodeRef(next, true) : null;
    }
    return ref;
  }
  function callbackNode(handle){ return nodeRef(handle); }
  // make() is reassigned below to wrap results in a Proxy that traps unknown methods.
  var make = rawMake;

  CheerioSet.prototype.find = function(sel){ var o=[]; for(var i=0;i<this._h.length;i++){ o=o.concat(parseHandleArray(N.cheerioSelect(this._h[i], sel))); } return make(o, this); };
  CheerioSet.prototype.children = function(sel){ var o=[]; for(var i=0;i<this._h.length;i++){ if(sel) o=o.concat(parseHandleArray(N.cheerioChildrenSelector(this._h[i], sel))); else o=o.concat(parseHandleArray(N.cheerioChildren(this._h[i]))); } return make(o, this); };
  CheerioSet.prototype.filter = function(arg){
    if(typeof arg==='function'){ var filtered=[]; for(var i=0;i<this._h.length;i++){ var node=callbackNode(this._h[i]); if(arg.call(node, i, node)) filtered.push(this._h[i]); } return make(filtered, this); }
    return make(parseHandleArray(N.cheerioFilter(JSON.stringify(this._h), String(arg), false)), this);
  };
  CheerioSet.prototype.not = function(sel){ return make(parseHandleArray(N.cheerioFilter(JSON.stringify(this._h), String(sel), true)), this); };
  CheerioSet.prototype.first = function(){ return make(this._h.slice(0,1), this); };
  CheerioSet.prototype.last = function(){ return make(this._h.slice(-1), this); };
  CheerioSet.prototype.eq = function(i){ if(i<0) i=this._h.length+i; return make(this._h[i]!=null?[this._h[i]]:[], this); };
  CheerioSet.prototype.get = function(i){ if(i===undefined) return this._h.map(callbackNode); var h=this._h[i<0?this._h.length+i:i]; return h==null?undefined:callbackNode(h); };
  CheerioSet.prototype.toArray = function(){ return this._h.map(callbackNode); };
  CheerioSet.prototype.each = function(fn){ for(var i=0;i<this._h.length;i++){ var node=callbackNode(this._h[i]); if(fn.call(node, i, node)===false) break; } return this; };
  CheerioSet.prototype.map = function(fn){
    var out=[]; for(var i=0;i<this._h.length;i++){ var node=callbackNode(this._h[i]); out.push(fn.call(node, i, node)); }
    return {
      length: out.length,
      get: function(index){ if(index===undefined) return out.slice(); return out[index<0?out.length+index:index]; },
      toArray: function(){ return out.slice(); },
      each: function(callback){ for(var j=0;j<out.length;j++){ if(callback.call(out[j],j,out[j])===false) break; } return this; },
      first: function(){ return out.length?out[0]:undefined; },
      last: function(){ return out.length?out[out.length-1]:undefined; },
      join: function(separator){ return out.join(separator); }
    };
  };
  CheerioSet.prototype.text = function(){ var s=''; for(var i=0;i<this._h.length;i++){ s += N.cheerioText(this._h[i]); } return s; };
  CheerioSet.prototype.html = function(){ if(this._h.length===0) return null; return N.cheerioHtml(this._h[0]); };
  CheerioSet.prototype.attr = function(name, val){ if(name===undefined){ if(this._h.length===0) return undefined; try{return JSON.parse(N.cheerioAttributes(this._h[0])||'{}');}catch(e){return {};}} if(val!==undefined){ for(var i=0;i<this._h.length;i++) N.cheerioSetAttr(this._h[i], name, String(val)); return this; } if(this._h.length===0) return undefined; var r=N.cheerioAttr(this._h[0], name); return r===null?undefined:r; };
  CheerioSet.prototype.prop = function(name){ if(this._h.length===0) return undefined; var r=N.cheerioProp(this._h[0], name); return r===null?undefined:r; };
  CheerioSet.prototype.data = function(key){ if(this._h.length===0) return undefined; var r=N.cheerioData(this._h[0], key); return r===null?undefined:r; };
  CheerioSet.prototype.val = function(){ if(this._h.length===0) return undefined; return N.cheerioVal(this._h[0]); };
  CheerioSet.prototype.hasClass = function(c){ for(var i=0;i<this._h.length;i++){ if(N.cheerioHasClass(this._h[i], c)) return true; } return false; };
  CheerioSet.prototype.addClass = function(c){ for(var i=0;i<this._h.length;i++) N.cheerioAddClass(this._h[i], c); return this; };
  CheerioSet.prototype.removeClass = function(c){ for(var i=0;i<this._h.length;i++) N.cheerioRemoveClass(this._h[i], c); return this; };
  CheerioSet.prototype.removeAttr = function(name){ var names=String(name||'').split(/\s+/).filter(Boolean); for(var i=0;i<this._h.length;i++) for(var j=0;j<names.length;j++) N.cheerioRemoveAttr(this._h[i], names[j]); return this; };
  CheerioSet.prototype.clone = function(){ var out=[]; for(var i=0;i<this._h.length;i++){ var h=N.cheerioClone(this._h[i]); if(h>=0) out.push(h); } return make(out,this); };
  CheerioSet.prototype.wrap = function(html){ for(var i=0;i<this._h.length;i++) N.cheerioWrap(this._h[i], String(html)); return this; };
  CheerioSet.prototype.nextUntil = function(sel){ var out=[]; for(var i=0;i<this._h.length;i++) out=out.concat(parseHandleArray(N.cheerioNextUntil(this._h[i], sel==null?'':String(sel)))); return make(out,this); };
  CheerioSet.prototype.has = function(sel){ var out=[]; for(var i=0;i<this._h.length;i++) if(N.cheerioHas(this._h[i], String(sel))) out.push(this._h[i]); return make(out,this); };
  CheerioSet.prototype.index = function(){ if(this._h.length===0) return -1; return N.cheerioIndex(this._h[0]); };
  CheerioSet.prototype.remove = function(){ for(var i=0;i<this._h.length;i++) N.cheerioRemove(this._h[i]); return this; };
  CheerioSet.prototype.parent = function(){ var o=[]; for(var i=0;i<this._h.length;i++){ var p=N.cheerioParent(this._h[i]); if(p>=0) o.push(p); } return make(o, this); };
  CheerioSet.prototype.parents = function(){ var o=[]; for(var i=0;i<this._h.length;i++){ o=o.concat(parseHandleArray(N.cheerioParents(this._h[i]))); } return make(o, this); };
  CheerioSet.prototype.closest = function(sel){ var o=[]; for(var i=0;i<this._h.length;i++){ var c=N.cheerioClosest(this._h[i], sel); if(c>=0) o.push(c); } return make(o, this); };
  CheerioSet.prototype.next = function(){ var o=[]; for(var i=0;i<this._h.length;i++){ var n=N.cheerioNext(this._h[i]); if(n>=0) o.push(n); } return make(o, this); };
  CheerioSet.prototype.nextAll = function(){ var o=[]; for(var i=0;i<this._h.length;i++){ o=o.concat(parseHandleArray(N.cheerioNextAll(this._h[i]))); } return make(o, this); };
  CheerioSet.prototype.prev = function(){ var o=[]; for(var i=0;i<this._h.length;i++){ var n=N.cheerioPrev(this._h[i]); if(n>=0) o.push(n); } return make(o, this); };
  CheerioSet.prototype.prevAll = function(){ var o=[]; for(var i=0;i<this._h.length;i++){ o=o.concat(parseHandleArray(N.cheerioPrevAll(this._h[i]))); } return make(o, this); };
  CheerioSet.prototype.siblings = function(){ var o=[]; for(var i=0;i<this._h.length;i++){ o=o.concat(parseHandleArray(N.cheerioSiblings(this._h[i]))); } return make(o, this); };
  CheerioSet.prototype.contents = function(){ var o=[]; for(var i=0;i<this._h.length;i++){ o=o.concat(parseHandleArray(N.cheerioContents(this._h[i]))); } return make(o, this); };
  CheerioSet.prototype.is = function(sel){ return parseHandleArray(N.cheerioFilter(JSON.stringify(this._h), String(sel), false)).length > 0; };
  CheerioSet.prototype.end = function(){ return this._prev || make([]); };
  CheerioSet.prototype.add = function(other){ var h=this._h.slice(); if(other && other._h) h=h.concat(other._h); else if (typeof other==='number') h.push(other); return make(h, this); };
  CheerioSet.prototype.addBack = function(sel){ var h=this._h.slice(); if(this._prev && this._prev._h){ for(var i=0;i<this._prev._h.length;i++){ var handle=this._prev._h[i]; if((!sel || N.cheerioIs(handle, sel)) && h.indexOf(handle)===-1) h.push(handle); } } return make(h, this); };
  CheerioSet.prototype.andSelf = function(sel){ return this.addBack(sel); };
  CheerioSet.prototype.slice = function(start, end){ return make(this._h.slice(start, end), this); };
  CheerioSet.prototype.replaceWith = function(html){ for(var i=0;i<this._h.length;i++) N.cheerioReplaceWith(this._h[i], String(html)); return this; };
  CheerioSet.prototype.before = function(html){ for(var i=0;i<this._h.length;i++) N.cheerioBefore(this._h[i], String(html)); return this; };
  CheerioSet.prototype.after = function(html){ for(var i=0;i<this._h.length;i++) N.cheerioAfter(this._h[i], String(html)); return this; };
  CheerioSet.prototype.append = function(html){ for(var i=0;i<this._h.length;i++) N.cheerioAppend(this._h[i], String(html)); return this; };
  CheerioSet.prototype.prepend = function(html){ for(var i=0;i<this._h.length;i++) N.cheerioPrepend(this._h[i], String(html)); return this; };
  CheerioSet.prototype.empty = function(){ for(var i=0;i<this._h.length;i++) N.cheerioEmpty(this._h[i]); return this; };
  CheerioSet.prototype.css = function(prop){ if(this._h.length===0) return undefined; return N.cheerioCss(this._h[0], prop); };

  // MANDATORY: Proxy trap logs and throws on unimplemented method access (drives Gate 2/3 debugging).
  make = function(handles, prev){
    var target = new CheerioSet(handles, prev);
    return new Proxy(target, {
      get: function(t, prop){
        if (typeof prop === 'symbol') return t[prop];
        // Not-thenable / not-serializable guards so accidental await/stringify don't throw.
        if (prop === 'then' || prop === 'catch' || prop === 'finally' || prop === 'toJSON') return undefined;
        if (prop in t) return t[prop];
        if (prop === 'length') return t._h.length;
        if (typeof prop === 'string' && /^[0-9]+$/.test(prop)) return t._h[parseInt(prop, 10)];
        __native.log("[cheerio-shim] unimplemented: " + String(prop));
        throw new Error("[cheerio-shim] unimplemented: " + String(prop));
      }
    });
  };

  module.exports = {
    load: function(html, options, isDocument){
      var docHandle = N.cheerioParse(String(html == null ? '' : html));
      var $ = function(selector, context){
        if (selector == null) return make([]);
        if (selector instanceof CheerioSet) return make(selector._h);
        if (typeof selector === 'number') return make([selector]);
        if (typeof selector === 'object'){ if (selector._lHandle != null) return make([selector._lHandle]); if (selector._h) return make(selector._h); return make([]); }
        var ctxHandle = docHandle;
        if (context != null){ if (typeof context === 'number') ctxHandle = context; else if (context._h && context._h.length) ctxHandle = context._h[0]; }
        return make(parseHandleArray(N.cheerioSelect(ctxHandle, String(selector))));
      };
      $.html = function(sel){ if (sel === undefined) return N.cheerioHtml(docHandle); if (sel instanceof CheerioSet) return sel.html(); return $(sel).html(); };
      $.text = function(){ return N.cheerioText(docHandle); };
      $.root = function(){ return make([docHandle]); };
      $._docHandle = docHandle;
      return $;
    }
  };
});
