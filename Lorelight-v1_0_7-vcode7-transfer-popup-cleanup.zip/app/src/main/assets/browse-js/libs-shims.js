// Pure-JS module registrations mirroring LNReader's @libs/* (VERIFIED strings) + htmlparser2 stub.

__registerModule('@libs/filterInputs', function(module){
  module.exports = { FilterTypes: {
    TextInput: 'Text',
    Picker: 'Picker',
    CheckboxGroup: 'Checkbox',
    Switch: 'Switch',
    ExcludableCheckboxGroup: 'XCheckbox'
  } };
});

__registerModule('@libs/novelStatus', function(module){
  module.exports = { NovelStatus: {
    Unknown: 'Unknown',
    Ongoing: 'Ongoing',
    Completed: 'Completed',
    Licensed: 'Licensed',
    PublishingFinished: 'Publishing Finished',
    Cancelled: 'Cancelled',
    OnHiatus: 'On Hiatus'
  } };
});

__registerModule('@libs/defaultCover', function(module){
  module.exports = { defaultCover: 'https://github.com/LNReader/lnreader-plugins/blob/main/icons/src/coverNotAvailable.jpg?raw=true' };
});

__registerModule('@libs/isAbsoluteUrl', function(module){
  module.exports = { isUrlAbsolute: function(u){ return /^(?:[a-z+]+:)?\/\//i.test(String(u)); } };
});

function __lorelightRawFetch(url, init){
  return new Promise(function(resolve, reject){
    init=init||{};
    var token=++globalThis.__lorelightFetchToken, signal=init.signal, settled=false;
    var startedAt=Date.now();
    function cleanup(){if(signal&&signal.removeEventListener)signal.removeEventListener('abort',onAbort);}
    function finish(fn,value){if(settled)return;settled=true;cleanup();fn(value);}
    function logAbort(stage){
      try{
        var rawUrl=String(url), host=(rawUrl.match(/^https?:\/\/[^/]+/i)||['unknown-host'])[0];
        var reason=(signal&&signal.reason!==undefined&&signal.reason!==null)?String(signal.reason):'unspecified';
        __native.log('[fetch-abort] host='+host+' token='+token+' elapsedMs='+(Date.now()-startedAt)+' stage='+stage+' reason='+reason);
      }catch(e){}
    }
    function abortError(){var reason=(signal&&signal.reason!==undefined&&signal.reason!==null&&String(signal.reason).length)?String(signal.reason):'';var message='The operation was aborted'+(reason?': '+reason:'');var error=new Error(message);error.name='AbortError';return error;}
    function onAbort(){logAbort('signal-event');delete globalThis.__fetchCallbacks[token];try{if(__native.cancelFetch)__native.cancelFetch(token);}catch(e){}finish(reject,abortError());}
    if(signal&&signal.aborted){logAbort('already-aborted');reject(abortError());return;}
    globalThis.__fetchCallbacks[token]={resolve:function(v){finish(resolve,v);},reject:function(e){finish(reject,e);}};
    if(signal&&signal.addEventListener)signal.addEventListener('abort',onAbort);
    try {
      var cleanInit={};for(var k in init)if(k!=='signal'&&Object.prototype.hasOwnProperty.call(init,k))cleanInit[k]=init[k];
      // Mirror LNReader's fetch helper defaults. Preserve every source-supplied
      // header (case-insensitively) while supplying the common browser headers
      // that many novel hosts expect when a source does not specify them.
      var suppliedHeaders=cleanInit.headers;
      if(suppliedHeaders instanceof Headers)suppliedHeaders=suppliedHeaders.toJSON();
      var mergedHeaders={};
      if(Array.isArray(suppliedHeaders)){
        for(var hi=0;hi<suppliedHeaders.length;hi++){
          if(suppliedHeaders[hi]&&suppliedHeaders[hi].length>=2)mergedHeaders[String(suppliedHeaders[hi][0])]=String(suppliedHeaders[hi][1]);
        }
      }else if(suppliedHeaders&&typeof suppliedHeaders==='object'){
        for(var hk in suppliedHeaders)if(Object.prototype.hasOwnProperty.call(suppliedHeaders,hk))mergedHeaders[hk]=String(suppliedHeaders[hk]);
      }
      function hasHeader(name){for(var existing in mergedHeaders)if(existing.toLowerCase()===name.toLowerCase())return true;return false;}
      var defaults={'Accept':'*/*','Accept-Language':'*','Sec-Fetch-Mode':'cors','Cache-Control':'max-age=0'};
      for(var dh in defaults)if(!hasHeader(dh))mergedHeaders[dh]=defaults[dh];
      cleanInit.headers=mergedHeaders;
      var body=cleanInit.body;
      if(typeof ArrayBuffer!=='undefined' && body instanceof ArrayBuffer){var bv=new Uint8Array(body);var bin='';for(var bi=0;bi<bv.length;bi++)bin+=String.fromCharCode(bv[bi]);cleanInit.body={__lorelightBinaryBody:btoa(bin)};}
      else if(typeof ArrayBuffer!=='undefined' && ArrayBuffer.isView && ArrayBuffer.isView(body)){var bv2=new Uint8Array(body.buffer,body.byteOffset,body.byteLength);var bin2='';for(var bj=0;bj<bv2.length;bj++)bin2+=String.fromCharCode(bv2[bj]);cleanInit.body={__lorelightBinaryBody:btoa(bin2)};}
      else if(body && body._bin!==undefined){cleanInit.body={__lorelightBinaryBody:btoa(body._bin)};}
      __native.fetch(String(url),JSON.stringify(cleanInit),token);
    }
    catch(e){delete globalThis.__fetchCallbacks[token];finish(reject,e);}
  });
}
globalThis.__lorelightFetchToken = globalThis.__lorelightFetchToken || 0;
function __lorelightDecodeBase64(value){
  var binary=atob(value || ''), out=new Uint8Array(binary.length);
  for(var i=0;i<binary.length;i++) out[i]=binary.charCodeAt(i)&255;
  return out;
}
function __lorelightResponse(raw){
  var headers=raw.headers||{}, lower={};
  for(var k in headers) if(Object.prototype.hasOwnProperty.call(headers,k)) lower[k.toLowerCase()]=headers[k];
  var response={
    ok:raw.status>=200 && raw.status<300, status:raw.status, statusText:raw.statusText||'',
    url:raw.url||'', redirected:!!raw.redirected, type:'basic', bodyUsed:false,
    headers:{
      get:function(name){var v=lower[String(name).toLowerCase()];return v===undefined?null:v;},
      has:function(name){return lower[String(name).toLowerCase()]!==undefined;},
      forEach:function(fn){for(var k in lower) fn(lower[k],k);},
      entries:function(){return Object.keys(lower).map(function(k){return [k,lower[k]];});},
      keys:function(){return Object.keys(lower);}, values:function(){return Object.keys(lower).map(function(k){return lower[k];});}
    },
    text:function(){response.bodyUsed=true;return Promise.resolve(raw.body||'');},
    json:function(){response.bodyUsed=true;return Promise.resolve(JSON.parse(raw.body||''));},
    arrayBuffer:function(){response.bodyUsed=true;var a=__lorelightDecodeBase64(raw.bodyBase64||btoa(raw.body||''));return Promise.resolve(a.buffer.slice(a.byteOffset,a.byteOffset+a.byteLength));},
    blob:function(){response.bodyUsed=true;var a=__lorelightDecodeBase64(raw.bodyBase64||btoa(raw.body||''));return Promise.resolve(new Blob([a],{type:lower['content-type']||''}));},
    clone:function(){return __lorelightResponse(raw);}
  };
  return response;
}
globalThis.fetch = function(url, init){ return __lorelightRawFetch(url,init).then(__lorelightResponse); };

__registerModule('@libs/fetch', function(module){
  function fetchApi(url, init){ return __lorelightRawFetch(url, init).then(__lorelightResponse); }
  function fetchText(url, init, encoding){ return __lorelightRawFetch(url, init).then(function(r){
    if(r.status<200 || r.status>=300) return '';
    if(encoding && typeof __native.decodeBase64Text==='function') return __native.decodeBase64Text(r.bodyBase64||'', String(encoding));
    return r.body;
  }).catch(function(){ return ''; }); }
  function fetchFile(url, init){ return __lorelightRawFetch(url, init).then(function(r){
    if(r.status<200 || r.status>=300) return '';
    return r.bodyBase64 || '';
  }).catch(function(){ return ''; }); }
  function fetchProto(protoInit, url, init){
    return Promise.resolve().then(function(){
      if(!protoInit || typeof protoInit.proto !== 'string' || !protoInit.proto.trim()) throw new TypeError('fetchProto requires protoInit.proto schema text');
      if(!protoInit.requestType || !protoInit.responseType) throw new TypeError('fetchProto requires requestType and responseType');
      if(typeof LorelightProto === 'undefined' || !LorelightProto.parse) throw new Error('The bundled Protocol Buffers runtime is unavailable');
      var root = LorelightProto.parse(protoInit.proto);
      var RequestType = root.lookupType(protoInit.requestType);
      var ResponseType = root.lookupType(protoInit.responseType);
      var requestData = protoInit.requestData == null ? {} : protoInit.requestData;
      var requestBytes = LorelightProto.encode(RequestType, requestData, root);
      var requestInit = {};
      if(init && typeof init === 'object') for(var k in init) if(Object.prototype.hasOwnProperty.call(init,k)) requestInit[k]=init[k];
      var headers = {};
      var supplied = requestInit.headers;
      if(supplied && typeof supplied.forEach === 'function') supplied.forEach(function(v,k){headers[k]=v;});
      else if(Array.isArray(supplied)) supplied.forEach(function(pair){if(pair&&pair.length>1)headers[String(pair[0])]=String(pair[1]);});
      else if(supplied && typeof supplied === 'object') for(var hk in supplied) if(Object.prototype.hasOwnProperty.call(supplied,hk)) headers[hk]=String(supplied[hk]);
      function hasHeader(name){for(var h in headers)if(h.toLowerCase()===name.toLowerCase())return true;return false;}
      if(!hasHeader('Content-Type')) headers['Content-Type']='application/x-protobuf';
      if(!hasHeader('Accept')) headers['Accept']='application/x-protobuf';
      requestInit.headers=headers;
      if(!requestInit.method) requestInit.method='POST';
      requestInit.body=requestBytes;
      return fetchApi(url, requestInit).then(function(response){
        if(!response.ok) throw new Error('fetchProto HTTP '+response.status+' '+(response.statusText||''));
        return response.arrayBuffer();
      }).then(function(buffer){
        var decoded = LorelightProto.decode(ResponseType, new Uint8Array(buffer));
        return LorelightProto.toObject(ResponseType, decoded, {longs:String, enums:String, bytes:String, defaults:false, arrays:true, objects:true});
      });
    });
  }
  module.exports = { fetchApi:fetchApi, fetchText:fetchText, fetchFile:fetchFile, fetchProto:fetchProto };
});

__registerModule('@libs/storage', function(module){
  function now(){ return Date.now(); }
  function toEpoch(expires){
    if (expires == null) return null;
    if (typeof expires === 'number') return expires;
    if (expires instanceof Date) return expires.getTime();
    return null;
  }
  var storage = {
    set: function(key, value, expires){
      var rec = { created: now(), value: value, expires: toEpoch(expires) };
      __native.storageSet(globalThis.__pluginId, String(key), JSON.stringify(rec));
    },
    get: function(key, raw){
      var s = __native.storageGet(globalThis.__pluginId, String(key));
      if (s == null || s === '') return undefined;
      var rec; try { rec = JSON.parse(s); } catch(e){ return undefined; }
      if (rec.expires != null && now() > rec.expires){ __native.storageDelete(globalThis.__pluginId, String(key)); return undefined; }
      return raw ? rec : rec.value;
    },
    getAllKeys: function(){ var s = __native.storageKeys(globalThis.__pluginId); try { return JSON.parse(s) || []; } catch(e){ return []; } },
    delete: function(key){ __native.storageDelete(globalThis.__pluginId, String(key)); },
    clearAll: function(){ __native.storageClear(globalThis.__pluginId); }
  };
  // LNReader contract: these two APIs expose read-only snapshots captured by
  // the app's own WebView. They are deliberately distinct from the persistent,
  // plugin-writable `storage` API above.
  function webStorageSnapshot(kind){
    try {
      var raw=__native.webStorageGet(globalThis.__pluginId, kind);
      if(!raw) return {};
      var value=JSON.parse(raw);
      return value && typeof value==='object' && !Array.isArray(value) ? value : {};
    } catch(e) {
      __native.log('[@libs/storage] Could not read '+kind+' snapshot: '+String(e&&e.message||e));
      return {};
    }
  }
  var localStorageSnapshot={get:function(){return webStorageSnapshot('localStorage');}};
  var sessionStorageSnapshot={get:function(){return webStorageSnapshot('sessionStorage');}};
  module.exports = { storage: storage, localStorage: localStorageSnapshot, sessionStorage: sessionStorageSnapshot };
});



// LNReader current and legacy import paths used by published plugins.
__registerModule('@/types/constants', function(module){
  module.exports = {
    NovelStatus: {
      Unknown: 'Unknown', Ongoing: 'Ongoing', Completed: 'Completed',
      Licensed: 'Licensed', PublishingFinished: 'Publishing Finished',
      Cancelled: 'Cancelled', OnHiatus: 'On Hiatus', STUB: 'STUB', Inactive: 'Inactive'
    },
    defaultCover: 'https://github.com/LNReader/lnreader-plugins/blob/main/icons/src/coverNotAvailable.jpg?raw=true'
  };
});


// LNReader's package map exports UTF-8 byte helpers from @noble/ciphers/utils
// through the stable @libs/utils alias. Keep the same named API for plugins.
__registerModule('@libs/utils', function(module){
  function utf8ToBytes(value){ return new TextEncoder().encode(String(value)); }
  function bytesToUtf8(value){ return new TextDecoder('utf-8').decode(value); }
  module.exports = { utf8ToBytes:utf8ToBytes, bytesToUtf8:bytesToUtf8 };
});

__registerModule('@libs/aes', function(module){
  function asBytes(value){
    if (value instanceof Uint8Array) return value;
    if (value instanceof ArrayBuffer) return new Uint8Array(value);
    if (value && value.buffer instanceof ArrayBuffer) return new Uint8Array(value.buffer, value.byteOffset || 0, value.byteLength);
    if (Array.isArray(value)) return new Uint8Array(value);
    throw new TypeError('AES-GCM input must be a byte array');
  }
  function encode(bytes){
    var s=''; for(var i=0;i<bytes.length;i++) s+=String.fromCharCode(bytes[i]);
    return btoa(s);
  }
  function decode(s){
    var bin=atob(s), out=new Uint8Array(bin.length);
    for(var i=0;i<bin.length;i++) out[i]=bin.charCodeAt(i)&255;
    return out;
  }
  function invoke(mode,key,nonce,data,aad){
    var result=__native.aesGcm(mode,encode(asBytes(key)),encode(asBytes(nonce)),encode(asBytes(data)),aad ? encode(asBytes(aad)) : '');
    if (typeof result !== 'string') throw new Error('AES-GCM bridge returned an invalid result');
    if (result.indexOf('!ERR:')===0) throw new Error(result.slice(5));
    return decode(result);
  }
  function gcm(key, nonce, associatedData){
    return {
      encrypt: function(plaintext){ return invoke('encrypt',key,nonce,plaintext,associatedData); },
      decrypt: function(ciphertext){ return invoke('decrypt',key,nonce,ciphertext,associatedData); }
    };
  }
  module.exports = { gcm: gcm };
});

__registerModule('@/lib/utils', function(module){
  function isUrlAbsolute(url){
    if (!url) return false;
    url=String(url);
    if (url.indexOf('//')===0) return true;
    if (url.indexOf('://')===-1 || url.indexOf('.')===-1 || url.indexOf('/')===-1) return false;
    if (url.indexOf(':')>url.indexOf('/')) return false;
    return url.indexOf('://')<url.indexOf('.');
  }
  function clsx(value){
    if (!value) return '';
    if (typeof value==='string' || typeof value==='number') return String(value);
    if (Array.isArray(value)) return value.map(clsx).filter(Boolean).join(' ');
    if (typeof value==='object') return Object.keys(value).filter(function(k){return !!value[k];}).join(' ');
    return '';
  }
  module.exports = { isUrlAbsolute:isUrlAbsolute, cn:function(){return Array.prototype.map.call(arguments,clsx).filter(Boolean).join(' ');}, getCoverUrl:function(cover){return cover || 'https://github.com/LNReader/lnreader-plugins/blob/main/icons/src/coverNotAvailable.jpg?raw=true';} };
});
