/*
 * Small dynamic Protocol Buffers runtime for Lorelight's LNReader plugin API.
 * Supports proto2/proto3 messages, enums, nested messages, oneof fields,
 * maps, packed repeated fields, and the standard scalar wire types.
 * Imports/extensions/groups and custom options are intentionally rejected or
 * ignored because fetchProto receives one self-contained .proto source string.
 */
(function (root) {
  'use strict';

  function tokenize(source) {
    var out = [], i = 0;
    while (i < source.length) {
      var c = source.charAt(i);
      if (/\s/.test(c)) { i++; continue; }
      if (c === '/' && source.charAt(i + 1) === '/') {
        i += 2; while (i < source.length && source.charAt(i) !== '\n') i++; continue;
      }
      if (c === '/' && source.charAt(i + 1) === '*') {
        var end = source.indexOf('*/', i + 2);
        if (end < 0) throw new Error('Unterminated comment in .proto schema');
        i = end + 2; continue;
      }
      if (c === '"' || c === "'") {
        var quote = c, start = i++;
        while (i < source.length) {
          if (source.charAt(i) === '\\') { i += 2; continue; }
          if (source.charAt(i++) === quote) break;
        }
        if (source.charAt(i - 1) !== quote) throw new Error('Unterminated string in .proto schema');
        out.push({ kind: 'string', value: source.slice(start, i) }); continue;
      }
      var match = source.slice(i).match(/^[A-Za-z_][A-Za-z0-9_]*|^-?(?:0x[0-9A-Fa-f]+|[0-9]+(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)/);
      if (match) { out.push({ kind: 'word', value: match[0] }); i += match[0].length; continue; }
      if ('{}[]<>=;,.()'.indexOf(c) >= 0) { out.push({ kind: c, value: c }); i++; continue; }
      throw new Error('Unexpected character in .proto schema: ' + c);
    }
    return out;
  }

  function parse(source) {
    if (typeof source !== 'string' || !source.trim()) throw new Error('Proto schema is empty');
    var tokens = tokenize(source), pos = 0, types = Object.create(null), packageName = '', syntaxVersion = 'proto2';
    function peek(v) { return tokens[pos] && (v == null || tokens[pos].value === v); }
    function take() { if (pos >= tokens.length) throw new Error('Unexpected end of .proto schema'); return tokens[pos++].value; }
    function expect(v) { var got = take(); if (got !== v) throw new Error('Expected "' + v + '" in .proto schema, got "' + got + '"'); }
    function word() { var t = tokens[pos++]; if (!t || t.kind !== 'word') throw new Error('Expected identifier in .proto schema'); return t.value; }
    function skipUntilSemicolon() { var depth = 0; while (pos < tokens.length) { var t = take(); if (t === '[' || t === '(') depth++; else if (t === ']' || t === ')') depth--; else if (t === ';' && depth <= 0) return; } }
    function skipOptions() {
      if (!peek('[')) return;
      take(); var depth = 1;
      while (pos < tokens.length && depth) { var t = take(); if (t === '[') depth++; else if (t === ']') depth--; }
      if (depth) throw new Error('Unterminated field options in .proto schema');
    }
    function parseTypeName() {
      var absolute = false, parts = [];
      if (peek('.')) { take(); absolute = true; }
      parts.push(word());
      while (peek('.')) { take(); parts.push(word()); }
      return (absolute ? '.' : '') + parts.join('.');
    }
    function register(type) {
      if (types[type.fullName]) throw new Error('Duplicate proto type: ' + type.fullName);
      types[type.fullName] = type;
    }
    function parseEnum(parent) {
      expect('enum'); var name = word(), full = parent ? parent + '.' + name : (packageName ? packageName + '.' : '') + name;
      var type = { kind: 'enum', name: name, fullName: full, values: Object.create(null), names: Object.create(null) };
      register(type); expect('{');
      while (!peek('}')) {
        if (pos >= tokens.length) throw new Error('Unterminated enum ' + full);
        if (peek('option') || peek('reserved')) { skipUntilSemicolon(); continue; }
        var key = word(); expect('='); var num = Number(take());
        if (!isFinite(num) || Math.floor(num) !== num) throw new Error('Invalid enum value in ' + full);
        skipOptions(); expect(';'); type.values[key] = num; if (type.names[num] === undefined) type.names[num] = key;
      }
      expect('}'); if (peek(';')) take(); return type;
    }
    function parseMessage(parent) {
      expect('message'); var name = word(), full = parent ? parent + '.' + name : (packageName ? packageName + '.' : '') + name;
      var type = { kind: 'message', name: name, fullName: full, fields: [], byId: Object.create(null) };
      register(type); expect('{');
      while (!peek('}')) {
        if (pos >= tokens.length) throw new Error('Unterminated message ' + full);
        if (peek('message')) { parseMessage(full); continue; }
        if (peek('enum')) { parseEnum(full); continue; }
        if (peek('oneof')) {
          take(); var oneofName = word(); expect('{');
          while (!peek('}')) parseField(type, full, 'optional', oneofName);
          expect('}'); if (peek(';')) take(); continue;
        }
        if (peek('option') || peek('reserved') || peek('extensions')) { skipUntilSemicolon(); continue; }
        if (peek('extend')) { take(); parseTypeName(); expect('{'); while (!peek('}')) skipUntilSemicolon(); expect('}'); continue; }
        parseField(type, full, null);
      }
      expect('}'); if (peek(';')) take(); return type;
    }
    function parseField(message, scope, forcedRule, oneofName) {
      var rule = forcedRule || 'optional';
      if (!forcedRule && (peek('optional') || peek('required') || peek('repeated'))) rule = take();
      var fieldType, mapKey = null, mapValue = null;
      if (peek('map')) {
        take(); expect('<'); mapKey = parseTypeName(); expect(','); mapValue = parseTypeName(); expect('>'); fieldType = 'map'; rule = 'repeated';
      } else fieldType = parseTypeName();
      var name = word(); expect('='); var id = Number(take());
      if (!isFinite(id) || Math.floor(id) !== id || id <= 0 || id >= 536870912 || (id >= 19000 && id <= 19999)) throw new Error('Invalid field number ' + id + ' in ' + message.fullName);
      var packed = null;
      if (peek('[')) {
        var before = pos; skipOptions();
        var optionText = tokens.slice(before, pos).map(function (t) { return t.value; }).join('');
        var m = optionText.match(/packed=(true|false)/); if (m) packed = m[1] === 'true';
      }
      expect(';');
      if (message.byId[id]) throw new Error('Duplicate field number ' + id + ' in ' + message.fullName);
      if (oneofName && fieldType === 'map') throw new Error('Map fields are not allowed inside oneof ' + oneofName);
      var field = { name: name, id: id, type: fieldType, rule: rule, packed: packed, mapKey: mapKey, mapValue: mapValue, scope: scope, oneof: oneofName || null };
      message.fields.push(field); message.byId[id] = field;
    }
    while (pos < tokens.length) {
      if (peek('syntax')) { take(); expect('='); var syntaxToken = take(); syntaxVersion = syntaxToken.replace(/^['"]|['"]$/g, ''); if (syntaxVersion !== 'proto2' && syntaxVersion !== 'proto3') throw new Error('Unsupported proto syntax: ' + syntaxVersion); expect(';'); }
      else if (peek('package')) { take(); packageName = parseTypeName().replace(/^\./, ''); expect(';'); }
      else if (peek('import')) { take(); if (peek('public') || peek('weak')) take(); var imp = take(); expect(';'); throw new Error('Proto imports are not supported by fetchProto: ' + imp); }
      else if (peek('option')) skipUntilSemicolon();
      else if (peek('message')) parseMessage('');
      else if (peek('enum')) parseEnum('');
      else if (peek('service')) { take(); word(); if (peek('{')) { take(); var d = 1; while (pos < tokens.length && d) { var st = take(); if (st === '{') d++; if (st === '}') d--; } } }
      else if (peek(';')) take();
      else throw new Error('Unsupported top-level .proto declaration: ' + take());
    }
    function resolve(name, scope) {
      if (!name) return null;
      if (name.charAt(0) === '.') return types[name.slice(1)] || null;
      var parts = (scope || '').split('.');
      while (parts.length) { var candidate = parts.join('.') + '.' + name; if (types[candidate]) return types[candidate]; parts.pop(); }
      return types[name] || (packageName && types[packageName + '.' + name]) || null;
    }
    Object.keys(types).forEach(function (k) {
      var t = types[k]; if (t.kind !== 'message') return;
      t.fields.forEach(function (f) {
        if (f.type === 'map') {
          f.resolvedKey = resolve(f.mapKey, f.scope); f.resolvedValue = resolve(f.mapValue, f.scope);
          if (!isScalar(f.mapKey) || f.mapKey === 'bytes' || f.mapKey === 'float' || f.mapKey === 'double' || f.mapKey === 'message') throw new Error('Unsupported map key type: ' + f.mapKey);
          if (!isScalar(f.mapValue) && !f.resolvedValue) throw new Error('Unknown map value type: ' + f.mapValue);
        } else {
          f.resolved = resolve(f.type, f.scope);
          if (!isScalar(f.type) && !f.resolved) throw new Error('Unknown proto type "' + f.type + '" in ' + t.fullName + '.' + f.name);
        }
      });
    });
    return { types: types, packedDefault: syntaxVersion === 'proto3', lookupType: function (name) {
      var key = String(name || '').replace(/^\./, '');
      if (types[key]) return types[key];
      var found = Object.keys(types).filter(function (k) { return k === key || k.slice(-(key.length + 1)) === '.' + key; });
      if (found.length === 1) return types[found[0]];
      if (found.length > 1) throw new Error('Ambiguous proto type name: ' + name);
      throw new Error('Proto type not found: ' + name);
    } };
  }

  var scalarTypes = { double: 1, float: 1, int32: 1, int64: 1, uint32: 1, uint64: 1, sint32: 1, sint64: 1, fixed32: 1, fixed64: 1, sfixed32: 1, sfixed64: 1, bool: 1, string: 1, bytes: 1 };
  function isScalar(name) { return !!scalarTypes[name]; }
  function utf8(value) {
    if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(String(value));
    var s = unescape(encodeURIComponent(String(value))), a = new Uint8Array(s.length);
    for (var i = 0; i < s.length; i++) a[i] = s.charCodeAt(i); return a;
  }
  function decodeUtf8(bytes) {
    if (typeof TextDecoder !== 'undefined') return new TextDecoder('utf-8').decode(bytes);
    var s = ''; for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]); return decodeURIComponent(escape(s));
  }
  function Writer() { this.a = []; }
  Writer.prototype.byte = function (v) { this.a.push(v & 255); };
  Writer.prototype.raw = function (a) { for (var i = 0; i < a.length; i++) this.byte(a[i]); };
  Writer.prototype.varint = function (value) {
    var n = typeof value === 'bigint' ? value : BigInt(value);
    if (n < 0) n = BigInt.asUintN(64, n);
    while (n > 127n) { this.byte(Number(n & 127n) | 128); n >>= 7n; }
    this.byte(Number(n));
  };
  Writer.prototype.lengthDelimited = function (bytes) { this.varint(bytes.length); this.raw(bytes); };
  Writer.prototype.finish = function () { return new Uint8Array(this.a); };

  function bytesValue(value) {
    if (value instanceof Uint8Array) return value;
    if (value instanceof ArrayBuffer) return new Uint8Array(value);
    if (Array.isArray(value)) return new Uint8Array(value);
    if (typeof value === 'string') {
      var bin = atob(value), out = new Uint8Array(bin.length); for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i); return out;
    }
    return new Uint8Array(0);
  }
  function enumNumber(type, value) {
    if (typeof value === 'string' && type && type.values[value] !== undefined) return type.values[value];
    var n = Number(value); if (!isFinite(n)) throw new Error('Invalid enum value: ' + value); return n;
  }
  function scalarWire(field) {
    var t = field.type;
    if (t === 'double' || t === 'fixed64' || t === 'sfixed64') return 1;
    if (t === 'string' || t === 'bytes' || t === 'message' || field.resolved && field.resolved.kind === 'message') return 2;
    if (t === 'float' || t === 'fixed32' || t === 'sfixed32') return 5;
    return 0;
  }
  function encodeScalar(writer, field, value, root) {
    var t = field.type, resolved = field.resolved;
    if (resolved && resolved.kind === 'enum') { writer.varint(enumNumber(resolved, value)); return; }
    if (resolved && resolved.kind === 'message') { var nested = encodeMessage(resolved, value || {}, root); writer.lengthDelimited(nested); return; }
    if (t === 'string') { writer.lengthDelimited(utf8(value == null ? '' : value)); return; }
    if (t === 'bytes') { writer.lengthDelimited(bytesValue(value)); return; }
    if (t === 'bool') { writer.varint(value ? 1 : 0); return; }
    if (t === 'float' || t === 'double') {
      var arr = new Uint8Array(t === 'float' ? 4 : 8), dv = new DataView(arr.buffer);
      if (t === 'float') dv.setFloat32(0, Number(value), true); else dv.setFloat64(0, Number(value), true);
      writer.raw(arr); return;
    }
    if (t === 'fixed32' || t === 'sfixed32') {
      var b32 = new Uint8Array(4); new DataView(b32.buffer).setUint32(0, Number(value) >>> 0, true); writer.raw(b32); return;
    }
    if (t === 'fixed64' || t === 'sfixed64') {
      var b64 = new Uint8Array(8), d64 = new DataView(b64.buffer), bi = BigInt(value);
      d64.setUint32(0, Number(BigInt.asUintN(32, bi & 0xffffffffn)), true);
      d64.setUint32(4, Number(BigInt.asUintN(32, bi >> 32n)), true); writer.raw(b64); return;
    }
    if (t === 'sint32') { var s32 = Number(value) | 0; writer.varint((s32 << 1) ^ (s32 >> 31)); return; }
    if (t === 'sint64') { var s64 = BigInt(value); writer.varint((s64 << 1n) ^ (s64 >> 63n)); return; }
    if (t === 'int32' || t === 'int64' || t === 'uint32' || t === 'uint64') { writer.varint(value == null ? 0 : value); return; }
    throw new Error('Unsupported proto scalar type: ' + t);
  }
  function encodeMessage(type, data, root) {
    var writer = new Writer(), selectedOneofs = Object.create(null); data = data || {};
    type.fields.forEach(function (f) {
      var value = data[f.name]; if (value === undefined || value === null) return;
      if (f.oneof) {
        if (selectedOneofs[f.oneof]) throw new Error('Only one field may be set in oneof ' + f.oneof);
        selectedOneofs[f.oneof] = f.name;
      }
      if (f.type === 'map') {
        Object.keys(value).forEach(function (key) {
          var kw = scalarWire({ type: f.mapKey, resolved: f.resolvedKey });
          // key is field 1
          var keyWriter = new Writer(); keyWriter.varint((1 << 3) | kw); encodeScalar(keyWriter, { type: f.mapKey, resolved: f.resolvedKey }, key, root);
          var valWriter = new Writer(); var vf = { type: f.mapValue, resolved: f.resolvedValue };
          valWriter.varint((2 << 3) | scalarWire(vf)); encodeScalar(valWriter, vf, value[key], root);
          var entryBytes = keyWriter.finish(), valBytes = valWriter.finish(), combined = new Uint8Array(entryBytes.length + valBytes.length);
          combined.set(entryBytes); combined.set(valBytes, entryBytes.length);
          writer.varint((f.id << 3) | 2); writer.lengthDelimited(combined);
        });
        return;
      }
      var values = f.rule === 'repeated' ? (Array.isArray(value) ? value : []) : [value];
      if (!values.length) return;
      var wire = scalarWire(f);
      var packable = wire === 0 || wire === 1 || wire === 5;
      var packed = f.rule === 'repeated' && packable && (f.packed === true || (f.packed == null && root && root.packedDefault));
      if (packed) {
        var packedWriter = new Writer(); values.forEach(function (v) { encodeScalar(packedWriter, f, v, root); });
        var packedBytes = packedWriter.finish(); writer.varint((f.id << 3) | 2); writer.lengthDelimited(packedBytes);
      } else {
        values.forEach(function (v) { writer.varint((f.id << 3) | wire); encodeScalar(writer, f, v, root); });
      }
    });
    return writer.finish();
  }
  function Reader(bytes) { this.b = bytes; this.p = 0; this.end = bytes.length; }
  Reader.prototype.varint = function () {
    var n = 0n, shift = 0n;
    while (this.p < this.end) { var b = this.b[this.p++]; n |= BigInt(b & 127) << shift; if (!(b & 128)) return n; shift += 7n; if (shift > 70n) throw new Error('Malformed protobuf varint'); }
    throw new Error('Truncated protobuf varint');
  };
  Reader.prototype.length = function () { var n = Number(this.varint()); if (!isFinite(n) || n < 0 || this.p + n > this.end) throw new Error('Invalid protobuf length'); return this.b.subarray(this.p, this.p += n); };
  Reader.prototype.fixed32 = function () { if (this.p + 4 > this.end) throw new Error('Truncated protobuf fixed32'); var n = new DataView(this.b.buffer, this.b.byteOffset + this.p, 4).getUint32(0, true); this.p += 4; return n; };
  Reader.prototype.fixed64 = function () { var lo = BigInt(this.fixed32()), hi = BigInt(this.fixed32()); return (hi << 32n) | lo; };
  Reader.prototype.skip = function (wire) {
    if (wire === 0) { this.varint(); return; }
    if (wire === 1) { this.p += 8; }
    else if (wire === 2) { this.length(); return; }
    else if (wire === 5) { this.p += 4; }
    else throw new Error('Unsupported protobuf wire type: ' + wire);
    if (this.p > this.end) throw new Error('Truncated protobuf field');
  };
  function decodeScalar(reader, field, wire, root) {
    var t = field.type, resolved = field.resolved;
    if (resolved && resolved.kind === 'message') return decodeMessage(resolved, new Reader(reader.length()), root);
    if (resolved && resolved.kind === 'enum') return Number(BigInt.asIntN(32, reader.varint()));
    if (t === 'string') return decodeUtf8(reader.length());
    if (t === 'bytes') return reader.length();
    if (t === 'bool') return reader.varint() !== 0n;
    if (t === 'float') { if (reader.p + 4 > reader.end) throw new Error('Truncated protobuf float'); var fv = new DataView(reader.b.buffer, reader.b.byteOffset + reader.p, 4).getFloat32(0, true); reader.p += 4; return fv; }
    if (t === 'double') { if (reader.p + 8 > reader.end) throw new Error('Truncated protobuf double'); var dv = new DataView(reader.b.buffer, reader.b.byteOffset + reader.p, 8).getFloat64(0, true); reader.p += 8; return dv; }
    if (t === 'fixed32') return reader.fixed32();
    if (t === 'sfixed32') return reader.fixed32() | 0;
    if (t === 'fixed64') return reader.fixed64().toString();
    if (t === 'sfixed64') return BigInt.asIntN(64, reader.fixed64()).toString();
    var raw = reader.varint();
    if (t === 'int32') return Number(BigInt.asIntN(32, raw));
    if (t === 'uint32') return Number(BigInt.asUintN(32, raw));
    if (t === 'sint32') { var z32 = Number(BigInt.asUintN(32, raw)); return (z32 >>> 1) ^ -(z32 & 1); }
    if (t === 'int64') return BigInt.asIntN(64, raw).toString();
    if (t === 'uint64') return BigInt.asUintN(64, raw).toString();
    if (t === 'sint64') { var z64 = BigInt.asUintN(64, raw); return ((z64 >> 1n) ^ (-(z64 & 1n))).toString(); }
    throw new Error('Unsupported protobuf scalar type: ' + t);
  }
  function decodeMessage(type, reader, root) {
    var result = {}, selectedOneofs = Object.create(null);
    while (reader.p < reader.end) {
      var tag = Number(reader.varint()), id = tag >>> 3, wire = tag & 7;
      if (!id) throw new Error('Invalid protobuf field tag');
      var f = type.byId[id]; if (!f) { reader.skip(wire); continue; }
      if (f.type === 'map') {
        var sub = new Reader(reader.length()), keyField = { type: f.mapKey, resolved: f.resolvedKey }, valField = { type: f.mapValue, resolved: f.resolvedValue };
        var key = '', val;
        while (sub.p < sub.end) {
          var st = Number(sub.varint()), sid = st >>> 3, sw = st & 7;
          if (sid === 1) key = decodeScalar(sub, keyField, sw, root);
          else if (sid === 2) val = decodeScalar(sub, valField, sw, root);
          else sub.skip(sw);
        }
        if (!result[f.name]) result[f.name] = {};
        result[f.name][String(key)] = val; continue;
      }
      var scalarWireType = scalarWire(f), packable = scalarWireType === 0 || scalarWireType === 1 || scalarWireType === 5;
      if (f.rule === 'repeated' && wire === 2 && packable && scalarWireType !== 2) {
        var packedReader = new Reader(reader.length());
        if (!result[f.name]) result[f.name] = [];
        while (packedReader.p < packedReader.end) result[f.name].push(decodeScalar(packedReader, f, scalarWireType, root));
        continue;
      }
      if (wire !== scalarWireType) throw new Error('Invalid wire type for ' + type.fullName + '.' + f.name);
      var value = decodeScalar(reader, f, wire, root);
      if (f.oneof) {
        var prior = selectedOneofs[f.oneof];
        if (prior) delete result[prior];
        selectedOneofs[f.oneof] = f.name;
      }
      if (f.rule === 'repeated') { if (!result[f.name]) result[f.name] = []; result[f.name].push(value); }
      else result[f.name] = value;
    }
    return result;
  }
  function toObject(type, value, options) {
    var out = {}, opts = options || {};
    type.fields.forEach(function (f) {
      if (value[f.name] === undefined) {
        if (opts.defaults) {
          if (f.rule === 'repeated') out[f.name] = [];
          else if (f.type === 'map') out[f.name] = {};
        }
        return;
      }
      function convert(v, resolved, t) {
        if (resolved && resolved.kind === 'message') return toObject(resolved, v, opts);
        if (resolved && resolved.kind === 'enum' && (opts.enums === String || opts.enums === 'string')) return resolved.names[v] !== undefined ? resolved.names[v] : v;
        if (t === 'bytes' && (opts.bytes === String || opts.bytes === 'string' || opts.bytes === 'base64')) {
          var a = bytesValue(v), s = ''; for (var i = 0; i < a.length; i++) s += String.fromCharCode(a[i]); return btoa(s);
        }
        if (/64$/.test(t) && (opts.longs === Number || opts.longs === 'number')) return Number(v);
        if (/64$/.test(t) && (opts.longs === String || opts.longs === 'string')) return String(v);
        return v;
      }
      var val = value[f.name];
      if (f.type === 'map') { var map = {}; Object.keys(val).forEach(function (k) { map[k] = convert(val[k], f.resolvedValue, f.mapValue); }); out[f.name] = map; }
      else if (f.rule === 'repeated') out[f.name] = val.map(function (v) { return convert(v, f.resolved, f.type); });
      else out[f.name] = convert(val, f.resolved, f.type);
    });
    return out;
  }

  root.LorelightProto = {
    parse: parse,
    encode: function (type, message, parsedRoot) { return encodeMessage(type, message || {}, parsedRoot || null); },
    decode: function (type, bytes) { return decodeMessage(type, new Reader(bytesValue(bytes)), null); },
    toObject: toObject
  };
})(globalThis);
