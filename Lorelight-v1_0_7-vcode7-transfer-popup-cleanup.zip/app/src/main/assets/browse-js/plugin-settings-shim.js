// Seeds defaults declared by LNReader pluginSettings without overwriting
// values saved by the user. The engine recreates the plugin instance after a
// successful seed so constructor/class-field reads see the initialized data.
(function (G) {
  G.__lorelightSeedPluginSettings = function (plugin) {
    var schema = plugin && plugin.pluginSettings ? plugin.pluginSettings : {};
    var storage = G.require('@libs/storage').storage;
    var changed = false;
    Object.keys(schema).forEach(function (key) {
      if (storage.get(key) === undefined) {
        var setting = schema[key] || {};
        var value = Object.prototype.hasOwnProperty.call(setting, 'value')
          ? setting.value : '';
        storage.set(key, value);
        changed = true;
      }
    });
    return changed;
  };
})(globalThis);
