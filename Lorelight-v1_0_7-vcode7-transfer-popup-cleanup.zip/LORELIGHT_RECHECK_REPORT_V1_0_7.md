# Lorelight 1.0.7 — Deep Recheck Report

**Artifact rechecked:** `Lorelight-v1_0_7-vcode7-full-audit-fixes.zip` (the ZIP attached in this conversation)  
**Android version metadata:** `versionCode = 7`, `versionName = "1.0.7"`  
**Recheck date:** 2026-11-14  
**Result:** targeted contract and JavaScript syntax checks passed; Android compilation, device behavior, and live website compatibility remain unverified. This report does **not** certify that the entire app is defect-free.

## 1. Scope and limits of this recheck

I re-opened and inspected the uploaded ZIP itself. ZIP integrity passed. It contains 1,433 ZIP entries (1,097 files and 336 directory entries).

The review concentrated on every implementation path touched by or directly related to the preceding work:

- Novel reader chapter positioning, toolbar, swipe navigation, settings and TTS chapter changes.
- Manga reader split-panel preference/default, toolbar chrome, long-strip feed window, chapter transitions and scroll anchoring.
- Per-source catalogue/search pagination, auto-prefetch, duplicate-page handling, retry and global search fan-out.
- Plugin JavaScript execution, fetch cancellation/timeouts, response conversion, page-plugin pagination and compatibility shims.
- Plugin repository loading, installation/update results, metadata storage and version comparison.
- Transfer search, candidate selection, chapter mapping, reading-progress precedence, completion/bookmark remapping and dialog cancellation.
- Cloudflare challenge retry/cancellation lifecycle and generic crawler fallback behavior.

The source paths and line ranges cited below refer to the rechecked archive. This was a line-oriented review of the changed and directly connected implementation paths, not a claim that every unrelated line in all 1,097 files was manually audited. The earlier pre-fix/base Lorelight ZIP and the LNReader archive are not available in the current file set, so a reliable complete old-versus-new diff could not be recreated. The prior LNReader comparison was against the app repository, not the separate live plugin bundle repository.

## 2. Checks run

| Check | Result | What it does and does not prove |
|---|---|---|
| ZIP CRC/integrity | PASS | `ZipFile.testzip()` returned no corrupt member. |
| Android version metadata | PASS | `app/build.gradle.kts:114–115` contains code 7 and name 1.0.7. |
| Seven JS contract suites | PASS — 77 assertions | Checks selected source contracts and regression guards; these are not Android UI/device tests. |
| Plugin runtime integration tests | PASS — 4 tests | Node-based tests exercise compatibility shims and mocked fetch/runtime behavior, not Android QuickJS against live websites. |
| Browse-JS syntax | PASS — 11 files | `node --check` passed for every `.js` file under `app/src/main/assets/browse-js`. |
| Kotlin compiler attempt | NOT A BUILD | `kotlinc` could not resolve Android, Compose, coroutine, project and generated dependency symbols (4,420 unresolved-reference diagnostics); no parser-style `expecting` / `unexpected tokens` diagnostics were found. This does not prove Kotlin semantic correctness. |
| Android Gradle build | NOT RUN | The archive lacks `gradle/wrapper/gradle-wrapper.jar`; no system Gradle executable or Android SDK is available in this environment. |
| Device/emulator | NOT RUN | No actual touch, scroll, lifecycle, rendering, or storage behavior was exercised on Android. |
| Live source websites | NOT RUN | No individual source-plugin bundle archive was supplied for representative end-to-end source tests. |

### Test breakdown

- `tests/cloudflare-safety-contracts.test.js`: 5 PASS
- `tests/fetch-timeout-contracts.test.js`: 8 PASS
- `tests/migration-progress-contracts.test.js`: 10 PASS
- `tests/plugin-acceptance-contracts.test.js`: 20 PASS
- `tests/plugin-runtime-contracts.test.js`: 1 PASS
- `tests/reader-behavior-contracts.test.js`: 14 PASS
- `tests/search-flow-contracts.test.js`: 19 PASS
- `node tools/plugin-runtime-tests/run.js`: 4 PASS

Total: **81 passing test assertions/integration checks**. This is not an 81-test Android instrumented suite.

## 3. Reader findings

### 3.1 Novel Reader

Relevant files:

- `app/src/main/java/com/lorelight/ui/reader/ReaderScreen.kt`
- `ReaderToolbar.kt`
- `ReaderContent.kt`
- `ReaderSettingsSheet.kt`
- `app/src/main/java/com/lorelight/tts/TtsPlaybackManager.kt`

Verified in source:

- The Novel Reader split-panel state, settings toggle and toolbar branch are absent from the Novel Reader implementation. The split-panel-only non-TTS chapter heading is also absent.
- The novel toolbar is a single compact solid black bar and includes the chapter number and chapter title.
- On a chapter-index transition after initial open, `ReaderScreen.kt:785–805` scrolls the list to item 0 and sets the restore guard for the new chapter before the saved-position effect can restore an old offset over it.
- The initial opening of a novel still uses the normal resume-position path; the top reset is tied to a chapter transition, not every initial open.
- The horizontal drag logic at `ReaderScreen.kt:1028–1055` maps a leftward drag to next chapter and a rightward drag to previous chapter, uses a 96 dp movement threshold and a 650 ms cooldown, and avoids acting while text selection is active.
- The Listen/TTS chapter-selection path passes a zero/start position when selecting the next or previous chapter.

**Not device-verified:** Compose gesture arbitration, touch slop, selection interactions, TTS timing, and whether the perceived swipe sensitivity feels right require a real Android device. The 96 dp threshold and cooldown are source facts, not proof of ideal feel on every screen size.

### 3.2 Manga Reader

Relevant files:

- `MangaReaderPrefs.kt`
- `MangaReaderSettingsPanel.kt`
- `MangaReaderChrome.kt`
- `MangaReaderScreen.kt`
- `MangaReaderViewModel.kt`
- `MangaWebtoonViewer.kt`

Verified in source:

- The split-panel toolbar remains in Manga Reader, and the saved-preference default is `true` for users with no value stored (`MangaReaderPrefs.kt:90–97`). The setting remains available.
- The Manga Reader status-bar backing and toolbar panels use black backgrounds; the split panels use 44 dp visible bars inside a 52 dp status-bar-padded container (`MangaReaderChrome.kt:58–92`).
- The long-strip feed keeps previous/current/next chapters in its bounded feed window. Natural active-page changes update the active chapter and shift that window (`MangaReaderViewModel.kt:620–677`) without incrementing the explicit-jump token.
- Initial positioning and explicit chapter jumps are keyed to `jumpToken` in `MangaReaderScreen.kt:455, 484–510`; the initial positioning effect is not keyed merely to every active chapter change.
- `MangaWebtoonViewer.kt:240–309` records the visible page key and pixel offset during scroll and reapplies that anchor after the feed changes, when the same key remains present.

**Not device-verified:** the stable-key and pixel-offset mechanism is present and contract-tested, but no emulator/device run verified that no visible jump occurs during fast flings, chapter insertion, image-height changes, rotation, process restoration, or cache misses. A source-level test cannot certify perceptually seamless continuous scrolling.

## 4. Source catalogue and infinite scrolling

Relevant file: `app/src/main/java/com/lorelight/browse/ui/SourceScreen.kt`.

Verified in source:

- Catalogue and search keep separate result lists, page counters, loading/error flags, jobs and generation tokens.
- The next-page paths call the source plugin with the next page number. Empty successful responses mark the end. Failed next-page calls set a retryable error and do not mark the source as exhausted (`SourceScreen.kt:310–357` and `439–479`).
- Duplicate-only non-empty pages advance the page counter rather than being mistaken for an empty end page.
- The visible-grid observer is tied to the active catalogue/search/filter state and reads the displayed collection size. It prefetches based on a viewport-scaled threshold.
- Duplicate-only automatic continuation is deliberately bounded: after three consecutive duplicate-only pages the user can manually continue. This prevents an unbounded request loop against a plugin that repeats the same page.
- Global search is a separate flow: it has bounded three-source fan-out, a 300 ms debounce, generation guards and per-source result/error updates as responses arrive.

**Precise conclusion:** automatic infinite-scroll pagination is implemented for the per-source catalogue and per-source search. It continues while a source returns usable pages, and exposes retry/continue states on errors or repeated duplicate pages. It is not a guarantee that every website provides infinite unique novels. If a plugin always returns page 1, ignores the page parameter, returns an empty page, or has no pagination support, the app cannot manufacture more results. Global search itself is not an infinitely paginated cross-source feed; it currently searches each source's first result page.

## 5. Search, plugin runtime and abort handling

Relevant files:

- `JSBridge.kt`
- `JSPluginEngine.kt`
- `libs-shims.js`
- `page-plugin-shim.js`
- `GlobalSearchScreen.kt`
- `CrawlerEngine.kt`

Verified improvements in the uploaded code:

- The default plugin operation timeout is 120 seconds; the native plugin fetch client has 120-second read/call budgets. The explicit multi-page novel-detail path has a longer five-minute budget.
- Abort reasons are preserved in native fetch errors when available.
- `cancelAllFetches` now posts an abort to the JS host only when it successfully marks the token as pending. This avoids delivering a stale abort after a fetch has already drained.
- Search results are applied only if their generation remains current; global-search source results publish independently.
- The prior per-host delay/429 retry behavior is not in the plugin fetch path, avoiding a queue that can consume the plugin operation timeout before results are delivered.

**The reported `[source] Error: The operation was aborted` is not certified as universally fixed.** The native timeout changes reduce one possible cause. A source plugin can still cancel its own request, a stale token or lifecycle edge can still exist outside the tested cases, and a particular website can reject requests. No live FWN/NovelBuddy/FanNovel tests were run because those plugin bundles were not supplied.

## 6. Transfer and reading-progress migration

Relevant files:

- `NovelSourceMigrator.kt`
- `MigrateSourceDialog.kt`
- `ProgressStore.kt`
- `ChapterReadStore.kt`

Verified in source and targeted contract tests:

- The migrator reads the durable progress row before choosing the source chapter position; it compares timestamps and prefers the newer progress representation.
- It anchors the target chapter by exact chapter number, then a safe chapter at/below that number, then a controlled index fallback; it writes both target chapter name and target index.
- Source-specific paragraph, manga-page, scroll and word offsets reset when the source changes.
- Completion/bookmark state is re-keyed against the target chapter URLs and incompatible source page offsets are cleared.
- The transfer dialog progressively publishes per-source candidates, makes the user select a candidate, uses the 120-second outer timeout, propagates coroutine cancellation, and holds updated job references so leaving composition cancels the current jobs.
- If a dialog closes after some migrations have succeeded, the completed subset is applied rather than silently discarded.

**Remaining durability concern:** `ChapterReadStore.remapForSourceMigration` submits the database update through the asynchronous writer and does not wait for a durable commit before the migration returns. A process death in that interval could leave some remapped completion/bookmark data unapplied. A future correction should make the source migration and chapter-state remap one awaited transaction or explicitly await the writer without blocking the main thread.

## 7. Browse, repository, installation and plugin state

Relevant files:

- `BrowseViewModel.kt`
- `BrowseScreen.kt`
- `PluginRepositoryManager.kt`
- `PluginManager.kt`
- `PluginStore.kt`
- `PluginVersion.kt`

Verified improvements:

- Install/update `Result` failures are now surfaced to Browse rather than silently ignored.
- A refresh where every configured repository fails is represented as an error/retry state, not a valid empty catalogue.
- Repository downloads use a bounded parallel pool and streaming index-size checks; plugin bundle installation stages and validates the bundle before activating it.
- `PluginStore` serializes its read-modify-write mutations under a shared lock.
- Browse refresh now explicitly rethrows coroutine cancellation instead of swallowing it as an ordinary repository error.

Remaining:

- When one repository succeeds and another fails, the failed repository is logged but is not clearly exposed as a partial-refresh warning in the UI. The visible catalogue can therefore be incomplete without a clear per-repository warning.
- SharedPreferences metadata writes still use asynchronous `apply()` in relevant paths; crash/process death immediately after a bundle-file change can leave file and metadata durability out of sync.

## 8. Cloudflare and generic crawler network handling

Relevant files:

- `CloudflareInterceptor.kt`
- `HttpClients.kt`
- `LorelightApplication.kt`
- `CrawlerEngine.kt`

Verified improvements:

- Cloudflare challenge retries do not replay request bodies marked one-shot or duplex.
- WebView cancellation cleanup is marshalled to the main looper and guarded against duplicate cleanup.
- The challenge solver now has a finite 20-second timeout; the built-in WebView polling also has its own bounded wait.
- The application initializes the shared client with the Cloudflare interceptor.

Remaining risk:

- Generic crawler fallback still retries an HTTPS failure over plaintext HTTP (`CrawlerEngine.kt:868–876`). That may help some legacy sites, but it is a transport downgrade and can expose traffic/cookies to interception. It should be removed or made an explicit per-source opt-in, not treated as a safe general retry.
- The Cloudflare solver was not run on an Android device or against a live challenge page. Main-thread cleanup and timeouts pass source-contract tests only.

## 9. Confirmed remaining compatibility/security gaps

These were found in the rechecked archive and are **not fixed by this update**:

| Severity | Location | Evidence | Impact |
|---|---|---|---|
| High | `app/src/main/assets/browse-js/page-plugin-shim.js:36–47` | Non-abort `parsePage()` failures are logged and swallowed; the accumulated partial chapter list is returned as success. | Novel details can look complete while chapter pages are missing. The app needs a structured incomplete result/retry or an explicit failure. |
| High | `app/src/main/java/com/lorelight/browse/ui/PluginSettingsDialog.kt:53–67, 92–145, 159–165`; `JSPluginEngine.kt:312–318` | Settings values are flattened to strings; only switch/select have dedicated controls; an array-valued CheckboxGroup falls into the text field path and is saved as a string. | LNReader sources using array-valued CheckboxGroup plugin settings cannot be configured correctly. This is separate from the normal source filter CheckboxGroup, which does have UI support. |
| High | `CrawlerEngine.kt:868–876` | HTTPS errors trigger an automatic HTTP retry. | Security downgrade; cookies/content may be exposed over plaintext transport. |
| Medium | `JSBridge.kt:139–148` | URL validation blocks localhost and common private IPv4 prefixes, but does not cover all IPv6 local ranges or DNS names that resolve to private/link-local addresses. | Incomplete private-network/SSRF protection for plugin fetch targets. |
| Medium | `JSBridge.kt:279–294` | Response is fully buffered, then represented simultaneously as bytes-derived text and Base64 without a maximum response size. | Large/malicious responses can create high memory pressure or OOM risk. |
| Medium | `JSPluginEngine.kt:54–55, 274–287`; `SourceScreen.kt:176–180, 846–882`; `GlobalSearchScreen.kt:127, 328–346` | `imageRequestInit` parses method and body, but cover `ImageRequest` paths only apply headers. | Image sources requiring POST/body semantics are not supported correctly; headers alone are not full request-init compatibility. |
| Medium | `libs-shims.js:120` | `@libs/fetch.fetchProto()` explicitly throws as unsupported. | Plugins using the LNReader protobuf helper cannot run that operation. |
| Medium | `libs-shims.js:148–149` | `localStorage` and `sessionStorage` are stubs returning empty objects, not browser-compatible stores. | Plugins using those Web Storage APIs can fail or lose state. The separate `@libs/storage` bridge is implemented, but it does not make the Web Storage stubs equivalent. |
| Medium | `PluginRepositoryManager.kt:132–151`, `PluginStore.kt:70–93` | `customJS`/`customCSS` metadata are parsed and persisted, but no plugin-runtime injection/use path was found in the app source. | Plugin customization metadata is retained but not shown to be executed/applied. |
| Medium | `JSPluginEngine.kt:99–110, 116–143` | A displaced but still-active plugin context is retained in `activeContexts`; acquisition prefers that context over the cache entry. | During an update while an old operation remains active, a new operation may temporarily reuse the old plugin context until it drains. |
| Low/Medium | `PluginRepositoryManager.kt:90–119` | Partial repository failures are logged while successful repositories are returned. | Catalogue can be incomplete with no visible per-repository warning. |
| Low/Medium | `ChapterReadStore.kt:272–323` | Remapped completion/bookmark state is submitted asynchronously. | Migration can return before that state is durably committed. |

The LNReader app archive used in the prior comparison is not the separate plugin bundle repository. Therefore this review cannot determine which currently published individual source plugins exercise each compatibility gap or certify their current uptime.

## 10. Changes made during this recheck

The following small hardening changes were made to the working copy after reopening the supplied ZIP:

1. `JSBridge.cancelAllFetches`: do not post a stale abort callback for a request token that is no longer pending.
2. `BrowseViewModel.refresh`: explicitly propagate coroutine cancellation instead of converting it into a normal refresh error.
3. `CloudflareInterceptor`: put the challenge solver behind a finite 20-second timeout.
4. Added regression assertions for those cases to the existing contract suites.

The ZIP linked with this report includes those recheck changes. The remaining issues in section 9 are deliberately disclosed rather than described as fixed.

## 11. Final status — strict wording

- **Novel reader split-panel removal:** confirmed in source and contract test; device rendering not tested.
- **Novel chapter start on next/previous:** confirmed in source and contract test; device/TTS timing not tested.
- **Novel swipe direction/threshold:** confirmed in source and contract test; perceived sensitivity not tested on device.
- **Manga split-panel default and retention:** confirmed in source and contract test; device rendering not tested.
- **Manga continuous chapter flow / no natural chapter auto-jump:** mechanism is present and contract-tested, but seamless visual preservation is not device-proven.
- **Source infinite pagination:** implemented for catalogue and per-source search with bounded duplicate-page recovery; not a guarantee against broken/non-paginated plugins.
- **120-second plugin timeout / abort handling:** native timeout and cancellation handling improved and contract-tested; universal website search success is not established.
- **Transfer progress mapping:** source-level migration ordering and target-index mapping are contract-tested; asynchronous completion/bookmark persistence remains a risk.
- **Cloudflare:** cancellation/retry/timeout hardening is contract-tested; real challenge solving remains unverified.
- **No-defects claim:** **not supportable**. The known gaps above remain, and no Android build/device/live-source verification was possible.

This recheck improves confidence in the exact behaviors tested, but it does not certify the whole application as bug-free.
