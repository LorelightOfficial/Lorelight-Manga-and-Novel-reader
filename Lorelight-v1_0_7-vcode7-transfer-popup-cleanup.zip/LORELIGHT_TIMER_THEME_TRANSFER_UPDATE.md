# Lorelight UI Update — Timer, Theme Surfaces, and Live Transfer Results

## Changes

### Sleep timer
- Replaced the platform `NumberPicker` with a Compose-rendered vertical wheel.
- The centre value is rendered larger and bold; adjacent values are smaller and subdued. This styling follows the selected value while the wheel is dragged.
- Vertical dragging changes the value continuously, wraps at the range boundary, and tapping above/below the centre steps the value.
- Changed the `H` label to **Hours** and `MIN` to **Minutes**.
- Added a themed timer heading and selected-value highlight surface.

### Theme consistency
- Removed the hard-coded black reader toolbar slab and white-only toolbar icon/text colour.
- Reader toolbar now uses `MaterialTheme.colorScheme.surface` and `onSurface`, so custom/light/dark palettes are respected.
- Timer panel uses the existing glass dropdown surface, which derives its tint and content colours from the active Material theme.

### Transfer search
- Each source continues to run its own search independently through the same source search engine used by the Source screen.
- To avoid Transfer's extra latency, it now tries the exact title and at most one cleaned/shortened fallback instead of up to four sequential title variants. A usable exact-title result stops retries immediately.
- The live source row shows the current attempt/query, elapsed time for each completed attempt, final match count, and total source duration. Each source keeps its own **120-second timeout**.
- As soon as a source finishes, its result group is promoted above still-searching sources. Results remain incremental; one slow source does not block faster sources.
- A slow source no longer visually hides completed results lower in the list.

### Transfer timeout adjustment
- Increased the per-source transfer search timeout from 30 seconds to **120 seconds (2 minutes)**.
- Timeout messages now report the 120-second limit. This is scoped to transfer candidate searches; unrelated download, AI, reader, and plugin execution timeouts are unchanged.

## Validation
- `node tests/plugin-runtime-contracts.test.js` — PASS.
- `node tools/plugin-runtime-tests/run.js` — PASS.
- JavaScript syntax check for all browse-js assets — PASS.
- Android Gradle compilation was not run: this checkout still lacks `gradle-wrapper.jar` and the environment has no configured Android SDK/system Gradle. The Compose changes therefore still require an Android build and on-device interaction test.

## Scope
Only the reader toolbar/timer and transfer dialog were changed for this update. Existing source-search, reader, AI, library, notifications, theme settings, and manga functionality were otherwise left intact. The LNReader repository is not included in the app archive.


### Read-mode toolbar visibility and status bar
- Restored the original v1.0.6 upper-toolbar placement is retained in normal mode and remains independent of the visibility gesture. Split-panel mode still has no chapter label between its panels.
- Increased the deliberate Read-mode scroll threshold from 22dp to 56dp and limited each drag to a single visibility toggle, reducing accidental hides during ordinary reading adjustments.
- Kept the Android status bar visible and its solid AMOLED-black backing fixed while the reader toolbar slides away.
