# Lorelight

Lorelight is an Android web-novel reader with built-in crawling, offline reading,
text-to-speech playback, and a plugin system for novel sources.

## Features
- Import and read web novels with a customizable reader
- Background text-to-speech playback with media controls
- Offline chapter caching
- Plugin-based source system (QuickJS)
- Library backup and restore

## Building
1. Open the project in Android Studio (or use Gradle 8.11+).
2. Debug build: `gradle assembleDebug`
3. Release build requires signing credentials via environment variables:
   - `RELEASE_STORE_PASSWORD`
   - `RELEASE_KEY_PASSWORD`
   - `RELEASE_KEY_ALIAS`
   and a `release.keystore` file in the project root.

## License & Acknowledgments
Lorelight contains code derived from [Mihon](https://github.com/mihonapp/mihon) (Apache-2.0) for Tachiyomi/Mihon extension compatibility.

## Plugin Runtime Contract Checks

The portable JavaScript runtime-shim contract tests can be run with Node.js from
this project root:

```sh
node tests/plugin-runtime-contracts.test.js
```

These checks cover Fetch/URL/body serialization, request cancellation, storage
and plugin-setting defaults, Blob/FileReader, Cheerio callback/selector behavior,
PagePlugin pagination, and htmlparser2 callback/serialization behavior. They do
not replace Android instrumentation or live website tests.

## vcode12 infinite source pagination update

This build retains the vcode11 LNReader-inspired plugin compatibility and staged
repository acceptance work, and restores robust infinite pagination for both
source catalogues and individual-source searches. Pagination now follows the
currently displayed list, prefetches relative to the visible viewport, advances
across duplicate-only pages without falsely declaring the source exhausted, and
keeps failed pages retryable.

See `SOURCE_PAGINATION_VCODE12.md` for the implementation notes and device
acceptance matrix. See `PLUGIN_COMPATIBILITY_VCODE11.md` for the compatibility
changes and known gaps (`fetchProto` and customJS/customCSS injection).

Run the portable contract tests from the project root:

```sh
node tests/plugin-runtime-contracts.test.js
node tests/search-flow-contracts.test.js
node tests/plugin-acceptance-contracts.test.js
```
