# Lorelight plugin compatibility audit — latest AI multi-provider keys build

**Target project:** `Lorelight-v1_0_6-vcode6-ai-multi-provider-keys.zip`
**Plugin reference archive:** `lnreader-plugins-master.zip`

## Repository inventory

- **260** plugin `.ts` / `.js` source files in the reference repository.
- **225** direct source plugin files across language folders.
- **35** multisource generator/template/helper files.
- **13** multisource families, containing **160** configured website entries.
- **14** source files are explicitly marked `.broken.ts` upstream.
- **36** of the multisource website entries are explicitly marked `down` by upstream metadata.

> This is a source/runtime compatibility audit, not a claim that every remote website was reachable or that every novel/chapter endpoint was live-tested. Website uptime, anti-bot challenges, API changes, regional restrictions, and source-side breakage remain external variables.

## Runtime compatibility changes made

- Added the missing `@libs/aes` module using Android JCA `AES/GCM/NoPadding`. It supports AES-128/192/256, nonce/IV, optional AAD, ciphertext-plus-authentication-tag layout, and both encrypt/decrypt operations.
- Added `@/types/constants` with the upstream `NovelStatus` values and `defaultCover`, fixing the NovelFire import path.
- Added a compatibility implementation for `@/lib/utils` (`isUrlAbsolute`, `cn`, and `getCoverUrl`) for legacy plugin bundles.
- Added global `fetch` with `text()`, `json()`, `arrayBuffer()`, `blob()`, response status/headers, and `clone()` support; response bytes are carried as base64 to avoid corrupting binary payloads.
- Added `Headers`, string-field `FormData`, `URLSearchParams` request serialization, and an `AbortController`/`AbortSignal` subset.
- Added native multipart/form-data and application/x-www-form-urlencoded request-body handling in the HTTP bridge.
- Fixed base64 encoding/decoding edge cases for input lengths not divisible by three; this is required for AES key/IV/ciphertext byte arrays.

## Plugin dependency audit

The plugin source imports were compared against Lorelight runtime registrations. The runtime imports used by plugin bundles are covered by the existing and updated shims:

| Import/module | Status |
|---|---|
| `@libs/fetch` | Existing shim; expanded response and global-fetch compatibility |
| `@libs/filterInputs` | Existing shim |
| `@libs/novelStatus` | Existing shim |
| `@libs/defaultCover` | Existing shim |
| `@libs/storage` | Existing shim |
| `@libs/isAbsoluteUrl` | Existing shim |
| `@libs/aes` | Added native AES-GCM implementation |
| `@/types/constants` | Added constants alias |
| `cheerio`, `htmlparser2`, `dayjs`, `urlencode`, `qs` | Existing shims/registrations |

`@/types/plugin` imports in the repository are TypeScript type imports and are erased during plugin compilation. `./sources.json`, `./settings.json`, `path`, `fs`, `url`, `readline`, and `process` appear in multisource build/generator files, not in the plugin runtime modules loaded by the app.

## Upstream source inventory

### Direct source plugins
**arabic (12)**
`Markazriwayat.broken.ts`, `azorafly.ts`, `dilartube.ts`, `eightysixar.ts`, `galaxynovels.ts`, `mknov.ts`, `mtlarabic.ts`, `rewayahfans.ts`, `rewayatclub.ts`, `rewayatfans.ts`, `seanovel.ts`, `sunovels.ts`

**bangla (1)**
`golpercity.ts`

**chinese (8)**
`69shu.ts`, `Quanben.ts`, `ixdzs8.ts`, `lewenn.ts`, `linovel.ts`, `linovelib.ts`, `linovelib_tw.ts`, `novel543.ts`

**english (123)**
`HangulPlanet.ts`, `NovelOnline.ts`, `StorySeedling.ts`, `animeAnyway.ts`, `ao3.ts`, `asianfanfics.ts`, `asianhobbyist.ts`, `asurascans.ts`, `atsumaru.ts`, `bakaTsuki.ts`, `beastnovels.ts`, `bestlightnovel.broken.ts`, `bloodcoretl.ts`, `boonnovel.ts`, `borntobenovel.ts`, `bronstl.ts`, `cclawtranslations.ts`, `cherrymistcafe.ts`, `chikari.ts`, `chrysanthemumgarden.ts`, `cotereader.ts`, `craneanime.ts`, `crimsonscrolls.ts`, `daotekno.ts`, `decodednovels.ts`, `divinedaolibrary.ts`, `dragonholic.ts`, `dreambigtl.ts`, `dreamyTranslations.ts`, `earlynovel.broken.ts`, `eatapplepies.ts`, `empirenovel.ts`, `experimentaltranslations.ts`, `faqwikius.ts`, `fenrirrealm.ts`, `fictionzone.ts`, `firebirdsnest.ts`, `firsttrytranslations.ts`, `foxteller.ts`, `fucknovelpia.ts`, `genesis.ts`, `hennoveltranslations.ts`, `impatientmtlreader.ts`, `indraTranslations.ts`, `inkitt.ts`, `inoveltranslation.ts`, `isogashiineeto.ts`, `itsametranslations.ts`, `kakushitranslations.ts`, `kaystranslations.ts`, `kdtnovels.ts`, `konkon.ts`, `leafstudio.ts`, `lightnovelto.ts`, `lightnoveltranslation.ts`, `lightnovelworld.ts`, `lncrawler.ts`, `lnmtl.ts`, `lnori.ts`, `luminaretranslations.ts`, `machineslicedbread.ts`, `maddertranslates.ts`, `maehwasup.ts`, `miumiu.ts`, `mizupanshoko.ts`, `mtlreader.broken.ts`, `mvlempyr.ts`, `mylasted.ts`, `mynovels.ts`, `nephologytl.ts`, `nightjarreads.ts`, `novel7s.ts`, `novelarchive.ts`, `novelarrow.ts`, `novelbin.ts`, `novelbuddy.ts`, `noveldex.ts`, `novelhall.ts`, `novelhi.ts`, `novelight.ts`, `novelito.ts`, `novelonomicon.ts`, `novelrest.ts`, `novelupdates.ts`, `nyxtranslation.ts`, `onlinereadfreenovel.ts`, `pawread.ts`, `pinkmuffintl.ts`, `procrastranslation.ts`, `puffinFolio.ts`, `rainofsnow.ts`, `readfrom.ts`, `readingpia.ts`, `readlitenovel.broken.ts`, `reaperscans.broken.ts`, `rechapters.ts`, `relibrary.ts`, `rinkagetranslation.ts`, `royalroad.ts`, `rpgnovels.ts`, `sadstranslates.ts`, `scribblehub.ts`, `seireitranslations.ts`, `skythewood.ts`, `stabbingwithasyringe.ts`, `sylthorian.ts`, `taekan.ts`, `taxingcorn117stranslations.ts`, `tensurafan.ts`, `tinytranslation.ts`, `toasteful.ts`, `towardsthesky.ts`, `tseirptranslations.ts`, `vynovel.ts`, `wanderinginn.ts`, `wct.ts`, `webnovel.ts`, `wetriedtls.ts`, `wntl.ts`, `wtrlab.ts`, `wuxiaworld.ts`, `wwaraitai.ts`, `ynvermoon.ts`

**french (13)**
`chireads.ts`, `harkeneliwood.ts`, `jgarden.ts`, `kisswood.ts`, `lightnovelvf.ts`, `noveldeglace.ts`, `novelfrance.ts`, `novhell.ts`, `rezerowebnovelfr.ts`, `tradindex.ts`, `warriorlegendtrad.ts`, `wuxialnscantrad.ts`, `xiaowaz.ts`

**indonesian (4)**
`grensia.ts`, `indowebnovel.ts`, `novelringan.ts`, `sakuranovel.ts`

**japanese (2)**
`Syosetu.ts`, `kakuyomu.ts`

**korean (1)**
`Agitoon.ts`

**multi (1)**
`komga.ts`

**polish (1)**
`novelki.ts`

**portuguese (5)**
`animecenterbr.ts`, `blnovels.ts`, `blogdoamonnovels.ts`, `novelmania.ts`, `tsundoku.ts`

**russian (21)**
`LitSpace.broken.ts`, `authortoday.ts`, `bookriver.ts`, `ficbook.ts`, `hexnovels.ts`, `jaomix.ts`, `neobook.ts`, `novelOvh.broken.ts`, `novelTL.ts`, `ranobehub.ts`, `ranobelib.ts`, `ranobelife.ts`, `ranobeme.ts`, `ranobemir.ts`, `ranoberf.ts`, `renovels.ts`, `ruranobe.ts`, `ruvers.broken.ts`, `topliba.broken.ts`, `webfandom.ts`, `zelluloza.ts`

**spanish (16)**
`NOVA.ts`, `hasutl.ts`, `miraiknovels.ts`, `novelaenespanol.ts`, `novelaligera4fan.ts`, `novelasligera.ts`, `novelasmtl.ts`, `novelastopcur.ts`, `novelawuxia.ts`, `novels2.ts`, `noveltranslations18.ts`, `novelyra.ts`, `oasistranslations.ts`, `skynovels.ts`, `tunovelaligera.ts`, `yukitls.ts`

**thai (1)**
`readallday.ts`

**turkish (4)**
`MangaTR.ts`, `epiknovel.ts`, `lnmakineceviri.ts`, `rezeroturkce.ts`

**ukrainian (3)**
`bakainua.ts`, `smakolykytl.ts`, `uaranobeclub.broken.ts`

**vietnamese (9)**
`LNHako.ts`, `Truyenconect.broken.ts`, `lightnovelvn.ts`, `nettruyen.ts`, `truyenchu.broken.ts`, `truyendich.ts`, `truyenfull.broken.ts`, `truyenss.ts`, `wetruyen.ts`

### Multisource families and configured websites
**fictioneer — 8 configured entries (1 upstream-marked down)**
Daoist Quest; Peach Puff Translations; NovelLib; Lily on the Valley; Penguin Squad; Prizma; Dearest Rosalie [upstream down]; Illusia

**hotnovelpub — 5 configured entries (4 upstream-marked down)**
HotNovelPub; EzNovels [upstream down]; LightNovelDaily [upstream down]; LaNovels [upstream down]; ThNovels [upstream down]

**ifreedom — 2 configured entries (0 upstream-marked down)**
Свободный Мир Ранобэ; Bookhamster

**lightnovelwp — 36 configured entries (7 upstream-marked down)**
Ligh Novel FR; Kol Novel; Free Kol Novel; KnoxT; Baca Light Novel; AllNovelRead [upstream down]; DaoTranslate; Novels Paradise; Universal Novel; NovelTR; NobleMTL; Panda Machine Translations [upstream down]; NovelsKnight; Central Novel; White Moonlight Novels; Sekte Novel; System Translation; Moonlight Novels [upstream down]; Light Novel Brasil; ElloTL [upstream down]; Ippotranslations; CPUnovel [upstream down]; Requiem Translations; Better Novels [upstream down]; Arcane Translations; Namevt; Kodeks Library; Vandy Translate; Lazy Girl Translations; Keopi Translations [upstream down]; TC & Sega; Translation Weaver; Hyacinth in Bloom; BlumeVerse; DobyNovels; OssanTL

**madara — 76 configured entries (18 upstream-marked down)**
NovelTranslate [upstream down]; LunarLetters; SleepyTranslations; FirstKissNovel; DaoNovel [upstream down]; MostNovel; NovelMultiverse; LightNovelHeaven; ArNovel; MeioNovel; WebNovelLover [upstream down]; WBNovel; WuxiaWorld.Site; MysticalSeries; Vanovel; HizoManga; Riwyat; Novel4Up [upstream down]; TurkceLightNovels; SonicMTL; Guavaread [upstream down]; NeoSekai Translations; MTL-Novel [upstream down]; Zetro Translation; WebNovelOku; Light Novel Updates [upstream down]; Foxaholic; Nitro Manga; Kiniga [upstream down]; Pancho Translations; Salmon Latte; Srank Manga; Novel Lucky; Fans Translations; Hiraeth Translation; Novel PDF; Azora [upstream down]; TranslatinOtaku; Dragon Tea; NovelBookID; Meownovel [upstream down]; Galaxy Translations [upstream down]; Olaoe.cyou [upstream down]; WordExcerpt; Citrus Aurora; Dusk Blossoms; Belle Repository; Traducciones Amistosas; Coral Boutique [upstream down]; Pastel Tales; Araz Novel; Novel oku [upstream down]; NABİ SCANS [upstream down]; E-KİTAPLAR; Wook's Teahouse; Eternalune; Fortune Eternal; Ragnar Scans; Read Fanfic; Violet Lily [upstream down]; Sweet Escape [upstream down]; AnimesHoy12 [upstream down]; kakikata; Ranovel; Etude Translations; MassNovel; Noice Translations; Novel Ninja; LulloBox; BoxNovel; Novel Nice; Novel Short; Lovelyblossoms; Tangerine Archive; BaiLianTales; Anslid

**mtlnovel — 6 configured entries (1 upstream-marked down)**
MTL Novel; MTL Novel (FR); MTL Novel (ES); MTL Novel (ID); MTL Novel (PT); MTL Novel (RU) [upstream down]

**novelcool — 2 configured entries (0 upstream-marked down)**
NovelCool; NovelCool (RU)

**novelfire — 2 configured entries (0 upstream-marked down)**
Novel Fire; Novel Phoenix

**ranobes — 2 configured entries (0 upstream-marked down)**
Ranobes; Ranobes (RU)

**readnovelfull — 8 configured entries (0 upstream-marked down)**
ReadNovelFull; AllNovel; LightNovelPlus; NovelFull; Lib Read; AllNovelFull; Novel Ping; Free Web Novel

**readwn — 7 configured entries (2 upstream-marked down)**
Wuxiabox; Wuxiafox [upstream down]; Ltnovel; Fans MTL; FanNovel; Wuxia Space; WuxiaV [upstream down]

**rulate — 3 configured entries (0 upstream-marked down)**
Rulate; Erolate; Bllate

**webnovelworld — 3 configured entries (3 upstream-marked down)**
Web Novel Pub [upstream down]; LightNovelPub Vip [upstream down]; LightNovelCave [upstream down]

### Sources explicitly marked broken upstream
- `arabic/Markazriwayat.broken.ts`
- `english/bestlightnovel.broken.ts`
- `english/earlynovel.broken.ts`
- `english/mtlreader.broken.ts`
- `english/readlitenovel.broken.ts`
- `english/reaperscans.broken.ts`
- `russian/LitSpace.broken.ts`
- `russian/novelOvh.broken.ts`
- `russian/ruvers.broken.ts`
- `russian/topliba.broken.ts`
- `ukrainian/uaranobeclub.broken.ts`
- `vietnamese/Truyenconect.broken.ts`
- `vietnamese/truyenchu.broken.ts`
- `vietnamese/truyenfull.broken.ts`

## Validation performed

- All JavaScript files in `app/src/main/assets/browse-js/` passed Node.js syntax checks.
- A Node.js compatibility harness passed: AES-GCM round-trip with AAD, constants alias resolution, FormData serialization, URLSearchParams serialization, Headers serialization, base64 round-trips for 0–99 byte payloads, global fetch text/arrayBuffer, and pre-aborted requests.
- ZIP integrity was checked before editing; the updated ZIP is re-created and integrity-checked after editing.

## Not yet verified

- A full Android Gradle build was not run: this archive does not contain `gradle/wrapper/gradle-wrapper.jar`, and no system Gradle installation is available in the build environment.
- Live popular/search/details/chapter requests were not executed against all 160 multisource entries and all direct sites. These require network/runtime testing on-device and may fail if the source website is down or has changed its API/anti-bot behavior.
- `FormData` currently supports string fields, which matches the FormData usages found in the audited plugin sources; binary file uploads are not implemented.
- `AbortController` rejects the JS request promise when aborted, but does not cancel an already-running OkHttp call at the socket layer.
