# Lorelight v1.0.7 — Plugin Compatibility Expansion

## Scope and result

This update continues from `Lorelight-v1_0_7-vcode7-remaining-fixes.zip`. Android metadata remains **versionCode 7 / versionName 1.0.7**.

The requested plugin-compatibility work is implemented in source for:

- Web Storage snapshot access (`localStorage.get()` and `sessionStorage.get()`).
- Binary Protocol Buffers requests and responses through `@libs/fetch.fetchProto()`.
- Plugin manifest `customJS` and `customCSS` asset download and chapter-processing integration.
- Chapter-cache invalidation when those custom assets are updated.

This is not a complete Android release verification. The limitations and unverified work are listed below.

## 1. Web Storage compatibility

### Implemented

- A plugin receives Web Storage only when its `webStorageUtilized` flag is true and its declared `site` resolves to a valid HTTP(S) origin.
- Snapshots are pinned to that exact normalized origin. A plugin cannot pass another plugin ID or arbitrary origin to read a different site's storage.
- Lorelight captures `localStorage` and `sessionStorage` from its own in-app browser and Cloudflare challenge WebViews after page completion.
- `localStorage.get()` returns the captured read-only snapshot, retained in app-private SharedPreferences.
- `sessionStorage.get()` returns a read-only snapshot with a 30-minute expiry, because its originating WebView session may have ended.
- Both snapshots are bounded to 2,048 keys and 512 KiB total; individual values larger than 64 KiB are omitted.
- The separate plugin `storage` API remains plugin-namespaced and persistent, with its existing read/write methods.
- Uninstalling one source preserves an origin snapshot while another installed source still uses the same origin.

### Compatibility boundaries

This matches the LNReader contract: `localStorage` and `sessionStorage` expose read-only `get()` snapshots populated by the app's WebView; plugin-owned persistent data belongs in `storage`.

Snapshots are refreshed when the app-owned WebView finishes a page. Changes made later by page scripts without another page completion may not be reflected until a later capture. Storage from unrelated external browsers is not imported. Session snapshots expire after 30 minutes by Lorelight policy.

## 2. `fetchProto()` implementation

### Implemented

- Added a bundled, dependency-free Protocol Buffers runtime loaded before the plugin library shims.
- `@libs/fetch.fetchProto(protoInit, url, init)` parses the supplied schema, resolves request/response message types, encodes `requestData`, sends a binary request (POST by default), and decodes the binary response.
- Request bytes are converted to Base64 only for the JavaScript-to-native bridge envelope; the native OkHttp request body is restored to the original binary bytes.
- HTTP error responses reject instead of being decoded as successful protobuf payloads.
- Supported schema/data features include proto2/proto3 syntax, packages, nested messages, enums, oneof alternatives, maps, repeated and packed fields, and standard scalar wire types (signed/unsigned integer, zig-zag, fixed-width, floating-point, bool, string, and bytes).
- 64-bit integer results are preserved as strings by default to avoid JavaScript number precision loss. Byte fields are returned as Base64 strings.

### Compatibility boundaries

This is a focused dynamic runtime, not the complete `protobuf.js` implementation. Imported `.proto` files are explicitly rejected; groups and extension resolution are not implemented; custom field options are not interpreted beyond the supported `packed` setting. Plugins whose schemas depend on imported definitions or these unsupported features will still need adaptation or a fuller protobuf runtime.

## 3. `customJS` and `customCSS`

### Implemented

- Manifest custom asset URLs are downloaded at install/update time, require HTTPS (including after redirects), use the public-address DNS guard and an isolated connection pool, and are capped at 1 MiB each.
- Plugin bundle and custom asset replacement is staged; failures restore the previous bundle/assets rather than leaving a partially updated installation.
- On plugin chapter extraction, Lorelight loads the returned HTML into an isolated WebView, injects the installed custom JS/CSS, then extracts the transformed page text.
- The processor removes the source page's script/iframe/object/embed/base elements, disables network loads, applies a restrictive Content Security Policy, exposes no native JavaScript interface, and has a five-second processing timeout.
- The chapter cache identity includes the custom asset file revisions, so changing either asset causes a fresh extraction rather than returning text transformed by an older asset.

### Important rendering limitation

Lorelight's novel reader renders native Compose text, not a browser page. Therefore custom CSS affects DOM layout/visibility during extraction (for example, hiding page elements before text extraction), but arbitrary browser styling—font families, colors, margins, and other visual CSS—is **not transferred to Compose text styling**. Likewise, custom JS runs against the parsed DOM without the original page's scripts or external network access; scripts that depend on those may not behave as on LNReader's browser-based reader. This is partial custom asset compatibility, not full browser-rendering parity.

## 4. Files changed from the previous remaining-fixes package

- `app/src/main/assets/browse-js/protobuf-runtime.js` — new protobuf schema parser, encoder, decoder and object conversion.
- `app/src/main/assets/browse-js/libs-shims.js` — `fetchProto` and read-only Web Storage wrappers.
- `app/src/main/java/com/lorelight/webstorage/WebStorageSnapshotStore.kt` — new bounded, origin-scoped snapshot store.
- `app/src/main/java/com/lorelight/browse/js/JSBridge.kt` — plugin-scoped Web Storage access.
- `app/src/main/java/com/lorelight/browse/js/JSPluginEngine.kt` — native bridge registration, protobuf asset loading and plugin metadata gate.
- `app/src/main/java/com/lorelight/browse/ui/InAppBrowserDialog.kt` and `app/src/main/java/com/lorelight/network/CloudflareInterceptor.kt` — Web Storage snapshot capture.
- `app/src/main/java/com/lorelight/browse/repo/PluginManager.kt` — guarded custom asset downloads, transactional activation and shared-origin-safe cleanup.
- `app/src/main/java/com/lorelight/browse/js/PluginChapterHtmlProcessor.kt` — new isolated custom page processor.
- `app/src/main/java/com/lorelight/crawler/CrawlerEngine.kt` — custom page processing and asset-sensitive chapter cache identity.
- `tests/plugin-acceptance-contracts.test.js` — expectations updated for now-implemented compatibility paths.
- `tests/plugin-compatibility-expansion.test.js` — new regression suite.

## 5. Verification performed

- **109 Node.js regression/contract assertions passed** across eight test files.
- **12/12 bundled browse JavaScript assets passed** `node --check`.
- Protobuf tests cover nested messages, enums, oneof, maps, repeated/packed fields, all standard scalar wire categories, int64 precision, the binary native-fetch bridge envelope, and HTTP error handling.
- Android metadata verified as versionCode 7 / versionName 1.0.7.
- ZIP integrity is checked separately when this report is packaged.

## 6. Verification not completed

- **No Android APK build was produced.** `gradle/wrapper/gradle-wrapper.jar` is missing; invoking `bash gradlew :app:assembleDebug` fails because that JAR is unavailable. No system Gradle installation or Android SDK was found.
- A targeted Kotlin compiler attempt could not type-check the changed Android classes because Android, Compose, coroutine, and project dependencies are not present on the standalone compiler classpath. It reported dependency-resolution errors; it is not a successful compile.
- No emulator or physical-device test was possible.
- No live website/repository test was performed. Search, authentication/session reuse, real protobuf endpoints, custom scripts from actual plugins, Cloudflare challenges, and chapter rendering still require validation in the app.

## Reference contract

Implementation was checked against the official LNReader plugin documentation: https://github.com/LNReader/lnreader-plugins/blob/master/docs/docs.md
