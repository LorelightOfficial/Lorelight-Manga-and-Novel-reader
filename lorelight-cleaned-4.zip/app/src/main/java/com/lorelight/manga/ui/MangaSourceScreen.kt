package com.lorelight.manga.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.browse.ui.AdultSources
import com.lorelight.browse.ui.SourceCoverShape
import com.lorelight.browse.ui.SourceDisplayPrefs
import com.lorelight.browse.ui.SourceDisplaySettingsSheet
import com.lorelight.browse.ui.SourceGridSpacing
import com.lorelight.browse.ui.SourceLayoutMode
import com.lorelight.browse.ui.SourceLibraryFilter
import com.lorelight.browse.ui.SourceNsfwMode
import com.lorelight.browse.ui.SourceTitleSize
import com.lorelight.data.model.isManga
import com.lorelight.manga.model.sanitizedMangas
import com.lorelight.manga.util.MangaNamingUtils
import com.lorelight.ui.animation.BookGridSkeleton
import com.lorelight.ui.animation.StaggeredItem
import eu.kanade.tachiyomi.source.CatalogueSource
import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.SManga
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import tachiyomi.domain.source.service.SourceManager
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

internal enum class SourceListingMode {
    POPULAR,
    LATEST,
    SEARCH
}

internal data class FirstPageCacheKey(val sourceId: Long, val mode: SourceListingMode, val query: String)
internal data class FirstPageCacheEntry(
    val mangas: List<SManga>,
    val hasNextPage: Boolean,
    val timestamp: Long
)

internal object MangaFirstPageCache {
    private const val TTL_MS = 5 * 60 * 1000L
    private val cache = mutableMapOf<FirstPageCacheKey, FirstPageCacheEntry>()

    fun get(sourceId: Long, mode: SourceListingMode, query: String): FirstPageCacheEntry? {
        val key = FirstPageCacheKey(sourceId, mode, query)
        val entry = cache[key] ?: return null
        if (System.currentTimeMillis() - entry.timestamp > TTL_MS) {
            cache.remove(key)
            return null
        }
        return entry
    }

    fun put(sourceId: Long, mode: SourceListingMode, query: String, mangas: List<SManga>, hasNextPage: Boolean) {
        val key = FirstPageCacheKey(sourceId, mode, query)
        cache[key] = FirstPageCacheEntry(mangas, hasNextPage, System.currentTimeMillis())
    }

    fun clear() {
        cache.clear()
    }
}

@Composable
fun MangaSourceScreen(
    sourceId: Long,
    startLatest: Boolean = false,
    onBack: () -> Unit,
    onOpenManga: (Long, SManga) -> Unit = { _, _ -> }
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        com.lorelight.core.DevLogStore.append(context, "NAV", "Opened Manga Source screen (id=$sourceId)")
    }
    var isSourceLoading by remember { mutableStateOf(true) }
    var source by remember { mutableStateOf<CatalogueSource?>(null) }

    var mode by remember { mutableStateOf(if (startLatest) SourceListingMode.LATEST else SourceListingMode.POPULAR) }
    var searchActive by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var submittedQuery by remember { mutableStateOf("") }

    // BACK ALIGNMENT: mirrors the in-app search toggle byte for byte, including
    // dropping out of SEARCH listing mode. Before this, Back closed the whole
    // source screen while the arrow/X only closed the search field.
    androidx.activity.compose.BackHandler(enabled = searchActive) {
        searchActive = false
        searchQuery = ""
        if (mode == SourceListingMode.SEARCH) {
            mode = SourceListingMode.POPULAR
        }
    }

    var filters by remember { mutableStateOf<FilterList?>(null) }
    var showFilterSheet by remember { mutableStateOf(false) }

    val settingsVersion by com.lorelight.data.local.AppSettingsSignal.version.collectAsState()

    // Catalog display preferences (layout, covers per row, badges...). Stored in
    // canonical preferences, shared between novel and manga sources.
    var display by remember(settingsVersion) { mutableStateOf(SourceDisplayPrefs.load(context)) }
    var showDisplaySettings by remember { mutableStateOf(false) }

    // Whether the user flagged THIS source as adult. Drives blur / hide.
    var adultSource by remember(sourceId, settingsVersion) { mutableStateOf(AdultSources.isAdult(context, sourceId.toString())) }

    // Manga paths from THIS source that already live in the library, plus the
    // subset marked Completed. Read off the main thread; failures are silent.
    var libraryPaths by remember { mutableStateOf<Set<String>>(emptySet()) }
    var finishedPaths by remember { mutableStateOf<Set<String>>(emptySet()) }
    val needsLibraryLookup = display.showLibraryBadge ||
        display.dimFinished ||
        display.libraryFilter != SourceLibraryFilter.NORMAL
    LaunchedEffect(sourceId, needsLibraryLookup) {
        if (!needsLibraryLookup) {
            libraryPaths = emptySet()
            finishedPaths = emptySet()
        } else {
            val loaded = withContext(Dispatchers.IO) {
                try {
                    val mine = com.lorelight.data.local.NovelPreferences
                        .loadNovelsFromPrefs(context)
                        .filter {
                            it.isManga && (
                                it.pluginId == sourceId.toString() ||
                                it.pluginId == MangaNamingUtils.toPluginId(sourceId) ||
                                it.pluginId == source?.name
                            )
                        }
                    val all = mine.mapNotNull { it.pluginNovelPath }.toSet()
                    val done = mine
                        .filter { it.readingStatus == "Completed" }
                        .mapNotNull { it.pluginNovelPath }
                        .toSet()
                    all to done
                } catch (e: Exception) {
                    emptySet<String>() to emptySet<String>()
                }
            }
            libraryPaths = loaded.first
            finishedPaths = loaded.second
        }
    }

    val mangaList = remember { mutableStateListOf<SManga>() }
    var page by remember { mutableStateOf(1) }
    var hasNextPage by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var loadingMore by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val gridState = rememberLazyGridState()

    // Filtered / reordered list driven by library filter + adult setting
    val displayItems = remember(mangaList.toList(), display.libraryFilter, libraryPaths, display.nsfwMode, adultSource) {
        val base = if (adultSource && display.nsfwMode == SourceNsfwMode.HIDE) {
            emptyList()
        } else {
            mangaList.toList()
        }
        when (display.libraryFilter) {
            SourceLibraryFilter.NORMAL -> base
            SourceLibraryFilter.HIDE_LIBRARY -> base.filterNot { it.url in libraryPaths }
            SourceLibraryFilter.LIBRARY_FIRST -> {
                val (inLib, rest) = base.partition { it.url in libraryPaths }
                inLib + rest
            }
        }
    }

    LaunchedEffect(sourceId) {
        isSourceLoading = true
        try {
            val s = Injekt.get<SourceManager>().get(sourceId) as? CatalogueSource
            source = s
            if (s != null) {
                filters = try {
                    s.getFilterList()
                } catch (e: Throwable) {
                    FilterList()
                }
            }
        } finally {
            isSourceLoading = false
        }
    }

    suspend fun fetchPage(targetPage: Int): MangasPage = withContext(Dispatchers.IO) {
        val s = source ?: throw IllegalStateException("Source not found")
        when (mode) {
            SourceListingMode.POPULAR -> s.getPopularManga(targetPage)
            SourceListingMode.LATEST -> s.getLatestUpdates(targetPage)
            SourceListingMode.SEARCH -> {
                val fList = filters ?: FilterList()
                s.getSearchManga(targetPage, submittedQuery, fList)
            }
        }
    }

    fun reload() {
        if (source == null) return
        val currentMode = mode
        val currentQuery = submittedQuery
        val sId = sourceId

        scope.launch {
            val cached = MangaFirstPageCache.get(sId, currentMode, currentQuery)
            if (cached != null) {
                mangaList.clear()
                mangaList.addAll(cached.mangas)
                hasNextPage = cached.hasNextPage
                page = 1
                loading = false
                error = null

                try {
                    val res = fetchPage(1)
                    val sanitized = res.mangas.sanitizedMangas()
                    mangaList.clear()
                    mangaList.addAll(sanitized)
                    hasNextPage = res.hasNextPage
                    MangaFirstPageCache.put(sId, currentMode, currentQuery, sanitized, res.hasNextPage)
                } catch (e: Throwable) {
                    if (e is kotlinx.coroutines.CancellationException) throw e
                }
            } else {
                loading = true
                error = null
                page = 1
                mangaList.clear()
                try {
                    val res = fetchPage(1)
                    val sanitized = res.mangas.sanitizedMangas()
                    mangaList.clear()
                    mangaList.addAll(sanitized)
                    hasNextPage = res.hasNextPage
                    MangaFirstPageCache.put(sId, currentMode, currentQuery, sanitized, res.hasNextPage)
                } catch (e: Throwable) {
                    if (e is kotlinx.coroutines.CancellationException) throw e
                    error = e.localizedMessage ?: e.message ?: e.toString()
                } finally {
                    loading = false
                }
            }
        }
    }

    LaunchedEffect(source, mode, submittedQuery) {
        if (source != null) {
            reload()
        }
    }

    // Pagination listener
    LaunchedEffect(gridState) {
        snapshotFlow { gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1 }
            .collect { lastIndex ->
                if (!loading && !loadingMore && hasNextPage && mangaList.isNotEmpty() && lastIndex >= displayItems.size - 6) {
                    loadingMore = true
                    val nextPage = page + 1
                    try {
                        val res = fetchPage(nextPage)
                        val existingUrls = mangaList.mapTo(HashSet()) { it.url }
                        mangaList.addAll(res.mangas.sanitizedMangas().filter { it.url !in existingUrls })
                        hasNextPage = res.hasNextPage
                        page = nextPage
                    } catch (e: Throwable) {
                        if (e is kotlinx.coroutines.CancellationException) throw e
                        hasNextPage = false
                    } finally {
                        loadingMore = false
                    }
                }
            }
    }

    if (isSourceLoading) {
        Scaffold { padding ->
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        return
    }

    if (source == null) {
        Scaffold { padding ->
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("Source not found or uninstalled.")
            }
        }
        return
    }

    val currentSource = source!!

    Box(Modifier.fillMaxSize()) {
        Scaffold(
        topBar = {
            Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    MangaSourceActionButton(
                        icon = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        onClick = onBack
                    )
                    Spacer(Modifier.width(6.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = currentSource.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = currentSource.lang.uppercase(),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    MangaSourceActionButton(
                        icon = Icons.Filled.Search,
                        contentDescription = "Search",
                        active = searchActive,
                        onClick = {
                            searchActive = !searchActive
                            if (!searchActive) {
                                searchQuery = ""
                                if (mode == SourceListingMode.SEARCH) {
                                    mode = SourceListingMode.POPULAR
                                }
                            }
                        }
                    )
                    Spacer(Modifier.width(6.dp))

                    if (filters != null && filters!!.isNotEmpty()) {
                        MangaSourceActionButton(
                            icon = Icons.Filled.FilterList,
                            contentDescription = "Filter",
                            active = showFilterSheet,
                            onClick = { showFilterSheet = true }
                        )
                        Spacer(Modifier.width(6.dp))
                    }

                    MangaSourceActionButton(
                        icon = Icons.Filled.Tune,
                        contentDescription = "Display settings",
                        active = showDisplaySettings,
                        onClick = { showDisplaySettings = true }
                    )
                }

                // Search Bar
                if (searchActive) {
                    val focusRequester = remember { FocusRequester() }
                    LaunchedEffect(Unit) { focusRequester.requestFocus() }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BasicTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface),
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = {
                                submittedQuery = searchQuery
                                mode = SourceListingMode.SEARCH
                            }),
                            modifier = Modifier.weight(1f).focusRequester(focusRequester),
                            decorationBox = { inner ->
                                Box {
                                    if (searchQuery.isEmpty()) {
                                        Text("Search manga...", color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                                    }
                                    inner()
                                }
                            }
                        )
                        if (searchQuery.isNotEmpty()) {
                            Icon(
                                Icons.Filled.Close,
                                contentDescription = "Clear",
                                modifier = Modifier.size(18.dp).clickable { searchQuery = "" }
                            )
                        }
                    }
                }

                // Listing Mode Tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val isPopular = mode == SourceListingMode.POPULAR
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isPopular) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant
                            )
                            .border(
                                1.dp,
                                if (isPopular) Color.Transparent else MaterialTheme.colorScheme.outline,
                                RoundedCornerShape(10.dp)
                            )
                            .clickable {
                                mode = SourceListingMode.POPULAR
                                submittedQuery = ""
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            "Popular",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isPopular) MaterialTheme.colorScheme.onPrimary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (currentSource.supportsLatest) {
                        val isLatest = mode == SourceListingMode.LATEST
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (isLatest) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .border(
                                    1.dp,
                                    if (isLatest) Color.Transparent else MaterialTheme.colorScheme.outline,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable {
                                    mode = SourceListingMode.LATEST
                                    submittedQuery = ""
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                "Latest",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isLatest) MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (submittedQuery.isNotEmpty()) {
                        val isSearch = mode == SourceListingMode.SEARCH
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    if (isSearch) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .border(
                                    1.dp,
                                    if (isSearch) Color.Transparent else MaterialTheme.colorScheme.outline,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { mode = SourceListingMode.SEARCH }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                "Search: $submittedQuery",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSearch) MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when {
                loading -> {
                    BookGridSkeleton(columns = if (display.columns > 0) display.columns else 3, itemCount = 12)
                }
                error != null -> {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = error ?: "An error occurred",
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyLarge
                        )
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = { reload() }) {
                            Text("Retry")
                        }
                    }
                }
                displayItems.isEmpty() -> {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = if (adultSource && display.nsfwMode == SourceNsfwMode.HIDE)
                                "Covers from this source are hidden by your adult content setting"
                            else if (mangaList.isNotEmpty())
                                "Everything here is already in your library"
                            else "No manga found.",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                else -> {
                    LazyVerticalGrid(
                        columns = when {
                            display.layout == SourceLayoutMode.LIST -> GridCells.Fixed(1)
                            display.columns > 0 -> GridCells.Fixed(display.columns)
                            display.layout == SourceLayoutMode.COMPACT_GRID -> GridCells.Adaptive(88.dp)
                            else -> GridCells.Adaptive(112.dp)
                        },
                        state = gridState,
                        contentPadding = PaddingValues(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(display.spacing.gap),
                        verticalArrangement = Arrangement.spacedBy(display.spacing.gap),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        itemsIndexed(items = displayItems, key = { _, manga -> manga.url }) { i, manga ->
                            val blurCover = adultSource && display.nsfwMode == SourceNsfwMode.BLUR
                            val inLibrary = manga.url in libraryPaths
                            val dim = display.dimFinished && manga.url in finishedPaths
                            StaggeredItem(index = i, key = manga.url) {
                                if (display.layout == SourceLayoutMode.LIST) {
                                    MangaListRow(
                                        manga = manga,
                                        sourceId = sourceId,
                                        coverRatio = display.coverShape.ratio,
                                        cornerRadius = display.coverCorner.dp,
                                        titleSizeSp = display.titleSize.sp,
                                        inLibrary = inLibrary,
                                        showLibraryBadge = display.showLibraryBadge,
                                        dim = dim,
                                        blurCover = blurCover,
                                        onClick = { onOpenManga(sourceId, manga) }
                                    )
                                } else {
                                    MangaGridCard(
                                        manga = manga,
                                        sourceId = sourceId,
                                        aspectRatio = display.coverShape.ratio,
                                        cornerRadius = display.coverCorner.dp,
                                        showTitle = display.titlesVisible,
                                        titleLines = display.titleLines,
                                        titleSizeSp = display.titleSize.sp,
                                        inLibrary = inLibrary,
                                        showLibraryBadge = display.showLibraryBadge,
                                        dim = dim,
                                        blurCover = blurCover,
                                        onClick = { onOpenManga(sourceId, manga) }
                                    )
                                }
                            }
                        }

                        if (loadingMore) {
                            item(span = { GridItemSpan(maxLineSpan) }) {
                                Box(
                                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CircularProgressIndicator(modifier = Modifier.size(24.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showFilterSheet && filters != null) {
        MangaFilterSheet(
            filters = filters!!,
            onReset = {
                scope.launch {
                    try {
                        filters = currentSource.getFilterList()
                    } catch (e: Throwable) {
                        // ignore
                    }
                }
            },
            onApply = {
                showFilterSheet = false
                mode = SourceListingMode.SEARCH
                reload()
            },
            onDismiss = { showFilterSheet = false }
        )
    }

        SourceDisplaySettingsSheet(
            visible = showDisplaySettings,
            initial = display,
            sourceName = currentSource.name,
            isAdultSource = adultSource,
            onAdultSourceChange = { flagged ->
                adultSource = flagged
                AdultSources.setAdult(context, sourceId.toString(), flagged)
            },
            onApply = { updated ->
                display = updated
                SourceDisplayPrefs.save(context, updated)
            },
            onDismiss = { showDisplaySettings = false }
        )
    }
}

@Composable
private fun MangaGridCard(
    manga: SManga,
    sourceId: Long,
    aspectRatio: Float = 0.7f,
    cornerRadius: Dp = 8.dp,
    showTitle: Boolean = true,
    titleLines: Int = 2,
    titleSizeSp: Int = 11,
    inLibrary: Boolean = false,
    showLibraryBadge: Boolean = true,
    dim: Boolean = false,
    blurCover: Boolean = false,
    onClick: () -> Unit
) {
    val coverShape = RoundedCornerShape(cornerRadius)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(if (dim) 0.42f else 1f)
            .clip(coverShape)
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(aspectRatio)
                .clip(coverShape)
                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), coverShape)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
        ) {
            MangaCoverImage(
                coverUrl = manga.thumbnail_url,
                sourceId = sourceId,
                title = manga.title,
                modifier = Modifier
                    .fillMaxSize()
                    .then(if (blurCover) Modifier.blur(18.dp) else Modifier)
            )

            if (blurCover) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "18+",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
            }

            if (showLibraryBadge && inLibrary) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "In library",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimary,
                        maxLines = 1
                    )
                }
            }
        }

        if (showTitle) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = manga.title,
                style = MaterialTheme.typography.bodySmall,
                fontSize = titleSizeSp.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = titleLines,
                overflow = TextOverflow.Ellipsis,
                lineHeight = (titleSizeSp + 3).sp
            )
        }
    }
}

@Composable
private fun MangaListRow(
    manga: SManga,
    sourceId: Long,
    coverRatio: Float = 0.7f,
    cornerRadius: Dp = 8.dp,
    titleSizeSp: Int = 13,
    inLibrary: Boolean = false,
    showLibraryBadge: Boolean = true,
    dim: Boolean = false,
    blurCover: Boolean = false,
    onClick: () -> Unit
) {
    val rowShape = RoundedCornerShape(cornerRadius)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .alpha(if (dim) 0.42f else 1f)
            .clip(rowShape)
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), rowShape)
            .clickable(onClick = onClick)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .width(48.dp)
                .aspectRatio(coverRatio)
                .clip(RoundedCornerShape(6.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            MangaCoverImage(
                coverUrl = manga.thumbnail_url,
                sourceId = sourceId,
                title = manga.title,
                modifier = Modifier
                    .fillMaxSize()
                    .then(if (blurCover) Modifier.blur(12.dp) else Modifier)
            )
            if (blurCover) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "18+",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
            }
        }

        Spacer(Modifier.width(12.dp))

        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = manga.title,
                style = MaterialTheme.typography.bodyMedium,
                fontSize = titleSizeSp.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            if (showLibraryBadge && inLibrary) {
                Spacer(Modifier.height(4.dp))
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Text(
                        text = "In library",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}

/*
 * The SAME tinted button recipe as the novel source screen
 * (browse/ui/SourceScreen.kt), on purpose: both source screens should read as
 * one family. A genuinely visible fill tinted from the active theme's primary
 * colour, plus a theme-derived outline. Nothing here is hardcoded to one
 * theme's green, so it follows whatever theme is applied.
 *
 * State is carried by BOTH tint strength and outline strength, so an active
 * button is obvious without needing a different colour.
 */
@Composable
private fun MangaSourceActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    val buttonTint = if (active) MaterialTheme.colorScheme.primary.copy(alpha = 0.34f)
    else MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
    val buttonOutline = if (active) MaterialTheme.colorScheme.primary
    else MaterialTheme.colorScheme.primary.copy(alpha = 0.60f)
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(buttonTint)
            .border(1.dp, buttonOutline, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (active) MaterialTheme.colorScheme.primary
            else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.size(18.dp)
        )
    }
}
