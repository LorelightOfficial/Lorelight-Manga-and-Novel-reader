import java.util.Properties
import java.util.Base64

plugins {
    alias(libs.plugins.androidApplication)
    alias(libs.plugins.jetbrainsKotlinAndroid)
    alias(libs.plugins.composeCompiler)
    alias(libs.plugins.ksp)
    alias(libs.plugins.kotlinSerialization)
    alias(libs.plugins.sqldelight)
}

android {
    namespace = "com.lorelight"
    compileSdk = 36
    buildToolsVersion = "36.0.0"

    signingConfigs {
        val ksOut = rootProject.file("debug.keystore")
        create("customDebug") {
            val ksBase64 = rootProject.file("debug.keystore.base64")
            if (ksBase64.exists()) {
                try {
                    val base64Content = ksBase64.readText().replace("\\s".toRegex(), "")
                    val decodedBytes = Base64.getDecoder().decode(base64Content)
                    ksOut.writeBytes(decodedBytes)
                } catch (e: Exception) {
                    println("Failed to decode debug.keystore.base64: ${e.message}")
                }
            }
            if (ksOut.exists()) {
                storeFile = ksOut
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
        create("release") {
            val keystoreFile = rootProject.file("release.keystore")
            val ksBase64Env = System.getenv("RELEASE_KEYSTORE_BASE64")
                ?: System.getenv("KEYSTORE_BASE64")

            if (!keystoreFile.exists() && !ksBase64Env.isNullOrBlank()) {
                try {
                    val cleanBase64 = ksBase64Env.replace("\\s".toRegex(), "")
                    val decodedBytes = Base64.getDecoder().decode(cleanBase64)
                    keystoreFile.writeBytes(decodedBytes)
                } catch (e: Exception) {
                    println("Failed to decode release keystore base64: ${e.message}")
                }
            }

            val envProperties = Properties()
            val envFile = project.rootProject.file(".env")
            if (envFile.exists()) {
                try {
                    envFile.inputStream().use { envProperties.load(it) }
                } catch (_: Exception) {}
            }

            val storePass = System.getenv("RELEASE_STORE_PASSWORD")
                ?: System.getenv("STORE_PASSWORD")
                ?: System.getenv("KEYSTORE_PASSWORD")
                ?: System.getenv("KEY_PASSWORD")
                ?: envProperties.getProperty("RELEASE_STORE_PASSWORD")
                ?: envProperties.getProperty("STORE_PASSWORD")
                ?: envProperties.getProperty("KEY_PASSWORD")
                ?: project.findProperty("RELEASE_STORE_PASSWORD") as String?

            val keyPass = System.getenv("RELEASE_KEY_PASSWORD")
                ?: System.getenv("KEY_PASSWORD")
                ?: envProperties.getProperty("RELEASE_KEY_PASSWORD")
                ?: envProperties.getProperty("KEY_PASSWORD")
                ?: storePass
                ?: project.findProperty("RELEASE_KEY_PASSWORD") as String?

            val alias = System.getenv("RELEASE_KEY_ALIAS")
                ?: System.getenv("KEY_ALIAS")
                ?: envProperties.getProperty("RELEASE_KEY_ALIAS")
                ?: envProperties.getProperty("KEY_ALIAS")
                ?: project.findProperty("RELEASE_KEY_ALIAS") as String?
                ?: "lorelight"

            if (keystoreFile.exists() && !storePass.isNullOrEmpty() && !keyPass.isNullOrEmpty()) {
                storeFile = keystoreFile
                storePassword = storePass
                keyAlias = alias
                keyPassword = keyPass
            } else if (ksOut.exists()) {
                storeFile = ksOut
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            } else {
                gradle.taskGraph.whenReady {
                    if (allTasks.any { it.name.contains("Release") }) {
                        throw GradleException(
                            "Release signing is not configured. " +
                            "Provide release.keystore (or KEYSTORE_BASE64 env) + passwords and alias " +
                            "as environment variables, .env, or GitHub secrets."
                        )
                    }
                }
            }
        }
    }

    defaultConfig {
        applicationId = "com.lorelight.app.fncydd"
        minSdk = 24
        targetSdk = 36
        versionCode = 4
        versionName = "1.0.4"
        // ABI selection now lives in the splits { abi { ... } } block below so
        // the release build can emit one APK per architecture plus a universal
        // one. Do NOT re-add abiFilters here - it collapses every split back to
        // a single architecture.
        
        // Dynamic secure credentials loading from local environment
        val envProperties = Properties()
        val envFile = project.rootProject.file(".env")
        val envExampleFile = project.rootProject.file(".env.example")
        if (envFile.exists()) {
            val fis = envFile.inputStream()
            envProperties.load(fis)
            fis.close()
        } else if (envExampleFile.exists()) {
            val fis = envExampleFile.inputStream()
            envProperties.load(fis)
            fis.close()
        }
        val fontsKey = envProperties.getProperty("FONTS_API_KEY") ?: ""
        buildConfigField("String", "FONTS_API_KEY", "\"$fontsKey\"")
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("customDebug")
        }
        release {
            // R8 code shrinking + resource shrinking ON, obfuscation OFF.
            //
            // Renaming is what breaks reflection-heavy code, and this app is full
            // of it: Injekt resolves singletons by generic type, Room loads
            // *_Impl classes by name, kotlinx.serialization looks up $$serializer
            // companions, and manga extensions are loaded out of foreign APKs.
            // Mihon handles this exactly the same way - its proguard-rules.pro
            // opens with `-dontobfuscate` - so every name survives while dead
            // code and unused resources are still stripped.
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    // One APK per architecture plus a universal fallback, matching Mihon.
    splits {
        abi {
            isEnable = true
            isUniversalApk = true
            reset()
            include("armeabi-v7a", "arm64-v8a", "x86", "x86_64")
        }
    }

    // Drops the dependency-metadata blob Google Play injects. Meaningless for
    // sideloaded builds and it costs bytes.
    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }

    // Lint gets much stricter once minification is on. A warning must never
    // fail a release build.
    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    packaging {
        jniLibs {
            // minSdk 24 + AGP 8 default to useLegacyPackaging = false, which
            // STORES every .so uncompressed in the APK (extractNativeLibs=false).
            // That is the right call for Play delivery, but this app is
            // sideloaded and ships a lot of native code - QuickJS, libarchive,
            // image-decoder, bundled SQLite, ML Kit OCR, zstd - so uncompressed
            // is pure download bloat and R8 can do nothing about it. This is
            // most likely the single biggest reason enabling minify barely moved
            // the APK size: the bulk of the file is not code, it is .so bytes.
            //
            // Trade-off: libs are extracted at install time, so the on-disk
            // install footprint grows. Set this back to false if you ever ship
            // an AAB to Play.
            useLegacyPackaging = true
        }

        // Expanded to Mihon's exclusion set - these are pure metadata files.
        resources.excludes += setOf(
            "META-INF/rxjava.properties",
            "META-INF/DEPENDENCIES",
            "META-INF/LICENSE",
            "META-INF/LICENSE.md",
            "META-INF/LICENSE.txt",
            "META-INF/NOTICE",
            "META-INF/NOTICE.md",
            "META-INF/README.md",
            "META-INF/*.properties",
            "META-INF/*.version",
            "META-INF/**/*.properties",
            "META-INF/**/LICENSE.txt",
            "META-INF/versions/9/OSGI-INF/MANIFEST.MF",
            "kotlin-tooling-metadata.json",
            "LICENSE.txt",
        )
    }
    // 70 locales ship today (the i18n module plus AndroidX/Material/GMS
    // translations). Resource shrinking never removes alternate locales, so
    // this is the biggest size lever R8 cannot touch - worth roughly 2-4 MB.
    // Left OFF deliberately: dropping translations is a product decision, not a
    // build optimisation. Uncomment to ship a subset.
    // androidResources {
    //     localeFilters += listOf(
    //         "en", "hi", "ta", "es", "fr", "de", "pt-rBR", "ru", "ja", "zh-rCN",
    //     )
    // }

    buildFeatures {
        compose = true
        buildConfig = true
        aidl = true
    }

    sqldelight {
        databases {
            create("Database") {
                packageName.set("tachiyomi.data")
                dialect(libs.sqldelight.sqliteDialect338)
                schemaOutputDirectory.set(project.file("./src/main/sqldelight"))
                generateAsync.set(true)
            }
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

// The 'unifile' AAR declares minCompileSdk=37 simply because it was built with
// the Android 17 SDK. It is a small DocumentFile fork that uses no API newer
// than 36, and the android-37 platform is not installable on CI runners, so we
// skip AGP's AAR metadata gate instead of forcing an AGP 9 migration.
tasks.matching { it.name.startsWith("check") && it.name.endsWith("AarMetadata") }
    .configureEach { enabled = false }

dependencies {
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation(libs.androidx.material.icons.core)
    implementation(libs.androidx.material.icons.extended)
    // Google Material Components (DynamicColors), androidx SQLite bundled driver,
    // and natural-order string comparator - required by the ported Mihon backend.
    implementation(libs.google.material)
    implementation(libs.androidx.sqlite.bundled)
    implementation(libs.natural.comparator)
    implementation("org.jsoup:jsoup:1.17.2")
    implementation("io.coil-kt:coil-compose:2.6.0")

    // Screen-based manga TTS: bundled Latin OCR model. Bundled (not the
    // play-services variant) so it works fully offline on sideloaded builds
    // and adds no Google Play Services dependency.
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("androidx.compose.ui:ui-text-google-fonts:1.6.8")
    implementation("androidx.profileinstaller:profileinstaller:1.3.1")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("dev.chrisbanes.haze:haze:0.7.0")

    // QuickJS JS engine for running LNReader plugins
    implementation(libs.quickjs.wrapper)

    // Mihon manga backend: DI (Injekt) + SQLDelight data layer + i18n string
    // resources, brought in verbatim so the manga backend matches Mihon's own
    // architecture with no variation.
    implementation(libs.injekt)
    implementation(libs.kotlinx.datetime)
    api(libs.bundles.sqldelight)
    implementation(project(":i18n"))
    implementation(libs.xmlutil.core)
    implementation(libs.xmlutil.serialization)

    // OkHttp — bumped to 5.4.0 to match Mihon (libs.versions.toml) so dynamically
    // loaded manga extensions can resolve okhttp3.brotli.* and okhttp3.zstd.* at runtime.
    implementation("com.squareup.okhttp3:okhttp:5.4.0")
    implementation("com.squareup.okhttp3:logging-interceptor:5.4.0")
    implementation("com.squareup.okhttp3:okhttp-brotli:5.4.0")
    implementation("com.squareup.okhttp3:okhttp-dnsoverhttps:5.4.0")
    implementation("com.squareup.okhttp3:okhttp-zstd:5.4.0")
    implementation("com.squareup.okio:okio:3.18.1")

    // Room database
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    // WorkManager
    implementation(libs.androidx.work.runtime.ktx)

    // ---- Manga (Mihon extension host) ----
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("io.reactivex:rxjava:1.3.8")
    implementation("com.github.mihonapp:injekt:91edab2317")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.8.1")
    // pinned >= 1.8.0 because extension serializers rely on the default typeParametersSerializers() implementation (kotlinx.serialization #2968); upstream Mihon 0.20.4 pins 1.11.0.
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json-okio:1.8.1")
    // Mihon backend runtime deps that were previously missing from the build:
    // protobuf (extension-repo wire format), logcat (logging facade), the native
    // image decoder (tachiyomi.decoder), and Jake Wharton's disk LRU cache.
    // protobuf pinned to 1.8.1 to match the kotlinx-serialization core above.
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-protobuf:1.8.1")
    implementation("com.squareup.logcat:logcat:0.4")
    implementation("com.github.mihonapp:image-decoder:e03b81e18a")
    implementation("com.jakewharton:disklrucache:2.0.2")
    implementation("androidx.preference:preference-ktx:1.2.1")
    implementation("net.engawapg.lib:zoomable:1.6.2")
    // Mihon archive reader (epub/cbz) + Shizuku extension installer support
    implementation(libs.archive)
    implementation(libs.unifile)
    implementation(libs.bundles.shizuku)

    debugImplementation(libs.androidx.ui.tooling)
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.12.1")
    testImplementation("wang.harlon.quickjs:wrapper-java:3.2.3")
}
