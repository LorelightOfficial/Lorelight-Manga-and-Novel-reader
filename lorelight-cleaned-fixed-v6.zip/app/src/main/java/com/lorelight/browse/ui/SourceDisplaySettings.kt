package com.lorelight.browse.ui

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.data.local.AppPrefs
import com.lorelight.ui.theme.GlassPanel
import kotlin.math.roundToInt

/**
 * Display preferences for the source catalog screen.
 *
 * Everything here is purely presentational - it changes how the catalog grid is
 * drawn, never what is fetched - and is persisted in the canonical settings
 * store so the choice survives app restarts and is covered by backup.
 */

enum class SourceLayoutMode(val label: String) {
    COMFORTABLE_GRID("Grid"),
    COMPACT_GRID("Compact"),
    COVER_ONLY("Cover only"),
    LIST("List")
}

enum class SourceCoverShape(val label: String, val ratio: Float) {
    BOOK("Book 2:3", 0.66f),
    CLASSIC("Classic 3:4", 0.75f),
    TALL("Tall 3:5", 0.60f),
    SQUARE("Square", 1.0f)
}

enum class SourceGridSpacing(val label: String, val gap: Dp) {
    TIGHT("Tight", 6.dp),
    NORMAL("Normal", 12.dp),
    ROOMY("Roomy", 18.dp)
}

/** What to do with catalog results that are already in the library. */
enum class SourceLibraryFilter(val label: String) {
    NORMAL("Normal"),
    LIBRARY_FIRST("Library first"),
    HIDE_LIBRARY("Hide added")
}

/** How covers from a source flagged as adult are drawn. */
enum class SourceNsfwMode(val label: String) {
    SHOW("Show"),
    BLUR("Blur"),
    HIDE("Hide")
}

/** Title text size presets, in sp. */
enum class SourceTitleSize(val label: String, val sp: Int) {
    SMALL("Small", 11),
    MEDIUM("Medium", 13),
    LARGE("Large", 15)
}

data class SourceDisplayPrefs(
    /** Grid / compact / cover-only / list. */
    val layout: SourceLayoutMode = SourceLayoutMode.COMFORTABLE_GRID,
    /** Covers per row. 0 means "Auto" (fits as many as the screen allows). */
    val columns: Int = 0,
    val coverShape: SourceCoverShape = SourceCoverShape.BOOK,
    val spacing: SourceGridSpacing = SourceGridSpacing.NORMAL,
    /** Cover corner roundness, in dp (0 = square corners). Minimum by default. */
    val coverCorner: Int = 0,
    val showTitles: Boolean = true,
    /** How many lines a title may wrap to before ellipsizing. */
    val titleLines: Int = 2,
    val titleSize: SourceTitleSize = SourceTitleSize.SMALL,
    val showChapterBadge: Boolean = true,
    val showLibraryBadge: Boolean = true,
    val libraryFilter: SourceLibraryFilter = SourceLibraryFilter.NORMAL,
    /** Fade out novels you have marked Completed. */
    val dimFinished: Boolean = false,
    /** Request smaller, cheaper cover bitmaps. */
    val dataSaver: Boolean = false,
    val nsfwMode: SourceNsfwMode = SourceNsfwMode.BLUR
) {
    /** Cover-only mode hides titles no matter what the title switch says. */
    val titlesVisible: Boolean get() = showTitles && layout != SourceLayoutMode.COVER_ONLY

    companion object {
        private const val KEY_LAYOUT = "source_display_layout"
        private const val KEY_COLUMNS = "source_display_columns"
        private const val KEY_SHAPE = "source_display_cover_shape"
        private const val KEY_SPACING = "source_display_spacing"
        private const val KEY_CORNER = "source_display_cover_corner"
        private const val KEY_TITLES = "source_display_show_titles"
        private const val KEY_TITLE_LINES = "source_display_title_lines"
        private const val KEY_TITLE_SIZE = "source_display_title_size"
        private const val KEY_CH_BADGE = "source_display_chapter_badge"
        private const val KEY_LIB_BADGE = "source_display_library_badge"
        private const val KEY_LIB_FILTER = "source_display_library_filter"
        private const val KEY_DIM_DONE = "source_display_dim_finished"
        private const val KEY_DATA_SAVER = "source_display_data_saver"
        private const val KEY_NSFW_MODE = "source_display_nsfw_mode"

        fun load(context: Context): SourceDisplayPrefs {
            val p = AppPrefs.get(context)
            val d = SourceDisplayPrefs()
            return SourceDisplayPrefs(
                layout = runCatching {
                    SourceLayoutMode.valueOf(p.getString(KEY_LAYOUT, d.layout.name) ?: d.layout.name)
                }.getOrDefault(d.layout),
                columns = p.getInt(KEY_COLUMNS, d.columns).coerceIn(0, 6),
                coverShape = runCatching {
                    SourceCoverShape.valueOf(p.getString(KEY_SHAPE, d.coverShape.name) ?: d.coverShape.name)
                }.getOrDefault(d.coverShape),
                spacing = runCatching {
                    SourceGridSpacing.valueOf(p.getString(KEY_SPACING, d.spacing.name) ?: d.spacing.name)
                }.getOrDefault(d.spacing),
                coverCorner = p.getInt(KEY_CORNER, d.coverCorner).coerceIn(0, 24),
                showTitles = p.getBoolean(KEY_TITLES, d.showTitles),
                titleLines = p.getInt(KEY_TITLE_LINES, d.titleLines).coerceIn(1, 3),
                titleSize = runCatching {
                    SourceTitleSize.valueOf(p.getString(KEY_TITLE_SIZE, d.titleSize.name) ?: d.titleSize.name)
                }.getOrDefault(d.titleSize),
                showChapterBadge = p.getBoolean(KEY_CH_BADGE, d.showChapterBadge),
                showLibraryBadge = p.getBoolean(KEY_LIB_BADGE, d.showLibraryBadge),
                libraryFilter = runCatching {
                    SourceLibraryFilter.valueOf(p.getString(KEY_LIB_FILTER, d.libraryFilter.name) ?: d.libraryFilter.name)
                }.getOrDefault(d.libraryFilter),
                dimFinished = p.getBoolean(KEY_DIM_DONE, d.dimFinished),
                dataSaver = p.getBoolean(KEY_DATA_SAVER, d.dataSaver),
                nsfwMode = runCatching {
                    SourceNsfwMode.valueOf(p.getString(KEY_NSFW_MODE, d.nsfwMode.name) ?: d.nsfwMode.name)
                }.getOrDefault(d.nsfwMode)
            )
        }

        fun save(context: Context, prefs: SourceDisplayPrefs) {
            AppPrefs.get(context).edit()
                .putString(KEY_LAYOUT, prefs.layout.name)
                .putInt(KEY_COLUMNS, prefs.columns)
                .putString(KEY_SHAPE, prefs.coverShape.name)
                .putString(KEY_SPACING, prefs.spacing.name)
                .putInt(KEY_CORNER, prefs.coverCorner)
                .putBoolean(KEY_TITLES, prefs.showTitles)
                .putInt(KEY_TITLE_LINES, prefs.titleLines)
                .putString(KEY_TITLE_SIZE, prefs.titleSize.name)
                .putBoolean(KEY_CH_BADGE, prefs.showChapterBadge)
                .putBoolean(KEY_LIB_BADGE, prefs.showLibraryBadge)
                .putString(KEY_LIB_FILTER, prefs.libraryFilter.name)
                .putBoolean(KEY_DIM_DONE, prefs.dimFinished)
                .putBoolean(KEY_DATA_SAVER, prefs.dataSaver)
                .putString(KEY_NSFW_MODE, prefs.nsfwMode.name)
                .apply()
        }
    }
}

/**
 * Per-source "this is an adult source" flag. The novel plugins carry no rating
 * metadata, so the user marks a source once and every cover from it then obeys
 * the blur/hide choice in [SourceDisplayPrefs.nsfwMode].
 */
object AdultSources {
    private fun key(pluginId: String) = "source_adult_flag_$pluginId"

    fun isAdult(context: Context, pluginId: String): Boolean =
        AppPrefs.get(context).getBoolean(key(pluginId), false)

    fun setAdult(context: Context, pluginId: String, adult: Boolean) {
        AppPrefs.get(context).edit().putBoolean(key(pluginId), adult).apply()
    }
}

/**
 * Right-side slide-in panel that edits [SourceDisplayPrefs]. Every change is reported
 * immediately through [onApply] so the grid behind the panel updates live.
 */
@Composable
fun SourceDisplaySettingsSheet(
    initial: SourceDisplayPrefs,
    sourceName: String = "this source",
    isAdultSource: Boolean = false,
    onAdultSourceChange: (Boolean) -> Unit = {},
    onApply: (SourceDisplayPrefs) -> Unit,
    onDismiss: () -> Unit,
    visible: Boolean = true
) {
    if (visible) {
        BackHandler(onBack = onDismiss)
    }

    var prefs by remember(initial) { mutableStateOf(initial) }

    fun update(next: SourceDisplayPrefs) {
        prefs = next
        onApply(next)
    }

    val layouts = SourceLayoutMode.values().toList()
    val shapes = SourceCoverShape.values().toList()
    val spacings = SourceGridSpacing.values().toList()
    val filters = SourceLibraryFilter.values().toList()
    val titleSizes = SourceTitleSize.values().toList()
    val nsfwModes = SourceNsfwMode.values().toList()

    AnimatedVisibility(
        visible = visible,
        enter = slideInHorizontally(
            initialOffsetX = { it },
            animationSpec = tween(260, easing = FastOutSlowInEasing)
        ) + fadeIn(tween(200)),
        exit = slideOutHorizontally(
            targetOffsetX = { it },
            animationSpec = tween(240)
        ) + fadeOut(tween(180))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(0.55f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { onDismiss() }
        ) {
            GlassPanel(
                shape = RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp),
                tintAlpha = 0.88f,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .fillMaxWidth(0.70f)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        enabled = true
                    ) {}
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 20.dp, vertical = 20.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                "Display",
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "Changes apply instantly and are remembered for every source.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Close",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                    ) {
                        DisplaySectionHeader("Layout")

                        DisplayChipRow(
                            label = "Layout",
                            options = layouts.map { it.label },
                            selectedIndex = layouts.indexOf(prefs.layout),
                            onSelect = { update(prefs.copy(layout = layouts[it])) }
                        )

                        if (prefs.layout != SourceLayoutMode.LIST) {
                            val columnLabels = listOf("Auto", "2", "3", "4", "5", "6")
                            DisplayChipRow(
                                label = "Covers per row",
                                options = columnLabels,
                                selectedIndex = if (prefs.columns == 0) 0 else prefs.columns - 1,
                                onSelect = { idx -> update(prefs.copy(columns = if (idx == 0) 0 else idx + 1)) }
                            )

                            DisplayChipRow(
                                label = "Cover shape",
                                options = shapes.map { it.label },
                                selectedIndex = shapes.indexOf(prefs.coverShape),
                                onSelect = { update(prefs.copy(coverShape = shapes[it])) }
                            )

                            DisplayChipRow(
                                label = "Grid spacing",
                                options = spacings.map { it.label },
                                selectedIndex = spacings.indexOf(prefs.spacing),
                                onSelect = { update(prefs.copy(spacing = spacings[it])) }
                            )
                        }

                        // Cover corner roundness, 0dp (sharp) to 24dp (very round).
                        Column(Modifier.padding(bottom = 14.dp)) {
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "COVER CORNERS",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    "${prefs.coverCorner} dp",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Slider(
                                value = prefs.coverCorner.toFloat(),
                                onValueChange = { update(prefs.copy(coverCorner = it.roundToInt().coerceIn(0, 24))) },
                                valueRange = 0f..24f,
                                steps = 11,
                                colors = SliderDefaults.colors(
                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                )
                            )
                        }

                        DisplaySectionHeader("Text")

                        if (prefs.layout != SourceLayoutMode.COVER_ONLY) {
                            DisplayToggleRow(
                                title = "Show titles",
                                subtitle = "Novel name under each cover",
                                checked = prefs.showTitles,
                                onCheckedChange = { update(prefs.copy(showTitles = it)) }
                            )

                            if (prefs.showTitles) {
                                DisplayChipRow(
                                    label = "Title text size",
                                    options = titleSizes.map { it.label },
                                    selectedIndex = titleSizes.indexOf(prefs.titleSize),
                                    onSelect = { update(prefs.copy(titleSize = titleSizes[it])) }
                                )

                                if (prefs.layout != SourceLayoutMode.LIST) {
                                    DisplayChipRow(
                                        label = "Title lines",
                                        options = listOf("1", "2", "3"),
                                        selectedIndex = prefs.titleLines - 1,
                                        onSelect = { update(prefs.copy(titleLines = it + 1)) }
                                    )
                                }
                            }
                        }

                        DisplaySectionHeader("Badges and states")

                        DisplayToggleRow(
                            title = "Chapter count badge",
                            subtitle = "Show how many chapters a novel has, when known",
                            checked = prefs.showChapterBadge,
                            onCheckedChange = { update(prefs.copy(showChapterBadge = it)) }
                        )

                        DisplayToggleRow(
                            title = "In-library badge",
                            subtitle = "Mark novels you have already added to your library",
                            checked = prefs.showLibraryBadge,
                            onCheckedChange = { update(prefs.copy(showLibraryBadge = it)) }
                        )

                        DisplayToggleRow(
                            title = "Dim finished novels",
                            subtitle = "Fade titles you marked Completed so new ones stand out",
                            checked = prefs.dimFinished,
                            onCheckedChange = { update(prefs.copy(dimFinished = it)) }
                        )

                        DisplayChipRow(
                            label = "Novels already in library",
                            options = filters.map { it.label },
                            selectedIndex = filters.indexOf(prefs.libraryFilter),
                            onSelect = { update(prefs.copy(libraryFilter = filters[it])) }
                        )

                        DisplaySectionHeader("Data and privacy")

                        DisplayToggleRow(
                            title = "Data saver covers",
                            subtitle = "Download smaller, lighter cover images",
                            checked = prefs.dataSaver,
                            onCheckedChange = { update(prefs.copy(dataSaver = it)) }
                        )

                        DisplayToggleRow(
                            title = "Adult source",
                            subtitle = "Treat covers from $sourceName as adult content",
                            checked = isAdultSource,
                            onCheckedChange = onAdultSourceChange
                        )

                        if (isAdultSource) {
                            DisplayChipRow(
                                label = "Adult covers",
                                options = nsfwModes.map { it.label },
                                selectedIndex = nsfwModes.indexOf(prefs.nsfwMode),
                                onSelect = { update(prefs.copy(nsfwMode = nsfwModes[it])) }
                            )
                        }

                        Spacer(Modifier.height(12.dp))
                    }

                    Spacer(Modifier.height(12.dp))
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { update(SourceDisplayPrefs()) }) {
                            Text("Reset to default")
                        }
                        Button(onClick = onDismiss) {
                            Text("Done")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DisplaySectionHeader(title: String) {
    Column {
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        Spacer(Modifier.height(12.dp))
        Text(
            title,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(Modifier.height(10.dp))
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun DisplayChipRow(
    label: String,
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit
) {
    Column(Modifier.padding(bottom = 14.dp)) {
        Text(
            label.uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(8.dp))
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEachIndexed { index, option ->
                val selected = index == selectedIndex
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (selected) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                        .border(
                            1.dp,
                            if (selected) Color.Transparent else MaterialTheme.colorScheme.outline,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { onSelect(index) }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = option,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (selected) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun DisplayToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
            Spacer(Modifier.height(2.dp))
            Text(
                subtitle,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            )
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
