package com.lorelight.browse.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.lorelight.browse.js.JSPluginEngine
import com.lorelight.browse.model.SourceNovelItem
import kotlinx.coroutines.launch

private data class SourceSearchState(
    val pluginId: String,
    val name: String,
    val site: String,
    val loading: Boolean,
    val items: List<SourceNovelItem>,
    val error: String?
)

/** Global search across all installed sources, grouped per source. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlobalSearchScreen(
    onBack: () -> Unit,
    onOpenNovel: (String, SourceNovelItem) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val vm: BrowseViewModel = viewModel()
    val installed by vm.installed.collectAsState()

    LaunchedEffect(Unit) { vm.loadInstalled(context) }

    var query by remember { mutableStateOf("") }
    var submitted by remember { mutableStateOf(false) }
    val results = remember { mutableStateListOf<SourceSearchState>() }

    fun runSearch() {
        val q = query.trim()
        if (q.isBlank()) return
        submitted = true
        results.clear()
        results.addAll(installed.map {
            SourceSearchState(it.info.id, it.info.name, it.info.site, true, emptyList(), null)
        })
        installed.forEach { ip ->
            scope.launch {
                try {
                    val res = JSPluginEngine.searchNovels(context.applicationContext, ip.info.id, q, 1)
                    val idx = results.indexOfFirst { it.pluginId == ip.info.id }
                    if (idx >= 0) results[idx] = results[idx].copy(loading = false, items = res)
                } catch (e: Exception) {
                    val idx = results.indexOfFirst { it.pluginId == ip.info.id }
                    if (idx >= 0) results[idx] = results[idx].copy(loading = false, error = e.message ?: "Failed")
                }
            }
        }
    }

    Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            TopAppBar(
                windowInsets = WindowInsets(0, 0, 0, 0),
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    TextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        placeholder = { Text("Search all sources") },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { runSearch() }),
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                actions = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, contentDescription = "Clear") }
                    }
                }
            )
        }
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when {
                installed.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Install a source first", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                !submitted -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Type a title and press search", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                else -> LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(results.size) { i ->
                        SourceResultBlock(results[i], onOpenNovel)
                    }
                }
            }
        }
    }
}

@Composable
private fun SourceResultBlock(r: SourceSearchState, onOpenNovel: (String, SourceNovelItem) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(r.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (r.loading) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
        }
        when {
            r.error != null -> Text(
                r.error,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            !r.loading && r.items.isEmpty() -> Text(
                "No results",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            else -> {
                val context = LocalContext.current
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(r.items.size) { i ->
                        val novel = r.items[i]
                        val request = remember(novel.cover, r.site) {
                            val coverUrl = novel.cover
                            if (coverUrl.isNullOrBlank()) null
                            else {
                                ImageRequest.Builder(context)
                                    .data(coverUrl)
                                    .memoryCacheKey(coverUrl)
                                    .diskCacheKey(coverUrl)
                                    .placeholderMemoryCacheKey(coverUrl)
                                    .crossfade(true)
                                    .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                                    .apply {
                                        if (r.site.isNotBlank()) addHeader("Referer", r.site)
                                    }
                                    .build()
                            }
                        }
                        Column(
                            Modifier
                                .width(100.dp)
                                .clickable { onOpenNovel(r.pluginId, novel) }
                        ) {
                            AsyncImage(
                                model = request,
                                contentDescription = novel.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .width(100.dp)
                                    .aspectRatio(0.7f)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(novel.name, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}
