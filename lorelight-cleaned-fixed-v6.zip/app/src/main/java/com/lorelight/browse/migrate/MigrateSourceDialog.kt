package com.lorelight.browse.migrate

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.data.model.Novel
import com.lorelight.ui.components.LorelightDialog
import kotlinx.coroutines.launch

/**
 * Source transfer dialog. Walks the selected novels one at a time, always
 * showing the candidate list for confirmation (never auto-picking), and hands
 * the rewritten novels back through [onApplied].
 */
@Composable
fun MigrateSourceDialog(
    novels: List<Novel>,
    onDismiss: () -> Unit,
    onApplied: (List<Novel>) -> Unit
) {
    if (novels.isEmpty()) {
        LorelightDialog(
            onDismissRequest = onDismiss,
            title = "Transfer source",
            text = "Select at least one novel first.",
            icon = Icons.Filled.SwapHoriz,
            confirmText = "OK",
            onConfirm = onDismiss
        )
        return
    }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var phase by remember { mutableStateOf("source") }
    var targetId by remember { mutableStateOf("") }
    var targetName by remember { mutableStateOf("") }
    var index by remember { mutableStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }

    val candidates = remember { mutableStateListOf<MigrationCandidate>() }
    val results = remember { mutableStateListOf<MigrationResult>() }
    val skipped = remember { mutableStateListOf<String>() }

    val commonPluginId = remember(novels) {
        val ids = novels.map { it.pluginId ?: "" }.distinct()
        if (ids.size == 1) ids[0] else null
    }
    val targets = remember(commonPluginId) {
        NovelSourceMigrator.installedTargets(context, commonPluginId)
    }

    val current = novels.getOrNull(index)
    val divider = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f)

    fun runSearch(term: String) {
        val n = current ?: return
        val q = if (term.isBlank()) n.title else term
        loading = true
        error = null
        scope.launch {
            var failure: String? = null
            val found = try {
                NovelSourceMigrator.searchCandidates(context, targetId, targetName, q)
            } catch (e: Exception) {
                failure = e.message ?: "Search failed."
                emptyList()
            }
            candidates.clear()
            candidates.addAll(found)
            error = failure ?: if (found.isEmpty()) "Nothing found on " + targetName + ". Edit the title and search again." else null
            loading = false
        }
    }

    fun advance() {
        candidates.clear()
        error = null
        if (index + 1 < novels.size) {
            index += 1
        } else {
            phase = "done"
        }
    }

    fun transfer(candidate: MigrationCandidate) {
        val n = current ?: return
        loading = true
        error = null
        scope.launch {
            try {
                val r = NovelSourceMigrator.migrate(context, n, candidate)
                results.add(r)
                loading = false
                advance()
            } catch (e: Exception) {
                loading = false
                error = e.message ?: "Transfer failed."
            }
        }
    }

    LaunchedEffect(phase, index, targetId) {
        if (phase == "match" && targetId.isNotBlank()) {
            val n = novels.getOrNull(index)
            if (n != null) {
                query = n.title
                runSearch(n.title)
            }
        }
    }

    when (phase) {
        "source" -> LorelightDialog(
            onDismissRequest = onDismiss,
            title = "Transfer to another source",
            text = if (targets.isEmpty()) "No other novel sources are installed. Add one from Browse first." else "Move " + novels.size + " novel(s) to:",
            icon = Icons.Filled.SwapHoriz,
            dismissText = "Cancel",
            onDismiss = onDismiss,
            content = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 320.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    targets.forEach { t ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    targetId = t.info.id
                                    targetName = t.info.name
                                    phase = "match"
                                }
                                .padding(vertical = 12.dp, horizontal = 4.dp)
                        ) {
                            Text(
                                text = t.info.name,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = t.info.site,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(0.7.dp)
                                .background(divider)
                        )
                    }
                }
            }
        )

        "match" -> LorelightDialog(
            onDismissRequest = onDismiss,
            title = "Find on " + targetName,
            text = (index + 1).toString() + " of " + novels.size + ": " + (current?.title ?: ""),
            icon = Icons.Filled.SwapHoriz,
            dismissText = "Skip",
            onDismiss = {
                val n = current
                if (n != null) skipped.add(n.title)
                advance()
            },
            content = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { runSearch(query) }) {
                            Text(text = "Search again", fontSize = 12.sp)
                        }
                    }
                    if (loading) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                            Text(
                                text = "   Searching...",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    val err = error
                    if (err != null && !loading) {
                        Text(
                            text = err,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        candidates.forEach { c ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable(enabled = !loading) { transfer(c) }
                                    .padding(vertical = 10.dp, horizontal = 4.dp)
                            ) {
                                Text(
                                    text = c.name,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = c.path,
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(0.7.dp)
                                    .background(divider)
                            )
                        }
                    }
                }
            }
        )

        else -> LorelightDialog(
            onDismissRequest = { onApplied(results.map { it.novel }) },
            title = "Transfer complete",
            text = results.size.toString() + " transferred, " + skipped.size + " skipped.",
            icon = Icons.Filled.SwapHoriz,
            confirmText = "Done",
            onConfirm = { onApplied(results.map { it.novel }) },
            content = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 300.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    results.forEach { r ->
                        val how = when (r.anchorMethod) {
                            AnchorMethod.EXACT_NUMBER -> "matched by chapter number"
                            AnchorMethod.NEAREST_NUMBER -> "nearest chapter number"
                            AnchorMethod.SAME_INDEX -> "same position in list"
                            AnchorMethod.RESET -> "restarted"
                        }
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                        ) {
                            Text(
                                text = r.novel.title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Chapters " + r.oldChapterCount + " to " + r.newChapterCount + ", now on " + r.newChapterName,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Position " + how + ", finished " + r.completedCarried + "/" + r.completedTotal,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(0.7.dp)
                                .background(divider)
                        )
                    }
                    skipped.forEach { t ->
                        Text(
                            text = "Skipped: " + t,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                }
            }
        )
    }
}
