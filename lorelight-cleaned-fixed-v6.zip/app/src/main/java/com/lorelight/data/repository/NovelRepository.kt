package com.lorelight.data.repository

import android.content.Context
import com.lorelight.data.local.NovelPreferences
import com.lorelight.data.model.Novel
import com.lorelight.data.model.Website

class NovelRepository(private val context: Context) {

    fun loadNovels(): List<Novel> {
        return NovelPreferences.loadNovelsFromPrefs(context)
    }

    fun saveNovels(novels: List<Novel>) {
        NovelPreferences.saveNovelsToPrefs(context, novels)
    }

    fun saveNovelsSync(novels: List<Novel>) {
        NovelPreferences.saveNovelsToPrefsSync(context, novels)
    }

    fun loadWebsites(): List<Website> {
        return NovelPreferences.loadWebsitesFromPrefs(context)
    }

    fun saveWebsites(websites: List<Website>) {
        NovelPreferences.saveWebsitesToPrefs(context, websites)
    }

    fun saveWebsitesSync(websites: List<Website>) {
        NovelPreferences.saveWebsitesToPrefsSync(context, websites)
    }
}
