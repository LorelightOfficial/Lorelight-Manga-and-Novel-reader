package com.lorelight.data.local

import android.content.Context
import com.lorelight.crawler.CrawlerEngine
import com.lorelight.data.model.Novel
import java.io.File

object NovelRemovalManager {

    /**
     * Removes a novel from the library according to its source type:
     * - Online novels (from websites/plugins): Deletes downloaded/cached chapter files and
     *   removes the novel from the Library list, but preserves its reading history and
     *   metadata so it remains accessible in History with its details page intact (no loading required).
     * - Imported novels (local EPUBs/files): Completely erases all files from disk storage,
     *   cached chapters, library list, reading history, and bookmarks.
     */
    fun removeNovelFromLibrary(context: Context, novel: Novel) {
        // FIX #15: reading_position keys were never cleaned up, so pos_idx_* /
        // pos_off_* entries accumulated forever for deleted novels.
        com.lorelight.ui.reader.ReadingPositionStore.clearNovel(context, novel.id)

        val isOnline = novel.isOnline || !novel.sourceUrl.isNullOrBlank() || !novel.pluginId.isNullOrBlank()

        if (isOnline) {
            // 1. Delete downloaded chapter text files from offline cache
            deleteDownloadedChapterFiles(context, novel)

            // 2. Remove novel from saved_novels (Library)
            val currentList = NovelPreferences.loadNovelsFromPrefs(context).toMutableList()
            currentList.removeAll { it.id == novel.id || (it.title == novel.title && (it.isOnline || !it.sourceUrl.isNullOrBlank() || !it.pluginId.isNullOrBlank())) }
            NovelPreferences.saveNovelsToPrefsSync(context, currentList, allowEmpty = true)

            // 3. DO NOT delete reading history. History entry keeps novelJson so opening from history
            // works smoothly with details page intact without re-loading.
        } else {
            // IMPORTED / LOCAL NOVEL
            // 1. Delete stored EPUB / local file from app storage
            try {
                val epubsDir = File(context.filesDir, "epubs")
                if (epubsDir.exists() && epubsDir.isDirectory) {
                    val targetEpub = File(epubsDir, "${novel.id}.epub")
                    if (targetEpub.exists()) {
                        targetEpub.delete()
                    }
                    epubsDir.listFiles()?.forEach { file ->
                        if (file.name.contains(novel.id)) {
                            try { file.delete() } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError(context, "NovelRemovalManager.deleteEpub", e) }
                        }
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // 2. Delete cached chapter text files
            deleteDownloadedChapterFiles(context, novel)

            // 3. Remove novel from saved_novels (Library)
            val currentList = NovelPreferences.loadNovelsFromPrefs(context).toMutableList()
            currentList.removeAll { it.id == novel.id || it.title == novel.title }
            NovelPreferences.saveNovelsToPrefsSync(context, currentList, allowEmpty = true)

            // 4. Erase reading history completely
            NovelPreferences.removeHistoryEntry(context, novel.id)

            // 5. Erase bookmarks completely
            NovelPreferences.removeBookmarksForNovel(context, novel.id)
        }
    }

    private fun deleteDownloadedChapterFiles(context: Context, novel: Novel) {
        try {
            // Clear cache using chapter URLs
            if (novel.chapterUrls.isNotEmpty()) {
                CrawlerEngine.clearCacheForUrls(context, novel.chapterUrls)
            }

            // Also search chapters_cache for any files matching novel.id or sanitized id
            val cacheDir = File(context.filesDir, "chapters_cache")
            if (cacheDir.exists() && cacheDir.isDirectory) {
                val sanitizedId = novel.id.replace(Regex("[^a-zA-Z0-9]"), "_")
                cacheDir.listFiles()?.forEach { file ->
                    if (file.name.contains(sanitizedId) || file.name.contains(novel.id)) {
                        try { file.delete() } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError(context, "NovelRemovalManager.deleteChapterFiles", e) }
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
