package com.lorelight.data.download

import android.content.Context
import com.lorelight.network.NetworkThrottle

/**
 * FEATURE: user-facing download tuning.
 *
 * Every knob the two download engines used to hardcode now lives here and is
 * read in one shot via [snapshot]:
 *
 *  - how many chapters are fetched at once (novels: one request per chapter),
 *  - how many pages are fetched at once (manga: 20-200 requests per chapter),
 *  - the politeness gap between chapters and between pages,
 *  - how many times a failed fetch is retried,
 *  - a hard speed ceiling, enforced on the shared HTTP client,
 *  - whether downloads may run on mobile data at all,
 *  - whether novels get the slow second verification sweep.
 *
 * WHY THIS EXISTS: both downloaders were strictly sequential with fixed delays
 * (2s between novel chapters, 120ms between manga pages, one request in flight
 * at a time). On a phone most of a fetch is round-trip latency - DNS, TLS, the
 * server thinking, Cloudflare - during which the socket sits idle. Serialising
 * paid that dead time once per item, back to back, and never overlapped it.
 * Overlapping a handful of requests is where the real speed-up is, so that is
 * what these knobs expose.
 *
 * The defaults are BALANCED, not TURBO, on purpose: sources rate-limit, and
 * getting soft-banned helps nobody.
 */
object DownloadTuning {

    private const val PREFS = "lorelight_download_tuning"

    private const val KEY_PARALLEL_CHAPTERS = "dl_parallel_chapters"
    private const val KEY_PARALLEL_PAGES = "dl_parallel_pages"
    private const val KEY_CHAPTER_DELAY = "dl_chapter_delay_ms"
    private const val KEY_PAGE_DELAY = "dl_page_delay_ms"
    private const val KEY_RETRIES = "dl_retry_attempts"
    private const val KEY_WIFI_ONLY = "dl_wifi_only"
    private const val KEY_VERIFY_PASS = "dl_verify_pass"
    private const val KEY_PRESET = "dl_preset"

    const val MIN_PARALLEL_CHAPTERS = 1
    const val MAX_PARALLEL_CHAPTERS = 5
    const val MIN_PARALLEL_PAGES = 1
    const val MAX_PARALLEL_PAGES = 8
    const val MIN_RETRIES = 1
    const val MAX_RETRIES = 5

    private const val DEFAULT_PARALLEL_CHAPTERS = 2
    private const val DEFAULT_PARALLEL_PAGES = 3
    private const val DEFAULT_CHAPTER_DELAY_MS = 2000L
    private const val DEFAULT_PAGE_DELAY_MS = 120L
    private const val DEFAULT_RETRIES = 3
    private const val DEFAULT_WIFI_ONLY = false
    private const val DEFAULT_VERIFY_PASS = true

    const val PRESET_GENTLE = "gentle"
    const val PRESET_BALANCED = "balanced"
    const val PRESET_TURBO = "turbo"
    const val PRESET_CUSTOM = "custom"

    /** Speed ceilings in KB/s. 0 = unlimited. */
    val SPEED_OPTIONS = listOf(0, 250, 500, 1024, 2048, 5120)

    val CHAPTER_DELAY_OPTIONS = listOf(0L, 500L, 1000L, 2000L, 4000L)

    val PAGE_DELAY_OPTIONS = listOf(0L, 60L, 120L, 250L)

    fun speedLabel(kbps: Int): String = when {
        kbps <= 0 -> "Unlimited"
        kbps >= 1024 && kbps % 1024 == 0 -> (kbps / 1024).toString() + " MB/s"
        else -> kbps.toString() + " KB/s"
    }

    fun delayLabel(ms: Long): String = when {
        ms <= 0L -> "None"
        ms < 1000L -> ms.toString() + " ms"
        ms % 1000L == 0L -> (ms / 1000L).toString() + "s"
        else -> ms.toString() + " ms"
    }

    /**
     * One immutable read of every knob. The engines take this ONCE at the start
     * of a job on purpose: moving a slider mid-download must not reshape a run
     * already in flight, which would make its progress numbers lie.
     */
    data class Snapshot(
        val parallelChapters: Int,
        val parallelPages: Int,
        val chapterDelayMs: Long,
        val pageDelayMs: Long,
        val retryAttempts: Int,
        val wifiOnly: Boolean,
        val verifyPass: Boolean,
        val speedLimitKbps: Int
    )

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun snapshot(context: Context): Snapshot = Snapshot(
        parallelChapters = getParallelChapters(context),
        parallelPages = getParallelPages(context),
        chapterDelayMs = getChapterDelayMs(context),
        pageDelayMs = getPageDelayMs(context),
        retryAttempts = getRetryAttempts(context),
        wifiOnly = isWifiOnly(context),
        verifyPass = isVerifyPassEnabled(context),
        speedLimitKbps = getSpeedLimitKbps(context)
    )

    // ---------------------------------------------------------------- getters

    fun getParallelChapters(context: Context): Int =
        prefs(context).getInt(KEY_PARALLEL_CHAPTERS, DEFAULT_PARALLEL_CHAPTERS)
            .coerceIn(MIN_PARALLEL_CHAPTERS, MAX_PARALLEL_CHAPTERS)

    fun getParallelPages(context: Context): Int =
        prefs(context).getInt(KEY_PARALLEL_PAGES, DEFAULT_PARALLEL_PAGES)
            .coerceIn(MIN_PARALLEL_PAGES, MAX_PARALLEL_PAGES)

    fun getChapterDelayMs(context: Context): Long =
        prefs(context).getLong(KEY_CHAPTER_DELAY, DEFAULT_CHAPTER_DELAY_MS).coerceAtLeast(0L)

    fun getPageDelayMs(context: Context): Long =
        prefs(context).getLong(KEY_PAGE_DELAY, DEFAULT_PAGE_DELAY_MS).coerceAtLeast(0L)

    fun getRetryAttempts(context: Context): Int =
        prefs(context).getInt(KEY_RETRIES, DEFAULT_RETRIES).coerceIn(MIN_RETRIES, MAX_RETRIES)

    fun isWifiOnly(context: Context): Boolean =
        prefs(context).getBoolean(KEY_WIFI_ONLY, DEFAULT_WIFI_ONLY)

    fun isVerifyPassEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_VERIFY_PASS, DEFAULT_VERIFY_PASS)

    /**
     * The speed ceiling lives in NetworkThrottle rather than here, because that
     * is what owns the interceptor on the shared HTTP client. Keeping it there
     * also means it is loaded by the existing NetworkThrottle.init() call from
     * HttpClients.init(), so there is no extra startup wiring to forget.
     */
    fun getSpeedLimitKbps(context: Context): Int =
        NetworkThrottle.getDownloadLimitKbps(context)

    fun getPreset(context: Context): String =
        prefs(context).getString(KEY_PRESET, PRESET_BALANCED) ?: PRESET_BALANCED

    // ---------------------------------------------------------------- setters

    // Any manual change means the active preset no longer describes reality, so
    // these setters drop the label to CUSTOM.

    fun setParallelChapters(context: Context, value: Int) {
        prefs(context).edit()
            .putInt(
                KEY_PARALLEL_CHAPTERS,
                value.coerceIn(MIN_PARALLEL_CHAPTERS, MAX_PARALLEL_CHAPTERS)
            )
            .putString(KEY_PRESET, PRESET_CUSTOM)
            .apply()
    }

    fun setParallelPages(context: Context, value: Int) {
        prefs(context).edit()
            .putInt(KEY_PARALLEL_PAGES, value.coerceIn(MIN_PARALLEL_PAGES, MAX_PARALLEL_PAGES))
            .putString(KEY_PRESET, PRESET_CUSTOM)
            .apply()
    }

    fun setChapterDelayMs(context: Context, value: Long) {
        prefs(context).edit()
            .putLong(KEY_CHAPTER_DELAY, value.coerceAtLeast(0L))
            .putString(KEY_PRESET, PRESET_CUSTOM)
            .apply()
    }

    fun setPageDelayMs(context: Context, value: Long) {
        prefs(context).edit()
            .putLong(KEY_PAGE_DELAY, value.coerceAtLeast(0L))
            .putString(KEY_PRESET, PRESET_CUSTOM)
            .apply()
    }

    fun setRetryAttempts(context: Context, value: Int) {
        prefs(context).edit()
            .putInt(KEY_RETRIES, value.coerceIn(MIN_RETRIES, MAX_RETRIES))
            .putString(KEY_PRESET, PRESET_CUSTOM)
            .apply()
    }

    fun setSpeedLimitKbps(context: Context, kbps: Int) {
        NetworkThrottle.setDownloadLimitKbps(context, kbps)
        prefs(context).edit().putString(KEY_PRESET, PRESET_CUSTOM).apply()
    }

    // Wi-Fi only and the verification pass are orthogonal to the speed presets,
    // so they deliberately do NOT reset the preset label.

    fun setWifiOnly(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_WIFI_ONLY, value).apply()
    }

    fun setVerifyPassEnabled(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_VERIFY_PASS, value).apply()
    }

    // ---------------------------------------------------------------- presets

    /**
     * GENTLE is for sources that ban quickly, TURBO for sources that do not
     * care. BALANCED is the shipping default: what the app did before this
     * screen existed, only two chapters wide instead of one.
     */
    fun applyPreset(context: Context, preset: String) {
        when (preset) {
            PRESET_GENTLE -> writeAll(
                context,
                preset = PRESET_GENTLE,
                chapters = 1,
                pages = 2,
                chapterDelay = 4000L,
                pageDelay = 250L,
                retries = 3,
                speedKbps = 500
            )
            PRESET_TURBO -> writeAll(
                context,
                preset = PRESET_TURBO,
                chapters = 4,
                pages = 6,
                chapterDelay = 0L,
                pageDelay = 0L,
                retries = 2,
                speedKbps = 0
            )
            else -> writeAll(
                context,
                preset = PRESET_BALANCED,
                chapters = DEFAULT_PARALLEL_CHAPTERS,
                pages = DEFAULT_PARALLEL_PAGES,
                chapterDelay = DEFAULT_CHAPTER_DELAY_MS,
                pageDelay = DEFAULT_PAGE_DELAY_MS,
                retries = DEFAULT_RETRIES,
                speedKbps = 0
            )
        }
    }

    fun resetToDefaults(context: Context) {
        applyPreset(context, PRESET_BALANCED)
        setWifiOnly(context, DEFAULT_WIFI_ONLY)
        setVerifyPassEnabled(context, DEFAULT_VERIFY_PASS)
    }

    private fun writeAll(
        context: Context,
        preset: String,
        chapters: Int,
        pages: Int,
        chapterDelay: Long,
        pageDelay: Long,
        retries: Int,
        speedKbps: Int
    ) {
        prefs(context).edit()
            .putInt(KEY_PARALLEL_CHAPTERS, chapters)
            .putInt(KEY_PARALLEL_PAGES, pages)
            .putLong(KEY_CHAPTER_DELAY, chapterDelay)
            .putLong(KEY_PAGE_DELAY, pageDelay)
            .putInt(KEY_RETRIES, retries)
            .putString(KEY_PRESET, preset)
            .apply()
        NetworkThrottle.setDownloadLimitKbps(context, speedKbps)
    }

    // ---------------------------------------------------------------- network

    /**
     * True when the active network is NOT metered. Wrapped in try/catch and
     * defaulting to "allowed" on failure on purpose: an OEM quirk or a missing
     * permission must never silently block every download in the app.
     */
    fun isUnmetered(context: Context): Boolean {
        return try {
            val cm = context.applicationContext
                .getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
                ?: return true
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
        } catch (t: Throwable) {
            true
        }
    }

    /** Null when downloading is allowed, otherwise the reason to show the user. */
    fun blockedReason(context: Context, snapshot: Snapshot): String? {
        if (!snapshot.wifiOnly) return null
        if (isUnmetered(context)) return null
        return "Waiting for Wi-Fi: downloads are set to Wi-Fi only in Settings."
    }
}
