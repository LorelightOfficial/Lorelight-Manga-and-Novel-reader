/*
 * =============================================================================
 * CompanionTalk.kt - making the face look like it is speaking.
 * Package: com.lorelight.companion
 *
 * WHY IT IS WRITTEN THIS WAY
 *
 * CelestialFaceState already owns ten Animatables and an idle loop that keeps
 * the character alive. Fighting that engine for control would mean either
 * rewriting it or racing it. Instead this file uses the engine's own
 * `pinnedSnapshot` hook: while he is talking we compute the entire face
 * ourselves, frame by frame, and pin it. The idle loop keeps running
 * harmlessly underneath and takes over again the instant we unpin.
 *
 * So CelestialBody.kt is not modified at all. Nothing about the existing
 * character can regress.
 *
 * THE THREE BEATS
 *
 *   NOTICE   he registers that he is about to speak - brows lift, eyes open
 *            a little, a small tilt. The sun rebounds into it; the moon
 *            drifts. Without this beat the mouth just starts flapping and it
 *            looks like a glitch.
 *   SPEAK    a looping murmur pulse at the mood's cadence P, with slow
 *            overlays on brows, tilt and pupils on periods that are multiples
 *            of P but never equal to it - so nothing ever lines up into an
 *            obvious loop.
 *   SETTLE   back to rest, ending on a slow blink for the sun.
 *
 * THE ONE THING THAT MATTERS MOST
 *
 * A perfectly periodic mouth reads as machinery within about two seconds.
 * The jitter table below scales every pulse by a different amount, so the
 * rhythm is recognisably his but never metronomic. It is a hoisted array
 * indexed by pulse count - no allocation, no randomness in the frame loop.
 * =============================================================================
 */
package com.lorelight.companion

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.runtime.withFrameNanos
import com.lorelight.ui.theme.modeswitch.celestial.CelestialFaceSnapshot
import com.lorelight.ui.theme.modeswitch.celestial.CelestialFaceState
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.sin

/* =========================================================================
 * CADENCE - the single source of speech timing.
 *
 * These same two numbers drive the mouth here AND the word-by-word reveal in
 * CompanionSpeechBox. That is deliberate: when the words and the mouth share
 * one constant, they read as the same act. If they ever drift apart, the
 * illusion dies.
 * =======================================================================*/

const val TALK_CADENCE_SUN_MS = 280L    // ~3.6 pulses/sec - bright, quick
const val TALK_CADENCE_MOON_MS = 420L   // ~2.4 pulses/sec - slow, low

/* --- beat lengths -------------------------------------------------------- */

private const val NOTICE_SUN_MS = 360f
private const val NOTICE_MOON_MS = 480f
private const val SETTLE_SUN_MS = 620f
private const val SETTLE_MOON_MS = 840f

/** Blend from whatever pose he was in, so talking never starts with a snap. */
private const val BLEND_IN_MS = 120f

/** Interruption (a tap) - short, and it never plays the settle blink. */
private const val INTERRUPT_MS = 160f

/* --- easings ------------------------------------------------------------- */

private val EaseOutQuad = CubicBezierEasing(0.25f, 0.46f, 0.45f, 0.94f)
private val EaseInQuad = CubicBezierEasing(0.55f, 0.09f, 0.68f, 0.53f)
private val EaseInOutCubic = CubicBezierEasing(0.65f, 0f, 0.35f, 1f)
private val Rebound = CubicBezierEasing(0.34f, 1.30f, 0.64f, 1.00f)
private val Gentle = CubicBezierEasing(0.30f, 0f, 0.30f, 1f)
private val Decelerate = CubicBezierEasing(0f, 0f, 0.20f, 1f)

/* --- the anti-metronome ------------------------------------------------- */

private val PULSE_JITTER = floatArrayOf(1.00f, 0.85f, 1.10f, 0.90f, 1.05f, 0.80f, 1.00f, 0.95f)

/** The resting face, matching CelestialBody's own rest pose. */
private val REST = CelestialFaceSnapshot(
    lidLeft = 0.06f, lidRight = 0.06f,
    browLeft = 0f, browRight = 0f,
    pupilX = 0f, pupilY = 0f,
    mouthOpen = 0f, mouthSmile = 0.55f,
    headTilt = 0f, squash = 0f
)

/**
 * One mood's talking personality. Everything that differs between the sun
 * and the moon lives here, so the animation code below is written once.
 */
private class TalkStyle(
    val cadenceMs: Long,
    val noticeMs: Float,
    val settleMs: Float,
    val noticeEasing: Easing,
    /** Mouth amplitude. The sun is expressive; the moon barely opens up. */
    val amp: Float,
    /** Quietest the mouth gets between pulses - never fully shut. */
    val floor: Float,
    val envelopeAttackMs: Float,
    val browBase: Float,
    val browSwing: Float,
    val browPeriods: Float,
    val tiltBase: Float,
    val tiltSwing: Float,
    val tiltPeriods: Float,
    val pupilYBase: Float,
    val pupilYSwing: Float,
    val pupilXSwing: Float,
    val squashPerPulse: Float,
    val smile: Float,
    val lids: Float,
    val lidSwing: Float,
    /** The sun ends on a slow blink. The moon just closes a little. */
    val settleBlink: Boolean
)

private val SunStyle = TalkStyle(
    cadenceMs = TALK_CADENCE_SUN_MS,
    noticeMs = NOTICE_SUN_MS,
    settleMs = SETTLE_SUN_MS,
    noticeEasing = Rebound,
    amp = 0.55f,
    floor = 0.06f,
    envelopeAttackMs = 340f,
    browBase = 0.25f, browSwing = 0.10f, browPeriods = 4f,
    tiltBase = 0f, tiltSwing = 0.10f, tiltPeriods = 8f,
    pupilYBase = -0.10f, pupilYSwing = 0.05f, pupilXSwing = 0.04f,
    squashPerPulse = 0.05f,
    smile = 0.50f,
    lids = 0.06f, lidSwing = 0f,
    settleBlink = true
)

private val MoonStyle = TalkStyle(
    cadenceMs = TALK_CADENCE_MOON_MS,
    noticeMs = NOTICE_MOON_MS,
    settleMs = SETTLE_MOON_MS,
    noticeEasing = Gentle,
    amp = 0.30f,
    floor = 0.04f,
    envelopeAttackMs = 500f,
    browBase = 0.10f, browSwing = 0.05f, browPeriods = 6f,
    // The moon's signature: a slow lean to one side while she speaks.
    tiltBase = -0.05f, tiltSwing = 0.12f, tiltPeriods = 6f,
    pupilYBase = -0.08f, pupilYSwing = 0.03f, pupilXSwing = 0.03f,
    squashPerPulse = 0f,
    smile = 0.40f,
    lids = 0.20f, lidSwing = 0.02f,
    settleBlink = false
)

/**
 * Plays the whole talk arc, pinning the face for its duration.
 *
 * Suspends until the arc finishes. Cancel it (or let the caller's coroutine
 * be cancelled) to interrupt: the face eases back to rest over 160ms and
 * unpins itself, so a tap can never leave him frozen mid-sentence.
 *
 * @param speakMs how long the SPEAK beat should last - normally the life of
 *                the bubble, so the mouth stops when the words stop.
 */
suspend fun CelestialFaceState.playTalk(
    mood: Mood,
    speakMs: Long,
    reduceMotion: Boolean = false
) {
    val style = if (mood == Mood.SUN) SunStyle else MoonStyle
    val start = snapshot()

    try {
        if (reduceMotion) {
            // One small acknowledgement, no arc at all.
            animate(240f) { t ->
                val open = if (t < 0.5f) t * 2f * 0.25f else (1f - t) * 2f * 0.25f
                start.copy(mouthOpen = open)
            }
            return
        }

        // --- NOTICE -------------------------------------------------------
        // Interpolating FROM the pose he was actually in is what blends this
        // in: if the idle loop had him mid-blink, the notice grows out of
        // that instead of snapping to a fixed starting face.
        val noticed = noticePose(style)
        animate(style.noticeMs) { t ->
            lerpFace(start, noticed, style.noticeEasing.transform(t))
        }

        // --- SPEAK --------------------------------------------------------
        val p = style.cadenceMs.toFloat()
        animate(speakMs.coerceAtLeast(style.cadenceMs).toFloat()) { t, elapsedMs ->
            speakPose(style, elapsedMs, p)
        }

        // --- SETTLE -------------------------------------------------------
        val last = snapshot()
        animate(style.settleMs) { t ->
            val eased = EaseInOutCubic.transform(t)
            val base = lerpFace(last, REST, eased)
            if (!style.settleBlink) return@animate base

            // A slow blink over the middle of the settle: the visual full
            // stop at the end of his sentence.
            val blink = blinkAmount(t)
            base.copy(
                lidLeft = maxOf(base.lidLeft, blink),
                lidRight = maxOf(base.lidRight, blink)
            )
        }
    } finally {
        // Interrupted or finished, he must always end up back under the
        // idle loop's control - never stuck pinned.
        withContext(NonCancellable) {
            val from = pinnedSnapshot
            if (from != null) {
                animate(INTERRUPT_MS) { t ->
                    lerpFace(from, REST, Decelerate.transform(t))
                }
            }
            pinnedSnapshot = null
        }
    }
}

/* --- poses -------------------------------------------------------------- */

/** The "oh, I'm about to say something" pose. */
private fun noticePose(style: TalkStyle) = REST.copy(
    lidLeft = (style.lids - 0.04f).coerceAtLeast(0f),
    lidRight = (style.lids - 0.04f).coerceAtLeast(0f),
    browLeft = style.browBase + 0.10f,
    browRight = style.browBase + 0.10f,
    pupilY = style.pupilYBase,
    mouthOpen = 0.10f,
    mouthSmile = style.smile,
    headTilt = style.tiltBase + style.tiltSwing * 0.5f,
    squash = style.squashPerPulse
)

/**
 * The face at one instant of speech.
 *
 * Pure function of elapsed time - no state, no allocation, no randomness.
 */
private fun speakPose(style: TalkStyle, elapsedMs: Float, p: Float): CelestialFaceSnapshot {
    val pulseIndex = (elapsedMs / p).toInt()
    val phase = (elapsedMs % p) / p

    // Mouth: opens fast over the first 40% of the beat, closes slower over
    // the rest. Speech is an attack followed by a decay, not a sine wave.
    val shape = if (phase < 0.40f) {
        EaseOutQuad.transform(phase / 0.40f)
    } else {
        1f - EaseInQuad.transform((phase - 0.40f) / 0.60f)
    }

    // Ramp in over the first few pulses so he does not start at full volume.
    val envelope = 0.25f + 0.75f * (elapsedMs / style.envelopeAttackMs).coerceIn(0f, 1f)
    val jitter = PULSE_JITTER[pulseIndex % PULSE_JITTER.size]
    val open = (style.floor + shape * style.amp * jitter * envelope).coerceIn(0f, 1f)

    // Slow overlays on periods that are multiples of P - related to his
    // rhythm, but never in step with it.
    val brow = style.browBase + style.browSwing * wave(elapsedMs, p * style.browPeriods, 0f)
    val tilt = style.tiltBase + style.tiltSwing * wave(elapsedMs, p * style.tiltPeriods, 0.25f)
    val pupY = style.pupilYBase + style.pupilYSwing * wave(elapsedMs, p * 6f, 0f)
    val pupX = style.pupilXSwing * wave(elapsedMs, p * 10f, 0f)
    val lid = style.lids + style.lidSwing * wave(elapsedMs, p * 8f, 0f)

    return CelestialFaceSnapshot(
        lidLeft = lid.coerceIn(0f, 1f),
        lidRight = lid.coerceIn(0f, 1f),
        browLeft = brow.coerceIn(0f, 1f),
        browRight = brow.coerceIn(0f, 1f),
        pupilX = pupX.coerceIn(-1f, 1f),
        pupilY = pupY.coerceIn(-1f, 1f),
        mouthOpen = open,
        mouthSmile = style.smile,
        headTilt = tilt.coerceIn(-1f, 1f),
        squash = (style.squashPerPulse * shape).coerceIn(-1f, 1f)
    )
}

/** Sine in -1..1 with an optional phase offset in turns. */
private fun wave(elapsedMs: Float, periodMs: Float, phaseTurns: Float): Float {
    if (periodMs <= 0f) return 0f
    return sin((elapsedMs / periodMs + phaseTurns) * 2f * PI.toFloat())
}

/** Lids closing and reopening across the middle of the settle beat. */
private fun blinkAmount(t: Float): Float {
    if (t < 0.25f || t > 0.85f) return 0f
    val local = (t - 0.25f) / 0.60f
    return if (local < 0.45f) {
        EaseInQuad.transform(local / 0.45f)
    } else {
        1f - EaseOutQuad.transform((local - 0.45f) / 0.55f)
    }
}

/* --- frame driving ------------------------------------------------------ */

/**
 * Runs [poseAt] every frame for [durationMs], pinning each result.
 *
 * Uses withFrameNanos so the face is computed exactly once per drawn frame -
 * no timers, no recomposition, and it pauses automatically when the app is
 * not visible.
 */
private suspend inline fun CelestialFaceState.animate(
    durationMs: Float,
    crossinline poseAt: (t: Float, elapsedMs: Float) -> CelestialFaceSnapshot
) {
    if (durationMs <= 0f) return
    var startNanos = 0L

    while (true) {
        val done = withFrameNanos { now ->
            if (startNanos == 0L) startNanos = now
            val elapsedMs = (now - startNanos) / 1_000_000f
            val t = (elapsedMs / durationMs).coerceIn(0f, 1f)
            pinnedSnapshot = poseAt(t, elapsedMs)
            t >= 1f
        }
        if (done) return
    }
}

/** Single-argument convenience for beats that only need normalised time. */
private suspend inline fun CelestialFaceState.animate(
    durationMs: Float,
    crossinline poseAt: (t: Float) -> CelestialFaceSnapshot
) = animate(durationMs) { t, _ -> poseAt(t) }

/* --- maths -------------------------------------------------------------- */

private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

private fun lerpFace(a: CelestialFaceSnapshot, b: CelestialFaceSnapshot, t: Float) =
    CelestialFaceSnapshot(
        lidLeft = lerp(a.lidLeft, b.lidLeft, t),
        lidRight = lerp(a.lidRight, b.lidRight, t),
        browLeft = lerp(a.browLeft, b.browLeft, t),
        browRight = lerp(a.browRight, b.browRight, t),
        pupilX = lerp(a.pupilX, b.pupilX, t),
        pupilY = lerp(a.pupilY, b.pupilY, t),
        mouthOpen = lerp(a.mouthOpen, b.mouthOpen, t),
        mouthSmile = lerp(a.mouthSmile, b.mouthSmile, t),
        headTilt = lerp(a.headTilt, b.headTilt, t),
        squash = lerp(a.squash, b.squash, t)
    )
