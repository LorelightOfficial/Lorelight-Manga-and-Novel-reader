/*
 * =============================================================================
 * CompanionCorpus.kt - loads and holds companion-lines.json.
 * Package: com.lorelight.companion
 *
 * Parsed ONCE, lazily, on a background thread, then held for the process
 * lifetime. It is about 24 KB of text and a few thousand small strings, so
 * this is cheap - but it must never happen on the main thread and never in
 * a draw pass.
 *
 * Uses org.json, which is part of Android. No new dependency.
 *
 * IMPORTANT: the JSON's own `eventClass` map is the authority for which
 * class (arr / evt / amb) an event's bodies belong to. The corpus was
 * authored against those classes, so the openers and tails only sound right
 * with them. This file therefore reads the classes from the JSON rather
 * than hardcoding them anywhere in Kotlin.
 * =============================================================================
 */
package com.lorelight.companion

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * One opener or tail.
 *
 * @param text       the fragment. May be empty - an empty fragment means
 *                   "say nothing here", and it deliberately carries the
 *                   heaviest weight so most lines are bare bodies.
 * @param weight     relative draw weight, from the corpus `w` field.
 * @param classMask  bitmask of LineClass values this fragment may attach to.
 */
class Fragment(
    val text: String,
    val weight: Int,
    val classMask: Int
) {
    val isEmpty: Boolean get() = text.isEmpty()

    fun allows(cls: LineClass): Boolean = (classMask and cls.bit) != 0
}

class CompanionCorpus(
    val version: Int,
    private val eventClasses: Map<CompanionEvent, LineClass>,
    private val openers: Map<Mood, List<Fragment>>,
    private val tails: Map<Mood, List<Fragment>>,
    private val bodies: Map<Mood, Map<CompanionEvent, List<String>>>,
    private val hintRungs: Map<Mood, List<List<String>>>,
    private val hintUpdate: Map<Mood, List<String>>,
    private val firstToggle: Map<Mood, List<String>>
) {

    /** The class an event's bodies belong to. Defaults to AMB if absent. */
    fun classOf(event: CompanionEvent): LineClass = eventClasses[event] ?: LineClass.AMB

    fun openers(mood: Mood): List<Fragment> = openers[mood].orEmpty()

    fun tails(mood: Mood): List<Fragment> = tails[mood].orEmpty()

    fun bodies(mood: Mood, event: CompanionEvent): List<String> =
        bodies[mood]?.get(event).orEmpty()

    /** How many rungs the hint ladder has. Rung 0 is the gentlest. */
    fun hintRungCount(mood: Mood): Int = hintRungs[mood]?.size ?: 0

    fun hintRung(mood: Mood, rung: Int): List<String> {
        val all = hintRungs[mood].orEmpty()
        if (all.isEmpty()) return emptyList()
        return all[rung.coerceIn(0, all.size - 1)]
    }

    fun hintUpdate(mood: Mood): List<String> = hintUpdate[mood].orEmpty()

    fun firstToggle(mood: Mood): List<String> = firstToggle[mood].orEmpty()

    /** True when there is at least one body for this event in this mood. */
    fun has(mood: Mood, event: CompanionEvent): Boolean =
        bodies(mood, event).isNotEmpty()

    companion object {
        const val ASSET = "companion-lines.json"

        /** Reads and parses the corpus. Call off the main thread. */
        fun load(context: Context, asset: String = ASSET): CompanionCorpus {
            val text = context.assets.open(asset).use { input ->
                input.readBytes().toString(Charsets.UTF_8)
            }
            return parse(JSONObject(text))
        }

        fun parse(root: JSONObject): CompanionCorpus {
            val classes = HashMap<CompanionEvent, LineClass>()
            root.optJSONObject("eventClass")?.let { obj ->
                val keys = obj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val event = CompanionEvent.fromKey(key) ?: continue
                    val cls = LineClass.fromWire(obj.optString(key)) ?: continue
                    classes[event] = cls
                }
            }

            return CompanionCorpus(
                version = root.optInt("version", 1),
                eventClasses = classes,
                openers = parseFragments(root.optJSONObject("openers")),
                tails = parseFragments(root.optJSONObject("tails")),
                bodies = parseBodies(root.optJSONObject("bodies")),
                hintRungs = parseHintRungs(root.optJSONObject("hints")),
                hintUpdate = parseMoodStrings(root.optJSONObject("hints"), "update"),
                firstToggle = parseMoodStrings(root.optJSONObject("hints"), "firstToggle")
            )
        }

        private fun parseFragments(obj: JSONObject?): Map<Mood, List<Fragment>> {
            val out = HashMap<Mood, List<Fragment>>()
            if (obj == null) return out
            for (mood in Mood.entries) {
                val arr = obj.optJSONArray(mood.wire) ?: continue
                val list = ArrayList<Fragment>(arr.length())
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    var mask = 0
                    val clsArr: JSONArray? = item.optJSONArray("cls")
                    if (clsArr == null) {
                        // No class list means "fits anywhere".
                        for (c in LineClass.entries) mask = mask or c.bit
                    } else {
                        for (j in 0 until clsArr.length()) {
                            LineClass.fromWire(clsArr.optString(j))?.let { mask = mask or it.bit }
                        }
                    }
                    list.add(
                        Fragment(
                            text = item.optString("t", "").trim(),
                            weight = item.optInt("w", 1).coerceAtLeast(1),
                            classMask = mask
                        )
                    )
                }
                out[mood] = list
            }
            return out
        }

        private fun parseBodies(obj: JSONObject?): Map<Mood, Map<CompanionEvent, List<String>>> {
            val out = HashMap<Mood, Map<CompanionEvent, List<String>>>()
            if (obj == null) return out
            for (mood in Mood.entries) {
                val moodObj = obj.optJSONObject(mood.wire) ?: continue
                val perEvent = HashMap<CompanionEvent, List<String>>()
                val keys = moodObj.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val event = CompanionEvent.fromKey(key) ?: continue
                    perEvent[event] = readStrings(moodObj.optJSONArray(key))
                }
                out[mood] = perEvent
            }
            return out
        }

        private fun parseHintRungs(hints: JSONObject?): Map<Mood, List<List<String>>> {
            val out = HashMap<Mood, List<List<String>>>()
            if (hints == null) return out
            for (mood in Mood.entries) {
                val arr = hints.optJSONArray(mood.wire) ?: continue
                val rungs = ArrayList<List<String>>(arr.length())
                for (i in 0 until arr.length()) {
                    rungs.add(readStrings(arr.optJSONArray(i)))
                }
                out[mood] = rungs
            }
            return out
        }

        private fun parseMoodStrings(hints: JSONObject?, field: String): Map<Mood, List<String>> {
            val out = HashMap<Mood, List<String>>()
            val obj = hints?.optJSONObject(field) ?: return out
            for (mood in Mood.entries) {
                out[mood] = readStrings(obj.optJSONArray(mood.wire))
            }
            return out
        }

        private fun readStrings(arr: JSONArray?): List<String> {
            if (arr == null) return emptyList()
            val list = ArrayList<String>(arr.length())
            for (i in 0 until arr.length()) {
                val s = arr.optString(i, "").trim()
                if (s.isNotEmpty()) list.add(s)
            }
            return list
        }
    }
}
