/*
 * =============================================================================
 * CompanionGestures.kt - the natural, propless actions.
 * Package: com.lorelight.companion
 *
 * WHAT THIS IS
 *
 * Twelve small body-language beats built ONLY from the ten channels the face
 * already has. No new art, no overlay, no assets: a nod is a squash pulse
 * plus a pupil dip, a doze is the lids closing slowly. That is the whole
 * trick, and it is why these cost nothing to add.
 *
 * HOW IT DRIVES THE FACE
 *
 * Exactly the same way CompanionTalk.kt does: compute the entire face
 * ourselves each frame and write it to the engine's `pinnedSnapshot` hook,
 * then unpin in a finally block so the idle loop takes back over. That means
 * CelestialBody.kt is not touched and none of the existing character can
 * regress.
 *
 * THE ONE HARD RULE
 *
 * Talking always wins. A gesture is cancelled the instant a line arrives,
 * because a mouth moving to two different scripts at once looks broken. The
 * cancel path eases back to rest, so an interrupted gesture can never leave
 * him frozen in a strange pose.
 *
 * WHY MOON GESTURES ARE SLOWER
 *
 * The same reason her speech cadence is 420ms against the sun's 280ms. One
 * scalar, applied here, keeps her body language in character without writing
 * every gesture twice.
 * =============================================================================
 */
package com.lorelight.companion

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.runtime.withFrameNanos
import com.lorelight.ui.theme.modeswitch.celestial.CelestialFaceSnapshot
import com.lorelight.ui.theme.modeswitch.celestial.CelestialFaceState
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/* =========================================================================
 * THE CATALOGUE
 * =======================================================================*/

/**
 * Every propless action he can perform.
 *
 * `sunMs` is the beat's length for the sun. The moon takes MOON_TIME_SCALE
 * longer, which is what makes her read as the slower, quieter one.
 */
enum class CompanionGesture(val sunMs: Long) {

    /** Eyes flick aside and drift back. The cheapest sign of life there is. */
    GLANCE_LEFT(900L),
    GLANCE_RIGHT(900L),

    /** Eyes drop, as if following the list going past. */
    GLANCE_DOWN(850L),

    /** Head cocks over with one brow up: he noticed something new. */
    TILT_CURIOUS(1150L),

    /** Two short dips. Approval, and the natural answer to finishing something. */
    NOD(950L),

    /** Stretch then squash then settle. Delight, used for milestones. */
    HOP(750L),

    /** Squint and flatten the smile. For failures - a load that did not work. */
    WINCE(850L),

    /** Lids close most of the way and breathing slows. Deep night. */
    DOZE(2600L),

    /** Lids snap open, brows high, a small gasp. The opposite of DOZE. */
    WAKE(700L),

    /** Lids settle halfway and stay. Long sessions, tiredness that lingers. */
    SLEEPY_SQUINT(1700L),

    /** Eyes slide away with a bigger smile. Bashful, or caught out. */
    LOOK_AWAY(1450L),

    /** Pupils trace a full circle. Fond exasperation. */
    EYE_ROLL(1150L),

    /** Snap away, snap back past centre, brows high. Genuine surprise. */
    DOUBLE_TAKE(950L),

    /** A long, slow swell. Not really an action - just proof he is there. */
    BREATHE(4200L);

    /** How long this beat runs for a given character. */
    fun durationMs(mood: Mood): Long =
        if (mood == Mood.SUN) sunMs else (sunMs * MOON_TIME_SCALE).toLong()
}

/** The moon does everything at this fraction of the sun's speed. */
private const val MOON_TIME_SCALE = 1.35f

/** Cancel ease-out. Must be short: an interrupt has to feel immediate. */
private const val GESTURE_INTERRUPT_MS = 150f

/* --- easings ------------------------------------------------------------- */

private val EaseOutQuad = CubicBezierEasing(0.25f, 0.46f, 0.45f, 0.94f)
private val EaseInQuad = CubicBezierEasing(0.55f, 0.09f, 0.68f, 0.53f)
private val EaseInOutCubic = CubicBezierEasing(0.65f, 0f, 0.35f, 1f)
private val Overshoot = CubicBezierEasing(0.34f, 1.36f, 0.64f, 1.00f)
private val Decelerate = CubicBezierEasing(0f, 0f, 0.20f, 1f)

/** Matches CelestialBody's own rest pose. Keep the two in step. */
private val GESTURE_REST = CelestialFaceSnapshot(
    lidLeft = 0.06f, lidRight = 0.06f,
    browLeft = 0f, browRight = 0f,
    pupilX = 0f, pupilY = 0f,
    mouthOpen = 0f, mouthSmile = 0.55f,
    headTilt = 0f, squash = 0f
)

/* =========================================================================
 * THE ENTRY POINT
 * =======================================================================*/

/**
 * Plays one gesture, pinning the face for its duration.
 *
 * Suspends until it finishes. Cancel the calling coroutine to interrupt: the
 * face eases back to rest over 150ms and unpins itself, so an interrupted
 * gesture never leaves him stuck.
 *
 * @param reduceMotion when true, plays a single soft acknowledgement instead
 *        of the full beat. Honours the system animation-scale setting.
 */
suspend fun CelestialFaceState.playGesture(
    gesture: CompanionGesture,
    mood: Mood,
    reduceMotion: Boolean = false
) {
    val start = snapshot()

    try {
        if (reduceMotion) {
            // One 240ms brow lift and nothing else. Still legible as a
            // reaction, but with no travel to make anyone queasy.
            runFrames(240f) { t, _ ->
                val rise = if (t < 0.5f) t * 2f else (1f - t) * 2f
                start.copy(browLeft = rise * 0.4f, browRight = rise * 0.4f)
            }
            return
        }

        val duration = gesture.durationMs(mood).toFloat()

        // Interpolating FROM the pose he was actually in is what blends the
        // gesture in. Snapping to a fixed opening pose reads as a glitch.
        runFrames(duration) { t, elapsed ->
            val target = posePart(gesture, mood, t, elapsed, duration)
            // Blend over the first 12% so nothing ever starts with a jump.
            val blend = (t / 0.12f).coerceIn(0f, 1f)
            blendFace(start, target, blend)
        }
    } finally {
        // Finished or interrupted, he must always end up back under the idle
        // loop's control. NonCancellable so the unpin happens even when the
        // caller was cancelled.
        withContext(NonCancellable) {
            val from = pinnedSnapshot
            if (from != null) {
                runFrames(GESTURE_INTERRUPT_MS) { t, _ ->
                    blendFace(from, GESTURE_REST, Decelerate.transform(t))
                }
            }
            pinnedSnapshot = null
        }
    }
}

/* =========================================================================
 * THE POSES
 *
 * Every one of these is a pure function of normalised time. No state, no
 * allocation beyond the returned snapshot, no randomness in the frame loop.
 * =======================================================================*/

private fun posePart(
    gesture: CompanionGesture,
    mood: Mood,
    t: Float,
    elapsedMs: Float,
    durationMs: Float
): CelestialFaceSnapshot = when (gesture) {

    CompanionGesture.GLANCE_LEFT -> glance(-1f, t)
    CompanionGesture.GLANCE_RIGHT -> glance(1f, t)

    CompanionGesture.GLANCE_DOWN -> {
        val a = arc(t)
        GESTURE_REST.copy(
            pupilY = 0.75f * a,
            lidLeft = 0.06f + 0.14f * a,
            lidRight = 0.06f + 0.14f * a
        )
    }

    CompanionGesture.TILT_CURIOUS -> {
        // Tilt arrives with a slight overshoot and unwinds smoothly, which is
        // what makes it read as interest rather than a mechanical rotation.
        val inT = (t / 0.35f).coerceIn(0f, 1f)
        val outT = ((t - 0.65f) / 0.35f).coerceIn(0f, 1f)
        val amount = Overshoot.transform(inT) * (1f - EaseInOutCubic.transform(outT))
        GESTURE_REST.copy(
            headTilt = 0.38f * amount,
            browLeft = 0.72f * amount,
            browRight = 0.16f * amount,
            lidLeft = 0.02f,
            lidRight = 0.02f,
            pupilY = -0.16f * amount,
            mouthSmile = 0.55f + 0.12f * amount
        )
    }

    CompanionGesture.NOD -> {
        // Two dips. The second is smaller: a repeated identical motion is the
        // fastest way to look like a machine.
        val dip = sin(t * 2f * TWO_PI).let { if (it < 0f) -it else it }
        val decay = 1f - 0.35f * t
        val amount = dip * decay
        GESTURE_REST.copy(
            pupilY = 0.42f * amount,
            squash = 0.20f * amount,
            mouthSmile = 0.62f + 0.12f * amount,
            lidLeft = 0.06f + 0.20f * amount,
            lidRight = 0.06f + 0.20f * amount
        )
    }

    CompanionGesture.HOP -> {
        // Stretch tall, land squashed, spring back. Classic squash-and-stretch
        // ordering - anticipation first, impact second.
        val s = when {
            t < 0.28f -> -0.42f * EaseOutQuad.transform(t / 0.28f)
            t < 0.55f -> -0.42f + 0.76f * EaseInQuad.transform((t - 0.28f) / 0.27f)
            else -> 0.34f * (1f - Overshoot.transform((t - 0.55f) / 0.45f))
        }
        val lift = (1f - t)
        GESTURE_REST.copy(
            squash = s,
            mouthOpen = 0.30f * lift,
            mouthSmile = 0.85f,
            browLeft = 0.55f * lift,
            browRight = 0.55f * lift,
            lidLeft = 0f, lidRight = 0f
        )
    }

    CompanionGesture.WINCE -> {
        // The face has no frown channel, so a wince is built from a squint
        // plus a flattened smile plus a small turn away. Read together they
        // are unmistakable.
        val a = arc(t)
        GESTURE_REST.copy(
            lidLeft = 0.06f + 0.52f * a,
            lidRight = 0.06f + 0.44f * a,
            browLeft = 0f,
            browRight = 0f,
            mouthSmile = 0.55f - 0.48f * a,
            mouthOpen = 0.10f * a,
            headTilt = -0.14f * a,
            pupilX = -0.20f * a
        )
    }

    CompanionGesture.DOZE -> {
        // Lids fall almost shut and STAY - this beat does not return to rest,
        // which is the point: he is drifting off, not blinking.
        val fall = EaseInOutCubic.transform((t / 0.6f).coerceIn(0f, 1f))
        val breath = sin(elapsedMs / 1400f * TWO_PI)
        GESTURE_REST.copy(
            lidLeft = 0.06f + 0.86f * fall,
            lidRight = 0.06f + 0.86f * fall,
            pupilY = 0.30f * fall,
            mouthSmile = 0.55f - 0.22f * fall,
            headTilt = 0.12f * fall,
            squash = 0.05f * breath
        )
    }

    CompanionGesture.WAKE -> {
        // Starts from lids nearly shut so it only makes sense straight after
        // a DOZE or on an early-morning launch.
        val pop = Overshoot.transform((t / 0.30f).coerceIn(0f, 1f))
        val calm = EaseInOutCubic.transform(((t - 0.45f) / 0.55f).coerceIn(0f, 1f))
        GESTURE_REST.copy(
            lidLeft = 0.88f * (1f - pop),
            lidRight = 0.88f * (1f - pop),
            browLeft = 0.92f * pop * (1f - calm),
            browRight = 0.92f * pop * (1f - calm),
            mouthOpen = 0.34f * pop * (1f - calm),
            pupilY = -0.22f * pop * (1f - calm),
            squash = -0.18f * pop * (1f - calm)
        )
    }

    CompanionGesture.SLEEPY_SQUINT -> {
        // Holds through the middle then releases, so it reads as tiredness
        // rather than a single slow blink.
        val hold = plateau(t, 0.25f, 0.75f)
        GESTURE_REST.copy(
            lidLeft = 0.06f + 0.42f * hold,
            lidRight = 0.06f + 0.46f * hold,
            browLeft = 0.08f * hold,
            browRight = 0.08f * hold,
            pupilY = 0.14f * hold,
            mouthSmile = 0.55f - 0.10f * hold,
            headTilt = 0.08f * hold
        )
    }

    CompanionGesture.LOOK_AWAY -> {
        val hold = plateau(t, 0.22f, 0.72f)
        GESTURE_REST.copy(
            pupilX = 0.78f * hold,
            pupilY = -0.18f * hold,
            headTilt = -0.16f * hold,
            mouthSmile = 0.55f + 0.30f * hold,
            lidLeft = 0.06f + 0.22f * hold,
            lidRight = 0.06f + 0.10f * hold
        )
    }

    CompanionGesture.EYE_ROLL -> {
        // A real circuit, not a flick: up, over, down, back. Starting at the
        // top is what makes it read as an eye roll and not a look-around.
        val sweep = EaseInOutCubic.transform(t)
        val angle = -TWO_PI * 0.25f + sweep * TWO_PI
        val fade = plateau(t, 0.10f, 0.90f)
        GESTURE_REST.copy(
            pupilX = cos(angle) * 0.62f * fade,
            pupilY = sin(angle) * 0.62f * fade,
            lidLeft = 0.06f + 0.12f * fade,
            lidRight = 0.06f + 0.12f * fade,
            mouthSmile = 0.55f - 0.24f * fade,
            headTilt = 0.10f * fade
        )
    }

    CompanionGesture.DOUBLE_TAKE -> {
        // Snap out fast, snap back THROUGH centre and overshoot the other
        // way, then settle. The overshoot is the whole gag.
        val x = when {
            t < 0.16f -> -EaseOutQuad.transform(t / 0.16f)
            t < 0.34f -> -1f + 1.36f * EaseOutQuad.transform((t - 0.16f) / 0.18f)
            else -> 0.36f * (1f - EaseInOutCubic.transform((t - 0.34f) / 0.66f))
        }
        val alarm = 1f - EaseInQuad.transform(t)
        GESTURE_REST.copy(
            pupilX = x * 0.85f,
            browLeft = 0.95f * alarm,
            browRight = 0.95f * alarm,
            lidLeft = 0f, lidRight = 0f,
            mouthOpen = 0.38f * alarm,
            squash = -0.20f * alarm,
            headTilt = 0.12f * x
        )
    }

    CompanionGesture.BREATHE -> {
        val swell = sin(t * TWO_PI)
        GESTURE_REST.copy(
            squash = 0.09f * swell,
            lidLeft = 0.06f + 0.05f * swell,
            lidRight = 0.06f + 0.05f * swell,
            mouthSmile = 0.55f + 0.05f * swell,
            pupilY = -0.05f * swell
        )
    }
}

/** Pupils out and back, with the lids and a brow coming along for the ride. */
private fun glance(direction: Float, t: Float): CelestialFaceSnapshot {
    val hold = plateau(t, 0.20f, 0.70f)
    return GESTURE_REST.copy(
        pupilX = direction * 0.82f * hold,
        pupilY = -0.10f * hold,
        browLeft = if (direction < 0f) 0.34f * hold else 0.10f * hold,
        browRight = if (direction > 0f) 0.34f * hold else 0.10f * hold,
        lidLeft = 0.02f,
        lidRight = 0.02f,
        headTilt = direction * 0.08f * hold
    )
}

/* =========================================================================
 * SHAPE HELPERS
 * =======================================================================*/

private const val TWO_PI = 6.2831855f

/** Rises to 1 by the midpoint and falls back. A single there-and-back beat. */
private fun arc(t: Float): Float =
    if (t < 0.5f) EaseOutQuad.transform(t / 0.5f)
    else 1f - EaseInOutCubic.transform((t - 0.5f) / 0.5f)

/**
 * Rises to 1 by [rise], HOLDS there, then falls after [fall].
 *
 * This is the difference between a pose he strikes and a pose he passes
 * through. Anything meant to be legible needs the hold.
 */
private fun plateau(t: Float, rise: Float, fall: Float): Float = when {
    t < rise -> EaseOutQuad.transform(t / rise)
    t < fall -> 1f
    else -> 1f - EaseInOutCubic.transform((t - fall) / (1f - fall))
}

/* =========================================================================
 * FRAME DRIVING
 * =======================================================================*/

/**
 * Runs [poseAt] once per drawn frame for [durationMs], pinning each result.
 *
 * withFrameNanos rather than a timer, so the face is computed exactly once
 * per frame, never recomposes, and pauses by itself when the app is not
 * visible.
 */
private suspend inline fun CelestialFaceState.runFrames(
    durationMs: Float,
    crossinline poseAt: (t: Float, elapsedMs: Float) -> CelestialFaceSnapshot
) {
    if (durationMs <= 0f) return
    var startNanos = 0L

    while (true) {
        val done = withFrameNanos { now ->
            if (startNanos == 0L) startNanos = now
            val elapsedMs = (now - startNanos) / 1_000_000f
            val t = (elapsedMs / durationMs).coerceIn(0f, 1f)
            pinnedSnapshot = poseAt(t, elapsedMs)
            t >= 1f
        }
        if (done) return
    }
}

private fun mix(a: Float, b: Float, t: Float) = a + (b - a) * t

private fun blendFace(
    a: CelestialFaceSnapshot,
    b: CelestialFaceSnapshot,
    t: Float
) = CelestialFaceSnapshot(
    lidLeft = mix(a.lidLeft, b.lidLeft, t),
    lidRight = mix(a.lidRight, b.lidRight, t),
    browLeft = mix(a.browLeft, b.browLeft, t),
    browRight = mix(a.browRight, b.browRight, t),
    pupilX = mix(a.pupilX, b.pupilX, t),
    pupilY = mix(a.pupilY, b.pupilY, t),
    mouthOpen = mix(a.mouthOpen, b.mouthOpen, t),
    mouthSmile = mix(a.mouthSmile, b.mouthSmile, t),
    headTilt = mix(a.headTilt, b.headTilt, t),
    squash = mix(a.squash, b.squash, t)
)
