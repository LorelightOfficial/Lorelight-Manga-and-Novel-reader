package com.lorelight.manga.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import com.lorelight.ui.components.LorelightDialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.lorelight.manga.util.MangaLanguages
import eu.kanade.tachiyomi.extension.ExtensionManager
import eu.kanade.tachiyomi.extension.model.Extension
import eu.kanade.tachiyomi.extension.model.InstallStep
import tachiyomi.domain.source.service.SourceManager
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import com.lorelight.ui.animation.ShimmerBox
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.foundation.Image
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

private const val PREFS = "lorelight_manga_prefs"
private const val KEY_NSFW = "manga_show_nsfw"
private const val KEY_TRUST_WARNING_SEEN = "manga_ext_trust_warning_seen"

enum class NsfwFilterMode { NORMAL, NSFW_TOP, NSFW_LAST }

private const val KEY_NSFW_MODE = "manga_nsfw_mode"

fun readNsfwMode(context: Context): NsfwFilterMode {
    val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    val raw = p.getString(KEY_NSFW_MODE, null)
    if (raw != null) return runCatching { NsfwFilterMode.valueOf(raw) }.getOrDefault(NsfwFilterMode.NORMAL)
    return if (p.getBoolean(KEY_NSFW, false)) NsfwFilterMode.NSFW_TOP else NsfwFilterMode.NORMAL
}

fun writeNsfwMode(context: Context, mode: NsfwFilterMode) {
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        .putString(KEY_NSFW_MODE, mode.name)
        .putBoolean(KEY_NSFW, mode == NsfwFilterMode.NSFW_TOP)
        .apply()
}

// Three-state cycle: default order -> 18+ first -> 18+ last -> default order.
fun nextNsfwMode(m: NsfwFilterMode) = when (m) {
    NsfwFilterMode.NORMAL -> NsfwFilterMode.NSFW_TOP
    NsfwFilterMode.NSFW_TOP -> NsfwFilterMode.NSFW_LAST
    NsfwFilterMode.NSFW_LAST -> NsfwFilterMode.NORMAL
}

/**
 * Single ordering implementation so every screen that honours the 18+ button
 * sorts identically. NSFW_LAST pushes mature sources to the bottom and pulls
 * everything else to the top; both sorted modes are alphabetical within a group.
 */
fun <T> sortByNsfwMode(
    items: List<T>,
    mode: NsfwFilterMode,
    isNsfw: (T) -> Boolean,
    name: (T) -> String
): List<T> = when (mode) {
    NsfwFilterMode.NORMAL -> items
    NsfwFilterMode.NSFW_TOP ->
        items.sortedWith(compareByDescending<T> { isNsfw(it) }.thenBy { name(it).lowercase() })
    NsfwFilterMode.NSFW_LAST ->
        items.sortedWith(compareBy<T> { isNsfw(it) }.thenBy { name(it).lowercase() })
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun MangaExtensionsScreen(
    onOpenSourceScreen: () -> Unit = {},
    hideHeader: Boolean = false,
    searchQuery: String = "",
    nsfwMode: NsfwFilterMode? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current
    val extensionManager = remember { Injekt.get<ExtensionManager>() }
    val sourceManager = remember { Injekt.get<SourceManager>() }

    var available by remember { mutableStateOf(extensionManager.availableExtensionsFlow.value) }
    var installed by remember { mutableStateOf(extensionManager.installedExtensionsFlow.value) }
    var loading by remember { mutableStateOf(available.isEmpty() && installed.isEmpty()) }
    // Distinct from `loading`, which only ever describes the first cold load.
    // This is true purely for the duration of a user-initiated pull-to-refresh.
    var refreshing by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var installSteps by remember { mutableStateOf<Map<String, InstallStep>>(emptyMap()) }

    var internalNsfwMode by remember { mutableStateOf(readNsfwMode(context)) }
    val effectiveNsfwMode = nsfwMode ?: internalNsfwMode

    var searchActive by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var showReposDialog by remember { mutableStateOf(false) }
    var extensionToUninstall by remember { mutableStateOf<Extension.Installed?>(null) }
    var installErrorReasons by remember { mutableStateOf<String?>(null) }
    var pendingTrustAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var pendingUntrustedExtension by remember { mutableStateOf<Extension.Untrusted?>(null) }

    LaunchedEffect(Unit) {
        com.lorelight.core.DevLogStore.append(context, "NAV", "Opened Manga Extensions screen")
    }

    LaunchedEffect(Unit) {
        extensionManager.installedExtensionsFlow.collectLatest { list ->
            installed = list
            MangaSourcesCache.clear()
        }
    }

    LaunchedEffect(Unit) {
        extensionManager.availableExtensionsFlow.collectLatest { list ->
            available = list
        }
    }

    LaunchedEffect(Unit) {
        extensionManager.untrustedExtensionsFlow.collectLatest { list ->
            val stillPending = pendingUntrustedExtension
            if (stillPending != null && list.none { it.pkgName == stillPending.pkgName }) {
                pendingUntrustedExtension = null
            }
            val next = list.firstOrNull()
            if (next != null && pendingUntrustedExtension == null) {
                pendingUntrustedExtension = next
            }
        }
    }

    fun refresh(userInitiated: Boolean = false) {
        scope.launch {
            if (userInitiated) refreshing = true
            loading = extensionManager.availableExtensionsFlow.value.isEmpty() &&
                extensionManager.installedExtensionsFlow.value.isEmpty()
            error = null
            try {
                withContext(Dispatchers.IO) {
                    extensionManager.findAvailableExtensions()
                }
                if (extensionManager.availableExtensionsFlow.value.isEmpty() &&
                    extensionManager.installedExtensionsFlow.value.isEmpty()
                ) {
                    error = "No manga sources found in your repositories.\nPull down to refresh or check your repo settings."
                }
            } catch (e: Exception) {
                if (extensionManager.availableExtensionsFlow.value.isEmpty()) {
                    error = e.localizedMessage ?: "Failed to load extensions. Please check your network connection."
                }
            } finally {
                loading = false
                refreshing = false
            }
        }
    }

    LaunchedEffect(Unit) {
        sourceManager.isInitialized.first { it }
        if (extensionManager.availableExtensionsFlow.value.isEmpty()) {
            refresh()
        } else {
            loading = false
        }
    }

    fun startInstallFlow(info: Extension.Available) {
        val trustPrefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!trustPrefs.getBoolean(KEY_TRUST_WARNING_SEEN, false)) {
            pendingTrustAction = { startInstallFlow(info) }
            return
        }

        scope.launch {
            extensionManager.installExtension(info).collectLatest { step ->
                installSteps = installSteps + (info.pkgName to step)
                if (step == InstallStep.Error) {
                    installErrorReasons = "Could not install ${info.name}. Please try again."
                }
                if (step.isCompleted()) {
                    installSteps = installSteps - info.pkgName
                }
            }
        }
    }

    val availableByPkg = remember(available) { available.associateBy { it.pkgName } }

    val effectiveQuery = if (hideHeader) searchQuery else query
    val q = effectiveQuery.trim()

    val presentLangs = remember(available) {
        available.map { it.lang }.filter { it.isNotBlank() }.distinct().toSet()
    }
    val selectedLangs = remember(context, presentLangs) {
        MangaLanguages.effective(context, presentLangs)
    }

    val multiExtensionBasePkgs = remember(available, installed) {
        val set = mutableSetOf<String>()
        available.filter { isMultiLang(it.lang) }.forEach {
            set.add(getBasePkg(it.pkgName, it.lang))
        }
        installed.filter { isMultiLang(it.lang) }.forEach {
            set.add(getBasePkg(it.pkgName, it.lang))
        }
        set
    }

    val multiExtensionCleanNames = remember(available, installed) {
        val set = mutableSetOf<String>()
        available.filter { isMultiLang(it.lang) }.forEach {
            set.add(getCleanName(it.name))
        }
        installed.filter { isMultiLang(it.lang) }.forEach {
            set.add(getCleanName(it.name))
        }
        set
    }

    val availableList = remember(available, q, selectedLangs, effectiveNsfwMode, multiExtensionBasePkgs, multiExtensionCleanNames) {
        val filtered = available.filter { info ->
            val matchesQuery = q.isBlank() || info.name.contains(q, true)
            val matchesLang = selectedLangs.isEmpty() || selectedLangs.contains(info.lang)
            val isMulti = isMultiLang(info.lang)
            val hasMultiVersion = multiExtensionBasePkgs.contains(getBasePkg(info.pkgName, info.lang)) ||
                    multiExtensionCleanNames.contains(getCleanName(info.name))

            matchesQuery && matchesLang && (isMulti || !hasMultiVersion)
        }
        sortByNsfwMode(filtered, effectiveNsfwMode, { it.isNsfw }, { it.name })
    }

    val filteredInstalled = remember(installed, q, selectedLangs, effectiveNsfwMode, multiExtensionBasePkgs, multiExtensionCleanNames) {
        val filtered = installed.filter { inst ->
            val matchesQuery = q.isBlank() || inst.name.contains(q, true)
            val matchesLang = selectedLangs.isEmpty() || selectedLangs.contains(inst.lang)
            val isMulti = isMultiLang(inst.lang)
            val hasMultiVersion = multiExtensionBasePkgs.contains(getBasePkg(inst.pkgName, inst.lang)) ||
                    multiExtensionCleanNames.contains(getCleanName(inst.name))

            matchesQuery && matchesLang && (isMulti || !hasMultiVersion)
        }
        sortByNsfwMode(filtered, effectiveNsfwMode, { it.isNsfw }, { it.name })
    }

    val updatable = remember(filteredInstalled, availableByPkg) {
        filteredInstalled.filter { inst ->
            val latest = availableByPkg[inst.pkgName]
            latest != null && (latest.versionCode > inst.versionCode || latest.versionName != inst.versionName)
        }
    }

    val installedPkgs = remember(installed) { installed.map { it.pkgName }.toSet() }

    val notInstalled = remember(availableList, installedPkgs) {
        availableList.filter { it.pkgName !in installedPkgs }
    }

    val updatesCount = updatable.size

    Column(Modifier.fillMaxSize()) {
        if (!hideHeader) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 12.dp)
                    .height(48.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Manga Extensions",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = MaterialTheme.typography.headlineLarge.fontFamily,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (updatesCount > 0) {
                        TextButton(
                            onClick = {
                                updatable.firstOrNull()?.let { ext ->
                                    availableByPkg[ext.pkgName]?.let { info ->
                                        startInstallFlow(info)
                                    }
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                        ) {
                            Text("Update ($updatesCount)", fontSize = 12.sp)
                        }
                    }

                    // 18+ ordering toggle. Cycles default order -> 18+ first ->
                    // 18+ last. The arrow tells the two sorted states apart, so
                    // the button is not just "a differently coloured 18+".
                    val nsfwBg = when (effectiveNsfwMode) {
                        NsfwFilterMode.NSFW_TOP -> MaterialTheme.colorScheme.error
                        NsfwFilterMode.NSFW_LAST -> MaterialTheme.colorScheme.primary
                        NsfwFilterMode.NORMAL -> MaterialTheme.colorScheme.surfaceVariant
                    }
                    val nsfwFg = when (effectiveNsfwMode) {
                        NsfwFilterMode.NSFW_TOP -> MaterialTheme.colorScheme.onError
                        NsfwFilterMode.NSFW_LAST -> MaterialTheme.colorScheme.onPrimary
                        NsfwFilterMode.NORMAL -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    // Glass pane, with the state colour carried underneath the
                    // glass rather than as a flat square. The active states
                    // still read loudly; the resting state now matches every
                    // other control on the row.
                    com.lorelight.ui.components.GlassIconSurface(
                        onClick = {
                            val m = nextNsfwMode(internalNsfwMode)
                            internalNsfwMode = m
                            writeNsfwMode(context, m)
                        },
                        buttonSize = 36.dp,
                        shape = RoundedCornerShape(10.dp),
                        containerTint = if (effectiveNsfwMode == NsfwFilterMode.NORMAL) {
                            null
                        } else {
                            nsfwBg
                        }
                    ) {
                        Text(
                            when (effectiveNsfwMode) {
                                NsfwFilterMode.NSFW_TOP -> "18\u2191"
                                NsfwFilterMode.NSFW_LAST -> "18\u2193"
                                NsfwFilterMode.NORMAL -> "18+"
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = nsfwFg
                        )
                    }

                    HeaderActionButton(
                        icon = Icons.Filled.Search,
                        contentDescription = "Search extensions",
                        active = searchActive,
                        onClick = {
                            searchActive = !searchActive
                            if (!searchActive) query = ""
                        }
                    )

                    HeaderActionButton(
                        icon = Icons.Filled.Settings,
                        contentDescription = "Repositories",
                        onClick = { showReposDialog = true }
                    )
                }
            }

            // Inline Search Bar
            if (searchActive) {
                val focusRequester = remember { FocusRequester() }
                LaunchedEffect(Unit) { focusRequester.requestFocus() }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.Search,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                        modifier = Modifier
                            .weight(1f)
                            .focusRequester(focusRequester),
                        decorationBox = { inner ->
                            Box {
                                if (query.isEmpty()) {
                                    Text(
                                        "Search extensions",
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                    )
                                }
                                inner()
                            }
                        }
                    )
                    Icon(
                        Icons.Filled.Close,
                        contentDescription = "Close search",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .size(18.dp)
                            .clickable { searchActive = false; query = "" }
                    )
                }
            }
        }

        PullToRefreshBox(
            // PULL-TO-REFRESH FIX: this used to be
            // `loading && (available.isNotEmpty() || installed.isNotEmpty())`.
            // refresh() recomputes `loading` as "both lists are empty", which is
            // false the moment the catalogue is on screen, so on the Available
            // page the indicator never appeared and the gesture looked dead even
            // though the network fetch really did run.
            isRefreshing = refreshing,
            onRefresh = { refresh(userInitiated = true) },
            modifier = Modifier.fillMaxSize()
        ) {
            when {
                loading && available.isEmpty() && installed.isEmpty() -> Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    repeat(8) {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                ShimmerBox(
                                    modifier = Modifier.size(40.dp),
                                    cornerRadius = 8
                                )
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    ShimmerBox(
                                        modifier = Modifier
                                            .fillMaxWidth(0.6f)
                                            .height(14.dp),
                                        cornerRadius = 4
                                    )
                                    Spacer(Modifier.height(6.dp))
                                    ShimmerBox(
                                        modifier = Modifier
                                            .fillMaxWidth(0.35f)
                                            .height(12.dp),
                                        cornerRadius = 4
                                    )
                                }
                            }
                        }
                    }
                }
                error != null && available.isEmpty() && installed.isEmpty() -> Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.Warning,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(Modifier.height(16.dp))
                    Text(
                        error ?: "No extensions found.",
                        textAlign = TextAlign.Center,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(20.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(onClick = { showReposDialog = true }) {
                            Icon(Icons.Filled.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Repo Settings")
                        }
                        Button(onClick = { refresh() }) {
                            Text("Retry")
                        }
                    }
                }
                updatable.isEmpty() && notInstalled.isEmpty() -> Box(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState()),
                    contentAlignment = Alignment.Center
                ) { Text("No extension matches.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Section: Updates
                        if (updatable.isNotEmpty()) {
                            stickyHeader(key = "header_updates") {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.background)
                                        .padding(vertical = 8.dp)
                                ) {
                                    Text(
                                        text = "UPDATES (${updatable.size})",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        letterSpacing = 1.sp
                                    )
                                }
                            }
                            items(updatable, key = { "update_${it.pkgName}" }) { ext ->
                                val latest = availableByPkg[ext.pkgName]
                                val isBusy = installSteps.containsKey(ext.pkgName)
                                InstalledMangaExtensionItem(
                                    ext = ext,
                                    latest = latest,
                                    hasUpdate = true,
                                    isBusy = isBusy,
                                    onUninstall = { extensionToUninstall = ext },
                                    onUpdate = {
                                        if (latest != null) startInstallFlow(latest)
                                    },
                                    onMigrate = {
                                        if (latest != null) startInstallFlow(latest)
                                    }
                                )
                            }
                        }

                        // Section: Available
                        if (notInstalled.isNotEmpty()) {
                            stickyHeader(key = "header_available") {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(MaterialTheme.colorScheme.background)
                                        .padding(vertical = 8.dp)
                                ) {
                                    Text(
                                        text = "AVAILABLE (${notInstalled.size})",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        letterSpacing = 1.sp
                                    )
                                }
                            }
                            items(notInstalled, key = { "avail_${it.pkgName}" }) { info ->
                                val isBusy = installSteps.containsKey(info.pkgName)
                                AvailableMangaExtensionItem(
                                    info = info,
                                    isInstalled = false,
                                    isBusy = isBusy,
                                    onInstall = { startInstallFlow(info) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Dialog: Uninstall Confirmation
    val extToUninstall = extensionToUninstall
    if (extToUninstall != null) {
        LorelightDialog(
            onDismissRequest = { extensionToUninstall = null },
            title = { Text("Uninstall ${extToUninstall.name}?") },
            text = { Text("Its sources will be removed from Browse.") },
            isDestructive = true,
            confirmButton = {
                TextButton(
                    onClick = {
                        extensionToUninstall = null
                        scope.launch {
                            extensionManager.uninstallExtension(extToUninstall)
                            MangaSourcesCache.clear()
                        }
                    }
                ) {
                    Text("Uninstall", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { extensionToUninstall = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Dialog: Install Error Reasons
    val installReasons = installErrorReasons
    if (installReasons != null) {
        LorelightDialog(
            onDismissRequest = { installErrorReasons = null },
            title = { Text("Extension Action Failed") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 400.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    androidx.compose.foundation.text.selection.SelectionContainer {
                        Text(
                            text = installReasons,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        clipboardManager.setText(AnnotatedString(installReasons))
                    }
                ) {
                    Text("Copy")
                }
            },
            dismissButton = {
                TextButton(onClick = { installErrorReasons = null }) {
                    Text("Close")
                }
            }
        )
    }

    // Dialog: First-time Trust Warning
    val trustAction = pendingTrustAction
    if (trustAction != null) {
        LorelightDialog(
            onDismissRequest = { pendingTrustAction = null },
            title = { Text("Third-Party Extensions") },
            text = {
                Text("Extensions are Android packages containing executable code built by third parties. Only install extensions from repositories and developers you trust.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                            .edit().putBoolean(KEY_TRUST_WARNING_SEEN, true).apply()
                        val actionToRun = pendingTrustAction
                        pendingTrustAction = null
                        actionToRun?.invoke()
                    }
                ) {
                    Text("Continue")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingTrustAction = null }) {
                    Text("Cancel")
                }
            }
        )
    }


    // Dialog: Untrusted Signer Disclosure & Confirmation
    val untrustedExtension = pendingUntrustedExtension
    if (untrustedExtension != null) {
        LorelightDialog(
            onDismissRequest = { pendingUntrustedExtension = null },
            title = { Text("Trust Extension Signer?") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "This extension is signed with a certificate that has not been approved yet. Inspect the SHA-256 fingerprint below before proceeding:",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(8.dp)) {
                            Text("Package: ${untrustedExtension.pkgName}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Version: ${untrustedExtension.versionName} (${untrustedExtension.versionCode})", fontSize = 12.sp)
                            Spacer(Modifier.height(4.dp))
                            Text("Certificate SHA-256:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                untrustedExtension.signatureHash,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        pendingUntrustedExtension = null
                        scope.launch {
                            extensionManager.trust(untrustedExtension)
                        }
                    }
                ) {
                    Text("Trust & Install")
                }
            },
            dismissButton = {
                TextButton(onClick = { pendingUntrustedExtension = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showReposDialog) {
        Dialog(
            onDismissRequest = { showReposDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                com.lorelight.manga.ui.MangaBrowseSettingsScreen(
                    onBack = { showReposDialog = false },
                    onChanged = {
                        refresh()
                    }
                )
            }
        }
    }
}

@Composable
private fun HeaderActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    active: Boolean = false,
    onClick: () -> Unit
) {
    IconButton(
        onClick = onClick,
        modifier = Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(
                if (active) MaterialTheme.colorScheme.primaryContainer
                else MaterialTheme.colorScheme.surfaceVariant
            )
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (active) MaterialTheme.colorScheme.onPrimaryContainer
            else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun InstalledMangaExtensionItem(
    ext: Extension.Installed,
    latest: Extension.Available?,
    hasUpdate: Boolean,
    isBusy: Boolean,
    onUninstall: () -> Unit,
    onUpdate: () -> Unit,
    onMigrate: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val extIcon = ext.icon
            val iconUrl = ext.iconUrl ?: latest?.iconUrl
            if (extIcon != null) {
                Image(
                    bitmap = remember(extIcon) { extIcon.toBitmap().asImageBitmap() },
                    contentDescription = ext.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
            } else if (!iconUrl.isNullOrBlank()) {
                AsyncImage(
                    model = iconUrl,
                    contentDescription = ext.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                )
            } else {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = ext.name.firstOrNull()?.uppercase() ?: "?",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = ext.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${MangaLanguages.displayName(ext.lang)} • v${ext.versionName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (ext.isObsolete) {
                        Text(
                            text = "  •  OBSOLETE",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    if (ext.isNsfw) {
                        Text(
                            text = "  •  18+",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    if (!ext.isShared) {
                        Text(
                            text = "  •  PRIVATE",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (isBusy) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (hasUpdate) {
                        IconButton(onClick = onUpdate) {
                            Icon(
                                imageVector = Icons.Filled.FileDownload,
                                contentDescription = "Update",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    IconButton(onClick = onUninstall) {
                        Icon(
                            imageVector = Icons.Filled.Delete,
                            contentDescription = "Uninstall",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AvailableMangaExtensionItem(
    info: Extension.Available,
    isInstalled: Boolean,
    isBusy: Boolean,
    onInstall: () -> Unit,
    onUninstall: () -> Unit = {}
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = info.iconUrl,
                contentDescription = info.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = info.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${MangaLanguages.displayName(info.lang)} • v${info.versionName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (info.isNsfw) {
                        Text(
                            text = "  •  18+",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            if (isBusy) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
            } else if (isInstalled) {
                IconButton(
                    onClick = onUninstall,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        Icons.Filled.CheckCircle,
                        contentDescription = "Installed",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            } else {
                IconButton(onClick = onInstall) {
                    Icon(
                        imageVector = Icons.Filled.FileDownload,
                        contentDescription = "Install",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

private fun isMultiLang(lang: String): Boolean {
    return lang.equals("all", ignoreCase = true) ||
            lang.equals("multi", ignoreCase = true) ||
            lang == "32"
}

private fun getCleanName(name: String): String {
    return name.replace(Regex("\\s*\\([A-Za-z0-9_-]+\\)$"), "").trim().lowercase()
}

private fun getBasePkg(pkg: String, lang: String): String {
    return if (lang.isNotBlank() && pkg.contains(".${lang.lowercase()}.")) {
        pkg.replace(".${lang.lowercase()}.", ".").lowercase()
    } else {
        pkg.lowercase()
    }
}
