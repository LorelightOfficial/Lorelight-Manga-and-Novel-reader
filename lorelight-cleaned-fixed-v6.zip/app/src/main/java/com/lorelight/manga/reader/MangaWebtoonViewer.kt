package com.lorelight.manga.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.withFrameNanos
import kotlinx.coroutines.flow.first
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.toSize
import eu.kanade.tachiyomi.source.model.Page
import kotlinx.coroutines.launch
import kotlin.math.abs

internal fun webtoonContainerHeightPx(viewportHeightPx: Int, scale: Float): Int =
    if (scale < 1f) (viewportHeightPx / scale).toInt() else viewportHeightPx

/**
 * How many rows of drift a feed rebuild is allowed to cause before the reading
 * position is re-applied by key.
 *
 * A rebuild that lands within a row or two was handled correctly by LazyColumn
 * itself, and re-applying then would fight a fling that is still in flight. The
 * failure this tolerance exists to catch is a whole chapter wide -- 150 to 200
 * rows -- so anything above a couple of rows is real displacement.
 */
private const val ANCHOR_DRIFT_TOLERANCE = 2

/**
 * ANTI-STUTTER: remembers the width/height aspect ratio of every page image
 * decoded this session. Before this cache existed a page occupied a 300dp
 * placeholder until its bitmap arrived, then snapped to its real height. In a
 * long strip that snap shifts everything below it, which reads as scroll
 * stutter — and scrolling BACK up was worst, because items above the viewport
 * collapsed and the list visibly jumped. With the ratio cached, a page
 * reserves its exact final height the moment it enters composition, so the
 * layout never moves again when the bitmap lands.
 */
internal object MangaPageAspectCache {
    private val map = java.util.concurrent.ConcurrentHashMap<String, Float>()

    fun get(key: String): Float? = map[key]

    fun put(key: String, value: Float) {
        if (value > 0f && !value.isNaN()) {
            // Unbounded growth is impossible in practice (a few hundred floats
            // per reading session), but cap it defensively anyway.
            if (map.size > 2048) map.clear()
            map[key] = value
        }
    }
}

internal fun mangaPageAspectKey(page: Page, cropBorders: Boolean): String =
    (if (cropBorders) "c:" else "") + (page.imageUrl?.takeIf { it.isNotBlank() }
        ?: page.url.takeIf { it.isNotBlank() }?.let { "$it#${page.index}" }
        ?: "page_${page.index}")

@Composable
fun MangaWebtoonViewer(
    sourceId: Long,
    pages: List<Page>,
    currentPageIndex: Int,
    textColor: Color,
    sidePaddingPercent: Int,
    disableZoomOut: Boolean,
    doubleTapToZoom: Boolean,
    onPageChanged: (Int) -> Unit,
    onSingleTap: () -> Unit,
    pageColorFilter: androidx.compose.ui.graphics.ColorFilter? = null,
    modifier: Modifier = Modifier,
    readerBgColor: Color = Color.Black,
    pageGapDp: Int = 0,
    maxZoom: Float = 3f,
    doubleTapScale: Float = 2f,
    pageContentScale: ContentScale = ContentScale.FillWidth,
    cropBorders: Boolean = false,
    feedItems: List<MangaFeedItem>? = null,
    listState: androidx.compose.foundation.lazy.LazyListState = rememberLazyListState(),
    onActivePageChanged: ((chapterIndex: Int, pageIndex: Int) -> Unit)? = null,
    onVisibleChapterIdsChanged: ((Set<String>) -> Unit)? = null,
    onNearEndOrBoundary: (() -> Unit)? = null,
    onNextChapter: () -> Unit = {},
    onPrevChapter: () -> Unit = {}
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val coroutineScope = rememberCoroutineScope()

    val effectiveItems = remember(pages, feedItems) {
        feedItems ?: pages.mapIndexed { idx, p ->
            MangaFeedItem.Page(
                chapterId = "",
                chapterIndex = 0,
                pageIndex = idx,
                pageCount = pages.size,
                imageUrl = p.imageUrl ?: p.url,
                sourcePage = p
            )
        }
    }

    val transformState = rememberWebtoonTransformState()
    var containerSize by remember { mutableStateOf(Size.Zero) }

    // Page tracking must not run before the list has real geometry. Until the
    // first images are measured every row is effectively zero height, the whole
    // feed counts as visible, and the tracker reports a page several ahead of
    // the one on screen. That index is written back into reader state and the
    // restore effect scrolls to it, which is why a manga could open on page 3
    // or 7.
    var trackingEnabled by remember(effectiveItems) { mutableStateOf(false) }

    // CHAPTER-TELEPORT FIX -- the actual cause this time.
    //
    // The feed is rebuilt whenever a neighbouring chapter finishes loading or
    // the loaded window moves, and buildFeedItems() puts the PREVIOUS chapter's
    // pages IN FRONT of the current one. So every rebuild inserts or removes a
    // whole chapter's worth of rows ahead of the row being read: twenty in a
    // gag manga, but a hundred and fifty to two hundred in a long manhua.
    //
    // LazyColumn is supposed to absorb that by itself. It remembers the KEY of
    // the row at the top of the viewport and looks that key up again in the new
    // list. What is easy to miss is that the lookup is not global -- the key
    // map only covers a window of roughly a hundred and thirty rows around the
    // index it already had. A short chapter shifts the anchor less than that
    // and is found. A hundred-and-eighty-page chapter shifts it clean outside
    // the window, the key is not found, and the list silently keeps the old raw
    // INDEX instead. That index in the new list is almost exactly one chapter
    // away from the page the reader was on: forward when a chapter drops off
    // the front, backward when one is added.
    //
    // That is the whole bug, and it explains the shape of it exactly -- always
    // a chapter, never a page or two; forward while reading on, backward when
    // going back; and only on titles with huge chapters. Nothing was ever
    // "skipped": the list stopped pointing at the page it was pointing at, and
    // the tracker then honestly reported whatever had slid under the viewport.
    // Earlier fixes hardened the tracker, which is why they could not cure it.
    //
    // The anchor is therefore kept here rather than left to the list: the key
    // and pixel offset of the row on screen are recorded while the feed is
    // stable, and re-applied by key once the rebuilt feed has geometry. A key
    // names one exact page for as long as that page is in the feed, at any
    // distance. This is what mihon's webtoon adapter does after it splices a
    // chapter into the strip.
    var anchorKey by remember { mutableStateOf<String?>(null) }
    var anchorOffset by remember { mutableIntStateOf(0) }

    LaunchedEffect(sourceId, currentPageIndex) {
        MangaViewerPositionTracker.updateVisiblePage(sourceId, currentPageIndex)
    }

    LaunchedEffect(listState, effectiveItems) {
        trackingEnabled = false
        snapshotFlow {
            listState.layoutInfo.visibleItemsInfo.any { it.size > 0 }
        }.first { it }

        // Re-apply the anchor taken from the PREVIOUS feed. anchorKey is only
        // ever written by the collector at the bottom of this effect, and that
        // collector dies with the feed it belongs to, so the value read here is
        // always the position as it stood before this rebuild.
        val pendingKey = anchorKey
        if (pendingKey != null) {
            val newIndex = effectiveItems.indexOfFirst { feedItemKey(it) == pendingKey }
            if (newIndex >= 0 &&
                abs(listState.firstVisibleItemIndex - newIndex) > ANCHOR_DRIFT_TOLERANCE
            ) {
                // Bring the row to the top of the viewport, then hand back the
                // slice of it that had already been scrolled past. Two steps
                // because that slice can fall on either side of the viewport
                // edge, and this way the sign is never in question.
                listState.scrollToItem(newIndex)
                if (anchorOffset != 0) listState.scrollBy(anchorOffset.toFloat())
            }
        }

        // Let the restore scroll land before accepting any tracked position.
        withFrameNanos { }
        trackingEnabled = true

        // Record the anchor for THIS feed. This runs on scroll frames, so it
        // walks the visible rows once, stops at the first real page, and packs
        // the row index and its offset into a single Long instead of allocating
        // a pair sixty times a second.
        snapshotFlow {
            val layout = listState.layoutInfo
            val visible = layout.visibleItemsInfo
            var packed = Long.MIN_VALUE
            for (i in visible.indices) {
                val info = visible[i]
                if (info.size <= 0) continue
                val key = info.key as? String ?: continue
                if (!key.startsWith(PAGE_KEY_PREFIX)) continue
                val scrolledPast = layout.viewportStartOffset - info.offset
                packed = (info.index.toLong() shl 32) or (scrolledPast.toLong() and 0xFFFFFFFFL)
                break
            }
            packed
        }.collect { packed ->
            if (packed == Long.MIN_VALUE) return@collect
            val item = effectiveItems.getOrNull((packed shr 32).toInt())
            if (item is MangaFeedItem.Page) {
                anchorKey = feedItemKey(item)
                anchorOffset = packed.toInt()
            }
        }
    }

    // In-flight prefetch requests, keyed by their disk/memory cache key. The
    // tracked-page collector below keeps this reconciled to the current preload
    // window, and it is emptied when the viewer leaves composition. Before this
    // existed, every page crossing fired four requests that were never
    // cancelled; a fast fling queued dozens on the single download slot and they
    // kept downloading pages nobody was looking at anymore.
    val prefetchJobs = remember { HashMap<String, coil.request.Disposable>() }
    androidx.compose.runtime.DisposableEffect(listState, effectiveItems) {
        onDispose {
            for (d in prefetchJobs.values) d.dispose()
            prefetchJobs.clear()
        }
    }

    // Feed identity map: LazyColumn key -> its index in THIS feed. Rebuilt only
    // when the feed itself changes, so scrolling never touches it. This is what
    // lets the tracker below reason in keys while still reaching the plain index
    // that the prefetch window needs.
    val indexByKey = remember(effectiveItems) {
        HashMap<String, Int>(effectiveItems.size * 2).also { map ->
            for (i in effectiveItems.indices) map[feedItemKey(effectiveItems[i])] = i
        }
    }

    LaunchedEffect(listState, effectiveItems, indexByKey) {
        snapshotFlow {
            val layout = listState.layoutInfo
            val visibleInfo = layout.visibleItemsInfo
            // CHAPTER-JUMP FIX.
            //
            // The active page used to be "the first visible item, then walk
            // forward until a Page turns up". Near the end of a chapter the item
            // sitting at the top of the viewport becomes the NEXT transition, so
            // that walk stepped straight over it and reported the next chapter's
            // page 0 as active while the reader was still looking at the tail of
            // the current one. That flipped activeChapterIndex, which re-centred
            // the loaded window and rebuilt the feed under the user -- the
            // "suddenly I am a whole chapter ahead" jump, every time.
            //
            // Report the page that actually occupies the most of the viewport
            // instead. A sliver of the next chapter at either edge can no longer
            // take over, and no transition item can stand in for a page.
            //
            // SCROLL SMOOTHNESS. This block re-runs on EVERY scroll frame,
            // because item offsets are snapshot state that changes as the list
            // moves. The old version allocated on every run: a filtered list,
            // a chapter-id set, and a Triple -- dozens of throwaway objects per
            // second during a fling, and GC pauses land exactly when you are
            // scrolling fastest. Now it walks the visible rows once, allocates
            // nothing, and packs the two indices into a single Long. The id set
            // is rebuilt inside collect, which only runs when the packed value
            // actually changed (a page crossed, not a frame).
            //
            // TELEPORT FIX -- the actual cause, not the selection rule.
            //
            // Everything above only changed WHICH visible row to trust. The row
            // was still named by its INDEX, and that index was then looked up in
            // effectiveItems inside collect. Those two steps read different
            // lists. buildFeedItems() PREPENDS the previous chapter's pages, so
            // the instant a neighbour finishes loading, every index below it
            // shifts by a whole chapter -- around 250 rows in a long webtoon.
            // Index 502 stopped meaning "chapter 6, page 0" and started meaning
            // something deep in chapter 8. The tracker reported chapter 8, the
            // window re-centred on 8, and chapter 6 left the feed taking the
            // scroll anchor with it. That is why re-tuning the selection never
            // cured the jump: the broken step was the index lookup itself.
            //
            // Name the row by its LazyColumn KEY instead. A key identifies one
            // exact page for as long as that page exists, so a key captured a
            // frame ago either resolves to the same page or is missing from the
            // new feed and is skipped. It can never resolve to a different
            // chapter. Keys come straight off LazyListItemInfo and a single
            // String reference is emitted, so this still allocates nothing per
            // frame.
            val vpStart = layout.viewportStartOffset
            val vpEnd = layout.viewportEndOffset
            var dominantKey = ""
            var dominantShare = 0
            for (i in visibleInfo.indices) {
                val info = visibleInfo[i]
                if (info.size <= 0) continue
                val key = info.key as? String ?: continue
                if (!key.startsWith(PAGE_KEY_PREFIX)) continue
                val share = (minOf(info.offset + info.size, vpEnd) - maxOf(info.offset, vpStart)).coerceAtLeast(0)
                if (dominantKey.isEmpty() || share > dominantShare) {
                    dominantShare = share
                    dominantKey = key
                }
            }
            dominantKey
        }.collect { dominantKey ->
            // One pass over the LIVE layout: the chapter ids on screen and the
            // furthest visible row, both resolved through the key map so neither
            // can be a stale index either.
            var lastIdx = -1
            val visibleIds = HashSet<String>()
            for (info in listState.layoutInfo.visibleItemsInfo) {
                val key = info.key as? String ?: continue
                val idx = indexByKey[key] ?: continue
                if (idx > lastIdx) lastIdx = idx
                (effectiveItems.getOrNull(idx) as? MangaFeedItem.Page)?.let { visibleIds.add(it.chapterId) }
            }
            // Always update visible chapter IDs first so window-shifting can never act on stale IDs
            onVisibleChapterIdsChanged?.invoke(visibleIds)

            val pStart = if (dominantKey.isEmpty()) -1 else (indexByKey[dominantKey] ?: -1)
            if (trackingEnabled && pStart in effectiveItems.indices) {
                var pIdx = pStart
                while (pIdx < effectiveItems.size) {
                    val item = effectiveItems.getOrNull(pIdx)
                    if (item is MangaFeedItem.Page) {
                        MangaViewerPositionTracker.updateVisiblePage(sourceId, item.pageIndex)
                        onActivePageChanged?.invoke(item.chapterIndex, item.pageIndex)
                        onPageChanged(item.pageIndex)

                        // Mihon preloads exactly the next four pages after the
                        // current one, at a LOWER priority than the page being
                        // viewed. The old window was pIdx-3..pIdx+10: up to
                        // fourteen equal-priority requests fired on every scroll
                        // emission, with the visible page just one more item in
                        // that pile. That is why jumping to an unloaded page
                        // crawled while mihon lands it in a second.
                        //
                        // BOUNDED + CANCELLABLE. Requests that fall out of the
                        // window are disposed, so a fast fling no longer leaves
                        // a trail of stale downloads fighting the visible page
                        // for the single download slot, and a page already
                        // enqueued is never enqueued twice.
                        val imageLoader = MangaImageLoaderProvider.getImageLoader(context)
                        val startIdx = pIdx + 1
                        val endIdx = (pIdx + MangaImageLoaderProvider.prefetchWindow())
                            .coerceAtMost(effectiveItems.lastIndex)
                        val wanted = HashSet<String>()
                        for (i in startIdx..endIdx) {
                            val feedItem = effectiveItems.getOrNull(i)
                            if (feedItem is MangaFeedItem.Page) {
                                val pageObj = feedItem.sourcePage
                                    ?: Page(feedItem.pageIndex, feedItem.imageUrl, feedItem.imageUrl)
                                if (pageObj.status != Page.State.Ready) {
                                    wanted.add(mangaPageCacheKey(sourceId, pageObj, cropBorders))
                                }
                            }
                        }
                        val jobIt = prefetchJobs.entries.iterator()
                        while (jobIt.hasNext()) {
                            val entry = jobIt.next()
                            if (entry.key !in wanted) {
                                entry.value.dispose()
                                jobIt.remove()
                            }
                        }
                        for (i in startIdx..endIdx) {
                            val feedItem = effectiveItems.getOrNull(i)
                            if (feedItem is MangaFeedItem.Page) {
                                val pageObj = feedItem.sourcePage
                                    ?: Page(feedItem.pageIndex, feedItem.imageUrl, feedItem.imageUrl)
                                if (pageObj.status != Page.State.Ready) {
                                    val prefetchCacheKey = mangaPageCacheKey(sourceId, pageObj, cropBorders)
                                    if (!prefetchJobs.containsKey(prefetchCacheKey)) {
                                        val key = MangaPageKey(sourceId, pageObj)
                                        val req = coil.request.ImageRequest.Builder(context)
                                            .data(key)
                                            .setParameter(MANGA_PRIORITY_PARAM, MANGA_PRIORITY_ADJACENT)
                                            .memoryCacheKey(prefetchCacheKey)
                                            .diskCacheKey(prefetchCacheKey)
                                            .build()
                                        prefetchJobs[prefetchCacheKey] = imageLoader.enqueue(req)
                                    }
                                }
                            }
                        }

                        break
                    }
                    pIdx++
                }
            }

            // If user is near or at the end of the loaded feed items, trigger boundary prefetch callback
            if (lastIdx >= 0 && effectiveItems.isNotEmpty() && lastIdx >= effectiveItems.size - 3) {
                onNearEndOrBoundary?.invoke()
            }
        }
    }

    val atFirstPosition by remember {
        derivedStateOf {
            listState.firstVisibleItemIndex == 0 && listState.firstVisibleItemScrollOffset == 0
        }
    }

    val atLastPosition by remember {
        derivedStateOf {
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()
            lastVisible != null && lastVisible.index == effectiveItems.size - 1
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(readerBgColor)
            .clipToBounds()
            .onSizeChanged { containerSize = it.toSize() }
            .webtoonGestures(
                transformState = transformState,
                containerSize = containerSize,
                disableZoomOut = disableZoomOut,
                doubleTapToZoom = doubleTapToZoom,
                maxZoom = maxZoom,
                doubleTapScale = doubleTapScale,
                atFirstPosition = atFirstPosition,
                atLastPosition = atLastPosition
            )
            // When zoomed out, the page column is narrower than the viewport,
            // so the side margins are dead space: touches there never reach the
            // LazyColumn and scrolling only worked directly on a page. Forward a
            // single-finger vertical drag from those margins to the list.
            // Gated on the touch actually starting outside the scaled content,
            // so the list keeps handling its own drags and there is no race for
            // touch slop. Two-finger gestures bail out so pinch zoom is
            // untouched, and nothing is consumed before slop so tap-to-toggle
            // the UI still works.
            .pointerInput(listState) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val s = transformState.scale
                    if (s > 0.999f) return@awaitEachGesture
                    val halfContentW = size.width * s / 2f
                    val centerX = size.width / 2f + transformState.offset.x
                    if (abs(down.position.x - centerX) <= halfContentW) return@awaitEachGesture

                    var pastSlop = false
                    var accumulated = 0f
                    val slop = viewConfiguration.touchSlop
                    while (true) {
                        val event = awaitPointerEvent()
                        if (event.changes.size > 1) return@awaitEachGesture
                        val change = event.changes.firstOrNull() ?: return@awaitEachGesture
                        if (change.isConsumed || !change.pressed) return@awaitEachGesture
                        val dy = change.positionChange().y
                        if (!pastSlop) {
                            accumulated += dy
                            if (abs(accumulated) > slop) pastSlop = true
                        }
                        if (pastSlop && dy != 0f) {
                            change.consume()
                            coroutineScope.launch {
                                listState.scrollBy(-dy / s.coerceAtLeast(0.1f))
                            }
                        }
                    }
                }
            }
    ) {
        val vpW = constraints.maxWidth
        val vpH = constraints.maxHeight
        val scale = transformState.scale
        val offset = transformState.offset
        val contentH = webtoonContainerHeightPx(vpH, scale)

        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .requiredWidth(with(density) { vpW.toDp() })
                .requiredHeight(with(density) { contentH.toDp() })
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    transformOrigin = TransformOrigin(0.5f, 0.5f)
                    translationX = offset.x
                    translationY = offset.y
                }
        ) {
            val horizontalPadding = if (sidePaddingPercent > 0) (sidePaddingPercent * 1.5f).dp else 0.dp

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = horizontalPadding),
                verticalArrangement = if (pageGapDp > 0) Arrangement.spacedBy(pageGapDp.dp) else Arrangement.Top
            ) {
                items(
                    effectiveItems,
                    key = { item -> feedItemKey(item) },
                    // Lets LazyColumn reuse compositions within each kind of
                    // row instead of tearing them down across kinds.
                    contentType = { item ->
                        if (item is MangaFeedItem.Page) "page" else "transition"
                    }
                ) { item ->
                    when (item) {
                        is MangaFeedItem.Page -> {
                            val pageObj = remember(item) {
                                item.sourcePage
                                    ?: Page(item.pageIndex, item.imageUrl, item.imageUrl)
                            }
                            WebtoonPageItem(
                                sourceId = sourceId,
                                page = pageObj,
                                textColor = textColor,
                                pageContentScale = pageContentScale,
                                pageColorFilter = pageColorFilter,
                                cropBorders = cropBorders,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        is MangaFeedItem.Transition -> {
                            WebtoonTransitionItem(
                                transition = item,
                                textColor = textColor,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WebtoonTransitionItem(
    transition: MangaFeedItem.Transition,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 72.dp)
            .padding(horizontal = 32.dp, vertical = 20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = textColor.copy(alpha = 0.20f)
        )
        Column(
            modifier = Modifier.padding(horizontal = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val toName = transition.toChapterName
            if (toName != null) {
                val chNum = transition.toChapterIndex?.let { it + 1 }?.toString() ?: ""
                val headerText = if (chNum.isNotBlank()) "Chapter $chNum starts here" else "Next chapter starts here"
                Text(
                    text = headerText,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = textColor.copy(alpha = 0.75f)
                )
                Text(
                    text = toName,
                    fontSize = 12.sp,
                    color = textColor.copy(alpha = 0.45f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            } else if (transition.toChapterIndex != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = textColor,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Loading chapter...",
                        fontSize = 13.sp,
                        color = textColor.copy(alpha = 0.75f)
                    )
                }
            } else {
                val label = if (transition.kind == MangaFeedItem.Transition.Kind.PREV) {
                    "This is the first chapter"
                } else {
                    "You have reached the end"
                }
                Text(
                    text = label,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = textColor.copy(alpha = 0.75f)
                )
            }
        }
        HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = textColor.copy(alpha = 0.20f)
        )
    }
}

@Composable
fun WebtoonPageItem(
    sourceId: Long,
    page: Page,
    textColor: Color,
    pageContentScale: ContentScale = ContentScale.FillWidth,
    pageColorFilter: androidx.compose.ui.graphics.ColorFilter? = null,
    cropBorders: Boolean = false,
    modifier: Modifier = Modifier
) {
    var retryKey by remember { mutableIntStateOf(0) }
    var autoRetryCount by remember(page) { mutableIntStateOf(0) }
    val context = LocalContext.current
    val imageLoader = remember(context) { MangaImageLoaderProvider.getImageLoader(context) }

    val pageCacheKey = remember(sourceId, page, cropBorders) {
        mangaPageCacheKey(sourceId, page, cropBorders)
    }

    val isCachedInRam = remember(pageCacheKey) {
        imageLoader.memoryCache?.get(coil.memory.MemoryCache.Key(pageCacheKey)) != null
    }
    val isCachedOnDisk = remember(pageCacheKey) {
        imageLoader.diskCache?.get(pageCacheKey)?.use { true } ?: false
    }

    val isAlreadyLoaded = page.status == Page.State.Ready || isCachedInRam || isCachedOnDisk

    var currentState by remember(page, retryKey) {
        mutableStateOf(if (isAlreadyLoaded) Page.State.Ready else page.status)
    }
    var isImageLoading by remember(page, retryKey) {
        mutableStateOf(!isAlreadyLoaded)
    }

    // Global "restart stuck page loads" from Settings > Advanced. A page that
    // already decoded keeps its bitmap; only unfinished ones are re-requested.
    val globalRetry by MangaPageRetryBus.version.collectAsState()
    LaunchedEffect(globalRetry) {
        if (globalRetry == 0) return@LaunchedEffect
        if (currentState is Page.State.Ready) return@LaunchedEffect
        autoRetryCount = 0
        clearMangaPageTempFiles(context, sourceId, page)
        page.status = Page.State.Queue
        currentState = Page.State.Queue
        retryKey++
    }

    // Auto-retry when a previously failed or un-cached page is revisited
    LaunchedEffect(page, currentState) {
        if (currentState is Page.State.Error && autoRetryCount < 2) {
            autoRetryCount++
            clearMangaPageTempFiles(context, sourceId, page)
            page.status = Page.State.Queue
            currentState = Page.State.Queue
            retryKey++
        }
    }

    // Stable identity for the height cache: survives recomposition, feed
    // rebuilds, and chapter-window shifts (page objects are recreated there).
    val aspectKey = remember(page, cropBorders) { mangaPageAspectKey(page, cropBorders) }
    var knownAspect by remember(aspectKey) { mutableStateOf(MangaPageAspectCache.get(aspectKey)) }

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        when (val s = currentState) {
            is Page.State.Error -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    androidx.compose.material3.Text(
                        text = "Failed to load page ${page.number}: ${s.error.localizedMessage ?: "Unknown error"}",
                        color = textColor,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    androidx.compose.material3.Button(
                        onClick = {
                            autoRetryCount = 0
                            clearMangaPageTempFiles(context, sourceId, page)
                            page.status = Page.State.Queue
                            currentState = Page.State.Queue
                            retryKey++
                        }
                    ) {
                        androidx.compose.material3.Text("Retry")
                    }
                }
            }
            else -> {
                // While the ratio is known, hard-reserve the final height via
                // aspectRatio so the strip never reflows when the bitmap lands.
                val imageSizing = if (knownAspect != null) {
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(knownAspect!!, matchHeightConstraintsFirst = false)
                } else {
                    Modifier.fillMaxWidth()
                }

                Box(contentAlignment = Alignment.Center) {
                    coil.compose.AsyncImage(
                        model = coil.request.ImageRequest.Builder(context)
                            .data(MangaPageKey(sourceId, page))
                            .setParameter("retry", retryKey)
                            // The page actually on screen outranks every
                            // preloaded neighbour in the download queue.
                            .setParameter(MANGA_PRIORITY_PARAM, MANGA_PRIORITY_VISIBLE)
                            // Stable keys => Coil reliably returns the already
                            // decoded/cached bitmap instead of reloading it.
                            .memoryCacheKey(pageCacheKey)
                            .diskCacheKey(pageCacheKey)
                            // Instantly reuse the bitmap already in the memory
                            // cache as the placeholder, so a recycled page draws
                            // its image on the first frame with no empty gap.
                            .placeholderMemoryCacheKey(pageCacheKey)
                            // Decode at the source's own resolution instead of
                            // letting the layout size decide it. Without this,
                            // Coil sizes the bitmap to the view, so a page wider
                            // than the screen was thrown away down to screen
                            // width -- fine while the page sits at 1x, soft the
                            // moment it is zoomed, and the reason double-page
                            // spreads and high-resolution scans looked worse here
                            // than in mihon. Enormous pages are still bounded:
                            // MangaTallImageDecoder claims anything tall or over
                            // budget and applies its own ceiling.
                            .size(coil.size.Size.ORIGINAL)
                            .crossfade(false)
                            .apply {
                                if (cropBorders) transformations(CropBordersTransformation())
                            }
                            .build(),
                        imageLoader = imageLoader,
                        contentDescription = "Page ${page.number}",
                        contentScale = pageContentScale,
                        colorFilter = pageColorFilter,
                        onLoading = {
                            if (!isAlreadyLoaded) {
                                isImageLoading = true
                                page.status = Page.State.LoadPage
                                currentState = Page.State.LoadPage
                            }
                        },
                        onSuccess = { result ->
                            autoRetryCount = 0
                            isImageLoading = false
                            page.status = Page.State.Ready
                            currentState = Page.State.Ready
                            val d = result.result.drawable
                            if (d.intrinsicWidth > 0 && d.intrinsicHeight > 0) {
                                val ratio = d.intrinsicWidth.toFloat() / d.intrinsicHeight.toFloat()
                                MangaPageAspectCache.put(aspectKey, ratio)
                                if (knownAspect == null) knownAspect = ratio
                            }
                        },
                        onError = { result ->
                            isImageLoading = false
                            val err = result.result.throwable
                            if (autoRetryCount < 2) {
                                autoRetryCount++
                                clearMangaPageTempFiles(context, sourceId, page)
                                page.status = Page.State.Queue
                                currentState = Page.State.Queue
                                retryKey++
                            } else {
                                page.status = Page.State.Error(err)
                                currentState = Page.State.Error(err)
                            }
                        },
                        modifier = imageSizing
                    )

                    if (isImageLoading && currentState != Page.State.Ready) {
                        val placeholderModifier = if (knownAspect != null) {
                            Modifier
                                .fillMaxWidth()
                                .aspectRatio(knownAspect!!, matchHeightConstraintsFirst = false)
                        } else {
                            Modifier
                                .fillMaxWidth()
                                .height(300.dp)
                        }
                        Box(
                            modifier = placeholderModifier
                                .background(Color.Black.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            // Determinate ring, like mihon's. The old spinner
                            // looked identical whether a page was arriving
                            // briskly or had stalled outright.
                            val progressKey = remember(sourceId, page) {
                                mangaPageProgressKey(sourceId, page)
                            }
                            val dlProgress by MangaPageProgress
                                .observe(progressKey)
                                .collectAsState()
                            if (dlProgress > 0f) {
                                androidx.compose.material3.CircularProgressIndicator(
                                    progress = { dlProgress },
                                    color = textColor
                                )
                            } else {
                                androidx.compose.material3.CircularProgressIndicator(color = textColor)
                            }
                        }
                    }
                }
            }
        }
    }
}
