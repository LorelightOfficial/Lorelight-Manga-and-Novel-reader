package com.lorelight.manga.reader

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.tts.TtsPlaybackManager

/**
 * Accent / Voice / Speed controls for the manga reader's experimental read-aloud.
 *
 * These write to MangaReaderPrefs, never to TtsPlaybackManager.
 *
 * The previous version called TtsPlaybackManager.selectAccentAndApply,
 * selectVoiceAndApply and setSpeechRateAndApply. That object is the NOVEL
 * reader's live playback state, and those functions also persist into the novel
 * reader's own "reader_prefs" store -- so choosing a voice or a speed for manga
 * silently changed novel playback too. Nothing here touches it now.
 *
 * The device voice inventory is still read from TtsPlaybackManager, because
 * allVoices / availableAccents are only a list of what the speech engine
 * offers. Reading them carries no user setting in either direction.
 */
@Composable
fun MangaTtsVoiceControls() {
    val context = LocalContext.current
    val allVoices by TtsPlaybackManager.allVoices.collectAsState()
    val availableAccents by TtsPlaybackManager.availableAccents.collectAsState()

    var accent by remember { mutableStateOf(MangaReaderPrefs.getTtsAccent(context)) }
    var voiceName by remember { mutableStateOf(MangaReaderPrefs.getTtsVoiceName(context)) }
    var rate by remember { mutableFloatStateOf(MangaReaderPrefs.getTtsRate(context)) }

    // Fills the engine's voice inventory if nothing has needed it yet. This is
    // the only call still made into the manager, and it only restores the novel
    // reader's own saved choice -- it cannot carry a manga choice across.
    LaunchedEffect(Unit) {
        if (allVoices.isEmpty()) {
            TtsPlaybackManager.updateFilteredVoicesAndSelectDefault()
        }
    }

    // Voices for the accent chosen HERE, not the one the novel reader is on.
    val voices = remember(allVoices, accent) {
        val code = countryCodeForAccent(accent)
        val matching = allVoices
            .filter { it.locale.country.equals(code, ignoreCase = true) }
            .sortedBy { it.name }
        matching.ifEmpty { allVoices }
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // ---- Accent ----
        Column(modifier = Modifier.weight(1f)) {
            Text(
                "Accent",
                fontWeight = FontWeight.Medium,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            var open by remember { mutableStateOf(false) }
            Box(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                        .clickable { open = true }
                        .padding(horizontal = 8.dp, vertical = 10.dp)
                ) {
                    Text(
                        accent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(
                        Icons.Default.ArrowDropDown,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    availableAccents.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option, fontSize = 13.sp) },
                            onClick = {
                                accent = option
                                MangaReaderPrefs.setTtsAccent(context, option)
                                // The voice list follows the accent, so a voice
                                // from the old country would no longer be in it.
                                val code = countryCodeForAccent(option)
                                val first = allVoices
                                    .filter { it.locale.country.equals(code, ignoreCase = true) }
                                    .sortedBy { it.name }
                                    .firstOrNull()
                                if (first != null) {
                                    voiceName = first.name
                                    MangaReaderPrefs.setTtsVoiceName(context, first.name)
                                }
                                open = false
                            }
                        )
                    }
                }
            }
        }

        // ---- Voice ----
        Column(modifier = Modifier.weight(1f)) {
            Text(
                "Voice",
                fontWeight = FontWeight.Medium,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            var open by remember { mutableStateOf(false) }
            Box(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                        .clickable { open = true }
                        .padding(horizontal = 8.dp, vertical = 10.dp)
                ) {
                    val shown = voiceName?.replace("en-us-x-", "")?.replace("-local", "")
                    Text(
                        shown ?: "Default",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(
                        Icons.Default.ArrowDropDown,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    voices.forEach { voice ->
                        DropdownMenuItem(
                            text = { Text(voice.name, fontSize = 13.sp) },
                            onClick = {
                                voiceName = voice.name
                                MangaReaderPrefs.setTtsVoiceName(context, voice.name)
                                open = false
                            }
                        )
                    }
                }
            }
        }

        // ---- Speed ----
        Column(modifier = Modifier.weight(0.7f)) {
            Text(
                "Speed",
                fontWeight = FontWeight.Medium,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            var open by remember { mutableStateOf(false) }
            Box(modifier = Modifier.fillMaxWidth()) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                        .clickable { open = true }
                        .padding(horizontal = 8.dp, vertical = 10.dp)
                ) {
                    Text(
                        "%.2fx".format(rate),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(
                        Icons.Default.ArrowDropDown,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f, 2.5f, 3.0f).forEach { option ->
                        DropdownMenuItem(
                            text = { Text("%.2fx".format(option)) },
                            onClick = {
                                rate = option
                                MangaReaderPrefs.setTtsRate(context, option)
                                open = false
                            }
                        )
                    }
                }
            }
        }
    }
}

/**
 * "United States (US)" -> "US". Mirrors the manager's own private helper, which
 * cannot be called from here. UK is spelled GB in locale data.
 */
private fun countryCodeForAccent(accent: String): String {
    val start = accent.indexOf('(')
    val end = accent.indexOf(')')
    if (start != -1 && end > start) {
        val code = accent.substring(start + 1, end)
        if (code.equals("UK", ignoreCase = true)) return "GB"
        return code
    }
    return "US"
}
