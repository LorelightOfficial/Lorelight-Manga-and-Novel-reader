package com.lorelight.manga.reader

import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Autoscroll speed control for the manga reader.
 *
 * REBUILT to match the novel reader's autoscroll panel exactly, which is the
 * one the user actually wanted: a compact 260.dp card pinned to the TOP END of
 * the screen, holding a single 46.dp row of play/pause + slider + a live speed
 * readout. The previous version was a wide GlassPanel anchored to the bottom
 * end, 150.dp up from the navigation bar, which covered the page being read and
 * sat nowhere near the top-bar button that raises it.
 *
 * The play/pause button lives INSIDE the panel now, so the panel is no longer
 * tied to a run already being in progress: the top-bar icon raises the panel,
 * and the panel starts and stops the run. That is how the novel reader behaves.
 *
 * There is deliberately no dismiss scrim. A full-screen scrim would swallow the
 * next tap anywhere on the page, and the caller already hides the panel a few
 * seconds after the last interaction.
 *
 * [onSpeedChange] fires continuously while the slider is dragged so the change
 * is felt immediately, and [onSpeedCommit] fires once on release. Keeping the
 * two apart matters: persisting on every tick would notify AppSettingsSignal
 * dozens of times per drag, and every reader preference is keyed on that
 * signal, so the whole screen would re-read its settings mid-gesture.
 */
@Composable
fun MangaAutoscrollPanel(
    speed: Int,
    running: Boolean,
    highlightColor: Color,
    bgColor: Color,
    textColor: Color,
    onToggleRunning: () -> Unit,
    onSpeedChange: (Int) -> Unit,
    onSpeedCommit: () -> Unit,
    topPadding: Dp = 8.dp,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = bgColor),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
            modifier = Modifier
                .align(Alignment.TopEnd)
                // [topPadding] is what makes the panel adaptive. The caller
                // pushes it below the top bar while the chrome is up, and lets
                // it rise to the very top once the chrome hides, so the panel
                // always sits just under the button that raised it and never
                // floats over a bar it is supposed to belong to.
                .padding(top = topPadding, end = 12.dp)
                .width(260.dp)
                .border(1.dp, textColor.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Play/pause takes 30% of the row, matching the novel reader.
                Box(
                    modifier = Modifier
                        .weight(0.3f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.Center
                ) {
                    FilledIconButton(
                        onClick = onToggleRunning,
                        colors = IconButtonDefaults.filledIconButtonColors(
                            containerColor = highlightColor,
                            contentColor = bgColor
                        ),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (running) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (running) "Pause autoscroll" else "Start autoscroll",
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Slider plus readout take the remaining 70%.
                Row(
                    modifier = Modifier
                        .weight(0.7f)
                        .fillMaxHeight(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Start
                ) {
                    Slider(
                        value = speed.toFloat(),
                        onValueChange = { onSpeedChange(it.toInt()) },
                        onValueChangeFinished = onSpeedCommit,
                        valueRange = 20f..400f,
                        colors = SliderDefaults.colors(
                            thumbColor = highlightColor,
                            activeTrackColor = highlightColor,
                            inactiveTrackColor = textColor.copy(alpha = 0.15f)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(24.dp)
                            .padding(horizontal = 4.dp)
                    )
                    Text(
                        text = "$speed",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = textColor,
                        modifier = Modifier
                            .padding(end = 4.dp)
                            .width(28.dp)
                    )
                }
            }
        }
    }
}

/**
 * The only autoscroll control that survives the chrome hiding itself.
 *
 * When "pause on touch" is OFF the reader deliberately keeps scrolling through
 * taps, and the chrome auto-hides a moment after a run starts, so there was no
 * way at all to stop a run without first tapping to bring the whole top bar
 * back. This is a small floating pause button that appears only in exactly that
 * situation: a run in progress, chrome hidden, pause-on-touch off.
 */
@Composable
fun MangaAutoscrollFloatingPause(
    highlightColor: Color,
    bgColor: Color,
    onPause: () -> Unit,
    modifier: Modifier = Modifier
) {
    FilledIconButton(
        onClick = onPause,
        colors = IconButtonDefaults.filledIconButtonColors(
            containerColor = bgColor.copy(alpha = 0.62f),
            contentColor = highlightColor
        ),
        modifier = modifier.size(40.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Pause,
            contentDescription = "Pause autoscroll",
            modifier = Modifier.size(20.dp)
        )
    }
}
