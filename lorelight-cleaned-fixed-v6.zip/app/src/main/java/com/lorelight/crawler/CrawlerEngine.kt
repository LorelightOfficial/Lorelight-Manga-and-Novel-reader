// =====================================================================
// CrawlerEngine.kt  —  LORELIGHT CRAWLER ENGINE (Universal)
// =====================================================================
// Drop-in replacement for com.lorelight.crawler.CrawlerEngine
// Compatible with existing CrawlerDownloadDialog.kt
//
// This engine is a single best-effort UNIVERSAL crawler used for any
// user-added website. There is no site-specific parsing here — every URL
// is analyzed with the same generic content-density heuristics.
// =====================================================================

package com.lorelight.crawler

import android.content.Context
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URI
import com.lorelight.ui.reader.ReaderBlock
import com.lorelight.ui.reader.toJsonString
import com.lorelight.ui.reader.toReaderBlocks

// ---------------------------------------------------------------------
// DATA MODELS  (unchanged — keep compatibility with the rest of the app)
// ---------------------------------------------------------------------
data class CrawledNovel(
    val title: String,
    val author: String,
    val description: String,
    val coverUrl: String?,
    val sourceUrl: String,
    val chapters: List<CrawledChapter>,
    val genres: List<String> = emptyList(),
    val status: String = "Ongoing"
)

data class CrawledChapter(
    val index: Int,
    val title: String,
    val url: String
)

object CrawlerEngine {

    val cacheUpdateTrigger = kotlinx.coroutines.flow.MutableStateFlow(0)

    fun triggerCacheUpdate() {
        cacheUpdateTrigger.value = cacheUpdateTrigger.value + 1
    }

    // -----------------------------------------------------------------
    // CONSTANTS
    // -----------------------------------------------------------------
    internal const val MOBILE_UA =
        "Mozilla/5.0 (Linux; Android 11; OPPO CPH1933) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    private const val DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private fun log(tag: String, msg: String) {
        try { com.lorelight.core.DiagnosticLogger.log(tag, msg) } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError("CrawlerEngine.log", e) }
    }

    // -----------------------------------------------------------------
    // PUBLIC: is this a homepage / listing rather than a novel page?
    // -----------------------------------------------------------------
    fun isProbablyHomepageUrl(url: String): Boolean {
        val cleanUrl = url.trim().lowercase().removeSuffix("/")
        try {
            val uri = URI(cleanUrl)
            val path = uri.path ?: ""

            if (path.isEmpty() || path == "/" || path == "/index.html" || path == "/home" ||
                path == "/index.php" || path == "/index" || path == "/main") return true

            if (path.contains("/search") || path.contains("/browse") || path.contains("/tag/") ||
                path.contains("/genres") || path.contains("/category") || path.contains("/listings") ||
                path.contains("/all-novels") || path == "/authors" || path == "/popular" ||
                path == "/updates" || path.contains("/latest-releases") || path.contains("/active-popular") ||
                path.contains("/sort/")
            ) return true

            val baseRegex = Regex("""^(https?://)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}/?$""")
            if (baseRegex.matches(cleanUrl)) return true
        } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError("CrawlerEngine.isProbablyHomepageUrl", e) }
        return false
    }

    // -----------------------------------------------------------------
    // PUBLIC: analyze a novel landing page
    // -----------------------------------------------------------------
    suspend fun analyzeUrl(url: String, context: Context? = null): CrawledNovel =
        withContext(Dispatchers.IO) {
            log("CRAWLER", "Starting analyzeUrl: $url")

            val (doc, currentUrl) = fetchGenericPage(url)
            val baseUri = URI(currentUrl)

            val title = extractTitle(doc)
            val author = extractAuthor(doc)
            val description = extractDescription(doc)
            val rawCoverUrl = extractCoverUrl(doc, baseUri)
            val genres = extractGenres(doc)
            val status = extractStatus(doc)

            val chapters = extractChapters(doc, baseUri)

            log("CRAWLER", "analyzeUrl done: '$title' chapters=${chapters.size}")

            val novelId = java.util.UUID.nameUUIDFromBytes(title.toByteArray()).toString()
            val base64Cover = downloadImageAsBase64(rawCoverUrl, context, novelId) ?: rawCoverUrl

            CrawledNovel(
                title = title.ifBlank { "Unknown Title" },
                author = author.ifBlank { "Unknown Author" },
                description = description.ifBlank { "No description available." },
                coverUrl = base64Cover,
                sourceUrl = url,
                chapters = chapters,
                genres = genres,
                status = status
            )
        }

    // -----------------------------------------------------------------
    // PUBLIC: analyze ONLY a novel landing page's metadata
    // -----------------------------------------------------------------
    suspend fun analyzeMetadata(url: String, context: Context): CrawledNovel =
        withContext(Dispatchers.IO) {
            log("CRAWLER", "Starting analyzeMetadata: $url")

            val (doc, currentUrl) = fetchGenericPage(url)
            val baseUri = URI(currentUrl)

            val title = extractTitle(doc)
            val author = extractAuthor(doc)
            val description = extractDescription(doc)
            val rawCoverUrl = extractCoverUrl(doc, baseUri)
            val genres = extractGenres(doc)
            val status = extractStatus(doc)

            if (title.isBlank()) {
                throw Exception("Could not find a valid title on the page.")
            }

            val novelId = java.util.UUID.nameUUIDFromBytes(title.toByteArray()).toString()
            val base64Cover = downloadImageAsBase64(rawCoverUrl, context, novelId) ?: rawCoverUrl

            CrawledNovel(
                title = title,
                author = author.ifBlank { "Unknown Author" },
                description = description.ifBlank { "No description available." },
                coverUrl = base64Cover,
                sourceUrl = url,
                chapters = emptyList(),
                genres = genres,
                status = status
            )
        }

    // -----------------------------------------------------------------
    // PUBLIC: stream chapters in background
    // -----------------------------------------------------------------
    suspend fun streamChapters(
        url: String,
        context: Context,
        onBatch: suspend (List<CrawledChapter>, Int) -> Unit
    ) = withContext(Dispatchers.IO) {
        log("CRAWLER", "streamChapters started for: $url")
        val baseUri = URI(url)

        val doc: Document = fetchGenericPage(url).first
        var chapters = extractChapters(doc, baseUri)
        if (chapters.isEmpty()) chapters = looseChapterScan(doc, baseUri)
        log("CRAWLER", "streamChapters: found ${chapters.size} chapters")
        if (chapters.isEmpty()) {
            throw Exception("Couldn't automatically find a chapter list on this page. Open the novel's main page (its table of contents) and try adding it again.")
        }
        onBatch(chapters, chapters.size)
    }

    // -----------------------------------------------------------------
    // NETWORK HELPERS
    // -----------------------------------------------------------------
    /** Maps low-level network/parse exceptions to clear, user-facing messages. */
    private fun friendlyError(e: Exception): Exception {
        val msg = when {
            e is org.jsoup.HttpStatusException -> when (e.statusCode) {
                403, 503 -> "This site blocked the app's request — it likely uses Cloudflare or bot protection, so it isn't supported yet."
                404 -> "Page not found (404). Please double-check the novel's URL."
                429 -> "This site is temporarily rate-limiting requests. Please wait a bit and try again."
                in 500..599 -> "The site is having server problems (error ${e.statusCode}). Please try again later."
                else -> "The site returned an error (${e.statusCode}). It may not be supported yet."
            }
            e is java.net.SocketTimeoutException -> "The site took too long to respond. Check your connection and try again."
            e is java.net.UnknownHostException -> "Couldn't reach this site. Check the URL and your internet connection."
            e is javax.net.ssl.SSLException -> "Couldn't establish a secure connection to this site."
            else -> "Couldn't load this page. This site may not be supported yet."
        }
        return Exception(msg)
    }

    private fun fetchGenericPage(startUrl: String): Pair<Document, String> {
        var currentUrl = startUrl
        return try {
            Jsoup.connect(currentUrl).userAgent(DESKTOP_UA).timeout(15000).get() to currentUrl
        } catch (e: Exception) {
            try {
                if (currentUrl.startsWith("https://")) {
                    android.util.Log.w("CrawlerEngine", "HTTPS failed, retrying over insecure HTTP: $currentUrl")
                    currentUrl = currentUrl.replaceFirst("https://", "http://")
                    Jsoup.connect(currentUrl).userAgent(DESKTOP_UA).timeout(15000).get() to currentUrl
                } else throw e
            } catch (e2: Exception) {
                throw friendlyError(e2)
            }
        }
    }

    // -----------------------------------------------------------------
    // COVER IMAGE -> FILE or BASE64
    // -----------------------------------------------------------------
    private suspend fun downloadImageAsBase64(imageUrl: String?, context: Context? = null, novelId: String? = null): String? = withContext(Dispatchers.IO) {
        if (imageUrl.isNullOrBlank()) return@withContext null
        log("CRAWLER", "Downloading cover: $imageUrl")
        try {
            val connection = Jsoup.connect(imageUrl)
                .ignoreContentType(true)
                .userAgent(DESKTOP_UA)
                .header("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8")
                .header("Connection", "keep-alive")
                .timeout(10000)
            val cookies = try { android.webkit.CookieManager.getInstance().getCookie(imageUrl) } catch (_: Exception) { null }
            if (!cookies.isNullOrBlank()) connection.header("Cookie", cookies)
            val response = connection.execute()
            val bytes = response.bodyAsBytes()
            if (bytes != null && bytes.isNotEmpty()) {
                if (context != null && !novelId.isNullOrEmpty()) {
                    val path = com.lorelight.data.local.CoverStorage.saveCoverBytes(context, novelId, bytes)
                    if (path != null) return@withContext path
                }
                android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
            } else null
        } catch (e: Exception) {
            log("CRAWLER_WARN", "Cover base64 failed: ${e.message}")
            null
        }
    }

    // -----------------------------------------------------------------
    // METADATA EXTRACTION
    // -----------------------------------------------------------------
    private fun extractTitle(doc: Document): String {
        return doc.select("h1, .post-title, .novel-title, .title").firstOrNull()?.text()
            ?: doc.title().replace(Regex("(?i)-.*(read|novel).*$"), "").trim()
    }

    private fun extractAuthor(doc: Document): String {
        val cleanDoc = doc.clone()
        listOf("header","footer","nav",".nav",".navigation",".footer",".header","#header","#footer",
            ".sidebar","#sidebar",".menu",".menu-container",".navbar","#navbar",".top-bar",".footer-links","#navigation")
            .forEach { cleanDoc.select(it).remove() }

        val candidates = mutableListOf<String>()
        val metaBooksAuthor = doc.select("meta[property=\"books:author\"], meta[property=\"book:author\"], meta[name=\"author\"], meta[property=\"og:book:author\"], meta[name=\"twitter:creator\"]").attr("content").trim()
        if (metaBooksAuthor.isNotBlank()) candidates.add(metaBooksAuthor)

        listOf("[itemprop=author] [itemprop=name]","[itemprop=author]","span[itemprop=name]",".author",
            ".novel-author",".info-author",".property-author","[itemprop=creator]","a[href*=/author/]",
            "a[class*=author]",".writer",".byline")
            .forEach { sel -> cleanDoc.select(sel).text().trim().let { if (it.isNotBlank()) candidates.add(it) } }

        cleanDoc.select("p:contains(Author), div:contains(Author), span:contains(Author), td:contains(Author)")
            .forEach { el -> el.text().trim().let { if (it.isNotBlank()) candidates.add(it) } }

        val infoText = cleanDoc.select(".info").text().trim()
        if (infoText.isNotBlank() && infoText.contains("Author", true)) candidates.add(infoText)

        val cleaned = candidates.map { raw ->
            raw.replace(Regex("(?i)^by\\s+"), "")
               .replace(Regex("(?i)^author:?\\s*"), "")
               .replace(Regex("(?i)\\bauthor:?\\s*"), "")
               .replace(Regex("(?i)\\bby\\s+"), "")
               .replace("\n", " ").replace(Regex("\\s+"), " ").trim()
        }.filter {
            it.isNotBlank() && it.length < 60 &&
            !it.contains("chapter", true) && !it.contains("webnovel", true) &&
            !it.contains("royalroad", true) && !it.contains("novelfull", true) &&
            !it.contains("read", true) && !it.contains("novel", true)
        }

        val best = cleaned.firstOrNull() ?: "Unknown Author"
        if (best == "Unknown Author") {
            val classified = ElementClassifier(cleanDoc).classifyAuthor()
            if (classified != null && classified.score > 20.0) return classified.text
        }
        return best
    }

    private fun extractDescription(doc: Document): String {
        val classified = ElementClassifier(doc).classifyDescription()
        if (classified != null && classified.score > 20.0) return classified.text

        val metaDesc = doc.select("meta[property=og:description], meta[name=description]").attr("content").trim()
        val candidates = doc.select(".m-desc .txt, .inner, .description, .summary, [itemprop=description], .manga-info-text, .novel-synopsis, .synopsis, .desc, #info, .content-inner")
        var bestText = ""
        candidates.forEach { element ->
            val clone = element.clone()
            clone.select("ul, li, a, h1, h2, h3, .genres, .author, .status, .metadata").remove()
            val text = clone.select("p").joinToString("\n") { it.text().trim() }
            val finalText = if (text.isNotBlank()) text else clone.text()
            if (finalText.length > bestText.length && finalText.length < 5000) bestText = finalText
        }
        if (bestText.length > 50 && !bestText.contains("Chapter 1:", true)) return bestText
        return metaDesc
    }

    private fun extractGenres(doc: Document): List<String> {
        val cleanDoc = doc.clone()
        listOf("header","footer","nav",".nav",".navigation",".footer",".header","#header","#footer",
            ".sidebar","#sidebar",".menu",".menu-container",".navbar","#navbar",".top-bar",".footer-links","#navigation")
            .forEach { cleanDoc.select(it).remove() }

        val classified = ElementClassifier(cleanDoc).classifyGenres()
        if (classified.isNotEmpty()) return classified

        val genres = mutableSetOf<String>()
        cleanDoc.select("a[href*=genre], a[href*=/genres/], a[href*=tag], .genres a, .categories a, [itemprop=genre], .property-item a, .novel-tags a, .tags a")
            .forEach { link ->
                val text = link.text().trim().replace(Regex("^#"), "")
                if (text.isNotBlank() && text.length < 25 && !text.contains(":") && !text.contains("/")) genres.add(text)
            }
        return genres.toList()
    }

    private fun extractStatus(doc: Document): String {
        val selectors = listOf(".status",".novel-status",".info-status",".property-status",
            "[itemprop=status]",".property-item",".metadata",".info-item")
        for (sel in selectors) for (el in doc.select(sel)) {
            val txt = el.text().trim().lowercase()
            if (txt.contains("completed") || txt.contains("complete") || txt.contains("finished")) return "Completed"
            if (txt.contains("ongoing") || txt.contains("active") || txt.contains("publishing") || txt.contains("serializing")) return "Ongoing"
            if (txt.contains("dropped") || txt.contains("hiatus") || txt.contains("paused")) return "Hiatus"
        }
        for (el in doc.select("span, li, div, td, p, h2, h3, h4, h5")) {
            val text = el.text().trim()
            if (text.length < 50 && text.contains(Regex("(?i)status"))) {
                val lower = text.lowercase()
                if (lower.contains("completed") || lower.contains("complete") || lower.contains("finished")) return "Completed"
                if (lower.contains("ongoing") || lower.contains("active") || lower.contains("publishing") || lower.contains("serializing")) return "Ongoing"
                if (lower.contains("dropped") || lower.contains("hiatus") || lower.contains("paused")) return "Hiatus"
            }
        }
        val allText = doc.text().lowercase()
        if (allText.contains("status: completed") || allText.contains("status : completed") || allText.contains("status: complete")) return "Completed"
        if (allText.contains("status: ongoing") || allText.contains("status : ongoing")) return "Ongoing"
        return "Ongoing"
    }

    private fun extractCoverUrl(doc: Document, baseUri: URI): String? {
        val candidates = mutableListOf<String>()

        val ogImage = doc.select("meta[property=\"og:image\"], meta[property=\"og:image:secure_url\"]").attr("content").trim()
        if (ogImage.isNotBlank()) candidates.add(ogImage)
        val twitterImage = doc.select("meta[name=\"twitter:image\"], meta[name=\"twitter:image:src\"]").attr("content").trim()
        if (twitterImage.isNotBlank()) candidates.add(twitterImage)

        doc.select(".cover img, .book img, .novel-cover img, img[alt*=\"cover\"], img[class*=\"cover\"], img[id*=\"cover\"]")
            .forEach { img ->
                listOf("src","data-src","data-lazy-src").forEach { a -> img.attr(a).trim().let { if (it.isNotBlank()) candidates.add(it) } }
            }

        val validUrls = candidates.map { resolveUrl(baseUri, it) }.filter { url ->
            url.startsWith("http", true) && !url.contains("placeholder", true) &&
            !url.contains("default-cover", true) && !url.contains("loading.gif", true) && !url.contains("blank.gif", true)
        }.distinct()

        if (validUrls.isEmpty()) {
            doc.select("img").firstOrNull()?.attr("src")?.trim()?.let {
                val resolved = resolveUrl(baseUri, it)
                if (resolved.startsWith("http", true)) return resolved
            }
            return null
        }

        return validUrls.maxByOrNull { url ->
            var score = 0
            if (url == ogImage) score += 200
            if (url == twitterImage) score += 150
            if (url.contains("1200") || url.contains("1000") || url.contains("800") || url.contains("600")) score += 50
            if (url.contains("thumb", true) || url.contains("150x", true) || url.contains("100x", true)) score -= 100
            score
        }
    }

    // -----------------------------------------------------------------
    // GENERIC CHAPTER NUMBER + CHAPTER LIST EXTRACTION (non-FWN sites)
    // -----------------------------------------------------------------
    private fun extractChapterNumber(text: String): Double? {
        val cleaned = text.lowercase().trim()
        Regex("""(?:chapter|chpx?|episode|ep|ch\.?|vol|volume|v\.)\s*(\d+(?:\.\d+)?)""").find(cleaned)?.let {
            return it.groupValues[1].toDoubleOrNull()
        }
        for (m in Regex("""\b(\d+(?:\.\d+)?)\b""").findAll(cleaned)) {
            val num = m.groupValues[1].toDoubleOrNull() ?: continue
            if (num > 0.0 && num < 100000.0) return num
        }
        return null
    }

    private fun extractChapters(doc: Document, baseUri: URI): List<CrawledChapter> {
        val cleanDoc = doc.clone()
        listOf("header","footer","nav",".nav",".navigation",".footer",".header",".sidebar",".widget",
            "#sidebar","#widget",".right-sidebar",".left-sidebar",".ranking-sidebar",".comments",".comment",
            "#comments","#comment",".comments-area",".ads",".ad",".ad-box","ins","iframe","script","style",
            ".related",".recommend",".recommendations",".related-novels",".related-post",".latest-releases",
            ".latest-release",".popular-novels",".ranking",".trend",".trending","#ranking")
            .forEach { cleanDoc.select(it).remove() }

        val containers = cleanDoc.select("div, ul, ol, table, tbody, section, main, article")

        fun isRejectedContainer(el: Element): Boolean {
            val classId = (el.className() + " " + el.id()).lowercase()
            val bad = listOf("sidebar","widget","ranking","latest","recent","comment","popular","relat","recommend","nav","footer","header","menu","search")
            if (bad.any { classId.contains(it) }) return true
            val headers = el.select("h1,h2,h3,h4,h5,h6,.title,.widget-title,.section-title,.header").text().lowercase()
            if (headers.contains("latest") || headers.contains("recent") || headers.contains("new updates") || headers.contains("update")) return true
            var sib = el.previousElementSibling(); var lim = 3
            while (sib != null && lim > 0) {
                if (sib.tagName().matches(Regex("h[1-6]")) || sib.className().contains("title", true)) {
                    val t = sib.text().lowercase()
                    if (t.contains("latest") || t.contains("recent") || t.contains("new updates") || t.contains("update")) return true
                }
                sib = sib.previousElementSibling(); lim--
            }
            return false
        }

        fun isChapterLikeLink(link: Element): Boolean {
            val href = link.attr("href").trim()
            if (href.isBlank() || href.startsWith("#") || href.contains("javascript:", true)) return false
            val lh = href.lowercase()
            if (listOf("comment","contact","about","privacy","advertise","login","register","signup","user","profile","facebook","twitter","reddit","discord","category","genre","author","tag").any { lh.contains(it) }) return false
            val text = link.text().trim(); val lt = text.lowercase()
            if (lt.isBlank() || lt.contains("home") || lt.contains("next") || lt.contains("prev") || lt.contains("bookmark") || lt.contains("search")) return false
            return lt.contains("chapter") || lt.contains("ch.") || lt.contains("ch ") || lt.contains("vol") ||
                lt.matches(Regex(".*(?:ch|vol|ep)[a-zA-Z\\.]*\\s*\\d+.*")) ||
                lh.contains("chapter") || lh.contains("/ch-") || lh.contains("/ch/") ||
                lt.matches(Regex("\\d+(?:\\.\\d+)?"))
        }

        data class ScoredContainer(val element: Element, val chapterLinks: List<Element>, val score: Double)
        val scored = mutableListOf<ScoredContainer>()

        for (el in containers) {
            if (isRejectedContainer(el)) continue
            val anchors = el.select("a[href]").filter { isChapterLikeLink(it) }.distinctBy { resolveUrl(baseUri, it.attr("href")) }
            if (anchors.isEmpty()) continue

            val classId = (el.className() + " " + el.id()).lowercase()
            val explicit = classId.contains("chapter-list") || classId.contains("chapters") || classId.contains("wp-manga-chapter") || classId.contains("iddata")
            if (anchors.size < 15 && !explicit) continue

            val nums = anchors.mapNotNull { extractChapterNumber(it.text()) }
            if (anchors.size < 15 && nums.size >= 2) {
                var desc = true
                for (i in 0 until nums.size - 1) if (nums[i] < nums[i + 1]) { desc = false; break }
                if (desc) continue
            }

            var score = anchors.size * 2.5
            var seq = 0; var prev: Double? = null
            for (n in nums) { if (prev != null) { val d = Math.abs(n - prev); if (d == 1.0 || d == 0.5) seq++ }; prev = n }
            score += seq * 8.0
            val groups = anchors.groupBy { resolveUrl(baseUri, it.attr("href")).replace(Regex("\\d+"), "{num}") }
            val largest = groups.values.maxOfOrNull { it.size } ?: 0
            score += (largest.toDouble() / anchors.size * 150.0) + (largest * 3.0)
            val low = nums.minOrNull() ?: 1000.0
            if (low <= 2.0) score += 350.0 else if (low <= 5.0) score += 150.0
            if (classId.contains("chapter-list") || classId.contains("chapters") || classId.contains("wp-manga-chapter") || classId.contains("table-of-contents") || classId.contains("contents") || classId.contains("iddata")) score += 300.0
            scored.add(ScoredContainer(el, anchors, score))
        }

        var best = scored.maxByOrNull { it.score }
        if (best == null || best.chapterLinks.isEmpty()) {
            val fallback = cleanDoc.select("a[href]").filter { isChapterLikeLink(it) }.filter { link ->
                !link.parents().any { p ->
                    val pc = (p.className() + " " + p.id()).lowercase()
                    listOf("sidebar","widget","comment","ranking","latest","recent","popular","recommend").any { pc.contains(it) }
                }
            }.distinctBy { resolveUrl(baseUri, it.attr("href")) }
            if (fallback.isNotEmpty()) best = ScoredContainer(cleanDoc.body(), fallback, 10.0)
        }

        val finalChapters = mutableListOf<CrawledChapter>()
        var i = 1
        best?.chapterLinks?.forEach { link ->
            val text = link.text().trim()
            finalChapters.add(CrawledChapter(i++, text.ifBlank { "Chapter ${i - 1}" }, resolveUrl(baseUri, link.attr("href"))))
        }

        // reverse if descending
        val nums = finalChapters.mapIndexed { idx, ch -> idx to extractChapterNumber(ch.title) }.mapNotNull { (a, b) -> if (b != null) a to b else null }
        var asc = 0; var desc = 0
        for (j in 0 until nums.size - 1) { if (nums[j].second < nums[j + 1].second) asc++ else if (nums[j].second > nums[j + 1].second) desc++ }
        val ordered = if (desc > asc) finalChapters.reversed() else finalChapters
        return ordered.mapIndexed { idx, ch -> ch.copy(index = idx + 1) }
    }

    /** UNIVERSAL last-resort chapter detection: when the scored extractor finds
     *  nothing, gather in-order links that look like chapters. */
    private fun looseChapterScan(doc: Document, baseUri: URI): List<CrawledChapter> {
        val basePath = (baseUri.path ?: "").trimEnd('/').lowercase()
        val out = mutableListOf<CrawledChapter>()
        val seen = HashSet<String>()
        var idx = 0
        for (a in doc.select("a[href]")) {
            val href = a.attr("href").trim()
            if (href.isBlank() || href.startsWith("#") || href.contains("javascript:", true)) continue
            val abs = resolveUrl(baseUri, href)
            val lower = abs.lowercase()
            if (listOf("comment","login","register","author","genre","/tag","category","contact","privacy","about","/user","profile","facebook","twitter","discord").any { lower.contains(it) }) continue
            val text = a.text().trim()
            val looksChapter = lower.contains("chapter") || lower.contains("/ch-") || lower.contains("/ch/") ||
                Regex("(?i)(chapter|episode|\\bch\\.?\\s*\\d+|\\bvol\\b)").containsMatchIn(text) ||
                (basePath.length > 1 && lower.contains(basePath) && Regex("\\d").containsMatchIn(lower))
            if (!looksChapter) continue
            if (!seen.add(abs)) continue
            out.add(CrawledChapter(index = ++idx, title = text.ifBlank { "Chapter $idx" }, url = abs))
        }
        return out
    }

    private fun resolveUrl(baseUri: URI, href: String): String =
        try { baseUri.resolve(href).toString() } catch (_: Exception) { href }

    // -----------------------------------------------------------------
    // CHAPTER CACHE
    // -----------------------------------------------------------------
    private fun getCacheFile(context: Context, url: String): File {
        val cacheDir = File(context.filesDir, "chapters_cache")
        if (!cacheDir.exists()) cacheDir.mkdirs()
        // Hash the URL instead of character-substituting it. The old scheme
        // mapped every non-alphanumeric character to the same "_", so two
        // different URLs could collide on one filename and silently serve the
        // wrong chapter. Hashing also removes the 255-byte filename limit
        // problem for long lnplugin:// URLs. Existing cached files under the
        // old naming just become orphaned and get re-fetched once — harmless,
        // since this is a disposable cache.
        val digest = java.security.MessageDigest.getInstance("SHA-256").digest(url.toByteArray(Charsets.UTF_8))
        val hex = digest.joinToString("") { "%02x".format(it) }
        return File(cacheDir, "$hex.txt")
    }

    fun isChapterCached(context: Context, url: String): Boolean {
        val f = getCacheFile(context, url); return f.exists() && f.length() > 0
    }

    fun cacheChapterText(context: Context, url: String, text: String) {
        try {
            getCacheFile(context, url).writeText(text)
            triggerCacheUpdate()
        } catch (e: Exception) {
            com.lorelight.core.DiagnosticLogger.log("ERROR", e.message ?: e.toString())
        }
    }

    // Public so every other consumer (TTS, EPUB export, downloads, the reader's
    // placeholder check) can treat "is this actually chapter text?" identically
    // instead of keeping separate, incomplete copies of this list.
    fun isFailureText(text: String): Boolean {
        val t = text.trim()
        if (t.isEmpty()) return true
        if (t.startsWith("Couldn't load chapter:")) return true
        return t.startsWith("EPUB file not found on disk") ||
               t.startsWith("Chapter entry not found in EPUB") ||
               t.startsWith("Failed to lazy load chapter") ||
               t == "Chapter text could not be loaded from EPUB." ||
               t == "Failed to load chapter content." || t == "No content extracted." ||
               t == "This chapter isn't available yet. It may still be downloading — please try again." ||
               t == "This chapter came back empty from the source." ||
               t == "Invalid chapter link." ||
               t == "Chapter text not found or cleared from cache."
    }

    private fun isFailureResult(serialized: String): Boolean {
        // epubfile results are JSON blocks: treat as failure if empty OR a single TextBlock that isFailureText
        return try {
            val blocks = serialized.toReaderBlocks()
            blocks.isEmpty() || (blocks.size == 1 && blocks[0] is ReaderBlock.TextBlock &&
                isFailureText((blocks[0] as ReaderBlock.TextBlock).text))
        } catch (_: Exception) { isFailureText(serialized) }
    }

    fun clearCacheForUrls(context: Context, urls: List<String>) {
        urls.forEach { url ->
            try {
                val f = getCacheFile(context, url)
                if (f.exists()) {
                    f.delete()
                }
            } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError(context, "CrawlerEngine.clearCacheForUrls", e) }
        }
    }

    fun getCachedChapterText(context: Context, url: String): String? = try {
        val f = getCacheFile(context, url)
        if (f.exists() && f.length() > 0) {
            val content = f.readText()
            if (isFailureResult(content)) {
                try { f.delete() } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError(context, "CrawlerEngine.getCachedChapterText", e) }
                null
            } else {
                content
            }
        } else null
    } catch (_: Exception) { null }

    // -----------------------------------------------------------------
    // CHAPTER TEXT EXTRACTION
    // -----------------------------------------------------------------
    suspend fun extractChapterText(context: Context, url: String): String = withContext(Dispatchers.IO) {
        getCachedChapterText(context, url)?.let { return@withContext it }
        if (url.startsWith("epubfile://")) {
            val blocks = com.lorelight.utils.EpubExtractor.lazyLoadChapterBlocks(context, url)
            if (blocks.isNotEmpty()) {
                val serialized = blocks.toJsonString()
                if (!isFailureResult(serialized)) {
                    cacheChapterText(context, url, serialized)
                }
                return@withContext serialized
            } else {
                return@withContext "Chapter text could not be loaded from EPUB."
            }
        }
        if (url.startsWith("epub://") || url.startsWith("local://"))
            return@withContext "Chapter text not found or cleared from cache."

        if (url.startsWith("lnplugin://")) {
            val rest = url.removePrefix("lnplugin://")
            val slash = rest.indexOf('/')
            if (slash <= 0) return@withContext "Invalid chapter link."
            val pid = rest.substring(0, slash)
            val chapterPath = android.net.Uri.decode(rest.substring(slash + 1))
            return@withContext try {
                val raw = com.lorelight.browse.js.JSPluginEngine.parseChapter(context, pid, chapterPath)
                if (raw.isBlank()) {
                    "This chapter came back empty from the source."
                } else {
                    val looksHtml = raw.contains("</") || raw.contains("<p") || raw.contains("<div") || raw.contains("<br")
                    val cleaned = if (looksHtml) {
                        val c = try {
                            cleanChapterText(blockTextOf(org.jsoup.Jsoup.parse(raw).body()))
                        } catch (e: Exception) { "" }
                        if (c.isNotBlank()) c else raw.trim()
                    } else {
                        raw.trim()
                    }
                    if (cleaned.isNotBlank()) {
                        cacheChapterText(context, url, cleaned)
                        cleaned
                    } else {
                        "Failed to load chapter content."
                    }
                }
            } catch (e: Exception) {
                "Couldn't load chapter: ${e.message ?: e.toString()}"
            }
        }

        log("CRAWLER", "Extracting chapter text: $url")

        val doc: Document = try { fetchChapterGeneric(context, url) }
        catch (e: Exception) { return@withContext (friendlyError(e).message ?: "Couldn't load this chapter.") }

        // --- Generic content-density extraction ---
        doc.select("script, style, iframe, nav, footer, header, .comments, .ads, ins, .ad-box, .sidebar").remove()
        val candidates = doc.select("div, article, main, section")
        var bestNode: Element = doc.body(); var maxScore = -1
        candidates.forEach { el ->
            val classId = (el.className() + " " + el.id()).lowercase()
            if (classId.contains("comment") || classId.contains("sidebar") || classId.contains("footer") || classId.contains("nav")) return@forEach
            val textLength = el.ownText().length + el.select("p").joinToString { it.text() }.length
            var score = textLength
            val links = el.select("a").size
            if (links > 0) score /= (links * 2)
            if (classId.contains("chapter-content") || classId.contains("entry-content") || classId.contains("reading-content") ||
                classId.contains("text-left") || classId.contains("cha-words") || classId.contains("chr-content") || classId.contains("m-read")) score += 10000
            if (score > maxScore) { maxScore = score; bestNode = el }
        }
        bestNode.select("script, style, iframe, nav, footer, .comments, .ads, ins, .ad-box, [class*=\"prev\"], [class*=\"next\"], [id*=\"prev\"], [id*=\"next\"], .chapter-nav, .nav-links, .btn-group, .entry-navigation, .navigation, .chapter-navigation, .page-navigation").remove()

        val content = blockTextOf(bestNode)
        val cleaned = cleanChapterText(content)
        val result = cleaned.ifBlank { "No content extracted." }
        if (result != "No content extracted." && result != "Failed to load chapter content." && !isFailureText(result))
            cacheChapterText(context, url, result)
        return@withContext result
    }

    private fun blockTextOf(node: Element): String {
        node.apply {
            ownerDocument()?.outputSettings()?.prettyPrint(false)
            select("p").prepend("###NEWLINE###")
            select("br").append("###NEWLINE###")
            select("div").prepend("###NEWLINE###")
        }
        return node.text().replace("###NEWLINE###", "\n")
    }

    private fun cleanChapterText(raw: String): String {
        var content = raw
            .replace(Regex(" +"), " ")
            .replace(Regex("\n[ \t]+"), "\n")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
        content = content
            .replace("scriptChapterMid();/scriptbr/", "")
            .replace("scriptChapterMid();", "")
            .replace("/scriptbr/", "")
            .replace(Regex("(?i)scriptChapter[a-zA-Z0-9_]*\\(\\);?/?(scriptbr/)?"), "")
            .replace(Regex("(?i)chapter[Mm]id\\(\\);?/?"), "")
            .trim()
        val lines = content.split("\n").map { it.trim() }.filter { line ->
            if (line.isEmpty()) return@filter true
            val l = line.lowercase()
            val isNav = (l.contains("next chapter") || l.contains("previous chapter") || l.contains("prev chapter") ||
                l.contains("chapter list") || l.contains("table of contents") || l == "next" || l == "prev" ||
                l == "previous" || l == "index") && line.length < 50
            !isNav
        }
        return lines.joinToString("\n").trim()
    }

    private fun fetchChapterGeneric(context: Context, url: String): Document {
        var currentUrl = url
        fun build(u: String): org.jsoup.Connection {
            val c = Jsoup.connect(u).userAgent(DESKTOP_UA)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8")
                .header("Accept-Language", "en-US,en;q=0.9")
                .header("Connection", "keep-alive")
                .header("Upgrade-Insecure-Requests", "1")
                .timeout(15000)
            try {
                val uri = URI(u); val host = uri.host
                if (!host.isNullOrEmpty()) c.header("Referer", "${uri.scheme ?: "https"}://$host/")
            } catch (_: Exception) {}
            val cookies = try { android.webkit.CookieManager.getInstance().getCookie(u) } catch (_: Exception) { null }
            if (!cookies.isNullOrBlank()) c.header("Cookie", cookies)
            return c
        }
        return try { build(currentUrl).get() }
        catch (e: Exception) {
            if (currentUrl.startsWith("https://")) {
                android.util.Log.w("CrawlerEngine", "HTTPS failed, retrying over insecure HTTP: $currentUrl")
                currentUrl = currentUrl.replaceFirst("https://", "http://")
                build(currentUrl).get()
            } else throw e
        }
    }
}

// =====================================================================
// ELEMENT CLASSIFIER  (unchanged from v1 — keep as-is)
// =====================================================================
class ElementClassifier(private val doc: Document) {

    data class ClassificationResult(val element: Element, val text: String, val score: Double)

    fun classifyDescription(): ClassificationResult? {
        val elements = doc.select("div, p, section, article")
        val results = mutableListOf<ClassificationResult>()
        for (el in elements) {
            val classId = (el.className() + " " + el.id()).lowercase()
            if (listOf("comment","sidebar","footer","nav","chapter","header","menu","search","recommend","relation","popular").any { classId.contains(it) }) continue
            val totalText = el.text().trim()
            if (totalText.length < 40 || totalText.length > 4000) continue
            val htmlLength = el.html().length.coerceAtLeast(1)
            val textDensity = totalText.length.toDouble() / htmlLength.toDouble()
            var score = 0.0
            if (classId.contains("description") || classId.contains("synopsis") || classId.contains("summary") || classId.contains("novel-synopsis")) score += 100.0
            if (classId.contains("desc") || classId.contains("about") || classId.contains("introduction") || classId.contains("intro")) score += 60.0
            if (classId.contains("info-text") || classId.contains("manga-info-text") || classId.contains("story-text")) score += 50.0
            if (classId.contains("info") || classId.contains("meta") || classId.contains("content-inner")) score += 20.0
            val itemprop = el.attr("itemprop").lowercase()
            if (itemprop == "description" || itemprop == "about" || itemprop == "abstract") score += 120.0
            val aria = (el.attr("aria-label") + " " + el.attr("aria-describedby")).lowercase()
            if (aria.contains("description") || aria.contains("synopsis") || aria.contains("summary")) score += 80.0
            if (textDensity > 0.4) score += 40.0 else if (textDensity > 0.2) score += 20.0
            val pTags = el.select("p")
            if (pTags.isNotEmpty()) { score += 30.0; if (pTags.map { it.text().trim().length }.average() > 40.0) score += 40.0 }
            else if (el.tagName() == "p" || el.tagName() == "div") score += 20.0
            val anchors = el.select("a").size; if (anchors > 0) score -= anchors * 15.0
            val lists = el.select("li, ul, ol").size; if (lists > 0) score -= lists * 10.0
            val forms = el.select("input, button, select, textarea, form").size; if (forms > 0) score -= forms * 30.0
            val heads = el.select("h1, h2, h3"); if (heads.isNotEmpty()) score -= heads.size * 25.0
            if (score > 0) {
                val clone = el.clone()
                clone.select("script, style, iframe, nav, footer, .comments, .ads, ins, .ad-box, h1, h2, h3, a, button, input").remove()
                val cleaned = clone.text().trim()
                if (cleaned.length > 40 && !cleaned.contains("Chapter 1", true) && !cleaned.contains("Next Chapter", true) && !cleaned.contains("All Chapters", true))
                    results.add(ClassificationResult(el, cleaned, score))
            }
        }
        return results.maxByOrNull { it.score }
    }

    fun classifyAuthor(): ClassificationResult? {
        val elements = doc.select("span, a, p, div, td, li")
        val results = mutableListOf<ClassificationResult>()
        for (el in elements) {
            val classId = (el.className() + " " + el.id()).lowercase()
            val text = el.text().trim()
            if (text.isBlank() || text.length < 2 || text.length > 60) continue
            if (text.contains("Chapter", true) || text.contains("Page", true)) continue
            var score = 0.0
            if (classId.contains("author") || classId.contains("writer") || classId.contains("creator") || classId.contains("novel-author")) score += 100.0
            if (classId.contains("property-value") || classId.contains("meta-value") || classId.contains("info-value")) score += 20.0
            else if (classId.contains("meta") || classId.contains("info") || classId.contains("property")) score += 10.0
            val itemprop = el.attr("itemprop").lowercase(); if (itemprop == "author" || itemprop == "creator") score += 120.0
            val aria = el.attr("aria-label").lowercase(); if (aria.contains("author") || aria.contains("writer")) score += 80.0
            val parentText = el.parent()?.text()?.trim() ?: ""
            if (text.startsWith("Author:", true) || text.contains("author:", true)) score += 60.0
            else if (parentText.startsWith("Author:", true) || parentText.contains("author:", true)) score += 40.0
            if (text.startsWith("By ", true)) score += 40.0
            val children = el.children().size
            score += when { children == 0 -> 25.0; children == 1 -> 10.0; else -> -(children * 15.0) }
            if (score > 20.0) {
                val cleaned = text.replace(Regex("(?i)^(by|author|writer|creator):?\\s*"), "").replace(Regex("(?i)\\s*(author|writer|creator):?"), "").trim()
                if (cleaned.isNotBlank() && cleaned.length < 40) results.add(ClassificationResult(el, cleaned, score))
            }
        }
        return results.maxByOrNull { it.score }
    }

    fun classifyGenres(): List<String> {
        val elements = doc.select("a, span, li")
        val candidates = mutableListOf<Pair<String, Double>>()
        val common = setOf("action","adventure","comedy","drama","fantasy","harem","historical","horror","isekai",
            "josei","martial arts","mature","mecha","mystery","psychological","romance","school life","sci-fi","seinen",
            "shoujo","shoujo ai","shounen","shounen ai","slice of life","sports","supernatural","tragedy","wuxia",
            "xianxia","xuanhuan","cultivation","eastern","game","adult")
        for (el in elements) {
            val classId = (el.className() + " " + el.id() + " " + el.parent()?.className()).lowercase()
            val rel = el.attr("rel").lowercase(); val href = el.attr("href").lowercase(); val text = el.text().trim()
            if (text.isBlank() || text.length < 2 || text.length > 25 || text.contains(":") || text.contains("/")) continue
            val lt = text.lowercase()
            if (lt in setOf("home","next","prev","chapter","read","novel","search","menu","login","register","comment")) continue
            var score = 0.0
            if (classId.contains("genre") || classId.contains("category") || classId.contains("subject") || classId.contains("novel-tag")) score += 80.0
            else if (classId.contains("tag") || classId.contains("label")) score += 40.0
            if (href.contains("genre") || href.contains("category") || href.contains("tag")) score += 60.0
            if (rel == "tag" || rel == "category") score += 50.0
            val aria = el.attr("aria-label").lowercase(); if (aria.contains("genre") || aria.contains("category") || aria.contains("tag")) score += 70.0
            if (common.contains(lt)) score += 50.0
            if (score > 35.0) { val g = text.replace(Regex("^#"), "").trim(); if (g.isNotBlank()) candidates.add(g to score) }
        }
        return candidates.groupBy { it.first.lowercase() }.map { e -> e.value.maxByOrNull { it.second }!!.first }.distinct()
    }
}
