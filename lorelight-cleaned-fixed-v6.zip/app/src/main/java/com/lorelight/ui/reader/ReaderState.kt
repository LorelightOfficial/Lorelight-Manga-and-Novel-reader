package com.lorelight.ui.reader

import androidx.compose.ui.geometry.Offset
import org.json.JSONArray
import org.json.JSONObject

data class WordRange(val start: Int, val end: Int)
data class WordPosition(val leftAnchor: Offset, val rightAnchor: Offset)

data class Highlight(
    val id: String = java.util.UUID.randomUUID().toString(),
    val novelId: String,
    val chapterTitle: String,
    val startWordIdx: Int,
    val endWordIdx: Int,
    val colorHex: String,
    val createdTimestamp: Long = System.currentTimeMillis()
)

sealed class ReaderBlock {
    data class TextBlock(val text: String, val isParagraphEnd: Boolean = false) : ReaderBlock()
    data class ImageBlock(val entryPath: String) : ReaderBlock()
}

fun List<ReaderBlock>.toJsonString(): String {
    val arr = JSONArray()
    for (block in this) {
        val obj = JSONObject()
        when (block) {
            is ReaderBlock.TextBlock -> {
                obj.put("type", "text")
                obj.put("content", block.text)
                obj.put("isParagraphEnd", block.isParagraphEnd)
            }
            is ReaderBlock.ImageBlock -> {
                obj.put("type", "image")
                obj.put("content", block.entryPath)
            }
        }
        arr.put(obj)
    }
    return arr.toString()
}

fun String.toReaderBlocks(): List<ReaderBlock> {
    val list = mutableListOf<ReaderBlock>()
    try {
        val arr = JSONArray(this)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val type = obj.optString("type")
            val content = obj.optString("content")
            if (type == "text") {
                val isParagraphEnd = obj.optBoolean("isParagraphEnd", false)
                list.add(ReaderBlock.TextBlock(content, isParagraphEnd))
            } else if (type == "image") {
                list.add(ReaderBlock.ImageBlock(content))
            }
        }
    } catch (e: Exception) {
        // Fallback: split by newlines as TextBlocks
        this.split("\n").map { it.trim() }.filter { it.isNotEmpty() }.forEach {
            list.add(ReaderBlock.TextBlock(it, isParagraphEnd = true))
        }
    }
    return list
}
