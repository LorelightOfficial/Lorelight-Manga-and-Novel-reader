package com.lorelight.ui.theme.modeswitch

import android.graphics.Bitmap
import android.view.View
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Stable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.lorelight.ui.theme.modeswitch.celestial.CelestialAltarArt
import com.lorelight.ui.theme.modeswitch.celestial.CelestialAltarWell
import com.lorelight.ui.theme.modeswitch.celestial.CelestialBodyView
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.abs
import kotlin.random.Random
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.animation.core.withInfiniteAnimationFrameNanos
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.center
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.util.lerp
import com.lorelight.ui.theme.modeswitch.celestial.CelestialExpression
import com.lorelight.ui.theme.modeswitch.celestial.rememberCelestialFaceState
import kotlinx.coroutines.launch
import kotlin.math.PI
import com.lorelight.ui.theme.modeswitch.celestial.CelestialFaceSnapshot
import com.lorelight.ui.theme.modeswitch.celestial.CelestialFaceState
import com.lorelight.ui.theme.modeswitch.celestial.drawCelestialBody

/**
 * Day / night switch animations.
 *
 * Both animations work the same way underneath: right before the theme flips
 * we grab a bitmap of the window, flip the theme instantly behind it, then draw
 * that stale bitmap in a full-screen overlay and take it apart. So what you
 * watch is the OLD screen being lit up / swept away, and the new theme is
 * simply what is already sitting underneath.
 *
 * That also means neither needs AGSL, so they run on minSdk 24 rather than
 * Android 13+.
 */
enum class ModeSwitchAnimation(
    val id: String,
    val label: String,
    val blurb: String,
    val durationMs: Int
) {
    CELESTIAL_ARC(
        "celestial", "Celestial Arc",
        "The sun or moon rises from the toggle, arcs into the sky, and its light washes the new theme across the screen",
        1400
    ),
    SPLASH_WASH(
        "splash", "Splash Wash",
        "Water pours down the glass and washes the old theme away -- an accelerating sheet that breaks into fingers, rivulets that outrun it, and spray thrown off the impact",
        1600
    ),
    EMBER_BURN(
        "ember", "Ember Burn",
        "The old screen smolders away like paper from where you tapped, with tall licking flames on the seam and drifting sparks",
        2600
    ),
    GLASS_SHATTER(
        "shatter", "Glass Shatter",
        "Cracks spider out from your finger, then the old screen breaks into shards that tumble away",
        1300
    ),
    TERMINATOR(
        "terminator", "Terminator Sweep",
        "Lite: the curved day / night line crosses with an atmospheric rim - easiest on older devices",
        700
    );

    companion object {
        fun all(): List<ModeSwitchAnimation> = values().toList()

        fun fromId(id: String?): ModeSwitchAnimation? = values().firstOrNull { it.id == id }

        fun poolFromCsv(csv: String?): List<ModeSwitchAnimation> {
            val found = csv.orEmpty()
                .split(',')
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .mapNotNull { fromId(it) }
                .distinct()
            return if (found.isEmpty()) all() else found
        }

        fun poolToCsv(pool: Collection<ModeSwitchAnimation>): String =
            all().filter { pool.contains(it) }.joinToString(",") { it.id }
    }
}

/**
 * Every random value an animation needs, drawn ONCE when the run starts.
 *
 * This matters: the draw lambda re-runs on every frame, so rolling dice inside
 * it would make the stars jump around instead of twinkling in place.
 */
class ModeSwitchRun(seed: Long) {
    private val r = Random(seed)

    // x, y (biased to the upper sky), appear delay, size, twinkle phase
    val stars: List<FloatArray> = List(30) {
        floatArrayOf(
            r.nextFloat(),
            r.nextFloat() * r.nextFloat() * 0.72f,
            0.15f + r.nextFloat() * 0.45f,
            0.5f + r.nextFloat(),
            r.nextFloat() * 6.28f
        )
    }

    // -- Splash Wash --
    // per column: speed multiplier, start delay, wobble phase
    val streams: List<FloatArray> = List(22) {
        floatArrayOf(
            0.75f + r.nextFloat() * 0.5f,
            r.nextFloat(),
            r.nextFloat() * 6.28f
        )
    }

    // stray droplets: x fraction, delay, size, fall speed multiplier
    val drops: List<FloatArray> = List(26) {
        floatArrayOf(
            r.nextFloat(),
            r.nextFloat() * 0.5f,
            0.5f + r.nextFloat(),
            0.8f + r.nextFloat() * 0.7f
        )
    }

    // -- Ember Burn --
    // three noise harmonics shaping the burn front: frequency, amplitude, phase
    val burnWobble: List<FloatArray> = List(3) { k ->
        floatArrayOf(
            (2 + k * 2 + r.nextInt(2)).toFloat(),
            0.030f + r.nextFloat() * 0.045f,
            r.nextFloat() * 6.28f
        )
    }

    // sparks riding the burn front: angle, delay, speed, size, flicker phase
    val sparks: List<FloatArray> = List(34) {
        floatArrayOf(
            r.nextFloat() * 6.28f,
            0.05f + r.nextFloat() * 0.75f,
            0.5f + r.nextFloat(),
            0.6f + r.nextFloat(),
            r.nextFloat() * 6.28f
        )
    }

    // flame tongues licking along the burn front:
    // angle, sway phase, height multiplier, width multiplier, flicker speed
    val flames: List<FloatArray> = List(30) {
        floatArrayOf(
            r.nextFloat() * 6.28f,
            r.nextFloat() * 6.28f,
            0.55f + r.nextFloat() * 0.95f,
            0.60f + r.nextFloat() * 0.70f,
            0.70f + r.nextFloat() * 0.90f
        )
    }

    // -- Glass Shatter --
    // shared jittered vertex grid so neighbouring shards tile with no gaps.
    // (cols+1) x (rows+1) points, two floats each: jitter as a cell fraction.
    val shatterCols = 5
    val shatterRows = 8
    val shatterVerts: FloatArray = FloatArray((shatterCols + 1) * (shatterRows + 1) * 2) { i ->
        val pt = i / 2
        val col = pt % (shatterCols + 1)
        val row = pt / (shatterCols + 1)
        // pin the border vertices so the sheet still covers the whole screen
        if (col == 0 || col == shatterCols || row == 0 || row == shatterRows) 0f
        else (r.nextFloat() - 0.5f) * 0.6f
    }

    // per shard: delay jitter, fall speed, sideways drift, spin direction/speed
    val shards: List<FloatArray> = List(shatterCols * shatterRows) {
        floatArrayOf(
            r.nextFloat(),
            0.8f + r.nextFloat() * 0.6f,
            (r.nextFloat() - 0.5f) * 2f,
            (r.nextFloat() - 0.5f) * 2f
        )
    }

    // radial crack polylines: angle, length fraction, two kink offsets
    val cracks: List<FloatArray> = List(11) { i ->
        floatArrayOf(
            (i.toFloat() / 11f) * 6.28f + (r.nextFloat() - 0.5f) * 0.5f,
            0.55f + r.nextFloat() * 0.45f,
            (r.nextFloat() - 0.5f) * 0.30f,
            (r.nextFloat() - 0.5f) * 0.30f
        )
    }
}

private fun findWindow(view: View): android.view.Window? {
    // This view first, then its ancestors. The order matters: the DecorView at
    // the top of the tree is built with a DecorContext that wraps the
    // *application* context, so an Activity is never reachable through it.
    // Handing this function a root view therefore returned null, PixelCopy was
    // skipped entirely, and the software fallback below then threw on Coil's
    // hardware cover bitmaps -- which is why the switch animation only ever
    // appeared on screens that had no cover art on them.
    var v: View? = view
    while (v != null) {
        var ctx: android.content.Context? = v.context
        while (ctx is android.content.ContextWrapper) {
            if (ctx is android.app.Activity) return ctx.window
            ctx = ctx.baseContext
        }
        v = v.parent as? View
    }
    return null
}

/**
 * Grabs the current window into a bitmap, capped so it stays cheap.
 *
 * PixelCopy is used wherever it exists because the software path below cannot
 * read back hardware layers: Coil hands us HARDWARE bitmaps for covers on API
 * 26+, and Canvas.drawBitmap throws on those. Without this the animation would
 * silently degrade to an instant flip on any screen showing artwork - which is
 * to say, the Library, which is where the toggle lives.
 *
 * PixelCopy also scales the source rect straight into the destination bitmap,
 * so the downscale is free and there is no full-size intermediate allocation.
 */
suspend fun captureWindow(view: View, maxDim: Int = 1000): ImageBitmap? {
    // Geometry comes from the root so the whole window is captured, but the
    // window itself is resolved from the view we were handed, because that is
    // the one whose context really is the Activity.
    val root = view.rootView ?: view
    val w = root.width
    val h = root.height
    if (w <= 0 || h <= 0) return null
    val scale = min(1f, maxDim.toFloat() / max(w, h).toFloat())
    val bw = max(1, (w * scale).roundToInt())
    val bh = max(1, (h * scale).roundToInt())

    val window = findWindow(view)
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O && window != null) {
        val target = try {
            Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        } catch (_: Throwable) {
            null
        }
        if (target != null) {
            val loc = IntArray(2)
            root.getLocationInWindow(loc)
            val rect = android.graphics.Rect(loc[0], loc[1], loc[0] + w, loc[1] + h)
            val ok = suspendCancellableCoroutine<Boolean> { cont ->
                try {
                    android.view.PixelCopy.request(
                        window,
                        rect,
                        target,
                        { result ->
                            if (cont.isActive) {
                                cont.resume(result == android.view.PixelCopy.SUCCESS)
                            }
                        },
                        android.os.Handler(android.os.Looper.getMainLooper())
                    )
                } catch (_: Throwable) {
                    if (cont.isActive) cont.resume(false)
                }
            }
            if (ok) return target.asImageBitmap()
        }
    }

    // API 24-25, or PixelCopy refused. Software draw; may throw on hardware
    // bitmaps, in which case the caller flips the theme with no animation.
    return try {
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bmp)
        canvas.scale(bw.toFloat() / w.toFloat(), bh.toFloat() / h.toFloat())
        root.draw(canvas)
        bmp.asImageBitmap()
    } catch (_: Throwable) {
        null
    }
}

/**
 * A flat stand-in for the screenshot, used when the window cannot be read back
 * at all. Eight pixels is plenty, since drawBase stretches it over the screen.
 */
private fun solidBitmap(color: Color): ImageBitmap? {
    if (color == Color.Unspecified) return null
    return try {
        val bmp = Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(
            android.graphics.Color.argb(
                (color.alpha * 255f).roundToInt(),
                (color.red * 255f).roundToInt(),
                (color.green * 255f).roundToInt(),
                (color.blue * 255f).roundToInt()
            )
        )
        bmp.asImageBitmap()
    } catch (_: Throwable) {
        null
    }
}

@Stable
/** How long the sun/moon takes to sink into the altar before the wipe. */
private const val DESCENT_MS = 260

/** How long the new body takes to rise back out of the altar and settle. */
private const val EMERGE_MS = 460

class ModeSwitchController {
    var capture by mutableStateOf<ImageBitmap?>(null)
        private set
    var animation by mutableStateOf<ModeSwitchAnimation?>(null)
        private set
    var run by mutableStateOf<ModeSwitchRun?>(null)
        private set
    var toLight by mutableStateOf(false)
        private set

    /** Where the toggle sits in root coordinates, so effects start at your finger. */
    var origin by mutableStateOf(Offset.Zero)

    val progress = Animatable(0f)

    /**
     * How far the sun/moon has sunk into the altar. 0 = resting on top of it,
     * 1 = fully swallowed. Driven by [play] so the descent finishes before the
     * screenshot is taken and the emergence runs after the overlay is gone.
     */
    val descent = Animatable(0f)

    private var busy = false

    private var previous: ModeSwitchAnimation? = null

    val isRunning: Boolean
        get() = capture != null

    /** True from the first frame of the descent until the emergence settles. */
    val isBusy: Boolean
        get() = busy

    private fun pick(pool: List<ModeSwitchAnimation>): ModeSwitchAnimation {
        if (pool.isEmpty()) return ModeSwitchAnimation.CELESTIAL_ARC
        if (pool.size == 1) return pool[0]
        // never the same one twice in a row
        var choice = pool[Random.nextInt(pool.size)]
        var guard = 0
        while (choice == previous && guard < 8) {
            choice = pool[Random.nextInt(pool.size)]
            guard++
        }
        return choice
    }

    /**
     * Capture, flip, animate. [flip] is invoked the instant the overlay is in
     * place, so the theme change itself is never visible as a hard cut.
     */
    suspend fun play(
        view: View,
        pool: List<ModeSwitchAnimation>,
        targetLight: Boolean,
        flip: () -> Unit,
        fallbackColor: Color = Color.Unspecified
    ) {
        if (isRunning || busy) return
        busy = true
        try {
            val chosen = pick(pool)
            // Beats 1-2: anticipation, then the descent into the altar. This
            // plays on the live UI *before* the screenshot is taken, so the
            // capture already shows an empty altar and the body is never
            // doubled up once the overlay goes in.
            descent.animateTo(
                targetValue = 1f,
                animationSpec = tween(DESCENT_MS, easing = FastOutSlowInEasing)
            )
            // A screenshot is preferred but never required. If the window refuses
            // to give one up, animate over a flat sheet in the outgoing background
            // colour rather than hard-cutting the theme.
            val shot = captureWindow(view) ?: solidBitmap(fallbackColor)
            if (shot == null) {
                flip()
            } else {
                previous = chosen
                toLight = targetLight
                animation = chosen
                run = ModeSwitchRun(System.nanoTime())
                capture = shot
                progress.snapTo(0f)
                flip()
                try {
                    progress.animateTo(1f, tween(chosen.durationMs, easing = LinearEasing))
                } finally {
                    capture = null
                    animation = null
                    run = null
                }
            }
            // Beats 4-5: the new body rises back out of the closing altar and
            // settles. The overlay is gone by now, so this is on the live UI.
            descent.animateTo(
                targetValue = 0f,
                animationSpec = tween(EMERGE_MS, easing = FastOutSlowInEasing)
            )
        } finally {
            busy = false
        }
    }
}

private fun sstep(t: Float): Float {
    val x = t.coerceIn(0f, 1f)
    return x * x * (3f - 2f * x)
}

private fun mix(a: Float, b: Float, t: Float): Float = a + (b - a) * t

/**
 * Smooth symmetric pulse: 1f at [center], easing to 0f at [center] +- [width].
 * Symmetric on purpose -- descent() plays the same curve in both directions.
 */
private fun bump(t: Float, center: Float, width: Float): Float {
    val x = abs(t - center) / width
    if (x >= 1f) return 0f
    val a = 1f - x
    return a * a * (3f - 2f * a)
}

private fun DrawScope.drawBase(img: ImageBitmap, alpha: Float = 1f, dy: Float = 0f) {
    drawImage(
        image = img,
        srcOffset = IntOffset.Zero,
        srcSize = IntSize(img.width, img.height),
        dstOffset = IntOffset(0, dy.roundToInt()),
        dstSize = IntSize(size.width.roundToInt(), size.height.roundToInt()),
        alpha = alpha.coerceIn(0f, 1f)
    )
}

// ------------------------------------------------------------ CELESTIAL ARC
/**
 * The flagship. The actual 3D sun / moon sprite pops out of the toggle,
 * sails along a rising arc into the upper sky, and the light it casts is what
 * changes the theme: a circular light front expands from the body, the old
 * screen survives only OUTSIDE that front, and the seam glows like the
 * atmosphere at dawn / dusk. Going dark, stars twinkle in behind the front;
 * going light, soft rays wheel around the sun.
 */
private fun DrawScope.drawCelestialArc(
    img: ImageBitmap,
    p: Float,
    o: Offset,
    toLight: Boolean,
    run: ModeSwitchRun
) {
    val w = size.width
    val h = size.height
    val diag = hypot(w, h)
    val minD = min(w, h)

    // -- flight: quadratic arc from the toggle to DEAD CENTRE of the screen.
    // The control point sits well above the destination, so the body launches
    // hard, overshoots a little and then settles into the middle of the screen
    // instead of drifting off into a corner.
    val rise = sstep((p / 0.55f).coerceIn(0f, 1f))
    val apex = Offset(w * 0.5f, h * 0.5f)
    val ctrl = Offset(mix(o.x, apex.x, 0.12f), apex.y - h * 0.30f)
    val inv = 1f - rise
    val pos = Offset(
        inv * inv * o.x + 2f * inv * rise * ctrl.x + rise * rise * apex.x,
        inv * inv * o.y + 2f * inv * rise * ctrl.y + rise * rise * apex.y
    )

    val popIn = sstep(p / 0.12f)
    val fadeOut = 1f - sstep((p - 0.90f) / 0.10f)
    val bodyAlpha = (popIn * fadeOut).coerceIn(0f, 1f)
    // Centre stage, so it can afford to be properly big.
    val bodyR = minD * (0.095f + 0.085f * rise) * (0.55f + 0.45f * popIn)

    // -- light front: the new theme exists only where the light has reached --
    val reveal = sstep(((p - 0.08f) / 0.84f).coerceIn(0f, 1f))
    val frontR = bodyR * 1.2f + reveal * diag * 1.30f

    if (reveal < 0.999f) {
        val lit = Path()
        lit.addOval(Rect(pos.x - frontR, pos.y - frontR, pos.x + frontR, pos.y + frontR))
        clipPath(lit, ClipOp.Difference) { drawBase(img) }
    }

    val warm = Color(0xFFFFC978)
    val cool = Color(0xFF8FA8FF)
    val rim = if (toLight) warm else cool

    // -- sky wash: dawn gold / dusk indigo breathes in and back out --
    val wash = sin(p * Math.PI.toFloat())
    if (wash > 0.02f) {
        val tint = if (toLight) Color(0xFFFFDFA8) else Color(0xFF17224A)
        val litClip = Path()
        litClip.addOval(Rect(pos.x - frontR, pos.y - frontR, pos.x + frontR, pos.y + frontR))
        clipPath(litClip) {
            drawRect(
                brush = Brush.verticalGradient(
                    0f to tint.copy(alpha = if (toLight) 0.26f else 0.34f),
                    0.7f to Color.Transparent
                ),
                alpha = wash
            )
        }
    }

    // -- atmospheric rim riding the seam of the light front --
    if (reveal > 0.001f && reveal < 0.99f) {
        val soft = 90.dp.toPx()
        val gradR = frontR + soft
        val inner = ((frontR - soft) / gradR).coerceIn(0f, 1f)
        val edge = (frontR / gradR).coerceIn(0f, 1f)
        drawCircle(
            brush = Brush.radialGradient(
                inner to Color.Transparent,
                edge to rim.copy(alpha = 0.55f),
                1f to Color.Transparent,
                center = pos,
                radius = gradR
            ),
            radius = gradR,
            center = pos,
            alpha = (1f - reveal * 0.55f)
        )
        drawCircle(
            color = Color.White,
            radius = frontR,
            center = pos,
            alpha = 0.35f * (1f - reveal),
            style = Stroke(width = 2.dp.toPx())
        )
    }

    // -- stars twinkle in behind the nightfall front --
    if (!toLight) {
        for (s in run.stars) {
            val appear = sstep((p - s[2]) / 0.28f)
            if (appear <= 0.01f) continue
            val sx = s[0] * w
            val sy = s[1] * h
            // only inside the region the night has already claimed
            if (hypot(sx - pos.x, sy - pos.y) > frontR * 0.92f) continue
            val twinkle = 0.55f + 0.45f * sin(p * 22f + s[4])
            drawCircle(
                color = Color(0xFFEAF0FF),
                radius = (0.9f + 1.3f * s[3]).dp.toPx(),
                center = Offset(sx, sy),
                alpha = (appear * twinkle * fadeOut).coerceIn(0f, 1f)
            )
        }
    }

    // -- glow + rays / halo around the body --
    if (bodyAlpha > 0.01f) {
        val glow = if (toLight) Color(0xFFFFD98C) else Color(0xFFB9C8FF)
        drawCircle(
            brush = Brush.radialGradient(
                0f to glow.copy(alpha = 0.55f),
                0.55f to glow.copy(alpha = 0.18f),
                1f to Color.Transparent,
                center = pos,
                radius = bodyR * 2.8f
            ),
            radius = bodyR * 2.8f,
            center = pos,
            alpha = bodyAlpha
        )

        if (toLight) {
            // soft sun rays, slowly wheeling
            val rayA = 0.20f * bodyAlpha * sstep((p - 0.15f) / 0.25f)
            if (rayA > 0.01f) {
                val spin = p * 40f
                for (k in 0 until 8) {
                    val a = Math.toRadians((spin + k * 45f).toDouble()).toFloat()
                    val r1 = bodyR * 1.35f
                    val r2 = bodyR * (2.1f + 0.35f * sin(p * 10f + k))
                    drawLine(
                        color = warm,
                        start = Offset(pos.x + cos(a) * r1, pos.y + sin(a) * r1),
                        end = Offset(pos.x + cos(a) * r2, pos.y + sin(a) * r2),
                        strokeWidth = 5.dp.toPx(),
                        cap = StrokeCap.Round,
                        alpha = rayA
                    )
                }
            }
        } else {
            // quiet moonlight halo pulse
            val pulse = 0.5f + 0.5f * sin(p * 7f)
            drawCircle(
                color = cool,
                radius = bodyR * (1.55f + 0.14f * pulse),
                center = pos,
                alpha = 0.22f * bodyAlpha,
                style = Stroke(width = 2.5.dp.toPx())
            )
        }

        // The living character itself, procedurally drawn, with a gentle roll
        // as it climbs plus an excited shiver right as it pulls free of the
        // altar. The whole performance is a pure function of p, so it plays
        // back identically on every frame.
        val emergeShiver = sin(p * 90f) * 2.4f * (1f - sstep(p / 0.22f))
        val tilt = (if (toLight) mix(-14f, 6f, rise) else sin(p * 3.2f) * 7f) + emergeShiver
        val launchK = 1f - sstep((p - 0.08f) / 0.20f)
        val rockK = sstep((p - 0.45f) / 0.15f) * (1f - sstep((p - 0.76f) / 0.12f))
        val blinkK = (1f - abs(p - 0.38f) / 0.045f).coerceIn(0f, 1f)
        val grinK = sstep((p - 0.80f) / 0.12f)
        val flightFace = CelestialFaceSnapshot(
            lidLeft = blinkK,
            lidRight = (blinkK + rockK * 0.38f).coerceAtMost(1f),
            browLeft = (launchK * 0.85f + rockK).coerceIn(0f, 1f),
            browRight = (launchK * 0.85f - rockK * 0.45f).coerceIn(0f, 1f),
            pupilX = 0f,
            pupilY = -0.6f * launchK,
            mouthOpen = launchK,
            mouthSmile = (0.35f + 0.45f * rise - rockK * 0.40f + grinK * 0.35f).coerceIn(0f, 1f),
            headTilt = rockK * 0.30f,
            squash = -0.55f * launchK
        )
        rotate(degrees = tilt, pivot = pos) {
            drawCelestialBody(
                center = pos,
                radius = bodyR,
                form = if (toLight) 1f else 0f,
                face = flightFace,
                timeSec = p * 1.6f,
                alpha = bodyAlpha
            )
        }
    }
}

// -------------------------------------------------------------- SPLASH WASH
/**
 * Water running down the glass -- the same pour in both directions.
 *
 * This used to be two different animations sharing one name. Going light, the
 * screenshot was sliced into 22 vertical columns that each slid downward like
 * strips of paper; going dark, a sheet of liquid ran down. The strip version
 * was the odd one out -- solid rectangles of UI dropping past each other never
 * read as water -- and it was also why the two directions felt so unequal.
 * Both now run the same pour, rebuilt from how water actually behaves on a
 * vertical pane:
 *
 *  - it accelerates, so distance grows with time squared rather than linearly,
 *  - surface tension breaks the sheet into fingers instead of a level line,
 *  - mass gathers into a bright bead along every leading edge,
 *  - thin rivulets outrun the sheet, each dragging a heavy droplet at its tip,
 *  - the film refracts, so the outgoing pixels smear downward through it,
 *  - impact throws spray that flies on a real ballistic arc,
 *  - and the glass dries clean before the last frame.
 */
private fun DrawScope.drawSplashWash(
    img: ImageBitmap,
    p: Float,
    toLight: Boolean,
    run: ModeSwitchRun
) {
    val w = size.width
    val h = size.height
    val n = run.streams.size

    // Water is almost colourless; it borrows its tone from what it reveals.
    val body = if (toLight) Color(0xFFBFE4F5) else Color(0xFF121A2E)
    val deep = if (toLight) Color(0xFF6FB8DF) else Color(0xFF05080F)
    val sheen = if (toLight) Color.White else Color(0xFFC3D6FF)

    // Every wet element fades out before the end so the new theme is left dry.
    val settle = 1f - sstep(((p - 0.86f) / 0.14f).coerceIn(0f, 1f))

    // ---- the leading edge -------------------------------------------------
    // Sampled continuously and blended between neighbouring streams, so the
    // edge is a smooth organic curve instead of 22 visible stair steps.
    fun frontAt(fx: Float): Float {
        val g = fx.coerceIn(0f, 1f) * (n - 1)
        val i0 = g.toInt().coerceIn(0, n - 1)
        val i1 = (i0 + 1).coerceAtMost(n - 1)
        val u = sstep(g - i0)
        val a = run.streams[i0]
        val b = run.streams[i1]
        val delay = mix(0.03f + 0.17f * a[1], 0.03f + 0.17f * b[1], u)
        val speed = mix(1.06f + 0.34f * a[0], 1.06f + 0.34f * b[0], u)
        val phase = mix(a[2], b[2], u)
        val local = ((p - delay) / 0.72f).coerceIn(0f, 1f)
        // a brief push from the pour, then gravity owns it
        val fall = 0.20f * local + 0.80f * local * local
        val wob = sin(p * 8.5f + phase) * h * 0.009f +
            sin(p * 21f + phase * 2.1f) * h * 0.004f
        return fall * h * speed + wob
    }

    val segs = 48
    val segW = w / segs

    // ---- reveal: the outgoing screen survives only below the water --------
    val poured = Path()
    poured.moveTo(-w, -h)
    poured.lineTo(-w, frontAt(0f))
    for (i in 0..segs) poured.lineTo(i * segW, frontAt(i.toFloat() / segs))
    poured.lineTo(w * 2f, frontAt(1f))
    poured.lineTo(w * 2f, -h)
    poured.close()
    clipPath(poured, ClipOp.Difference) { drawBase(img) }

    // ---- refraction: old pixels dragged down through the film -------------
    // A real film displaces whatever you see through it. Clipping the outgoing
    // screenshot to a band on the wet side of the edge and pushing it downward
    // is both the cheapest and the most convincing version of that.
    if (settle > 0.01f) {
        val bandH = h * 0.06f
        val lens = Path()
        lens.moveTo(0f, frontAt(0f))
        for (i in 0..segs) lens.lineTo(i * segW, frontAt(i.toFloat() / segs))
        for (i in segs downTo 0) lens.lineTo(i * segW, frontAt(i.toFloat() / segs) - bandH)
        lens.close()
        clipPath(lens) { drawBase(img, alpha = 0.34f * settle, dy = bandH * 0.55f) }
    }

    // ---- the sheet: a thin film above, dense right at the bead ------------
    for (i in 0 until segs) {
        val f = frontAt((i + 0.5f) / segs)
        if (f <= 1f) continue
        val film = (h * 0.085f).coerceAtMost(f)
        drawRect(
            brush = Brush.verticalGradient(
                0.00f to body.copy(alpha = 0f),
                0.50f to body.copy(alpha = 0.09f * settle),
                0.86f to body.copy(alpha = 0.28f * settle),
                1.00f to deep.copy(alpha = 0.52f * settle),
                startY = f - film,
                endY = f
            ),
            topLeft = Offset(i * segW, f - film),
            size = androidx.compose.ui.geometry.Size(segW + 1f, film)
        )
    }

    // ---- the bead: surface tension holding mass on the edge ---------------
    val edge = Path()
    for (i in 0..segs) {
        val x = i * segW
        val y = frontAt(i.toFloat() / segs)
        if (i == 0) edge.moveTo(x, y) else edge.lineTo(x, y)
    }
    drawPath(edge, deep, alpha = 0.42f * settle, style = Stroke(width = 13.dp.toPx(), cap = StrokeCap.Round))
    drawPath(edge, body, alpha = 0.52f * settle, style = Stroke(width = 5.5.dp.toPx(), cap = StrokeCap.Round))
    drawPath(edge, sheen, alpha = 0.72f * settle, style = Stroke(width = 1.6.dp.toPx()))

    // ---- rivulets outrunning the sheet, each with a heavy tip -------------
    for (i in run.streams.indices) {
        if (i % 2 == 1) continue
        val s = run.streams[i]
        val fx = (i + 0.5f) / n
        val base = frontAt(fx)
        if (base <= 1f) continue
        val lead = ((p - 0.05f - 0.18f * s[1]) / 0.80f).coerceIn(0f, 1f)
        val extra = lead * lead * h * 0.17f * (0.55f + 0.60f * s[0])
        if (extra < 3f) continue
        val tipY = base + extra
        if (tipY > h * 1.03f) continue
        val x = fx * w + sin(p * 6.5f + s[2]) * w * 0.007f
        val rw = (2.0f + 2.2f * s[0]).dp.toPx()
        drawLine(
            color = body,
            start = Offset(x, base),
            end = Offset(x, tipY),
            strokeWidth = rw,
            cap = StrokeCap.Round,
            alpha = 0.38f * settle
        )
        drawLine(
            color = sheen,
            start = Offset(x - rw * 0.18f, base),
            end = Offset(x - rw * 0.18f, tipY - rw),
            strokeWidth = rw * 0.30f,
            cap = StrokeCap.Round,
            alpha = 0.30f * settle
        )
        drawCircle(color = deep, radius = rw * 0.95f, center = Offset(x, tipY), alpha = 0.55f * settle)
        drawCircle(
            color = sheen,
            radius = rw * 0.30f,
            center = Offset(x - rw * 0.24f, tipY - rw * 0.30f),
            alpha = 0.55f * settle
        )
    }

    // ---- faint runnels left behind on the washed glass --------------------
    for (i in run.streams.indices) {
        val s = run.streams[i]
        val fx = (i + 0.5f) / n
        val f = frontAt(fx)
        if (f <= h * 0.04f) continue
        val x = fx * w
        drawLine(
            color = sheen,
            start = Offset(x + sin(s[2]) * segW * 0.35f, 0f),
            end = Offset(x, f - 3f),
            strokeWidth = (0.7f + 1.3f * s[0]).dp.toPx(),
            cap = StrokeCap.Round,
            alpha = 0.09f * settle
        )
    }

    // ---- droplets, motion-blurred by their own speed ---------------------
    for (d in run.drops) {
        val t = ((p - d[1] * 0.7f) / 0.55f).coerceIn(0f, 1f)
        if (t <= 0.02f || t >= 0.995f) continue
        val y = (0.16f * t + 0.84f * t * t) * h * 1.2f * d[3]
        if (y > h) continue
        val r = (1.0f + 2.0f * d[2]).dp.toPx()
        val streak = r * (2.5f + 7f * t)
        val x = d[0] * w
        drawLine(
            color = body,
            start = Offset(x, y - streak),
            end = Offset(x, y),
            strokeWidth = r * 1.05f,
            cap = StrokeCap.Round,
            alpha = 0.26f * (1f - t) * settle
        )
        drawCircle(color = deep, radius = r, center = Offset(x, y), alpha = 0.62f * (1f - t * 0.55f) * settle)
        drawCircle(
            color = sheen,
            radius = r * 0.33f,
            center = Offset(x - r * 0.25f, y - r * 0.30f),
            alpha = 0.58f * (1f - t) * settle
        )
    }

    // ---- impact: a spreading sheet at the top, then ballistic spray -------
    val hit = 1f - sstep(((p - 0.02f) / 0.22f).coerceIn(0f, 1f))
    if (hit > 0.01f) {
        drawRect(
            brush = Brush.verticalGradient(
                0.00f to sheen.copy(alpha = 0.40f * hit),
                0.30f to body.copy(alpha = 0.26f * hit),
                1.00f to Color.Transparent,
                startY = 0f,
                endY = h * 0.28f
            ),
            size = androidx.compose.ui.geometry.Size(w, h * 0.28f)
        )
    }
    for (k in run.sparks.indices) {
        val s = run.sparks[k]
        val st = (p - 0.015f - s[1] * 0.05f) / 0.34f
        if (st <= 0f || st >= 1f) continue
        val dir = if (k % 2 == 0) 1f else -1f
        // thrown outward and up, then pulled back down by gravity
        val x = w * 0.5f + dir * (0.22f + 0.58f * s[2]) * w * 0.62f * st
        val y = h * 0.015f - (0.32f + 0.48f * s[3]) * h * 0.34f * st + h * 1.05f * st * st
        if (y > h || x < -12f || x > w + 12f) continue
        val rr = (0.9f + 1.7f * s[3]).dp.toPx() * (1f - 0.35f * st)
        drawCircle(
            color = if (st < 0.5f) sheen else body,
            radius = rr,
            center = Offset(x, y),
            alpha = (0.66f * (1f - st)).coerceIn(0f, 1f)
        )
    }
}

// --------------------------------------------------------------- EMBER BURN
/**
 * The old screen is a sheet of paper catching fire from where you tapped. An
 * irregular smoldering front eats outward; along the seam sits a charred dark
 * band, then a deep-orange glow, then a thin white-hot line. Sparks lift off
 * the front, drift upward and gutter out. The new theme is what's revealed
 * where the paper has burned through.
 */
private fun DrawScope.drawEmberBurn(
    img: ImageBitmap,
    p: Float,
    toLight: Boolean,
    o: Offset,
    run: ModeSwitchRun
) {
    val w = size.width
    val h = size.height
    val diag = hypot(w, h)
    val minD = min(w, h)

    val reveal = sstep((p / 0.88f).coerceIn(0f, 1f))
    val baseR = reveal * diag * 1.18f + 4.dp.toPx()

    // radius per angle, warped by the run's noise harmonics so the front looks
    // like burning paper rather than a compass circle
    fun radiusAt(a: Float): Float {
        var m = 1f
        for (k in run.burnWobble) m += k[1] * sin(k[0] * a + k[2] + p * 2.4f)
        return baseR * m
    }

    val segs = 64
    val hole = Path()
    for (i in 0..segs) {
        val a = (i.toFloat() / segs) * 6.2831855f
        val r = radiusAt(a)
        val x = o.x + cos(a) * r
        val y = o.y + sin(a) * r
        if (i == 0) hole.moveTo(x, y) else hole.lineTo(x, y)
    }
    hole.close()

    if (reveal < 0.999f) {
        clipPath(hole, ClipOp.Difference) { drawBase(img) }
    }

    val charCol = Color(0xFF1A0E06)
    val glowCol = if (toLight) Color(0xFFFF9E3D) else Color(0xFFFF7A26)
    val hotCol = Color(0xFFFFE9B8)

    if (reveal > 0.002f && reveal < 0.99f) {
        val flicker = 0.85f + 0.15f * sin(p * 31f)
        // charred paper band just outside the seam
        drawPath(hole, charCol, alpha = 0.55f, style = Stroke(width = 22.dp.toPx()))
        // the ember glow breathing on the seam
        drawPath(hole, glowCol, alpha = 0.60f * flicker, style = Stroke(width = 16.dp.toPx()))
        // white-hot leading line
        drawPath(hole, hotCol, alpha = 0.88f * flicker, style = Stroke(width = 3.5.dp.toPx()))
        // heat haze bleeding inward from the seam
        val soft = 110.dp.toPx()
        val gradR = baseR + soft
        drawCircle(
            brush = Brush.radialGradient(
                ((baseR - soft) / gradR).coerceIn(0f, 1f) to Color.Transparent,
                (baseR / gradR).coerceIn(0f, 1f) to glowCol.copy(alpha = 0.40f),
                1f to Color.Transparent,
                center = o,
                radius = gradR
            ),
            radius = gradR,
            center = o,
            alpha = 1f - reveal * 0.6f
        )
    }

    // -- flame tongues licking off the burn front --
    // Fire rises, so every tongue leans upward regardless of which way the
    // front happens to face at that angle, and breathes on its own clock.
    if (reveal > 0.002f && reveal < 0.995f) {
        val flameH = minD * 0.155f
        for (f in run.flames) {
            val a = f[0]
            val rr = radiusAt(a)
            val bx = o.x + cos(a) * rr
            val by = o.y + sin(a) * rr
            if (bx < -flameH || bx > w + flameH || by < -flameH || by > h + flameH) continue
            val lick = 0.55f + 0.45f * sin(p * 15f * f[4] + f[1])
            val hgt = flameH * f[2] * lick
            val wid = flameH * 0.30f * f[3]
            // outward normal blended with "straight up" so the flame leans up
            var dx = cos(a) * 0.45f
            var dy = sin(a) * 0.45f - 0.90f
            val dl = hypot(dx, dy)
            dx /= dl
            dy /= dl
            val px = -dy * wid
            val py = dx * wid
            val sway = sin(p * 19f + f[1]) * wid * 0.85f
            val tipX = bx + dx * hgt + sway
            val tipY = by + dy * hgt
            val midX = bx + dx * hgt * 0.45f + sway * 0.35f
            val midY = by + dy * hgt * 0.45f
            val fade = 1f - reveal * 0.30f
            val tongue = Path()
            tongue.moveTo(bx + px, by + py)
            tongue.lineTo(midX + px * 0.60f, midY + py * 0.60f)
            tongue.lineTo(tipX, tipY)
            tongue.lineTo(midX - px * 0.60f, midY - py * 0.60f)
            tongue.lineTo(bx - px, by - py)
            tongue.close()
            drawPath(tongue, glowCol, alpha = (0.55f * lick * fade).coerceIn(0f, 1f))
            // white-hot core sitting in the base of the tongue
            val core = Path()
            core.moveTo(bx + px * 0.55f, by + py * 0.55f)
            core.lineTo(midX, midY)
            core.lineTo(bx - px * 0.55f, by - py * 0.55f)
            core.close()
            drawPath(core, hotCol, alpha = (0.50f * lick * fade).coerceIn(0f, 1f))
        }
    }

    // sparks lifting off the front, drifting up, guttering out
    for (s in run.sparks) {
        val t = ((p - s[1]) / 0.35f).coerceIn(0f, 1f)
        if (t <= 0.01f || t >= 0.99f) continue
        val born = radiusAt(s[0])
        val sx = o.x + cos(s[0]) * born + sin(s[4] + p * 9f) * 10.dp.toPx() * t
        val sy = o.y + sin(s[0]) * born - t * h * 0.17f * s[2]
        val flick = 0.5f + 0.5f * sin(p * 34f + s[4])
        drawCircle(
            color = if (t < 0.6f) hotCol else glowCol,
            radius = (1.3f + 2.6f * s[3]).dp.toPx() * (1f - t * 0.5f),
            center = Offset(sx, sy),
            alpha = ((1f - t) * flick).coerceIn(0f, 1f)
        )
    }
}

// ------------------------------------------------------------ GLASS SHATTER
/**
 * The old screen is a pane of glass. Cracks spider out from the tap point
 * first; then the pane lets go and every shard tumbles away under gravity with
 * its own spin and drift, nearest shards first. The shards share a jittered
 * vertex grid, so before they fall the pane still tiles the screen perfectly.
 */
private fun DrawScope.drawGlassShatter(
    img: ImageBitmap,
    p: Float,
    toLight: Boolean,
    o: Offset,
    run: ModeSwitchRun
) {
    val w = size.width
    val h = size.height
    val diag = hypot(w, h)
    val cols = run.shatterCols
    val rows = run.shatterRows
    val cellW = w / cols
    val cellH = h / rows

    fun vx(c: Int, r: Int): Float =
        c * cellW + run.shatterVerts[(r * (cols + 1) + c) * 2] * cellW
    fun vy(c: Int, r: Int): Float =
        r * cellH + run.shatterVerts[(r * (cols + 1) + c) * 2 + 1] * cellH

    val crackPhase = sstep((p / 0.20f).coerceIn(0f, 1f))
    val anyFalling = p > 0.16f

    if (!anyFalling) {
        // pane intact: full screenshot plus growing cracks
        drawBase(img)
    } else {
        // pane released: draw every shard on its own trajectory
        for (idx in run.shards.indices) {
            val c = idx % cols
            val r = idx / cols
            val s = run.shards[idx]
            val cx = (c + 0.5f) * cellW
            val cy = (r + 0.5f) * cellH
            val dist = hypot(cx - o.x, cy - o.y) / diag
            val delay = 0.16f + dist * 0.26f + s[0] * 0.10f
            val t = ((p - delay) / 0.52f).coerceIn(0f, 1f)
            if (t >= 1f) continue

            val fall = t * t * h * 1.35f * s[1]
            val drift = t * w * 0.10f * s[2]
            val spin = t * 55f * s[3]
            val alpha = (1f - sstep((t - 0.55f) / 0.45f)).coerceIn(0f, 1f)
            if (alpha <= 0.01f) continue

            val shard = Path()
            shard.moveTo(vx(c, r), vy(c, r))
            shard.lineTo(vx(c + 1, r), vy(c + 1, r))
            shard.lineTo(vx(c + 1, r + 1), vy(c + 1, r + 1))
            shard.lineTo(vx(c, r + 1), vy(c, r + 1))
            shard.close()

            withTransform({
                translate(left = drift, top = fall)
                rotate(degrees = spin, pivot = Offset(cx, cy))
            }) {
                clipPath(shard) {
                    drawBase(img, alpha = alpha)
                    // glass edge catching the light as the shard turns
                    drawPath(
                        shard,
                        color = if (toLight) Color.White else Color(0xFFB9C8FF),
                        alpha = 0.18f * alpha * (0.5f + 0.5f * sin(spin * 0.2f + idx.toFloat())),
                        style = Stroke(width = 1.5.dp.toPx())
                    )
                }
            }
        }
    }

    // radiating cracks while the pane is still holding on
    if (crackPhase > 0.01f && p < 0.30f) {
        val fade = 1f - sstep((p - 0.20f) / 0.10f)
        val crackCol = if (toLight) Color.White else Color(0xFFDDE6FF)
        for (ck in run.cracks) {
            val reach = crackPhase * diag * 0.6f * ck[1]
            val a = ck[0]
            val m1 = Offset(
                o.x + cos(a + ck[2]) * reach * 0.45f,
                o.y + sin(a + ck[2]) * reach * 0.45f
            )
            val m2 = Offset(
                o.x + cos(a + ck[3]) * reach * 0.78f,
                o.y + sin(a + ck[3]) * reach * 0.78f
            )
            val end = Offset(o.x + cos(a) * reach, o.y + sin(a) * reach)
            val crack = Path()
            crack.moveTo(o.x, o.y)
            crack.lineTo(m1.x, m1.y)
            crack.lineTo(m2.x, m2.y)
            crack.lineTo(end.x, end.y)
            drawPath(crack, crackCol, alpha = 0.65f * fade, style = Stroke(width = 1.8.dp.toPx()))
            drawPath(crack, Color.Black, alpha = 0.25f * fade, style = Stroke(width = 3.5.dp.toPx()))
        }
        // stress ring around the impact point
        drawCircle(
            color = crackCol,
            radius = crackPhase * diag * 0.10f,
            center = o,
            alpha = 0.35f * fade,
            style = Stroke(width = 1.5.dp.toPx())
        )
    }
}

// --------------------------------------------------------------- TERMINATOR
private fun DrawScope.drawTerminator(img: ImageBitmap, p: Float, toLight: Boolean) {
    val w = size.width
    val h = size.height
    val e = sstep(p)
    val bulge = w * 0.14f
    val base = mix(-w * 0.32f, w * 1.36f, e)
    val steps = 28

    val cleared = Path()
    cleared.moveTo(-w, -h)
    cleared.lineTo(base, -h)
    var i = 0
    while (i <= steps) {
        val t = i.toFloat() / steps
        cleared.lineTo(base + bulge * sin(t * Math.PI.toFloat()), t * h)
        i++
    }
    cleared.lineTo(base, h * 2f)
    cleared.lineTo(-w, h * 2f)
    cleared.close()
    clipPath(cleared, ClipOp.Difference) { drawBase(img) }

    val seam = Path()
    seam.moveTo(base, -h * 0.06f)
    i = 0
    while (i <= steps) {
        val t = i.toFloat() / steps
        seam.lineTo(base + bulge * sin(t * Math.PI.toFloat()), t * h)
        i++
    }
    seam.lineTo(base, h * 1.06f)

    val warm = if (toLight) Color(0xFFFFC978) else Color(0xFFFF9A4D)
    val cool = if (toLight) Color(0xFFA8ECFF) else Color(0xFF6E8DE0)
    drawPath(seam, warm, alpha = 0.10f, style = Stroke(width = 120.dp.toPx()))
    drawPath(seam, warm, alpha = 0.20f, style = Stroke(width = 44.dp.toPx()))
    drawPath(seam, cool, alpha = 0.55f, style = Stroke(width = 7.dp.toPx()))
    drawPath(seam, Color.White, alpha = 0.72f, style = Stroke(width = 2.dp.toPx()))
}

/** Full-screen overlay. Renders nothing at all when no switch is in flight. */
@Composable
fun ModeSwitchOverlay(controller: ModeSwitchController) {
    val img = controller.capture ?: return
    val anim = controller.animation ?: return
    val run = controller.run ?: return
    val toLight = controller.toLight

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) { detectTapGestures { } }
    ) {
        val p = controller.progress.value
        val o = if (controller.origin == Offset.Zero) {
            Offset(size.width * 0.5f, size.height * 0.86f)
        } else {
            controller.origin
        }
        when (anim) {
            ModeSwitchAnimation.CELESTIAL_ARC ->
                drawCelestialArc(img, p, o, toLight, run)
            ModeSwitchAnimation.SPLASH_WASH -> drawSplashWash(img, p, toLight, run)
            ModeSwitchAnimation.EMBER_BURN -> drawEmberBurn(img, p, toLight, o, run)
            ModeSwitchAnimation.GLASS_SHATTER -> drawGlassShatter(img, p, toLight, o, run)
            ModeSwitchAnimation.TERMINATOR -> drawTerminator(img, p, toLight)
        }
    }
}

private val SunGlow = Color(0xFFFFB753)
private val MoonGlow = Color(0xFF8FB6E8)
private val SunRimLight = Color(0xFFF3E2B8)
private val MoonRimLight = Color(0xFFAEC6E4)

private const val BODY_RADIUS_FRACTION = 0.30f
private const val BOB_PERIOD_SEC = 3.4f
private val TWO_PI = (2.0 * PI).toFloat()

/**
 * The sun / moon puck, drawn by the procedural [CelestialBodyView] character.
 *
 * The character and the altar are separate siblings in the layout, so the
 * shared lighting is faked from this side: we own the hover bob (the body is
 * composed with hover = false) so the cast shadow and the thrown glow stay
 * locked to the character's vertical motion, and we paint a slice of the
 * altar's front rim back over the body's lower edge so it reads as sitting
 * inside a socket rather than floating in front of a picture.
 */
@Composable
fun CelestialModeToggle(
    isLight: Boolean,
    modifier: Modifier = Modifier,
    glyphSize: Dp = 56.dp,
    riseAbove: Dp = 18.dp,
    enabled: Boolean = true,
    hidden: Boolean = false,
    descent: () -> Float = { 0f },
    /**
     * Lets an outside owner drive this puck's face. The companion passes its
     * own face state here so it can talk and gesture with the character that
     * is actually on screen, instead of animating a second invisible one.
     */
    faceOverride: CelestialFaceState? = null,
    /**
     * Optional draw-only layer painted over the body: spectacles, a hat, arms.
     * It inherits the body's bob and press dip so props stay glued to the
     * face, and it never receives touches.
     */
    propOverlay: (@Composable () -> Unit)? = null,
    onPositioned: (Offset) -> Unit,
    onToggle: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val description = if (isLight) "Switch to dark theme" else "Switch to light theme"
    // remember is called unconditionally and the choice made afterwards. Doing
    // it the other way round -- faceOverride ?: rememberCelestialFaceState() --
    // would make the remember slot conditional, which is a composition hazard.
    val ownFace = rememberCelestialFaceState()
    val face = faceOverride ?: ownFace

    // 0f = moon lighting, 1f = sun lighting; drives glow/rim crossfades.
    // Matches the resting body: in dark mode the SUN waits on the altar and
    // in light mode the MOON does, so the lighting must follow that body.
    val lightMix by animateFloatAsState(
        targetValue = if (isLight) 0f else 1f,
        animationSpec = tween(durationMillis = 500),
        label = "celestialLightMix"
    )

    // We own the bob (hover = false on the body) so the cast shadow stays
    // perfectly in sync with the character's vertical motion.
    var bob by remember { mutableFloatStateOf(0f) } // -1f (down) .. 1f (up)
    LaunchedEffect(Unit) {
        var start = -1L
        while (true) {
            withInfiniteAnimationFrameNanos { now ->
                if (start < 0L) start = now
                val t = (now - start) / 1_000_000_000f
                bob = sin(t * TWO_PI / BOB_PERIOD_SEC)
            }
        }
    }

    // Press dip + squash. Springs back on release, no ripple.
    val press = remember { Animatable(0f) }
    LaunchedEffect(interaction) {
        val scope = this
        interaction.interactions.collect { event ->
            when (event) {
                is PressInteraction.Press -> {
                    scope.launch {
                        press.animateTo(1f, tween(90, easing = LinearOutSlowInEasing))
                    }
                    scope.launch { face.play(CelestialExpression.SURPRISE) }
                }
                is PressInteraction.Release, is PressInteraction.Cancel -> {
                    scope.launch {
                        press.animateTo(
                            0f,
                            spring(dampingRatio = 0.38f, stiffness = Spring.StiffnessMedium)
                        )
                    }
                }
            }
        }
    }

    Box(
        modifier = modifier
            .size(glyphSize)
            .offset(y = -riseAbove)
            .onGloballyPositioned { onPositioned(it.boundsInRoot().center) }
            .graphicsLayer { alpha = if (hidden) 0f else 1f }
            .clickable(
                interactionSource = interaction,
                indication = null,
                enabled = enabled && !hidden
            ) { onToggle() }
            .semantics { contentDescription = description }
            .drawWithCache {
                // Everything heavy is hoisted here; the draw lambda allocates nothing.
                val bodyR = size.minDimension * BODY_RADIUS_FRACTION
                val cx = size.width / 2f
                val groundY = size.height * 0.80f
                val bobAmpPx = 2.5.dp.toPx()
                val dipPx = 6.dp.toPx()
                val maxDy = bobAmpPx + dipPx

                // Unit-radius gradients, positioned/sized via canvas transforms.
                val shadowBrush = Brush.radialGradient(
                    0f to Color(0xCC000000), 0.7f to Color(0x33000000), 1f to Color.Transparent,
                    center = Offset.Zero, radius = 1f
                )
                val sunGlowBrush = Brush.radialGradient(
                    0f to SunGlow, 1f to SunGlow.copy(alpha = 0f),
                    center = Offset.Zero, radius = 1f
                )
                val moonGlowBrush = Brush.radialGradient(
                    0f to MoonGlow, 1f to MoonGlow.copy(alpha = 0f),
                    center = Offset.Zero, radius = 1f
                )

                // Basin geometry, matched to the altar's carved hollow. Nothing is
                // stroked here any more: the altar art draws its own basin, and a
                // stroked arc read as a semicircle line floating under the body.
                val socketRx = bodyR * 0.72f
                val socketRy = bodyR * 0.26f

                onDrawWithContent {
                    val dy = press.value * dipPx - bob * bobAmpPx
                    val prox = ((dy / maxDy) + 1f) / 2f // 0 = highest, 1 = closest to altar
                    val mix = lightMix

                    // Colored glow the character throws down onto the altar.
                    val glowA = lerp(0.28f, 0.5f, prox)
                    withTransform({
                        translate(cx, groundY)
                        scale(bodyR * lerp(2.2f, 1.7f, prox), bodyR * lerp(1.5f, 1.1f, prox), Offset.Zero)
                    }) {
                        drawCircle(sunGlowBrush, radius = 1f, center = Offset.Zero, alpha = glowA * mix)
                        drawCircle(moonGlowBrush, radius = 1f, center = Offset.Zero, alpha = glowA * (1f - mix))
                    }

                    // Contact shadow: shrinks + darkens as the body drops, grows + softens as it lifts.
                    val shScale = lerp(1.18f, 0.82f, prox)
                    withTransform({
                        translate(cx, groundY)
                        scale(bodyR * 1.05f * shScale, bodyR * 0.34f * shScale, Offset.Zero)
                    }) {
                        drawCircle(
                            shadowBrush, radius = 1f, center = Offset.Zero,
                            alpha = lerp(0.22f, 0.42f, prox)
                        )
                    }

                    drawContent()
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                // ---- PHASE 4: threshold over-paint (mouth shadow, rim cut, flare, sparks) ----
                // Goes IMMEDIATELY BEFORE the graphicsLayer so it draws in stable box
                // space, over the already-transformed body.
                .drawWithCache {
                    val bodyR = size.minDimension * BODY_RADIUS_FRACTION
                    val cx = size.width / 2f
                    val groundY = size.height * 0.80f
                    val socketRx = bodyR * 0.72f
                    val socketRy = bodyR * 0.26f

                    // The dark interior of the altar's mouth, painted back OVER the body.
                    val mouthPath = Path().apply {
                        addOval(
                            Rect(
                                cx - socketRx * 0.92f, groundY - socketRy * 0.92f,
                                cx + socketRx * 0.92f, groundY + socketRy * 0.92f
                            )
                        )
                    }

                    // Unit-radius spill gradients, positioned/sized via canvas transforms.
                    val sunSpill = Brush.radialGradient(
                        0f to SunGlow, 1f to SunGlow.copy(alpha = 0f),
                        center = Offset.Zero, radius = 1f
                    )
                    val moonSpill = Brush.radialGradient(
                        0f to MoonGlow, 1f to MoonGlow.copy(alpha = 0f),
                        center = Offset.Zero, radius = 1f
                    )

                    // Fixed spark seats along the 18..162deg rim arc. Deterministic: the
                    // same frame value gives the same picture, forwards and backwards.
                    val seats = floatArrayOf(0.10f, 0.28f, 0.50f, 0.72f, 0.90f)
                    val sparkX = FloatArray(seats.size)
                    val sparkBaseY = FloatArray(seats.size)
                    for (i in seats.indices) {
                        val ang = (18f + 144f * seats[i]) * (PI.toFloat() / 180f)
                        sparkX[i] = cx + socketRx * cos(ang)
                        sparkBaseY[i] = groundY + socketRy * sin(ang)
                    }
                    val sparkR = 1.6.dp.toPx()
                    val sparkLift = 11.dp.toPx()

                    onDrawWithContent {
                        drawContent()

                        val d = descent().coerceIn(0f, 1f)
                        if (d <= 0.001f) return@onDrawWithContent

                        val mixT = lightMix
                        // Hottest exactly as the body crosses the rim; symmetric, so the
                        // flare reads as a rune-surge in BOTH directions.
                        val flare = bump(d, 0.50f, 0.34f)
                        val swallowed = sstep(((d - 0.20f) / 0.80f).coerceIn(0f, 1f))
                        val rim = lerp(MoonRimLight, SunRimLight, mixT)
                        // Ease the over-paint in across the first few percent so the mouth
                        // shadow and occlusion band never pop on (or off) as a hard step.
                        val onset = sstep((d / 0.10f).coerceIn(0f, 1f))

                        // 1) Mouth interior darkens over the body: sells "it went INSIDE".
                        drawPath(
                            mouthPath, Color.Black,
                            alpha = (0.30f + 0.40f * swallowed) * onset
                        )

                        // 2) Light spilling UP out of the opening, strongest at threshold.
                        withTransform({
                            translate(cx, groundY)
                            scale(socketRx * 1.7f, socketRy * 3.4f, Offset.Zero)
                        }) {
                            drawCircle(
                                sunSpill, radius = 1f, center = Offset.Zero,
                                alpha = 0.45f * flare * mixT
                            )
                            drawCircle(
                                moonSpill, radius = 1f, center = Offset.Zero,
                                alpha = 0.45f * flare * (1f - mixT)
                            )
                        }

                        // 3) A few motes kicked up off the basin lip at the threshold.
                        for (i in seats.indices) {
                            val rise = flare * (0.45f + 0.55f * seats[i])
                            drawCircle(
                                color = rim,
                                radius = sparkR * (0.7f + 0.3f * (1f - seats[i])),
                                center = Offset(sparkX[i], sparkBaseY[i] - sparkLift * rise),
                                alpha = flare * (0.5f + 0.5f * seats[i])
                            )
                        }
                    }
                }
                .graphicsLayer {
                    val p = press.value
                    val d = descent().coerceIn(0f, 1f)

                    // Beat 1 -- ANTICIPATION: a tiny hop + puff right as the drop begins.
                    val antic = bump(d, 0.09f, 0.11f)
                    // Beat 2 -- DESCENT: the plunge starts only after the wind-up.
                    val sink = sstep(((d - 0.12f) / 0.88f).coerceIn(0f, 1f))
                    // Beat 3 -- THRESHOLD: stretch with speed, then pinched by the mouth.
                    val stretch = bump(d, 0.50f, 0.30f)
                    val swallow = sstep(((d - 0.66f) / 0.34f).coerceIn(0f, 1f))

                    translationY = p * 6.dp.toPx() -
                        bob * 2.5.dp.toPx() * (1f - d) -      // idle bob hands off smoothly
                        antic * 3.5.dp.toPx() +               // wind-up lift
                        sink * glyphSize.toPx() * 0.58f       // the plunge

                    scaleX = (1f + 0.07f * p) *
                        (1f + 0.05f * antic) *                // puff on the wind-up
                        (1f - 0.10f * stretch) *              // narrows while falling fast
                        (1f - 0.30f * swallow)                // squeezed by the opening
                    scaleY = (1f - 0.12f * p) *
                        (1f - 0.06f * antic) *
                        (1f + 0.14f * stretch) *              // stretches with speed
                        (1f - 0.55f * swallow)                // crushed flat going under

                    // Hard rule (B): alpha reaches 0 at d = 0.90, leaving margin before the
                    // screenshot at d == 1f. The mouth shadow covers the last sliver.
                    alpha = 1f - sstep(((d - 0.62f) / 0.28f).coerceIn(0f, 1f))

                    // Squash from the body's resting point on the altar.
                    transformOrigin = TransformOrigin(0.5f, 0.80f)
                }
                .drawWithCache {
                    // Bounced light on the character's underside, clipped to the body disc
                    // so the read-only shading is tinted, never covered.
                    val bodyR = size.minDimension * BODY_RADIUS_FRACTION
                    val c = size.center
                    val bodyClip = Path().apply {
                        addOval(Rect(center = c, radius = bodyR + 1f))
                    }
                    val sunBounce = Brush.radialGradient(
                        0f to SunRimLight, 1f to SunRimLight.copy(alpha = 0f),
                        center = Offset.Zero, radius = 1f
                    )
                    val moonBounce = Brush.radialGradient(
                        0f to MoonRimLight, 1f to MoonRimLight.copy(alpha = 0f),
                        center = Offset.Zero, radius = 1f
                    )
                    onDrawWithContent {
                        drawContent()
                        val mix = lightMix
                        val strength = 0.22f + 0.18f * press.value // brighter when dipped closer
                        clipPath(bodyClip) {
                            withTransform({
                                translate(c.x, c.y + bodyR)
                                scale(bodyR * 1.05f, bodyR * 0.55f, Offset.Zero)
                            }) {
                                drawCircle(sunBounce, 1f, Offset.Zero, alpha = strength * mix)
                                drawCircle(moonBounce, 1f, Offset.Zero, alpha = strength * (1f - mix))
                            }
                        }
                    }
                }
        ) {
            CelestialBodyView(
                // The altar holds the body that is NOT ruling the sky: the SUN
                // waits here in dark mode, the MOON in light mode. Tapping
                // launches the waiting body; the other rises from below.
                form = if (isLight) 0f else 1f,
                modifier = Modifier.fillMaxSize(),
                face = face,
                hover = false // we drive the bob so the shadow stays in sync
            )
        }

        // ---- COMPANION PROP LAYER ------------------------------------------
        // Drawn in the puck's own box and AFTER the body, so props land on the
        // face and paint over it. It repeats the body's bob and press dip:
        // without that, a pair of spectacles would sit still while the head
        // breathed underneath them, which reads instantly as broken.
        //
        // Draw-only, deliberately. No clickable, no pointerInput. The tap on
        // this puck is the theme toggle and it stays instant, always.
        if (propOverlay != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        translationY = press.value * 6.dp.toPx() - bob * 2.5.dp.toPx()
                        // Props vanish with the body during the arc flight.
                        alpha = if (hidden) 0f else 1f
                    }
            ) {
                propOverlay()
            }
        }
    }
}

/**
 * The runic altar the sun and moon are set into, drawn by [CelestialAltarArt].
 * While the Celestial Arc is in flight the altar follows the flight's progress
 * one to one; when the arc deactivates it eases shut instead of snapping.
 */
@Composable
fun CelestialAltar(
    isLight: Boolean,
    modifier: Modifier = Modifier,
    arcActive: Boolean = false,
    arcProgress: () -> Float = { 0f },
    descent: () -> Float = { 0f }
) {
    val progress by rememberUpdatedState(arcProgress)
    val open = remember { Animatable(0f) }

    LaunchedEffect(arcActive) {
        if (arcActive) {
            // Follow the gesture 1:1 while active.
            while (true) {
                withFrameNanos { }
                open.snapTo(progress().coerceIn(0f, 1f))
            }
        } else if (open.value > 0f) {
            // Ease shut instead of snapping when the arc deactivates.
            open.animateTo(
                targetValue = 0f,
                animationSpec = tween(
                    durationMillis = 450,
                    easing = CubicBezierEasing(0.2f, 0f, 0f, 1f)
                )
            )
        }
    }

    // The altar opens for the descent on every animation, and additionally
    // tracks the flight one to one when the Celestial Arc is the one playing.
    CelestialAltarArt(
        isLight = isLight,
        modifier = modifier,
        openAmount = max(open.value, descent().coerceIn(0f, 1f))
    )
}

/**
 * The subtle ambient dent/glow inside the glass bar behind the altar, drawn
 * by [CelestialAltarWell].
 */
@Composable
fun CelestialPanelWell(
    isLight: Boolean,
    modifier: Modifier = Modifier
) {
    CelestialAltarWell(isLight = isLight, modifier = modifier)
}
