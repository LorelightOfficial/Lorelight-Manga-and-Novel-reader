package com.lorelight.ui.reader

import android.content.SharedPreferences
import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import com.lorelight.tts.TtsPlaybackManager
import com.lorelight.ui.components.FontManagerEngine
import com.lorelight.data.model.Novel
import com.lorelight.data.local.NovelPreferences
import com.lorelight.utils.TextFilter
import com.lorelight.utils.FilterRule
import com.lorelight.crawler.CrawlerEngine
import com.lorelight.core.getSafeFloat
import com.lorelight.core.getSafeLong
import com.lorelight.core.getSafeBoolean
import com.lorelight.core.getSafeString

class ReaderViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext

    // Delegate TTS & Player State to TtsPlaybackManager
    val isTtsReady = TtsPlaybackManager.isTtsReady
    val availableVoices = TtsPlaybackManager.availableVoices
    val selectedVoice = TtsPlaybackManager.selectedVoice
    
    val speechRate = TtsPlaybackManager.speechRate
    val speechPitch = TtsPlaybackManager.speechPitch
    val nextSentencePauseMs = TtsPlaybackManager.nextSentencePauseMs
    val paragraphPauseMs = TtsPlaybackManager.paragraphPauseMs
    val punctuationPauseScale = TtsPlaybackManager.punctuationPauseScale

    // Sleep Timer
    val sleepTimerMinutes = TtsPlaybackManager.sleepTimerMinutes

    // Browser Force Dark Mode
    val browserForceDarkMode = MutableStateFlow(false)

    // Feature Toggles: Immersive Mode & Volume Key Page Turn
    val immersiveMode = MutableStateFlow(false)
    val volumeKeysEnabled = MutableStateFlow(false)

    fun setImmersiveMode(v: Boolean) { immersiveMode.value = v }
    fun setVolumeKeysEnabled(v: Boolean) { volumeKeysEnabled.value = v }

    // Reader Mode Settings (Read vs Listen)
    val readerMode = MutableStateFlow("Listen") // "Read" or "Listen"
    val readerFontFamily = MutableStateFlow("System Default")
    val appInterfaceFont = MutableStateFlow("System Default")


    val isDimmerEnabled = MutableStateFlow(false)
    val isTapNavigationEnabled = MutableStateFlow(false)
    val isDefaultHighlight = MutableStateFlow(true)
    val customHighlightColor = MutableStateFlow(0xFF39FF14L) // Glow Green default

    // TTS Voice filtering by Accents
    val allVoices = TtsPlaybackManager.allVoices
    val availableAccents = TtsPlaybackManager.availableAccents
    val selectedAccent = TtsPlaybackManager.selectedAccent
    val filteredVoices = TtsPlaybackManager.filteredVoices

    // Typography
    val readerFontSize = MutableStateFlow(18f)
    val readerLineSpacing = MutableStateFlow(1.3f)
    val readerParagraphSpacing = MutableStateFlow(16f)
    val readerTextAlignment = MutableStateFlow("Left")

    val readerBgColor = MutableStateFlow(0xFF1C1B1FL)
    val readerTextColor = MutableStateFlow(0xFFE6E1E5L)
    val readerHighlightColor = MutableStateFlow(0xFF2E7D32L)
    val readerBackgroundType = MutableStateFlow("Theme")
    val appTheme = MutableStateFlow("Forest Green")
    val appThemeMode = MutableStateFlow("Dark")
    val appThemeColorFlow = appTheme.combine(appThemeMode) { theme, mode -> Pair(theme, mode) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, Pair("Forest Green", "Dark"))

    // Day / night switch animation. "Random" shuffles the pool below and never
    // repeats back to back; "Single" pins whatever themeSwitchAnimSingle holds.
    // The pool is a CSV of ModeSwitchAnimation ids so it survives new entries
    // being added later without a preference migration.
    val themeSwitchAnimMode = MutableStateFlow("Single")
    val themeSwitchAnimPool = MutableStateFlow("celestial,splash,ember,shatter,terminator")
    val themeSwitchAnimSingle = MutableStateFlow("celestial")

    // Playback State
    val activeNovel = TtsPlaybackManager.activeNovel
    val chapters = TtsPlaybackManager.chapters
    val activeChapterIndex = TtsPlaybackManager.activeChapterIndex
    val activeSentenceIndex = TtsPlaybackManager.activeSentenceIndex
    val sentences = TtsPlaybackManager.sentences
    val isPlaying = TtsPlaybackManager.isPlaying
    val isFetchingChapter = TtsPlaybackManager.isFetchingChapter
    val cachedChapterIndices = TtsPlaybackManager.cachedChapterIndices
    val maxPlayableIndex = TtsPlaybackManager.maxPlayableIndex
    val autoNextChapter = TtsPlaybackManager.autoNextChapter

    // Text Filter Rules
    val textFilterRules = TtsPlaybackManager.textFilterRules

    val activeNovelTitle = TtsPlaybackManager.activeNovelTitle

    val filteredSentences = TtsPlaybackManager.filteredSentences

    // TTS error message state flow
    val errorMessage = TtsPlaybackManager.errorMessage

    val tokensBySentence = filteredSentences.map { list ->
        var globalWordIdx = 0
        list.map { block ->
            if (block is ReaderBlock.TextBlock) {
                val (rawTokens, nextIdx) = TextFilter.tokenize(block.text, globalWordIdx)
                globalWordIdx = nextIdx
                rawTokens
            } else {
                emptyList()
            }
        }
    }.flowOn(kotlinx.coroutines.Dispatchers.Default)
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), emptyList())

    fun loadRules() {
        TtsPlaybackManager.loadRules()
    }

    fun saveRules(rules: List<FilterRule>) {
        TtsPlaybackManager.saveRules(rules)
    }

    val highlights = MutableStateFlow<List<Highlight>>(emptyList())

    fun loadHighlights() {
        viewModelScope.launch(Dispatchers.IO) {
            highlights.value = NovelPreferences.loadHighlightsFromPrefs(appContext)
        }
    }

    fun saveHighlight(highlight: Highlight) {
        val current = highlights.value.toMutableList()
        val idx = current.indexOfFirst { it.id == highlight.id }
        if (idx >= 0) {
            current[idx] = highlight
        } else {
            current.add(highlight)
        }
        highlights.value = current
        viewModelScope.launch(Dispatchers.IO) {
            NovelPreferences.saveHighlightsToPrefs(appContext, current)
        }
    }

    fun removeHighlight(id: String) {
        val current = highlights.value.filter { it.id != id }
        highlights.value = current
        viewModelScope.launch(Dispatchers.IO) {
            NovelPreferences.saveHighlightsToPrefs(appContext, current)
        }
    }

    init {
        loadRules()
        loadHighlights()
        // Load saved settings
        val prefs = appContext.getSharedPreferences("reader_prefs", Context.MODE_PRIVATE)
        readerFontSize.value = prefs.getSafeFloat("reader_font_size", 18f)
        readerLineSpacing.value = prefs.getSafeFloat("reader_line_spacing", 1.3f)
        readerParagraphSpacing.value = prefs.getSafeFloat("reader_paragraph_spacing", 16f)
        readerTextAlignment.value = prefs.getSafeString("reader_text_alignment", "Left") ?: "Left"
        readerBgColor.value = prefs.getSafeLong("reader_bg_color", 0xFF1C1B1FL)
        readerTextColor.value = prefs.getSafeLong("reader_text_color", 0xFFE6E1E5L)
        readerHighlightColor.value = prefs.getSafeLong("reader_highlight_color", 0xFF2E7D32L)

        // Load new settings
        readerMode.value = prefs.getSafeString("reader_mode", "Listen") ?: "Listen"
        readerFontFamily.value = FontManagerEngine.getSelectedFont(appContext, "reader", "System Default")
        appInterfaceFont.value = FontManagerEngine.getSelectedFont(appContext, "app_interface", "System Default")

        isDimmerEnabled.value = prefs.getSafeBoolean("is_dimmer_enabled", false)
        isTapNavigationEnabled.value = prefs.getSafeBoolean("is_tap_navigation_enabled", false)
        isDefaultHighlight.value = prefs.getSafeBoolean("is_default_highlight", true)
        customHighlightColor.value = prefs.getSafeLong("custom_highlight_color", 0xFF39FF14L)
        readerBackgroundType.value = prefs.getSafeString("reader_background_type", "Theme") ?: "Theme"
        appTheme.value = prefs.getSafeString("app_theme", "Forest Green") ?: "Forest Green"
        // FIX B14: this was hardcoded to "Dark" on every load, which threw away
        // the value the collector further down this file already persists as
        // "app_theme_mode". Result: the complete light palette in Theme.kt was
        // unreachable. Default stays "Dark" so existing installs look unchanged.
        appThemeMode.value = prefs.getSafeString("app_theme_mode", "Dark") ?: "Dark"
        // The animation set was rebuilt around "celestial" + "terminator",
        // then grew "splash", "ember" and "shatter". A pool saved by the old
        // build may still contain retired ids (eclipse, rain, sand, meteor,
        // wick); if we spot any of those we reset the pool to the full current
        // set rather than letting it silently collapse to whatever survived.
        val fullAnimPool = "celestial,splash,ember,shatter,terminator"
        themeSwitchAnimMode.value = prefs.getSafeString("theme_switch_anim_mode", "Single") ?: "Single"
        val savedAnimPool = prefs.getSafeString("theme_switch_anim_pool", fullAnimPool)
            ?: fullAnimPool
        val retiredAnimIds = setOf("eclipse", "rain", "sand", "meteor", "wick")
        themeSwitchAnimPool.value =
            if (savedAnimPool.split(',').any { it.trim() in retiredAnimIds }) fullAnimPool
            else savedAnimPool
        val savedAnimSingle = prefs.getSafeString("theme_switch_anim_single", "celestial") ?: "celestial"
        themeSwitchAnimSingle.value = if (savedAnimSingle in retiredAnimIds) "celestial" else savedAnimSingle
        browserForceDarkMode.value = prefs.getSafeBoolean("browser_force_dark_mode", false)
        immersiveMode.value = prefs.getSafeBoolean("reader_immersive_mode", false)
        volumeKeysEnabled.value = prefs.getSafeBoolean("reader_volume_keys", false)

        // Setup observers to save preferences
        viewModelScope.launch { readerFontSize.collect { prefs.edit().putFloat("reader_font_size", it).apply() } }
        viewModelScope.launch { readerLineSpacing.collect { prefs.edit().putFloat("reader_line_spacing", it).apply() } }
        viewModelScope.launch { readerParagraphSpacing.collect { prefs.edit().putFloat("reader_paragraph_spacing", it).apply() } }
        viewModelScope.launch { readerTextAlignment.collect { prefs.edit().putString("reader_text_alignment", it).apply() } }
        viewModelScope.launch { readerBgColor.collect { prefs.edit().putLong("reader_bg_color", it).apply() } }
        viewModelScope.launch { readerTextColor.collect { prefs.edit().putLong("reader_text_color", it).apply() } }
        viewModelScope.launch { readerHighlightColor.collect { prefs.edit().putLong("reader_highlight_color", it).apply() } }

        // Setup new observers to save preferences
        viewModelScope.launch { readerMode.collect { prefs.edit().putString("reader_mode", it).apply() } }
        viewModelScope.launch { 
            readerFontFamily.collect { 
                FontManagerEngine.setSelectedFont(appContext, "reader", it)
                prefs.edit().putString("reader_font_family", it).apply() 
            } 
        }
        viewModelScope.launch { 
            appInterfaceFont.collect { 
                FontManagerEngine.setSelectedFont(appContext, "app_interface", it)
            } 
        }

        viewModelScope.launch { isDimmerEnabled.collect { prefs.edit().putBoolean("is_dimmer_enabled", it).apply() } }
        viewModelScope.launch { isTapNavigationEnabled.collect { prefs.edit().putBoolean("is_tap_navigation_enabled", it).apply() } }
        viewModelScope.launch { isDefaultHighlight.collect { prefs.edit().putBoolean("is_default_highlight", it).apply() } }
        viewModelScope.launch { customHighlightColor.collect { prefs.edit().putLong("custom_highlight_color", it).apply() } }
        viewModelScope.launch { readerBackgroundType.collect { prefs.edit().putString("reader_background_type", it).apply() } }
        viewModelScope.launch { appTheme.collect { prefs.edit().putString("app_theme", it).apply() } }
        viewModelScope.launch { appThemeMode.collect { prefs.edit().putString("app_theme_mode", it).apply() } }
        viewModelScope.launch { themeSwitchAnimMode.collect { prefs.edit().putString("theme_switch_anim_mode", it).apply() } }
        viewModelScope.launch { themeSwitchAnimPool.collect { prefs.edit().putString("theme_switch_anim_pool", it).apply() } }
        viewModelScope.launch { themeSwitchAnimSingle.collect { prefs.edit().putString("theme_switch_anim_single", it).apply() } }
        viewModelScope.launch { browserForceDarkMode.collect { prefs.edit().putBoolean("browser_force_dark_mode", it).apply() } }
        viewModelScope.launch { immersiveMode.collect { prefs.edit().putBoolean("reader_immersive_mode", it).apply() } }
        viewModelScope.launch { volumeKeysEnabled.collect { prefs.edit().putBoolean("reader_volume_keys", it).apply() } }
    }

    val showBatteryOptimizationDialog = MutableStateFlow(false)

    fun checkBatteryOptimizationOnPlay() {
        val prefs = appContext.getSharedPreferences("reader_prefs", Context.MODE_PRIVATE)
        val alreadyAsked = prefs.getBoolean("battery_optimization_asked", false)
        if (!alreadyAsked) {
            val pm = appContext.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                val isIgnoring = pm.isIgnoringBatteryOptimizations(appContext.packageName)
                if (!isIgnoring) {
                    showBatteryOptimizationDialog.value = true
                }
            }
        }
    }

    fun dismissBatteryOptimizationDialog(dontAskAgain: Boolean) {
        if (dontAskAgain) {
            val prefs = appContext.getSharedPreferences("reader_prefs", Context.MODE_PRIVATE)
            prefs.edit().putBoolean("battery_optimization_asked", true).apply()
        }
        showBatteryOptimizationDialog.value = false
    }

    fun launchBatteryExemptionIntent(context: Context) {
        try {
            val intent = Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = android.net.Uri.parse("package:${context.packageName}")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("ReaderViewModel", "Failed to launch battery exemption settings", e)
        }
    }

    fun updateFilteredVoicesAndSelectDefault() {
        TtsPlaybackManager.updateFilteredVoicesAndSelectDefault()
    }

    fun selectAccentAndApply(accent: String) {
        TtsPlaybackManager.selectAccentAndApply(accent)
    }

    fun setBrowserForceDarkMode(enabled: Boolean) {
        browserForceDarkMode.value = enabled
    }

    fun startReading(novel: Novel, startChapterName: String? = null, startChapterIndex: Int? = null) {
        checkBatteryOptimizationOnPlay()
        TtsPlaybackManager.startReading(novel, startChapterName = startChapterName, startChapterIndex = startChapterIndex)
    }

    fun startReadingAndPlay(novel: Novel, startChapterName: String? = null, startChapterIndex: Int? = null) {
        checkBatteryOptimizationOnPlay()
        TtsPlaybackManager.startReadingAndPlay(novel, startChapterName = startChapterName, startChapterIndex = startChapterIndex)
    }

    fun saveProgress() {
        TtsPlaybackManager.saveProgress()
    }

    fun saveDetailedProgress(paragraphIndex: Int, scrollOffset: Int, wordIndex: Int) {
        TtsPlaybackManager.saveDetailedProgress(paragraphIndex, scrollOffset, wordIndex)
    }

    fun recomputeCachedChapters() {
        TtsPlaybackManager.recomputeCachedChapters()
    }

    fun getFreshestNovel(): Novel? {
        return TtsPlaybackManager.getFreshestNovel()
    }

    fun selectChapter(index: Int, initialParagraphIndex: Int = 0, autoPlay: Boolean = false) {
        TtsPlaybackManager.selectChapter(index, initialParagraphIndex, autoPlay)
    }

    fun nextChapter() {
        TtsPlaybackManager.dispatch(TtsPlaybackManager.TtsCommand.NextChapter)
    }

    fun prevChapter() {
        TtsPlaybackManager.dispatch(TtsPlaybackManager.TtsCommand.PrevChapter)
    }

    fun jumpToSentence(index: Int) = TtsPlaybackManager.jumpToSentence(index)

    private suspend fun downloadOne(context: Context, url: String): Boolean {
        if (CrawlerEngine.isChapterCached(context, url)) return true
        var attempt = 0
        while (attempt < 3) {
            try {
                val text = CrawlerEngine.extractChapterText(context, url)
                if (text.isNotBlank()
                    && text != "Failed to load chapter content."
                    && text != "No content extracted."
                    && CrawlerEngine.isChapterCached(context, url)) return true
            } catch (e: Exception) {
                Log.e("Download", "chapter fetch failed (try ${attempt+1})", e)
            }
            attempt++
            delay(1500L * attempt)   // backoff: 1.5s, 3s, 4.5s
        }
        return false
    }

    fun startDownloadWhole(novel: Novel) {
        if (com.lorelight.manga.download.MangaDownloadManager.isManga(novel)) {
            // Manga is images, not crawlable text: hand off to the manga
            // downloader, which warms Coil's page cache (and optionally OCR).
            com.lorelight.manga.download.MangaDownloadManager.downloadWhole(appContext, novel, viewModelScope)
            Toast.makeText(appContext, "Starting manga download for ${novel.title}...", Toast.LENGTH_SHORT).show()
            return
        }
        val jobId = "novel_${novel.id}"
        val total = novel.chapters.size
        val targetIndices = (0 until total).toList()
        val initialItems = targetIndices.map { i ->
            val chTitle = novel.chapters.getOrNull(i) ?: "Chapter ${i + 1}"
            val chUrl = novel.chapterUrls.getOrNull(i) ?: "ch_$i"
            val isCached = CrawlerEngine.isChapterCached(appContext, chUrl)
            com.lorelight.data.download.DownloadItemState(
                id = chUrl,
                name = chTitle,
                status = if (isCached) com.lorelight.data.download.DownloadStatus.DONE else com.lorelight.data.download.DownloadStatus.QUEUED,
                current = if (isCached) 1L else 0L,
                total = 1L
            )
        }
        com.lorelight.data.download.DownloadProgressBus.start(
            id = jobId,
            title = novel.title,
            kind = "Novel",
            total = total,
            novelId = novel.id,
            items = initialItems
        )

        var isPaused = false
        val downloadJob = viewModelScope.launch(Dispatchers.IO) {
            launch(Dispatchers.Main) {
                Toast.makeText(appContext, "Starting background download of all chapters for ${novel.title}...", Toast.LENGTH_SHORT).show()
            }
            
            try {
                // First pass
                for (i in targetIndices) {
                    if (com.lorelight.data.download.DownloadProgressBus.isCancelled(jobId)) {
                        com.lorelight.data.download.DownloadProgressBus.cancel(jobId)
                        return@launch
                    }
                    while (isPaused) {
                        delay(500L)
                        if (com.lorelight.data.download.DownloadProgressBus.isCancelled(jobId)) {
                            com.lorelight.data.download.DownloadProgressBus.cancel(jobId)
                            return@launch
                        }
                    }

                    val url = novel.chapterUrls.getOrNull(i)
                    if (url.isNullOrBlank()) continue
                    if (CrawlerEngine.isChapterCached(appContext, url)) {
                        com.lorelight.data.download.DownloadProgressBus.finishItem(jobId, url)
                        continue
                    }

                    com.lorelight.data.download.DownloadProgressBus.startItem(jobId, url)
                    try {
                        downloadOne(appContext, url)
                        if (CrawlerEngine.isChapterCached(appContext, url)) {
                            com.lorelight.data.download.DownloadProgressBus.finishItem(jobId, url)
                        } else {
                            com.lorelight.data.download.DownloadProgressBus.failItem(jobId, url, "Chapter download failed")
                        }
                        delay(1800L) // Gentle delay
                    } catch (e: Exception) {
                        com.lorelight.data.download.DownloadProgressBus.failItem(jobId, url, e.message ?: "Failed")
                    }
                }
                
                // Second pass (verification and retry)
                for (i in targetIndices) {
                    if (com.lorelight.data.download.DownloadProgressBus.isCancelled(jobId)) {
                        com.lorelight.data.download.DownloadProgressBus.cancel(jobId)
                        return@launch
                    }
                    while (isPaused) {
                        delay(500L)
                        if (com.lorelight.data.download.DownloadProgressBus.isCancelled(jobId)) {
                            com.lorelight.data.download.DownloadProgressBus.cancel(jobId)
                            return@launch
                        }
                    }

                    val url = novel.chapterUrls.getOrNull(i)
                    if (url.isNullOrBlank()) continue
                    if (!CrawlerEngine.isChapterCached(appContext, url)) {
                        com.lorelight.data.download.DownloadProgressBus.startItem(jobId, url)
                        try {
                            downloadOne(appContext, url)
                            if (CrawlerEngine.isChapterCached(appContext, url)) {
                                com.lorelight.data.download.DownloadProgressBus.finishItem(jobId, url)
                            } else {
                                com.lorelight.data.download.DownloadProgressBus.failItem(jobId, url, "Retry failed")
                            }
                            delay(3000L) // Longer delay
                        } catch (e: Exception) {
                            com.lorelight.data.download.DownloadProgressBus.failItem(jobId, url, e.message ?: "Retry failed")
                        }
                    }
                }
                
                // Honest result
                var cachedCount = 0
                for (i in targetIndices) {
                    val url = novel.chapterUrls.getOrNull(i)
                    if (!url.isNullOrBlank() && CrawlerEngine.isChapterCached(appContext, url)) {
                        cachedCount++
                    }
                }
                
                TtsPlaybackManager.recomputeCachedChapters()
                val summary = if (cachedCount == total) "Downloaded all $total chapters."
                else "Downloaded $cachedCount of $total. ${total - cachedCount} couldn't be fetched."
                com.lorelight.data.download.DownloadProgressBus.finish(jobId, summary)
                
                launch(Dispatchers.Main) {
                    if (cachedCount == total) {
                        Toast.makeText(appContext, "Downloaded all $total chapters for ${novel.title}!", Toast.LENGTH_LONG).show()
                    } else {
                        val missing = total - cachedCount
                        Toast.makeText(appContext, "Downloaded $cachedCount of $total. $missing chapters couldn't be fetched (tap Download again to retry).", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                com.lorelight.data.download.DownloadProgressBus.fail(jobId, "Download failed: ${e.message ?: e.toString()}")
            } finally {
                com.lorelight.data.download.DownloadProgressBus.unregisterCanceller(jobId)
            }
        }

        com.lorelight.data.download.DownloadProgressBus.registerCanceller(jobId) {
            downloadJob.cancel()
        }
        com.lorelight.data.download.DownloadProgressBus.registerPauseController(jobId) { paused ->
            isPaused = paused
        }
    }

    fun togglePlayPause() {
        if (!TtsPlaybackManager.isPlaying.value) {
            checkBatteryOptimizationOnPlay()
        }
        TtsPlaybackManager.togglePlayPause()
    }

    fun startSpeaking() {
        checkBatteryOptimizationOnPlay()
        TtsPlaybackManager.startSpeaking()
    }

    fun pauseSpeaking() {
        TtsPlaybackManager.pauseSpeaking()
    }

    fun stopSpeaking() {
        TtsPlaybackManager.stopSpeaking()
    }

    fun skipForward() {
        TtsPlaybackManager.skipForward()
    }

    fun skipBackward() {
        TtsPlaybackManager.skipBackward()
    }

    fun setSpeechRateAndApply(rate: Float) {
        TtsPlaybackManager.setSpeechRateAndApply(rate)
    }

    fun setNextSentencePauseMs(ms: Float) {
        TtsPlaybackManager.nextSentencePauseMs.value = ms
    }

    fun setParagraphPauseMs(ms: Float) {
        TtsPlaybackManager.paragraphPauseMs.value = ms
    }

    fun setPunctuationPauseScale(scale: Float) {
        TtsPlaybackManager.punctuationPauseScale.value = scale
    }

    fun setAutoNextChapter(enabled: Boolean) {
        TtsPlaybackManager.autoNextChapter.value = enabled
    }
    
    fun selectVoiceAndApply(voice: Voice) {
        TtsPlaybackManager.selectVoiceAndApply(voice)
    }

    fun setSleepTimer(minutes: Int?) {
        TtsPlaybackManager.setSleepTimer(minutes)
    }

    fun clearErrorMessage() {
        TtsPlaybackManager.errorMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        // Playback continues safely completely decoupled from Activity!
    }
}
