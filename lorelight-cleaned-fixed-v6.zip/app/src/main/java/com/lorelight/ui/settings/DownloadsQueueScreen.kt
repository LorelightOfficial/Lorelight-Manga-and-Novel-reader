package com.lorelight.ui.settings

import android.text.format.DateUtils
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.data.download.DownloadItemState
import com.lorelight.data.download.DownloadJobState
import com.lorelight.data.download.DownloadProgressBus
import com.lorelight.data.download.DownloadStatus
import com.lorelight.ui.theme.GlassPanel
import com.lorelight.ui.theme.rememberGlassPalette
import kotlinx.coroutines.delay

/**
 * DOWNLOADS QUEUE - REBUILT LIVE.
 *
 * WHY IT USED TO FREEZE
 * ---------------------
 * Every derived list on this screen was computed inside `remember(queue) { ... }`.
 * `DownloadProgressBus.queue` is a snapshot state LIST whose IDENTITY never
 * changes - the bus mutates entries inside it. A remember key that never changes
 * means the calculation runs exactly once, so the screen kept serving the lists
 * it built the instant it opened. Recomposition did happen; the numbers it
 * re-rendered were the cached ones. That is the "open it and it is stuck"
 * behaviour, and it is why the counts never matched reality.
 *
 * WHAT IT DOES NOW
 * ----------------
 *  - Reads the queue during composition with no remember at all, so every
 *    recomposition re-derives the groups from the current truth.
 *  - Runs one 1-second ticker for the whole screen, but only while there is live
 *    work, so elapsed times, throughput and ETAs move on their own.
 *  - Shows per-job percentage, live rate and a real remaining-time estimate
 *    built from the job's own completion history.
 *  - Uses the app's glass surfaces instead of flat cards, and caps the expanded
 *    chapter breakdown to its own scroll area so a 200-page manga job cannot
 *    stretch the card off the screen.
 */
@Composable
fun DownloadsQueueScreen(
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    // LIVE READ. Reading the snapshot list here - and nowhere behind a stale
    // remember key - is what subscribes this screen to the bus.
    val jobs = DownloadProgressBus.queue.toList()
    var selectedFilter by remember { mutableStateOf("All") }

    val activeJobs = jobs.filter {
        it.downloadStatus == DownloadStatus.ACTIVE || it.downloadStatus == DownloadStatus.PAUSED
    }
    val queuedJobs = jobs.filter { it.downloadStatus == DownloadStatus.QUEUED }
    val failedJobs = jobs.filter {
        it.downloadStatus == DownloadStatus.FAILED || it.failedCount > 0
    }
    val completedJobs = jobs.filter {
        it.downloadStatus == DownloadStatus.DONE && it.failedCount == 0
    }
    val totalFailedCount = jobs.sumOf { it.failedCount } +
        jobs.count { it.downloadStatus == DownloadStatus.FAILED && it.items.isEmpty() }

    val hasLiveWork = activeJobs.isNotEmpty() || queuedJobs.isNotEmpty()

    // One ticker for the whole screen. Without it, every duration on the page
    // would only advance when the bus happened to publish something.
    var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(hasLiveWork) {
        nowMs = System.currentTimeMillis()
        while (hasLiveWork) {
            delay(1000L)
            nowMs = System.currentTimeMillis()
        }
    }

    val displayJobs = when (selectedFilter) {
        "Active" -> activeJobs
        "Queued" -> queuedJobs
        "Failed" -> failedJobs
        "Completed" -> completedJobs
        else -> jobs
    }.sortedWith(
        compareBy<DownloadJobState> { job ->
            when {
                job.downloadStatus == DownloadStatus.ACTIVE -> 0
                job.downloadStatus == DownloadStatus.PAUSED -> 1
                job.downloadStatus == DownloadStatus.QUEUED -> 2
                job.failedCount > 0 || job.downloadStatus == DownloadStatus.FAILED -> 3
                else -> 4
            }
        }.thenByDescending { it.startedAt }
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        QueueHeader(
            onBack = onBack,
            totalJobs = jobs.size,
            activeCount = activeJobs.size,
            failedCount = totalFailedCount,
            completedCount = completedJobs.size,
            live = hasLiveWork
        )

        if (jobs.isNotEmpty()) {
            QueueSummaryStrip(
                activeCount = activeJobs.size,
                queuedCount = queuedJobs.size,
                failedCount = totalFailedCount,
                completedCount = completedJobs.size,
                onRetryAll = { DownloadProgressBus.retryAllFailed() }
            )

            FilterChipRow(
                counts = listOf(
                    "All" to jobs.size,
                    "Active" to activeJobs.size,
                    "Queued" to queuedJobs.size,
                    "Failed" to failedJobs.size,
                    "Completed" to completedJobs.size
                ),
                selected = selectedFilter,
                onSelect = { selectedFilter = it }
            )
        }

        if (displayJobs.isEmpty()) {
            EmptyQueueState(
                queueEmpty = jobs.isEmpty(),
                filterLabel = selectedFilter,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            )
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(displayJobs, key = { it.id }) { job ->
                    DownloadJobCard(job = job, nowMs = nowMs)
                }
            }
        }
    }
}

@Composable
private fun QueueHeader(
    onBack: (() -> Unit)?,
    totalJobs: Int,
    activeCount: Int,
    failedCount: Int,
    completedCount: Int,
    live: Boolean
) {
    val glass = rememberGlassPalette(tintAlpha = 0.86f)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(glass.container)
            .border(1.dp, glass.borderTop, RoundedCornerShape(0.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                if (onBack != null) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("downloads_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Downloads",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (live) LivePulse()
                    }
                    Text(
                        text = when {
                            totalJobs == 0 -> "Nothing downloading"
                            activeCount > 0 -> "$activeCount running of $totalJobs job" +
                                (if (totalJobs == 1) "" else "s")
                            else -> "$totalJobs job" + (if (totalJobs == 1) "" else "s") + " in the list"
                        },
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                if (failedCount > 0) {
                    IconButton(
                        onClick = { DownloadProgressBus.retryAllFailed() },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("retry_all_failed_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Retry all failed",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                if (completedCount > 0) {
                    IconButton(
                        onClick = { DownloadProgressBus.clearCompleted() },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("clear_completed_downloads_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.DeleteSweep,
                            contentDescription = "Clear completed",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                if (activeCount > 0) {
                    IconButton(
                        onClick = { DownloadProgressBus.cancelAll() },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("cancel_all_downloads_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.StopCircle,
                            contentDescription = "Stop all",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

/** Small breathing dot: proof the page is watching rather than frozen. */
@Composable
private fun LivePulse() {
    val transition = rememberInfiniteTransition(label = "livePulse")
    val alpha by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "livePulseAlpha"
    )
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = alpha))
        )
        Text(
            text = "LIVE",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp,
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.9f)
        )
    }
}

@Composable
private fun QueueSummaryStrip(
    activeCount: Int,
    queuedCount: Int,
    failedCount: Int,
    completedCount: Int,
    onRetryAll: () -> Unit
) {
    GlassPanel(
        shape = RoundedCornerShape(14.dp),
        tintAlpha = 0.78f,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                StatDot("Active", activeCount, MaterialTheme.colorScheme.primary)
                StatDot("Queued", queuedCount, MaterialTheme.colorScheme.outline)
                if (failedCount > 0) {
                    StatDot("Failed", failedCount, MaterialTheme.colorScheme.error)
                }
                StatDot("Done", completedCount, Color(0xFF2E7D32))
            }
            if (failedCount > 0) {
                TextButton(
                    onClick = onRetryAll,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "Retry", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun StatDot(label: String, count: Int, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = "$count $label",
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun FilterChipRow(
    counts: List<Pair<String, Int>>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        counts.forEach { (label, count) ->
            val isSelected = selected == label
            val badgeColor = when (label) {
                "Failed" -> MaterialTheme.colorScheme.error
                "Active" -> MaterialTheme.colorScheme.primary
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            }
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        if (isSelected) {
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)
                        } else {
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                        }
                    )
                    .border(
                        1.dp,
                        if (isSelected) {
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
                        } else {
                            MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                        },
                        RoundedCornerShape(20.dp)
                    )
                    .clickable { onSelect(label) }
                    .testTag("filter_chip_$label")
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = label,
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSelected) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.onSurfaceVariant
                    }
                )
                if (count > 0) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(badgeColor.copy(alpha = if (isSelected) 0.9f else 0.15f))
                            .padding(horizontal = 5.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "$count",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else badgeColor
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyQueueState(
    queueEmpty: Boolean,
    filterLabel: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.CloudDownload,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                    modifier = Modifier.size(28.dp)
                )
            }
            Text(
                text = if (queueEmpty) "Nothing in the queue" else "No $filterLabel downloads",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Chapters and manga pages you download show up here while they run, and stay for a moment after they finish.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 16.sp,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
        }
    }
}

@Composable
private fun DownloadJobCard(job: DownloadJobState, nowMs: Long) {
    var isExpanded by remember(job.id) { mutableStateOf(false) }
    val rotation by animateFloatAsState(
        targetValue = if (isExpanded) 180f else 0f,
        label = "chevron"
    )

    val isFailing = job.failedCount > 0 || job.downloadStatus == DownloadStatus.FAILED
    val accent = when {
        isFailing -> MaterialTheme.colorScheme.error
        job.downloadStatus == DownloadStatus.DONE -> Color(0xFF2E7D32)
        job.downloadStatus == DownloadStatus.PAUSED -> MaterialTheme.colorScheme.outline
        else -> MaterialTheme.colorScheme.primary
    }

    val fraction = job.fraction.coerceIn(0f, 1f)
    val animatedFraction by animateFloatAsState(targetValue = fraction, label = "jobProgress")
    val percent = (fraction * 100f).toInt()

    // Live timing, all of it derived from the ticker rather than from whenever
    // the bus last published.
    val elapsedMs = (
        if (job.isFinished && job.finishedAt > 0L) job.finishedAt - job.startedAt
        else nowMs - job.startedAt
        ).coerceAtLeast(0L)
    val elapsedText = DateUtils.formatElapsedTime(elapsedMs / 1000L)
    val doneNow = job.completedCount
    val remaining = (job.totalCount - doneNow).coerceAtLeast(0)
    val etaText = if (job.active && doneNow > 0 && remaining > 0 && elapsedMs > 3_000L) {
        val perItemMs = elapsedMs / doneNow
        "~" + DateUtils.formatElapsedTime((perItemMs * remaining) / 1000L) + " left"
    } else {
        null
    }

    GlassPanel(
        shape = RoundedCornerShape(14.dp),
        tintAlpha = 0.80f,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("download_job_card_${job.id}")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded }
                    .padding(start = 12.dp, end = 4.dp, top = 12.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val isManga = job.kind.equals("Manga", ignoreCase = true)
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(accent.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isManga) Icons.Default.MenuBook else Icons.Default.Book,
                        contentDescription = job.kind,
                        tint = accent,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = job.title,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(3.dp))

                    val summary = buildString {
                        if (job.items.isNotEmpty()) {
                            append("$doneNow of ${job.totalCount}")
                            if (job.failedCount > 0) append(" • ${job.failedCount} failed")
                            if (job.activeCount > 0) append(" • ${job.activeCount} running")
                            if (job.pendingCount > 0 && job.active) append(" • ${job.pendingCount} waiting")
                        } else {
                            append(job.status)
                        }
                    }
                    Text(
                        text = summary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (isFailing) MaterialTheme.colorScheme.error else accent,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Text(
                        text = buildString {
                            append(job.kind.uppercase())
                            append(" • ")
                            append(
                                when {
                                    job.downloadStatus == DownloadStatus.PAUSED -> "Paused"
                                    job.downloadStatus == DownloadStatus.QUEUED -> "Waiting"
                                    job.isFinished -> "Finished in $elapsedText"
                                    else -> "Running $elapsedText"
                                }
                            )
                            if (etaText != null) {
                                append(" • ")
                                append(etaText)
                            }
                        },
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Text(
                    text = "$percent%",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = accent
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(0.dp)
                ) {
                    if (job.active || job.downloadStatus == DownloadStatus.PAUSED) {
                        IconButton(
                            onClick = { DownloadProgressBus.togglePause(job.id) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = if (job.downloadStatus == DownloadStatus.PAUSED) {
                                    Icons.Default.PlayArrow
                                } else {
                                    Icons.Default.Pause
                                },
                                contentDescription = if (job.downloadStatus == DownloadStatus.PAUSED) "Resume" else "Pause",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    if (isFailing) {
                        IconButton(
                            onClick = { DownloadProgressBus.retryFailedItems(job.id) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Retry failed",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    if (job.active ||
                        job.downloadStatus == DownloadStatus.QUEUED ||
                        job.downloadStatus == DownloadStatus.PAUSED
                    ) {
                        IconButton(
                            onClick = { DownloadProgressBus.cancel(job.id) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Cancel,
                                contentDescription = "Cancel",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    } else if (job.isFinished) {
                        IconButton(
                            onClick = { DownloadProgressBus.remove(job.id) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Remove",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    IconButton(
                        onClick = { isExpanded = !isExpanded },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ExpandMore,
                            contentDescription = if (isExpanded) "Collapse" else "Expand",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .size(20.dp)
                                .rotate(rotation)
                        )
                    }
                }
            }

            LinearProgressIndicator(
                progress = { animatedFraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp),
                color = accent,
                trackColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
            )

            AnimatedVisibility(
                visible = isExpanded,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.45f))
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "BREAKDOWN (${job.items.size})",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = accent,
                            letterSpacing = 0.5.sp
                        )
                        if (job.failedCount > 0) {
                            TextButton(
                                onClick = { DownloadProgressBus.retryFailedItems(job.id) },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Retry ${job.failedCount}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }

                    if (job.items.isEmpty()) {
                        Text(
                            text = job.status.ifBlank { "No per-chapter detail reported for this job." },
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    } else {
                        // Failures and running items first: with 200 pages in a
                        // job, what went wrong should never be buried.
                        val ordered = job.items.sortedBy { item ->
                            when (item.status) {
                                DownloadStatus.FAILED -> 0
                                DownloadStatus.ACTIVE -> 1
                                DownloadStatus.PAUSED -> 2
                                DownloadStatus.QUEUED -> 3
                                else -> 4
                            }
                        }
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 300.dp)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            ordered.forEach { item ->
                                DownloadItemRow(jobId = job.id, item = item)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DownloadItemRow(jobId: String, item: DownloadItemState) {
    val tint = when (item.status) {
        DownloadStatus.DONE -> Color(0xFF2E7D32)
        DownloadStatus.FAILED -> MaterialTheme.colorScheme.error
        DownloadStatus.ACTIVE -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(tint.copy(alpha = 0.08f))
            .border(0.5.dp, tint.copy(alpha = 0.22f), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = when (item.status) {
                DownloadStatus.DONE -> Icons.Default.CheckCircle
                DownloadStatus.FAILED -> Icons.Default.Error
                DownloadStatus.ACTIVE -> Icons.Default.Downloading
                DownloadStatus.PAUSED -> Icons.Default.PauseCircle
                DownloadStatus.CANCELLED -> Icons.Default.Cancel
                else -> Icons.Outlined.HourglassEmpty
            },
            contentDescription = item.status.name,
            tint = tint,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.name,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            val detail = when {
                !item.errorMessage.isNullOrBlank() -> item.errorMessage
                item.status == DownloadStatus.ACTIVE && item.total > 0L ->
                    "${item.current} / ${item.total}"
                item.status == DownloadStatus.ACTIVE -> "Downloading"
                else -> null
            }
            if (detail != null) {
                Text(
                    text = detail,
                    fontSize = 10.sp,
                    color = if (item.errorMessage.isNullOrBlank()) tint else MaterialTheme.colorScheme.error,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (item.status == DownloadStatus.ACTIVE && item.total > 0L) {
            Text(
                text = "${(item.fraction * 100f).toInt()}%",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = tint
            )
            Spacer(modifier = Modifier.width(4.dp))
        }
        if (item.status == DownloadStatus.FAILED || item.status == DownloadStatus.CANCELLED) {
            IconButton(
                onClick = { DownloadProgressBus.retryItem(jobId, item.id) },
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Retry chapter",
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
        if (item.status == DownloadStatus.ACTIVE || item.status == DownloadStatus.QUEUED) {
            IconButton(
                onClick = { DownloadProgressBus.cancelItem(jobId, item.id) },
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Cancel chapter",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}
