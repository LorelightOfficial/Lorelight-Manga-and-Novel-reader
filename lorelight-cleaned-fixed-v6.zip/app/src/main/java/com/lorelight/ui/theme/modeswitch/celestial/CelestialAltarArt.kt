package com.lorelight.ui.theme.modeswitch.celestial

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.lerp
import kotlin.math.floor
import kotlin.math.sin

/*
 * ─────────────────────────────────────────────────────────────────────────
 *  THE SUNKEN DAIS — a celestial altar for the Lorelight navigation bar
 * ─────────────────────────────────────────────────────────────────────────
 *
 *  Design: a fragment of a forgotten temple, wedged into the gap between
 *  the two glass panels as if the bar itself had been built around it.
 *
 *    · A wide, weathered FOUNDATION SLAB spans the whole gap and slides
 *      beneath both glass panes, so the altar is physically seated in the
 *      bar rather than floating over it. Its crest rises gently under the
 *      dais and dips at the ends where it tucks under the panels.
 *
 *    · Two LEANING MONOLITH WINGS — angular, faceted, slightly canted
 *      toward the center — rise where the altar meets each pane. Their
 *      outer faces catch the same top-weighted rim light as the glass.
 *
 *    · A two-tiered ZIGGURAT DAIS climbs to a shallow OFFERING BASIN.
 *      The basin holds only light: a soft pool that breathes faintly
 *      while asleep and floods with radiance as openAmount rises. The
 *      celestial body itself is NEVER drawn here — the 56dp toggle puck
 *      composable supplies it, seated over the basin.
 *
 *    · A GLYPH BAND is carved across the lower tier and each wing.
 *      Asleep, the glyphs are barely-raised stone; awake, they ignite
 *      one shade at a time with a slow shimmer.
 *
 *    · When the altar opens, two curved LIGHT SHAFTS lean out of the
 *      basin and a handful of EMBERS drift upward. All motion is slow
 *      and low-amplitude — this lives under a reader's thumb.
 *
 *  Everything is procedural, scaled from the supplied size, and colored
 *  from two fixed palettes (warm sun-stone / cool moon-stone) so it sits
 *  correctly on every app theme's glass.
 * ─────────────────────────────────────────────────────────────────────────
 */

// ── Palettes ──────────────────────────────────────────────────────────────

private class AltarPalette(
    val stoneDeep: Color,   // shadowed stone, bottoms and crevices
    val stoneMid: Color,    // body of the stone
    val stoneLit: Color,    // upward faces catching ambient light
    val rim: Color,         // hairline edge light, matches the glass rims
    val glow: Color,        // awakened light, mid tone
    val glowHot: Color,     // awakened light, core
    val ember: Color        // drifting motes
)

private val DayPalette = AltarPalette(
    stoneDeep = Color(0xFF6A583E),
    stoneMid = Color(0xFF8B775A),
    stoneLit = Color(0xFFC9B287),
    rim = Color(0xFFF6EBCE),
    glow = Color(0xFFF0B95C),
    glowHot = Color(0xFFFFEDC4),
    ember = Color(0xFFFFDf9E)
)

private val NightPalette = AltarPalette(
    stoneDeep = Color(0xFF181F29),
    stoneMid = Color(0xFF29323F),
    stoneLit = Color(0xFF4A5A6E),
    rim = Color(0xFFA9BED8),
    glow = Color(0xFF8FB6E8),
    glowHot = Color(0xFFDCEBFF),
    ember = Color(0xFFC2DCFB)
)

private fun paletteFor(isLight: Boolean) = if (isLight) DayPalette else NightPalette

private fun frac(x: Float): Float = x - floor(x)

// ── Public API ────────────────────────────────────────────────────────────

/**
 * The celestial altar. Draws only stone, light, and atmosphere — the
 * sun/moon puck is a separate composable layered on top by the caller.
 */
@Composable
fun CelestialAltarArt(
    isLight: Boolean,
    modifier: Modifier = Modifier,
    openAmount: Float = 0f
) {
    // A calm, monotonically increasing clock for the pure draw function.
    val timeSec by produceState(0f) {
        var start = -1L
        while (true) {
            withFrameNanos { now ->
                if (start < 0L) start = now
                value = (now - start) / 1_000_000_000f
            }
        }
    }

    Canvas(modifier = modifier) {
        drawCelestialAltar(
            size = size,
            isLight = isLight,
            openAmount = openAmount.coerceIn(0f, 1f),
            timeSec = timeSec
        )
    }
}

/**
 * The ambient dent/glow inside the glass bar behind the altar: a soft
 * depression in the pane, as if the glass had been poured around the stone.
 */
@Composable
fun CelestialAltarWell(
    isLight: Boolean,
    modifier: Modifier = Modifier
) {
    val p = paletteFor(isLight)
    val dentAlpha = if (isLight) 0.07f else 0.20f
    val breathAlpha = if (isLight) 0.06f else 0.05f

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f) return@Canvas
        val center = Offset(w * 0.5f, h * 0.58f)

        // The dent: darkest at its heart, feathering to nothing. Squashed
        // into the pane so it reads as depth, not decoration.
        scale(1f, (h * 0.72f) / w.coerceAtLeast(1f), pivot = center) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.Black.copy(alpha = dentAlpha),
                        Color.Black.copy(alpha = dentAlpha * 0.45f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = w * 0.5f
                ),
                radius = w * 0.5f,
                center = center
            )
        }

        // A faint standing warmth deep in the dent — the altar's presence
        // seeping into the glass even while asleep.
        scale(1f, (h * 0.42f) / w.coerceAtLeast(1f), pivot = center) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        p.glow.copy(alpha = breathAlpha),
                        Color.Transparent
                    ),
                    center = center,
                    radius = w * 0.30f
                ),
                radius = w * 0.30f,
                center = center
            )
        }
    }
}

/**
 * Pure drawing of the altar. All geometry derives from [size]; all
 * awakening derives from [openAmount]; all idle life derives from [timeSec].
 */
fun DrawScope.drawCelestialAltar(
    size: Size,
    isLight: Boolean,
    openAmount: Float,
    timeSec: Float
) {
    val w = size.width
    val h = size.height
    if (w <= 0f || h <= 0f) return

    val p = paletteFor(isLight)
    val open = openAmount.coerceIn(0f, 1f)
    val cx = w * 0.5f

    // The slow breath of the sleeping altar: ±4% over ~8 seconds.
    val breath = 0.5f + 0.5f * sin(timeSec * 0.78f)

    // Key vertical stations (fractions of the 64dp-ish box height).
    val basinY = h * 0.475f          // where the puck seats
    val tierTopY = h * 0.485f
    val tierBottomY = h * 0.635f
    val plinthTopY = h * 0.635f
    val plinthBottomY = h * 0.80f
    val baseCrestY = h * 0.70f       // foundation crest under the dais
    val baseEndY = h * 0.82f         // where the slab dips under the panes

    // ── 1. Standing atmosphere ───────────────────────────────────────────
    // A very soft veil of light behind the whole altar. Large, dim, and
    // vertically squashed so it never reads as a body — only as air.
    run {
        val auraAlpha = (0.05f + 0.16f * open) * (0.94f + 0.06f * breath)
        val auraCenter = Offset(cx, h * 0.50f)
        scale(1f, 0.62f, pivot = auraCenter) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(p.glow.copy(alpha = auraAlpha), Color.Transparent),
                    center = auraCenter,
                    radius = w * 0.46f
                ),
                radius = w * 0.46f,
                center = auraCenter
            )
        }
    }

    // ── 2. Foundation slab ───────────────────────────────────────────────
    // Spans past both edges so its ends slide beneath the glass panels.
    // The top edge is one continuous curve: dipping at the ends, cresting
    // gently beneath the dais. No straight shadow lines anywhere.
    val slabLeft = -w * 0.06f
    val slabRight = w * 1.06f
    run {
        val slab = Path().apply {
            moveTo(slabLeft, baseEndY)
            quadraticBezierTo(cx, baseCrestY - h * 0.06f, slabRight, baseEndY)
            lineTo(slabRight, h)
            lineTo(slabLeft, h)
            close()
        }
        drawPath(
            path = slab,
            brush = Brush.verticalGradient(
                colors = listOf(p.stoneMid, p.stoneDeep),
                startY = baseCrestY,
                endY = h
            )
        )

        // Crest light: a thin filled band hugging the top curve, echoing
        // the glass panels' top-weighted rim light so the materials agree.
        val crestBand = Path().apply {
            moveTo(slabLeft, baseEndY)
            quadraticBezierTo(cx, baseCrestY - h * 0.06f, slabRight, baseEndY)
            lineTo(slabRight, baseEndY + h * 0.055f)
            quadraticBezierTo(cx, baseCrestY, slabLeft, baseEndY + h * 0.055f)
            close()
        }
        val crestAlpha = (if (isLight) 0.34f else 0.14f) + 0.20f * open
        drawPath(
            path = crestBand,
            brush = Brush.verticalGradient(
                colors = listOf(p.rim.copy(alpha = crestAlpha), Color.Transparent),
                startY = baseCrestY - h * 0.06f,
                endY = baseEndY + h * 0.06f
            )
        )

        // Grounding: the slab's own mass darkening toward the screen edge.
        drawPath(
            path = slab,
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.12f)),
                startY = h * 0.88f,
                endY = h
            )
        )
    }

    // ── 3. Monolith wings ────────────────────────────────────────────────
    // Two angular, faceted standing stones leaning toward the dais, their
    // outer heels buried under the glass panes. Each wing is two facets:
    // a lit inner face and a shaded outer face — no rounded boulders.
    drawWing(p, w, h, open, isLight, mirrored = false)
    drawWing(p, w, h, open, isLight, mirrored = true)

    // ── 4. Ziggurat dais ─────────────────────────────────────────────────
    // Two tapering tiers. Each tier: body gradient + a flat top face
    // that brightens as the altar wakes, as if light were pooling on it.
    drawTier(p, cx, w * 0.255f, w * 0.225f, plinthBottomY, plinthTopY, open, isLight)
    drawTier(p, cx, w * 0.175f, w * 0.150f, tierBottomY, tierTopY, open, isLight)

    // Soft seat shadow where the dais meets the foundation — an elliptical
    // pool of shade, never a straight line.
    run {
        val seat = Offset(cx, plinthBottomY + h * 0.015f)
        scale(1f, 0.22f, pivot = seat) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.Black.copy(alpha = 0.16f), Color.Transparent),
                    center = seat,
                    radius = w * 0.30f
                ),
                radius = w * 0.30f,
                center = seat
            )
        }
    }

    // ── 5. Offering basin ────────────────────────────────────────────────
    // A shallow carved hollow on the altar table. Rendered entirely with
    // soft filled gradients — no stroked rim that could read as a drawn
    // arc beneath the puck.
    run {
        val basinCenter = Offset(cx, basinY)
        val basinR = w * 0.105f
        val squash = 0.42f

        // The hollow itself: darker toward its heart.
        scale(1f, squash, pivot = basinCenter) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        p.stoneDeep.copy(alpha = 0.85f),
                        p.stoneMid.copy(alpha = 0.35f),
                        Color.Transparent
                    ),
                    center = basinCenter,
                    radius = basinR
                ),
                radius = basinR,
                center = basinCenter
            )
        }

        // The pooled light: a faint sleeping warmth that floods when open.
        val poolAlpha = (0.10f + 0.80f * open) * (0.92f + 0.08f * breath)
        val poolR = basinR * (0.75f + 0.55f * open)
        scale(1f, squash, pivot = basinCenter) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        p.glowHot.copy(alpha = poolAlpha),
                        p.glow.copy(alpha = poolAlpha * 0.55f),
                        Color.Transparent
                    ),
                    center = basinCenter,
                    radius = poolR
                ),
                radius = poolR,
                center = basinCenter
            )
        }
    }

    // ── 6. Carved glyphs ─────────────────────────────────────────────────
    // A band of god-marks across the lowest tier, one on each wing.
    // Asleep they are chiselled stone a shade lighter than their face;
    // awake they ignite and shimmer very slowly, each on its own phase.
    run {
        val glyphY = (plinthTopY + plinthBottomY) * 0.5f
        val glyphXs = floatArrayOf(0.335f, 0.415f, 0.50f, 0.585f, 0.665f)
        for (i in glyphXs.indices) {
            val shimmer = 0.80f + 0.20f * sin(timeSec * 0.55f + i * 1.9f)
            drawGlyph(
                p = p,
                index = i,
                center = Offset(w * glyphXs[i], glyphY),
                unit = w * 0.018f,
                open = open,
                shimmer = shimmer,
                isLight = isLight
            )
        }
        // Wing glyphs — larger, older marks.
        val wingShimmerL = 0.80f + 0.20f * sin(timeSec * 0.47f + 4.2f)
        val wingShimmerR = 0.80f + 0.20f * sin(timeSec * 0.47f + 7.6f)
        drawGlyph(p, 5, Offset(w * 0.125f, h * 0.585f), w * 0.020f, open, wingShimmerL, isLight)
        drawGlyph(p, 6, Offset(w * 0.875f, h * 0.585f), w * 0.020f, open, wingShimmerR, isLight)
    }

    // ── 7. Light shafts ──────────────────────────────────────────────────
    // Two curved veils of light leaning out of the basin during the
    // awakening. Curved closed paths with vertical gradient fills — the
    // edges feather to nothing, so there are no hard rectangles of light.
    if (open > 0.04f) {
        val sway = sin(timeSec * 0.42f) * w * 0.010f
        drawLightShaft(p, cx, basinY, w, h, open, lean = -1f, sway = sway)
        drawLightShaft(p, cx, basinY, w, h, open, lean = 1f, sway = -sway)
    }

    // ── 8. Embers ────────────────────────────────────────────────────────
    // A handful of motes rising slowly out of the basin while the altar is
    // open. Deterministic per-index, gentle sway, small and dim — they are
    // sparks off the light, not fireworks.
    if (open > 0.06f) {
        val emberCount = 6
        for (i in 0 until emberCount) {
            val seed = frac(i * 0.6180339f + 0.137f)
            val speed = 0.050f + 0.028f * frac(seed * 7.13f)
            val phase = frac(timeSec * speed + seed)
            val riseY = basinY - phase * h * 0.34f
            val spread = (frac(seed * 13.7f) - 0.5f) * w * 0.14f
            val swayX = sin(timeSec * 0.55f + i * 1.71f) * w * 0.012f * phase
            val x = cx + spread + swayX
            // Fade in quickly at birth, out slowly toward the top.
            val life = (phase * 5f).coerceAtMost(1f) * (1f - phase)
            val a = open * life * 0.75f
            if (a > 0.01f) {
                val r = w * (0.006f + 0.005f * frac(seed * 29.3f)) * (1f - 0.35f * phase)
                // Halo first, core second.
                drawCircle(
                    color = p.glow.copy(alpha = a * 0.35f),
                    radius = r * 2.6f,
                    center = Offset(x, riseY)
                )
                drawCircle(
                    color = p.ember.copy(alpha = a),
                    radius = r,
                    center = Offset(x, riseY)
                )
            }
        }
    }
}

// ── Private construction ──────────────────────────────────────────────────

/**
 * One leaning monolith wing. Built from two facets so it reads as a
 * carved, angular standing stone: a lit inner face turned toward the
 * dais and a shaded outer face turned toward the glass pane it abuts.
 */
private fun DrawScope.drawWing(
    p: AltarPalette,
    w: Float,
    h: Float,
    open: Float,
    isLight: Boolean,
    mirrored: Boolean
) {
    // All x-coordinates authored for the LEFT wing, mirrored for the right.
    fun x(f: Float): Float = if (mirrored) w - f * w else f * w

    val heelOuterX = x(-0.045f)          // buried under the pane
    val heelInnerX = x(0.235f)
    val heelY = h * 0.94f
    val tipOuterX = x(0.075f)
    val tipInnerX = x(0.165f)
    val tipY = h * 0.315f
    val ridgeX = x(0.115f)               // the front ridge between facets
    val ridgeY = h * 0.345f

    // Outer (shaded) facet.
    val outer = Path().apply {
        moveTo(heelOuterX, heelY)
        lineTo(tipOuterX, tipY + h * 0.045f)
        lineTo(ridgeX, ridgeY)
        lineTo(x(0.105f), heelY)
        close()
    }
    drawPath(
        path = outer,
        brush = Brush.verticalGradient(
            colors = listOf(p.stoneMid, p.stoneDeep),
            startY = tipY,
            endY = heelY
        )
    )

    // Inner (lit) facet — leans toward the basin and takes the awakened
    // light: its tint shifts toward the glow color as the altar opens.
    val litColor = lerp(p.stoneLit, p.glow, 0.22f * open)
    val inner = Path().apply {
        moveTo(x(0.105f), heelY)
        lineTo(ridgeX, ridgeY)
        lineTo(tipInnerX, tipY)
        lineTo(heelInnerX, heelY)
        close()
    }
    drawPath(
        path = inner,
        brush = Brush.verticalGradient(
            colors = listOf(litColor, p.stoneMid),
            startY = tipY,
            endY = heelY
        )
    )

    // Crown bevel: a small bright facet at the very tip, catching the
    // rim light exactly the way the glass panels' top edges do.
    val crownAlpha = (if (isLight) 0.42f else 0.20f) + 0.25f * open
    val crown = Path().apply {
        moveTo(tipOuterX, tipY + h * 0.045f)
        lineTo(tipInnerX, tipY)
        lineTo(x(0.150f), tipY + h * 0.085f)
        lineTo(x(0.098f), tipY + h * 0.105f)
        close()
    }
    drawPath(path = crown, color = p.rim.copy(alpha = crownAlpha))
}

/**
 * One tier of the ziggurat: a tapering block plus a flat top face that
 * pools with light as the altar wakes.
 */
private fun DrawScope.drawTier(
    p: AltarPalette,
    cx: Float,
    halfBottom: Float,
    halfTop: Float,
    bottomY: Float,
    topY: Float,
    open: Float,
    isLight: Boolean
) {
    val body = Path().apply {
        moveTo(cx - halfBottom, bottomY)
        lineTo(cx - halfTop, topY)
        lineTo(cx + halfTop, topY)
        lineTo(cx + halfBottom, bottomY)
        close()
    }
    drawPath(
        path = body,
        brush = Brush.verticalGradient(
            colors = listOf(
                lerp(p.stoneLit, p.glow, 0.15f * open),
                p.stoneMid,
                p.stoneDeep
            ),
            startY = topY,
            endY = bottomY
        )
    )

    // The top face: a slim flat highlight strip along the tier's upper
    // edge, thicker in the middle and vanishing at the corners — reads as
    // a horizontal stone surface catching the sky (or the awakened glow).
    val faceAlpha = (if (isLight) 0.30f else 0.13f) + 0.30f * open
    val faceH = (bottomY - topY) * 0.16f
    val face = Path().apply {
        moveTo(cx - halfTop, topY)
        lineTo(cx + halfTop, topY)
        quadraticBezierTo(cx, topY + faceH * 1.8f, cx - halfTop, topY)
        close()
    }
    drawPath(
        path = face,
        color = lerp(p.rim, p.glowHot, 0.5f * open).copy(alpha = faceAlpha)
    )
}

/**
 * The rune aurora: mint, ice, violet, rose, gold -- a looping ramp rather
 * than a list, so the last colour walks back into the first with no seam.
 */
private val AURORA_RAMP = listOf(
    Color(0xFF5EEAD4),
    Color(0xFF38BDF8),
    Color(0xFFA78BFA),
    Color(0xFFF472B6),
    Color(0xFFFCD34D)
)

/**
 * One rune's place on that ramp.
 *
 * [index] spreads the band out so no two neighbouring runes share a hue, and
 * [shimmer] and [open] walk each rune along the ramp so the colours drift the
 * way an aurora does instead of sitting still.
 */
private fun auroraInk(index: Int, shimmer: Float, open: Float): Color {
    val span = AURORA_RAMP.size
    var pos = (index * 0.41f + shimmer * 0.70f + open * 0.30f) % 1f
    if (pos < 0f) pos += 1f
    val scaled = pos * span
    val i0 = scaled.toInt() % span
    val i1 = (i0 + 1) % span
    return lerp(AURORA_RAMP[i0], AURORA_RAMP[i1], scaled - scaled.toInt())
}

/**
 * A single carved god-mark. Seven distinct forms, all built from short
 * round-capped strokes so they read as chisel work rather than typography.
 */
private fun DrawScope.drawGlyph(
    p: AltarPalette,
    index: Int,
    center: Offset,
    unit: Float,
    open: Float,
    shimmer: Float,
    isLight: Boolean
) {
    // These marks used to vanish: dark mode drew them at 0.22 alpha in a pale
    // stone tone with almost no contrast against the stone face, and light mode
    // at 0.62 was merely faint. They are now properly legible at rest in BOTH
    // modes, and are cut as real chisel work: a dark depth stroke offset down
    // and right, with the lit mark riding on top of it.
    val sleepAlpha = if (isLight) 0.90f else 0.78f
    val a = (sleepAlpha + (1f - sleepAlpha) * open) * shimmer
    // Light mode: a deep near-black incision in the pale stone.
    // Dark mode: a warm ember-tinted mark, so it catches light instead of
    // sinking into the dark stone the way the old stoneLit tone did.
    val carved = if (isLight) {
        lerp(p.stoneDeep, Color.Black, 0.55f)
    } else {
        lerp(p.stoneLit, p.glow, 0.55f)
    }
    // Multicoloured aurora rather than a single warm ember: each rune takes
    // its own hue, and lights further into it as the altar opens.
    val aurora = auroraInk(index, shimmer, open)
    val color = lerp(lerp(carved, aurora, 0.80f), aurora, open).copy(alpha = a)
    // The shadow inside the groove. In light mode it sits under the mark as
    // depth; in dark mode it is the dark rim that makes the warm mark pop.
    val depth = (if (isLight) Color.White else Color.Black)
        .copy(alpha = a * (if (isLight) 0.45f else 0.55f))
    val sw = (unit * 0.46f).coerceAtLeast(1.2f)
    val dOff = sw * 0.34f

    fun stroke(x1: Float, y1: Float, x2: Float, y2: Float) {
        // groove shadow first, offset so the mark reads as cut INTO the stone
        drawLine(
            color = depth,
            start = Offset(center.x + x1 * unit + dOff, center.y + y1 * unit + dOff),
            end = Offset(center.x + x2 * unit + dOff, center.y + y2 * unit + dOff),
            strokeWidth = sw,
            cap = StrokeCap.Round
        )
        drawLine(
            color = color,
            start = Offset(center.x + x1 * unit, center.y + y1 * unit),
            end = Offset(center.x + x2 * unit, center.y + y2 * unit),
            strokeWidth = sw,
            cap = StrokeCap.Round
        )
    }

    // Seeds get the same chisel treatment as the strokes.
    fun dot(dx: Float, dy: Float) {
        drawCircle(
            color = depth,
            radius = sw * 0.9f,
            center = Offset(center.x + dx * unit + dOff, center.y + dy * unit + dOff)
        )
        drawCircle(
            color = color,
            radius = sw * 0.9f,
            center = Offset(center.x + dx * unit, center.y + dy * unit)
        )
    }

    when (index % 7) {
        0 -> { // the pillar: a bar with a crossing tick
            stroke(0f, -1.1f, 0f, 1.1f)
            stroke(-0.7f, -0.2f, 0.7f, -0.2f)
        }
        1 -> { // the mountain: a chevron
            stroke(-0.9f, 0.8f, 0f, -0.9f)
            stroke(0f, -0.9f, 0.9f, 0.8f)
        }
        2 -> { // the river: two stacked bars
            stroke(-0.8f, -0.45f, 0.8f, -0.45f)
            stroke(-0.8f, 0.45f, 0.8f, 0.45f)
        }
        3 -> { // the gate: two pillars and a lintel
            stroke(-0.7f, 1f, -0.7f, -0.7f)
            stroke(0.7f, 1f, 0.7f, -0.7f)
            stroke(-0.9f, -0.85f, 0.9f, -0.85f)
        }
        4 -> { // the sower: a slash with a seed
            stroke(-0.8f, 0.9f, 0.8f, -0.9f)
            dot(-0.55f, -0.75f)
        }
        5 -> { // the watcher (wings): a tall mark with side ticks
            stroke(0f, -1.3f, 0f, 1.3f)
            stroke(-0.8f, -0.6f, 0f, -0.1f)
            stroke(0.8f, -0.6f, 0f, -0.1f)
        }
        else -> { // the offering: a shallow vee holding a seed
            stroke(-0.9f, -0.5f, 0f, 0.6f)
            stroke(0f, 0.6f, 0.9f, -0.5f)
            dot(0f, -0.5f)
        }
    }
}

/**
 * One curved veil of light leaning out of the basin. A closed path with
 * bowed sides and a vertical gradient that feathers to transparent well
 * before its geometric edge — no hard-edged light.
 */
private fun DrawScope.drawLightShaft(
    p: AltarPalette,
    cx: Float,
    basinY: Float,
    w: Float,
    h: Float,
    open: Float,
    lean: Float,
    sway: Float
) {
    val rootHalf = w * 0.036f
    val rootX = cx + lean * w * 0.045f
    val tipX = cx + lean * w * 0.115f + sway
    val tipY = basinY - h * 0.34f * open
    val tipHalf = w * 0.010f

    val shaft = Path().apply {
        moveTo(rootX - rootHalf, basinY)
        quadraticBezierTo(
            rootX - rootHalf + lean * w * 0.010f, (basinY + tipY) * 0.5f,
            tipX - tipHalf, tipY
        )
        lineTo(tipX + tipHalf, tipY)
        quadraticBezierTo(
            rootX + rootHalf + lean * w * 0.030f, (basinY + tipY) * 0.5f,
            rootX + rootHalf, basinY
        )
        close()
    }
    val a = 0.20f * open
    drawPath(
        path = shaft,
        brush = Brush.verticalGradient(
            colorStops = arrayOf(
                0.0f to Color.Transparent,
                0.35f to p.glow.copy(alpha = a * 0.45f),
                0.85f to p.glowHot.copy(alpha = a),
                1.0f to p.glowHot.copy(alpha = a * 0.7f)
            ),
            startY = tipY,
            endY = basinY
        )
    )
}
