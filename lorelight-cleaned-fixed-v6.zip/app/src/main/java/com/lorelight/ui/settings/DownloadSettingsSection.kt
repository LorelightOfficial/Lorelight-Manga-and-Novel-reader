package com.lorelight.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.data.download.DownloadTuning
import com.lorelight.manga.download.MangaOcrCache

/**
 * FEATURE: "Download tuning" - the secondary controls for HOW download work is
 * performed, as opposed to the download queue, which only reports what it did.
 *
 * These knobs map one-to-one onto what the two engines consume from
 * DownloadTuning.snapshot(). Novels and manga are split deliberately, because
 * the shape of the work genuinely differs: a novel chapter is ONE request, so
 * width comes from fetching several chapters at once; a manga chapter is 20-200
 * image requests, so width comes from fetching several pages of the same
 * chapter at once.
 */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun DownloadSettingsSection() {
    val context = LocalContext.current

    var preset by remember { mutableStateOf(DownloadTuning.getPreset(context)) }
    var parallelChapters by remember { mutableStateOf(DownloadTuning.getParallelChapters(context)) }
    var parallelPages by remember { mutableStateOf(DownloadTuning.getParallelPages(context)) }
    var chapterDelay by remember { mutableStateOf(DownloadTuning.getChapterDelayMs(context)) }
    var pageDelay by remember { mutableStateOf(DownloadTuning.getPageDelayMs(context)) }
    var retries by remember { mutableStateOf(DownloadTuning.getRetryAttempts(context)) }
    var speedKbps by remember { mutableStateOf(DownloadTuning.getSpeedLimitKbps(context)) }
    var wifiOnly by remember { mutableStateOf(DownloadTuning.isWifiOnly(context)) }
    var verifyPass by remember { mutableStateOf(DownloadTuning.isVerifyPassEnabled(context)) }
    var ocrOnDownload by remember { mutableStateOf(MangaOcrCache.isOcrOnDownloadEnabled(context)) }

    // A preset rewrites six values at once, so the panel re-reads everything
    // rather than trying to keep each field in sync by hand.
    val reload: () -> Unit = {
        preset = DownloadTuning.getPreset(context)
        parallelChapters = DownloadTuning.getParallelChapters(context)
        parallelPages = DownloadTuning.getParallelPages(context)
        chapterDelay = DownloadTuning.getChapterDelayMs(context)
        pageDelay = DownloadTuning.getPageDelayMs(context)
        retries = DownloadTuning.getRetryAttempts(context)
        speedKbps = DownloadTuning.getSpeedLimitKbps(context)
        wifiOnly = DownloadTuning.isWifiOnly(context)
        verifyPass = DownloadTuning.isVerifyPassEnabled(context)
    }

    SettingsGroup(title = "Download tuning") {

        // ----------------------------------------------------------- presets
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp)
        ) {
            Text(
                text = "Speed preset",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = when (preset) {
                    DownloadTuning.PRESET_GENTLE ->
                        "Gentle: one thing at a time, long pauses. For sources that block you."
                    DownloadTuning.PRESET_TURBO ->
                        "Turbo: no pauses, widest parallelism. Fastest, but more likely to get rate-limited."
                    DownloadTuning.PRESET_BALANCED ->
                        "Balanced: a few requests overlap, short pauses kept. Recommended."
                    else ->
                        "Custom: your own values below."
                },
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    DownloadTuning.PRESET_GENTLE to "Gentle",
                    DownloadTuning.PRESET_BALANCED to "Balanced",
                    DownloadTuning.PRESET_TURBO to "Turbo"
                ).forEach { entry ->
                    FilterChip(
                        selected = preset == entry.first,
                        onClick = {
                            DownloadTuning.applyPreset(context, entry.first)
                            reload()
                        },
                        label = { Text(entry.second, fontSize = 12.sp) }
                    )
                }
            }
        }

        SettingsRowDivider()

        // ------------------------------------------------------ parallelism
        DownloadStepperRow(
            title = "Novel chapters at once",
            subtitle = "A novel chapter is a single request, so fetching several at a time overlaps " +
                "the waiting. Raise for speed, lower if a source starts failing.",
            icon = Icons.Default.Download,
            value = parallelChapters,
            min = DownloadTuning.MIN_PARALLEL_CHAPTERS,
            max = DownloadTuning.MAX_PARALLEL_CHAPTERS,
            onChange = {
                DownloadTuning.setParallelChapters(context, it)
                parallelChapters = DownloadTuning.getParallelChapters(context)
                preset = DownloadTuning.getPreset(context)
            }
        )

        SettingsRowDivider()

        DownloadStepperRow(
            title = "Manga pages at once",
            subtitle = "Pages of the same chapter fetched in parallel. This is the big one for manga: " +
                "a chapter can be 200 images.",
            icon = Icons.Default.Download,
            value = parallelPages,
            min = DownloadTuning.MIN_PARALLEL_PAGES,
            max = DownloadTuning.MAX_PARALLEL_PAGES,
            onChange = {
                DownloadTuning.setParallelPages(context, it)
                parallelPages = DownloadTuning.getParallelPages(context)
                preset = DownloadTuning.getPreset(context)
            }
        )

        SettingsRowDivider()

        // ------------------------------------------------------ speed limit
        DownloadChipRow(
            title = "Speed limit",
            subtitle = "Caps download throughput so a big job leaves bandwidth for everything else.",
            options = DownloadTuning.SPEED_OPTIONS.map { it to DownloadTuning.speedLabel(it) },
            selected = speedKbps,
            onSelect = {
                DownloadTuning.setSpeedLimitKbps(context, it)
                speedKbps = DownloadTuning.getSpeedLimitKbps(context)
                preset = DownloadTuning.getPreset(context)
            }
        )

        SettingsRowDivider()

        // ----------------------------------------------------------- pacing
        DownloadChipRow(
            title = "Pause between chapters",
            subtitle = "Politeness gap so sources are less likely to rate-limit you.",
            options = DownloadTuning.CHAPTER_DELAY_OPTIONS.map { it to DownloadTuning.delayLabel(it) },
            selected = chapterDelay,
            onSelect = {
                DownloadTuning.setChapterDelayMs(context, it)
                chapterDelay = DownloadTuning.getChapterDelayMs(context)
                preset = DownloadTuning.getPreset(context)
            }
        )

        SettingsRowDivider()

        DownloadChipRow(
            title = "Pause between manga pages",
            subtitle = "Applied per page. None plus a low page count is the fastest setting.",
            options = DownloadTuning.PAGE_DELAY_OPTIONS.map { it to DownloadTuning.delayLabel(it) },
            selected = pageDelay,
            onSelect = {
                DownloadTuning.setPageDelayMs(context, it)
                pageDelay = DownloadTuning.getPageDelayMs(context)
                preset = DownloadTuning.getPreset(context)
            }
        )

        SettingsRowDivider()

        // ---------------------------------------------------------- retries
        DownloadStepperRow(
            title = "Retry attempts",
            subtitle = "Tries per chapter before it is marked failed, with a widening pause between tries.",
            icon = Icons.Default.Refresh,
            value = retries,
            min = DownloadTuning.MIN_RETRIES,
            max = DownloadTuning.MAX_RETRIES,
            onChange = {
                DownloadTuning.setRetryAttempts(context, it)
                retries = DownloadTuning.getRetryAttempts(context)
                preset = DownloadTuning.getPreset(context)
            }
        )

        SettingsRowDivider()

        // --------------------------------------------------------- switches
        SettingsRow(
            title = "Download on Wi-Fi only",
            subtitle = "Blocks new download jobs on mobile data instead of quietly eating your quota.",
            trailing = {
                Switch(
                    checked = wifiOnly,
                    onCheckedChange = {
                        wifiOnly = it
                        DownloadTuning.setWifiOnly(context, it)
                    }
                )
            }
        )

        SettingsRowDivider()

        SettingsRow(
            title = "Second verification pass (novels)",
            subtitle = "A slower sweep over anything still missing. Flaky sources often hand back a " +
                "block page first and the real chapter moments later. Turn off for speed.",
            trailing = {
                Switch(
                    checked = verifyPass,
                    onCheckedChange = {
                        verifyPass = it
                        DownloadTuning.setVerifyPassEnabled(context, it)
                    }
                )
            }
        )

        SettingsRowDivider()

        SettingsRow(
            title = "Run OCR while downloading (manga)",
            subtitle = "Reads the speech bubbles up front so read-aloud never waits in the reader. " +
                "Makes downloads noticeably slower.",
            trailing = {
                Switch(
                    checked = ocrOnDownload,
                    onCheckedChange = {
                        ocrOnDownload = it
                        MangaOcrCache.setOcrOnDownloadEnabled(context, it)
                    }
                )
            }
        )

        SettingsRowDivider()

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(
                onClick = {
                    DownloadTuning.resetToDefaults(context)
                    MangaOcrCache.setOcrOnDownloadEnabled(context, false)
                    ocrOnDownload = false
                    reload()
                }
            ) {
                Text("Reset to defaults", fontSize = 12.sp)
            }
        }

        Text(
            text = "Changes apply to the next download you start. Jobs already running keep the " +
                "settings they began with, so their progress stays accurate.",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp)
        )
    }
}

/** A up/down stepper row, used for the small integer knobs. */
@Composable
private fun DownloadStepperRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    value: Int,
    min: Int,
    max: Int,
    onChange: (Int) -> Unit
) {
    SettingsRow(
        title = title,
        subtitle = subtitle,
        icon = icon,
        trailing = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { if (value > min) onChange(value - 1) },
                    enabled = value > min
                ) {
                    Icon(
                        Icons.Default.KeyboardArrowDown,
                        contentDescription = "Decrease",
                        modifier = Modifier.size(20.dp)
                    )
                }
                Text(
                    text = value.toString(),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(
                    onClick = { if (value < max) onChange(value + 1) },
                    enabled = value < max
                ) {
                    Icon(
                        Icons.Default.KeyboardArrowUp,
                        contentDescription = "Increase",
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    )
}

/** A wrapping chip picker, used where the useful values are a fixed set. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun <T> DownloadChipRow(
    title: String,
    subtitle: String,
    options: List<Pair<T, String>>,
    selected: T,
    onSelect: (T) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Text(
            text = title,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = subtitle,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEach { option ->
                FilterChip(
                    selected = selected == option.first,
                    onClick = { onSelect(option.first) },
                    label = { Text(option.second, fontSize = 12.sp) }
                )
            }
        }
    }
}
