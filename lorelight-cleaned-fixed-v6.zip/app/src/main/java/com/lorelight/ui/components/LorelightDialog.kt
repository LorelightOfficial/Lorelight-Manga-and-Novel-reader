package com.lorelight.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.lorelight.ui.theme.GlassDialog

/**
 * Reusable glass-styled dialog for Lorelight.
 * Built on top of [GlassDialog] to maintain visual consistency across the app.
 */
@Composable
fun LorelightDialog(
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
    title: String? = null,
    titleContent: (@Composable () -> Unit)? = null,
    text: String? = null,
    icon: ImageVector? = null,
    iconContent: (@Composable () -> Unit)? = null,
    confirmText: String? = null,
    onConfirm: (() -> Unit)? = null,
    confirmButton: (@Composable () -> Unit)? = null,
    dismissText: String? = null,
    onDismiss: (() -> Unit)? = null,
    dismissButton: (@Composable () -> Unit)? = null,
    isDestructive: Boolean = false,
    content: (@Composable ColumnScope.() -> Unit)? = null
) {
    Dialog(
        onDismissRequest = onDismissRequest,
        properties = DialogProperties(
            usePlatformDefaultWidth = false
        )
    ) {
        var visible by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) {
            visible = true
        }

        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(tween(180)) + scaleIn(
                initialScale = 0.92f,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow)
            ),
            exit = fadeOut(tween(150)) + scaleOut(targetScale = 0.95f)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.55f))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { onDismissRequest() },
                contentAlignment = Alignment.Center
            ) {
                GlassDialog(
                    modifier = modifier
                        .padding(horizontal = 24.dp, vertical = 32.dp)
                        .widthIn(min = 280.dp, max = 520.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            enabled = true
                        ) {} // consume clicks inside dialog box
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // 1. Icon
                        if (iconContent != null) {
                            iconContent()
                            Spacer(modifier = Modifier.height(16.dp))
                        } else if (icon != null) {
                            val containerBg = if (isDestructive) {
                                MaterialTheme.colorScheme.errorContainer
                            } else {
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
                            }
                            val iconTint = if (isDestructive) {
                                MaterialTheme.colorScheme.onErrorContainer
                            } else {
                                MaterialTheme.colorScheme.primary
                            }
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(containerBg),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = iconTint,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                        }

                        // 2. Title
                        if (titleContent != null) {
                            titleContent()
                            Spacer(modifier = Modifier.height(12.dp))
                        } else if (!title.isNullOrBlank()) {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                        }

                        // 3. Body
                        if (content != null) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                content = content
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                        } else if (!text.isNullOrBlank()) {
                            Text(
                                text = text,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                        }

                        // 4. Buttons Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (dismissButton != null) {
                                dismissButton()
                            } else if (!dismissText.isNullOrBlank() || onDismiss != null) {
                                TextButton(
                                    onClick = { onDismiss?.invoke() ?: onDismissRequest() }
                                ) {
                                    Text(
                                        text = dismissText ?: "Cancel",
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            if (dismissButton != null || dismissText != null || onDismiss != null) {
                                Spacer(modifier = Modifier.width(8.dp))
                            }

                            if (confirmButton != null) {
                                confirmButton()
                            } else if (!confirmText.isNullOrBlank() || onConfirm != null) {
                                Button(
                                    onClick = { onConfirm?.invoke() },
                                    colors = if (isDestructive) {
                                        ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.error,
                                            contentColor = MaterialTheme.colorScheme.onError
                                        )
                                    } else {
                                        ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.primary,
                                            contentColor = MaterialTheme.colorScheme.onPrimary
                                        )
                                    }
                                ) {
                                    Text(
                                        text = confirmText ?: "Confirm",
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Slot overload matching standard AlertDialog signature for easy drop-in migration.
 */
@Composable
fun LorelightDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    dismissButton: (@Composable () -> Unit)? = null,
    icon: (@Composable () -> Unit)? = null,
    title: (@Composable () -> Unit)? = null,
    text: (@Composable () -> Unit)? = null,
    isDestructive: Boolean = false,
    containerColor: Color = Color.Unspecified,
    shape: Shape? = null
) {
    LorelightDialog(
        onDismissRequest = onDismissRequest,
        modifier = modifier,
        titleContent = title,
        iconContent = icon,
        confirmButton = confirmButton,
        dismissButton = dismissButton,
        isDestructive = isDestructive,
        content = text?.let { textSlot ->
            { textSlot() }
        }
    )
}
