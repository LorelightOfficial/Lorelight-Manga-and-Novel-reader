package com.lorelight.ui.reader

import androidx.compose.animation.*
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import com.lorelight.ui.components.LorelightDialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.zIndex
import com.lorelight.data.model.Novel
import com.lorelight.ui.components.FontManagerEngine
import com.lorelight.ui.components.resolveFontFamily
import com.lorelight.ui.components.readerSafeTopPadding
import com.lorelight.ui.theme.GoldOnGradient
import com.lorelight.ui.theme.RefinedGoldGradient
import com.lorelight.ui.theme.GlassPanel
import com.lorelight.utils.FilterRule
import com.lorelight.utils.TextFilter

private val SettingCardRadius = 14.dp
private val SettingCardPadding = 14.dp     // inner padding of a card
private val SettingRowMinHeight = 48.dp    // touch target
private val SettingGroupGap = 14.dp        // gap between cards
private val SettingInnerGap = 12.dp        // gap between rows inside a card

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun ReaderSettingsSheet(
    showSettingsDialog: Boolean,
    onDismissSettings: () -> Unit,
    showTextFilterPanel: Boolean,
    onSetTextFilterPanelVisible: (Boolean) -> Unit,
    viewModel: ReaderViewModel,
    activeNovel: Novel?,
    readerTextColor: Color,
    readerHighlightColor: Color,
    themeState: String,
    onOpenFontManager: () -> Unit,
    onResetSelection: () -> Unit
) {
    val context = LocalContext.current

    val readerMode by viewModel.readerMode.collectAsState()
    val fontSize by viewModel.readerFontSize.collectAsState()
    val lineSpacing by viewModel.readerLineSpacing.collectAsState()
    val paragraphSpacing by viewModel.readerParagraphSpacing.collectAsState()
    val textAlignment by viewModel.readerTextAlignment.collectAsState()
    val readerBackgroundType by viewModel.readerBackgroundType.collectAsState()
    val readerTextColorRaw by viewModel.readerTextColor.collectAsState()
    val readerBgColorRaw by viewModel.readerBgColor.collectAsState()
    val readerFontFamily by viewModel.readerFontFamily.collectAsState()
    val isDefaultHighlight by viewModel.isDefaultHighlight.collectAsState()
    val customHighlightColorRaw by viewModel.customHighlightColor.collectAsState()
    val textFilterRules by viewModel.textFilterRules.collectAsState()
    val isTapNavigationEnabled by viewModel.isTapNavigationEnabled.collectAsState()

    // Listen TTS specific settings
    val selectedAccent by viewModel.selectedAccent.collectAsState()
    val selectedVoice by viewModel.selectedVoice.collectAsState()
    val speechRate by viewModel.speechRate.collectAsState()
    val availableAccents by viewModel.availableAccents.collectAsState()
    val filteredVoices by viewModel.filteredVoices.collectAsState()

    // Local Display states for custom Dialog pickers
    var showFontSelectionDialog by remember { mutableStateOf(false) }
    var showColorWheelDialog by remember { mutableStateOf(false) }
    var showNovelTextColorPicker by remember { mutableStateOf(false) }
    var showBgColorPicker by remember { mutableStateOf(false) }
    var showDownloadedFontsDialog by remember { mutableStateOf(false) }

    var isFontLayoutExpanded by remember { mutableStateOf(true) }
    var isThemeOptionsExpanded by remember { mutableStateOf(false) }
    var isReadingModesExpanded by remember { mutableStateOf(false) }

    val defaultHighlightColor = remember(themeState) { getDefaultHighlightColor(themeState) }

    AnimatedVisibility(
        visible = showSettingsDialog,
        enter = slideInHorizontally(
            initialOffsetX = { it },
            animationSpec = tween(260, easing = FastOutSlowInEasing)
        ) + fadeIn(tween(200)),
        exit = slideOutHorizontally(
            targetOffsetX = { it },
            animationSpec = tween(240)
        ) + fadeOut(tween(180))
    ) {
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(0.55f)).clickable { onDismissSettings() }) {
            GlassPanel(
                shape = RoundedCornerShape(topStart = 20.dp, bottomStart = 20.dp),
                tintAlpha = 0.88f,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .fillMaxWidth(0.85f)
                    .clickable(enabled = false) {}
            ) {
                Column(modifier = Modifier.fillMaxSize().padding(top = readerSafeTopPadding()).padding(horizontal = 20.dp, vertical = 20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        Text("Reader Settings", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                        IconButton(onClick = onDismissSettings) { 
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)) 
                        }
                    }
                    
                    // Tab Selection Row for Read and Listen
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                            .height(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                            .padding(4.dp)
                    ) {
                        listOf("Read", "Listen").forEach { tab ->
                            val isSelected = readerMode == tab
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                    .then(
                                        if (isSelected) Modifier.border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp))
                                        else Modifier
                                    )
                                    .clickable { viewModel.readerMode.value = tab },
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = if (tab == "Read") Icons.Default.MenuBook else Icons.Default.Headphones,
                                        contentDescription = null,
                                        tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = tab,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                    
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(SettingGroupGap),
                        contentPadding = PaddingValues(top = 4.dp, bottom = 80.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        if (readerMode == "Read") {
                            // ------------------ READ TAB SETTINGS ------------------
                            // Page Formatting / Manage Text Filter
                            item {
                                Column {
                                    Text("PAGE FORMATTING", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .clickable {
                                                onDismissSettings()
                                                onSetTextFilterPanelVisible(true)
                                            }
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.defaultMinSize(minHeight = SettingRowMinHeight)
                                        ) {
                                            Icon(Icons.Default.FilterAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text("Manage Text Filter", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                                            ) {
                                                Text("${textFilterRules.size} active", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Icon(Icons.Default.ArrowForwardIos, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(12.dp))
                                        }
                                    }
                                }
                            }
                            
                            // Typography / Downloaded Fonts
                            item {
                                Column {
                                    Text("TYPOGRAPHY", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .clickable { showDownloadedFontsDialog = true }
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.defaultMinSize(minHeight = SettingRowMinHeight)
                                        ) {
                                            Icon(Icons.Default.FontDownload, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("Font Selection", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                                                Text(readerFontFamily, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                            }
                                            Icon(Icons.Default.ArrowForwardIos, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(12.dp))
                                        }
                                    }
                                }
                            }

                            // Text Sliders Group Card
                            item {
                                Column {
                                    Text("TEXT", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding),
                                        verticalArrangement = Arrangement.spacedBy(SettingInnerGap)
                                    ) {
                                        // Text Size
                                        Column {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text("Text Size", fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${fontSize.toInt()}sp", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = fontSize,
                                                onValueChange = { viewModel.readerFontSize.value = it },
                                                valueRange = 12f..32f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                        // Line Spacing
                                        Column {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text("Line Spacing", fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${"%.1fx".format(lineSpacing)}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = lineSpacing,
                                                onValueChange = { viewModel.readerLineSpacing.value = it },
                                                valueRange = 1.0f..2.5f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                        // Paragraph Spacing
                                        Column {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text("Paragraph Spacing", fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${paragraphSpacing.toInt()}dp", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = paragraphSpacing,
                                                onValueChange = { viewModel.readerParagraphSpacing.value = it },
                                                valueRange = 0f..40f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }
                                    }
                                }
                            }

                            // Text Alignment
                            item {
                                Column {
                                    Text("TEXT ALIGNMENT", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            val alignOptions = listOf(
                                                Triple("Left", Icons.Default.FormatAlignLeft, "Left"),
                                                Triple("Center", Icons.Default.FormatAlignCenter, "Center"),
                                                Triple("Right", Icons.Default.FormatAlignRight, "Right"),
                                                Triple("Justify", Icons.Default.FormatAlignJustify, "Justify")
                                            )
                                            alignOptions.forEach { (align, icon, label) ->
                                                val isSelected = textAlignment == align
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(SettingRowMinHeight)
                                                        .clip(RoundedCornerShape(10.dp))
                                                        .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                                        .border(
                                                            width = if (isSelected) 1.5.dp else 1.dp,
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                                            shape = RoundedCornerShape(10.dp)
                                                        )
                                                        .clickable { viewModel.readerTextAlignment.value = align },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Column(
                                                        horizontalAlignment = Alignment.CenterHorizontally,
                                                        verticalArrangement = Arrangement.Center
                                                    ) {
                                                        Icon(
                                                            imageVector = icon,
                                                            contentDescription = label,
                                                            tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                        Text(
                                                            text = label, 
                                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal, 
                                                            fontSize = 11.sp, 
                                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Background Style
                            item {
                                Column {
                                    Text("BACKGROUND STYLE", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            listOf("Theme", "Choose").forEach { bgType ->
                                                val isSelected = if (bgType == "Choose") {
                                                    (readerBackgroundType == "Choose" || readerBackgroundType == "AMOLED Black")
                                                } else {
                                                    readerBackgroundType == bgType
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(SettingRowMinHeight)
                                                        .clip(RoundedCornerShape(10.dp))
                                                        .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                                        .border(
                                                            width = if (isSelected) 1.5.dp else 1.dp,
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                                            shape = RoundedCornerShape(10.dp)
                                                        )
                                                        .clickable {
                                                            if (bgType == "Choose") {
                                                                showBgColorPicker = true
                                                            } else {
                                                                viewModel.readerBackgroundType.value = bgType
                                                            }
                                                        },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = bgType,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                        fontSize = 13.sp,
                                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Novel Text Color
                            item {
                                Column {
                                    Text("NOVEL TEXT COLOR", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .clickable { showNovelTextColorPicker = true }
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.defaultMinSize(minHeight = SettingRowMinHeight)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(readerTextColorRaw))
                                                    .border(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f), CircleShape)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text(
                                                text = "Choose custom text color...",
                                                fontSize = 14.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                fontWeight = FontWeight.Medium,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Icon(
                                                Icons.Default.ColorLens,
                                                contentDescription = "Text Color Picker",
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        } else {
                            // ------------------ LISTEN TAB SETTINGS ------------------
                            // Novel Text Color
                            item {
                                Column {
                                    Text("NOVEL TEXT COLOR", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .clickable { showNovelTextColorPicker = true }
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.defaultMinSize(minHeight = SettingRowMinHeight)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(24.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(readerTextColorRaw))
                                                    .border(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f), CircleShape)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text(
                                                text = "Choose custom text color...",
                                                fontSize = 14.sp,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                fontWeight = FontWeight.Medium,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Icon(
                                                Icons.Default.ColorLens,
                                                contentDescription = "Text Color Picker",
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }

                            // Page Formatting / Manage Text Filter
                            item {
                                Column {
                                    Text("PAGE FORMATTING", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .clickable {
                                                onDismissSettings()
                                                onSetTextFilterPanelVisible(true)
                                            }
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.defaultMinSize(minHeight = SettingRowMinHeight)
                                        ) {
                                            Icon(Icons.Default.FilterAlt, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Text("Manage Text Filter", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(MaterialTheme.colorScheme.primaryContainer)
                                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                                            ) {
                                                Text("${textFilterRules.size} active", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Icon(Icons.Default.ArrowForwardIos, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(12.dp))
                                        }
                                    }
                                }
                            }

                            // Visual Aesthetics (Switches Card)
                            item {
                                Column {
                                    Text("VISUAL AESTHETICS", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding),
                                        verticalArrangement = Arrangement.spacedBy(SettingInnerGap)
                                    ) {
                                        // Auto-Next Chapter
                                        Row(
                                            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = SettingRowMinHeight),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "Auto-Next Chapter",
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 14.sp,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            val autoNextChapter by viewModel.autoNextChapter.collectAsState()
                                            Switch(
                                                checked = autoNextChapter,
                                                onCheckedChange = { viewModel.setAutoNextChapter(it) },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = MaterialTheme.colorScheme.primary,
                                                    checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                                                )
                                            )
                                        }

                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                                        // Immersive Mode
                                        Row(
                                            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = SettingRowMinHeight),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "Immersive Mode",
                                                    fontWeight = FontWeight.Medium,
                                                    fontSize = 14.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "Hide status and navigation bars while reading",
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                                )
                                            }
                                            val immersiveMode by viewModel.immersiveMode.collectAsState()
                                            Switch(
                                                checked = immersiveMode,
                                                onCheckedChange = { viewModel.setImmersiveMode(it) },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = MaterialTheme.colorScheme.primary,
                                                    checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                                                )
                                            )
                                        }

                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                                        // Volume Key Page Turn
                                        Row(
                                            modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = SettingRowMinHeight),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "Volume Key Page Turn",
                                                    fontWeight = FontWeight.Medium,
                                                    fontSize = 14.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Text(
                                                    text = "Volume buttons scroll the page (off during narration)",
                                                    fontSize = 12.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                                )
                                            }
                                            val volumeKeysEnabled by viewModel.volumeKeysEnabled.collectAsState()
                                            Switch(
                                                checked = volumeKeysEnabled,
                                                onCheckedChange = { viewModel.setVolumeKeysEnabled(it) },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = MaterialTheme.colorScheme.primary,
                                                    checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                                                )
                                            )
                                        }
                                    }
                                }
                            }

                            // Speech Controls Card
                            item {
                                Column {
                                    Text("SPEECH CONTROLS", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // Accent
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("Accent", fontWeight = FontWeight.Medium, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 4.dp))
                                                var accentDropdownVisible by remember { mutableStateOf(false) }
                                                Box(modifier = Modifier.fillMaxWidth()) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                                                            .clickable { accentDropdownVisible = true }.padding(horizontal = 8.dp, vertical = 10.dp)
                                                    ) {
                                                        Text(selectedAccent, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                                                    }
                                                    DropdownMenu(expanded = accentDropdownVisible, onDismissRequest = { accentDropdownVisible = false }) {
                                                        availableAccents.forEach { accent ->
                                                            DropdownMenuItem(
                                                                text = { Text(accent, fontSize = 13.sp) },
                                                                onClick = { viewModel.selectAccentAndApply(accent); accentDropdownVisible = false }
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                            // Voice
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("Voice", fontWeight = FontWeight.Medium, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 4.dp))
                                                var voiceDropdownVisible by remember { mutableStateOf(false) }
                                                Box(modifier = Modifier.fillMaxWidth()) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(8.dp))
                                                            .clickable { voiceDropdownVisible = true }.padding(horizontal = 8.dp, vertical = 10.dp)
                                                    ) {
                                                        val voiceName = selectedVoice?.name?.replace("en-us-x-", "")?.replace("-local", "")
                                                        Text(if (voiceName != null) voiceName else "Default", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                                                    }
                                                    DropdownMenu(expanded = voiceDropdownVisible, onDismissRequest = { voiceDropdownVisible = false }) {
                                                        filteredVoices.forEach { voice ->
                                                            DropdownMenuItem(
                                                                text = { Text(voice.name, fontSize = 13.sp) },
                                                                onClick = { viewModel.selectVoiceAndApply(voice); voiceDropdownVisible = false }
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                            // Speed
                                            Column(modifier = Modifier.weight(0.7f)) {
                                                Text("Speed", fontWeight = FontWeight.Medium, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 4.dp))
                                                var rateDropdownVisible by remember { mutableStateOf(false) }
                                                Box(modifier = Modifier.fillMaxWidth()) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).border(1.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp))
                                                            .clickable { rateDropdownVisible = true }.padding(horizontal = 8.dp, vertical = 10.dp)
                                                    ) {
                                                        Text("${"%.2fx".format(speechRate)}", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, color = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.weight(1f))
                                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                                                    }
                                                    DropdownMenu(expanded = rateDropdownVisible, onDismissRequest = { rateDropdownVisible = false }) {
                                                        listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.50f, 1.75f, 2.0f, 2.5f, 3.0f).forEach { speedOption ->
                                                            DropdownMenuItem(text = { Text("${"%.2fx".format(speedOption)}") }, onClick = { viewModel.setSpeechRateAndApply(speedOption); rateDropdownVisible = false })
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Text Alignment
                            item {
                                Column {
                                    Text("TEXT ALIGNMENT", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            val alignOptions = listOf(
                                                Triple("Left", Icons.Default.FormatAlignLeft, "Left"),
                                                Triple("Center", Icons.Default.FormatAlignCenter, "Center"),
                                                Triple("Right", Icons.Default.FormatAlignRight, "Right"),
                                                Triple("Justify", Icons.Default.FormatAlignJustify, "Justify")
                                            )
                                            alignOptions.forEach { (align, icon, label) ->
                                                val isSelected = textAlignment == align
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(SettingRowMinHeight)
                                                        .clip(RoundedCornerShape(10.dp))
                                                        .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                                        .border(
                                                            width = if (isSelected) 1.5.dp else 1.dp,
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                                            shape = RoundedCornerShape(10.dp)
                                                        )
                                                        .clickable { viewModel.readerTextAlignment.value = align },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Column(
                                                        horizontalAlignment = Alignment.CenterHorizontally,
                                                        verticalArrangement = Arrangement.Center
                                                    ) {
                                                        Icon(
                                                            imageVector = icon,
                                                            contentDescription = label,
                                                            tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                        Text(
                                                            text = label, 
                                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal, 
                                                            fontSize = 11.sp, 
                                                            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Background Style
                            item {
                                Column {
                                    Text("BACKGROUND STYLE", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            listOf("Theme", "Choose").forEach { bgType ->
                                                val isSelected = if (bgType == "Choose") {
                                                    (readerBackgroundType == "Choose" || readerBackgroundType == "AMOLED Black")
                                                } else {
                                                    readerBackgroundType == bgType
                                                }
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(SettingRowMinHeight)
                                                        .clip(RoundedCornerShape(10.dp))
                                                        .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                                        .border(
                                                            width = if (isSelected) 1.5.dp else 1.dp,
                                                            color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                                            shape = RoundedCornerShape(10.dp)
                                                        )
                                                        .clickable {
                                                            if (bgType == "Choose") {
                                                                showBgColorPicker = true
                                                            } else {
                                                                viewModel.readerBackgroundType.value = bgType
                                                            }
                                                        },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = bgType,
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                                        fontSize = 13.sp,
                                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Typography / Downloaded Fonts
                            item {
                                Column {
                                    Text("TYPOGRAPHY", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .clickable { showDownloadedFontsDialog = true }
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.defaultMinSize(minHeight = SettingRowMinHeight)
                                        ) {
                                            Icon(Icons.Default.FontDownload, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("Font Selection", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurface)
                                                Text(readerFontFamily, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                            }
                                            Icon(Icons.Default.ArrowForwardIos, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f), modifier = Modifier.size(12.dp))
                                        }
                                    }
                                }
                            }

                            // Text Sliders Group Card (Fix drift: same header "TEXT" and title "Text Size" as Read tab)
                            item {
                                Column {
                                    Text("TEXT", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding),
                                        verticalArrangement = Arrangement.spacedBy(SettingInnerGap)
                                    ) {
                                        // Text Size
                                        Column {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text("Text Size", fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${fontSize.toInt()}sp", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = fontSize,
                                                onValueChange = { viewModel.readerFontSize.value = it },
                                                valueRange = 12f..32f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                        // Line Spacing
                                        Column {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text("Line Spacing", fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${"%.1fx".format(lineSpacing)}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = lineSpacing,
                                                onValueChange = { viewModel.readerLineSpacing.value = it },
                                                valueRange = 1.0f..2.5f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }
                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                                        // Paragraph Spacing
                                        Column {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                                Text("Paragraph Spacing", fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface)
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${paragraphSpacing.toInt()}dp", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = paragraphSpacing,
                                                onValueChange = { viewModel.readerParagraphSpacing.value = it },
                                                valueRange = 0f..40f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }
                                    }
                                }
                            }

                            // Text Highlights Accent
                            item {
                                Column {
                                    Text("TEXT HIGHLIGHTS ACCENT", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding)
                                    ) {
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            // Default option
                                            Card(
                                                shape = RoundedCornerShape(10.dp),
                                                colors = CardDefaults.cardColors(containerColor = if (isDefaultHighlight) MaterialTheme.colorScheme.primaryContainer else Color.Transparent),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clickable { viewModel.isDefaultHighlight.value = true }
                                                    .border(
                                                        width = if (isDefaultHighlight) 1.5.dp else 1.dp,
                                                        color = if (isDefaultHighlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                                        shape = RoundedCornerShape(10.dp)
                                                    )
                                            ) {
                                                val defaultHighlightName = if (themeState == "blackgold") "Amber Gold" else "Dim Glow Green"
                                                Row(
                                                    modifier = Modifier.padding(12.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(defaultHighlightColor))
                                                    Text(defaultHighlightName, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (isDefaultHighlight) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface)
                                                }
                                            }
                                            
                                            // Set Color / Custom picker option
                                            Card(
                                                shape = RoundedCornerShape(10.dp),
                                                colors = CardDefaults.cardColors(containerColor = if (!isDefaultHighlight) MaterialTheme.colorScheme.primaryContainer else Color.Transparent),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clickable { showColorWheelDialog = true }
                                                    .border(
                                                        width = if (!isDefaultHighlight) 1.5.dp else 1.dp,
                                                        color = if (!isDefaultHighlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant,
                                                        shape = RoundedCornerShape(10.dp)
                                                    )
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(12.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(if (!isDefaultHighlight) Color(customHighlightColorRaw) else Color.Gray))
                                                    Text(if (!isDefaultHighlight) "Custom Active" else "Set Custom", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = if (!isDefaultHighlight) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            // Speech Pauses
                            item {
                                Column {
                                    Text("SPEECH PAUSES", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(SettingCardRadius))
                                            .background(MaterialTheme.colorScheme.surface)
                                            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(SettingCardRadius))
                                            .padding(SettingCardPadding),
                                        verticalArrangement = Arrangement.spacedBy(SettingInnerGap)
                                    ) {
                                        // Pause between sentences
                                        val nextSentencePause by viewModel.nextSentencePauseMs.collectAsState()
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                                Text("Pause between sentences", fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${nextSentencePause.toInt()} ms", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = nextSentencePause,
                                                onValueChange = { viewModel.nextSentencePauseMs.value = it },
                                                valueRange = 0f..800f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }

                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                                        // Pause between paragraphs
                                        val paragraphPause by viewModel.paragraphPauseMs.collectAsState()
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                                Text("Pause between paragraphs", fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${paragraphPause.toInt()} ms", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = paragraphPause,
                                                onValueChange = { viewModel.paragraphPauseMs.value = it },
                                                valueRange = 0f..1500f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }

                                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                                        // Punctuation pause intensity
                                        val punctuationScale by viewModel.punctuationPauseScale.collectAsState()
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                                Text("Punctuation pause ( . , ! ? … )", fontWeight = FontWeight.Medium, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.weight(1f))
                                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 8.dp, vertical = 3.dp)) {
                                                    Text("${"%.1fx".format(punctuationScale)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                                }
                                            }
                                            Slider(
                                                value = punctuationScale,
                                                onValueChange = { viewModel.punctuationPauseScale.value = it },
                                                valueRange = 0f..2f,
                                                colors = SliderDefaults.colors(
                                                    thumbColor = MaterialTheme.colorScheme.primary,
                                                    activeTrackColor = MaterialTheme.colorScheme.primary,
                                                    inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                                                )
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(2.dp))

                                        Text(
                                            text = "All pauses automatically shrink at faster speech speeds and grow at slower speeds.",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Normal,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal pickers display section
    if (showDownloadedFontsDialog) {
        DownloadedFontsDialog(
            viewModel = viewModel,
            onDismiss = { showDownloadedFontsDialog = false },
            onOpenFontManager = onOpenFontManager,
            context = context
        )
    }

    if (showBgColorPicker) {
        BgColorWheelPickerDialog(
            initialColorValue = viewModel.readerBgColor.collectAsState().value,
            isAmoledBlack = (readerBackgroundType == "AMOLED Black"),
            onAmoledChanged = { amoled ->
                if (amoled) {
                    viewModel.readerBackgroundType.value = "AMOLED Black"
                } else {
                    viewModel.readerBackgroundType.value = "Choose"
                }
            },
            onColorSelected = { color ->
                viewModel.readerBgColor.value = color
                viewModel.readerBackgroundType.value = "Choose"
            },
            onDismiss = { showBgColorPicker = false }
        )
    }

    if (showNovelTextColorPicker) {
        NovelTextColorWheelPickerDialog(
            initialColorValue = readerTextColorRaw,
            onColorSelected = { color ->
                viewModel.readerTextColor.value = color
            },
            onDismiss = { showNovelTextColorPicker = false }
        )
    }

    if (showColorWheelDialog) {
        ColorWheelPickerDialog(
            initialColorValue = customHighlightColorRaw.toInt(),
            onColorSelected = { color ->
                viewModel.customHighlightColor.value = color.toLong()
                viewModel.isDefaultHighlight.value = false
            },
            onDismiss = { showColorWheelDialog = false }
        )
    }

    // Slide-in Text Filter Settings Panel (rendered as full overlay when showTextFilterPanel is true)
    AnimatedVisibility(
        visible = showTextFilterPanel,
        enter = slideInHorizontally(initialOffsetX = { it }, animationSpec = tween(300)),
        exit = slideOutHorizontally(targetOffsetX = { it }, animationSpec = tween(250)),
        modifier = Modifier
            .fillMaxSize()
            .zIndex(1000f)
    ) {
        var activeTab by remember { mutableStateOf(0) }
        var editingRule by remember { mutableStateOf<FilterRule?>(null) }
        
        var manualOriginal by remember { mutableStateOf("") }
        var manualReplacement by remember { mutableStateOf("") }
        var manualAction by remember { mutableStateOf(TextFilter.ACTION_ERASE_TEXT) }
        var manualStrictMatch by remember { mutableStateOf(false) }
        var manualScope by remember { mutableStateOf("All Books") }
        
        Surface(
            color = if (readerBackgroundType == "Theme") getThemeBgColor(themeState) else Color(viewModel.readerBgColor.collectAsState().value),
            contentColor = readerTextColor,
            modifier = Modifier.fillMaxSize()
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().statusBarsPadding()
                ) {
                    IconButton(onClick = { onSetTextFilterPanelVisible(false) }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = readerTextColor)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Manage Text Filter",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = readerTextColor
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                AdaptiveTabSwitch(
                    options = listOf(
                        "rules" to "Active Rules (${textFilterRules.size})",
                        "manual" to "Add Manual"
                    ),
                    selectedKey = if (activeTab == 0) "rules" else "manual",
                    onSelect = { activeTab = if (it == "rules") 0 else 1 },
                    accentColor = readerHighlightColor,
                    textColor = readerTextColor
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                if (activeTab == 0) {
                    Text(
                        text = "How it works: Long-press any word in the reader to select and create an active rule, replacing or hiding that word dynamically during reads.",
                        fontSize = 11.sp,
                        color = readerTextColor.copy(alpha = 0.6f),
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(bottom = 16.dp, start = 4.dp, end = 4.dp)
                    )
                    if (textFilterRules.isEmpty()) {
                        Box(
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    Icons.Default.Info,
                                    contentDescription = null,
                                    tint = readerTextColor.copy(alpha = 0.3f),
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "No active filter rules",
                                    fontSize = 14.sp,
                                    color = readerTextColor.copy(alpha = 0.5f)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Long-press any word in the reader to select it and create a rule.",
                                    fontSize = 11.sp,
                                    textAlign = TextAlign.Center,
                                    color = readerTextColor.copy(alpha = 0.3f),
                                    modifier = Modifier.padding(horizontal = 32.dp)
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.weight(1f).fillMaxWidth()
                        ) {
                            items(textFilterRules) { rule ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(readerTextColor.copy(alpha = 0.04f))
                                        .border(0.5.dp, readerTextColor.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                        .padding(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when (rule.action) {
                                                    TextFilter.ACTION_REPLACE -> Color(0xFF66BB6A).copy(alpha = 0.15f)
                                                    TextFilter.ACTION_ERASE_LINE -> Color(0xFFFF9800).copy(alpha = 0.15f)
                                                    else -> Color(0xFFEF5350).copy(alpha = 0.15f)
                                                }
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = when (rule.action) {
                                                TextFilter.ACTION_REPLACE -> "✏️"
                                                TextFilter.ACTION_ERASE_LINE -> "🗑️"
                                                else -> "🚫"
                                            },
                                            fontSize = 12.sp
                                        )
                                    }
                                    
                                    Spacer(modifier = Modifier.width(12.dp))
                                    
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = rule.original,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = readerTextColor
                                            )
                                            if (rule.action == TextFilter.ACTION_REPLACE || (!rule.isVanish && rule.action.isBlank())) {
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Icon(Icons.Default.ArrowForward, contentDescription = null, tint = readerTextColor.copy(alpha = 0.5f), modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = rule.replacement,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    color = readerHighlightColor
                                                )
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        val actionLabel = when (rule.action) {
                                            TextFilter.ACTION_REPLACE -> "Replace"
                                            TextFilter.ACTION_ERASE_LINE -> "Erase line"
                                            else -> "Erase text"
                                        }
                                        val strictLabel = if (rule.strictMatch) " • Strict" else ""
                                        Text(
                                            text = "$actionLabel$strictLabel • ${if (rule.scope == "All Books") "All Books 🌍" else "This Book 📖"}",
                                            fontSize = 10.sp,
                                            color = readerTextColor.copy(alpha = 0.5f)
                                        )
                                    }
                                    
                                    IconButton(
                                        onClick = {
                                            editingRule = rule
                                        }
                                    ) {
                                        Icon(
                                            Icons.Default.Edit,
                                            contentDescription = "Edit rule",
                                            tint = readerTextColor.copy(alpha = 0.7f)
                                        )
                                    }
                                    
                                    IconButton(
                                        onClick = {
                                            onResetSelection()
                                            viewModel.saveRules(textFilterRules.filter { it.id != rule.id })
                                        }
                                    ) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Delete rule",
                                            tint = Color(0xFFEF5350)
                                        )
                                    }
                                }
                            }
                        }
                    }
                } else {
                    Text(
                        text = "How it works: Enter the original word below to target it. Select 'Vanish' to hide it, or 'Replace' to swap it completely while reading.",
                        fontSize = 11.sp,
                        color = readerTextColor.copy(alpha = 0.6f),
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(bottom = 8.dp, start = 4.dp, end = 4.dp)
                    )
                    Column(
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    ) {
                        Column {
                            Text("Match Word or Phrase", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = readerTextColor.copy(alpha = 0.7f), modifier = Modifier.padding(bottom = 6.dp))
                            OutlinedTextField(
                                value = manualOriginal,
                                onValueChange = { manualOriginal = it },
                                placeholder = { Text("E.g., forbidden word", fontSize = 13.sp, color = readerTextColor.copy(alpha = 0.4f)) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = readerHighlightColor,
                                    unfocusedBorderColor = readerTextColor.copy(alpha = 0.15f),
                                    focusedTextColor = readerTextColor,
                                    unfocusedTextColor = readerTextColor
                                ),
                                modifier = Modifier.fillMaxWidth().height(50.dp)
                            )
                        }
                        
                        Column {
                            Text("When this text is found:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = readerTextColor.copy(alpha = 0.7f), modifier = Modifier.padding(bottom = 6.dp))
                            AdaptiveChoiceChips(
                                options = listOf(
                                    TextFilter.ACTION_REPLACE to "Replace",
                                    TextFilter.ACTION_ERASE_TEXT to "Erase text",
                                    TextFilter.ACTION_ERASE_LINE to "Erase line"
                                ),
                                selectedKey = manualAction,
                                onSelect = { manualAction = it },
                                accentColor = readerHighlightColor,
                                textColor = readerTextColor
                            )
                        }
                        
                        if (manualAction == TextFilter.ACTION_REPLACE) {
                            Column {
                                Text("Replacement Text", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = readerTextColor.copy(alpha = 0.7f), modifier = Modifier.padding(bottom = 6.dp))
                                OutlinedTextField(
                                    value = manualReplacement,
                                    onValueChange = { manualReplacement = it },
                                    placeholder = { Text("E.g., happy", fontSize = 13.sp, color = readerTextColor.copy(alpha = 0.4f)) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = readerHighlightColor,
                                        unfocusedBorderColor = readerTextColor.copy(alpha = 0.15f),
                                        focusedTextColor = readerTextColor,
                                        unfocusedTextColor = readerTextColor
                                    ),
                                    modifier = Modifier.fillMaxWidth().height(50.dp)
                                )
                            }
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Ignore dots, spaces & lookalikes",
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 13.sp,
                                    color = readerTextColor
                                )
                                Text(
                                    text = "Also catches f.r.e.e, F R E E and fr33",
                                    fontSize = 11.sp,
                                    color = readerTextColor.copy(alpha = 0.5f)
                                )
                            }
                            Switch(
                                checked = manualStrictMatch,
                                onCheckedChange = { manualStrictMatch = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = MaterialTheme.colorScheme.primary,
                                    checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                                )
                            )
                        }
                        
                        Column {
                            Text("Scope", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = readerTextColor.copy(alpha = 0.7f), modifier = Modifier.padding(bottom = 6.dp))
                            AdaptiveChoiceChips(
                                options = listOf(
                                    "All Books" to "All Books 🌍",
                                    "This Book" to "This Book 📖"
                                ),
                                selectedKey = manualScope,
                                onSelect = { manualScope = it },
                                accentColor = readerHighlightColor,
                                textColor = readerTextColor
                            )
                        }
                        
                        Spacer(modifier = Modifier.weight(1f))
                        
                        Button(
                            onClick = {
                                val cleanedOriginal = manualOriginal.trim()
                                    .trim('"', '\u201C', '\u201D', ',', '.', ';', ':', '!', '?')
                                    .replace(Regex("\\s+"), " ")
                                if (cleanedOriginal.isNotBlank()) {
                                    val squashedNew = TextFilter.squash(cleanedOriginal)
                                    val existingRule = textFilterRules.firstOrNull { rule ->
                                        TextFilter.squash(rule.original) == squashedNew && rule.scope == manualScope
                                    }
                                    val bookIdVal = if (manualScope == "This Book") (activeNovel?.id ?: "") else ""
                                    if (existingRule != null) {
                                        val updatedRule = existingRule.copy(
                                            original = cleanedOriginal,
                                            replacement = if (manualAction == TextFilter.ACTION_REPLACE) manualReplacement.trim() else "",
                                            isVanish = (manualAction != TextFilter.ACTION_REPLACE),
                                            action = manualAction,
                                            strictMatch = manualStrictMatch,
                                            scope = manualScope,
                                            bookId = bookIdVal
                                        )
                                        val updatedList = textFilterRules.map { if (it.id == existingRule.id) updatedRule else it }
                                        viewModel.saveRules(updatedList)
                                        Toast.makeText(context, "Updated existing rule", Toast.LENGTH_SHORT).show()
                                    } else {
                                        val newRule = FilterRule(
                                            id = java.util.UUID.randomUUID().toString(),
                                            original = cleanedOriginal,
                                            replacement = if (manualAction == TextFilter.ACTION_REPLACE) manualReplacement.trim() else "",
                                            isVanish = (manualAction != TextFilter.ACTION_REPLACE),
                                            scope = manualScope,
                                            bookId = bookIdVal,
                                            action = manualAction,
                                            strictMatch = manualStrictMatch
                                        )
                                        viewModel.saveRules(textFilterRules + newRule)
                                    }
                                    onResetSelection()
                                    manualOriginal = ""
                                    manualReplacement = ""
                                    activeTab = 0
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (themeState == "blackgold") Color.Transparent else readerHighlightColor,
                                contentColor = if (themeState == "blackgold") GoldOnGradient else Color.Black
                            ),
                            enabled = manualOriginal.trim().trim('"', '\u201C', '\u201D', ',', '.', ';', ':', '!', '?').replace(Regex("\\s+"), " ").isNotBlank(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(42.dp)
                                .then(
                                    if (themeState == "blackgold") {
                                        Modifier.background(RefinedGoldGradient, RoundedCornerShape(8.dp))
                                    } else {
                                        Modifier
                                    }
                                ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Save Rule", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // Edit Rule Dialog
        editingRule?.let { ruleToEdit ->
            var editOriginal by remember(ruleToEdit) { mutableStateOf(ruleToEdit.original) }
            var editReplacement by remember(ruleToEdit) { mutableStateOf(ruleToEdit.replacement) }
            var editAction by remember(ruleToEdit) { mutableStateOf(ruleToEdit.action) }
            var editStrictMatch by remember(ruleToEdit) { mutableStateOf(ruleToEdit.strictMatch) }
            var editScope by remember(ruleToEdit) { mutableStateOf(ruleToEdit.scope) }

            LorelightDialog(
                onDismissRequest = { editingRule = null },
                title = { Text("Edit Filter Rule") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = editOriginal,
                            onValueChange = { editOriginal = it },
                            label = { Text("Match Word or Phrase") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        
                        Text("Action:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        AdaptiveChoiceChips(
                            options = listOf(
                                TextFilter.ACTION_REPLACE to "Replace",
                                TextFilter.ACTION_ERASE_TEXT to "Erase text",
                                TextFilter.ACTION_ERASE_LINE to "Erase line"
                            ),
                            selectedKey = editAction,
                            onSelect = { editAction = it },
                            accentColor = MaterialTheme.colorScheme.primary,
                            textColor = MaterialTheme.colorScheme.onSurface
                        )
                        
                        if (editAction == TextFilter.ACTION_REPLACE) {
                            OutlinedTextField(
                                value = editReplacement,
                                onValueChange = { editReplacement = it },
                                label = { Text("Replacement Text") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Ignore dots, spaces & lookalikes", fontSize = 12.sp)
                            Switch(checked = editStrictMatch, onCheckedChange = { editStrictMatch = it })
                        }

                        Text("Scope:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        AdaptiveChoiceChips(
                            options = listOf("All Books" to "All Books 🌍", "This Book" to "This Book 📖"),
                            selectedKey = editScope,
                            onSelect = { editScope = it },
                            accentColor = MaterialTheme.colorScheme.primary,
                            textColor = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (editOriginal.isNotBlank()) {
                                val activeNovel = viewModel.activeNovel.value
                                val updatedRule = ruleToEdit.copy(
                                    original = editOriginal.trim(),
                                    replacement = if (editAction == TextFilter.ACTION_REPLACE) editReplacement.trim() else "",
                                    action = editAction,
                                    isVanish = (editAction != TextFilter.ACTION_REPLACE),
                                    strictMatch = editStrictMatch,
                                    scope = editScope,
                                    bookId = if (editScope == "This Book") (activeNovel?.id ?: "") else ""
                                )
                                val updatedList = textFilterRules.map { if (it.id == updatedRule.id) updatedRule else it }
                                viewModel.saveRules(updatedList)
                                editingRule = null
                            }
                        }
                    ) {
                        Text("Save")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { editingRule = null }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}

@Composable
fun FontSelectionDialog(
    showFontSelectionDialog: Boolean,
    onDismiss: () -> Unit
) {
    // Left as stub if required or if defined. Wait! FontSelectionDialog was defined inside ReaderScreen.kt.
    // Let's bring in the original FontSelectionDialog code under line 3210!
}

@Composable
fun FontItemRow() {
    // Stub or helper
}

@Composable
fun FontDownloadProgressDialog() {
    // Stub or helper
}

@Composable
fun ColorWheelPickerDialog(
    initialColorValue: Int,
    onColorSelected: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedColorCode by remember { mutableStateOf(initialColorValue.toLong() and 0xFFFFFFFFL) }
    var sliderVal by remember { mutableStateOf(0f) }
    
    val finalColor = remember(selectedColorCode, sliderVal) {
        val wheelColor = Color(selectedColorCode)
        if (sliderVal < 0f) {
            blendColors(wheelColor, Color.White, -sliderVal)
        } else {
            blendColors(wheelColor, Color.Black, sliderVal)
        }
    }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth(0.95f)
        ) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.ColorLens, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Select Accent Highlight", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 12.dp))
                
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .clip(CircleShape)
                        .pointerInput(Unit) {
                            detectDragGestures { change, _ ->
                                val position = change.position
                                val radius = size.width / 2f
                                val dx = position.x - radius
                                val dy = position.y - radius
                                val distance = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                if (distance <= radius) {
                                    val angle = Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
                                    val normalizedAngle = if (angle < 0) angle + 360f else angle
                                    val hsvColor = android.graphics.Color.HSVToColor(floatArrayOf(normalizedAngle, 0.85f, 0.95f))
                                    selectedColorCode = hsvColor.toLong() and 0xFFFFFFFFL
                                }
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val canvasSize = size
                        val radius = canvasSize.width / 2f
                        
                        for (angleDegrees in 0 until 360 step 2) {
                            val hsvColor = android.graphics.Color.HSVToColor(floatArrayOf(angleDegrees.toFloat(), 0.85f, 0.95f))
                            drawArc(
                                color = Color(hsvColor),
                                startAngle = angleDegrees.toFloat(),
                                sweepAngle = 3f,
                                useCenter = true
                            )
                        }
                        
                        drawCircle(
                            color = Color.White,
                            radius = radius,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx())
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "Luminance: Light to Dark (White -> Selected -> Black)",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Slider(
                    value = sliderVal,
                    onValueChange = { sliderVal = it },
                    valueRange = -1f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = finalColor,
                        activeTrackColor = finalColor.copy(alpha = 0.6f),
                        inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("White", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                    Text("Selected", fontSize = 10.sp, color = finalColor, fontWeight = FontWeight.Bold)
                    Text("Black", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
                ) {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(
                            text = buildAnnotatedString {
                                append("This is ")
                                withStyle(
                                    style = SpanStyle(
                                        color = finalColor,
                                        background = finalColor.copy(alpha = 0.15f),
                                        fontWeight = FontWeight.Bold
                                    )
                                ) {
                                    append("highlighted text")
                                }
                                append(" in the reader.")
                            },
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(16.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Button(
                    onClick = { onColorSelected(finalColor.toArgb()); onDismiss() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Apply Accent Color", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun NovelTextColorWheelPickerDialog(
    initialColorValue: Long,
    onColorSelected: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedColorCode by remember { mutableStateOf(initialColorValue) }
    var sliderVal by remember { mutableStateOf(0f) }
    
    val finalColor = remember(selectedColorCode, sliderVal) {
        val wheelColor = Color(selectedColorCode)
        if (sliderVal < 0f) {
            blendColors(wheelColor, Color.White, -sliderVal)
        } else {
            blendColors(wheelColor, Color.Black, sliderVal)
        }
    }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth(0.95f)
        ) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.ColorLens, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Select Novel Text Color", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 12.dp))
                
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .clip(CircleShape)
                        .pointerInput(Unit) {
                            detectDragGestures { change, _ ->
                                val position = change.position
                                val radius = size.width / 2f
                                val dx = position.x - radius
                                val dy = position.y - radius
                                val distance = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                if (distance <= radius) {
                                    val angle = Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
                                    val normalizedAngle = if (angle < 0) angle + 360f else angle
                                    val hsvColor = android.graphics.Color.HSVToColor(floatArrayOf(normalizedAngle, 0.85f, 0.95f))
                                    selectedColorCode = hsvColor.toLong() and 0xFFFFFFFFL
                                }
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val canvasSize = size
                        val radius = canvasSize.width / 2f
                        
                        for (angleDegrees in 0 until 360 step 2) {
                            val hsvColor = android.graphics.Color.HSVToColor(floatArrayOf(angleDegrees.toFloat(), 0.85f, 0.95f))
                            drawArc(
                                color = Color(hsvColor),
                                startAngle = angleDegrees.toFloat(),
                                sweepAngle = 3f,
                                useCenter = true
                            )
                        }
                        
                        drawCircle(
                            color = Color.White,
                            radius = radius,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx())
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "Luminance: Light to Dark (White -> Selected -> Black)",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Slider(
                    value = sliderVal,
                    onValueChange = { sliderVal = it },
                    valueRange = -1f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = finalColor,
                        activeTrackColor = finalColor.copy(alpha = 0.6f),
                        inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("White", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                    Text("Selected", fontSize = 10.sp, color = finalColor, fontWeight = FontWeight.Bold)
                    Text("Black", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = finalColor.copy(alpha = 0.15f)),
                    modifier = Modifier.fillMaxWidth().border(1.dp, finalColor.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                ) {
                    Text(
                        text = "The quick brown fox jumps over the lazy dog.",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = finalColor,
                        modifier = Modifier.padding(12.dp),
                        textAlign = TextAlign.Center
                    )
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Button(
                    onClick = { onColorSelected(finalColor.toArgb().toLong() and 0xFFFFFFFFL); onDismiss() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Apply Novel Text Color", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun BgColorWheelPickerDialog(
    initialColorValue: Long,
    isAmoledBlack: Boolean,
    onAmoledChanged: (Boolean) -> Unit,
    onColorSelected: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedColorCode by remember { mutableStateOf(initialColorValue) }
    var useAmoled by remember { mutableStateOf(isAmoledBlack) }
    var sliderVal by remember { mutableStateOf(0f) }
    
    val finalColor = remember(selectedColorCode, sliderVal, useAmoled) {
        if (useAmoled) {
            Color.Black
        } else {
            val wheelColor = Color(selectedColorCode)
            if (sliderVal < 0f) {
                blendColors(wheelColor, Color.White, -sliderVal)
            } else {
                blendColors(wheelColor, Color.Black, sliderVal)
            }
        }
    }
    
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth(0.95f)
        ) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.ColorLens, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Background Color Wheel", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 12.dp))
                
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                        .clickable { 
                            useAmoled = !useAmoled
                        },
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (useAmoled) Color.Black else MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(
                        width = 1.5.dp,
                        color = if (useAmoled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Brightness2,
                                contentDescription = null,
                                tint = if (useAmoled) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "AMOLED Black Mode",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (useAmoled) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = useAmoled,
                            onCheckedChange = { useAmoled = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MaterialTheme.colorScheme.primary,
                                checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    }
                }
                
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .clip(CircleShape)
                        .pointerInput(useAmoled) {
                            if (!useAmoled) {
                                detectDragGestures { change, _ ->
                                    val position = change.position
                                    val radius = size.width / 2f
                                    val dx = position.x - radius
                                    val dy = position.y - radius
                                    val distance = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()
                                    if (distance <= radius) {
                                        val angle = Math.toDegrees(Math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
                                        val normalizedAngle = if (angle < 0) angle + 360f else angle
                                        val hsvColor = android.graphics.Color.HSVToColor(floatArrayOf(normalizedAngle, 0.85f, 0.95f))
                                        selectedColorCode = hsvColor.toLong() and 0xFFFFFFFFL
                                    }
                                }
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val canvasSize = size
                        val radius = canvasSize.width / 2f
                        
                        for (angleDegrees in 0 until 360 step 2) {
                            val hsvColor = android.graphics.Color.HSVToColor(floatArrayOf(angleDegrees.toFloat(), 0.85f, 0.95f))
                            drawArc(
                                color = if (useAmoled) Color.Gray.copy(alpha = 0.3f) else Color(hsvColor),
                                startAngle = angleDegrees.toFloat(),
                                sweepAngle = 3f,
                                useCenter = true
                            )
                        }
                        
                        drawCircle(
                            color = if (useAmoled) Color.White.copy(alpha = 0.5f) else Color.White,
                            radius = radius,
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx())
                        )
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                if (useAmoled) {
                    Text(
                        text = "AMOLED mode overrides background with standard pure black.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        textAlign = TextAlign.Center
                    )
                } else {
                    Text(
                        text = "Luminance: Light to Dark (White -> Selected -> Black)",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Slider(
                        value = sliderVal,
                        onValueChange = { sliderVal = it },
                        valueRange = -1f..1f,
                        colors = SliderDefaults.colors(
                            thumbColor = finalColor,
                            activeTrackColor = finalColor.copy(alpha = 0.6f),
                            inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("White", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                        Text("Selected", fontSize = 10.sp, color = finalColor, fontWeight = FontWeight.Bold)
                        Text("Black", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Button(
                    onClick = {
                        if (useAmoled) {
                            onAmoledChanged(true)
                        } else {
                            onAmoledChanged(false)
                            onColorSelected(finalColor.toArgb().toLong() and 0xFFFFFFFFL)
                        }
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Apply Background Config", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
fun FontItemCard(
    fontName: String,
    isSelected: Boolean,
    readerFontSize: Float,
    onClick: () -> Unit,
    context: android.content.Context,
    modifier: Modifier = Modifier
) {
    val fontFamily = remember(fontName) { resolveFontFamily(fontName, context) }
    val animatedBg by animateColorAsState(
        targetValue = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f),
        animationSpec = tween(200),
        label = "fontItemBg"
    )
    val animatedBorderColor by animateColorAsState(
        targetValue = if (isSelected) MaterialTheme.colorScheme.primary
        else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f),
        animationSpec = tween(200),
        label = "fontItemBorder"
    )
    val animatedBorderWidth by animateDpAsState(
        targetValue = if (isSelected) 1.5.dp else 1.dp,
        animationSpec = tween(200),
        label = "fontItemBorderWidth"
    )

    Card(
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(animatedBorderWidth, animatedBorderColor),
        colors = CardDefaults.cardColors(containerColor = animatedBg),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = fontName,
                    fontFamily = fontFamily,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                if (isSelected) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Selected",
                            tint = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "The quick brown fox jumps over the lazy dog.",
                fontFamily = fontFamily,
                fontSize = readerFontSize.coerceIn(12f, 24f).sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun AlignmentIcon(align: String, tint: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.size(16.dp)) {
        val width = size.width
        val height = size.height
        val lineSpacing = height / 4
        
        when (align) {
            "Left" -> {
                drawLine(color = tint, start = Offset(0f, lineSpacing * 1), end = Offset(width * 0.9f, lineSpacing * 1), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(0f, lineSpacing * 2), end = Offset(width * 0.6f, lineSpacing * 2), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(0f, lineSpacing * 3), end = Offset(width * 0.8f, lineSpacing * 3), strokeWidth = 2.dp.toPx())
            }
            "Center" -> {
                drawLine(color = tint, start = Offset(width * 0.1f, lineSpacing * 1), end = Offset(width * 0.9f, lineSpacing * 1), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(width * 0.25f, lineSpacing * 2), end = Offset(width * 0.75f, lineSpacing * 2), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(width * 0.15f, lineSpacing * 3), end = Offset(width * 0.85f, lineSpacing * 3), strokeWidth = 2.dp.toPx())
            }
            "Right" -> {
                drawLine(color = tint, start = Offset(width * 0.1f, lineSpacing * 1), end = Offset(width, lineSpacing * 1), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(width * 0.4f, lineSpacing * 2), end = Offset(width, lineSpacing * 2), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(width * 0.2f, lineSpacing * 3), end = Offset(width, lineSpacing * 3), strokeWidth = 2.dp.toPx())
            }
            "Justify" -> {
                drawLine(color = tint, start = Offset(0f, lineSpacing * 1), end = Offset(width, lineSpacing * 1), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(0f, lineSpacing * 2), end = Offset(width, lineSpacing * 2), strokeWidth = 2.dp.toPx())
                drawLine(color = tint, start = Offset(0f, lineSpacing * 3), end = Offset(width * 0.7f, lineSpacing * 3), strokeWidth = 2.dp.toPx())
            }
        }
    }
}

@Composable
fun FloatingStylePanel(
    fontSize: Float,
    lineSpacing: Float,
    paragraphSpacing: Float,
    textAlignment: String,
    onClose: () -> Unit,
    onFontSizeChange: (Float) -> Unit,
    onLineSpacingChange: (Float) -> Unit,
    onParagraphSpacingChange: (Float) -> Unit,
    onAlignmentChange: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
        modifier = Modifier.fillMaxWidth().wrapContentHeight()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Box(
                modifier = Modifier
                    .width(40.dp)
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f))
                    .align(Alignment.CenterHorizontally)
            )
            
            Spacer(modifier = Modifier.height(12.dp))

            // HEADER
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.FontDownload,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Customize Typography",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Adjust reading layout & spacing",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                }
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Panel",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            HorizontalDivider(
                color = MaterialTheme.colorScheme.outlineVariant,
                modifier = Modifier.padding(vertical = 12.dp)
            )

            // SLIDERS & CONTROLS SECTION
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Left Column: Font Size & Line Spacing
                Column(modifier = Modifier.weight(1.1f)) {
                    // Size
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Size",
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${fontSize.toInt()}sp",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Slider(
                        value = fontSize,
                        onValueChange = onFontSizeChange,
                        valueRange = 12f..32f,
                        colors = SliderDefaults.colors(
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier.height(28.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Line Spacing
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Line Spacing",
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${"%.1fx".format(lineSpacing)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Slider(
                        value = lineSpacing,
                        onValueChange = onLineSpacingChange,
                        valueRange = 1.0f..2.5f,
                        colors = SliderDefaults.colors(
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier.height(28.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Paragraph Spacing
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Paragraph Spacing",
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${paragraphSpacing.toInt()}dp",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Slider(
                        value = paragraphSpacing,
                        onValueChange = onParagraphSpacingChange,
                        valueRange = 0f..40f,
                        colors = SliderDefaults.colors(
                            activeTrackColor = MaterialTheme.colorScheme.primary,
                            inactiveTrackColor = MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier.height(28.dp)
                    )
                }

                // Right Column: Text Alignment Options
                Column(modifier = Modifier.weight(0.9f)) {
                    Text(
                        text = "Alignment",
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Column(
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        listOf("Left", "Center", "Right", "Justify").forEach { align ->
                            val isSelected = textAlignment == align
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(32.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        if (isSelected) MaterialTheme.colorScheme.primaryContainer 
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable { onAlignmentChange(align) },
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.padding(horizontal = 8.dp)
                                ) {
                                    AlignmentIcon(
                                        align = align,
                                        tint = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Text(
                                        text = align,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 10.sp,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DownloadedFontsDialog(
    viewModel: ReaderViewModel,
    onDismiss: () -> Unit,
    onOpenFontManager: () -> Unit,
    context: android.content.Context
) {
    val currentReaderFont by viewModel.readerFontFamily.collectAsState()
    val currentFontSize by viewModel.readerFontSize.collectAsState()
    var searchQuery by remember { mutableStateOf("") }

    val systemFonts = remember {
        listOf("System Default", "System Serif", "System Monospace", "System Cursive")
    }

    val downloadedFonts = remember(context) {
        val df = FontManagerEngine.getDownloadedFonts(context)
        df.map { it.family }.distinct().filter { font ->
            font !in systemFonts && font != "Serif" && font != "Monospace" && font != "Cursive"
        }
    }

    val filteredSystemFonts = remember(searchQuery, systemFonts) {
        if (searchQuery.isBlank()) systemFonts
        else systemFonts.filter { it.contains(searchQuery, ignoreCase = true) }
    }

    val filteredDownloadedFonts = remember(searchQuery, downloadedFonts) {
        if (searchQuery.isBlank()) downloadedFonts
        else downloadedFonts.filter { it.contains(searchQuery, ignoreCase = true) }
    }

    LorelightDialog(
        onDismissRequest = onDismiss,
        titleContent = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.FontDownload,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Text(
                        text = "Font Selection",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                TextButton(
                    onClick = {
                        onDismiss()
                        onOpenFontManager()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Browse Fonts",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Browse", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close", fontWeight = FontWeight.Bold)
            }
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 480.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search fonts...", fontSize = 13.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        modifier = Modifier.size(18.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear",
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                    unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f),
                    focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (filteredSystemFonts.isNotEmpty()) {
                    item {
                        Text(
                            text = "SYSTEM FONTS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.8.sp,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(start = 4.dp, top = 4.dp, bottom = 4.dp)
                        )
                    }

                    items(filteredSystemFonts, key = { "sys_$it" }) { fontName ->
                        FontItemCard(
                            fontName = fontName,
                            isSelected = fontName == currentReaderFont,
                            readerFontSize = currentFontSize,
                            onClick = {
                                viewModel.readerFontFamily.value = fontName
                                onDismiss()
                            },
                            context = context
                        )
                    }
                }

                if (filteredDownloadedFonts.isNotEmpty() || searchQuery.isBlank()) {
                    item {
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "DOWNLOADED FONTS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (downloadedFonts.isNotEmpty()) {
                                Text(
                                    text = "${downloadedFonts.size} installed",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }

                    if (filteredDownloadedFonts.isEmpty() && searchQuery.isBlank()) {
                        item {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
                                ),
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                                ) {
                                    Text(
                                        text = "No custom fonts downloaded yet.",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Button(
                                        onClick = {
                                            onDismiss()
                                            onOpenFontManager()
                                        },
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                                            contentColor = MaterialTheme.colorScheme.primary
                                        ),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(36.dp),
                                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 0.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Download,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Download Fonts", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    } else {
                        items(filteredDownloadedFonts, key = { "dl_$it" }) { fontName ->
                            FontItemCard(
                                fontName = fontName,
                                isSelected = fontName == currentReaderFont,
                                readerFontSize = currentFontSize,
                                onClick = {
                                    viewModel.readerFontFamily.value = fontName
                                    onDismiss()
                                },
                                context = context
                            )
                        }
                    }
                }

                if (filteredSystemFonts.isEmpty() && filteredDownloadedFonts.isEmpty() && searchQuery.isNotBlank()) {
                    item {
                        Box(
                            modifier = Modifier.fillMaxWidth().padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No fonts match \"$searchQuery\"",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

private val fontFamilyCache = mutableMapOf<String, FontFamily>()

fun getFontFamily(fontName: String): FontFamily {
    return fontFamilyCache.getOrPut(fontName) {
        when (fontName) {
            "System Serif", "Serif" -> FontFamily.Serif
            "System Monospace", "Monospace" -> FontFamily.Monospace
            "System Cursive", "Cursive" -> FontFamily.Cursive
            else -> FontFamily.Default
        }
    }
}

@Composable
fun GlassCollapsibleSection(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isExpanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    GlassPanel(
        modifier = Modifier.fillMaxWidth(),
        cornerRadius = 16.dp,
        tintAlpha = 0.35f
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggle() }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (isExpanded) "Collapse" else "Expand",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                    modifier = Modifier.size(20.dp)
                )
            }
            
            if (isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    content()
                }
            }
        }
    }
}
