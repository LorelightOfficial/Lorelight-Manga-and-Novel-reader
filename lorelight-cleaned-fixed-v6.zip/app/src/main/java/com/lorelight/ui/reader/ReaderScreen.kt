package com.lorelight.ui.reader

import com.lorelight.R
import com.lorelight.ui.theme.*
import com.lorelight.ui.reader.ReaderViewModel
import com.lorelight.data.model.Novel
import com.lorelight.utils.TextFilter
import com.lorelight.utils.FilterRule
import com.lorelight.utils.Token
import com.lorelight.core.getSafeFloat
import com.lorelight.tts.TtsPlaybackManager
import com.lorelight.crawler.CrawlerEngine

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import com.lorelight.ui.components.LorelightDialog
import com.lorelight.ui.components.readerSafeTopPadding
import androidx.compose.runtime.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.distinctUntilChanged
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.zIndex
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import android.content.Context
import android.content.Intent
import android.app.SearchManager
import android.widget.Toast
import androidx.compose.ui.graphics.toArgb

import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.IntOffset
import androidx.compose.foundation.verticalScroll
import kotlin.math.roundToInt

@OptIn(ExperimentalAnimationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    viewModel: ReaderViewModel,
    onClose: () -> Unit,
    onOpenFontManager: () -> Unit
) {
    val context = LocalContext.current
    val activeNovelState by viewModel.activeNovel.collectAsState()

    // FIX #10: the old code read activeNovelState during the FIRST composition,
    // when it is still null, so novelId was "" and load() always returned null.
    // It therefore always seeded (0,0) and this restore path was dead code.
    // Start at 0 and let the restore effect below do the real work once the
    // chapter content actually exists.
    val listState = rememberLazyListState()

    // FIX #1: nothing may be persisted until the position has been restored for
    // the current novel+chapter. Holds "novelId#chapterIndex" once restored.
    var restoredKey by remember { mutableStateOf<String?>(null) }

    // FIX #12: typography fingerprint, kept in state so the save callbacks
    // declared below can reference it.
    var layoutSigState by remember { mutableStateOf(0) }

    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val textFilterRules by viewModel.textFilterRules.collectAsState()
    var selRange by remember { mutableStateOf<WordRange?>(null) }
    var selSentenceIndex by remember { mutableStateOf(-1) }
    var selectionVersion by remember { mutableStateOf(0) }
    var isSelectionPanelCollapsed by remember { mutableStateOf(true) }

    androidx.activity.compose.BackHandler(onBack = {
        if (selRange != null) {
            selRange = null
            selSentenceIndex = -1
            selectionVersion++
            return@BackHandler
        }
        persistReaderPosition(
            context,
            viewModel.activeNovel.value?.id ?: "",
            viewModel.activeChapterIndex.value,
            listState,
            layoutSigState
        )
        viewModel.saveDetailedProgress(
            paragraphIndex = listState.firstVisibleItemIndex,
            scrollOffset = listState.firstVisibleItemScrollOffset,
            wordIndex = viewModel.activeSentenceIndex.value
        )
        onClose()
    })
    
    LaunchedEffect(selRange) {
        if (selRange != null) {
            isSelectionPanelCollapsed = true
        } else {
            selSentenceIndex = -1
        }
    }
    val wordPositions = remember { mutableStateMapOf<Int, WordPosition>() }
    var showTextFilterPanel by remember { mutableStateOf(false) }
    var magnifierText by remember { mutableStateOf<String?>(null) }
    
    val activeNovel by viewModel.activeNovel.collectAsState()
    val chapters by viewModel.chapters.collectAsState()
    val activeChapterIndex by viewModel.activeChapterIndex.collectAsState()
    val activeSentenceIndexState = viewModel.activeSentenceIndex.collectAsState()
    val activeSentenceIndex by activeSentenceIndexState
    val filteredSentences by viewModel.filteredSentences.collectAsState()

    // ---- Companion signals ------------------------------------------------
    // Any real finger scroll counts as motion. He waits for a still screen
    // before speaking, so this is what stops a bubble landing mid-flick.
    LaunchedEffect(listState) {
        snapshotFlow { listState.isScrollInProgress }.collect { scrolling ->
            if (scrolling) com.lorelight.companion.CompanionBus.noteMotion()
        }
    }

    // A chapter that would not load at all. Keyed on the content, so it fires
    // when the failure text arrives rather than on every recomposition, and
    // the bus rate limits him on top of that. "Loading chapter..." is not a
    // failure text, so this does not fire while a fetch is still in flight.
    LaunchedEffect(filteredSentences) {
        val only = filteredSentences.singleOrNull() as? ReaderBlock.TextBlock
        if (only != null &&
            only.text.isNotBlank() &&
            com.lorelight.crawler.CrawlerEngine.isFailureText(only.text)
        ) {
            com.lorelight.companion.CompanionBus.onLoadFailed()
        }
    }
    val cachedChapterIndices by viewModel.cachedChapterIndices.collectAsState()
    val maxPlayableIndex by viewModel.maxPlayableIndex.collectAsState()
    val showBatteryOptimizationDialog by viewModel.showBatteryOptimizationDialog.collectAsState()

    val wordIndexMap by produceState(initialValue = emptyMap<Int, String>(), filteredSentences) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
            val map = mutableMapOf<Int, String>()
            var currentIdx = 0
            filteredSentences.forEach { sentence ->
                val sentenceText = when (sentence) {
                    is ReaderBlock.TextBlock -> sentence.text
                    is ReaderBlock.ImageBlock -> ""
                }
                val (tokens, nextIdx) = TextFilter.tokenize(sentenceText, currentIdx)
                tokens.forEach { tok ->
                    if (tok.isWord && tok.wordIdx >= 0) {
                        map[tok.wordIdx] = tok.raw
                    }
                }
                currentIdx = nextIdx
            }
            map
        }
    }
    val isPlaying by viewModel.isPlaying.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    val fontSize by viewModel.readerFontSize.collectAsState()
    val lineSpacing by viewModel.readerLineSpacing.collectAsState()
    val paragraphSpacing by viewModel.readerParagraphSpacing.collectAsState()
    val textAlignment by viewModel.readerTextAlignment.collectAsState()
    val readerBgColorRaw by viewModel.readerBgColor.collectAsState()
    val readerTextColorRaw by viewModel.readerTextColor.collectAsState()
    val sleepTimerMinutes by viewModel.sleepTimerMinutes.collectAsState()

    LaunchedEffect(fontSize, lineSpacing, paragraphSpacing) {
        layoutSigState = ReadingPositionStore.layoutSignature(
            fontSize, lineSpacing, paragraphSpacing
        )
    }

    val readerFontFamily by viewModel.readerFontFamily.collectAsState()
    val tokensBySentence by viewModel.tokensBySentence.collectAsState()
    val isFetchingChapter by viewModel.isFetchingChapter.collectAsState()
    val readerMode by viewModel.readerMode.collectAsState()
    val isDefaultHighlight by viewModel.isDefaultHighlight.collectAsState()
    val customHighlightColorRaw by viewModel.customHighlightColor.collectAsState()
    val readerBackgroundType by viewModel.readerBackgroundType.collectAsState()
    val themeState by viewModel.appTheme.collectAsState()
    val highlights by viewModel.highlights.collectAsState()

    // Resolve themed colors
    val themeBgColor = remember(themeState) { getThemeBgColor(themeState) }
    val themeTextColor = remember(themeState) { getThemeTextColor(themeState) }

    val readerBgColor = remember(readerBackgroundType, readerBgColorRaw, themeBgColor) {
        if (readerBackgroundType == "AMOLED Black") {
            Color.Black
        } else if (readerBackgroundType == "Theme") {
            themeBgColor
        } else {
            if (readerBgColorRaw == 0xFF1C1B1FL) themeBgColor else Color(readerBgColorRaw)
        }
    }

    val readerTextColor = remember(readerBgColor, readerBackgroundType, readerTextColorRaw, themeTextColor, themeState) {
        if (readerTextColorRaw != 0xFFE6E1E5L) {
            Color(readerTextColorRaw)
        } else if (readerBackgroundType == "Theme") {
            themeTextColor
        } else if (readerBgColor == Color.Black) {
            if (themeState == "readerwhite") Color(0xFFE4E4E7) else {
                when (themeState) {
                    "blackgold" -> Color(0xFFE9C484)
                    "Satin Pink" -> Color(0xFFEBC7D5)
                    "cyne" -> Color(0xFFC2F3F8)
                    else -> Color(0xFFE4E4E7)
                }
            }
        } else {
            themeTextColor
        }
    }

    val defaultHighlightColor = remember(themeState) { getDefaultHighlightColor(themeState) }

    val readerHighlightColor = remember(themeState, isDefaultHighlight, defaultHighlightColor, customHighlightColorRaw) {
        if (themeState == "readerblacknew") {
            Color(0xFF888888)
        } else if (isDefaultHighlight) {
            defaultHighlightColor
        } else {
            Color(customHighlightColorRaw)
        }
    }

    // Dynamic Edge-to-Edge Status Bar Icon Color Controller
    val view = androidx.compose.ui.platform.LocalView.current
    if (!view.isInEditMode) {
        val activity = remember(context) {
            var currentContext = context
            while (currentContext is android.content.ContextWrapper) {
                if (currentContext is android.app.Activity) {
                    break
                }
                currentContext = currentContext.baseContext
            }
            currentContext as? android.app.Activity
        }
        
        activity?.let { act ->
            val isDark = (0.299f * readerBgColor.red + 0.587f * readerBgColor.green + 0.114f * readerBgColor.blue) < 0.5f
            SideEffect {
                act.window.statusBarColor = android.graphics.Color.TRANSPARENT
                androidx.core.view.WindowCompat.getInsetsController(act.window, view).isAppearanceLightStatusBars = !isDark
            }

            val immersive by viewModel.immersiveMode.collectAsState()
            DisposableEffect(immersive) {
                val controller = androidx.core.view.WindowCompat.getInsetsController(act.window, view)
                if (immersive) {
                    controller.systemBarsBehavior =
                        androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                    controller.hide(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                } else {
                    controller.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                }
                onDispose {
                    controller.show(androidx.core.view.WindowInsetsCompat.Type.systemBars())
                }
            }
        }
    }

    val volumeKeysEnabled by viewModel.volumeKeysEnabled.collectAsState()

    DisposableEffect(volumeKeysEnabled, readerMode) {
        VolumeKeyBus.active = volumeKeysEnabled && readerMode != "Listen"
        onDispose { VolumeKeyBus.active = false }
    }

    var showChapterDrawer by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showSleepTimerMenu by remember { mutableStateOf(false) }
    var showFloatingStylePanel by remember { mutableStateOf(false) }

    val chaptersListState = rememberLazyListState()

    // Autoscroll premium states
    val readerPrefs = remember { context.getSharedPreferences("reader_prefs", android.content.Context.MODE_PRIVATE) }
    // FIX #19: honour the keep-screen-on preference. Stored in reader_prefs
    // alongside the other reader settings.
    val keepScreenOnPref = remember { readerPrefs.getBoolean("reader_keep_screen_on", true) }
    
    var isAutoScrollActive by remember { mutableStateOf(false) }
    var autoScrollSpeed by remember {
        mutableStateOf(readerPrefs.getSafeFloat("reader_autoscroll_speed", 30f).coerceIn(1f, 100f))
    }
    var showAutoScrollPanel by remember { mutableStateOf(false) }
    var autoScrollInteractionTrigger by remember { mutableStateOf(0) }

    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(isPlaying) {
        VolumeKeyBus.events.collect { dir ->
            if (isPlaying) return@collect
            val info = listState.layoutInfo
            val viewport = (info.viewportEndOffset - info.viewportStartOffset).toFloat()
            if (viewport <= 0f) return@collect
            // ~8% overlap so no line is skipped across the seam
            val step = viewport * 0.92f * dir
            coroutineScope.launch { listState.animateScrollBy(step) }
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    val slideOffset = remember { Animatable(0f) }   // in pixels
    var containerWidthPx by remember { mutableStateOf(0f) }

    LaunchedEffect(Unit) {
        var prevIndex = activeChapterIndex
        snapshotFlow { activeChapterIndex }.collect { newIndex ->
            if (newIndex != prevIndex) {
                val forward = newIndex > prevIndex          // Next = true, Previous = false
                val inForeground =
                    lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
                if (inForeground && containerWidthPx > 0f) {
                    val start = if (forward) containerWidthPx else -containerWidthPx   // new page enters from that side
                    slideOffset.snapTo(start)
                    slideOffset.animateTo(0f, tween(durationMillis = 260, easing = FastOutSlowInEasing))
                } else {
                    slideOffset.snapTo(0f)
                }
                prevIndex = newIndex
            }
        }
    }
    


    LaunchedEffect(readerMode) {
        if (readerMode == "Read") {
            viewModel.pauseSpeaking()
        } else if (readerMode == "Listen") {
            isAutoScrollActive = false
            showAutoScrollPanel = false
        }
    }

    LaunchedEffect(showChapterDrawer) {
        if (showChapterDrawer) {
            viewModel.recomputeCachedChapters()
        }
    }

    // Auto-dismiss short-lived panel after 5 seconds of inactivity
    LaunchedEffect(showAutoScrollPanel, autoScrollSpeed, isAutoScrollActive, autoScrollInteractionTrigger) {
        if (showAutoScrollPanel) {
            kotlinx.coroutines.delay(5000L)
            showAutoScrollPanel = false
        }
    }

    // smooth autoscroll animation loop
    val density = androidx.compose.ui.platform.LocalDensity.current.density
    LaunchedEffect(isAutoScrollActive, autoScrollSpeed) {
        if (isAutoScrollActive) {
            var lastTimeNanos = System.nanoTime()
            while (true) {
                androidx.compose.runtime.withFrameNanos { }
                val currentTimeNanos = System.nanoTime()
                val elapsedSeconds = (currentTimeNanos - lastTimeNanos).coerceAtLeast(0L) / 1_000_000_000f
                lastTimeNanos = currentTimeNanos
                if (elapsedSeconds > 0f) {
                    val speedPx = autoScrollSpeed * density
                    val deltaPx = speedPx * elapsedSeconds
                    val consumed = listState.scrollBy(deltaPx)
                    if (consumed == 0f && deltaPx > 0.05f && !listState.canScrollForward) {
                        isAutoScrollActive = false
                    }
                }
            }
        }
    }

    LaunchedEffect(autoScrollSpeed) {
        readerPrefs.edit().putFloat("reader_autoscroll_speed", autoScrollSpeed).apply()
    }

    // FIX #1 / #2 / #7 / #8: this collector used to start immediately and write
    // unconditionally, so it persisted (0,0) BEFORE the restore effect ever ran -
    // which is what silently reset everyone's reading position to the top of the
    // chapter. It now refuses to write until restoredKey matches the current
    // novel+chapter.
    // FIX #6: conflate + a settle delay instead of a blocking write per frame.
    LaunchedEffect(listState) {
        snapshotFlow {
            val nId = viewModel.activeNovel.value?.id ?: ""
            val cIdx = viewModel.activeChapterIndex.value
            Triple(
                "$nId#$cIdx",
                listState.firstVisibleItemIndex,
                listState.firstVisibleItemScrollOffset
            )
        }
            .distinctUntilChanged()
            .conflate()
            .collect { (key, _, _) ->
                kotlinx.coroutines.delay(250L)
                if (restoredKey != key) return@collect
                persistReaderPosition(
                    context,
                    viewModel.activeNovel.value?.id ?: "",
                    viewModel.activeChapterIndex.value,
                    listState,
                    layoutSigState
                )
            }
    }

    LaunchedEffect(listState) {
        listState.interactionSource.interactions.collect { interaction ->
            if (interaction is androidx.compose.foundation.interaction.DragInteraction.Start) {
                isAutoScrollActive = false
            }
        }
    }

    val lifecycleState by lifecycleOwner.lifecycle.currentStateFlow.collectAsState()
    val isResumed = lifecycleState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)
    var isFirstScroll by remember { mutableStateOf(true) }

    var lastChapterIdx by remember { mutableStateOf(-1) }
    LaunchedEffect(activeChapterIndex) {
        selRange = null
        selSentenceIndex = -1
        selectionVersion++
        wordPositions.clear()
        if (activeChapterIndex != lastChapterIdx && lastChapterIdx != -1) {
            // FIX #2 / #8: entering a different chapter invalidates the restore
            // marker, so the saver stays disabled until the NEW chapter's own
            // position has been restored. Without this, the scrollToItem(0, 0)
            // below was immediately persisted as "progress = top of chapter".
            // (The old !isFirstScroll wrapper is redundant: lastChapterIdx == -1
            // already covers the first composition.)
            restoredKey = null
            try {
                listState.scrollToItem(0, 0)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        lastChapterIdx = activeChapterIndex
    }

    LaunchedEffect(activeSentenceIndex, filteredSentences, isResumed, activeChapterIndex, isFetchingChapter) {
        if (isResumed && filteredSentences.isNotEmpty()) {
            val targetIdx = activeSentenceIndex.coerceIn(0, filteredSentences.lastIndex)
            val novelId = viewModel.activeNovel.value?.id ?: ""
            val chapterIdx = activeChapterIndex
            val key = "$novelId#$chapterIdx"
            if (restoredKey != key) {
                isFirstScroll = false
                if (novelId.isEmpty() || chapterIdx < 0) return@LaunchedEffect
                // FIX #17: while a chapter is being fetched, filteredSentences
                // holds a single "Loading chapter..." placeholder block. It is
                // non-empty, so without these two guards the restore runs against
                // a 1-item list, clamps the position to 0, AND sets restoredKey -
                // meaning the real content never gets restored at all.
                // CRITICAL: return WITHOUT assigning restoredKey, so this effect
                // runs again when the real content arrives.
                if (isFetchingChapter) return@LaunchedEffect
                if (isPlaceholderContent(filteredSentences)) return@LaunchedEffect
                // FIX #14: wait until the list has actually laid out items.
                // Restoring against an empty list clamped everything to 0.
                snapshotFlow { listState.layoutInfo.totalItemsCount }.first { it > 0 }
                val total = listState.layoutInfo.totalItemsCount
                val stored = ReadingPositionStore.load(context, novelId, chapterIdx)
                val para: Int
                val offset: Int
                if (stored != null) {
                    if (stored.layoutSig != layoutSigState && stored.fraction > 0f) {
                        // FIX #12: typography changed since this was saved, so the
                        // stored pixel offset is meaningless. Fall back to the
                        // fraction, which is reflow-proof.
                        para = ((stored.fraction * total).toInt() - 1).coerceIn(0, total - 1)
                        offset = 0
                    } else {
                        para = stored.index.coerceIn(0, total - 1)
                        offset = stored.offset.coerceAtLeast(0)
                    }
                } else {
                    para = (viewModel.activeNovel.value?.currentParagraphIndex ?: targetIdx)
                        .coerceIn(0, total - 1)
                    offset = (viewModel.activeNovel.value?.currentScrollOffset ?: 0)
                        .coerceAtLeast(0)
                }
                try {
                    listState.scrollToItem(para, offset)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
                restoredKey = key   // FIX #1: only NOW may the saver run
                return@LaunchedEffect
            }
            if (isPlaying && !listState.isScrollInProgress) {
                kotlinx.coroutines.delay(200)
                if (!listState.isScrollInProgress) {
                    val layoutInfo = listState.layoutInfo
                    val viewportHeight = layoutInfo.viewportEndOffset - layoutInfo.viewportStartOffset
                    if (viewportHeight > 0) {
                        // Skip the scroll animation entirely if the sentence is already comfortably on screen.
                        val visibleItem = layoutInfo.visibleItemsInfo.firstOrNull { it.index == targetIdx }
                        val comfortZoneTop = layoutInfo.viewportStartOffset + viewportHeight / 8
                        val comfortZoneBottom = layoutInfo.viewportStartOffset + (viewportHeight * 2) / 3
                        val alreadyComfortable = visibleItem != null &&
                            visibleItem.offset >= comfortZoneTop &&
                            (visibleItem.offset + visibleItem.size) <= comfortZoneBottom
                        if (!alreadyComfortable) {
                            val centerOffset = -(viewportHeight / 3)
                            try {
                                listState.animateScrollToItem(targetIdx, centerOffset)
                            } catch (e: Exception) { e.printStackTrace() }
                        }
                    }
                }
            }
        }
    }

    val localView = androidx.compose.ui.platform.LocalView.current
    DisposableEffect(isPlaying, keepScreenOnPref) {
        // FIX #19: screen-on now follows the user preference while the reader is
        // open, and still forces on during TTS playback regardless of the
        // preference (audio playback with the screen sleeping is the expected
        // case, but the reader was previously the ONLY thing keeping it awake).
        localView.keepScreenOn = isPlaying || keepScreenOnPref
        onDispose {
            localView.keepScreenOn = false
        }
    }

    LaunchedEffect(showChapterDrawer) {
        if (showChapterDrawer && activeChapterIndex in chapters.indices) {
            kotlinx.coroutines.delay(120)
            val viewportSize = chaptersListState.layoutInfo.viewportEndOffset - chaptersListState.layoutInfo.viewportStartOffset
            if (viewportSize > 0) {
                chaptersListState.scrollToItem(activeChapterIndex, -(viewportSize / 2 - 120))
            } else {
                chaptersListState.scrollToItem((activeChapterIndex - 3).coerceAtLeast(0))
            }
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                TtsPlaybackManager.isAppInBackground.value = false
            } else if (event == androidx.lifecycle.Lifecycle.Event.ON_STOP) {
                TtsPlaybackManager.isAppInBackground.value = true
                persistReaderPosition(
                    context,
                    viewModel.activeNovel.value?.id ?: "",
                    viewModel.activeChapterIndex.value,
                    listState,
                    layoutSigState
                )
                viewModel.saveDetailedProgress(
                    paragraphIndex = listState.firstVisibleItemIndex,
                    scrollOffset = listState.firstVisibleItemScrollOffset,
                    wordIndex = viewModel.activeSentenceIndex.value
                )
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(readerBgColor)
    ) {
        // Decorative Hero Background images for specialized styled themes.
        // Guarded on the RESOLVED color, not just the "AMOLED Black" chip:
        // the AMOLED app theme also resolves to pure black, and painting a
        // texture over black is what turned it grey. Alpha matches the reader
        // content layer so the two do not stack into a washed-out grey.
        if (readerBgColor != Color.Black && (readerBackgroundType == "Theme" || readerBgColorRaw == 0xFF1C1B1FL)) {
            val bgRes = when (themeState) {
                "blackgold" -> R.drawable.readergold
                "Satin Pink" -> R.drawable.readerpink
                "Ocean Blue" -> R.drawable.readerblue
                "cyne" -> R.drawable.readercyne
                "readerpurple" -> R.drawable.readerpurple
                "readerblood" -> R.drawable.readerred
                else -> R.drawable.readergreen
            }
            Image(
                painter = painterResource(id = bgRes),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(0.20f)
            )
        }



        Box(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
            ) {
                Scaffold(
                    containerColor = Color.Transparent,
                    topBar = {
                ReaderToolbar(
                    activeNovel = activeNovel,
                    chapters = chapters,
                    activeChapterIndex = activeChapterIndex,
                    readerMode = readerMode,
                    sleepTimerMinutes = sleepTimerMinutes,
                    isAutoScrollActive = isAutoScrollActive,
                    readerHighlightColor = readerHighlightColor,
                    onClose = {
                        persistReaderPosition(
                            context,
                            viewModel.activeNovel.value?.id ?: "",
                            viewModel.activeChapterIndex.value,
                            listState,
                            layoutSigState
                        )
                        viewModel.saveDetailedProgress(
                            paragraphIndex = listState.firstVisibleItemIndex,
                            scrollOffset = listState.firstVisibleItemScrollOffset,
                            wordIndex = viewModel.activeSentenceIndex.value
                        )
                        onClose()
                    },
                    onSetSleepTimer = { minutes -> viewModel.setSleepTimer(minutes); Unit },
                    onToggleChapters = { showChapterDrawer = !showChapterDrawer },
                    onToggleAutoScroll = { showAutoScrollPanel = !showAutoScrollPanel },
                    onOpenSettings = { showSettingsDialog = true }
                )
            },
            bottomBar = {
                if (readerMode == "Listen") {
                    ReaderBottomControls(
                        isPlaying = isPlaying,
                        readerBgColor = readerBgColor,
                        readerTextColor = readerTextColor,
                        readerHighlightColor = readerHighlightColor,
                        themeState = themeState,
                        activeChapterIndex = activeChapterIndex,
                        chaptersCount = chapters.size,
                        onPrevChapter = {
                            if (activeChapterIndex > 0) {
                                viewModel.prevChapter()
                            }
                        },
                        onNextChapter = {
                            if (activeChapterIndex < chapters.size - 1) {
                                viewModel.nextChapter()
                            }
                        },
                        onSkipBackward = { viewModel.skipBackward() },
                        onSkipForward = { viewModel.skipForward() },
                        onTogglePlayPause = { viewModel.togglePlayPause() }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(
                        top = innerPadding.calculateTopPadding(),
                        bottom = 0.dp
                    )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .onSizeChanged { containerWidthPx = it.width.toFloat() }
                        .graphicsLayer { translationX = slideOffset.value }
                ) {
                    ReaderContent(
                        listState = listState,
                        readerBackgroundType = readerBackgroundType,
                        themeState = themeState,
                        readerBgColor = readerBgColor,
                        readerTextColor = readerTextColor,
                        readerHighlightColor = readerHighlightColor,
                        filteredSentences = filteredSentences,
                        novelId = activeNovel?.id ?: "",
                        tokensBySentence = tokensBySentence,
                        activeSentenceIndexState = activeSentenceIndexState,
                        readerMode = readerMode,
                        fontSize = fontSize,
                        lineSpacing = lineSpacing,
                        paragraphSpacing = paragraphSpacing,
                        textAlignment = textAlignment,
                        readerFontFamily = readerFontFamily,
                        selRange = selRange,
                        selectionVersion = selectionVersion,
                        wordPositions = wordPositions,
                        wordIndexMap = wordIndexMap,
                        activeChapterIndex = activeChapterIndex,
                        chapters = chapters,
                        highlights = highlights,
                        onSentenceClick = { index ->
                            viewModel.jumpToSentence(index)
                        },
                        onWordSelected = { range, isDragging ->
                            selRange = range
                        },
                        onPositioned = { idx, left, right ->
                            wordPositions[idx] = WordPosition(left, right)
                        },
                        onParagraphLongClick = { index ->
                            selSentenceIndex = index
                        },
                        onChapterSelect = { index ->
                            viewModel.selectChapter(index)
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }

                val isTapNavigationEnabled by viewModel.isTapNavigationEnabled.collectAsState()
                if (isTapNavigationEnabled) {
                    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                        val width = constraints.maxWidth
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(Unit) {
                                    detectTapGestures { offset ->
                                        val x = offset.x
                                        val leftThreshold = width * 0.2f
                                        val rightThreshold = width * 0.8f
                                        
                                        coroutineScope.launch {
                                            if (x < leftThreshold) {
                                                val targetIndex = (listState.firstVisibleItemIndex - 3).coerceAtLeast(0)
                                                listState.scrollToItem(targetIndex)
                                            } else if (x > rightThreshold) {
                                                val targetIndex = (listState.firstVisibleItemIndex + 3).coerceAtMost(filteredSentences.size - 1)
                                                listState.scrollToItem(targetIndex)
                                            } else {
                                                showSettingsDialog = !showSettingsDialog
                                            }
                                        }
                                    }
                                }
                        )
                    }
                }

                // Auto-Scroll Speed Adjustment Panel
                AnimatedVisibility(
                    visible = showAutoScrollPanel && readerMode == "Read",
                    enter = slideInVertically(initialOffsetY = { -it / 2 }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { -it / 2 }) + fadeOut(),
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 8.dp, end = 12.dp)
                        .zIndex(99f)
                ) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = readerBgColor),
                        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                        modifier = Modifier
                            .width(260.dp)
                            .border(1.dp, readerTextColor.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .padding(horizontal = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Play/Pause button (takes 30% of the row space)
                            Box(
                                modifier = Modifier
                                    .weight(0.3f)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                FilledIconButton(
                                    onClick = { 
                                        isAutoScrollActive = !isAutoScrollActive 
                                        autoScrollInteractionTrigger++
                                    },
                                    colors = IconButtonDefaults.filledIconButtonColors(
                                        containerColor = readerHighlightColor,
                                        contentColor = if (themeState == "blackgold") Color(0xFF2E1901) else Color.White
                                    ),
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isAutoScrollActive) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play/Pause Auto-scroll",
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            // Slider area (takes 70% of the row space)
                            Row(
                                modifier = Modifier
                                    .weight(0.7f)
                                    .fillMaxHeight(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Slider(
                                    value = autoScrollSpeed,
                                    onValueChange = { 
                                        autoScrollSpeed = it
                                        autoScrollInteractionTrigger++
                                    },
                                    valueRange = 1f..150f,
                                    colors = SliderDefaults.colors(
                                        thumbColor = readerHighlightColor,
                                        activeTrackColor = readerHighlightColor,
                                        inactiveTrackColor = readerTextColor.copy(alpha = 0.15f)
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(24.dp)
                                        .padding(horizontal = 4.dp)
                                )
                                Text(
                                    text = "${autoScrollSpeed.toInt()}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = readerTextColor,
                                    modifier = Modifier
                                        .padding(end = 4.dp)
                                        .width(22.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Floating Sleep Timer selector Dialog
        if (showSleepTimerMenu) {
            Dialog(onDismissRequest = { showSleepTimerMenu = false }) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .border(1.dp, readerHighlightColor.copy(alpha = 0.25f), RoundedCornerShape(24.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Timer, contentDescription = null, tint = readerHighlightColor)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("TTS Sleep Timer", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Playback stops automatically after designated duration.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f), modifier = Modifier.align(Alignment.Start))
                        
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 12.dp))
                        
                        val sleepOptions = listOf(0, 5, 10, 15, 30, 45, 60)
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            sleepOptions.forEach { minutes ->
                                val isActive = sleepTimerMinutes == minutes
                                Card(
                                    onClick = {
                                        viewModel.setSleepTimer(minutes)
                                        showSleepTimerMenu = false
                                    },
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isActive) readerHighlightColor.copy(alpha = 0.15f) else Color.Transparent
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 16.dp, vertical = 12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = if (minutes == 0) "Disabled (Play Continuously)" else "$minutes Minutes",
                                            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 14.sp,
                                            color = if (isActive) readerHighlightColor else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (isActive) {
                                            Icon(Icons.Default.Check, contentDescription = "Active", tint = readerHighlightColor, modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        TextButton(onClick = { showSleepTimerMenu = false }) {
                            Text("Cancel", fontWeight = FontWeight.Bold, color = readerTextColor.copy(alpha = 0.8f))
                        }
                    }
                }
            }
        }

        // Floating shortcut settings toolbar
        AnimatedVisibility(
            visible = showFloatingStylePanel,
            enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it / 2 }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 96.dp)
                .padding(horizontal = 24.dp)
                .zIndex(98f)
        ) {
            FloatingStylePanel(
                fontSize = fontSize,
                lineSpacing = lineSpacing,
                paragraphSpacing = paragraphSpacing,
                textAlignment = textAlignment,
                onClose = { showFloatingStylePanel = false },
                onFontSizeChange = { viewModel.readerFontSize.value = it },
                onLineSpacingChange = { viewModel.readerLineSpacing.value = it },
                onParagraphSpacingChange = { viewModel.readerParagraphSpacing.value = it },
                onAlignmentChange = { viewModel.readerTextAlignment.value = it }
            )
        }

        // Selection Draggable Handles Overlay & Floating Action Bar
        val selectedTextPreview = remember(selRange, filteredSentences) {
            val range = selRange
            if (range == null) "" else {
                val minIdx = minOf(range.start, range.end)
                val maxIdx = maxOf(range.start, range.end)
                val allRawTokens = mutableListOf<Token>()
                var currentWordIdx = 0
                filteredSentences.forEach { sentence ->
                    val sentenceText = when (sentence) {
                        is ReaderBlock.TextBlock -> sentence.text
                        is ReaderBlock.ImageBlock -> ""
                    }
                    val (raw, nextIdx) = TextFilter.tokenize(sentenceText, currentWordIdx)
                    allRawTokens.addAll(raw)
                    currentWordIdx = nextIdx
                }
                val firstTokIdx = allRawTokens.indexOfFirst { it.wordIdx == minIdx }
                val lastTokIdx = allRawTokens.indexOfLast { it.wordIdx == maxIdx }
                if (firstTokIdx != -1 && lastTokIdx != -1 && firstTokIdx <= lastTokIdx) {
                    allRawTokens.subList(firstTokIdx, lastTokIdx + 1)
                        .joinToString("") { it.raw }
                        .trim()
                } else {
                    allRawTokens.filter { it.wordIdx in minIdx..maxIdx }
                        .joinToString("") { it.raw }
                        .trim()
                }
            }
        }

        selRange?.let { range ->
            var overlayRootOffset by remember { mutableStateOf(Offset.Zero) }
            
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .zIndex(998f)
                    .onGloballyPositioned { overlayRootOffset = it.localToRoot(Offset.Zero) }
            ) {
                val selMin = minOf(range.start, range.end)
                val selMax = maxOf(range.start, range.end)
                // The opposite end of the selection, snapshotted when a drag begins
                // so it stays fixed for the whole gesture.
                var dragFixedEnd by remember { mutableStateOf(selMax) }
                var dragFixedStart by remember { mutableStateOf(selMin) }
                val startAnchor = wordPositions[selMin]?.leftAnchor
                val endAnchor = wordPositions[selMax]?.rightAnchor
                
                val handleRadiusDp = 11.dp
                val touchPaddingDp = 12.dp
                val density = LocalDensity.current
                val handleRadiusPx = with(density) { handleRadiusDp.toPx() }
                val touchPaddingPx = with(density) { touchPaddingDp.toPx() }

                // Start Handle (Left / Top-Right teardrop)
                startAnchor?.let { anchor ->
                    var accumulatedStartDrag by remember { mutableStateOf(Offset.Zero) }
                    
                    Box(
                        modifier = Modifier
                            .offset {
                                IntOffset(
                                    (anchor.x - overlayRootOffset.x - handleRadiusPx - touchPaddingPx).roundToInt(),
                                    (anchor.y - overlayRootOffset.y - touchPaddingPx).roundToInt()
                                )
                            }
                            .size(46.dp)
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = {
                                        // Read live state at drag start. pointerInput(Unit)
                                        // never restarts, so captured values would go stale.
                                        val live = selRange
                                        val liveMin = live?.let { minOf(it.start, it.end) } ?: 0
                                        dragFixedEnd = live?.let { maxOf(it.start, it.end) } ?: liveMin
                                        accumulatedStartDrag = wordPositions[liveMin]?.leftAnchor ?: anchor
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        accumulatedStartDrag += dragAmount
                                        var closestIdx = -1
                                        var minDistance = Float.MAX_VALUE
                                        for ((idx, wPos) in wordPositions) {
                                            val wordCenter = Offset(
                                                (wPos.leftAnchor.x + wPos.rightAnchor.x) / 2f,
                                                (wPos.leftAnchor.y + wPos.rightAnchor.y) / 2f
                                            )
                                            val distX = accumulatedStartDrag.x - wordCenter.x
                                            val distY = accumulatedStartDrag.y - wordCenter.y
                                            val dist = distX * distX + distY * distY
                                            if (dist < minDistance) {
                                                minDistance = dist
                                                closestIdx = idx
                                            }
                                        }
                                        if (closestIdx != -1) {
                                            val newMin = minOf(closestIdx, dragFixedEnd)
                                            val newMax = maxOf(closestIdx, dragFixedEnd)
                                            if (selRange?.start != newMin || selRange?.end != newMax) {
                                                selRange = WordRange(newMin, newMax)
                                                try {
                                                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                                                } catch (_: Exception) {}
                                            }
                                        }
                                    },
                                    onDragEnd = {},
                                    onDragCancel = {}
                                )
                            }
                            .padding(touchPaddingDp)
                    ) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .shadow(2.dp, shape = CircleShape)
                        ) {
                            val r = size.width / 2f
                            val path = Path().apply {
                                moveTo(r, 0f)
                                arcTo(
                                    rect = Rect(0f, 0f, 2 * r, 2 * r),
                                    startAngleDegrees = -90f,
                                    sweepAngleDegrees = 270f,
                                    forceMoveTo = false
                                )
                                close()
                            }
                            drawPath(path = path, color = readerHighlightColor)
                        }
                    }
                }

                // End Handle (Right / Top-Left teardrop)
                endAnchor?.let { anchor ->
                    var accumulatedEndDrag by remember { mutableStateOf(Offset.Zero) }
                    
                    Box(
                        modifier = Modifier
                            .offset {
                                IntOffset(
                                    (anchor.x - overlayRootOffset.x - handleRadiusPx - touchPaddingPx).roundToInt(),
                                    (anchor.y - overlayRootOffset.y - touchPaddingPx).roundToInt()
                                )
                            }
                            .size(46.dp)
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = {
                                        val live = selRange
                                        val liveMax = live?.let { maxOf(it.start, it.end) } ?: 0
                                        dragFixedStart = live?.let { minOf(it.start, it.end) } ?: liveMax
                                        accumulatedEndDrag = wordPositions[liveMax]?.rightAnchor ?: anchor
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        accumulatedEndDrag += dragAmount
                                        var closestIdx = -1
                                        var minDistance = Float.MAX_VALUE
                                        for ((idx, wPos) in wordPositions) {
                                            val wordCenter = Offset(
                                                (wPos.leftAnchor.x + wPos.rightAnchor.x) / 2f,
                                                (wPos.leftAnchor.y + wPos.rightAnchor.y) / 2f
                                            )
                                            val distX = accumulatedEndDrag.x - wordCenter.x
                                            val distY = accumulatedEndDrag.y - wordCenter.y
                                            val dist = distX * distX + distY * distY
                                            if (dist < minDistance) {
                                                minDistance = dist
                                                closestIdx = idx
                                            }
                                        }
                                        if (closestIdx != -1) {
                                            val newMin = minOf(dragFixedStart, closestIdx)
                                            val newMax = maxOf(dragFixedStart, closestIdx)
                                            if (selRange?.start != newMin || selRange?.end != newMax) {
                                                selRange = WordRange(newMin, newMax)
                                                try {
                                                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                                                } catch (_: Exception) {}
                                            }
                                        }
                                    },
                                    onDragEnd = {},
                                    onDragCancel = {}
                                )
                            }
                            .padding(touchPaddingDp)
                    ) {
                        Canvas(
                            modifier = Modifier
                                .fillMaxSize()
                                .shadow(2.dp, shape = CircleShape)
                        ) {
                            val r = size.width / 2f
                            val path = Path().apply {
                                moveTo(r, 0f)
                                arcTo(
                                    rect = Rect(0f, 0f, 2 * r, 2 * r),
                                    startAngleDegrees = -90f,
                                    sweepAngleDegrees = -270f,
                                    forceMoveTo = false
                                )
                                close()
                            }
                            drawPath(path = path, color = readerHighlightColor)
                        }
                    }
                }
            }
        }

        // Sliding Bottom Action Bar on Selection
        AnimatedVisibility(
            visible = selRange != null && !isSelectionPanelCollapsed,
            enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(300)) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(200)) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .zIndex(999f)
        ) {
            val cleanedMatch = remember(selectedTextPreview) {
                val base = selectedTextPreview.trim().replace(Regex("\\s+"), " ")
                val stripped = base.trim('"', '\u201C', '\u201D', ',', '.', ';', ':', '!', '?')
                // If the selection is only punctuation, stripping would empty it and
                // disable the Add button. Keep the raw selection in that case.
                if (stripped.isBlank()) base else stripped
            }
            
            var isVanish by remember { mutableStateOf(true) }
            var replacementText by remember { mutableStateOf("") }
            var selectedScope by remember { mutableStateOf("All Books") }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .background(readerBgColor)
                    .border(1.dp, readerHighlightColor.copy(alpha = 0.3f), RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Create Filter Rule",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = readerTextColor
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        IconButton(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Selected Text", cleanedMatch))
                            Toast.makeText(context, "Copied", Toast.LENGTH_SHORT).show()
                            selRange = null
                            selSentenceIndex = -1
                            selectionVersion++
                        }) {
                            Icon(
                                Icons.Default.ContentCopy,
                                contentDescription = "Copy text",
                                tint = readerTextColor.copy(alpha = 0.6f)
                            )
                        }
                        IconButton(onClick = { 
                            isSelectionPanelCollapsed = true 
                        }) {
                            Icon(
                                Icons.Default.KeyboardArrowDown,
                                contentDescription = "Minimize selection panel",
                                tint = readerTextColor.copy(alpha = 0.6f)
                            )
                        }
                        IconButton(onClick = { 
                            selRange = null 
                            selSentenceIndex = -1
                            selectionVersion++
                        }) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Cancel selection",
                                tint = readerTextColor.copy(alpha = 0.6f)
                            )
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(readerTextColor.copy(alpha = 0.06f))
                        .border(0.5.dp, readerTextColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = "Match: \"$cleanedMatch\"",
                        fontSize = 13.sp,
                        color = readerTextColor,
                        fontStyle = FontStyle.Italic
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                AdaptiveChoiceChips(
                    options = listOf(
                        "vanish" to "Vanish \uD83D\uDEAB",
                        "replace" to "Replace \u270F\uFE0F"
                    ),
                    selectedKey = if (isVanish) "vanish" else "replace",
                    onSelect = { isVanish = (it == "vanish") },
                    accentColor = readerHighlightColor,
                    textColor = readerTextColor
                )

                if (!isVanish) {
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = replacementText,
                        onValueChange = { replacementText = it },
                        placeholder = { Text("Enter replacement text...", fontSize = 13.sp, color = readerTextColor.copy(alpha = 0.4f)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = readerHighlightColor,
                            unfocusedBorderColor = readerTextColor.copy(alpha = 0.2f),
                            focusedTextColor = readerTextColor,
                            unfocusedTextColor = readerTextColor
                        ),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                
                AdaptiveChoiceChips(
                    options = listOf(
                        "All Books" to "All Books 🌍",
                        "This Book" to "This Book 📖"
                    ),
                    selectedKey = selectedScope,
                    onSelect = { selectedScope = it },
                    accentColor = readerHighlightColor,
                    textColor = readerTextColor
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Button(
                    onClick = {
                        if (cleanedMatch.isNotBlank()) {
                            val squashedNew = TextFilter.squash(cleanedMatch)
                            val existingRule = textFilterRules.firstOrNull { rule ->
                                TextFilter.squash(rule.original) == squashedNew && rule.scope == selectedScope
                            }
                            val activeNovelVal = activeNovel
                            val bookIdVal = if (selectedScope == "This Book") (activeNovelVal?.id ?: "") else ""
                            if (existingRule != null) {
                                val updatedRule = existingRule.copy(
                                    original = cleanedMatch,
                                    replacement = if (isVanish) "" else replacementText,
                                    isVanish = isVanish,
                                    scope = selectedScope,
                                    bookId = bookIdVal,
                                    action = if (isVanish) TextFilter.ACTION_ERASE_TEXT else TextFilter.ACTION_REPLACE,
                                    strictMatch = false
                                )
                                val updatedList = textFilterRules.map { if (it.id == existingRule.id) updatedRule else it }
                                viewModel.saveRules(updatedList)
                                Toast.makeText(context, "Updated existing rule", Toast.LENGTH_SHORT).show()
                            } else {
                                val newRule = FilterRule(
                                    id = java.util.UUID.randomUUID().toString(),
                                    original = cleanedMatch,
                                    replacement = if (isVanish) "" else replacementText,
                                    isVanish = isVanish,
                                    scope = selectedScope,
                                    bookId = bookIdVal,
                                    action = if (isVanish) TextFilter.ACTION_ERASE_TEXT else TextFilter.ACTION_REPLACE,
                                    strictMatch = false
                                )
                                viewModel.saveRules(textFilterRules + newRule)
                            }
                            selRange = null
                            selSentenceIndex = -1
                            selectionVersion++
                            isSelectionPanelCollapsed = true
                            replacementText = ""
                        }
                    },
                    enabled = cleanedMatch.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (themeState == "blackgold") Color.Transparent else readerHighlightColor,
                        contentColor = if (themeState == "blackgold") GoldOnGradient else Color.Black
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .then(
                            if (themeState == "blackgold") {
                                Modifier.background(RefinedGoldGradient, RoundedCornerShape(8.dp))
                            } else {
                                Modifier
                            }
                        ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Add Filter Rule", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        // Floating Action Button/Badge for Selection Collapse (Bottom Right)
        AnimatedVisibility(
            visible = selRange != null && isSelectionPanelCollapsed,
            enter = slideInVertically(initialOffsetY = { it / 2 }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it / 2 }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 24.dp, end = 24.dp)
                .navigationBarsPadding()
                .zIndex(999f)
        ) {
            Box(
                modifier = Modifier.wrapContentSize(),
                contentAlignment = Alignment.TopEnd
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = readerBgColor.copy(alpha = 0.95f)),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, readerHighlightColor),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .padding(top = 10.dp, end = 10.dp)
                        .clickable { isSelectionPanelCollapsed = false }
                        .wrapContentSize()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FilterList,
                            contentDescription = "Open Filter Rules Panel",
                            tint = readerHighlightColor,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "Create Filter",
                            color = readerTextColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.errorContainer)
                        .border(1.dp, MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.4f), CircleShape)
                        .clickable { 
                            selRange = null 
                            selectionVersion++
                        }
                        .align(Alignment.TopEnd),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Cancel filtering",
                        tint = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
            }
        }

        // CHAPTER CONTENTS LEFT SLIDEOUT DRAWER
        AnimatedVisibility(
            visible = showChapterDrawer,
            enter = slideInHorizontally(
                initialOffsetX = { -it },
                animationSpec = tween(260, easing = FastOutSlowInEasing)
            ) + fadeIn(tween(200)),
            exit = slideOutHorizontally(
                targetOffsetX = { -it },
                animationSpec = tween(240)
            ) + fadeOut(tween(180))
        ) {
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(0.55f)).clickable { showChapterDrawer = false }) {
                GlassPanel(
                    cornerRadius = 0.dp,
                    tintAlpha = 0.90f,
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(280.dp)
                        .clickable(enabled = false) {}
                ) {
                    Column(modifier = Modifier.fillMaxSize().padding(top = readerSafeTopPadding()).padding(16.dp)) {
                        // CHAPTER SEARCH: hidden behind the magnifier until tapped.
                        // Filtering keeps the ORIGINAL chapter index next to the title
                        // so tapping a filtered row still opens the correct chapter.
                        // Mirrored 1:1 in the manga reader's Contents drawer.
                        var chapterSearchOpen by remember { mutableStateOf(false) }
                        var chapterQuery by remember { mutableStateOf("") }
                        val filteredChapters = remember(chapters, chapterQuery) {
                            val q = chapterQuery.trim()
                            if (q.isEmpty()) chapters.withIndex().toList()
                            else chapters.withIndex().filter { it.value.contains(q, ignoreCase = true) }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(22.dp), tint = readerHighlightColor)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Contents", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = readerTextColor, modifier = Modifier.weight(1f))
                            IconButton(onClick = {
                                chapterSearchOpen = !chapterSearchOpen
                                if (!chapterSearchOpen) chapterQuery = ""
                            }) {
                                Icon(
                                    Icons.Default.Search,
                                    contentDescription = "Search chapters",
                                    tint = if (chapterSearchOpen) readerHighlightColor else readerTextColor
                                )
                            }
                            IconButton(onClick = { showChapterDrawer = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = readerTextColor)
                            }
                        }
                        HorizontalDivider(color = readerTextColor.copy(alpha = 0.15f), modifier = Modifier.padding(vertical = 12.dp))
                        AnimatedVisibility(visible = chapterSearchOpen) {
                            OutlinedTextField(
                                value = chapterQuery,
                                onValueChange = { chapterQuery = it },
                                singleLine = true,
                                placeholder = {
                                    Text(
                                        "Search chapters",
                                        fontSize = 14.sp,
                                        color = readerTextColor.copy(alpha = 0.5f)
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        Icons.Default.Search,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp),
                                        tint = readerHighlightColor
                                    )
                                },
                                trailingIcon = {
                                    if (chapterQuery.isNotEmpty()) {
                                        IconButton(onClick = { chapterQuery = "" }) {
                                            Icon(
                                                Icons.Default.Close,
                                                contentDescription = "Clear search",
                                                modifier = Modifier.size(16.dp),
                                                tint = readerTextColor.copy(alpha = 0.7f)
                                            )
                                        }
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = readerHighlightColor,
                                    unfocusedBorderColor = readerTextColor.copy(alpha = 0.25f),
                                    focusedTextColor = readerTextColor,
                                    unfocusedTextColor = readerTextColor,
                                    cursorColor = readerHighlightColor
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp)
                            )
                        }
                        // Novel-side dim comes from the same store as the details
                        // list now, instead of a list of chapter NAME strings that
                        // only the TTS path ever appended to.
                        val tocStateFlow = remember(activeNovel?.id) {
                            com.lorelight.data.chapters.ChapterReadStore
                                .observe(context, activeNovel?.id ?: "")
                        }
                        val tocState by tocStateFlow.collectAsState()
                        val completedChapterIndices = remember(tocState, activeNovel) {
                            val n = activeNovel
                            if (n == null) {
                                emptySet()
                            } else {
                                com.lorelight.data.chapters.ChapterReadStore.completedIndices(n, tocState)
                            }
                        }
                        com.lorelight.ui.components.VerticalFastScroller(
                            listState = chaptersListState,
                            thumbColor = readerHighlightColor,
                            modifier = Modifier.weight(1f)
                        ) {
                            LazyColumn(state = chaptersListState, verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxSize()) {
                                if (filteredChapters.isEmpty()) {
                                    item {
                                        Text(
                                            text = "No chapters match \"${chapterQuery.trim()}\"",
                                            fontSize = 13.sp,
                                            color = readerTextColor.copy(alpha = 0.6f),
                                            modifier = Modifier.padding(vertical = 24.dp)
                                        )
                                    }
                                }
                                itemsIndexed(filteredChapters) { _, entry ->
                                    val index = entry.index
                                    val chTitle = entry.value
                                    val isActive = index == activeChapterIndex
                                    val isCompleted = completedChapterIndices.contains(index)
                                    val isCached = cachedChapterIndices.contains(index)
                                    ChapterRowItem(
                                        index = index,
                                        chTitle = chTitle,
                                        isActive = isActive,
                                        isCompleted = isCompleted,
                                        isCached = isCached,
                                        readerHighlightColor = readerHighlightColor,
                                        readerTextColor = readerTextColor,
                                        onClick = { 
                                            viewModel.selectChapter(index)
                                            showChapterDrawer = false 
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Animated Bottom Settings Sheet Drawer containing layout formatting, voice selections, and text filters
        ReaderSettingsSheet(
            showSettingsDialog = showSettingsDialog,
            onDismissSettings = { showSettingsDialog = false },
            showTextFilterPanel = showTextFilterPanel,
            onSetTextFilterPanelVisible = { showTextFilterPanel = it },
            viewModel = viewModel,
            activeNovel = activeNovel,
            readerTextColor = readerTextColor,
            readerHighlightColor = readerHighlightColor,
            themeState = themeState,
            onOpenFontManager = onOpenFontManager,
            onResetSelection = {
                selRange = null
                selectionVersion++
                isSelectionPanelCollapsed = true
            }
        )

        if (showBatteryOptimizationDialog) {
            LorelightDialog(
                onDismissRequest = {
                    viewModel.dismissBatteryOptimizationDialog(dontAskAgain = false)
                },
                title = {
                    Text(
                        text = "Uninterrupted Reading",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(
                        text = "Lorelight requires battery exemption to provide continuous, uninterruptible background text-to-speech reading sessions even when your screen is off.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.launchBatteryExemptionIntent(context)
                            viewModel.dismissBatteryOptimizationDialog(dontAskAgain = true)
                        }
                    ) {
                        Text("Allow")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            viewModel.dismissBatteryOptimizationDialog(dontAskAgain = false)
                        }
                    ) {
                        Text("Keep Default")
                    }
                }
            )
        }
    }
}

@Composable
fun ChapterRowItem(
    index: Int,
    chTitle: String,
    isActive: Boolean,
    isCompleted: Boolean,
    isCached: Boolean,
    readerHighlightColor: Color,
    readerTextColor: Color,
    onClick: () -> Unit
) {
    val textWeight = if (isActive) FontWeight.Bold else if (isCompleted) FontWeight.Medium else FontWeight.Normal
    val titleColor = if (isActive) readerHighlightColor else if (isCompleted) Color.Gray else readerTextColor
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = if (isActive) readerHighlightColor.copy(alpha = 0.15f) else Color.Transparent),
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = chTitle,
                fontWeight = textWeight,
                fontStyle = if (isCompleted) FontStyle.Italic else FontStyle.Normal,
                fontSize = 14.sp,
                color = titleColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            if (isCached) {
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.Download,
                    tint = readerHighlightColor,
                    contentDescription = "Downloaded",
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

/**
 * Single place that writes the reader's scroll position. Computes the
 * last-visible fraction the same way Grimoire does, so progress survives a
 * later font-size change (FIX #12).
 */
private fun persistReaderPosition(
    context: android.content.Context,
    novelId: String,
    chapterIndex: Int,
    listState: androidx.compose.foundation.lazy.LazyListState,
    layoutSig: Int
) {
    if (novelId.isEmpty() || chapterIndex < 0) return
    val info = listState.layoutInfo
    val total = info.totalItemsCount
    if (total <= 0) return
    val last = info.visibleItemsInfo.lastOrNull()?.index ?: listState.firstVisibleItemIndex
    val fraction = ((last + 1).toFloat() / total).coerceIn(0f, 1f)
    ReadingPositionStore.save(
        context = context,
        novelId = novelId,
        chapterIndex = chapterIndex,
        index = listState.firstVisibleItemIndex,
        offset = listState.firstVisibleItemScrollOffset,
        fraction = fraction,
        layoutSig = layoutSig
    )
}

/**
 * FIX #17: the chapter loader injects status messages into the CONTENT list as
 * real ReaderBlock.TextBlock items instead of using separate UI state. They must
 * never be treated as chapter text when restoring a scroll position.
 *
 * Keep this in sync with the updateSentences(...) calls in TtsPlaybackManager
 * (currently around lines 967, 1016, 1034, 1037 and 1077) and with
 * isChapterFetchFailure() in the same file.
 */
private val READER_PLACEHOLDER_TEXTS = setOf(
    "Loading chapter...",
    "Loading next chapter...",
    "Chapter content is empty.",
    "Chapter content is empty or could not be loaded.",
    "This chapter isn't available yet. Please try again.",
    "Failed to load chapter content.",
    "No content extracted."
)

private fun isPlaceholderContent(blocks: List<ReaderBlock>): Boolean {
    if (blocks.size != 1) return false
    val b = blocks.firstOrNull()
    return b is ReaderBlock.TextBlock &&
        (b.text in READER_PLACEHOLDER_TEXTS || com.lorelight.crawler.CrawlerEngine.isFailureText(b.text))
}


