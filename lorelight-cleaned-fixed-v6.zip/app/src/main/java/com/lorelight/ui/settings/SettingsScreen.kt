package com.lorelight.ui.settings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import com.lorelight.ui.components.LorelightDialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import eu.kanade.tachiyomi.extension.ExtensionManager
import mihon.domain.extension.interactor.AddExtensionStore
import mihon.domain.extension.interactor.GetExtensionStores
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get

import com.lorelight.R
import com.lorelight.ui.theme.*
import com.lorelight.data.model.Novel
import com.lorelight.data.model.Website
import com.lorelight.data.model.toJSONObject
import com.lorelight.data.model.toNovel
import com.lorelight.ui.reader.ReaderViewModel
import com.lorelight.core.BackupManager
import com.lorelight.core.BackupInfo
import com.lorelight.core.CrashReporter
import com.lorelight.core.CrashReport
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CacheStats(val fileCount: Int, val totalSizeFormatted: String, val sizeInBytes: Long)

fun formatBytes(totalBytes: Long): String = when {
    totalBytes < 1024 -> "$totalBytes B"
    totalBytes < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", totalBytes / 1024.0)
    else -> String.format(Locale.US, "%.1f MB", totalBytes / (1024.0 * 1024.0))
}

data class NovelCacheStat(
    val novelId: String,
    val title: String,
    val fileCount: Int,
    val sizeInBytes: Long,
    val sizeFormatted: String
)

private fun cacheFileNameFor(url: String): String =
    url.replace(Regex("[^a-zA-Z0-9]"), "_") + ".txt"

fun getPerNovelCacheStats(context: Context, novels: List<com.lorelight.data.model.Novel>): List<NovelCacheStat> {
    val cacheDir = File(context.filesDir, "chapters_cache")
    if (!cacheDir.exists() || !cacheDir.isDirectory) return emptyList()
    val allFiles = (cacheDir.listFiles() ?: return emptyList())
        .filter { it.isFile && it.name.endsWith(".txt") }
        .associateBy { it.name }

    val out = mutableListOf<NovelCacheStat>()
    val claimed = mutableSetOf<String>()

    novels.forEach { novel ->
        var count = 0
        var bytes = 0L
        novel.chapterUrls.forEach { url ->
            val name = cacheFileNameFor(url)
            val f = allFiles[name]
            if (f != null && claimed.add(name)) {
                count++
                bytes += f.length()
            }
        }
        if (count > 0) {
            out.add(NovelCacheStat(novel.id, novel.title, count, bytes, formatBytes(bytes)))
        }
    }

    val leftover = allFiles.keys - claimed
    if (leftover.isNotEmpty()) {
        val bytes = leftover.sumOf { allFiles[it]?.length() ?: 0L }
        out.add(NovelCacheStat("__orphaned__", "Other / removed novels", leftover.size, bytes, formatBytes(bytes)))
    }
    return out.sortedByDescending { it.sizeInBytes }
}

fun deleteCacheForNovel(context: Context, novel: com.lorelight.data.model.Novel): Int {
    var deleted = 0
    try {
        val cacheDir = File(context.filesDir, "chapters_cache")
        novel.chapterUrls.forEach { url ->
            val f = File(cacheDir, cacheFileNameFor(url))
            if (f.exists() && f.delete()) deleted++
        }
    } catch (e: Exception) { e.printStackTrace() }
    return deleted
}

fun deleteOrphanedCache(context: Context, novels: List<com.lorelight.data.model.Novel>): Int {
    var deleted = 0
    try {
        val cacheDir = File(context.filesDir, "chapters_cache")
        val keep = novels.flatMap { it.chapterUrls }.map { cacheFileNameFor(it) }.toSet()
        (cacheDir.listFiles() ?: return 0)
            .filter { it.isFile && it.name.endsWith(".txt") && it.name !in keep }
            .forEach { if (it.delete()) deleted++ }
    } catch (e: Exception) { e.printStackTrace() }
    return deleted
}

fun getCacheStats(context: Context): CacheStats {
    val cacheDir = File(context.filesDir, "chapters_cache")
    if (!cacheDir.exists() || !cacheDir.isDirectory) {
        return CacheStats(0, "0 B", 0L)
    }
    val files = cacheDir.listFiles() ?: return CacheStats(0, "0 B", 0L)
    val txtFiles = files.filter { it.isFile && it.name.endsWith(".txt") }
    val count = txtFiles.size
    val totalBytes = txtFiles.sumOf { it.length() }
    return CacheStats(count, formatBytes(totalBytes), totalBytes)
}

fun deleteChaptersCache(context: Context): Boolean {
    return try {
        val cacheDir = File(context.filesDir, "chapters_cache")
        if (cacheDir.exists() && cacheDir.isDirectory) {
            val files = cacheDir.listFiles()
            if (files != null) {
                for (file in files) {
                    if (file.isFile && file.name.endsWith(".txt")) {
                        file.delete()
                    }
                }
            }
        }
        true
    } catch (e: Exception) {
        e.printStackTrace()
        false
    }
}

// FIX C15: single canonical settings store, which also merges the legacy
// "lorelight_settings" file that the library screen used to own.
private fun loreSettingsPrefs(context: Context): android.content.SharedPreferences =
    com.lorelight.data.local.AppPrefs.get(context)

/**
 * What the user chose to include in this backup.
 *
 * Persisted in the same "lorelight_backup_prefs" file that [BackupManager]
 * already owns, so the choice survives across sessions and is picked up by
 * both "Backup Now" and the file export path.
 */
data class BackupOptions(
    val includeSources: Boolean = true,
) {
    companion object {
        private const val PREFS = "lorelight_backup_prefs"
        private const val KEY_SOURCES = "backup_include_sources"

        fun load(context: Context): BackupOptions {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            return BackupOptions(
                includeSources = p.getBoolean(KEY_SOURCES, true),
            )
        }

        fun save(context: Context, options: BackupOptions) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_SOURCES, options.includeSources)
                .commit()
        }
    }
}

fun generateBackupJson(
    context: Context,
    options: BackupOptions = BackupOptions.load(context),
): String {
    val backupObj = JSONObject()
    
    // 1. Novels & History from Room via NovelPreferences
    val savedNovelsList = com.lorelight.data.local.NovelPreferences.loadNovelsFromPrefs(context)
    val savedNovelsArr = JSONArray()
    savedNovelsList.forEach { novel ->
        val obj = novel.toJSONObject()
        val cover = novel.coverImageBase64
        // A remote http(s) cover restores fine on its own -- the new install
        // just downloads it again. Only LOCAL covers are lost on uninstall,
        // because filesDir is deleted with the app, so only those need to be
        // embedded here.
        val isRemote = cover != null &&
            (cover.startsWith("http://") || cover.startsWith("https://"))
        if (!isRemote) {
            val encoded = com.lorelight.data.local.CoverStorage
                .encodeCoverForBackup(context, novel.id, cover)
            if (encoded != null) {
                obj.put("coverBackupData", encoded)
                // Blank the stale absolute path. It points into the OLD
                // install's filesDir and is meaningless on the new device;
                // leaving it would only render a broken image.
                obj.put("coverImageBase64", "")
            }
        }
        savedNovelsArr.put(obj)
    }
    
    val lorePrefs = loreSettingsPrefs(context)
    val savedWebsites = lorePrefs.getString("saved_websites", "[]")
    
    val readingHistoryList = com.lorelight.data.local.NovelPreferences.loadHistoryFromPrefs(context)
    val readingHistoryArr = JSONArray()
    readingHistoryList.forEach { item ->
        val obj = JSONObject()
        obj.put("novelId", item.novelId)
        obj.put("novelTitle", item.novelTitle)
        obj.put("chapterId", item.chapterId)
        obj.put("chapterTitle", item.chapterTitle)
        obj.put("timestamp", item.timestamp)
        obj.put("lastModified", item.lastModified)
        obj.put("novelJson", item.novelJson)
        readingHistoryArr.put(obj)
    }

    backupObj.put("saved_novels", savedNovelsArr.toString())
    backupObj.put("saved_websites", savedWebsites)
    backupObj.put("reading_history", readingHistoryArr.toString())

    val highlightsList = com.lorelight.data.local.NovelPreferences.loadHighlightsFromPrefs(context)
    val highlightsArr = JSONArray()
    highlightsList.forEach { h ->
        val obj = JSONObject()
        obj.put("id", h.id)
        obj.put("novelId", h.novelId)
        obj.put("chapterTitle", h.chapterTitle)
        obj.put("startWordIdx", h.startWordIdx)
        obj.put("endWordIdx", h.endWordIdx)
        obj.put("colorHex", h.colorHex)
        obj.put("createdTimestamp", h.createdTimestamp)
        highlightsArr.put(obj)
    }
    backupObj.put("saved_highlights", highlightsArr.toString())
    
    // 2. SharedPreferences: reader_text_filters
    val filterPrefs = context.getSharedPreferences("reader_text_filters", Context.MODE_PRIVATE)
    val rules = filterPrefs.getString("rules", "[]")
    backupObj.put("reader_text_filters_rules", rules)

    // 2b. Manga side. The read-aloud text filters live in their own store, and
    // every manga reader setting (autoscroll, tap zones, OCR detail, TTS voice)
    // lives in lorelight_manga_reader_prefs. Without these two blocks a backup
    // silently dropped the entire manga half of the reader setup.
    val mangaFilterPrefs = context.getSharedPreferences("manga_reader_text_filters", Context.MODE_PRIVATE)
    backupObj.put("manga_reader_text_filters_rules", mangaFilterPrefs.getString("rules", "[]"))

    val mangaReaderPrefs = context.getSharedPreferences("lorelight_manga_reader_prefs", Context.MODE_PRIVATE)
    val mangaReaderPrefsObj = JSONObject()
    mangaReaderPrefs.all.forEach { (key, value) ->
        mangaReaderPrefsObj.put(key, value)
    }
    backupObj.put("lorelight_manga_reader_prefs", mangaReaderPrefsObj)
    
    // 3. SharedPreferences: reader_prefs
    val readerPrefs = context.getSharedPreferences("reader_prefs", Context.MODE_PRIVATE)
    val readerPrefsObj = JSONObject()
    val allReaderPrefs = readerPrefs.all
    allReaderPrefs.forEach { (key, value) ->
        readerPrefsObj.put(key, value)
    }
    backupObj.put("reader_prefs", readerPrefsObj)
    
    // ---- Sources (opt-in) -------------------------------------------------
    // Guarded so a user who only wants library data still gets a small file.
    if (options.includeSources) {
        val browsePrefs = context.getSharedPreferences(
            "lorelight_browse_prefs", Context.MODE_PRIVATE,
        )
        // Novel plugin repos + installed novel plugins are plain JSON in
        // SharedPreferences, so these restore perfectly.
        backupObj.put(
            "novel_plugin_repos",
            browsePrefs.getString("repo_urls", "[]") ?: "[]",
        )
        backupObj.put(
            "novel_installed_plugins",
            browsePrefs.getString("installed_plugins", "[]") ?: "[]",
        )

        // Manga extension repos live in tachiyomi.db behind suspend
        // interactors. generateBackupJson must therefore never run on the
        // main thread -- both call sites now dispatch to Dispatchers.IO.
        try {
            val stores = runBlocking { Injekt.get<GetExtensionStores>().get() }
            val storeArr = JSONArray()
            stores.forEach { storeArr.put(it.indexUrl) }
            backupObj.put("manga_extension_repos", storeArr.toString())
        } catch (e: Exception) {
            // A missing extension subsystem must never fail the whole backup.
            backupObj.put("manga_extension_repos", "[]")
        }

        // Installed manga extensions are APKs and cannot be restored as data.
        // Record them so the user knows what to reinstall after a restore.
        try {
            val extManager = Injekt.get<ExtensionManager>()
            val installedArr = JSONArray()
            extManager.installedExtensionsFlow.value.forEach { ext ->
                installedArr.put(
                    JSONObject()
                        .put("pkgName", ext.pkgName)
                        .put("name", ext.name)
                        .put("versionName", ext.versionName),
                )
            }
            backupObj.put("manga_installed_extensions", installedArr.toString())
        } catch (e: Exception) {
            backupObj.put("manga_installed_extensions", "[]")
        }
    }

    // Metadata
    backupObj.put("backup_timestamp", System.currentTimeMillis())
    backupObj.put("app_version", com.lorelight.BuildConfig.VERSION_NAME)
    
    return backupObj.toString()
}

fun restoreBackupJson(context: Context, backupStr: String): Boolean {
    try {
        val backupObj = JSONObject(backupStr)
        
        // 1. Merge Saved Novels via NovelPreferences
        val backupSavedNovelsStr = backupObj.optString("saved_novels", "[]")
        val backupSavedWebsitesStr = backupObj.optString("saved_websites", "[]")
        
        // Quick structural validation of backup input
        try {
            JSONArray(backupSavedNovelsStr)
        } catch (e: Exception) {
            return false
        }
        
        val currentNovels = com.lorelight.data.local.NovelPreferences.loadNovelsFromPrefs(context)
        val mergedNovels = currentNovels.toMutableList()
        val existingNovelTitles = currentNovels.map { it.title }.filter { it.isNotEmpty() }.toMutableSet()
        
        val backupNovelsArr = JSONArray(backupSavedNovelsStr)
        for (i in 0 until backupNovelsArr.length()) {
            val novelObj = backupNovelsArr.getJSONObject(i)
            val parsed = novelObj.toNovel()
            if (parsed.title.isEmpty() || existingNovelTitles.contains(parsed.title)) {
                continue
            }
            // Rehydrate the embedded cover into THIS install's covers/ dir and
            // point the novel at the new local path. Older backups have no
            // "coverBackupData" key and simply restore without a cover.
            val coverData = novelObj.optString("coverBackupData", "")
            val novel = if (coverData.isNotEmpty()) {
                val restoredPath = com.lorelight.data.local.CoverStorage
                    .restoreCoverFromBackup(context, parsed.id, coverData)
                if (restoredPath != null) {
                    parsed.copy(coverImageBase64 = restoredPath)
                } else {
                    parsed
                }
            } else {
                parsed
            }
            mergedNovels.add(novel)
            existingNovelTitles.add(novel.title)
        }
        com.lorelight.data.local.NovelPreferences.saveNovelsToPrefs(context, mergedNovels)
        
        // Merge Saved Websites
        val lorePrefs = loreSettingsPrefs(context)
        val currentSavedWebsitesStr = lorePrefs.getString("saved_websites", "[]") ?: "[]"
        val mergedWebsites = JSONArray()
        val existingWebsitesUrls = mutableSetOf<String>()
        
        val currentWebsitesArr = JSONArray(currentSavedWebsitesStr)
        for (i in 0 until currentWebsitesArr.length()) {
            val webObj = currentWebsitesArr.getJSONObject(i)
            val url = webObj.optString("url", "")
            if (url.isNotEmpty()) {
                existingWebsitesUrls.add(url)
            }
            mergedWebsites.put(webObj)
        }
        
        val backupWebsitesArr = JSONArray(backupSavedWebsitesStr)
        for (i in 0 until backupWebsitesArr.length()) {
            val webObj = backupWebsitesArr.getJSONObject(i)
            val url = webObj.optString("url", "")
            if (url.isNotEmpty() && !existingWebsitesUrls.contains(url)) {
                mergedWebsites.put(webObj)
                existingWebsitesUrls.add(url)
            }
        }
        
        lorePrefs.edit()
            .putString("saved_websites", mergedWebsites.toString())
            .commit()

        // Merge Reading History via NovelPreferences
        val backupHistoryStr = if (backupObj.has("reading_history")) backupObj.optString("reading_history", "[]")
                               else backupObj.optString("reading_history_list", "[]")
        if (backupHistoryStr.isNotEmpty() && backupHistoryStr != "[]") {
            try {
                val currentHistory = com.lorelight.data.local.NovelPreferences.loadHistoryFromPrefs(context).toMutableList()
                val existingKeys = currentHistory.map { "${it.novelId}_${it.chapterId}" }.toMutableSet()
                val historyArr = JSONArray(backupHistoryStr)
                for (i in 0 until historyArr.length()) {
                    val obj = historyArr.getJSONObject(i)
                    val entry = com.lorelight.data.model.HistoryEntry(
                        novelId = obj.optString("novelId"),
                        novelTitle = obj.optString("novelTitle"),
                        chapterId = obj.optString("chapterId"),
                        chapterTitle = obj.optString("chapterTitle"),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        lastModified = obj.optLong("lastModified", System.currentTimeMillis()),
                        novelJson = obj.optString("novelJson")
                    )
                    val key = "${entry.novelId}_${entry.chapterId}"
                    if (existingKeys.add(key)) {
                        currentHistory.add(entry)
                    }
                }
                com.lorelight.data.local.NovelPreferences.saveHistoryToPrefs(context, currentHistory)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
            
        // Merge Highlights
        val backupHighlightsStr = backupObj.optString("saved_highlights", "[]")
        if (backupHighlightsStr.isNotEmpty() && backupHighlightsStr != "[]") {
            try {
                val currentHighlights = com.lorelight.data.local.NovelPreferences.loadHighlightsFromPrefs(context).toMutableList()
                val existingIds = currentHighlights.map { it.id }.toMutableSet()
                val arr = JSONArray(backupHighlightsStr)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val id = obj.optString("id", "")
                    if (id.isNotEmpty() && existingIds.add(id)) {
                        currentHighlights.add(
                            com.lorelight.ui.reader.Highlight(
                                id = id,
                                novelId = obj.optString("novelId", ""),
                                chapterTitle = obj.optString("chapterTitle", ""),
                                startWordIdx = obj.optInt("startWordIdx", 0),
                                endWordIdx = obj.optInt("endWordIdx", 0),
                                colorHex = obj.optString("colorHex", "#FFFF00"),
                                createdTimestamp = obj.optLong("createdTimestamp", System.currentTimeMillis())
                            )
                        )
                    }
                }
                com.lorelight.data.local.NovelPreferences.saveHighlightsToPrefs(context, currentHighlights)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // 2. SharedPreferences: reader_text_filters (Merge unique rules based on rule ID)
        val filterPrefs = context.getSharedPreferences("reader_text_filters", Context.MODE_PRIVATE)
        val currentRulesStr = filterPrefs.getString("rules", "[]") ?: "[]"
        val backupRulesStr = backupObj.optString("reader_text_filters_rules", "[]")
        
        val mergedRules = JSONArray()
        val existingRuleIds = mutableSetOf<String>()
        
        val currentRulesArr = JSONArray(currentRulesStr)
        for (i in 0 until currentRulesArr.length()) {
            val ruleObj = currentRulesArr.getJSONObject(i)
            val id = ruleObj.optString("id", "")
            if (id.isNotEmpty()) {
                existingRuleIds.add(id)
            }
            mergedRules.put(ruleObj)
        }
        
        val backupRulesArr = JSONArray(backupRulesStr)
        for (i in 0 until backupRulesArr.length()) {
            val ruleObj = backupRulesArr.getJSONObject(i)
            val id = ruleObj.optString("id", "")
            if (id.isNotEmpty() && !existingRuleIds.contains(id)) {
                mergedRules.put(ruleObj)
                existingRuleIds.add(id)
            }
        }
        filterPrefs.edit().putString("rules", mergedRules.toString()).commit()

        // 2b. Manga read-aloud filters: same merge-by-id policy, so restoring
        // never drops rules the user added since the backup. Missing key (old
        // backup) is a silent no-op.
        try {
            val mangaFilterPrefs = context.getSharedPreferences("manga_reader_text_filters", Context.MODE_PRIVATE)
            val mangaCurrentStr = mangaFilterPrefs.getString("rules", "[]") ?: "[]"
            val mangaBackupStr = backupObj.optString("manga_reader_text_filters_rules", "[]")
            val mangaMerged = JSONArray()
            val mangaSeen = mutableSetOf<String>()
            val mangaCurrentArr = JSONArray(mangaCurrentStr)
            for (i in 0 until mangaCurrentArr.length()) {
                val ruleObj = mangaCurrentArr.getJSONObject(i)
                val id = ruleObj.optString("id", "")
                if (id.isNotEmpty()) {
                    mangaSeen.add(id)
                }
                mangaMerged.put(ruleObj)
            }
            val mangaBackupArr = JSONArray(mangaBackupStr)
            for (i in 0 until mangaBackupArr.length()) {
                val ruleObj = mangaBackupArr.getJSONObject(i)
                val id = ruleObj.optString("id", "")
                if (id.isNotEmpty() && !mangaSeen.contains(id)) {
                    mangaMerged.put(ruleObj)
                    mangaSeen.add(id)
                }
            }
            mangaFilterPrefs.edit().putString("rules", mangaMerged.toString()).commit()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 2c. Manga reader settings: overlay from backup, same typed policy as
        // reader_prefs below. Guarded so an old backup without this key is a
        // no-op, including during SelfHealingEngine crash recovery.
        try {
            val mangaReaderPrefs = context.getSharedPreferences("lorelight_manga_reader_prefs", Context.MODE_PRIVATE)
            val mangaReaderPrefsObj = backupObj.optJSONObject("lorelight_manga_reader_prefs")
            if (mangaReaderPrefsObj != null) {
                val mangaEdit = mangaReaderPrefs.edit()
                val mangaKeys = mangaReaderPrefsObj.keys()
                while (mangaKeys.hasNext()) {
                    val key = mangaKeys.next()
                    val value = mangaReaderPrefsObj.get(key)
                    when (value) {
                        is Boolean -> mangaEdit.putBoolean(key, value)
                        is Float -> mangaEdit.putFloat(key, value)
                        is Int -> mangaEdit.putInt(key, value)
                        is Long -> mangaEdit.putLong(key, value)
                        is String -> mangaEdit.putString(key, value)
                        is Double -> mangaEdit.putFloat(key, value.toFloat())
                    }
                }
                mangaEdit.commit()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        
        // 3. SharedPreferences: reader_prefs (Safely overlay settings from backup)
        val readerPrefs = context.getSharedPreferences("reader_prefs", Context.MODE_PRIVATE)
        val readerPrefsObj = backupObj.optJSONObject("reader_prefs")
        val edit = readerPrefs.edit()
        if (readerPrefsObj != null) {
            val keys = readerPrefsObj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val value = readerPrefsObj.get(key)
                when (value) {
                    is Boolean -> edit.putBoolean(key, value)
                    is Float -> edit.putFloat(key, value)
                    is Int -> edit.putInt(key, value)
                    is Long -> edit.putLong(key, value)
                    is String -> edit.putString(key, value)
                    is Double -> edit.putFloat(key, value.toFloat())
                }
            }
        }
        edit.commit()
        
        // 4. Chapters Cache Files (Write backup caches if they exist, never overwriting local ones)
        val cacheObj = backupObj.optJSONObject("chapters_cache")
        if (cacheObj != null) {
            val cacheDir = File(context.filesDir, "chapters_cache")
            if (!cacheDir.exists()) {
                cacheDir.mkdirs()
            }
            val keys = cacheObj.keys()
            while (keys.hasNext()) {
                val fileName = keys.next()
                if (fileName.endsWith(".txt")) {
                    val file = File(cacheDir, fileName)
                    if (!file.exists()) {
                        try {
                            val content = cacheObj.getString(fileName)
                            file.writeText(content)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }
            }
        }

        // ---- Sources ------------------------------------------------------
        // Absent keys mean the backup was made with sources excluded, or is an
        // older backup. Both cases must be silent no-ops. Every block is
        // individually guarded because restoreBackupJson also runs during
        // automatic crash recovery (SelfHealingEngine), where a source failure
        // must never abort library recovery.
        try {
            val browsePrefs = context.getSharedPreferences(
                "lorelight_browse_prefs", Context.MODE_PRIVATE,
            )

            // Novel plugin repos: union, never drop the user's current repos.
            val backupRepos = backupObj.optString("novel_plugin_repos", "[]")
            if (backupRepos.isNotEmpty() && backupRepos != "[]") {
                val current = JSONArray(browsePrefs.getString("repo_urls", "[]") ?: "[]")
                val seen = mutableSetOf<String>()
                val merged = JSONArray()
                for (i in 0 until current.length()) {
                    val url = current.optString(i, "")
                    if (url.isNotEmpty() && seen.add(url)) merged.put(url)
                }
                val incoming = JSONArray(backupRepos)
                for (i in 0 until incoming.length()) {
                    val url = incoming.optString(i, "")
                    if (url.isNotEmpty() && seen.add(url)) merged.put(url)
                }
                browsePrefs.edit().putString("repo_urls", merged.toString()).commit()
            }

            // Installed novel plugins: union keyed on info.id.
            val backupPlugins = backupObj.optString("novel_installed_plugins", "[]")
            if (backupPlugins.isNotEmpty() && backupPlugins != "[]") {
                val current = JSONArray(browsePrefs.getString("installed_plugins", "[]") ?: "[]")
                val seenIds = mutableSetOf<String>()
                val merged = JSONArray()
                for (i in 0 until current.length()) {
                    val o = current.optJSONObject(i) ?: continue
                    val id = o.optJSONObject("info")?.optString("id", "") ?: ""
                    if (id.isNotEmpty()) seenIds.add(id)
                    merged.put(o)
                }
                val incoming = JSONArray(backupPlugins)
                for (i in 0 until incoming.length()) {
                    val o = incoming.optJSONObject(i) ?: continue
                    val id = o.optJSONObject("info")?.optString("id", "") ?: ""
                    if (id.isNotEmpty() && seenIds.add(id)) merged.put(o)
                }
                browsePrefs.edit().putString("installed_plugins", merged.toString()).commit()
            }

            // DEAD-SOURCE FIX.
            //
            // The block above restores only the plugin RECORDS. The plugin
            // itself is a .js file under files/plugins, and nothing ever brought
            // that file back -- so after a restore the source was listed, looked
            // installed, and then failed the instant anything asked it for a
            // chapter, because the engine reads that missing file. That is the
            // "the source that came with the backup doesn't work" bug.
            //
            // Every restored record carries its own download url, so re-fetch
            // any plugin whose file is missing. Anything that cannot be fetched
            // is dropped from the list rather than left behind as a source that
            // exists but can never load; its repo has just been restored above,
            // so it can be reinstalled in one tap.
            try {
                val installedNow = JSONArray(
                    browsePrefs.getString("installed_plugins", "[]") ?: "[]"
                )
                val unavailable = mutableListOf<String>()
                for (i in 0 until installedNow.length()) {
                    val entry = installedNow.optJSONObject(i) ?: continue
                    val info = entry.optJSONObject("info") ?: continue
                    val id = info.optString("id", "")
                    if (id.isEmpty()) continue
                    if (com.lorelight.browse.repo.PluginManager.pluginFile(context, id).exists()) {
                        continue
                    }
                    val url = info.optString("url", "")
                    if (url.isEmpty()) {
                        unavailable.add(id)
                        continue
                    }
                    val pluginInfo = com.lorelight.browse.model.PluginInfo(
                        id = id,
                        name = info.optString("name", id),
                        site = info.optString("site", ""),
                        lang = info.optString("lang", "Unknown"),
                        version = info.optString("version", "0.0.0"),
                        url = url,
                        iconUrl = info.optString("iconUrl", ""),
                        hasSettings = info.optBoolean("hasSettings", false),
                        hasUpdate = info.optBoolean("hasUpdate", false),
                        repoUrl = info.optString("repoUrl", ""),
                        customJS = info.optString("customJS", "").ifEmpty { null }.takeIf { it != "null" },
                        customCSS = info.optString("customCSS", "").ifEmpty { null }.takeIf { it != "null" }
                    )
                    val ok = runBlocking {
                        runCatching {
                            com.lorelight.browse.repo.PluginManager
                                .installPlugin(context, pluginInfo)
                                .isSuccess
                        }.getOrDefault(false)
                    }
                    if (!ok) unavailable.add(id)
                }
                for (deadId in unavailable) {
                    com.lorelight.browse.repo.PluginStore.remove(context, deadId)
                }
                browsePrefs.edit()
                    .putString("sources_awaiting_reinstall", JSONArray(unavailable).toString())
                    .commit()
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // Manga extension repos: insert through the interactor so the DB
            // and its flows stay consistent. Duplicates are rejected by the
            // repository itself, so a failed Result here is expected.
            val backupStores = backupObj.optString("manga_extension_repos", "[]")
            if (backupStores.isNotEmpty() && backupStores != "[]") {
                val arr = JSONArray(backupStores)
                val addStore = Injekt.get<AddExtensionStore>()
                runBlocking {
                    for (i in 0 until arr.length()) {
                        val url = arr.optString(i, "")
                        if (url.isNotEmpty()) {
                            runCatching { addStore(url) }
                        }
                    }
                }
            }
            // "manga_installed_extensions" is intentionally NOT restored: those
            // are APKs, not data. The key exists as a record of what to
            // reinstall from the now-restored repos.
        } catch (e: Exception) {
            // Best effort: library data has already landed and must not be
            // rolled back because a repo insert failed.
            e.printStackTrace()
        }

        return true
    } catch (e: Exception) {
        e.printStackTrace()
        return false
    }
}

private val SettingCardRadius = 14.dp
private val SettingCardPadding = 14.dp
private val SettingRowMinHeight = 48.dp
private val SettingGroupGap = 14.dp
private val SettingInnerGap = 12.dp

/*
 * SETTINGS CATEGORIES
 *
 * Merged from ten categories down to six. The old set split things that belong
 * together and made the hub feel like a wall of near-duplicates:
 *
 *   Reader Editor + Text-to-Speech          -> Reading & Voice
 *   New Chapter Notifications + Manga Sources -> Library & Sources
 *   Downloads Queue + Storage Maintenance   -> Downloads & Storage
 *   Advanced Tools + About Lorelight        -> Advanced & About
 *
 * Backup & Restore stays on its own because it is high stakes and people look
 * for it by that exact name. Appearance stays on its own because it is the most
 * visited screen.
 */
enum class SettingsCategory(
    val title: String,
    val desc: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    APPEARANCE(
        "Appearance",
        "Theme mode, colour palettes, and typography",
        Icons.Default.Palette
    ),
    READING(
        "Reading & Voice",
        "Reader layout, margins, line spacing, and text-to-speech",
        Icons.Default.Book
    ),
    LIBRARY(
        "Library & Sources",
        "Chapter update checks, notifications, manga sources and extensions",
        Icons.Default.NotificationsActive
    ),
    STORAGE(
        "Downloads & Storage",
        "Download queue, offline chapter cache, and source health",
        Icons.Default.Download
    ),
    BACKUP_RESTORE(
        "Backup & Restore",
        "Export, import, and automatic daily backups",
        Icons.Default.Backup
    ),
    ADVANCED(
        "Advanced & About",
        "Diagnostics, crash reports, app version, and community",
        Icons.Default.Settings
    )
}

@Composable
fun SettingsScreen(
    importedNovels: List<Novel>,
    websites: List<Website>,
    readerViewModel: ReaderViewModel,
    onRestoreSuccess: () -> Unit,
    onOpenFontManager: () -> Unit,
    onOpenNewChapters: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    var cacheStats by remember { mutableStateOf(getCacheStats(context)) }
    var perNovelStats by remember { mutableStateOf<List<NovelCacheStat>?>(null) }
    var selectedForDelete by remember { mutableStateOf<NovelCacheStat?>(null) }
    var showClearConfirmDialog by remember { mutableStateOf(false) }
    var isOperating by remember { mutableStateOf(false) }
    var showRestoreConfirmDialog by remember { mutableStateOf(false) }
    var pendingRestoreContent by remember { mutableStateOf("") }
    
    // Auto Backups & Crash Reports states
    var singleBackupInfo by remember { mutableStateOf(BackupManager.getSingleBackupInfo(context)) }
    var crashReports by remember { mutableStateOf(CrashReporter.getCrashReports(context)) }
    var viewingCrashReport by remember { mutableStateOf<CrashReport?>(null) }
    var showAutoRestoreConfirmDialog by remember { mutableStateOf<BackupInfo?>(null) }

    val settingsVersion by com.lorelight.data.local.AppSettingsSignal.version.collectAsState()
    val backupPrefs = remember(settingsVersion) { context.getSharedPreferences("lorelight_backup_prefs", Context.MODE_PRIVATE) }
    var backupLocationType by remember(settingsVersion) { mutableStateOf(backupPrefs.getString(BackupManager.KEY_LOCATION_TYPE, "external") ?: "external") }
    var customFolderPathName by remember(settingsVersion) { mutableStateOf(backupPrefs.getString(BackupManager.KEY_CUSTOM_PATH_NAME, "No Folder Selected") ?: "No Folder Selected") }

    // Active detail category state
    var activeCategory by remember { mutableStateOf<SettingsCategory?>(null) }
    // Search-first entry point: filters individual settings across every
    // category, so you no longer have to guess which of six screens owns a
    // toggle before you can find it.
    var settingsQuery by remember { mutableStateOf("") }
    // The download queue is a whole screen, not a settings row. It used to be
    // rendered as an item inside this LazyColumn, which nested a scrollable
    // inside a scrollable. It is now hosted as an overlay instead.
    var showDownloadsQueue by remember { mutableStateOf(false) }

    // BACK ALIGNMENT: the in-app arrow in a settings category header does
    // `activeCategory = null`, returning to the category list. System Back used
    // to skip that level entirely and leave the Settings tab, so the two
    // gestures disagreed on every settings detail page.
    androidx.activity.compose.BackHandler(enabled = activeCategory != null && !showDownloadsQueue) {
        activeCategory = null
    }
    var devModeUnlocked by remember { mutableStateOf(com.lorelight.core.DevLogStore.isDevModeUnlocked(context)) }

    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val takeFlags: Int = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                context.contentResolver.takePersistableUriPermission(uri, takeFlags)
                
                val doc = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, uri)
                val folderName = doc?.name ?: "Custom Folder"
                
                backupPrefs.edit().apply {
                    putString(BackupManager.KEY_LOCATION_TYPE, "custom")
                    putString(BackupManager.KEY_CUSTOM_URI, uri.toString())
                    putString(BackupManager.KEY_CUSTOM_PATH_NAME, folderName)
                }.commit()
                
                backupLocationType = "custom"
                customFolderPathName = folderName
                
                val success = BackupManager.createBackup(context)
                singleBackupInfo = BackupManager.getSingleBackupInfo(context)
                if (success) {
                    Toast.makeText(context, "Location changed & backup created successfully!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Location updated.", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Failed to persist folder permission: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
    
    // Backup Launcher (Saves JSON document)
    val backupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            isOperating = true
            coroutineScope.launch {
                val success = withContext(Dispatchers.IO) {
                    try {
                        val backupText = generateBackupJson(context)
                        context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                            outputStream.write(backupText.toByteArray())
                            outputStream.flush()
                        }
                        true
                    } catch (e: Exception) {
                        e.printStackTrace()
                        false
                    }
                }
                isOperating = false
                if (success) {
                    Toast.makeText(context, "Backup exported successfully!", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(context, "Failed to export backup.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    
    // Restore Launcher (Opens JSON document)
    val restoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            isOperating = true
            coroutineScope.launch {
                val fileContent = withContext(Dispatchers.IO) {
                    try {
                        context.contentResolver.openInputStream(uri)?.use { inputStream ->
                            inputStream.reader().readText()
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        null
                    }
                }
                isOperating = false
                if (!fileContent.isNullOrEmpty()) {
                    pendingRestoreContent = fileContent
                    showRestoreConfirmDialog = true
                } else {
                    Toast.makeText(context, "Failed to read backup file.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    
    LaunchedEffect(importedNovels, cacheStats) {
        cacheStats = getCacheStats(context)
        val stats = withContext(Dispatchers.IO) {
            val novels = com.lorelight.data.local.NovelPreferences.loadNovelsFromPrefs(context)
            getPerNovelCacheStats(context, novels)
        }
        perNovelStats = stats
    }

    // ADAPTIVE LAYOUT: phones keep the hub -> detail flow, while anything at
    // least 720dp wide (landscape phones, tablets, unfolded foldables) gets a
    // persistent category rail, so switching category costs no Back press.
    val configuration = LocalConfiguration.current
    val twoPane = configuration.screenWidthDp >= 720
    val cat = activeCategory

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = if (twoPane) 1180.dp else 680.dp),
            horizontalArrangement = Arrangement.spacedBy(if (twoPane) 14.dp else 0.dp)
        ) {
        if (twoPane) {
            SettingsCategoryRail(
                activeCategory = cat,
                query = settingsQuery,
                onQueryChange = { settingsQuery = it },
                onSelect = { activeCategory = it },
                modifier = Modifier
                    // Deterministic rail width instead of a width fraction.
                    // weight(0.36f) shrank the rail to roughly 250dp on a
                    // 720dp tablet, which is what forced the category labels
                    // to wrap mid-word. A fixed readable band fixes the cause
                    // rather than squeezing the text, and the detail pane
                    // absorbs whatever space is left.
                    .width(if (configuration.screenWidthDp >= 900) 320.dp else 272.dp)
                    .fillMaxHeight()
                    .padding(start = 16.dp, top = 16.dp, bottom = 24.dp)
            )
        }
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(SettingsGroupGap),
            contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp)
        ) {
            if (cat == null && !twoPane) {
                // SCREEN TITLE & SUBTITLE WITH DISCORD
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Settings",
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Configure reading view, voice playback, and backup",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                        
                        val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
                        Button(
                            onClick = { uriHandler.openUri("https://discord.gg/nyFMhq9EFw") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5865F2)),
                            shape = RoundedCornerShape(20.dp),
                            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                            modifier = Modifier.height(40.dp)
                        ) {
                            Icon(
                                painter = androidx.compose.ui.res.painterResource(id = R.drawable.ic_discord),
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Discord", color = MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                
                // SEARCH: matches individual settings, not just category titles.
                item {
                    SettingsSearchField(
                        query = settingsQuery,
                        onQueryChange = { settingsQuery = it },
                        onClear = { settingsQuery = "" }
                    )
                }

                // CURRENT DATA SUMMARY CARD
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        border = borderIndicator(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "CURRENT DATA SUMMARY",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                              ) {
                                StatItem(
                                    label = "Novels",
                                    value = importedNovels.size.toString(),
                                    modifier = Modifier.weight(1f)
                                )
                                StatItem(
                                    label = "Websites",
                                    value = websites.size.toString(),
                                    modifier = Modifier.weight(1f)
                                )
                                StatItem(
                                    label = "Offline Cache",
                                    value = cacheStats.totalSizeFormatted,
                                    subtext = "${cacheStats.fileCount} chapters",
                                    modifier = Modifier.weight(1.2f)
                                )
                            }
                        }
                    }
                }

                val hits = settingsSearchResults(settingsQuery)
                if (settingsQuery.isNotBlank()) {
                    item {
                        SettingsGroup(
                            title = if (hits.isEmpty()) "No matches" else hits.size.toString() + " matches"
                        ) {
                            if (hits.isEmpty()) {
                                SettingsRow(
                                    title = "Nothing found",
                                    subtitle = "Try a shorter word, for example voice, backup, cache or zoom."
                                )
                            } else {
                                hits.forEachIndexed { index, hit ->
                                    if (index > 0) {
                                        SettingsRowDivider()
                                    }
                                    SettingsRow(
                                        title = hit.label,
                                        subtitle = hit.category.title,
                                        icon = hit.category.icon,
                                        showChevron = true,
                                        onClick = {
                                            settingsQuery = ""
                                            activeCategory = hit.category
                                        }
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // HUB CATEGORY ROWS: one glass container, one radius, one row
                    // language, descriptions allowed to wrap, and real lazy items
                    // instead of ten cards composed inside a single item block.
                    items(SettingsCategory.values().toList()) { category ->
                        SettingsGroup {
                            SettingsRow(
                                title = category.title,
                                subtitle = category.desc,
                                icon = category.icon,
                                showChevron = true,
                                onClick = { activeCategory = category }
                            )
                        }
                    }
                }
            } else if (cat != null) {
                // DETAILS PANEL VIEW
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (!twoPane) {
                            IconButton(onClick = { activeCategory = null }) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = MaterialTheme.colorScheme.onBackground
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Column {
                            Text(
                                text = cat.title,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = cat.desc,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }
                }

                // CATEGORY CORRESPONDING SUB-SECTIONS
                when (cat) {
                    SettingsCategory.APPEARANCE -> {
                        item {
                            AppearanceSettingsSection(readerViewModel = readerViewModel)
                        }
                        item {
                            Spacer(modifier = Modifier.height(12.dp))
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                                border = borderIndicator(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onOpenFontManager() }
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FontDownload,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Manage Typography Fonts",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = "Download, cache and customize system and reader fonts",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.ChevronRight,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                                    )
                                }
                            }
                        }
                    }
                    SettingsCategory.READING -> {
                        item { SettingsSectionLabel("Reader layout") }
                        item {
                            ReaderSettingsSection(
                                readerViewModel = readerViewModel,
                                onOpenFontManager = onOpenFontManager
                            )
                        }
                        item { SettingsSectionLabel("Text-to-speech") }
                        item {
                            TtsSettingsSection(readerViewModel = readerViewModel)
                        }
                    }
                    SettingsCategory.BACKUP_RESTORE -> {
                        item {
                            BackupSettingsSection(
                                backupLauncher = backupLauncher,
                                restoreLauncher = restoreLauncher,
                                folderPickerLauncher = folderPickerLauncher,
                                singleBackupInfo = singleBackupInfo,
                                onSingleBackupInfoChange = { singleBackupInfo = it },
                                backupLocationType = backupLocationType,
                                onBackupLocationTypeChange = { backupLocationType = it },
                                customFolderPathName = customFolderPathName,
                                onShowAutoRestoreConfirm = { showAutoRestoreConfirmDialog = it }
                            )
                        }
                    }
                    SettingsCategory.LIBRARY -> {
                        item { SettingsSectionLabel("Chapter updates") }
                        item {
                            LibraryUpdatesSettingsSection(onOpenNewChapters = onOpenNewChapters)
                        }
                        // Manual refetch of all Details-page data (keeps reading progress).
                        item {
                            RefetchDetailsSection()
                        }
                        item { SettingsSectionLabel("Manga sources") }
                        item {
                            MangaSourcesSettingsSection()
                        }
                        item {
                            MangaInstalledExtensionsSection()
                        }
                    }
                    SettingsCategory.STORAGE -> {
                        // Opens the real queue screen as an overlay rather than
                        // nesting an 800 line scrollable inside this scroller.
                        item {
                            SettingsGroup(title = "Download queue") {
                                SettingsRow(
                                    title = "Open download queue",
                                    subtitle = "Active, queued, finished and failed novel & manga downloads",
                                    icon = Icons.Default.Download,
                                    showChevron = true,
                                    onClick = { showDownloadsQueue = true }
                                )
                            }
                        }
                        // FEATURE E29: downloads / storage monitor.
                        item {
                            DownloadsMonitorSection(
                                onOpenDownloadsQueue = { showDownloadsQueue = true }
                            )
                        }
                        // Secondary controls for HOW download work runs:
                        // parallelism, speed ceiling, pacing, retries, Wi-Fi only.
                        item {
                            DownloadSettingsSection()
                        }
                        // FEATURE E32: source & plugin health dashboard.
                        item {
                            SourceHealthSettingsSection()
                        }
                        item {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                border = borderIndicator(),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "LOCAL DATA & CACHE",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        letterSpacing = 1.sp
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = "Chapters Cache Size",
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "${cacheStats.fileCount} chapters stored offline (${cacheStats.totalSizeFormatted})",
                                                fontSize = 12.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Button(
                                            onClick = { showClearConfirmDialog = true },
                                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("Clear Cache", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                border = borderIndicator(),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "PER NOVEL DOWNLOADS",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        letterSpacing = 1.sp
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))

                                    val currentPerNovel = perNovelStats
                                    if (currentPerNovel == null) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 16.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(24.dp),
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    } else if (currentPerNovel.isEmpty()) {
                                        Text(
                                            text = "No offline chapters yet.",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                            modifier = Modifier.padding(vertical = 8.dp)
                                        )
                                    } else {
                                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            currentPerNovel.forEach { item ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clip(RoundedCornerShape(8.dp))
                                                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.3f))
                                                        .padding(horizontal = 12.dp, vertical = 10.dp),
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(
                                                            text = item.title,
                                                            fontSize = 13.sp,
                                                            fontWeight = FontWeight.SemiBold,
                                                            color = MaterialTheme.colorScheme.onSurface,
                                                            maxLines = 1,
                                                            overflow = TextOverflow.Ellipsis
                                                        )
                                                        Spacer(modifier = Modifier.height(2.dp))
                                                        Text(
                                                            text = "${item.fileCount} chapters · ${item.sizeFormatted}",
                                                            fontSize = 11.sp,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                                        )
                                                    }
                                                    IconButton(
                                                        onClick = { selectedForDelete = item },
                                                        modifier = Modifier.size(32.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.Delete,
                                                            contentDescription = "Delete cache for ${item.title}",
                                                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    SettingsCategory.ADVANCED -> {
                        if (devModeUnlocked) {
                            item {
                                NetworkThrottleSection()
                            }
                        }
                        item {
                            AdvancedSettingsSection(
                                cacheStats = cacheStats,
                                onClearCacheClick = { showClearConfirmDialog = true },
                                crashReports = crashReports,
                                onCrashReportsChange = { crashReports = it },
                                onViewCrashReport = { viewingCrashReport = it }
                            )
                        }
                        item { SettingsSectionLabel("About Lorelight") }
                        item {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                                border = borderIndicator(),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    var devTapCount by remember { mutableStateOf(0) }
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = "About",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clickable {
                                                if (!devModeUnlocked) {
                                                    devTapCount += 1
                                                    if (devTapCount >= 5) {
                                                        devModeUnlocked = true
                                                        com.lorelight.core.DevLogStore.setDevModeUnlocked(context, true)
                                                        com.lorelight.core.DevLogStore.append(context, "DEV", "Developer mode unlocked")
                                                    }
                                                }
                                            }
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "Lorelight Web Novel Reader",
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Version ${com.lorelight.BuildConfig.VERSION_NAME} • Stable Build",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                    )
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = "Lorelight is a premium, open-source web novel extractor, aggregator, and offline reading client with fully custom typography rendering and a high-performance text-to-speech audio engine.",
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center,
                                        lineHeight = 18.sp
                                    )
                                    Spacer(modifier = Modifier.height(24.dp))
                                    val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
                                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                        Button(
                                            onClick = { uriHandler.openUri("https://discord.gg/nyFMhq9EFw") },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5865F2)),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Text("Join Discord Community", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    if (devModeUnlocked) {
                                        Spacer(modifier = Modifier.height(16.dp))
                                        DevLogPanel()
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                item {
                    SettingsPlaceholderPane()
                }
            }
        }
        }

        if (showDownloadsQueue) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
            ) {
                DownloadsQueueScreen(onBack = { showDownloadsQueue = false })
            }
            androidx.activity.compose.BackHandler { showDownloadsQueue = false }
        }
        
        // Modal Loading Indicator during export/import processing
        if (isOperating) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .clickable(enabled = false) {},
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Processing data...",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
        
        // Confirmation dialog for clearing cache
        if (showClearConfirmDialog) {
            LorelightDialog(
                onDismissRequest = { showClearConfirmDialog = false },
                title = { Text("Clear Offline Chapters?", fontWeight = FontWeight.Bold) },
                text = { Text("This will permanently delete ${cacheStats.fileCount} downloaded chapter texts from offline cache, freeing up ${cacheStats.totalSizeFormatted} of space. You will need internet connections to load these chapters next time. Progress is kept.") },
                isDestructive = true,
                confirmButton = {
                    Button(
                        onClick = {
                            showClearConfirmDialog = false
                            val done = deleteChaptersCache(context)
                            if (done) {
                                cacheStats = getCacheStats(context)
                                Toast.makeText(context, "Offline chapters cache cleared successfully!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Failed to clear cache.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Delete", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showClearConfirmDialog = false }) {
                        Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            )
        }

        val toDelete = selectedForDelete
        if (toDelete != null) {
            LorelightDialog(
                onDismissRequest = { selectedForDelete = null },
                title = { Text("Delete downloads?", fontWeight = FontWeight.Bold) },
                text = { Text("This removes ${toDelete.fileCount} offline chapters for ${toDelete.title}. Your reading progress and the novel itself are not affected.") },
                isDestructive = true,
                confirmButton = {
                    Button(
                        onClick = {
                            val target = toDelete
                            selectedForDelete = null
                            coroutineScope.launch {
                                withContext(Dispatchers.IO) {
                                    val novels = com.lorelight.data.local.NovelPreferences.loadNovelsFromPrefs(context)
                                    if (target.novelId == "__orphaned__") {
                                        deleteOrphanedCache(context, novels)
                                    } else {
                                        val match = novels.find { it.id == target.novelId }
                                        if (match != null) {
                                            deleteCacheForNovel(context, match)
                                        }
                                    }
                                }
                                cacheStats = getCacheStats(context)
                                val updatedStats = withContext(Dispatchers.IO) {
                                    val novels = com.lorelight.data.local.NovelPreferences.loadNovelsFromPrefs(context)
                                    getPerNovelCacheStats(context, novels)
                                }
                                perNovelStats = updatedStats
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Delete", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedForDelete = null }) {
                        Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            )
        }
        
        // Confirmation dialog for restoring backup
        if (showRestoreConfirmDialog) {
            LorelightDialog(
                onDismissRequest = { showRestoreConfirmDialog = false },
                title = { Text("Confirm Library Restore & Merge?", fontWeight = FontWeight.Bold) },
                text = { Text("This will safely merge the backup's novels, websites, custom text replacement rules, and custom settings into your current application state. Any current novels and websites will remain completely untouched.") },
                confirmButton = {
                    Button(
                        onClick = {
                            showRestoreConfirmDialog = false
                            isOperating = true
                            coroutineScope.launch {
                                val success = withContext(Dispatchers.IO) {
                                    restoreBackupJson(context, pendingRestoreContent)
                                }
                                isOperating = false
                                if (success) {
                                    onRestoreSuccess()
                                    cacheStats = getCacheStats(context)
                                    Toast.makeText(context, "Data successfully restored and merged!", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "Failed to restore backup. File is corrupted or invalid.", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Restore Now", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showRestoreConfirmDialog = false }) {
                        Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            )
        }

        // Confirmation dialog for auto backup restore
        val autoRestoreTarget = showAutoRestoreConfirmDialog
        if (autoRestoreTarget != null) {
            val targetInfo = autoRestoreTarget
            LorelightDialog(
                onDismissRequest = { showAutoRestoreConfirmDialog = null },
                title = { Text("Restore Daily Auto-Backup?", fontWeight = FontWeight.Bold) },
                text = { Text("This will restore library progress, custom replacement rules, configured websites and client setup from the daily auto-backup updated on ${targetInfo.dateFormatted}.\n\nYour library will merge safely without losing newer additions.") },
                confirmButton = {
                    Button(
                        onClick = {
                            showAutoRestoreConfirmDialog = null
                            isOperating = true
                            coroutineScope.launch {
                                val success = withContext(Dispatchers.IO) {
                                    try {
                                        val content = if (targetInfo.file != null) {
                                            targetInfo.file.readText()
                                        } else if (targetInfo.uri != null) {
                                            context.contentResolver.openInputStream(targetInfo.uri)?.use { stream ->
                                                stream.bufferedReader().use { it.readText() }
                                            } ?: ""
                                        } else {
                                            ""
                                        }
                                        if (content.isNotEmpty()) {
                                            restoreBackupJson(context, content)
                                        } else {
                                            false
                                        }
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                        false
                                    }
                                }
                                isOperating = false
                                if (success) {
                                    onRestoreSuccess()
                                    cacheStats = getCacheStats(context)
                                    Toast.makeText(context, "State restored successfully from automated backup!", Toast.LENGTH_LONG).show()
                                } else {
                                    Toast.makeText(context, "Failed to restore backup file.", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Restore Now", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAutoRestoreConfirmDialog = null }) {
                        Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            )
        }

        // Large Dialog to view the Crash Report
        val crashReport = viewingCrashReport
        if (crashReport != null) {
            val report = crashReport
            val metaObj = remember(report) {
                try {
                    if (!report.metadata.isNullOrEmpty()) JSONObject(report.metadata) else null
                } catch (e: Exception) {
                    null
                }
            }
            val copyableContext = remember(report, metaObj) {
                if (metaObj != null) {
                    val logsArr = metaObj.optJSONArray("diagnostic_logs")
                    val logsStr = if (logsArr != null && logsArr.length() > 0) {
                        val sb = java.lang.StringBuilder()
                        for (i in 0 until logsArr.length()) {
                            sb.append(logsArr.optString(i)).append("\n")
                        }
                        sb.toString()
                    } else "None."
                    
                    """
                        App Version: ${metaObj.optString("app_version", "unknown")}
                        Build Type: ${metaObj.optString("build_type", "unknown")}
                        Memory Class: ${metaObj.optString("memory_class", "unknown")}MB
                        Low Memory Mode: ${metaObj.optBoolean("is_low_memory", false)}
                        Device Display info: ${metaObj.optString("device_screen_dp", "unknown")}
                        
                        DIAGNOSTICS LOGS AT CRASH:
                        $logsStr
                    """.trimIndent()
                } else "No clinical context stored."
            }

            LorelightDialog(
                onDismissRequest = { viewingCrashReport = null },
                title = { Text("Diagnostics & Crash Details", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error) },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(0.65f)
                            .verticalScroll(androidx.compose.foundation.rememberScrollState())
                    ) {
                        Text(
                            text = "Primary message:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = report.message,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        Text(
                            text = "StackTrace Analysis:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = report.stackTrace,
                                fontSize = 10.sp,
                                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                                lineHeight = 13.sp
                            )
                        }
                        
                        if (metaObj != null) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "Device System Metadata Context:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.Black.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = copyableContext,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            try {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                val reportString = """
                                    == LORELIGHT PREMIUM CRASH REPORT ==
                                    Timestamp: ${report.timestamp}
                                    Message: ${report.message}
                                    Cause: ${report.cause}
                                    Thread: ${report.thread}
                                    $copyableContext
                                    
                                    STACKTRACE:
                                    ${report.stackTrace}
                                """.trimIndent()
                                val clip = android.content.ClipData.newPlainText("Lorelight Premium Crash Report", reportString)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Premium crash report copied to clipboard!", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Failed to copy.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Copy Report", fontWeight = FontWeight.Bold)
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { viewingCrashReport = null }) {
                        Text("Dismiss", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            )
        }
    }
}

@Composable
fun StatItem(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    subtext: String? = null
) {
    Column(
        modifier = modifier.padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = value,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
        if (subtext != null) {
            Text(
                text = subtext,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center
            )
        }
        Text(
            text = label,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun borderIndicator(): BorderStroke {
    return BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
}

@Composable
fun SettingActionCard(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    iconTint: Color = MaterialTheme.colorScheme.primary
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(iconTint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    fontSize = 11.sp,
                    lineHeight = 15.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis
                )
            }
            
            Spacer(modifier = Modifier.width(8.dp))
            
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
fun LibraryUpdatesSettingsSection(
    onOpenNewChapters: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val settingsVersion by com.lorelight.data.local.AppSettingsSignal.version.collectAsState()
    val prefs = remember(context, settingsVersion) { loreSettingsPrefs(context) }

    var enabled by remember(settingsVersion) { mutableStateOf(prefs.getBoolean("lib_update_enabled", false)) }
    var intervalHours by remember(settingsVersion) { mutableStateOf(prefs.getLong("lib_update_hours", 12L)) }
    var wifiOnly by remember(settingsVersion) { mutableStateOf(prefs.getBoolean("lib_update_wifi_only", true)) }
    var chargingOnly by remember(settingsVersion) { mutableStateOf(prefs.getBoolean("lib_update_charging_only", false)) }
    var skipCompleted by remember(settingsVersion) { mutableStateOf(prefs.getBoolean("lib_update_skip_completed", true)) }

    val pendingUpdates by com.lorelight.service.NewChaptersManager.pendingUpdates.collectAsState()
    val isScanning by com.lorelight.service.NewChaptersManager.isScanning.collectAsState()

    fun syncWork() {
        if (enabled) {
            com.lorelight.work.LibraryUpdateScheduler.schedule(context, intervalHours, wifiOnly, chargingOnly)
        } else {
            com.lorelight.work.LibraryUpdateScheduler.cancel(context)
        }
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        border = borderIndicator(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(
                text = "NEW CHAPTER NOTIFICATIONS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp
            )

            // Master Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "New chapter notifications",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Periodically check followed novels & manga for new chapters",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
                Switch(
                    checked = enabled,
                    onCheckedChange = { newValue ->
                        enabled = newValue
                        prefs.edit().putBoolean("lib_update_enabled", newValue).commit()
                        syncWork()
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = MaterialTheme.colorScheme.primary,
                        checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                    )
                )
            }

            // Quick Access / Status Card
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenNewChapters() }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.NewReleases,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Review Pending Updates",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (pendingUpdates.isNotEmpty()) {
                                    "${pendingUpdates.size} ${if (pendingUpdates.size == 1) "title" else "titles"} with unimported chapters"
                                } else {
                                    "No pending chapters · Tap to review"
                                },
                                fontSize = 11.sp,
                                color = if (pendingUpdates.isNotEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Check Now Button
            OutlinedButton(
                onClick = {
                    if (!isScanning) {
                        coroutineScope.launch {
                            android.widget.Toast.makeText(context, "Checking library for updates...", android.widget.Toast.LENGTH_SHORT).show()
                            val found = com.lorelight.service.NewChaptersManager.scanLibrary(context)
                            if (found > 0) {
                                android.widget.Toast.makeText(context, "Found $found title update${if (found == 1) "" else "s"}!", android.widget.Toast.LENGTH_SHORT).show()
                            } else {
                                android.widget.Toast.makeText(context, "Library is already up to date.", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                },
                enabled = !isScanning,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isScanning) {
                    CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Scanning Library...", fontSize = 12.sp)
                } else {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Check for Updates Now", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            if (enabled) {
                HorizontalDivider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f))

                // Interval selector (6h / 12h / 24h)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Check Frequency",
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(6L to "6 Hours", 12L to "12 Hours", 24L to "24 Hours").forEach { (hrs, label) ->
                            val selected = intervalHours == hrs
                            FilterChip(
                                selected = selected,
                                onClick = {
                                    intervalHours = hrs
                                    prefs.edit().putLong("lib_update_hours", hrs).commit()
                                    syncWork()
                                },
                                label = { Text(label, fontSize = 12.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                HorizontalDivider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f))

                // Wi-Fi Only Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Wi-Fi only",
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Only check when connected to unmetered Wi-Fi",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                    Switch(
                        checked = wifiOnly,
                        onCheckedChange = { newValue ->
                            wifiOnly = newValue
                            prefs.edit().putBoolean("lib_update_wifi_only", newValue).commit()
                            syncWork()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.primary,
                            checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }

                // Charging Only Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Only while charging",
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Only run checks when the device is plugged in",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                    Switch(
                        checked = chargingOnly,
                        onCheckedChange = { newValue ->
                            chargingOnly = newValue
                            prefs.edit().putBoolean("lib_update_charging_only", newValue).commit()
                            syncWork()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.primary,
                            checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }

                // Skip Completed Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Skip completed titles",
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Ignore finished novels and completed manga",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                    Switch(
                        checked = skipCompleted,
                        onCheckedChange = { newValue ->
                            skipCompleted = newValue
                            prefs.edit().putBoolean("lib_update_skip_completed", newValue).commit()
                            syncWork()
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.primary,
                            checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    )
                }
            }

            Text(
                text = "Notifications update in place per title with no duplicates. Tapping any alert opens the New Chapters review screen.",
                fontSize = 11.sp,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
            )
        }
    }
}

