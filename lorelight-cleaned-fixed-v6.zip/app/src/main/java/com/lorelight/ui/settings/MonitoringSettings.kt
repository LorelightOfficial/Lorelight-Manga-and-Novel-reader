package com.lorelight.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import uy.kohesive.injekt.api.get

/*
 * FEATURE E29 + E32.
 *
 * The app already tracked everything needed to answer "what is downloading,
 * what is stored, and are my sources healthy?" - chapter cache files, saved
 * EPUBs, extension APKs, the queued-write depth, the automatic-update job, the
 * self-healing recovery notice, the Cloudflare interceptor and the installed
 * plugin/extension records. None of it was ever shown to the user, so a stuck
 * download or a silent automatic restore was invisible. These two read-only
 * sections surface that existing state. No new background work is started.
 */

private data class DirUsage(val fileCount: Int, val bytes: Long)

private fun measureDir(dir: File, extension: String? = null): DirUsage {
    if (!dir.exists() || !dir.isDirectory) return DirUsage(0, 0L)
    val files = dir.listFiles() ?: return DirUsage(0, 0L)
    val matching = files.filter {
        it.isFile && (extension == null || it.name.endsWith(extension, ignoreCase = true))
    }
    return DirUsage(matching.size, matching.sumOf { it.length() })
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text = text,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        letterSpacing = 1.sp
    )
}

@Composable
private fun MonitorRow(label: String, value: String, detail: String? = null) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.padding(end = 12.dp)) {
            Text(
                text = label,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (detail != null) {
                Text(
                    text = detail,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
        Text(
            text = value,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

/**
 * E29: "Downloads & storage" monitor.
 *
 * Everything here is read from state the app already keeps:
 *  - chapter cache files      -> getCacheStats(context)
 *  - saved books              -> filesDir/epubs
 *  - installed extension APKs -> private extension storage folder (filesDir/exts)
 *  - unsaved library writes   -> NovelPreferences.pendingWriteCount()
 *  - background update job    -> the lib_update_* settings keys
 */
@Composable
fun DownloadsMonitorSection(
    onOpenDownloadsQueue: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { com.lorelight.data.local.AppPrefs.get(context) }

    var refreshKey by remember { mutableIntStateOf(0) }
    var cacheFiles by remember { mutableIntStateOf(0) }
    var cacheBytes by remember { mutableStateOf(0L) }
    var epubFiles by remember { mutableIntStateOf(0) }
    var epubBytes by remember { mutableStateOf(0L) }
    var apkFiles by remember { mutableIntStateOf(0) }
    var apkBytes by remember { mutableStateOf(0L) }
    var ocrCacheFiles by remember { mutableIntStateOf(0) }
    var ocrCacheBytes by remember { mutableStateOf(0L) }
    var pendingWrites by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var statusLine by remember { mutableStateOf<String?>(null) }

    // Measure on the IO dispatcher: these are directory scans, not main-thread work.
    LaunchedEffect(refreshKey) {
        val chapters = withContext(Dispatchers.IO) { getCacheStats(context) }
        val epubs = withContext(Dispatchers.IO) {
            measureDir(File(context.filesDir, "epubs"), ".epub")
        }
        val apks = withContext(Dispatchers.IO) {
            measureDir(File(context.filesDir, "exts"), ".ext")
        }
        cacheFiles = chapters.fileCount
        cacheBytes = chapters.sizeInBytes
        epubFiles = epubs.fileCount
        epubBytes = epubs.bytes
        apkFiles = apks.fileCount
        apkBytes = apks.bytes
        val ocr = withContext(Dispatchers.IO) { com.lorelight.manga.download.MangaOcrCache.stats(context) }
        ocrCacheFiles = ocr.first
        ocrCacheBytes = ocr.second
    }

    // Live queue depth. Cheap in-memory counter, polled only while visible.
    LaunchedEffect(Unit) {
        while (true) {
            pendingWrites = com.lorelight.data.local.NovelPreferences.pendingWriteCount()
            delay(1_500L)
        }
    }

    val autoUpdateEnabled = prefs.getBoolean("lib_update_enabled", false)
    val autoUpdateHours = prefs.getLong("lib_update_hours", 12L)
    val wifiOnly = prefs.getBoolean("lib_update_wifi_only", true)
    val chargingOnly = prefs.getBoolean("lib_update_charging_only", false)
    val totalBytes = cacheBytes + epubBytes + apkBytes + ocrCacheBytes

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        border = borderIndicator(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader("DOWNLOADS & STORAGE MONITOR")
                if (onOpenDownloadsQueue != null) {
                    Text(
                        text = "Open Queue →",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .clickable { onOpenDownloadsQueue() }
                            .padding(vertical = 2.dp)
                    )
                }
            }

            val activeJob = com.lorelight.data.download.DownloadProgressBus.current
            if (activeJob != null) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = if (activeJob.active) "Downloading now" else "Last download",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "${activeJob.kind}: ${activeJob.title}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (activeJob.active) {
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                    Text(
                        text = if (activeJob.total > 0) "${activeJob.current} / ${activeJob.total} - ${activeJob.status}" else activeJob.status,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (!activeJob.active) {
                        TextButton(onClick = { com.lorelight.data.download.DownloadProgressBus.clear() }) {
                            Text("Dismiss", fontSize = 12.sp)
                        }
                    }
                }
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f)
                )
            }

            MonitorRow(
                label = "Downloaded chapters",
                value = "$cacheFiles",
                detail = "Offline chapter text - ${formatBytes(cacheBytes)}"
            )
            MonitorRow(
                label = "Imported books",
                value = "$epubFiles",
                detail = "EPUB files kept in app storage - ${formatBytes(epubBytes)}"
            )
            MonitorRow(
                label = "Extension packages",
                value = "$apkFiles",
                detail = "Installed manga extension APKs - ${formatBytes(apkBytes)}"
            )
            MonitorRow(
                label = "Pre-computed manga OCR",
                value = "$ocrCacheFiles",
                detail = "Recognised manga pages ready to read - ${formatBytes(ocrCacheBytes)}"
            )

            HorizontalDivider(
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f)
            )

            MonitorRow(
                label = "Total app data measured",
                value = formatBytes(totalBytes)
            )
            MonitorRow(
                label = "Unsaved library writes",
                value = "$pendingWrites",
                detail = if (pendingWrites == 0) {
                    "Everything is written to disk"
                } else {
                    "Queued database writes waiting to finish"
                }
            )
            MonitorRow(
                label = "Background chapter checks",
                value = if (autoUpdateEnabled) "Every ${autoUpdateHours}h" else "Off",
                detail = if (!autoUpdateEnabled) {
                    "Turn on Library Updates to check for new chapters"
                } else {
                    buildString {
                        append(if (wifiOnly) "Wi-Fi only" else "Any network")
                        if (chargingOnly) append(" - while charging")
                    }
                }
            )

            HorizontalDivider(
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f)
            )

            var ocrOnDownload by remember { mutableStateOf(com.lorelight.manga.download.MangaOcrCache.isOcrOnDownloadEnabled(context)) }
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Run OCR while downloading manga",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        "Recognise speech bubbles as each manga downloads so the reader does not wait for OCR later.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(8.dp))
                Switch(
                    checked = ocrOnDownload,
                    onCheckedChange = {
                        ocrOnDownload = it
                        com.lorelight.manga.download.MangaOcrCache.setOcrOnDownloadEnabled(context, it)
                    }
                )
            }

            statusLine?.let {
                Text(
                    text = it,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextButton(
                    onClick = { refreshKey++ },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Refresh", fontSize = 13.sp)
                }
                TextButton(
                    onClick = {
                        if (!busy) {
                            busy = true
                            statusLine = "Finishing queued writes..."
                            scope.launch {
                                val drained = withContext(Dispatchers.IO) {
                                    com.lorelight.data.local.NovelPreferences.flushPendingWrites()
                                }
                                pendingWrites =
                                    com.lorelight.data.local.NovelPreferences.pendingWriteCount()
                                statusLine = if (drained) {
                                    "All pending writes are saved."
                                } else {
                                    "Some writes are still running - they will finish in the background."
                                }
                                busy = false
                            }
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Save now", fontSize = 13.sp)
                }
            }
        }
    }
}

/**
 * E32: source & extension health.
 *
 * Surfaces state that already existed but had no UI:
 *  - SelfHealingEngine.pendingRecoveryNotice(): an automatic restore that
 *    replaced the library without telling anyone (FIX A7 recorded it).
 *  - HttpClients.isCloudflareAware(): whether the Cloudflare challenge solver
 *    is actually installed on the shared HTTP client (FIX C17 wired it up).
 *  - Installed novel plugins and manga extensions, with their source counts.
 *  - Handled errors already collected by CrashReporter.
 */
@Composable
fun SourceHealthSettingsSection() {
    val context = LocalContext.current

    var refreshKey by remember { mutableIntStateOf(0) }
    var pluginCount by remember { mutableIntStateOf(0) }
    var pinnedPlugins by remember { mutableIntStateOf(0) }
    var extensionCount by remember { mutableIntStateOf(0) }
    var sourceCount by remember { mutableIntStateOf(0) }
    var errorCount by remember { mutableIntStateOf(0) }
    var recovery by remember {
        mutableStateOf(com.lorelight.core.SelfHealingEngine.pendingRecoveryNotice(context))
    }

    LaunchedEffect(refreshKey) {
        val plugins = withContext(Dispatchers.IO) {
            com.lorelight.browse.repo.PluginStore.getInstalled(context)
        }
        val extensions = withContext(Dispatchers.IO) {
            uy.kohesive.injekt.Injekt.get<eu.kanade.tachiyomi.extension.ExtensionManager>().installedExtensionsFlow.value
        }
        val errors = withContext(Dispatchers.IO) {
            com.lorelight.core.CrashReporter.getCrashReports(context)
        }
        pluginCount = plugins.size
        pinnedPlugins = plugins.count { it.pinned }
        extensionCount = extensions.size
        sourceCount = extensions.sumOf { it.sources.size }
        errorCount = errors.size
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        border = borderIndicator(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SectionHeader("SOURCE & EXTENSION HEALTH")

            recovery?.let { notice ->
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Library was automatically recovered",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.error
                    )
                    Text(
                        text = "${notice.reason} - restored ${notice.novelCount} item(s) on " +
                            java.text.SimpleDateFormat(
                                "d MMM yyyy, HH:mm",
                                java.util.Locale.getDefault()
                            ).format(java.util.Date(notice.at)),
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    notice.undoBackupPath?.let { path ->
                        Text(
                            text = "A copy of the previous data is kept at: $path",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                    TextButton(onClick = {
                        com.lorelight.core.SelfHealingEngine.acknowledgeRecoveryNotice(context)
                        recovery = null
                    }) {
                        Text("Got it", fontSize = 13.sp)
                    }
                }
                HorizontalDivider(
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f)
                )
            }

            MonitorRow(
                label = "Novel plugins installed",
                value = "$pluginCount",
                detail = if (pinnedPlugins > 0) "$pinnedPlugins pinned to a fixed version" else null
            )
            MonitorRow(
                label = "Manga extensions installed",
                value = "$extensionCount",
                detail = "Providing $sourceCount source(s)"
            )
            MonitorRow(
                label = "Cloudflare challenge solver",
                value = if (com.lorelight.network.HttpClients.isCloudflareAware()) "Active" else "Unavailable",
                detail = if (com.lorelight.network.HttpClients.isCloudflareAware()) {
                    "Protected sites are retried with a browser check"
                } else {
                    "Sites behind Cloudflare may fail to load"
                }
            )
            MonitorRow(
                label = "Handled errors recorded",
                value = "$errorCount",
                detail = "Kept for diagnostics only, never uploaded"
            )

            TextButton(onClick = { refreshKey++ }, modifier = Modifier.fillMaxWidth()) {
                Text("Refresh", fontSize = 13.sp)
            }
        }
    }
}


/**
 * Manual "refetch details" control.
 *
 * Re-downloads everything the Details page renders - cover art, genres,
 * description, author, status and the whole chapter list - for every novel in
 * the library. Reading progress (current chapter, scroll/paragraph/word
 * position, completed chapters, favourites, categories and reading status) is
 * preserved untouched.
 */
@Composable
fun RefetchDetailsSection() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var busy by remember { mutableStateOf(false) }
    var doneCount by remember { mutableIntStateOf(0) }
    var totalCount by remember { mutableIntStateOf(0) }
    var lastResult by remember { mutableStateOf<String?>(null) }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
        border = borderIndicator(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                text = "REFETCH NOVEL DETAILS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp
            )
            Text(
                text = "Re-downloads cover art, genres, description, author, status and the full chapter list for every novel. Your reading progress, bookmarks, favourites and downloads are kept.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f)
            )

            if (busy) {
                if (totalCount > 0) {
                    LinearProgressIndicator(
                        progress = { doneCount.toFloat() / totalCount.toFloat() },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                Text(
                    text = if (totalCount > 0) "Refetching $doneCount / $totalCount..." else "Preparing...",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            lastResult?.let { msg ->
                Text(text = msg, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            }

            TextButton(
                onClick = {
                    if (!busy) {
                        busy = true
                        lastResult = null
                        doneCount = 0
                        totalCount = 0
                        scope.launch {
                            val refreshed = withContext(Dispatchers.IO) {
                                com.lorelight.service.NovelImportManager.refetchAllNovelDetails(context) { d, t ->
                                    doneCount = d
                                    totalCount = t
                                }
                            }
                            busy = false
                            lastResult = "Refetched $refreshed novel(s). Reading progress kept."
                        }
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (busy) "Refetching..." else "Refetch all novel details", fontSize = 13.sp)
            }
        }
    }
}

/**
 * Debug network speed throttle setting.
 * Allows simulating slow 2G/3G/4G network speeds to test streaming and error conditions on-demand.
 */
@Composable
fun NetworkThrottleSection() {
    val context = LocalContext.current
    if (!com.lorelight.core.DevLogStore.isDevModeUnlocked(context)) return

    var selectedKbps by remember {
        mutableIntStateOf(com.lorelight.network.NetworkThrottle.getThrottleKbps(context))
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        border = borderIndicator(),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Debug: simulated network speed",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 0.5.sp
                )
                if (selectedKbps > 0) {
                    val activePreset = com.lorelight.network.NetworkThrottle.PRESETS.find { it.kbps == selectedKbps }
                    val speedLabel = activePreset?.description ?: "~$selectedKbps KB/s"
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "Active: $speedLabel",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Text(
                text = "Deliberately slows all network downloads and should be left Off during normal use. Simulates slow speeds to test progressive manga image streaming and network resilience. Takes effect immediately.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
            )

            // Segmented preset selectors
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.6f))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                com.lorelight.network.NetworkThrottle.PRESETS.forEach { preset ->
                    val isSelected = selectedKbps == preset.kbps
                    Surface(
                        onClick = {
                            selectedKbps = preset.kbps
                            com.lorelight.network.NetworkThrottle.setThrottleKbps(context, preset.kbps)
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) {
                            if (preset.kbps > 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        } else {
                            Color.Transparent
                        },
                        contentColor = if (isSelected) {
                            if (preset.kbps > 0) MaterialTheme.colorScheme.onError else MaterialTheme.colorScheme.onPrimary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Selected",
                                        modifier = Modifier
                                            .size(12.dp)
                                            .padding(end = 2.dp)
                                    )
                                }
                                Text(
                                    text = preset.label,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                            Text(
                                text = preset.description,
                                fontSize = 10.sp,
                                color = if (isSelected) {
                                    (if (preset.kbps > 0) MaterialTheme.colorScheme.onError else MaterialTheme.colorScheme.onPrimary).copy(alpha = 0.85f)
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
