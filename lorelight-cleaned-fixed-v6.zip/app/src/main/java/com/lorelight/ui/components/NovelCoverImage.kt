package com.lorelight.ui.components

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val base64ImageCache = java.util.concurrent.ConcurrentHashMap<String, androidx.compose.ui.graphics.ImageBitmap>()

/**
 * Clears the in-memory decoded Base64 / EPUB cover bitmaps. Called by
 * MemoryManager when the app is backgrounded or the system is low on memory.
 * The bitmaps are re-decoded lazily on next display, so this is safe.
 */
fun clearBase64ImageCache() {
    base64ImageCache.clear()
}

@Composable
fun NovelCoverImage(
    coverBase64: String?,
    title: String = "Novel",
    modifier: Modifier = Modifier,
    placeholderKey: String? = null
) {
    if (coverBase64 == null) {
        Box(
            modifier = modifier.background(Color.Transparent),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.MenuBook,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = title.split(" ").firstOrNull() ?: "Novel",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        return
    }

    if (coverBase64.startsWith("http://") || coverBase64.startsWith("https://")) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(coverBase64)
                .memoryCacheKey(coverBase64)
                .diskCacheKey(coverBase64)
                .placeholderMemoryCacheKey(coverBase64)
                // A short fade still hides the pop-in but does not make a
                // cached cover look slow. The default (~200 ms) reads as lag
                // when you are scrolling a shelf.
                .crossfade(100)
                .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                .build(),
            contentDescription = "Novel Cover",
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
        return
    }

    if (coverBase64.startsWith("file://")) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(java.io.File(coverBase64.removePrefix("file://")))
                .memoryCacheKey(coverBase64)
                .diskCacheKey(coverBase64)
                .placeholderMemoryCacheKey(placeholderKey ?: coverBase64)
                .crossfade(false)
                .build(),
            contentDescription = "Novel Cover",
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
        return
    }

    // Check high-speed cache first!
    val cachedBitmap = base64ImageCache[coverBase64]
    if (cachedBitmap != null) {
        Image(
            bitmap = cachedBitmap,
            contentDescription = "Novel Cover",
            contentScale = ContentScale.Crop,
            modifier = modifier
        )
        return
    }

    var imageBitmap by remember(coverBase64) { mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null) }
    var isLoading by remember(coverBase64) { mutableStateOf(true) }

    LaunchedEffect(coverBase64) {
        withContext(Dispatchers.IO) {
            try {
                val decodedString = Base64.decode(coverBase64, Base64.DEFAULT)
                val bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
                val imgBmp = bitmap?.asImageBitmap()
                if (imgBmp != null) {
                    base64ImageCache[coverBase64] = imgBmp
                }
                withContext(Dispatchers.Main) {
                    imageBitmap = imgBmp
                    isLoading = false
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    isLoading = false
                }
            }
        }
    }

    if (isLoading) {
        Box(
            modifier = modifier.background(Color.White.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.MenuBook,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f),
                modifier = Modifier.size(24.dp)
            )
        }
    } else {
        val bitmap = imageBitmap
        if (bitmap != null) {
            Image(
                bitmap = bitmap,
                contentDescription = "Novel Cover",
                contentScale = ContentScale.Crop,
                modifier = modifier
            )
        } else {
            Box(
                modifier = modifier.background(Color.Transparent),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(8.dp)
                ) {
                    Icon(
                    imageVector = Icons.Filled.MenuBook,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = title.split(" ").firstOrNull() ?: "Novel",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White.copy(alpha = 0.8f),
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                }
            }
        }
    }
}
