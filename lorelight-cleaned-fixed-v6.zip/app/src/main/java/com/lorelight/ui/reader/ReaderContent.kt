package com.lorelight.ui.reader

import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.State
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.R
import com.lorelight.crawler.CrawlerEngine
import com.lorelight.data.model.Novel
import com.lorelight.ui.components.resolveFontFamily
import com.lorelight.utils.Token
import com.lorelight.utils.EpubExtractor
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.shape.CircleShape
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ReaderContent(
    listState: LazyListState,
    readerBackgroundType: String,
    themeState: String,
    readerBgColor: Color,
    readerTextColor: Color,
    readerHighlightColor: Color,
    filteredSentences: List<ReaderBlock>,
    novelId: String,
    tokensBySentence: List<List<Token>>,
    activeSentenceIndexState: State<Int>,
    readerMode: String,
    fontSize: Float,
    lineSpacing: Float,
    paragraphSpacing: Float,
    textAlignment: String,
    readerFontFamily: String,
    selRange: WordRange?,
    selectionVersion: Int,
    wordPositions: SnapshotStateMap<Int, WordPosition>,
    wordIndexMap: Map<Int, String>,
    activeChapterIndex: Int,
    chapters: List<String>,
    highlights: List<Highlight> = emptyList(),
    onSentenceClick: (Int) -> Unit,
    onWordSelected: (WordRange, Boolean) -> Unit,
    onPositioned: (Int, Offset, Offset) -> Unit,
    onParagraphLongClick: (Int) -> Unit,
    onChapterSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    // THEME-BG FIX. This used to be hardcoded true, so selecting "Theme"
    // as the reader background always painted a decorative drawable over
    // the flat theme colour. That overlay is what made the theme background
    // look off -- and for any theme not in the drawable map below it fell
    // back to the GREEN texture, tinting unrelated themes green.
    // The texture is now opt-in via Settings -> Reader -> Background texture.
    val hasReaderBgImage = context
        .getSharedPreferences("reader_prefs", android.content.Context.MODE_PRIVATE)
        .getBoolean("reader_bg_texture", true)
    var activeFullscreenImageBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }

    Box(modifier = modifier.fillMaxSize()) {
        // GREY-WASH FIX. This used to draw the decorative texture at FULL
        // opacity and then wash only a 40%-alpha theme color over it, so ~60%
        // of what you actually saw was raw image instead of the theme color --
        // that is the greyish layer sitting over every theme.
        //
        // It was also gated on the background *type* alone, so the AMOLED app
        // theme (which resolves to pure black) still got a full-opacity texture
        // painted on top of the black, which is why AMOLED came out completely
        // grey instead of #000000.
        //
        // Now: the theme color is always the flat base, the texture is only a
        // faint accent above it, and anything that resolves to pure black gets
        // no texture at all.
        val showBgImage = readerBackgroundType == "Theme" &&
            hasReaderBgImage &&
            readerBgColor != Color.Black

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(readerBgColor)
        )

        if (showBgImage) {
            Image(
                painter = painterResource(
                    id = when (themeState) {
                        "blackgold" -> R.drawable.readergold
                        "Satin Pink" -> R.drawable.readerpink
                        "readerblacknew" -> R.drawable.readerblack
                        "Ocean Blue" -> R.drawable.readerblue
                        "cyne" -> R.drawable.readercyne
                        "readerpurple" -> R.drawable.readerpurple
                        "readerblood" -> R.drawable.readerred
                        else -> R.drawable.readergreen
                    }
                ),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alpha = 0.20f,
                modifier = Modifier.fillMaxSize()
            )
        }

        if (filteredSentences.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = readerHighlightColor)
            }
        } else {
            val currentFontFamily = remember(readerFontFamily) { resolveFontFamily(readerFontFamily, context) }
            val isCaveat = remember(readerFontFamily) { readerFontFamily == "System Cursive" || readerFontFamily == "Cursive" }
            val alignStyle = remember(textAlignment) {
                when (textAlignment) {
                    "Center" -> TextAlign.Center
                    "Right" -> TextAlign.Right
                    "Justify" -> TextAlign.Justify
                    else -> TextAlign.Left
                }
            }

            val premiumFling = rememberPremiumKineticFlingBehavior()

            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.TopCenter
            ) {
                LazyColumn(
                    state = listState,
                    flingBehavior = premiumFling,
                    userScrollEnabled = true,
                    contentPadding = PaddingValues(
                        start = 20.dp,
                        end = 20.dp,
                        top = 16.dp,
                        bottom = if (readerMode == "Listen") 120.dp else 32.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(paragraphSpacing.dp),
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                ) {
                    itemsIndexed(
                        filteredSentences,
                        // FIX #18: key on content identity, not slot position, so
                        // per-item selection/layout state cannot be inherited by a
                        // different paragraph when the filtered list changes.
                        // The index stays in the key to keep duplicate paragraphs
                        // (very common: "..." , "***") distinct.
                        key = { index, block ->
                            when (block) {
                                is ReaderBlock.TextBlock -> "t$index:${block.text.hashCode()}"
                                is ReaderBlock.ImageBlock -> "i$index:${block.entryPath}"
                            }
                        },
                        // Lets Compose recycle text rows and image rows separately.
                        contentType = { _, block ->
                            if (block is ReaderBlock.ImageBlock) "img" else "txt"
                        }
                    ) { index, sentence ->
                        // derivedStateOf: only the row whose active-state actually flips recomposes,
                        // instead of every visible row on each TTS sentence change.
                        val isActiveSentence by remember(index, readerMode) {
                            derivedStateOf { readerMode == "Listen" && activeSentenceIndexState.value == index }
                        }
                        val textColor = if (isActiveSentence) readerHighlightColor else readerTextColor
                        // FIX #21: plain indexed read. The old remember() was keyed
                        // on the entire list, so it invalidated for every row on any
                        // change - strictly more work than the lookup it cached.
                        val sentenceTokens = tokensBySentence.getOrNull(index) ?: emptyList()
                        
                        val onSentenceClickLambda = remember(index, readerMode) {
                            { onSentenceClick(index) }
                        }
                        
                        val onSentenceLongClick = remember(index, sentenceTokens) {
                            { onParagraphLongClick(index) }
                        }

                        val onWordSelectedLambda = remember {
                            { range: WordRange, isDragging: Boolean ->
                                onWordSelected(range, isDragging)
                            }
                        }

                        val onPositionedLambda = remember {
                            { wordIdx: Int, left: Offset, right: Offset ->
                                onPositioned(wordIdx, left, right)
                            }
                        }

                        when (sentence) {
                            is ReaderBlock.TextBlock -> {
                                SentenceRow(
                                    index = index,
                                    sentence = sentence.text,
                                    isActiveSentence = isActiveSentence,
                                    readerMode = readerMode,
                                    textColor = textColor,
                                    readerHighlightColor = readerHighlightColor,
                                    readerTextColor = readerTextColor,
                                    currentFontFamily = currentFontFamily,
                                    isCaveat = isCaveat,
                                    alignStyle = alignStyle,
                                    textAlignment = textAlignment,
                                    fontSize = fontSize,
                                    lineSpacing = lineSpacing,
                                    paragraphSpacing = paragraphSpacing,
                                    selRange = selRange,
                                    selectionVersion = selectionVersion,
                                    sentenceTokens = sentenceTokens,
                                    wordPositions = wordPositions,
                                    highlights = highlights,
                                    onSentenceClick = onSentenceClickLambda,
                                    onSentenceLongClick = onSentenceLongClick,
                                    onWordSelected = onWordSelectedLambda,
                                    onPositioned = onPositionedLambda
                                )
                            }
                            is ReaderBlock.ImageBlock -> {
                                EpubImage(
                                    novelId = novelId,
                                    entryPath = sentence.entryPath,
                                    onImageClick = { bitmap ->
                                        activeFullscreenImageBitmap = bitmap
                                    }
                                )
                            }
                        }
                    }

                    if (readerMode == "Read") {
                        item {
                            Spacer(modifier = Modifier.height(24.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(56.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(1.dp, readerTextColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                    .background(readerTextColor.copy(alpha = 0.04f)),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Previous Button
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .clickable(enabled = activeChapterIndex > 0 && !listState.isScrollInProgress) {
                                            onChapterSelect(activeChapterIndex - 1)
                                        }
                                        .alpha(if (activeChapterIndex > 0) 1.0f else 0.35f),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.KeyboardArrowLeft,
                                            contentDescription = "Previous Chapter",
                                            tint = readerTextColor,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Text(
                                            text = "Previous",
                                            color = readerTextColor,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Medium,
                                            fontFamily = currentFontFamily
                                        )
                                    }
                                }

                                // 50/50 Vertical Divider line
                                VerticalDivider(
                                    color = readerTextColor.copy(alpha = 0.15f),
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .width(1.dp)
                                 )

                                // Next Button
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .clickable(enabled = (activeChapterIndex < chapters.size - 1) && !listState.isScrollInProgress) {
                                            onChapterSelect(activeChapterIndex + 1)
                                        }
                                        .alpha(if (activeChapterIndex < chapters.size - 1) 1.0f else 0.35f),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(
                                            text = "Next",
                                            color = readerTextColor,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Medium,
                                            fontFamily = currentFontFamily
                                        )
                                        Icon(
                                            imageVector = Icons.Default.KeyboardArrowRight,
                                            contentDescription = "Next Chapter",
                                            tint = readerTextColor,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(48.dp))
                        }
                    }
                }
            }
        }
    }

    activeFullscreenImageBitmap?.let { bitmap ->
        FullscreenImageViewer(
            bitmap = bitmap,
            onDismiss = { activeFullscreenImageBitmap = null }
        )
    }
}

@Composable
fun EpubImage(
    novelId: String,
    entryPath: String,
    modifier: Modifier = Modifier,
    onImageClick: (android.graphics.Bitmap) -> Unit
) {
    val context = LocalContext.current
    val widthPx = with(LocalDensity.current) {
        LocalConfiguration.current.screenWidthDp.dp.roundToPx()
    }
    val imageBitmapState = produceState<android.graphics.Bitmap?>(initialValue = null, novelId, entryPath, widthPx) {
        value = withContext(Dispatchers.IO) {
            EpubExtractor.extractImageBitmap(context, novelId, entryPath, widthPx)
        }
    }

    val bitmap = imageBitmapState.value
    Box(
        modifier = modifier
            .fillMaxWidth()
            .wrapContentHeight()
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Epub image",
                contentScale = ContentScale.Fit,
                filterQuality = androidx.compose.ui.graphics.FilterQuality.High,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onImageClick(bitmap) }
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(Color.Gray.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
fun FullscreenImageViewer(
    bitmap: android.graphics.Bitmap,
    onDismiss: () -> Unit
) {
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    val state = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(1f, 5f)
        offset += offsetChange
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Fullscreen Image",
                contentScale = ContentScale.Fit,
                filterQuality = androidx.compose.ui.graphics.FilterQuality.High,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    )
                    .transformable(state = state)
            )

            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(24.dp)
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close",
                    tint = Color.White
                )
            }
        }
    }
}


private class LayoutCoordsHolder { var value: androidx.compose.ui.layout.LayoutCoordinates? = null }
private class TextLayoutHolder { var value: androidx.compose.ui.text.TextLayoutResult? = null }

@Composable
fun SentenceRow(
    index: Int,
    sentence: String,
    isActiveSentence: Boolean,
    readerMode: String,
    textColor: Color,
    readerHighlightColor: Color,
    readerTextColor: Color,
    currentFontFamily: FontFamily?,
    isCaveat: Boolean,
    alignStyle: TextAlign,
    textAlignment: String,
    fontSize: Float,
    lineSpacing: Float,
    paragraphSpacing: Float,
    selRange: WordRange?,
    selectionVersion: Int,
    sentenceTokens: List<Token>,
    wordPositions: SnapshotStateMap<Int, WordPosition>,
    highlights: List<Highlight> = emptyList(),
    onSentenceClick: () -> Unit,
    onSentenceLongClick: () -> Unit,
    onWordSelected: (WordRange, Boolean) -> Unit,
    onPositioned: (Int, Offset, Offset) -> Unit
) {
    val paragraphWordIndices = remember(sentenceTokens) {
        val wordTokens = sentenceTokens.filter { it.isWord && it.wordIdx >= 0 }
        if (wordTokens.isEmpty()) null else wordTokens.first().wordIdx..wordTokens.last().wordIdx
    }
    val hasOverlap = remember(selRange, paragraphWordIndices) {
        if (selRange == null || paragraphWordIndices == null) false else {
            val selMin = minOf(selRange.start, selRange.end)
            val selMax = maxOf(selRange.start, selRange.end)
            paragraphWordIndices.start <= selMax && paragraphWordIndices.endInclusive >= selMin
        }
    }

    val rowCoordsHolder = remember { LayoutCoordsHolder() }
    var dragStartRootOffset by remember(selectionVersion) { mutableStateOf(Offset.Zero) }
    var dragStartWordIdx by remember(selectionVersion) { mutableStateOf(-1) }
    var lastClosestIdx by remember(selectionVersion) { mutableStateOf(-1) }
    val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
    val currentSelRange by rememberUpdatedState(selRange)
    val textLayoutHolder = remember { TextLayoutHolder() }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .onGloballyPositioned { coords ->
                rowCoordsHolder.value = coords
            }
            .pointerInput(sentence, selectionVersion) {
                detectTapGestures(onTap = { onSentenceClick() })
            }
            .pointerInput(sentence, selectionVersion) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { offset ->
                        onSentenceLongClick()
                        val rootOffset = rowCoordsHolder.value?.localToRoot(offset) ?: Offset.Zero
                        dragStartRootOffset = rootOffset
                        
                        var closestIdx = -1
                        val layoutResult = textLayoutHolder.value
                        if (layoutResult != null && !hasOverlap) {
                            val density = this
                            val padX = with(density) { 12.dp.toPx() }
                            val padY = with(density) { (paragraphSpacing / 4).dp.toPx() }
                            val adjustedOffset = Offset(offset.x - padX, offset.y - padY)
                            
                            val boundedX = adjustedOffset.x.coerceIn(0f, layoutResult.size.width.toFloat())
                            val boundedY = adjustedOffset.y.coerceIn(0f, layoutResult.size.height.toFloat())
                            
                            val charIdxRaw = layoutResult.getOffsetForPosition(Offset(boundedX, boundedY))
                            val charIdx = if (sentence.isNotEmpty()) charIdxRaw.coerceIn(0, sentence.length - 1) else charIdxRaw
                            if (charIdx in 0..sentence.length) {
                                var currOffset = 0
                                var bestTokenIdx = -1
                                for (tIdx in sentenceTokens.indices) {
                                    val tok = sentenceTokens[tIdx]
                                    val nextOffset = currOffset + tok.raw.length
                                    if (charIdx >= currOffset && charIdx < nextOffset) {
                                        bestTokenIdx = tIdx
                                        break
                                    }
                                    currOffset = nextOffset
                                }
                                
                                if (bestTokenIdx != -1) {
                                    var foundIdx = -1
                                    if (sentenceTokens[bestTokenIdx].isWord && sentenceTokens[bestTokenIdx].wordIdx >= 0) {
                                        foundIdx = sentenceTokens[bestTokenIdx].wordIdx
                                    } else {
                                        var distance = 1
                                        while (true) {
                                            val left = bestTokenIdx - distance
                                            val right = bestTokenIdx + distance
                                            if (left < 0 && right >= sentenceTokens.size) break
                                            
                                            if (right < sentenceTokens.size && sentenceTokens[right].isWord && sentenceTokens[right].wordIdx >= 0) {
                                                foundIdx = sentenceTokens[right].wordIdx
                                                break
                                            }
                                            if (left >= 0 && sentenceTokens[left].isWord && sentenceTokens[left].wordIdx >= 0) {
                                                foundIdx = sentenceTokens[left].wordIdx
                                                break
                                            }
                                            distance++
                                        }
                                    }
                                    if (foundIdx != -1) {
                                        closestIdx = foundIdx
                                    }
                                }
                            }
                        }
                        
                        if (closestIdx == -1) {
                            var minDistance = Float.MAX_VALUE
                            for ((idx, wPos) in wordPositions) {
                                val wordCenter = Offset(
                                    (wPos.leftAnchor.x + wPos.rightAnchor.x) / 2f,
                                    (wPos.leftAnchor.y + wPos.rightAnchor.y) / 2f
                                )
                                val distX = dragStartRootOffset.x - wordCenter.x
                                val distY = dragStartRootOffset.y - wordCenter.y
                                val dist = distX * distX + distY * distY
                                if (dist < minDistance) {
                                    minDistance = dist
                                    closestIdx = idx
                                }
                            }
                        }

                        if (closestIdx != -1) {
                            dragStartWordIdx = closestIdx
                            lastClosestIdx = closestIdx
                            onWordSelected(WordRange(closestIdx, closestIdx), true)
                        } else {
                            val wordTokens = sentenceTokens.filter { it.isWord && it.wordIdx >= 0 }
                            if (wordTokens.isNotEmpty()) {
                                val firstWordIdx = wordTokens.first().wordIdx
                                dragStartWordIdx = firstWordIdx
                                lastClosestIdx = firstWordIdx
                                onWordSelected(WordRange(firstWordIdx, firstWordIdx), true)
                            }
                        }
                        try {
                            haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                        } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError("ReaderContent.Haptic", e) }
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        dragStartRootOffset += dragAmount
                        
                        var closestIdx = -1
                        var minDistance = Float.MAX_VALUE
                        for ((idx, wPos) in wordPositions) {
                            val wordCenter = Offset(
                                (wPos.leftAnchor.x + wPos.rightAnchor.x) / 2f,
                                (wPos.leftAnchor.y + wPos.rightAnchor.y) / 2f
                            )
                            val distX = dragStartRootOffset.x - wordCenter.x
                            val distY = dragStartRootOffset.y - wordCenter.y
                            val dist = distX * distX + distY * distY
                            if (dist < minDistance) {
                                minDistance = dist
                                closestIdx = idx
                            }
                        }
                        if (closestIdx != -1 && dragStartWordIdx != -1) {
                            if (lastClosestIdx != closestIdx) {
                                lastClosestIdx = closestIdx
                                onWordSelected(WordRange(dragStartWordIdx, closestIdx), true)
                                try {
                                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                                } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError("ReaderContent.Haptic", e) }
                            }
                        }
                    },
                    onDragEnd = {
                        if (currentSelRange != null && dragStartWordIdx != -1 && lastClosestIdx != -1) {
                            onWordSelected(WordRange(dragStartWordIdx, lastClosestIdx), false)
                        }
                    },
                    onDragCancel = {
                        if (currentSelRange != null && dragStartWordIdx != -1 && lastClosestIdx != -1) {
                            onWordSelected(WordRange(dragStartWordIdx, lastClosestIdx), false)
                        }
                    }
                )
            }
            .padding(horizontal = 12.dp, vertical = (paragraphSpacing / 4).dp)
    ) {
        if (!hasOverlap) {
            val annotatedText = remember(sentence, sentenceTokens, highlights) {
                if (highlights.isEmpty() || sentenceTokens.isEmpty()) {
                    androidx.compose.ui.text.AnnotatedString(sentence)
                } else {
                    androidx.compose.ui.text.buildAnnotatedString {
                        append(sentence)
                        var currentOffset = 0
                        for (token in sentenceTokens) {
                            val tokenLen = token.raw.length
                            if (token.isWord && token.wordIdx >= 0) {
                                val matchingHighlight = highlights.firstOrNull { h ->
                                    val hMin = minOf(h.startWordIdx, h.endWordIdx)
                                    val hMax = maxOf(h.startWordIdx, h.endWordIdx)
                                    token.wordIdx in hMin..hMax
                                }
                                if (matchingHighlight != null) {
                                    try {
                                        val parsedColor = Color(android.graphics.Color.parseColor(matchingHighlight.colorHex))
                                        addStyle(
                                            style = androidx.compose.ui.text.SpanStyle(
                                                background = parsedColor.copy(alpha = 0.45f)
                                            ),
                                            start = currentOffset,
                                            end = (currentOffset + tokenLen).coerceAtMost(sentence.length)
                                        )
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }
                                }
                            }
                            currentOffset += tokenLen
                        }
                    }
                }
            }
            Text(
                text = annotatedText,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontSize = fontSize.sp,
                    lineHeight = (fontSize * lineSpacing).sp,
                    fontWeight = if (isActiveSentence) FontWeight.Bold else FontWeight.Normal,
                    fontFamily = currentFontFamily,
                    fontStyle = if (isCaveat) FontStyle.Italic else FontStyle.Normal,
                    textAlign = alignStyle
                ),
                color = textColor,
                onTextLayout = { textLayoutHolder.value = it },
                modifier = Modifier.fillMaxWidth()
            )
        } else {
            val flowAlign = when (textAlignment) {
                "Center" -> Arrangement.Center
                "Right" -> Arrangement.End
                else -> Arrangement.Start
            }
            
            @OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
            FlowRow(
                horizontalArrangement = flowAlign,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = (paragraphSpacing / 4).dp)
            ) {
                sentenceTokens.forEach { token ->
                    if (token.raw.isNotEmpty()) {
                        if (token.isWord && token.wordIdx >= 0) {
                            DisposableEffect(token.wordIdx) {
                                onDispose {
                                    wordPositions.remove(token.wordIdx)
                                }
                            }
                            
                            val range = selRange
                            val isSelected = if (range != null) {
                                token.wordIdx in minOf(range.start, range.end)..maxOf(range.start, range.end)
                            } else {
                                false
                            }
                            
                            val matchingHighlight = if (token.isWord && token.wordIdx >= 0) {
                                highlights.firstOrNull { h ->
                                    val hMin = minOf(h.startWordIdx, h.endWordIdx)
                                    val hMax = maxOf(h.startWordIdx, h.endWordIdx)
                                    token.wordIdx in hMin..hMax
                                }
                            } else null
                            val persistentHighlightColor = matchingHighlight?.let {
                                try { Color(android.graphics.Color.parseColor(it.colorHex)) } catch (_: Exception) { null }
                            }

                            WordSpanView(
                                token = token,
                                isSelected = isSelected,
                                highlightColor = readerHighlightColor,
                                textColor = textColor,
                                fontSize = fontSize,
                                currentFontFamily = currentFontFamily,
                                isCaveat = isCaveat,
                                selectionVersion = selectionVersion,
                                selRange = selRange,
                                onPositioned = { left, right ->
                                    onPositioned(token.wordIdx, left, right)
                                },
                                onWordSelected = onWordSelected,
                                wordPositions = wordPositions,
                                persistentHighlightColor = persistentHighlightColor
                            )
                        } else {
                            Text(
                                text = token.raw,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontSize = fontSize.sp,
                                    lineHeight = (fontSize * lineSpacing).sp,
                                    fontWeight = if (isActiveSentence) FontWeight.Bold else FontWeight.Normal,
                                    fontFamily = currentFontFamily,
                                    fontStyle = if (isCaveat) FontStyle.Italic else FontStyle.Normal
                                ),
                                color = textColor
                            )
                        }
                    }
                }
            }
        }
    }
}


