package com.lorelight.ui.library

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import com.lorelight.ui.components.LorelightDialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lorelight.data.model.Novel
import com.lorelight.ui.components.NovelCoverImage
import com.lorelight.ui.theme.getThemedButtonProps

@Composable
fun BookEditDetailsDialog(
    showDialog: Boolean,
    targetNovel: Novel?,
    importedNovels: List<Novel>,
    currentNovel: Novel?,
    editedTitle: String,
    onEditedTitleChange: (String) -> Unit,
    editedCoverBase64: String?,
    onCoverPickerLaunch: () -> Unit,
    onImportedNovelsChange: (List<Novel>) -> Unit,
    onCurrentNovelChange: (Novel?) -> Unit,
    onDismissRequest: () -> Unit,
    onSuccess: () -> Unit
) {
    if (showDialog && targetNovel != null) {
        val context = androidx.compose.ui.platform.LocalContext.current
        LorelightDialog(
            onDismissRequest = onDismissRequest,
            title = {
                Text(
                    text = "Edit Novel Details",
                    fontWeight = FontWeight.Bold,
                    fontFamily = MaterialTheme.typography.headlineLarge.fontFamily,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "Customize the title and cover image of this novel.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    
                    OutlinedTextField(
                        value = editedTitle,
                        onValueChange = onEditedTitleChange,
                        label = { Text("Novel Title") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedTextColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                            focusedLabelColor = MaterialTheme.colorScheme.primary,
                            unfocusedLabelColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Cover Image",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.align(Alignment.Start)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        Box(
                            modifier = Modifier
                                .size(96.dp, 136.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surface)
                                .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .clickable { onCoverPickerLaunch() },
                            contentAlignment = Alignment.Center
                        ) {
                            NovelCoverImage(
                                coverBase64 = editedCoverBase64,
                                title = editedTitle,
                                modifier = Modifier.fillMaxSize()
                            )
                            
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.4f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Filled.Edit,
                                        contentDescription = "Change Cover",
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Tap to Change",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = {
                            com.lorelight.data.local.NovelRemovalManager.removeNovelFromLibrary(context, targetNovel)
                            val remainingNovels = importedNovels.filter { it.title != targetNovel.title }
                            onImportedNovelsChange(remainingNovels)
                            if (currentNovel?.title == targetNovel.title) {
                                onCurrentNovelChange(remainingNovels.firstOrNull())
                            }
                            onSuccess()
                        }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Delete,
                                contentDescription = "Delete",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(16.dp)
                            )
                            Text("Delete", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TextButton(onClick = onDismissRequest) {
                            Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Button(
                            onClick = {
                                if (editedTitle.isNotBlank()) {
                                    val updatedNovels = importedNovels.map {
                                        if (it.title == targetNovel.title) {
                                            it.copy(title = editedTitle, coverImageBase64 = editedCoverBase64)
                                        } else {
                                            it
                                        }
                                    }
                                    onImportedNovelsChange(updatedNovels)
                                    if (currentNovel?.title == targetNovel.title) {
                                        onCurrentNovelChange(updatedNovels.find { it.title == editedTitle })
                                    }
                                    onSuccess()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (getThemedButtonProps(MaterialTheme.colorScheme.primary).first) Color.Transparent else MaterialTheme.colorScheme.primary,
                                contentColor = getThemedButtonProps(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.background).third
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.then(
                                if (getThemedButtonProps(MaterialTheme.colorScheme.primary).first) {
                                    Modifier.background(getThemedButtonProps(MaterialTheme.colorScheme.primary).second, RoundedCornerShape(10.dp))
                                } else {
                                    Modifier
                                }
                            )
                        ) {
                            Text("Save", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(18.dp)
        )
    }
}
