package com.lorelight.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.animation.animateColorAsState

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush

// Forest Green Theme
val ForestPrimary = Color(0xFF75974D)
val ForestPrimaryLight = Color(0xFF566B21)

val ForestDarkScheme = darkColorScheme(
    primary = ForestPrimary,
    onPrimary = Color(0xFF0D1A11),
    primaryContainer = Color(0xFF1B3224),
    onPrimaryContainer = ForestPrimary,
    secondary = Color(0xFF6DA17F),
    onSecondary = Color(0xFF0B190E),
    secondaryContainer = Color(0xFF142918),
    onSecondaryContainer = Color(0xFF6DA17F),
    background = Color(0xFF050907),
    onBackground = Color(0xFFDEEBE2),
    surface = Color(0xFF0A1410),
    onSurface = Color(0xFFDEEBE2),
    surfaceVariant = Color(0xFF111E17),
    onSurfaceVariant = Color(0xFFACC2B6),
    outline = Color(0xFF233A2D)
)

val ForestLightScheme = lightColorScheme(
    primary = ForestPrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFDCE3C0),
    onPrimaryContainer = Color(0xFF293A00),
    secondary = Color(0xFF6E7654),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFE9EDD9),
    onSecondaryContainer = Color(0xFF394124),
    background = Color(0xFFF7F8F4),
    onBackground = Color(0xFF292E1B),
    surface = Color(0xFFFCFCFA),
    onSurface = Color(0xFF292E1B),
    surfaceVariant = Color(0xFFEBEEE2),
    onSurfaceVariant = Color(0xFF5E634F),
    outline = Color(0xFFB5B7AA),
    outlineVariant = Color(0xFFDFE0D8)
)

// Black Gold Theme
val BlackGoldPrimary = Color(0xFFFFD580)
val BlackGoldPrimaryLight = Color(0xFF7E5D2F)

val BlackGoldDarkScheme = darkColorScheme(
    primary = BlackGoldPrimary,
    onPrimary = Color(0xFF2E1A00),
    primaryContainer = Color(0xFF4D2F02),
    onPrimaryContainer = Color(0xFFFFECC4),
    secondary = Color(0xFFE1B970),
    onSecondary = Color(0xFF2A1C00),
    secondaryContainer = Color(0xFF4A3410),
    onSecondaryContainer = Color(0xFFE1B970),
    background = Color(0xFF0E0B08),
    onBackground = Color(0xFFFFF8EE),
    surface = Color(0xFF191410),
    onSurface = Color(0xFFFFF8EE),
    surfaceVariant = Color(0xFF261E18),
    onSurfaceVariant = Color(0xFFDFCCA8),
    outline = Color(0xFF423321)
)

val BlackGoldLightScheme = lightColorScheme(
    primary = BlackGoldPrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFF1DCC5),
    onPrimaryContainer = Color(0xFF48300B),
    secondary = Color(0xFF816F59),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFF5E9DC),
    onSecondaryContainer = Color(0xFF4A3B29),
    background = Color(0xFFFAF7F4),
    onBackground = Color(0xFF352A1E),
    surface = Color(0xFFFEFCFA),
    onSurface = Color(0xFF352A1E),
    surfaceVariant = Color(0xFFF2EBE4),
    onSurfaceVariant = Color(0xFF6B5F52),
    outline = Color(0xFFBDB5AC),
    outlineVariant = Color(0xFFE4DFD9)
)

// Satin Pink Theme
val PinkPrimary = Color(0xFFFFB0D0)
val PinkPrimaryLight = Color(0xFF944F4B)

val SatinPinkDarkScheme = darkColorScheme(
    primary = PinkPrimary,
    onPrimary = Color(0xFF4A102D),
    primaryContainer = Color(0xFF6D1B43),
    onPrimaryContainer = Color(0xFFFFD0E0),
    secondary = Color(0xFFFF8DA1),
    onSecondary = Color(0xFF4E0827),
    secondaryContainer = Color(0xFF6F1739),
    onSecondaryContainer = Color(0xFFFFD0E0),
    background = Color(0xFF0F080B),
    onBackground = Color(0xFFFFF0F5),
    surface = Color(0xFF1A0E13),
    onSurface = Color(0xFFFFF0F5),
    surfaceVariant = Color(0xFF29151E),
    onSurfaceVariant = Color(0xFFE5BCCB),
    outline = Color(0xFF4F263C)
)

val SatinPinkLightScheme = lightColorScheme(
    primary = PinkPrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFDD7D3),
    onPrimaryContainer = Color(0xFF592522),
    secondary = Color(0xFF8C6A66),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFCE6E4),
    onSecondaryContainer = Color(0xFF533634),
    background = Color(0xFFFCF7F6),
    onBackground = Color(0xFF3B2725),
    surface = Color(0xFFFEFCFB),
    onSurface = Color(0xFF3B2725),
    surfaceVariant = Color(0xFFF6EAE8),
    onSurfaceVariant = Color(0xFF715C5A),
    outline = Color(0xFFC1B3B1),
    outlineVariant = Color(0xFFE7DEDD)
)

// Black (Midnight/OLED) Theme
val BlackNewPrimary = Color(0xFFFFFFFF)
val BlackNewPrimaryLight = Color(0xFF755F51)

// TRUE AMOLED. Only `background` used to be #000000; every surface the UI
// actually paints -- cards, glass panels, bars, chips -- came from `surface`
// (#0C0C0C), `surfaceVariant` (#1A1A1A), `primaryContainer` (#2D2D2D) and
// `secondaryContainer` (#1F1F1F). GlassPanel compounds it, because in dark
// mode its container is `surface.copy(alpha = tintAlpha)`. So the panel the
// user looks at was grey even though the wallpaper behind it was black, and
// an OLED panel never got to switch its pixels off.
//
// Fills are now pure black. Separation comes from `outline`, which is a
// 1px stroke rather than a filled region, so it costs no lit pixels worth
// mentioning while keeping cards distinguishable.
val BlackDarkScheme = darkColorScheme(
    primary = BlackNewPrimary,
    onPrimary = Color(0xFF000000),
    primaryContainer = Color(0xFF000000),
    onPrimaryContainer = BlackNewPrimary,
    secondary = Color(0xFFCCCCCC),
    onSecondary = Color(0xFF000000),
    secondaryContainer = Color(0xFF000000),
    onSecondaryContainer = Color(0xFFD4D4D4),
    background = Color(0xFF000000),
    onBackground = Color(0xFFF3F4F6),
    surface = Color(0xFF000000),
    onSurface = Color(0xFFF3F4F6),
    surfaceVariant = Color(0xFF000000),
    onSurfaceVariant = Color(0xFF9CA3AF),
    outline = Color(0xFF3A3A3A),
    outlineVariant = Color(0xFF242424),
    surfaceContainer = Color(0xFF000000),
    surfaceContainerHigh = Color(0xFF000000),
    surfaceContainerHighest = Color(0xFF050505),
    surfaceContainerLow = Color(0xFF000000),
    surfaceContainerLowest = Color(0xFF000000),
    surfaceBright = Color(0xFF0A0A0A),
    surfaceDim = Color(0xFF000000),
    inverseSurface = Color(0xFFE5E5E5),
    inverseOnSurface = Color(0xFF000000),
    scrim = Color(0xFF000000),
    // The single biggest reason this theme looked grey. Material 3 tints any
    // surface that has tonal elevation with `surfaceTint`, which DEFAULTS TO
    // `primary`. Here primary is pure white, so every elevated Card, Surface,
    // menu, sheet and bar had a white veil blended over it -- the higher the
    // elevation, the greyer it got. Pinning it to black disables the overlay.
    surfaceTint = Color(0xFF000000)
)

val BlackLightScheme = lightColorScheme(
    primary = BlackNewPrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFEADDD6),
    onPrimaryContainer = Color(0xFF423127),
    secondary = Color(0xFF7B7069),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFF1EAE6),
    onSecondaryContainer = Color(0xFF453C36),
    background = Color(0xFFF9F7F7),
    onSurface = Color(0xFF312B27),
    surface = Color(0xFFFDFCFB),
    onBackground = Color(0xFF312B27),
    surfaceVariant = Color(0xFFF0ECE9),
    onSurfaceVariant = Color(0xFF665F5B),
    outline = Color(0xFFBAB5B3),
    outlineVariant = Color(0xFFE2DFDD)
)

// Ocean Blue Theme
val OceanPrimary = Color(0xFF81C7F4)
val OceanPrimaryLight = Color(0xFF0067AD)

val OceanBlueDarkScheme = darkColorScheme(
    primary = OceanPrimary,
    onPrimary = Color(0xFF003354),
    primaryContainer = Color(0xFF004D7C),
    onPrimaryContainer = Color(0xFFCDE5FF),
    secondary = Color(0xFF5C93E2),
    onSecondary = Color(0xFF00224D),
    secondaryContainer = Color(0xFF003D80),
    onSecondaryContainer = Color(0xFFCDE5FF),
    background = Color(0xFF060B12),
    onBackground = Color(0xFFECF5FF),
    surface = Color(0xFF0E1624),
    onSurface = Color(0xFFECF5FF),
    surfaceVariant = Color(0xFF162338),
    onSurfaceVariant = Color(0xFFA9CBEA),
    outline = Color(0xFF203A58)
)

val OceanBlueLightScheme = lightColorScheme(
    primary = OceanPrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFCEE1FF),
    onPrimaryContainer = Color(0xFF003766),
    secondary = Color(0xFF5B7395),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFE0ECFF),
    onSecondaryContainer = Color(0xFF273F5B),
    background = Color(0xFFF5F8FD),
    onBackground = Color(0xFF1E2D40),
    surface = Color(0xFFFBFCFF),
    onSurface = Color(0xFF1E2D40),
    surfaceVariant = Color(0xFFE7EDF8),
    onSurfaceVariant = Color(0xFF546276),
    outline = Color(0xFFAFB6C4),
    outlineVariant = Color(0xFFDBE0E8)
)

// Cyan Theme
val CyanPrimary = Color(0xFF54D6E4)
val CyanPrimaryLight = Color(0xFF006C89)

val CyanDarkScheme = darkColorScheme(
    primary = CyanPrimary,
    onPrimary = Color(0xFF00353B),
    primaryContainer = Color(0xFF004D54),
    onPrimaryContainer = CyanPrimary,
    secondary = Color(0xFF3BBFA5),
    onSecondary = Color(0xFF003729),
    secondaryContainer = Color(0xFF004F3D),
    onSecondaryContainer = Color(0xFF4DBC9E),
    background = Color(0xFF040A0F),
    onBackground = Color(0xFFE2FAF9),
    surface = Color(0xFF0A141C),
    onSurface = Color(0xFFE2FAF9),
    surfaceVariant = Color(0xFF12202B),
    onSurfaceVariant = Color(0xFFA2CCD4),
    outline = Color(0xFF1C3A44)
)

val CyanLightScheme = lightColorScheme(
    primary = CyanPrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFC6E4F3),
    onPrimaryContainer = Color(0xFF003A4D),
    secondary = Color(0xFF577784),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFDDEEF6),
    onSecondaryContainer = Color(0xFF25414D),
    background = Color(0xFFF5F8FA),
    onBackground = Color(0xFF1C2F36),
    surface = Color(0xFFFAFCFE),
    onSurface = Color(0xFF1C2F36),
    surfaceVariant = Color(0xFFE5EEF2),
    onSurfaceVariant = Color(0xFF51636C),
    outline = Color(0xFFADB8BD),
    outlineVariant = Color(0xFFDAE1E4)
)

// Purple Theme
val PurplePrimary = Color(0xFFD59DFB)
val PurplePrimaryLight = Color(0xFF7E5489)

val PurpleDarkScheme = darkColorScheme(
    primary = PurplePrimary,
    onPrimary = Color(0xFF380044),
    primaryContainer = Color(0xFF530063),
    onPrimaryContainer = PurplePrimary,
    secondary = Color(0xFFB388FF),
    onSecondary = Color(0xFF22004D),
    secondaryContainer = Color(0xFF3D0080),
    onSecondaryContainer = Color(0xFFB693FE),
    background = Color(0xFF080510),
    onBackground = Color(0xFFFAF4FF),
    surface = Color(0xFF110B22),
    onSurface = Color(0xFFFAF4FF),
    surfaceVariant = Color(0xFF1C1236),
    onSurfaceVariant = Color(0xFFDAC6F2),
    outline = Color(0xFF2E1C4B)
)

val PurpleLightScheme = lightColorScheme(
    primary = PurplePrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFEFD9F3),
    onPrimaryContainer = Color(0xFF482851),
    secondary = Color(0xFF806B84),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFF4E7F6),
    onSecondaryContainer = Color(0xFF49384D),
    background = Color(0xFFFAF7FA),
    onBackground = Color(0xFF342836),
    surface = Color(0xFFFDFCFE),
    onSurface = Color(0xFF342836),
    surfaceVariant = Color(0xFFF1EAF2),
    onSurfaceVariant = Color(0xFF695D6C),
    outline = Color(0xFFBBB3BD),
    outlineVariant = Color(0xFFE3DEE4)
)

// Creme White Theme
val WhitePrimary = Color(0xFF61411D)
val CremeWhiteDarkPrimary = Color(0xFFECE3D5)

val CremeWhiteDarkScheme = darkColorScheme(
    primary = CremeWhiteDarkPrimary,
    onPrimary = Color(0xFF261D12),
    primaryContainer = Color(0xFF3E3324),
    onPrimaryContainer = CremeWhiteDarkPrimary,
    secondary = Color(0xFFC7B7A3),
    onSecondary = Color(0xFF241B10),
    secondaryContainer = Color(0xFF362C1E),
    onSecondaryContainer = Color(0xFFC7B7A3),
    background = Color(0xFF13110E),
    onBackground = Color(0xFFFAF6EE),
    surface = Color(0xFF1C1915),
    onSurface = Color(0xFFFAF6EE),
    surfaceVariant = Color(0xFF2B251F),
    onSurfaceVariant = Color(0xFFC7B7A3),
    outline = Color(0xFF3F372F)
)

val CremeWhiteLightScheme = lightColorScheme(
    primary = WhitePrimary,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFEFE6D8),
    onPrimaryContainer = Color(0xFF291907),
    secondary = Color(0xFF6E5132),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFF5EFE5),
    onSecondaryContainer = Color(0xFF2B1C0B),
    background = Color(0xFFF8F4EC),
    onBackground = Color(0xFF241B12),
    surface = Color(0xFFFEFDFB),
    onSurface = Color(0xFF241B12),
    surfaceVariant = Color(0xFFEDE3D3),
    onSurfaceVariant = Color(0xFF594B3C),
    outline = Color(0xFFDACFBD),
    outlineVariant = Color(0xFFE9E0D2)
)

// Blood Red Theme
val BloodPrimary = Color(0xFFFA5F70)
val BloodPrimaryLight = Color(0xFFAC3E38)

val BloodRedDarkScheme = darkColorScheme(
    primary = BloodPrimary,
    onPrimary = Color(0xFF5F0013),
    primaryContainer = Color(0xFF84001B),
    onPrimaryContainer = Color(0xFFFFD9DC),
    secondary = Color(0xFFFA4F61),
    onSecondary = Color(0xFF54000C),
    secondaryContainer = Color(0xFF7A0014),
    onSecondaryContainer = Color(0xFFFA4F61),
    background = Color(0xFF0C0304),
    onBackground = Color(0xFFFFF0F1),
    surface = Color(0xFF1A080A),
    onSurface = Color(0xFFFFF0F1),
    surfaceVariant = Color(0xFF2A0F11),
    onSurfaceVariant = Color(0xFFE6A6AB),
    outline = Color(0xFF4A1A1D)
)

val BloodRedLightScheme = lightColorScheme(
    primary = BloodPrimaryLight,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFFFD6CF),
    onPrimaryContainer = Color(0xFF691214),
    secondary = Color(0xFF9B645D),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFFFE4E0),
    onSecondaryContainer = Color(0xFF5E312C),
    background = Color(0xFFFEF6F5),
    onBackground = Color(0xFF422420),
    surface = Color(0xFFFFFBFA),
    onSurface = Color(0xFF422420),
    surfaceVariant = Color(0xFFFCE8E5),
    onSurfaceVariant = Color(0xFF7A5954),
    outline = Color(0xFFC8B1AE),
    outlineVariant = Color(0xFFEBDCDA)
)

// Gradients
val RefinedCyanGradient = Brush.linearGradient(colors = listOf(Color(0xFF4DB6AC), Color(0xFF62D2DF), Color(0xFFB2DFDB)))
val CyanOnGradient = Color(0xFF00353A)

val RefinedPurpleGradient = Brush.linearGradient(colors = listOf(Color(0xFF9575CD), Color(0xFFD59DFB), Color(0xFFEDE7F6)))
val PurpleOnGradient = Color(0xFF380041)

val RefinedWhiteGradient = Brush.linearGradient(colors = listOf(Color(0xFFE8E4DC), Color(0xFFFAF7F2), Color(0xFFFFFFFF)))
val WhiteOnGradient = Color(0xFF262626)

val RefinedBloodGradient = Brush.linearGradient(colors = listOf(Color(0xFF98001C), Color(0xFFFA5F70), Color(0xFFFFB3BC)))
val BloodOnGradient = Color(0xFF3F000A)

val RefinedGoldGradient = Brush.linearGradient(colors = listOf(Color(0xFFC59832), Color(0xFFE5B942), Color(0xFFF5D68F)))
val GoldOnGradient = Color(0xFF1E1405)

val RefinedPinkGradient = Brush.linearGradient(colors = listOf(Color(0xFFDC829F), Color(0xFFEFA5C0), Color(0xFFFFCBDC)))
val PinkOnGradient = Color(0xFF3B0B24)

val RefinedMidnightGradient = Brush.linearGradient(colors = listOf(Color(0xFFBCBCC0), Color(0xFFD8D8DC), Color(0xFFF2F2F7)))
val MidnightOnGradient = Color(0xFF000000)

val RefinedOceanGradient = Brush.linearGradient(colors = listOf(Color(0xFF4DA6FF), Color(0xFF7AD3FF), Color(0xFFA1ECFF)))
val OceanOnGradient = Color(0xFF001F3F)

val RefinedForestGradient = Brush.linearGradient(colors = listOf(Color(0xFF5B7A3E), Color(0xFF75974D), Color(0xFF9EBA7B)))
val ForestOnGradient = Color(0xFF0C1B0E)

// Backwards compatibility declarations
val SophisticatedDarkScheme = ForestDarkScheme
val BlackGoldScheme = BlackGoldDarkScheme
val SatinPinkScheme = SatinPinkDarkScheme
val MidnightBlackScheme = BlackDarkScheme
val BlackNewScheme = BlackDarkScheme
val OceanBlueScheme = OceanBlueDarkScheme
val CyanScheme = CyanDarkScheme
val PurpleScheme = PurpleDarkScheme
val WhiteScheme = CremeWhiteLightScheme
val BloodRedScheme = BloodRedDarkScheme

val ForestBackground = Color(0xFF050907)
val ForestSurface = Color(0xFF0A1410)
val ForestSurfaceVariant = Color(0xFF111E17)
val ForestBorder = Color(0xFF233A2D)

val BlackGoldBackground = Color(0xFF0E0B08)
val BlackGoldSurface = Color(0xFF191410)
val BlackGoldSurfaceVariant = Color(0xFF261E18)
val BlackGoldBorder = Color(0xFF423321)

val PinkBackground = Color(0xFF0F080B)
val PinkSurface = Color(0xFF1A0E13)
val PinkSurfaceVariant = Color(0xFF29151E)
val PinkBorder = Color(0xFF4F263C)

val BlackNewBackground = Color(0xFF000000)
val BlackNewSurface = Color(0xFF0C0C0C)
val BlackNewSurfaceVariant = Color(0xFF1A1A1A)
val BlackNewBorder = Color(0xFF2E2E2E)

val MidnightBackground = BlackNewBackground
val MidnightSurface = BlackNewSurface
val MidnightSurfaceVariant = BlackNewSurfaceVariant
val MidnightPrimary = BlackNewPrimary
val MidnightOnBackground = Color(0xFFF3F4F6)
val MidnightOnSurfaceVariant = Color(0xFF9CA3AF)
val MidnightBorder = BlackNewBorder

val OceanBackground = Color(0xFF060B12)
val OceanSurface = Color(0xFF0E1624)
val OceanSurfaceVariant = Color(0xFF162338)
val OceanBorder = Color(0xFF203A58)

val CyanBackground = Color(0xFF040A0F)
val CyanSurface = Color(0xFF0A141C)
val CyanSurfaceVariant = Color(0xFF12202B)
val CyanBorder = Color(0xFF1C3A44)

val PurpleBackground = Color(0xFF080510)
val PurpleSurface = Color(0xFF110B22)
val PurpleSurfaceVariant = Color(0xFF1C1236)
val PurpleBorder = Color(0xFF2E1C4B)

val WhiteBackground = Color(0xFFFAF7F2)
val WhiteSurface = Color(0xFFF1EDE4)
val WhiteSurfaceVariant = Color(0xFFE6DEC9)
val WhiteOnBackground = Color(0xFF2F241A)
val WhiteOnSurfaceVariant = Color(0xFF5E4E3F)
val WhiteBorder = Color(0xFFD2C1A8)

val BloodBackground = Color(0xFF0C0304)
val BloodSurface = Color(0xFF1A080A)
val BloodSurfaceVariant = Color(0xFF2A0F11)
val BloodBorder = Color(0xFF4A1A1D)

@Composable
fun ColorScheme.animated(): ColorScheme {
    val spec = androidx.compose.animation.core.tween<Color>(durationMillis = 450)
    return copy(
        primary = animateColorAsState(primary, spec, label = "primary").value,
        onPrimary = animateColorAsState(onPrimary, spec, label = "onPrimary").value,
        secondary = animateColorAsState(secondary, spec, label = "secondary").value,
        background = animateColorAsState(background, spec, label = "background").value,
        onBackground = animateColorAsState(onBackground, spec, label = "onBackground").value,
        surface = animateColorAsState(surface, spec, label = "surface").value,
        onSurface = animateColorAsState(onSurface, spec, label = "onSurface").value,
        surfaceVariant = animateColorAsState(surfaceVariant, spec, label = "surfaceVariant").value,
        onSurfaceVariant = animateColorAsState(onSurfaceVariant, spec, label = "onSurfaceVariant").value
    )
}

fun getAppColorScheme(theme: String, isLightMode: Boolean): ColorScheme {
    return if (isLightMode) {
        when (theme) {
            "blackgold" -> BlackGoldLightScheme
            "Satin Pink" -> SatinPinkLightScheme
            "readerblacknew" -> BlackLightScheme
            "Ocean Blue" -> OceanBlueLightScheme
            "cyne" -> CyanLightScheme
            "readerpurple" -> PurpleLightScheme
            "readerblood" -> BloodRedLightScheme
            else -> ForestLightScheme
        }
    } else {
        when (theme) {
            "blackgold" -> BlackGoldDarkScheme
            "Satin Pink" -> SatinPinkDarkScheme
            "readerblacknew" -> BlackDarkScheme
            "Ocean Blue" -> OceanBlueDarkScheme
            "cyne" -> CyanDarkScheme
            "readerpurple" -> PurpleDarkScheme
            "readerblood" -> BloodRedDarkScheme
            else -> ForestDarkScheme
        }
    }
}

fun getThemedButtonProps(primary: Color, fallbackContent: Color = Color.Black): Triple<Boolean, Brush, Color> {
    val isPremium = primary == Color(0xFFF3C77D) || primary == Color(0xFFFFD580) ||
                    primary == Color(0xFFFFB0D0) || 
                    primary == Color(0xFFE5E5E5) ||
                    primary == Color(0xFF6ABFFF) ||
                    primary == ForestPrimary ||
                    primary == Color(0xFF00E5FF) ||
                    primary == Color(0xFFD500F9) ||
                    primary == Color(0xFF1A1A1A) ||
                    primary == Color(0xFFFF3333) ||
                    primary == BloodPrimary
    val gradient = when (primary) {
        Color(0xFFF3C77D), Color(0xFFFFD580) -> RefinedGoldGradient
        Color(0xFFFFB0D0) -> RefinedPinkGradient
        Color(0xFFE5E5E5) -> RefinedMidnightGradient
        Color(0xFF6ABFFF) -> RefinedOceanGradient
        ForestPrimary -> RefinedForestGradient
        Color(0xFF00E5FF) -> RefinedCyanGradient
        Color(0xFFD500F9) -> RefinedPurpleGradient
        Color(0xFF1A1A1A) -> RefinedWhiteGradient
        Color(0xFFFF3333), BloodPrimary -> RefinedBloodGradient
        else -> Brush.linearGradient(colors = listOf(primary, primary))
    }
    val contentColor = when (primary) {
        Color(0xFFF3C77D), Color(0xFFFFD580) -> GoldOnGradient
        Color(0xFFFFB0D0) -> PinkOnGradient
        Color(0xFFE5E5E5) -> MidnightOnGradient
        Color(0xFF6ABFFF) -> OceanOnGradient
        ForestPrimary -> ForestOnGradient
        Color(0xFF00E5FF) -> CyanOnGradient
        Color(0xFFD500F9) -> PurpleOnGradient
        Color(0xFF1A1A1A) -> WhiteOnGradient
        Color(0xFFFF3333), BloodPrimary -> BloodOnGradient
        else -> fallbackContent
    }
    return Triple(isPremium, gradient, contentColor)
}
