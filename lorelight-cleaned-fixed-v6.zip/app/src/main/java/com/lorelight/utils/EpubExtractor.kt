package com.lorelight.utils

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.net.Uri
import android.util.Base64
import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.nodes.Node
import org.jsoup.nodes.TextNode
import org.xmlpull.v1.XmlPullParser
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.zip.ZipFile
import kotlin.math.roundToInt
import com.lorelight.ui.reader.ReaderBlock

data class OpfItem(val id: String, val href: String, val mediaType: String, val properties: String)
data class SpineItem(val idref: String, val linear: String?)

data class OpfData(
    val title: String,
    val author: String,
    val language: String,
    val description: String,
    val series: String,
    val manifest: Map<String, OpfItem>,
    val spine: List<SpineItem>,
    val coverId: String?
)

class Volume(val index: Int, val title: String?, val chapters: List<Chapter>)
class Chapter(val id: String, val title: String, val content: List<ContentBlock>, val order: Int, val volume: Int)
sealed class ContentBlock {
    data class Text(val text: String) : ContentBlock()
    data class Image(val base64: String) : ContentBlock()
}
class SpineChapter(
    val index: Int,
    val filePath: String,
    val originalTitle: String,
    val headings: List<String>,
    val textContent: String,
    val htmlContent: String,
    val wordCount: Int,
    val charCount: Int,
    val detectedNum: Int?,
    var resolvedTitle: String = ""
)
class TocItem(val title: String, val href: String)

object EpubExtractor {

    private val imageCache = object : android.util.LruCache<String, android.graphics.Bitmap>(12 * 1024 * 1024) { // 12 MB
        override fun sizeOf(key: String, value: android.graphics.Bitmap): Int {
            return value.byteCount
        }
    }

    private const val MAX_EPUB_BYTES = 512L * 1024 * 1024

    /** Cheap header check: every EPUB is a ZIP, which always starts with "PK". */
    private fun looksLikeZip(file: java.io.File): Boolean = try {
        java.io.FileInputStream(file).use { input ->
            val header = ByteArray(4)
            val read = input.read(header)
            read >= 2 && header[0] == 0x50.toByte() && header[1] == 0x4B.toByte()
        }
    } catch (e: Throwable) {
        false
    }

    fun extract(context: Context, uri: Uri): JSONObject {
        val rootJson = JSONObject()
        // FIX A3: this used to be one fixed name in the cache directory, so two
        // imports running at once (the in-app picker and "Open with Lorelight")
        // wrote over each other's bytes and produced a corrupt or mixed-up book.
        val tempFile = java.io.File(
            context.cacheDir,
            "epub_import_${System.currentTimeMillis()}_${java.util.UUID.randomUUID()}.epub"
        )
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                tempFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: throw Exception("Failed to open input stream for URI: $uri")

            // FIX A3: fail with a clear, specific reason instead of letting
            // ZipFile throw a generic exception on anything that is not a book,
            // and refuse absurd sizes before parsing the whole archive.
            if (tempFile.length() == 0L) {
                throw Exception("The selected file is empty")
            }
            if (tempFile.length() > MAX_EPUB_BYTES) {
                throw Exception(
                    "EPUB is too large to import (${tempFile.length() / (1024 * 1024)} MB, limit ${MAX_EPUB_BYTES / (1024 * 1024)} MB)"
                )
            }
            if (!looksLikeZip(tempFile)) {
                throw Exception("The selected file is not a valid EPUB (bad archive header)")
            }
            
            ZipFile(tempFile).use { zipFile ->
                // 1. Detect all OPF files
                val opfEntries = zipFile.entries().asSequence()
                    .filter { !it.isDirectory && it.name.endsWith(".opf", ignoreCase = true) }
                    .toList()
                    
                // 2. Parse META-INF/container.xml to find the primary OPF path
                var primaryOpfPath = "OEBPS/content.opf"
                val containerEntry = findEntry(zipFile, "META-INF/container.xml")
                if (containerEntry != null) {
                    zipFile.getInputStream(containerEntry).use { input ->
                        primaryOpfPath = parseContainerXml(input)
                    }
                } else {
                    val firstOpf = opfEntries.firstOrNull()?.name
                    if (firstOpf != null) {
                        primaryOpfPath = firstOpf
                    }
                }
                
                val primaryOpfData = parseOpf(zipFile, primaryOpfPath)
                
                val metadataJson = JSONObject().apply {
                    put("title", primaryOpfData.title)
                    put("author", JSONArray().apply { put(primaryOpfData.author) })
                    put("language", primaryOpfData.language)
                    put("description", primaryOpfData.description)
                    put("series", primaryOpfData.series)
                }
                rootJson.put("metadata", metadataJson)
                
                val novelId = java.util.UUID.nameUUIDFromBytes(("${primaryOpfData.title}-${primaryOpfData.author}").toByteArray()).toString()
                rootJson.put("novelId", novelId)
                
                // Extract cover image
                val coverJson = JSONObject()
                var coverBase64: String? = null
                
                val coverId = primaryOpfData.coverId
                val coverHref = if (!coverId.isNullOrEmpty()) primaryOpfData.manifest[coverId]?.href else null
                if (coverHref != null) {
                    val coverEntry = findEntry(zipFile, coverHref)
                    if (coverEntry != null) {
                        val coverBytes = zipFile.getInputStream(coverEntry).use { it.readBytes() }
                        val compressed = scaleAndCompressToRawBytes(coverBytes)
                        if (compressed != null) {
                            val path = com.lorelight.data.local.CoverStorage.saveCoverBytes(context, novelId, compressed)
                            coverBase64 = path ?: Base64.encodeToString(compressed, Base64.NO_WRAP)
                        }
                    }
                }
                
                if (coverBase64 != null) {
                    coverJson.put("image_base64", coverBase64)
                    rootJson.put("cover", coverJson)
                } else {
                    rootJson.put("cover", JSONObject.NULL)
                }
                
                // 3. Determine if we should parse nested/compound OPFs (e.g. for Ocean book)
                val subOpfEntries = opfEntries.filter { !it.name.equals(primaryOpfPath, ignoreCase = true) }
                val useSubOpfs = if (subOpfEntries.isNotEmpty()) {
                    val hasSubdirs = subOpfEntries.any { it.name.contains("/") }
                    if (hasSubdirs) {
                        val numberedSubDirs = subOpfEntries.map { it.name.substringBefore("/") + "/" }.distinct()
                        val hasNumberedSubDirsMissing = numberedSubDirs.any { subDir ->
                            primaryOpfData.spine.none { 
                                it.idref.contains(subDir, ignoreCase = true) || 
                                (primaryOpfData.manifest[it.idref]?.href?.startsWith(subDir, ignoreCase = true) == true) 
                            }
                        }
                        hasNumberedSubDirsMissing
                    } else {
                        false
                    }
                } else {
                    false
                }
                
                val finalChaptersArray = JSONArray()
                
                if (useSubOpfs) {
                    // Enumerate sub-OPFs in NATURAL sort order
                    val sortedSubOpfs = subOpfEntries.sortedWith { o1, o2 ->
                        naturalCompare(o1.name, o2.name)
                    }
                    
                    var globalChapterIndex = 1
                    for (subOpfEntry in sortedSubOpfs) {
                        val subOpfPath = subOpfEntry.name
                        val subOpfData = parseOpf(zipFile, subOpfPath)
                        
                        // Parse TOC for this sub-OPF
                        val hrefToTitle = mutableMapOf<String, String>()
                        val navItem = subOpfData.manifest.values.find { it.properties.contains("nav", ignoreCase = true) }
                        val ncxItem = subOpfData.manifest.values.find { it.mediaType == "application/x-dtbncx+xml" || it.href.endsWith(".ncx", ignoreCase = true) }
                        
                        if (navItem != null) {
                            hrefToTitle.putAll(parseNavXhtml(zipFile, navItem.href))
                        }
                        if (ncxItem != null) {
                            hrefToTitle.putAll(parseNcx(zipFile, ncxItem.href))
                        }
                        
                        val segmentName = if (subOpfPath.contains("/")) subOpfPath.substringBefore("/") else ""
                        val prefix = if (segmentName.isNotEmpty()) "[$segmentName] " else ""
                        
                        for (spineItem in subOpfData.spine) {
                            val manifestItem = subOpfData.manifest[spineItem.idref] ?: continue
                            if (isObviousPageToSkip(manifestItem.href, manifestItem.properties, spineItem.linear)) {
                                continue
                            }
                            
                            var title = hrefToTitle[manifestItem.href.lowercase()]
                            if (title.isNullOrEmpty()) {
                                title = extractLightweightTitle(zipFile, manifestItem.href)
                            }
                            if (title.isNullOrEmpty()) {
                                title = "Chapter $globalChapterIndex"
                            } else {
                                title = prefix + title
                            }
                            
                            val chapterJson = JSONObject().apply {
                                put("index", globalChapterIndex)
                                put("file_path", manifestItem.href)
                                put("title", title)
                            }
                            finalChaptersArray.put(chapterJson)
                            globalChapterIndex++
                        }
                    }
                } else {
                    // Single OPF
                    val hrefToTitle = mutableMapOf<String, String>()
                    val navItem = primaryOpfData.manifest.values.find { it.properties.contains("nav", ignoreCase = true) }
                    val ncxItem = primaryOpfData.manifest.values.find { it.mediaType == "application/x-dtbncx+xml" || it.href.endsWith(".ncx", ignoreCase = true) }
                    
                    if (navItem != null) {
                        hrefToTitle.putAll(parseNavXhtml(zipFile, navItem.href))
                    }
                    if (ncxItem != null) {
                        hrefToTitle.putAll(parseNcx(zipFile, ncxItem.href))
                    }
                    
                    val parsedSpineChapters = mutableListOf<JSONObject>()
                    var assignedIndex = 1
                    for (spineItem in primaryOpfData.spine) {
                        val manifestItem = primaryOpfData.manifest[spineItem.idref] ?: continue
                        if (isObviousPageToSkip(manifestItem.href, manifestItem.properties, spineItem.linear)) {
                            continue
                        }
                        
                        var title = hrefToTitle[manifestItem.href.lowercase()]
                        if (title.isNullOrEmpty()) {
                            title = extractLightweightTitle(zipFile, manifestItem.href)
                        }
                        if (title.isNullOrEmpty()) {
                            title = "Chapter $assignedIndex"
                        }
                        
                        val chapterJson = JSONObject().apply {
                            put("index", assignedIndex)
                            put("file_path", manifestItem.href)
                            put("title", title)
                            put("detectedNum", parseChapterNumber(title))
                        }
                        parsedSpineChapters.add(chapterJson)
                        assignedIndex++
                    }
                    
                    // For single OPF, apply start index slicing
                    var startIndex = -1
                    for (i in parsedSpineChapters.indices) {
                        val detNum = parsedSpineChapters[i].opt("detectedNum") as? Int
                        if (detNum == 1) {
                            startIndex = i
                            break
                        }
                    }
                    if (startIndex == -1) {
                        for (i in parsedSpineChapters.indices) {
                            val detNum = parsedSpineChapters[i].opt("detectedNum") as? Int
                            if (detNum != null && detNum <= 2) {
                                startIndex = i
                                break
                            }
                        }
                    }
                    if (startIndex == -1) {
                        for (i in parsedSpineChapters.indices) {
                            val item = parsedSpineChapters[i]
                            val title = item.optString("title").lowercase()
                            if (title.contains("chapter")) {
                                startIndex = i
                                break
                            }
                        }
                    }
                    if (startIndex == -1) {
                        startIndex = 0
                        for (i in parsedSpineChapters.indices) {
                            val item = parsedSpineChapters[i]
                            val t = item.optString("title").lowercase()
                            if (t.contains("cover") || t.contains("titlepage") || t.contains("copyright") || t.contains("toc") || t.contains("table of contents")) {
                                if (i + 1 < parsedSpineChapters.size) {
                                    startIndex = i + 1
                                }
                            } else {
                                break
                            }
                        }
                    }
                    
                    val slicedChapters = if (startIndex in parsedSpineChapters.indices) {
                        parsedSpineChapters.subList(startIndex, parsedSpineChapters.size)
                    } else {
                        parsedSpineChapters
                    }
                    
                    var finalIdx = 1
                    for (chapter in slicedChapters) {
                        chapter.put("index", finalIdx)
                        finalChaptersArray.put(chapter)
                        finalIdx++
                    }
                }
                
                rootJson.put("chapters", finalChaptersArray)
                
                // Copy the picked .epub into app storage
                val epubsDir = java.io.File(context.filesDir, "epubs")
                if (!epubsDir.exists()) {
                    epubsDir.mkdirs()
                }
                // FIX A3: the old code deleted the existing book and THEN
                // copied. A failed or interrupted copy left the library with a
                // row pointing at a missing or truncated file. Stage the copy
                // beside the target, verify its length, then swap it in.
                val finalFile = java.io.File(epubsDir, "${novelId}.epub")
                val stagingFile = java.io.File(epubsDir, "${novelId}.epub.part")
                if (stagingFile.exists()) {
                    stagingFile.delete()
                }
                tempFile.copyTo(stagingFile, overwrite = true)
                if (stagingFile.length() != tempFile.length()) {
                    stagingFile.delete()
                    throw Exception("Copying the EPUB into app storage did not complete")
                }
                if (finalFile.exists()) {
                    finalFile.delete()
                }
                if (!stagingFile.renameTo(finalFile)) {
                    stagingFile.copyTo(finalFile, overwrite = true)
                    stagingFile.delete()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            rootJson.put("error", "Failed to extract EPUB: ${e.message}")
        } finally {
            if (tempFile.exists()) {
                tempFile.delete()
            }
        }
        return rootJson
    }

    fun lazyLoadChapterText(context: Context, url: String): String? {
        if (!url.startsWith("epubfile://")) return null
        try {
            val pathPart = url.substring("epubfile://".length)
            val novelId = pathPart.substringBefore("/")
            val zipEntryPath = pathPart.substringAfter("/")
            
            val epubsDir = java.io.File(context.filesDir, "epubs")
            val epubFile = java.io.File(epubsDir, "${novelId}.epub")
            if (!epubFile.exists()) {
                return "EPUB file not found on disk: ${epubFile.absolutePath}"
            }
            
            ZipFile(epubFile).use { zipFile ->
                val entry = findEntry(zipFile, zipEntryPath) ?: return "Chapter entry not found in EPUB: $zipEntryPath"
                zipFile.getInputStream(entry).use { input ->
                    val html = String(input.readBytes())
                    return extractTextFromHtml(html)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return "Failed to lazy load chapter: ${e.message}"
        }
    }

    fun lazyLoadChapterBlocks(context: Context, url: String): List<ReaderBlock> {
        if (!url.startsWith("epubfile://")) return emptyList()
        val list = mutableListOf<ReaderBlock>()
        try {
            val pathPart = url.substring("epubfile://".length)
            val novelId = pathPart.substringBefore("/")
            val zipEntryPath = pathPart.substringAfter("/")
            val zipEntryDir = if (zipEntryPath.contains("/")) zipEntryPath.substringBeforeLast("/") + "/" else ""
            
            val epubsDir = java.io.File(context.filesDir, "epubs")
            val epubFile = java.io.File(epubsDir, "${novelId}.epub")
            if (!epubFile.exists()) {
                return listOf(ReaderBlock.TextBlock("EPUB file not found on disk: ${epubFile.absolutePath}"))
            }
            
            ZipFile(epubFile).use { zipFile ->
                val entry = findEntry(zipFile, zipEntryPath) ?: return listOf(ReaderBlock.TextBlock("Chapter entry not found in EPUB: $zipEntryPath"))
                zipFile.getInputStream(entry).use { input ->
                    val html = String(input.readBytes())
                    val doc = Jsoup.parse(html)
                    val body = doc.body() ?: doc
                    
                    val blocks = mutableListOf<ReaderBlock>()
                    val currentText = StringBuilder()
                    
                    fun flushText() {
                        val text = currentText.toString().trim()
                        if (text.isNotEmpty()) {
                            val cleaned = cleanFormattedText(text)
                            if (cleaned.isNotEmpty()) {
                                cleaned.split(Regex("\\n\\n+")).forEach { p ->
                                    val trimmed = p.trim()
                                    if (trimmed.isNotEmpty()) {
                                        blocks.add(ReaderBlock.TextBlock(trimmed, isParagraphEnd = true))
                                    }
                                }
                            }
                        }
                        currentText.clear()
                    }
                    
                    fun traverse(node: Node) {
                        if (node is TextNode) {
                            currentText.append(node.text())
                        } else if (node is Element) {
                            val tagName = node.tagName().lowercase()
                            when (tagName) {
                                "img" -> {
                                    flushText()
                                    val src = node.attr("src")
                                    if (src.isNotEmpty()) {
                                        val resolved = resolveAndCleanPath(zipEntryDir, src)
                                        blocks.add(ReaderBlock.ImageBlock(resolved))
                                    }
                                }
                                "image" -> {
                                    flushText()
                                    var href = node.attr("xlink:href")
                                    if (href.isEmpty()) {
                                        href = node.attr("href")
                                    }
                                    if (href.isNotEmpty()) {
                                        val resolved = resolveAndCleanPath(zipEntryDir, href)
                                        blocks.add(ReaderBlock.ImageBlock(resolved))
                                    }
                                }
                                "p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "blockquote", "br" -> {
                                    flushText()
                                    for (child in node.childNodes()) {
                                        traverse(child)
                                    }
                                    flushText()
                                }
                                else -> {
                                    for (child in node.childNodes()) {
                                        traverse(child)
                                    }
                                }
                            }
                        }
                    }
                    
                    traverse(body)
                    flushText()
                    return blocks
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return listOf(ReaderBlock.TextBlock("Failed to lazy load chapter blocks: ${e.message}"))
        }
    }

    fun parseContainerXml(inputStream: InputStream): String {
        val parser = Xml.newPullParser()
        parser.setInput(inputStream, "UTF-8")
        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG && parser.name == "rootfile") {
                val fullPath = parser.getAttributeValue(null, "full-path")
                if (fullPath != null) {
                    return fullPath
                }
            }
            eventType = parser.next()
        }
        return "OEBPS/content.opf"
    }

    fun parseOpf(zipFile: ZipFile, opfPath: String): OpfData {
        val entry = findEntry(zipFile, opfPath) ?: throw Exception("OPF file not found: $opfPath")
        val opfDir = if (opfPath.contains("/")) opfPath.substringBeforeLast("/") + "/" else ""
        
        var title = "Unknown Title"
        var author = "Unknown Author"
        var language = "English"
        var description = "No description available."
        var series = ""
        var coverId: String? = null
        
        val manifest = mutableMapOf<String, OpfItem>()
        val spine = mutableListOf<SpineItem>()
        
        zipFile.getInputStream(entry).use { inputStream ->
            val parser = Xml.newPullParser()
            parser.setInput(inputStream, "UTF-8")
            
            var eventType = parser.eventType
            var currentTag = ""
            
            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG) {
                    currentTag = parser.name
                    when (currentTag) {
                        "item" -> {
                            val id = parser.getAttributeValue(null, "id") ?: ""
                            val href = parser.getAttributeValue(null, "href") ?: ""
                            val mediaType = parser.getAttributeValue(null, "media-type") ?: ""
                            val properties = parser.getAttributeValue(null, "properties") ?: ""
                            if (id.isNotEmpty() && href.isNotEmpty()) {
                                val resolvedHref = resolveAndCleanPath(opfDir, href)
                                manifest[id] = OpfItem(id, resolvedHref, mediaType, properties)
                            }
                        }
                        "itemref" -> {
                            val idref = parser.getAttributeValue(null, "idref") ?: ""
                            val linear = parser.getAttributeValue(null, "linear")
                            if (idref.isNotEmpty()) {
                                spine.add(SpineItem(idref, linear))
                            }
                        }
                        "meta" -> {
                            val name = parser.getAttributeValue(null, "name")
                            val content = parser.getAttributeValue(null, "content")
                            if (name == "cover" && content != null) {
                                coverId = content
                            }
                            
                            val property = parser.getAttributeValue(null, "property")
                            if (property == "belongs-to-collection") {
                                try {
                                    val nextEvent = parser.next()
                                    if (nextEvent == XmlPullParser.TEXT) {
                                        series = parser.text.trim()
                                    }
                                } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError("EpubExtractor.parseCollection", e) }
                            }
                        }
                    }
                } else if (eventType == XmlPullParser.TEXT) {
                    val text = parser.text.trim()
                    if (text.isNotEmpty()) {
                        when (currentTag) {
                            "dc:title", "title" -> title = text
                            "dc:creator", "creator" -> author = text
                            "dc:language", "language" -> language = text
                            "dc:description", "description" -> description = text
                        }
                    }
                } else if (eventType == XmlPullParser.END_TAG) {
                    currentTag = ""
                }
                eventType = parser.next()
            }
        }
        
        val coverImageItem = manifest.values.find { it.properties.contains("cover-image", ignoreCase = true) }
        val finalCoverId = coverImageItem?.id ?: coverId
        
        return OpfData(title, author, language, description, series, manifest, spine, finalCoverId)
    }

    fun parseNcx(zipFile: ZipFile, ncxPath: String): Map<String, String> {
        val entry = findEntry(zipFile, ncxPath) ?: return emptyMap()
        val hrefToTitle = mutableMapOf<String, String>()
        val ncxDir = if (ncxPath.contains("/")) ncxPath.substringBeforeLast("/") + "/" else ""
        try {
            zipFile.getInputStream(entry).use { inputStream ->
                val parser = Xml.newPullParser()
                parser.setInput(inputStream, "UTF-8")
                var eventType = parser.eventType
                var currentTag = ""
                
                class NavPointFrame {
                    var title: String = ""
                    var href: String = ""
                }
                val stack = java.util.Stack<NavPointFrame>()
                
                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG) {
                        currentTag = parser.name
                        if (currentTag == "navPoint") {
                            stack.push(NavPointFrame())
                        } else if (currentTag == "content" && stack.isNotEmpty()) {
                            val src = parser.getAttributeValue(null, "src")
                            if (src != null) {
                                stack.peek().href = src
                            }
                        }
                    } else if (eventType == XmlPullParser.TEXT) {
                        val text = parser.text.trim()
                        if (text.isNotEmpty() && currentTag == "text" && stack.isNotEmpty() && stack.peek().title.isEmpty()) {
                            stack.peek().title = text
                        }
                    } else if (eventType == XmlPullParser.END_TAG) {
                        if (parser.name == "navPoint") {
                            if (stack.isNotEmpty()) {
                                val frame = stack.pop()
                                if (frame.href.isNotEmpty() && frame.title.isNotEmpty()) {
                                    val resolvedHref = resolveAndCleanPath(ncxDir, frame.href)
                                    hrefToTitle[resolvedHref.lowercase()] = frame.title
                                }
                            }
                        }
                        currentTag = ""
                    }
                    eventType = parser.next()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return hrefToTitle
    }

    fun parseNavXhtml(zipFile: ZipFile, navPath: String): Map<String, String> {
        val entry = findEntry(zipFile, navPath) ?: return emptyMap()
        val hrefToTitle = mutableMapOf<String, String>()
        val navDir = if (navPath.contains("/")) navPath.substringBeforeLast("/") + "/" else ""
        try {
            zipFile.getInputStream(entry).use { inputStream ->
                val doc = Jsoup.parse(inputStream, "UTF-8", "")
                val navElement = doc.select("nav[epub:type=toc]").firstOrNull() 
                    ?: doc.select("nav").firstOrNull()
                    ?: doc.body()
                
                navElement?.select("a")?.forEach { a ->
                    val href = a.attr("href")
                    val title = a.text().trim()
                    if (href.isNotEmpty() && title.isNotEmpty()) {
                        val resolvedHref = resolveAndCleanPath(navDir, href)
                        hrefToTitle[resolvedHref.lowercase()] = title
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return hrefToTitle
    }

    fun extractLightweightTitle(zipFile: ZipFile, entryPath: String): String? {
        val entry = findEntry(zipFile, entryPath) ?: return null
        try {
            zipFile.getInputStream(entry).use { inputStream ->
                val doc = Jsoup.parse(inputStream, "UTF-8", "")
                val title = doc.title().trim()
                if (title.isNotEmpty() && !title.endsWith(".xhtml", ignoreCase = true) && !title.endsWith(".html", ignoreCase = true)) {
                    return title
                }
                val h1 = doc.select("h1, h2, h3, h4, h5, h6").firstOrNull()?.text()?.trim()
                if (!h1.isNullOrEmpty()) {
                    return h1
                }
            }
        } catch (e: Exception) {
            // ignore
        }
        return null
    }

    fun findEntry(zipFile: ZipFile, path: String): java.util.zip.ZipEntry? {
        val exact = zipFile.getEntry(path)
        if (exact != null) return exact
        val normalized = path.replace("\\", "/").lowercase()
        return zipFile.entries().asSequence().firstOrNull {
            it.name.replace("\\", "/").lowercase() == normalized
        }
    }

    fun extractImageBytes(context: android.content.Context, novelId: String, entryPath: String): ByteArray? {
        val epubsDir = java.io.File(context.filesDir, "epubs")
        val epubFile = java.io.File(epubsDir, "$novelId.epub")
        if (!epubFile.exists()) return null
        return try {
            java.util.zip.ZipFile(epubFile).use { zipFile ->
                val entry = findEntry(zipFile, entryPath) ?: return null
                zipFile.getInputStream(entry).use { it.readBytes() }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun extractImageBitmap(
        context: android.content.Context,
        novelId: String,
        entryPath: String,
        reqWidthPx: Int
    ): android.graphics.Bitmap? {
        val cacheKey = "$novelId/$entryPath/$reqWidthPx"
        val cached = imageCache.get(cacheKey)
        if (cached != null) return cached

        val bytes = extractImageBytes(context, novelId, entryPath) ?: return null
        val bitmap = try {
            // 1) bounds only
            val boundsOpts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, boundsOpts)
            val srcW = boundsOpts.outWidth
            val srcH = boundsOpts.outHeight
            // target ~2x display width for crispness, capped so longest side <= 2048
            val target = reqWidthPx.coerceAtLeast(1) * 2
            var sample = 1
            if (srcW > 0 && target > 0) {
                while (srcW / (sample * 2) >= target) sample *= 2
            }
            val maxSide = maxOf(srcW, srcH)
            if (maxSide > 0) {
                while (maxSide / sample > 2048) {
                    sample *= 2
                }
            }
            val opts = android.graphics.BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
                inScaled = false
            }
            android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        } catch (e: OutOfMemoryError) {
            // fallback: decode at half again
            try {
                val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = 4 }
                android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
            } catch (_: Throwable) { null }
        } catch (e: Exception) { null }

        if (bitmap != null) {
            imageCache.put(cacheKey, bitmap)
        }
        return bitmap
    }

    fun resolveAndCleanPath(baseDir: String, href: String): String {
        var cleanHref = href.substringBefore("#")
        try {
            cleanHref = java.net.URLDecoder.decode(cleanHref, "UTF-8")
        } catch (e: Exception) {
            // ignore
        }
        if (cleanHref.startsWith("/")) {
            return cleanHref.substring(1)
        }
        var b = baseDir
        var h = cleanHref
        while (h.startsWith("../")) {
            h = h.substring(3)
            b = if (b.contains("/")) b.substringBeforeLast("/").substringBeforeLast("/") + "/" else ""
        }
        return b + h
    }

    fun naturalCompare(s1: String, s2: String): Int {
        val regex = Regex("\\d+|\\D+")
        val chunks1 = regex.findAll(s1).map { it.value }.toList()
        val chunks2 = regex.findAll(s2).map { it.value }.toList()
        
        var i = 0
        while (i < chunks1.size && i < chunks2.size) {
            val c1 = chunks1[i]
            val c2 = chunks2[i]
            if (c1 != c2) {
                val isDigit1 = c1[0].isDigit()
                val isDigit2 = c2[0].isDigit()
                if (isDigit1 && isDigit2) {
                    val num1 = c1.toBigIntegerOrNull() ?: java.math.BigInteger.ZERO
                    val num2 = c2.toBigIntegerOrNull() ?: java.math.BigInteger.ZERO
                    val cmp = num1.compareTo(num2)
                    if (cmp != 0) return cmp
                } else {
                    val cmp = c1.compareTo(c2)
                    if (cmp != 0) return cmp
                }
            }
            i++
        }
        return chunks1.size.compareTo(chunks2.size)
    }

    fun isObviousPageToSkip(href: String, properties: String, linear: String?): Boolean {
        if (linear == "no") return true
        if (properties.contains("nav", ignoreCase = true) || properties.contains("cover", ignoreCase = true)) return true
        val lowerHref = href.lowercase()
        if (lowerHref.contains("cover") || lowerHref.contains("copyright") || lowerHref.contains("toc") || lowerHref.contains("titlepage")) return true
        return false
    }

    fun parseChapterNumber(text: String): Int? {
        var clean = text.trim().lowercase()
        clean = clean.replaceFirst(Regex("^[^a-z0-9]+"), "")
        if (clean.isEmpty()) return null
        
        val romanMap = mapOf(
            "i" to 1, "ii" to 2, "iii" to 3, "iv" to 4, "v" to 5, "vi" to 6, "vii" to 7, "viii" to 8, "ix" to 9, "x" to 10,
            "xi" to 11, "xii" to 12, "xiii" to 13, "xiv" to 14, "xv" to 15, "xvi" to 16, "xvii" to 17, "xviii" to 18, "xix" to 19, "xx" to 20,
            "xxi" to 21, "xxii" to 22, "xxiii" to 23, "xxiv" to 24, "xxv" to 25, "xxvi" to 26, "xxvii" to 27, "xxviii" to 28, "xxix" to 29, "xxx" to 30,
            "xl" to 40, "l" to 50, "lx" to 60, "lxx" to 70, "lxxx" to 80, "xc" to 90, "c" to 100
        )
        
        val wordMap = mapOf(
            "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10,
            "eleven" to 11, "twelve" to 12, "thirteen" to 13, "fourteen" to 14, "fifteen" to 15, "sixteen" to 16, "seventeen" to 17, "eighteen" to 18, "nineteen" to 19, "twenty" to 20,
            "twenty-one" to 21, "twenty-two" to 22, "twenty-three" to 23, "twenty-four" to 24, "twenty-five" to 25, "twenty-six" to 26, "twenty-seven" to 27, "twenty-eight" to 28, "twenty-nine" to 29,
            "thirty" to 30, "thirty-one" to 31, "thirty-two" to 32, "thirty-three" to 33, "thirty-four" to 34, "thirty-five" to 35, "thirty-six" to 36, "thirty-seven" to 37, "thirty-eight" to 38, "thirty-nine" to 39,
            "forty" to 40, "forty-one" to 41, "forty-two" to 42, "forty-three" to 43, "forty-four" to 44, "forty-five" to 45, "forty-six" to 46, "forty-seven" to 47, "forty-eight" to 48, "forty-nine" to 49,
            "fifty" to 50
        )

        val regexDigits = Regex("^(?:chapter|ch|chap|part|section|volume)\\s*[:.-]?\\s*(\\d+)", RegexOption.IGNORE_CASE)
        val matchDigits = regexDigits.find(clean)
        if (matchDigits != null) {
            return matchDigits.groupValues[1].toIntOrNull()
        }
        
        val regexWords = Regex("^(?:chapter|ch|chap|part|section|volume)\\s*[:.-]?\\s*([a-z-]+)", RegexOption.IGNORE_CASE)
        val matchWords = regexWords.find(clean)
        if (matchWords != null) {
            val wordVal = matchWords.groupValues[1].trim()
            wordMap[wordVal]?.let { return it }
            romanMap[wordVal]?.let { return it }
        }
        
        val regexStandaloneDigit = Regex("^(\\d+)(?:\\s*[:.-]|\\s+|\$)")
        val matchStandaloneDigit = regexStandaloneDigit.find(clean)
        if (matchStandaloneDigit != null) {
            return matchStandaloneDigit.groupValues[1].toIntOrNull()
        }
        
        val regexStandaloneWord = Regex("^([a-z-]+)(?:\\s*[:.-]|\\s+|\$)")
        val matchStandaloneWord = regexStandaloneWord.find(clean)
        if (matchStandaloneWord != null) {
            val wordVal = matchStandaloneWord.groupValues[1].trim()
            wordMap[wordVal]?.let { return it }
            romanMap[wordVal]?.let { return it }
        }

        return null
    }

    fun cleanHtml(html: String): String {
        try {
            return Jsoup.parse(html).text().trim()
        } catch (e: Exception) {
            return html.replace(Regex("<[^>]*>"), " ").replace(Regex("\\s+"), " ").trim()
        }
    }
    
    fun extractTextFromHtml(html: String): String {
        try {
            val doc = Jsoup.parse(html)
            val rootElement = doc.body() ?: doc
            val formattedText = formatElement(rootElement)
            return cleanFormattedText(formattedText)
        } catch (e: Exception) {
            e.printStackTrace()
            return fallbackCleanText(html)
        }
    }

    private fun formatElement(element: Element): String {
        val sb = StringBuilder()
        
        fun traverse(node: Node, currentListType: String = "") {
            when (node) {
                is TextNode -> {
                    val text = node.text()
                    if (text.isNotEmpty()) {
                        sb.append(text)
                    }
                }
                is Element -> {
                    val tag = node.tagName().lowercase()
                    when (tag) {
                        "style", "script", "head", "noscript" -> {
                        }
                        "p", "div", "section", "article" -> {
                            ensureNewline(sb)
                            for (child in node.childNodes()) {
                                traverse(child, currentListType)
                            }
                            ensureNewline(sb)
                            sb.append("\n")
                        }
                        "h1", "h2", "h3", "h4", "h5", "h6" -> {
                            ensureNewline(sb)
                            sb.append("### ")
                            for (child in node.childNodes()) {
                                traverse(child, currentListType)
                            }
                            ensureNewline(sb)
                            sb.append("\n\n")
                        }
                        "blockquote" -> {
                            ensureNewline(sb)
                            sb.append("   > ")
                            for (child in node.childNodes()) {
                                traverse(child, currentListType)
                            }
                            ensureNewline(sb)
                            sb.append("\n\n")
                        }
                        "b", "strong" -> {
                            sb.append("**")
                            for (child in node.childNodes()) {
                                traverse(child, currentListType)
                            }
                            sb.append("**")
                        }
                        "i", "em" -> {
                            sb.append("*")
                            for (child in node.childNodes()) {
                                traverse(child, currentListType)
                            }
                            sb.append("*")
                        }
                        "ul" -> {
                            ensureNewline(sb)
                            for (child in node.childNodes()) {
                                if (child is Element && child.tagName().lowercase() == "li") {
                                    ensureNewline(sb)
                                    sb.append("   • ")
                                    traverse(child, "ul")
                                    ensureNewline(sb)
                                } else {
                                    traverse(child, currentListType)
                                }
                            }
                            ensureNewline(sb)
                            sb.append("\n")
                        }
                        "ol" -> {
                            ensureNewline(sb)
                            var itemIndex = 1
                            for (child in node.childNodes()) {
                                if (child is Element && child.tagName().lowercase() == "li") {
                                    ensureNewline(sb)
                                    sb.append("   $itemIndex. ")
                                    traverse(child, "ol")
                                    ensureNewline(sb)
                                    itemIndex++
                                } else {
                                    traverse(child, currentListType)
                                }
                            }
                            ensureNewline(sb)
                            sb.append("\n")
                        }
                        "br" -> {
                            sb.append("\n")
                        }
                        else -> {
                            for (child in node.childNodes()) {
                                traverse(child, currentListType)
                            }
                        }
                    }
                }
                else -> {
                    for (child in node.childNodes()) {
                        traverse(child, currentListType)
                    }
                }
            }
        }
        
        traverse(element)
        return sb.toString()
    }

    private fun ensureNewline(sb: StringBuilder) {
        if (sb.isNotEmpty() && !sb.endsWith("\n")) {
            sb.append("\n")
        }
    }

    fun cleanFormattedText(text: String): String {
        var cleaned = text
        cleaned = cleaned.replace(Regex("(?i)\\.nn\\b"), ".")
        cleaned = cleaned.replace(Regex("\\[\\s*page\\s*\\d+\\s*\\]", RegexOption.IGNORE_CASE), "")
        cleaned = cleaned.replace(Regex("(?i)\\bPage\\s+\\d+(?:\\s+of\\s+\\d+)?\\b"), "")
        cleaned = cleaned.replace(Regex("[-_~*=]{4,}"), "")
        cleaned = cleaned.replace(Regex("\\*\\*\\s*\\*\\*"), "")
        cleaned = cleaned.replace(Regex("\\*\\s+\\*"), "")
        cleaned = cleaned.replace(Regex("(?m)^[ \t]+•"), "   •")
        cleaned = cleaned.replace(Regex("(?m)^[ \t]+>"), "   >")
        cleaned = cleaned.replace(Regex("\\n{3,}"), "\n\n")
        
        val lines = cleaned.split("\n")
        val cleanedLines = lines.map { line ->
            val indent = line.takeWhile { it == ' ' || it == '\t' }
            val rest = line.substring(indent.length).trim().replace(Regex("[\\s            ​]+"), " ")
            if (rest.isEmpty()) "" else indent + rest
        }
        cleaned = cleanedLines.joinToString("\n")
        cleaned = cleaned.replace(Regex("\\.{2,}"), ".")
        return cleaned.trim()
    }

    fun fallbackCleanText(html: String): String {
        var text = html
        text = text.replace(Regex("<style[^>]*>.*?</style>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)), "")
        text = text.replace(Regex("<script[^>]*>.*?</script>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)), "")
        text = text.replace(Regex("</p>", RegexOption.IGNORE_CASE), "\\n\\n")
        text = text.replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\\n")
        text = text.replace(Regex("<[^>]*>"), "")
        
        text = text.replace(Regex("&amp;"), "&")
        text = text.replace(Regex("&nbsp;"), " ")
        text = text.replace(Regex("&#160;"), " ")
        text = text.replace(Regex("&lt;"), "<")
        text = text.replace(Regex("&gt;"), ">")
        text = text.replace(Regex("&quot;"), "\"")
        text = text.replace(Regex("&apos;"), "'")
        text = text.replace(Regex("&#39;"), "'")
        text = text.replace(Regex("&rsquo;"), "’")
        text = text.replace(Regex("&lsquo;"), "‘")
        text = text.replace(Regex("&ldquo;"), "“")
        text = text.replace(Regex("&rdquo;"), "”")
        text = text.replace(Regex("&mdash;"), "—")
        text = text.replace(Regex("&ndash;"), "–")
        text = text.replace(Regex("&hellip;"), "…")
        
        return cleanFormattedText(text)
    }

    fun scaleAndCompressToRawBytes(imageBytes: ByteArray): ByteArray? {
        try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size, options)
            var scale = 1
            val maxDimension = 600
            if (options.outWidth > maxDimension || options.outHeight > maxDimension) {
                val largest = maxOf(options.outWidth, options.outHeight)
                scale = Math.round(largest.toFloat() / maxDimension.toFloat())
                if (scale < 1) scale = 1
            }
            val decodeOptions = BitmapFactory.Options().apply { inSampleSize = scale }
            val bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size, decodeOptions) ?: return null
            val outStream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 70, outStream)
            val compressedBytes = outStream.toByteArray()
            bitmap.recycle()
            return compressedBytes
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun scaleAndCompressImageBytes(imageBytes: ByteArray): String? {
        val compressedBytes = scaleAndCompressToRawBytes(imageBytes) ?: return null
        return Base64.encodeToString(compressedBytes, Base64.NO_WRAP)
    }

    fun parseEpub(
        htmlFiles: List<Pair<String, String>>,
        fileMap: Map<String, ByteArray>
    ): List<Volume> {
        return emptyList()
    }

    fun extractRichContent(
        body: Element,
        fileMap: Map<String, ByteArray>,
        basePath: String
    ): List<ContentBlock> {
        return emptyList()
    }

    fun mergeTextBlocks(blocks: List<ContentBlock>): List<ContentBlock> {
        return emptyList()
    }

    fun assignVolumes(chapters: List<Chapter>): List<Volume> {
        return emptyList()
    }
}
