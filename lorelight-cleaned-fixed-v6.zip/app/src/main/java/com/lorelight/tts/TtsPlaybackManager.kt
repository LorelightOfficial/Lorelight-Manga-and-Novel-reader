package com.lorelight.tts

import android.app.Application
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.util.Log
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import com.lorelight.data.model.Novel
import com.lorelight.ui.reader.ReadingPositionStore
import com.lorelight.utils.FilterRule
import com.lorelight.utils.TextFilter
import com.lorelight.core.DiagnosticLogger
import com.lorelight.core.CrashReporter
import com.lorelight.crawler.CrawlerEngine
import com.lorelight.crawler.CrawledChapter
import com.lorelight.service.TtsPlaybackService
import com.lorelight.data.local.NovelPreferences.loadNovelsFromPrefs
import com.lorelight.data.local.NovelPreferences.saveNovelsToPrefs
import com.lorelight.core.getSafeFloat
import com.lorelight.core.getSafeInt
import com.lorelight.core.getSafeString
import com.lorelight.ui.reader.ReaderBlock
import com.lorelight.ui.reader.toReaderBlocks
import com.lorelight.data.model.toNovel

object TtsPlaybackManager : AudioManager.OnAudioFocusChangeListener {

    private const val TAG = "TtsPlaybackManager"

    sealed class TtsCommand {
        object Play : TtsCommand()
        object Pause : TtsCommand()
        object PauseForFocus : TtsCommand()
        object PlayPause : TtsCommand()
        object Stop : TtsCommand()
        object NextSentence : TtsCommand()
        object PrevSentence : TtsCommand()
        object NextChapter : TtsCommand()
        object PrevChapter : TtsCommand()
        data class JumpToSentence(val index: Int) : TtsCommand()
        data class SelectChapter(val index: Int, val startPara: Int = 0, val autoPlay: Boolean = false) : TtsCommand()
        object AutoAdvance : TtsCommand()
        data class ApplyFetchedChapter(
            val chapterIndex: Int,
            val blocks: List<ReaderBlock>,
            val initialParagraphIndex: Int,
            val autoPlay: Boolean
        ) : TtsCommand()
    }

    // ── FIX A6: a real serial command queue ──────────────────────────────────
    //
    // dispatch() used to be `managerScope.launch { commandMutex.withLock { ... } }`:
    // one coroutine per command, all contending for a mutex. That gave no
    // ordering guarantee at all, so rapid taps (play/pause/next/next) could be
    // executed out of order, and a Stop could be starved behind a queue of Play
    // and AutoAdvance work that then resumed playback *after* the stop.
    //
    // Now there is exactly one worker draining a FIFO queue, and Stop clears the
    // backlog so it always wins.
    private data class QueuedCommand(val cmd: TtsCommand, val generation: Long)

    private val pendingCommands = java.util.ArrayDeque<QueuedCommand>()
    private var workerRunning = false
    private var stopGeneration = 0L

    fun dispatch(cmd: TtsCommand) {
        synchronized(pendingCommands) {
            if (cmd is TtsCommand.Stop) {
                // Everything queued before a Stop is obsolete by definition.
                stopGeneration++
                pendingCommands.clear()
            }
            pendingCommands.addLast(QueuedCommand(cmd, stopGeneration))
            if (workerRunning) return
            workerRunning = true
        }
        managerScope.launch { runCommandLoop() }
    }

    private suspend fun runCommandLoop() {
        while (true) {
            var currentGeneration = 0L
            val next: QueuedCommand? = synchronized(pendingCommands) {
                currentGeneration = stopGeneration
                val head = pendingCommands.pollFirst()
                if (head == null) workerRunning = false
                head
            }
            if (next == null) return

            // A Stop arrived after this command was queued: drop it instead of
            // letting it restart playback the user already stopped.
            if (next.generation < currentGeneration && next.cmd !is TtsCommand.Stop) {
                Log.d(TAG, "Dropping superseded command ${next.cmd}")
                continue
            }

            try {
                process(next.cmd)
            } catch (e: Exception) {
                Log.e(TAG, "cmd ${next.cmd} failed", e)
            }
        }
    }

    /** Queue depth, for diagnostics. */
    fun pendingCommandCount(): Int = synchronized(pendingCommands) { pendingCommands.size }

    private suspend fun process(cmd: TtsCommand) {
        when (cmd) {
            TtsCommand.Play -> doStartSpeaking(interrupting = true)
            TtsCommand.Pause -> doPause(isTransient = false)
            TtsCommand.PauseForFocus -> doPause(isTransient = true)
            TtsCommand.PlayPause -> {
                if (isPlaying.value) doPause(isTransient = false) else doStartSpeaking(interrupting = true)
            }
            TtsCommand.Stop -> doStop()
            TtsCommand.NextSentence -> doSkipForward()
            TtsCommand.PrevSentence -> doSkipBackward()
            TtsCommand.NextChapter -> doSelectChapter(activeChapterIndex.value + 1, 0, isPlaying.value)
            TtsCommand.PrevChapter -> doSelectChapter(activeChapterIndex.value - 1, 0, isPlaying.value)
            is TtsCommand.JumpToSentence -> doJumpToSentence(cmd.index)
            is TtsCommand.SelectChapter -> doSelectChapter(cmd.index, cmd.startPara, cmd.autoPlay)
            TtsCommand.AutoAdvance -> doAutoAdvance()
            is TtsCommand.ApplyFetchedChapter -> doApplyFetchedChapter(cmd.chapterIndex, cmd.blocks, cmd.initialParagraphIndex, cmd.autoPlay)
        }
    }
    private var isInitialized = false
    private lateinit var appContext: Context

    private var tts: TextToSpeech? = null
    
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private var wasPlayingBeforeFocusLoss = false

    // TTS state flows mirrored from ReaderViewModel
    val isTtsReady = MutableStateFlow(false)
    val availableVoices = MutableStateFlow<List<Voice>>(emptyList())
    val selectedVoice = MutableStateFlow<Voice?>(null)
    
    val speechRate = MutableStateFlow(1.0f)
    val speechPitch = MutableStateFlow(1.0f)

    // Sleep Timer
    val sleepTimerMinutes = MutableStateFlow<Int?>(null)
    private var sleepTimerJob: Job? = null
    private var prefetchJob: Job? = null
    private var nextChapterWatchJob: Job? = null

    // Voice accent filtering
    val allVoices = MutableStateFlow<List<Voice>>(emptyList())
    val availableAccents = MutableStateFlow<List<String>>(listOf("United States (US)"))
    val selectedAccent = MutableStateFlow("United States (US)")
    val filteredVoices = MutableStateFlow<List<Voice>>(emptyList())

    // Playback state flows
    val activeNovel = MutableStateFlow<Novel?>(null)
    val chapters = MutableStateFlow<List<String>>(emptyList())
    val activeChapterIndex = MutableStateFlow(0)
    val activeSentenceIndex = MutableStateFlow(0)
    val sentences = MutableStateFlow<List<ReaderBlock>>(emptyList())
    val isPlaying = MutableStateFlow(false)
    val isFetchingChapter = MutableStateFlow(false)
    val autoNextChapter = MutableStateFlow(true)

    // Battery Saving & Background States
    val isAppInBackground = MutableStateFlow(false)

    // Text Filter Rules
    val textFilterRules = MutableStateFlow<List<FilterRule>>(emptyList())

    private val managerScope = CoroutineScope(Dispatchers.Main + kotlinx.coroutines.SupervisorJob())

    val activeNovelTitle = activeNovel.map { it?.title ?: "" }.distinctUntilChanged()

    val filteredSentences = MutableStateFlow<List<ReaderBlock>>(emptyList())

    // TTS error state flow
    val errorMessage = MutableStateFlow<String?>(null)

    val sessionActive = MutableStateFlow(false)

    val maxPlayableIndex = kotlinx.coroutines.flow.combine(chapters, activeNovel) { ch, novel ->
        minOf(ch.size, novel?.chapterUrls?.size ?: 0) - 1
    }.stateIn(managerScope, SharingStarted.Eagerly, -1)

    val cachedChapterIndices = MutableStateFlow<Set<Int>>(emptySet())

    var lastActiveNovelId: String? = null

    private var wifiLock: android.net.wifi.WifiManager.WifiLock? = null

    private var currentVolume = 1.0f
    private var hasAudioFocus = false
    
    val nextSentencePauseMs = MutableStateFlow(0f)
    val paragraphPauseMs = MutableStateFlow(500f)
    val punctuationPauseScale = MutableStateFlow(1.0f)

    private var currentParagraphSentences: List<String> = emptyList()
    private var currentSentenceIndexInParagraph: Int = 0

    @Volatile private var lastProgressAtMs: Long = 0L
    private fun markProgress() { lastProgressAtMs = System.currentTimeMillis() }

    // FIX #40/#42: cached so the per-sentence path stops re-applying engine state.
    @Volatile private var lastAppliedRate: Float = -1f
    @Volatile private var lastAppliedPitch: Float = -1f
    @Volatile private var lastAppliedVoiceName: String? = null
    @Volatile private var batteryCheckDoneThisSession: Boolean = false
    private val sentenceSplitPattern = Regex("""(?<=[.!?\u2026])\s+(?=[A-Z"'\u201C(])""")

    // FIX #38: the scale used to multiply a base that defaults to 0f, so the slider
    // was inert. Now it scales around a reference so 1.0x reproduces the old
    // behaviour exactly, >1.0x lengthens, and <1.0x shortens down to zero.
    private val PUNCT_REFERENCE_MS = 250f

    private fun computeGapMs(baseMs: Float, speedFactor: Float): Long {
        val scale = punctuationPauseScale.value.coerceIn(0f, 3f)
        val extra = (baseMs + PUNCT_REFERENCE_MS) * scale - PUNCT_REFERENCE_MS
        return if (extra <= 0f) 0L else (extra / speedFactor).toLong()
    }

    private var isRecovering = false
    private var watchdogJob: Job? = null
    private var recoveryAttempts = 0
    private val STALL_MS = 9000L
    private val MAX_RETRIES = 5

    private var batteryPromptShownThisSession = false

    fun checkBatteryOptimizationOnPlay() {
        if (batteryPromptShownThisSession) return
        if (batteryCheckDoneThisSession) return
        if (!::appContext.isInitialized) return
        batteryCheckDoneThisSession = true
        val pm = appContext.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val isIgnoring = pm.isIgnoringBatteryOptimizations(appContext.packageName)
            if (!isIgnoring) {
                batteryPromptShownThisSession = true
                DiagnosticLogger.logEngineStatus("Battery optimization active for package ${appContext.packageName}.")
            }
        }
    }

    private fun reconnectEngineAndResume(reason: String) {
        if (isRecovering) return
        isRecovering = true
        DiagnosticLogger.logEngineStatus("TTS recovery: $reason -> reinitializing engine")
        managerScope.launch(Dispatchers.Main) {
            try {
                try { tts?.stop() } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError("TtsPlaybackManager.reconnectEngine", e) }
                try { tts?.shutdown() } catch (e: Exception) { com.lorelight.core.CrashReporter.recordError("TtsPlaybackManager.reconnectEngine", e) }
                tts = null
                isTtsReady.value = false
                initializeTts()
                var waited = 0
                while (!isTtsReady.value && waited < 5000) { delay(150); waited += 150 }
                if (isTtsReady.value && isPlaying.value) {
                    com.lorelight.service.TtsPlaybackService.acquireWakeLock(appContext)
                    markProgress()
                    speakSentence(currentSentenceIndexInParagraph, interrupting = true)
                }
            } finally {
                isRecovering = false
            }
        }
    }

    private fun startWatchdog() {
        if (watchdogJob?.isActive == true) return
        watchdogJob = managerScope.launch(Dispatchers.Default) {
            while (true) {
                delay(3000)
                if (!isPlaying.value) { recoveryAttempts = 0; continue }
                if (isFetchingChapter.value || isRecovering) continue
                val engine = tts
                val speaking = try { engine?.isSpeaking == true } catch (_: Exception) { false }
                val sinceProgress = System.currentTimeMillis() - lastProgressAtMs
                if (!speaking && sinceProgress > STALL_MS) {
                    recoveryAttempts++
                    withContext(Dispatchers.Main) {
                        if (recoveryAttempts <= 2) {
                            com.lorelight.service.TtsPlaybackService.acquireWakeLock(appContext)
                            markProgress()
                            speakSentence(currentSentenceIndexInParagraph, interrupting = true)
                        } else if (recoveryAttempts <= MAX_RETRIES) {
                            reconnectEngineAndResume("watchdog stall #$recoveryAttempts")
                        } else {
                            isPlaying.value = false
                            errorMessage.value = "Playback stopped: the text-to-speech engine stopped responding."
                            recoveryAttempts = 0
                        }
                    }
                    delay((recoveryAttempts.coerceAtMost(4)) * 1000L)
                } else if (speaking || sinceProgress < STALL_MS) {
                    recoveryAttempts = 0
                }
            }
        }
    }

    private fun acquireWifiLock() {
        try {
            if (wifiLock == null) {
                val wifiManager = appContext.applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager
                wifiLock = wifiManager.createWifiLock(android.net.wifi.WifiManager.WIFI_MODE_FULL_HIGH_PERF, "Lorelight:TtsWifiLock")
            }
            wifiLock?.let {
                if (!it.isHeld) {
                    it.acquire()
                    Log.d(TAG, "[WifiLock] WifiLock acquired")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to acquire WifiLock", e)
        }
    }

    private fun releaseWifiLock() {
        try {
            wifiLock?.let {
                if (it.isHeld) {
                    it.release()
                    Log.d(TAG, "[WifiLock] WifiLock released")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to release WifiLock", e)
        }
    }

    fun recomputeCachedChapters() {
        val novel = activeNovel.value ?: return
        managerScope.launch(Dispatchers.IO) {
            val cachedSet = mutableSetOf<Int>()
            novel.chapterUrls.forEachIndexed { index, url ->
                if (!url.isNullOrEmpty() && CrawlerEngine.isChapterCached(appContext, url)) {
                    cachedSet.add(index)
                }
            }
            cachedChapterIndices.value = cachedSet
            Log.d(TAG, "Recomputed cached chapter indices: $cachedSet")
        }
    }

    fun getFreshestNovel(): Novel? {
        val current = activeNovel.value
        val id = current?.id ?: lastActiveNovelId ?: return null
        val fresh = loadNovelsFromPrefs(appContext).firstOrNull { it.id == id }
        return fresh ?: current
    }

    fun recalculateFilteredSentences() {
        val rawSentences = sentences.value
        val rules = textFilterRules.value
        val bookTitle = activeNovel.value?.title ?: ""
        val bookId = activeNovel.value?.id ?: ""
        if (rawSentences.isEmpty()) {
            filteredSentences.value = emptyList()
            return
        }

        val lineTexts = rawSentences.map { block ->
            when (block) {
                is ReaderBlock.TextBlock -> block.text
                is ReaderBlock.ImageBlock -> ""
            }
        }

        val erasedIndices = TextFilter.linesToErase(lineTexts, rules, currentBookId = bookId, currentBookTitle = bookTitle)

        val result = mutableListOf<ReaderBlock>()
        rawSentences.forEachIndexed { idx, block ->
            if (idx !in erasedIndices) {
                when (block) {
                    is ReaderBlock.TextBlock -> {
                        val filteredText = TextFilter.applyRawStringRules(block.text, rules, currentBookId = bookId, currentBookTitle = bookTitle)
                        if (filteredText.isNotBlank()) {
                            result.add(ReaderBlock.TextBlock(filteredText, block.isParagraphEnd))
                        }
                    }
                    is ReaderBlock.ImageBlock -> {
                        result.add(block)
                    }
                }
            }
        }
        filteredSentences.value = result
    }

    private fun updateSentences(newSentences: List<ReaderBlock>) {
        sentences.value = newSentences
        recalculateFilteredSentences()
    }

    fun init(context: Context) {
        if (isInitialized) return
        appContext = context.applicationContext
        audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        isInitialized = true

        loadRules()

        // Load saved settings
        val prefs = appContext.getSharedPreferences("reader_prefs", Context.MODE_PRIVATE)
        speechRate.value = prefs.getSafeFloat("speech_rate", 1.0f)
        speechPitch.value = prefs.getSafeFloat("speech_pitch", 1.0f)
        selectedAccent.value = prefs.getSafeString("selected_accent", "United States (US)") ?: "United States (US)"
        autoNextChapter.value = prefs.getBoolean("auto_next_chapter", true)
        nextSentencePauseMs.value = prefs.getSafeFloat("next_sentence_pause_ms", 0f)
        paragraphPauseMs.value = prefs.getSafeFloat("paragraph_pause_ms", 500f)
        punctuationPauseScale.value = prefs.getSafeFloat("punctuation_pause_scale", 1.0f)

        // Observers to save preferences
        managerScope.launch { speechRate.collect { prefs.edit().putFloat("speech_rate", it).apply() } }
        managerScope.launch { speechPitch.collect { prefs.edit().putFloat("speech_pitch", it).apply() } }
        managerScope.launch { selectedVoice.collect { it?.let { prefs.edit().putString("selected_voice_name", it.name).apply() } } }
        managerScope.launch { activeSentenceIndex.collect { saveProgress() } }
        managerScope.launch { selectedAccent.collect { prefs.edit().putString("selected_accent", it).apply() } }
        managerScope.launch { autoNextChapter.collect { prefs.edit().putBoolean("auto_next_chapter", it).apply() } }
        managerScope.launch { nextSentencePauseMs.collect { prefs.edit().putFloat("next_sentence_pause_ms", it).apply() } }
        managerScope.launch { paragraphPauseMs.collect { prefs.edit().putFloat("paragraph_pause_ms", it).apply() } }
        managerScope.launch { punctuationPauseScale.collect { prefs.edit().putFloat("punctuation_pause_scale", it).apply() } }
        managerScope.launch { textFilterRules.collect { recalculateFilteredSentences() } }
        managerScope.launch {
            activeNovel
                .map { it?.title }
                .distinctUntilChanged()
                .collect { recalculateFilteredSentences() }
        }
        managerScope.launch {
            isAppInBackground.collect { isInBg ->
                DiagnosticLogger.logEngineStatus("[Background] App background state changed: isBg=$isInBg")
                forceFlushProgress()
            }
        }

        managerScope.launch {
            com.lorelight.crawler.CrawlerEngine.cacheUpdateTrigger.collect {
                recomputeCachedChapters()
            }
        }

        managerScope.launch {
            activeNovel.collect { novel ->
                if (novel != null) {
                    lastActiveNovelId = novel.id
                    recomputeCachedChapters()
                }
            }
        }

        // Polling loop removed entirely to make speech playback 100% callback-driven, eliminating stutters and saving massive battery.
        initializeTts()
        startWatchdog()
        setupServiceSync()
    }

    private fun setupServiceSync() {
        TtsPlaybackService.onPlayPauseAction = {
            togglePlayPause()
        }
        TtsPlaybackService.onPlayAction = {
            startSpeaking()
        }
        TtsPlaybackService.onPauseAction = {
            pauseSpeaking()
        }
        TtsPlaybackService.onNextAction = {
            skipForward()
        }
        TtsPlaybackService.onPrevAction = {
            skipBackward()
        }
        TtsPlaybackService.onStopAction = {
            sessionActive.value = false
            stopSpeaking()
        }

        managerScope.launch {
            kotlinx.coroutines.flow.combine(isPlaying, activeNovel, activeSentenceIndex, filteredSentences, sessionActive) { _, _, _, _, _ -> }
                .collect {
                    val novel = activeNovel.value
                    val isSessionActive = sessionActive.value
                    if (isSessionActive && novel != null) {
                        pushPlaybackServiceUpdate()
                    } else {
                        stopPlaybackService()
                    }
                }
        }
    }

    private var lastNotificationState: NotificationState? = null

    private fun pushPlaybackServiceUpdate() {
        val novel = activeNovel.value ?: return
        val blocks = filteredSentences.value
        val activeIdx = activeSentenceIndex.value
        val block = blocks.getOrNull(activeIdx)
        val text = when (block) {
            is ReaderBlock.TextBlock -> block.text
            is ReaderBlock.ImageBlock -> "[Image]"
            else -> ""
        }
        val chName = chapters.value.getOrNull(activeChapterIndex.value) ?: ""

        val currentState = NotificationState(
            title = novel.title,
            author = novel.author,
            isPlaying = isPlaying.value,
            coverBase64 = novel.coverImageBase64,
            text = text,
            chapterName = chName
        )

        if (currentState == lastNotificationState) {
            return
        }
        lastNotificationState = currentState

        // Character-based progress estimation: ~15 chars = 1000ms (1 second) of audio
        var totalChars = 0L
        var completedChars = 0L
        blocks.forEachIndexed { idx, b ->
            val len = when (b) {
                is ReaderBlock.TextBlock -> b.text.length.toLong()
                is ReaderBlock.ImageBlock -> 0L
            }
            totalChars += len
            if (idx < activeIdx) {
                completedChars += len
            }
        }
        
        val charsPerSecond = 15.0
        val durationMs = (totalChars / charsPerSecond * 1000).toLong().coerceAtLeast(1000L)
        val positionMs = (completedChars / charsPerSecond * 1000).toLong().coerceIn(0L, durationMs)

        TtsPlaybackService.currentCoverBase64 = novel.coverImageBase64
        val intent = Intent(appContext, TtsPlaybackService::class.java).apply {
            action = TtsPlaybackService.ACTION_UPDATE
            putExtra(TtsPlaybackService.EXTRA_TITLE, novel.title)
            putExtra(TtsPlaybackService.EXTRA_AUTHOR, novel.author)
            putExtra(TtsPlaybackService.EXTRA_NOVEL_ID, novel.id)
            putExtra(TtsPlaybackService.EXTRA_PLAYING, isPlaying.value)
            putExtra(TtsPlaybackService.EXTRA_COVER, novel.coverImageBase64)
            putExtra(TtsPlaybackService.EXTRA_TEXT, text)
            putExtra(TtsPlaybackService.EXTRA_CHAPTER, chName)
            putExtra(TtsPlaybackService.EXTRA_POSITION_MS, positionMs)
            putExtra(TtsPlaybackService.EXTRA_DURATION_MS, durationMs)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appContext.startForegroundService(intent)
            } else {
                appContext.startService(intent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start service", e)
        }
    }

    private fun stopPlaybackService() {
        lastNotificationState = null
        try {
            appContext.stopService(Intent(appContext, TtsPlaybackService::class.java))
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun initializeTts() {
        Log.d(TAG, "Initializing TTS with com.google.android.tts...")
        DiagnosticLogger.logEngineStatus("Initializing primary Google TTS engine (com.google.android.tts)")
        errorMessage.value = null
        try {
            tts = TextToSpeech(appContext, { status ->
                if (status == TextToSpeech.SUCCESS) {
                    isTtsReady.value = true
                    errorMessage.value = null
                    DiagnosticLogger.logEngineStatus("Primary Google TTS engine initialized successfully.")
                    setupVoices()
                } else {
                    Log.e(TAG, "Failed to initialize Google TTS engine, attempting fallback to default engine...")
                    DiagnosticLogger.logEngineStatus("Failed to initialize Google TTS engine, status code=$status. Invoking fallback...")
                    fallbackInitializeTts()
                }
            }, "com.google.android.tts")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create com.google.android.tts, trying fallback", e)
            DiagnosticLogger.logEngineStatus("Primary Google TTS constructor exception: ${e.message}. Invoking fallback...")
            fallbackInitializeTts()
        }
    }

    private fun fallbackInitializeTts() {
        try {
            DiagnosticLogger.logEngineStatus("Initializing fallback system default TTS engine...")
            tts = TextToSpeech(appContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    Log.d(TAG, "Successfully initialized fallback default platform TTS engine")
                    isTtsReady.value = true
                    errorMessage.value = null
                    DiagnosticLogger.logEngineStatus("Fallback platform system default TTS engine initialized successfully.")
                    setupVoices()
                } else {
                    Log.e(TAG, "Failed to initialize default platform TTS engine as well.")
                    isTtsReady.value = false
                    errorMessage.value = "Failed to initialize TTS. Please configure a Text-To-Speech engine in your Android settings."
                    DiagnosticLogger.logEngineStatus("Critical: Fallback TTS engine failed to initialize, status code=$status.")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create default platform TTS engine", e)
            isTtsReady.value = false
            errorMessage.value = "Failed to create local platform TTS component: ${e.message ?: "Unknown error"}"
            DiagnosticLogger.logEngineStatus("Critical: Fallback TTS constructor exception: ${e.message}")
        }
    }

    private fun setupVoices() {
        val engine = tts ?: return
        lastAppliedRate = -1f
        lastAppliedPitch = -1f
        lastAppliedVoiceName = null
        try {
            engine.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    DiagnosticLogger.logEngineStatus("TTS Utterance OnStart: id=$utteranceId")
                    com.lorelight.service.TtsPlaybackService.acquireWakeLock(appContext)
                    markProgress()
                    recoveryAttempts = 0
                }
                override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                    markProgress()
                }
                override fun onDone(utteranceId: String?) {
                    DiagnosticLogger.logEngineStatus("TTS Utterance OnDone: id=$utteranceId")
                    markProgress()
                    recoveryAttempts = 0
                    if (utteranceId != null && utteranceId.startsWith("reader_utt_")) {
                        val index = utteranceId.substringAfter("reader_utt_").toIntOrNull()
                        if (index != null && index == currentSentenceIndexInParagraph) {
                            if (index < currentParagraphSentences.lastIndex) {
                                currentSentenceIndexInParagraph = index + 1
                                managerScope.launch {
                                    val speedFactor = speechRate.value.coerceAtLeast(0.25f)
                                    val gap = computeGapMs(nextSentencePauseMs.value, speedFactor)
                                    if (gap > 0L) delay(gap)
                                    if (isPlaying.value) {
                                        speakSentence(currentSentenceIndexInParagraph, false)
                                    }
                                }
                            } else {
                                managerScope.launch {
                                    if (isPlaying.value) {
                                        dispatch(TtsCommand.AutoAdvance)
                                    }
                                }
                            }
                        }
                    }
                }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    managerScope.launch(Dispatchers.Main) { 
                        DiagnosticLogger.logEngineStatus("TTS Utterance OnError(deprecated): id=$utteranceId")
                        CrashReporter.recordError(appContext, TAG, Exception("TTS speak processing error"), "TTS_PLAYBACK_CALLBACK_ERROR")
                        if (isPlaying.value) {
                            recoveryAttempts++
                            if (recoveryAttempts <= MAX_RETRIES) {
                                reconnectEngineAndResume("utterance onError deprecated")
                            } else {
                                isPlaying.value = false
                                errorMessage.value = "TTS engine reported a speak processing error."
                                recoveryAttempts = 0
                            }
                        } else {
                            errorMessage.value = "TTS engine reported a speak processing error."
                        }
                    }
                }
                override fun onError(utteranceId: String?, errorCode: Int) {
                    managerScope.launch(Dispatchers.Main) {
                        val errorStr = when (errorCode) {
                            -14 -> "Audio resource capacity exceeded"
                            -13 -> "Invalid TTS request configuration"
                            -11 -> "Network issue: Selected voice requires internet access"
                            -12 -> "Network connection timeout"
                            -6 -> "Voice asset is still downloading or not fully installed on device"
                            -5 -> "TTS playback is mocked or restricted"
                            -4 -> "TTS engine service connection failure"
                            -3 -> "Synthesis parsing issue or corrupted input string"
                            else -> "Internal Text-to-Speech service error (code $errorCode)"
                        }
                        DiagnosticLogger.logEngineStatus("TTS Utterance OnError: id=$utteranceId, code=$errorCode ($errorStr)")
                        CrashReporter.recordError(appContext, TAG, Exception("TTS Callback Error ($errorCode): $errorStr"), "TTS_PLAYBACK_CALLBACK_ERROR")
                        if (isPlaying.value) {
                            recoveryAttempts++
                            if (recoveryAttempts <= MAX_RETRIES) {
                                reconnectEngineAndResume("utterance onError code=$errorCode")
                            } else {
                                isPlaying.value = false
                                errorMessage.value = "TTS Error: $errorStr"
                                recoveryAttempts = 0
                            }
                        } else {
                            errorMessage.value = "TTS Error: $errorStr"
                        }
                    }
                }
            })

            val voiceList = engine.voices?.toList() ?: emptyList()
            val enVoices = voiceList.filter {
                it.locale.language.equals("en", ignoreCase = true)
            }.sortedBy { it.name }

            allVoices.value = enVoices

            val countryMapping = mapOf(
                "US" to "United States (US)",
                "GB" to "United Kingdom (UK)",
                "IN" to "India (IN)",
                "AU" to "Australia (AU)",
                "CA" to "Canada (CA)",
                "IE" to "Ireland (IE)",
                "SG" to "Singapore (SG)",
                "ZA" to "South Africa (ZA)"
            )

            val foundCountries = enVoices.mapNotNull {
                val c = it.locale.country.uppercase()
                if (c.isNotEmpty()) c else null
            }.distinct()

            val accentList = foundCountries.map { code ->
                countryMapping[code] ?: "${Locale(Locale.ENGLISH.language, code).displayCountry} ($code)"
            }.sortedBy { it }

            val finalAccentList = if (accentList.any { it.contains("(US)") }) {
                accentList
            } else {
                listOf("United States (US)") + accentList
            }
            availableAccents.value = finalAccentList

            val savedAccent = appContext.getSharedPreferences("reader_prefs", Context.MODE_PRIVATE).getSafeString("selected_accent", "United States (US)") ?: "United States (US)"
            if (finalAccentList.contains(savedAccent)) {
                selectedAccent.value = savedAccent
            } else {
                selectedAccent.value = "United States (US)"
            }

            updateFilteredVoicesAndSelectDefault()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun updateFilteredVoicesAndSelectDefault() {
        val engine = tts ?: return
        try {
            val currentAccent = selectedAccent.value
            val countryCode = getCountryCodeFromAccent(currentAccent)

            val filt = allVoices.value.filter {
                it.locale.country.equals(countryCode, ignoreCase = true)
            }.sortedBy { it.name }

            filteredVoices.value = filt.ifEmpty { allVoices.value }
            availableVoices.value = filteredVoices.value

            val savedName = appContext.getSharedPreferences("reader_prefs", Context.MODE_PRIVATE).getSafeString("selected_voice_name", null)
            val defaultChoice = if (savedName != null) filteredVoices.value.find { it.name == savedName } else null
                ?: filteredVoices.value.find { it.name.contains("en-us-x-iom", ignoreCase = true) }
                ?: filteredVoices.value.find { it.name.contains("iom", ignoreCase = true) }
                ?: filteredVoices.value.firstOrNull()
                ?: engine.voice

            defaultChoice?.let {
                selectedVoice.value = it
                engine.voice = it
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to select default voice or retrieve voice properties from engine", e)
        }
    }

    private fun getCountryCodeFromAccent(accent: String): String {
        val startIndex = accent.indexOf('(')
        val endIndex = accent.indexOf(')')
        if (startIndex != -1 && endIndex != -1 && endIndex > startIndex) {
            val code = accent.substring(startIndex + 1, endIndex)
            if (code.equals("UK", ignoreCase = true)) return "GB"
            return code
        }
        return "US"
    }

    fun selectAccentAndApply(accent: String) {
        selectedAccent.value = accent
        updateFilteredVoicesAndSelectDefault()
        filteredVoices.value.firstOrNull()?.let {
            selectVoiceAndApply(it)
        }
    }

    /**
     * RESUME REDESIGN. One place decides which chapter a session opens on.
     *
     * Order of authority: an explicit index from the caller, then an explicit
     * name, then the durable currentChapterIndex stamped by whoever last turned
     * a page, and only then the old name lookup for rows saved before the index
     * existed.
     *
     * The old code did indexOf(currentChapter) and, on a miss, quietly returned
     * 0. That single fallback is the "placeholder Chapter 1" bug: a history card
     * can carry a snapshot whose chapter list is the synthetic 1..100 filler, so
     * the real chapter name was never in it and the player always landed on the
     * first chapter. 0 is now returned only when there is genuinely nothing else
     * to go on.
     */
    private fun resolveStartIndex(
        novel: Novel,
        startChapterName: String?,
        startChapterIndex: Int?
    ): Int {
        if (startChapterIndex != null && startChapterIndex in novel.chapters.indices) {
            return startChapterIndex
        }
        if (startChapterName != null) {
            val byName = novel.chapters.indexOf(startChapterName)
            if (byName >= 0) return byName
        }
        if (novel.currentChapterIndex in novel.chapters.indices) {
            return novel.currentChapterIndex
        }
        val byCurrentName = novel.chapters.indexOf(novel.currentChapter)
        return if (byCurrentName >= 0) byCurrentName else 0
    }

    fun startReading(novel: Novel, startChapterName: String? = null, startChapterIndex: Int? = null) {
        // ── Resume-friendly: if this novel is already the active session and the
        // caller isn't jumping to a DIFFERENT chapter, don't stop TTS — just
        // refresh metadata (e.g. newly added chapters) and keep playing. ──
        val current = activeNovel.value
        if (sessionActive.value && current != null && current.id == novel.id) {
            val requestedIdx = startChapterIndex ?: startChapterName?.let { name ->
                novel.chapters.indexOf(name).takeIf { it >= 0 }
            }
            val currentIdx = activeChapterIndex.value
            if (requestedIdx == null || requestedIdx == currentIdx) {
                // Same novel, same (or unspecified) chapter → keep playback alive.
                activeNovel.value = novel
                chapters.value = novel.chapters
                return
            }
        }

        dispatch(TtsCommand.Stop)
        sessionActive.value = true
        activeNovel.value = novel
        chapters.value = novel.chapters

        val initialIdx = resolveStartIndex(novel, startChapterName, startChapterIndex)

        // FIX #4 / #11: SelectChapter expects an index into the TTS `sentences`
        // list. currentWordIndex holds exactly that. currentParagraphIndex is the
        // reader's LazyColumn item index - a different index space - and using it
        // here made TTS start speaking somewhere other than where the reader
        // scrolled to. currentWordIndex was previously written but never read.
        val startParaIdx = if (startChapterIndex == null && (startChapterName == null || startChapterName == novel.currentChapter)) {
            novel.currentWordIndex
        } else {
            0
        }

        dispatch(TtsCommand.SelectChapter(initialIdx, startParaIdx))
    }

    fun startReadingAndPlay(novel: Novel, startChapterName: String? = null, startChapterIndex: Int? = null) {
        // ── If the same novel is already active AND currently speaking, don't
        // restart — just refresh metadata. If it's active but paused, fall
        // through only to trigger Play, never a full Stop+reload. ──
        val current = activeNovel.value
        if (sessionActive.value && current != null && current.id == novel.id) {
            val requestedIdx = startChapterIndex ?: startChapterName?.let { name ->
                novel.chapters.indexOf(name).takeIf { it >= 0 }
            }
            val currentIdx = activeChapterIndex.value
            if (requestedIdx == null || requestedIdx == currentIdx) {
                activeNovel.value = novel
                chapters.value = novel.chapters
                if (!isPlaying.value) {
                    dispatch(TtsCommand.Play)
                }
                return
            }
        }

        dispatch(TtsCommand.Stop)
        sessionActive.value = true
        activeNovel.value = novel
        chapters.value = novel.chapters

        val initialIdx = resolveStartIndex(novel, startChapterName, startChapterIndex)

        // FIX #4 / #11: SelectChapter expects an index into the TTS `sentences`
        // list. currentWordIndex holds exactly that. currentParagraphIndex is the
        // reader's LazyColumn item index - a different index space - and using it
        // here made TTS start speaking somewhere other than where the reader
        // scrolled to. currentWordIndex was previously written but never read.
        val startParaIdx = if (startChapterIndex == null && (startChapterName == null || startChapterName == novel.currentChapter)) {
            novel.currentWordIndex
        } else {
            0
        }

        dispatch(TtsCommand.SelectChapter(initialIdx, startParaIdx, autoPlay = true))
    }

    fun tryRestoreLastActiveSession() {
        if (activeNovel.value != null) return // Already loaded!
        val history = com.lorelight.data.local.NovelPreferences.loadHistoryFromPrefs(appContext)
        val lastEntry = history.firstOrNull() ?: return
        try {
            if (lastEntry.novelJson.isNotEmpty()) {
                val novel = org.json.JSONObject(lastEntry.novelJson).toNovel()
                startReading(novel)
                Log.d(TAG, "[Resurrection] Restored last active session for novel: ${novel.title}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "[Resurrection] Failed to restore session from json", e)
        }
    }

    // FIX #16: starting at 0L made "now - lastSaveTime >= timeLimit" always true
    // on the first save of a session, bypassing the buffer.
    private var lastSaveTime = System.currentTimeMillis()
    private var sentenceCountSinceSave = 0

    // FIX #13: serialises the read-modify-write of the whole novel list so two
    // overlapping flushes (reader scroll save + TTS sentence save) cannot lose
    // each other's progress.
    private val progressWriteMutex = kotlinx.coroutines.sync.Mutex()

    @Volatile private var pendingParagraphIndex: Int? = null
    @Volatile private var pendingScrollOffset: Int? = null
    @Volatile private var pendingWordIndex: Int? = null

    fun forceFlushProgress() {
        if (activeNovel.value == null) return
        writeNovelProgressToDiskImmediate()
    }

    /** Merges pending progress into the novel. Does NOT emit to the StateFlow. */
    private fun buildNovelWithPendingProgress(): Novel? {
        val novel = activeNovel.value ?: return null
        val chapterName = chapters.value.getOrNull(activeChapterIndex.value) ?: novel.currentChapter
        return novel.copy(
            currentChapter = chapterName,
            // RESUME REDESIGN. Stamp the index alongside the name. This is the
            // write that makes every resume path reliable.
            currentChapterIndex = activeChapterIndex.value,
            currentParagraphIndex = pendingParagraphIndex ?: novel.currentParagraphIndex,
            currentScrollOffset = pendingScrollOffset ?: novel.currentScrollOffset,
            currentWordIndex = pendingWordIndex ?: novel.currentWordIndex,
            lastReadTimestamp = System.currentTimeMillis()
        )
    }

    // FIX #9: the old signature took a Novel and then ignored it completely,
    // which let callers believe they controlled which novel was written. Removed.
    private fun writeNovelProgressToDiskImmediate() {
        val merged = prepareFlush() ?: return
        managerScope.launch(Dispatchers.IO) {
            progressWriteMutex.withLock {
                try {
                    // Phase 1B: this was loadNovelsFromPrefs -> map -> saveNovelsToPrefs,
                    // i.e. a full rewrite of every row in the library on every flush
                    // (roughly every 5 sentences). It now writes the single
                    // reading_progress row belonging to this novel.
                    //
                    // FIX #5 still holds: the row is keyed on id, never on title.
                    com.lorelight.data.local.NovelPreferences.saveProgressOnly(appContext, merged)
                } catch (e: Exception) { e.printStackTrace() }
            }
        }
    }

    /**
     * FIX A1 + A6: durable flush for pause / stop / teardown.
     *
     * The old pause and stop paths called forceFlushProgress(), which fired a
     * coroutine and returned immediately. If the process was killed right after
     * (very common: user pauses, swipes the app away, Android reclaims it) the
     * write never happened and the last minutes of listening were lost. This
     * version does not return until the row is on disk.
     */
    private suspend fun flushProgressDurably() {
        val merged = prepareFlush() ?: return
        withContext(Dispatchers.IO) {
            progressWriteMutex.withLock {
                try {
                    com.lorelight.data.local.NovelPreferences.saveProgressOnlySync(appContext, merged)
                } catch (e: Exception) { e.printStackTrace() }
            }
        }
    }

    /**
     * Shared preparation for both flush paths: publish the merged novel, persist
     * the precise chapter-scoped position and reset the debounce counters.
     */
    private fun prepareFlush(): Novel? {
        val merged = buildNovelWithPendingProgress() ?: return null
        // Update the flow ONCE per flush (every ~5 sentences), not every sentence:
        activeNovel.value = merged

        // FIX #7: the position store is written here, INSIDE the debounce, instead
        // of on every single sentence. Chapter-scoped now (FIX #3).
        if (::appContext.isInitialized && merged.id.isNotEmpty()) {
            val chIdx = activeChapterIndex.value
            if (chIdx >= 0) {
                ReadingPositionStore.save(
                    context = appContext,
                    novelId = merged.id,
                    chapterIndex = chIdx,
                    index = merged.currentParagraphIndex,
                    offset = merged.currentScrollOffset,
                    fraction = 0f,
                    layoutSig = 0
                )
            }
        }

        // FIX #8: pending values must NOT survive the flush. They are @Volatile
        // fields that persisted across chapters and novels, so chapter N's pixel
        // offset was being applied to chapter N+1.
        pendingParagraphIndex = null
        pendingScrollOffset = null
        pendingWordIndex = null

        lastSaveTime = System.currentTimeMillis()
        sentenceCountSinceSave = 0
        return merged
    }

    // FIX #4: activeSentenceIndex is an index into `sentences` (the unfiltered TTS
    // list), NOT into `filteredSentences` (the LazyColumn list). Writing it into
    // currentParagraphIndex corrupted the reader's scroll index every time a text
    // filter rule removed blocks - the two writers were stomping on each other in
    // incompatible index spaces. It belongs in currentWordIndex, which is the TTS
    // sentence slot. FIX #11 then makes that field actually get read again.
    fun saveProgress() {
        val novel = activeNovel.value ?: return
        if (chapters.value.getOrNull(activeChapterIndex.value) == null) return
        pendingWordIndex = activeSentenceIndex.value
        saveNovelProgressLocally(novel)
    }

    fun saveDetailedProgress(paragraphIndex: Int, scrollOffset: Int, wordIndex: Int) {
        val novel = activeNovel.value ?: return
        if (chapters.value.getOrNull(activeChapterIndex.value) == null) return
        pendingParagraphIndex = paragraphIndex
        pendingScrollOffset = scrollOffset
        pendingWordIndex = wordIndex
        saveNovelProgressLocally(novel)
    }

    private fun saveNovelProgressLocally(novel: Novel) {
        // FIX #6 / #7: the ReadingPositionStore.save() call that used to be here
        // ran on EVERY sentence with a blocking commit(), which defeated the whole
        // battery-saving buffer below. It now happens inside
        // writeNovelProgressToDiskImmediate(), i.e. only on an actual flush.
        val now = System.currentTimeMillis()
        val isBg = isAppInBackground.value

        // Buffer limits optimized for background states
        val timeLimit = if (isBg) 30000L else 12000L // 30s in bg, 12s in normal active foreground
        val sentenceLimit = if (isBg) 12 else 5 // 12 sentences in bg, 5 sentences in normal active foreground

        sentenceCountSinceSave++

        if (now - lastSaveTime >= timeLimit || sentenceCountSinceSave >= sentenceLimit) {
            writeNovelProgressToDiskImmediate()
        } else {
            // Keep memory state 100% reactive, but defer persistent storage write to save battery
            Log.d(TAG, "Progress cached in memory: sentence count = $sentenceCountSinceSave/$sentenceLimit")
        }
    }

    private fun isChapterFetchFailure(text: String?): Boolean {
        if (text.isNullOrBlank()) return true
        return com.lorelight.crawler.CrawlerEngine.isFailureText(text)
    }

    private suspend fun stopThenSettle() {
        tts?.stop()
        delay(200L)   // OEM stop() is async; too-soon speak() is dropped
    }

    fun selectChapter(index: Int, initialParagraphIndex: Int = 0, autoPlay: Boolean = false) {
        dispatch(TtsCommand.SelectChapter(index, initialParagraphIndex, autoPlay))
    }

    private suspend fun doSelectChapter(index: Int, initialParagraphIndex: Int = 0, autoPlay: Boolean = false) {
        if (chapters.value.isEmpty()) return
        val safeIndex = index.coerceIn(0, chapters.value.lastIndex)
        val wasPlaying = isPlaying.value || autoPlay
        nextChapterWatchJob?.cancel()
        nextChapterWatchJob = null
        stopThenSettle()                        // from Prompt 1: async stop() safety
        
        // Track completed chapters
        val previousIdx = activeChapterIndex.value
        if (safeIndex != previousIdx) {
            val prevChapterName = chapters.value.getOrNull(previousIdx)
            val currentContextNovel = activeNovel.value
            if (prevChapterName != null && currentContextNovel != null) {
                if (!currentContextNovel.completedChapters.contains(prevChapterName)) {
                    val updatedList = currentContextNovel.completedChapters + prevChapterName
                    val updatedNovel = currentContextNovel.copy(completedChapters = updatedList)
                    activeNovel.value = updatedNovel
                    saveNovelProgressLocally(updatedNovel)
                }
            }
            // NEW CHAPTER-STATE BACKEND. Novels never recorded per-chapter
            // completion anywhere the details list could read, which is the whole
            // reason nothing ever dulled out for text novels: the only record was
            // a list of chapter NAME strings that only this function appended to.
            // Moving FORWARD off a chapter is the honest "you finished it" moment.
            if (::appContext.isInitialized && previousIdx >= 0 && safeIndex > previousIdx) {
                activeNovel.value?.let { n ->
                    com.lorelight.data.chapters.ChapterReadStore.markCompleted(appContext, n, previousIdx)
                }
            }
        }

        activeChapterIndex.value = safeIndex
        // Stamped on the one path every novel chapter open goes through, so the
        // details list highlights where you actually are.
        if (::appContext.isInitialized) {
            activeNovel.value?.let { n ->
                com.lorelight.data.chapters.ChapterReadStore.setCurrent(appContext, n, safeIndex)
            }
        }
        isFetchingChapter.value = true
        updateSentences(listOf(ReaderBlock.TextBlock("Loading chapter...")))

        // Delayed Prefetching
        prefetchJob?.cancel()
        prefetchJob = managerScope.launch {
            delay(3000L)
            val currentNovel = activeNovel.value
            val nextIndex = safeIndex + 1
            if (currentNovel != null && nextIndex < currentNovel.chapterUrls.size) {
                val nextUrl = currentNovel.chapterUrls[nextIndex]
                if (!nextUrl.isNullOrEmpty()) {
                    withContext(Dispatchers.IO) {
                        if (!CrawlerEngine.isChapterCached(appContext, nextUrl)) {
                            try {
                                Log.d("TtsPlaybackManager", "Smart prefetching next chapter URL in background: $nextUrl")
                                CrawlerEngine.extractChapterText(appContext, nextUrl)
                                recomputeCachedChapters()
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    }
                }
            }
        }

        // a) resolve URL from in-memory novel, then reload from prefs if blank
        var novel = activeNovel.value
        var url = novel?.chapterUrls?.getOrNull(safeIndex)
        if (url.isNullOrBlank() && novel != null) {
            val fresh = loadNovelsFromPrefs(appContext).firstOrNull { it.id == novel.id }
            if (fresh != null) { activeNovel.value = fresh; novel = fresh; url = fresh.chapterUrls.getOrNull(safeIndex) }
        }

        // b) if still missing and it's an online novel, fetch the chapter list, then retry
        if (url.isNullOrBlank() && novel != null && !novel.sourceUrl.isNullOrBlank()) {
            try {
                withContext(Dispatchers.IO) {
                    com.lorelight.service.NovelImportManager.checkForNewChapters(appContext, novel.id)
                }
                val fresh = loadNovelsFromPrefs(appContext).firstOrNull { it.id == novel.id }
                if (fresh != null) { activeNovel.value = fresh; url = fresh.chapterUrls.getOrNull(safeIndex) }
            } catch (e: Exception) { Log.e(TAG, "chapter refetch failed", e) }
        }

        if (!url.isNullOrBlank()) {
            val text = CrawlerEngine.getCachedChapterText(appContext, url)
                ?: withContext(Dispatchers.IO) { CrawlerEngine.extractChapterText(appContext, url!!) }
            val blocks = text.toReaderBlocks()
            updateSentences(blocks.ifEmpty { listOf(ReaderBlock.TextBlock("Chapter content is empty.")) })
            isFetchingChapter.value = false
            
            val sSize = sentences.value.size
            val targetPara = if (initialParagraphIndex == -1) {
                (sSize - 1).coerceAtLeast(0)
            } else {
                initialParagraphIndex.coerceIn(0, (sSize - 1).coerceAtLeast(0))
            }
            activeSentenceIndex.value = targetPara
            
            if (wasPlaying) { isPlaying.value = true; doStartSpeaking(interrupting = true) } else doPause(isTransient = false)
            saveProgress()
            recomputeCachedChapters()
        } else {
            // c) genuinely not ready: watch for it (auto-next) up to 5 min instead of dead-ending
            isFetchingChapter.value = false
            if (autoNextChapter.value && novel != null && !novel.sourceUrl.isNullOrBlank()) {
                updateSentences(listOf(ReaderBlock.TextBlock("Loading next chapter...")))
                startNextChapterWatch(novel.id, safeIndex, wasPlaying)
            } else {
                updateSentences(listOf(ReaderBlock.TextBlock("This chapter isn't available yet. Please try again.")))
                val targetPara = if (initialParagraphIndex == -1) 0 else initialParagraphIndex.coerceAtLeast(0)
                activeSentenceIndex.value = targetPara
                doPause(isTransient = false)
                saveProgress()
            }
        }
    }

    private fun startNextChapterWatch(novelId: String, targetIndex: Int, wasPlaying: Boolean) {
        nextChapterWatchJob?.cancel()
        nextChapterWatchJob = managerScope.launch {
            try {
                kotlinx.coroutines.withTimeout(5 * 60 * 1000L) {
                    while (true) {
                        withContext(Dispatchers.IO) { com.lorelight.service.NovelImportManager.checkForNewChapters(appContext, novelId) }
                        val fresh = loadNovelsFromPrefs(appContext).firstOrNull { it.id == novelId }
                        val u = fresh?.chapterUrls?.getOrNull(targetIndex)
                        if (fresh != null && !u.isNullOrBlank()) {
                            activeNovel.value = fresh
                            dispatch(TtsCommand.SelectChapter(targetIndex, 0, wasPlaying))
                            break
                        }
                        kotlinx.coroutines.delay(15_000L)
                    }
                }
            } catch (_: kotlinx.coroutines.TimeoutCancellationException) {
                isPlaying.value = false
            } catch (e: Exception) { Log.e(TAG, "chapter watch failed", e) }
            finally { nextChapterWatchJob = null }
        }
    }

    private suspend fun doApplyFetchedChapter(
        chapterIndex: Int,
        blocks: List<ReaderBlock>,
        initialParagraphIndex: Int,
        autoPlay: Boolean
    ) {
        if (activeChapterIndex.value == chapterIndex) {
            updateSentences(blocks.ifEmpty { listOf(ReaderBlock.TextBlock("Chapter content is empty or could not be loaded.")) })
            isFetchingChapter.value = false
            
            val sSize = sentences.value.size
            val targetPara = if (initialParagraphIndex == -1) {
                (sSize - 1).coerceAtLeast(0)
            } else {
                initialParagraphIndex.coerceIn(0, (sSize - 1).coerceAtLeast(0))
            }
            activeSentenceIndex.value = targetPara
            if (autoPlay) {
                isPlaying.value = true
                doStartSpeaking(interrupting = true)
            } else {
                doPause(isTransient = false)
            }
            saveProgress()
            recomputeCachedChapters()
            Log.d(TAG, "[ChapterTransition] End Fetch: index = $chapterIndex, sentences.size = ${sentences.value.size}")
        }
    }

    fun jumpToSentence(index: Int) {
        dispatch(TtsCommand.JumpToSentence(index))
    }

    private suspend fun doJumpToSentence(index: Int) {
        val sList = filteredSentences.value
        if (sList.isEmpty()) return
        val safe = index.coerceIn(0, sList.lastIndex)
        activeSentenceIndex.value = safe
        if (isPlaying.value) {
            doStartSpeaking(interrupting = true)
        }
    }

    fun togglePlayPause() {
        dispatch(TtsCommand.PlayPause)
    }

    fun startSpeaking() {
        dispatch(TtsCommand.Play)
    }

    private fun splitIntoSentences(text: String): List<String> {
        return text.split(sentenceSplitPattern).map { it.trim() }.filter { it.isNotBlank() }
    }

    private fun speakSentence(index: Int, interrupting: Boolean) {
        val engine = tts ?: return
        val sentenceText = currentParagraphSentences.getOrNull(index)
        if (sentenceText.isNullOrBlank()) {
            dispatch(TtsCommand.AutoAdvance)
            return
        }

        val utteranceId = "reader_utt_$index"
        val params = Bundle().apply { 
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, currentVolume)
        }

        val queueMode = if (interrupting) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        
        try {
            val result = engine.speak(sentenceText, queueMode, params, utteranceId)
            if (result == TextToSpeech.ERROR) {
                Log.e(TAG, "engine.speak returned ERROR code, attempting voice-agnostic fallback...")
                errorMessage.value = "TTS engine returned playback error. Attempting voice-agnostic fallback..."
                try {
                    engine.voice = engine.defaultVoice
                    lastAppliedVoiceName = null
                    val fallbackResult = engine.speak(sentenceText, queueMode, params, utteranceId)
                    if (fallbackResult == TextToSpeech.ERROR) {
                        errorMessage.value = "Playback failed. Please verify your selected voice and device speaker configuration."
                        isPlaying.value = false
                        CrashReporter.recordError(appContext, TAG, Exception("TTS speak call returned ERROR even with default voice"), "TTS_PLAYBACK_SPEAK_ERROR")
                    } else {
                        markProgress()
                        errorMessage.value = null
                    }
                } catch (ex: Exception) {
                    Log.e(TAG, "Voiced and default engine speak failed", ex)
                    errorMessage.value = "TTS fallback speak failed: ${ex.message ?: "Unknown error"}"
                    isPlaying.value = false
                    CrashReporter.recordError(appContext, TAG, ex, "TTS_PLAYBACK_SPEAK_ERROR")
                }
            } else {
                markProgress()
                errorMessage.value = null
            }
        } catch (e: java.lang.NullPointerException) {
            Log.e(TAG, "TTS native nullpointer exception on speak", e)
            errorMessage.value = "TTS engine crashed (NullPointerException). Please try restarting the app."
            isPlaying.value = false
            CrashReporter.recordError(appContext, TAG, e, "TTS_PLAYBACK_CRASH_NPE")
        } catch (e: Exception) {
            Log.e(TAG, "TTS speak failed", e)
            errorMessage.value = "TTS Playback Error: ${e.message ?: "Playback failed"}"
            isPlaying.value = false
            CrashReporter.recordError(appContext, TAG, e, "TTS_PLAYBACK_EXCEPTION")
        }
    }

    private suspend fun doStartSpeaking(interrupting: Boolean = false) {
        checkBatteryOptimizationOnPlay()
        if (!isTtsReady.value) return
        val sList = filteredSentences.value
        if (sList.isEmpty()) return
        if (isFetchingChapter.value) return

        if (!requestAudioFocus()) {
            Log.e(TAG, "Failed to get audio focus")
            return
        }

        val sIdx = activeSentenceIndex.value.coerceIn(0, sList.lastIndex)
        val block = sList.getOrNull(sIdx)
        if (block == null) {
            isPlaying.value = false
            return
        }

        if (block is ReaderBlock.ImageBlock) {
            var nextIdx = sIdx + 1
            while (nextIdx < sList.size && sList[nextIdx] is ReaderBlock.ImageBlock) {
                nextIdx++
            }
            if (nextIdx < sList.size) {
                activeSentenceIndex.value = nextIdx
                doStartSpeaking(interrupting = interrupting)
            } else {
                val nextChIdx = activeChapterIndex.value + 1
                if (nextChIdx <= maxPlayableIndex.value) {
                    doSelectChapter(nextChIdx, 0, true)
                } else {
                    isPlaying.value = false
                    activeSentenceIndex.value = 0
                    abandonAudioFocus()
                }
            }
            return
        }

        val speakingText = (block as ReaderBlock.TextBlock).text
        activeSentenceIndex.value = sIdx
        isPlaying.value = true

        val cleanedText = cleanSentenceForTts(speakingText)
        DiagnosticLogger.logProcessedText(speakingText)
        DiagnosticLogger.logEngineStatus("Attempting speak on sentence index=$sIdx. Rate=${speechRate.value}, Pitch=${speechPitch.value}, Voice=${selectedVoice.value?.name ?: "Default"}")

        val engine = tts ?: return
        
        if (interrupting) {
            tts?.stop()
            delay(150)
        } else {
            val speedFactor = speechRate.value.coerceAtLeast(0.25f)
            val prevWasParagraphEnd = sList.getOrNull(sIdx - 1)?.let { (it as? ReaderBlock.TextBlock)?.isParagraphEnd } ?: false
            val baseGap = if (prevWasParagraphEnd) paragraphPauseMs.value else nextSentencePauseMs.value
            val gap = computeGapMs(baseGap, speedFactor)
            if (gap > 0L) delay(gap)
        }

        try {
            if (lastAppliedRate != speechRate.value) {
                engine.setSpeechRate(speechRate.value)
                lastAppliedRate = speechRate.value
            }
            if (lastAppliedPitch != speechPitch.value) {
                engine.setPitch(speechPitch.value)
                lastAppliedPitch = speechPitch.value
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to apply speech variables", e)
        }
        
        try {
            selectedVoice.value?.let { v ->
                if (lastAppliedVoiceName != v.name) {
                    engine.voice = v
                    lastAppliedVoiceName = v.name
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to apply selected voice, continuing with default", e)
        }

        currentParagraphSentences = splitIntoSentences(cleanedText)
        currentSentenceIndexInParagraph = 0

        if (currentParagraphSentences.isEmpty()) {
            dispatch(TtsCommand.AutoAdvance)
            return
        }

        speakSentence(0, interrupting)
        saveProgress()
    }

    fun pauseForFocus() {
        dispatch(TtsCommand.PauseForFocus)
    }

    fun pauseSpeaking() {
        dispatch(TtsCommand.Pause)
    }

    private suspend fun doPause(isTransient: Boolean) {
        isPlaying.value = false
        tts?.stop()
        if (isTransient) {
            DiagnosticLogger.logEngineStatus("Temporary focus loss pause. Speech output stopped, keeping audio focus.")
        } else {
            DiagnosticLogger.logEngineStatus("User requested pause. Speech output stopped, audio focus abandoned.")
            abandonAudioFocus()
        }
        saveProgress()
        // FIX A1: wait for the write instead of firing and forgetting.
        flushProgressDurably()
    }

    fun stopSpeaking() {
        dispatch(TtsCommand.Stop)
    }

    private suspend fun doStop() {
        isPlaying.value = false
        tts?.stop()
        DiagnosticLogger.logEngineStatus("Speech execution stopped completely.")
        saveProgress()
        // FIX A1: the position must be on disk before we let go of the session.
        flushProgressDurably()
        abandonAudioFocus()
        if (!sessionActive.value) {
            activeNovel.value = null
        }
    }

    private suspend fun doAutoAdvance() {
        if (!isPlaying.value) return
        val sList = filteredSentences.value
        val currentSIdx = activeSentenceIndex.value

        if (currentSIdx < sList.lastIndex) {
            activeSentenceIndex.value = currentSIdx + 1
            doStartSpeaking(interrupting = false)
        } else {
            val nextChIdx = activeChapterIndex.value + 1
            if (nextChIdx <= maxPlayableIndex.value) {
                doSelectChapter(nextChIdx, 0, true)
            } else {
                isPlaying.value = false
                activeSentenceIndex.value = 0
                abandonAudioFocus()
            }
        }
    }

    fun skipForward() {
        dispatch(TtsCommand.NextSentence)
    }

    private suspend fun doSkipForward() {
        val currentSIdx = activeSentenceIndex.value
        val sList = filteredSentences.value
        var nextIdx = currentSIdx + 1
        while (nextIdx < sList.size && sList[nextIdx] is ReaderBlock.ImageBlock) {
            nextIdx++
        }
        if (nextIdx < sList.size) {
            activeSentenceIndex.value = nextIdx
            if (isPlaying.value) doStartSpeaking(interrupting = true)
        } else {
            val nextChIdx = activeChapterIndex.value + 1
            if (nextChIdx <= maxPlayableIndex.value) {
                doSelectChapter(nextChIdx)
                if (isPlaying.value) doStartSpeaking(interrupting = true)
            } else {
                withContext(Dispatchers.Main) {
                    Toast.makeText(appContext, "You're on the latest available chapter", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun skipBackward() {
        dispatch(TtsCommand.PrevSentence)
    }

    private suspend fun doSkipBackward() {
        val currentSIdx = activeSentenceIndex.value
        val sList = filteredSentences.value
        var prevIdx = currentSIdx - 1
        while (prevIdx >= 0 && sList[prevIdx] is ReaderBlock.ImageBlock) {
            prevIdx--
        }
        if (prevIdx >= 0) {
            activeSentenceIndex.value = prevIdx
            if (isPlaying.value) doStartSpeaking(interrupting = true)
        } else {
            val prevChIdx = activeChapterIndex.value - 1
            if (prevChIdx >= 0) {
                doSelectChapter(prevChIdx)
                val prevList = filteredSentences.value
                var lastTextIdx = prevList.lastIndex
                while (lastTextIdx >= 0 && prevList[lastTextIdx] is ReaderBlock.ImageBlock) {
                    lastTextIdx--
                }
                activeSentenceIndex.value = lastTextIdx.coerceAtLeast(0)
                if (isPlaying.value) doStartSpeaking(interrupting = true)
            }
        }
    }

    fun setSpeechRateAndApply(rate: Float) {
        speechRate.value = rate
        tts?.setSpeechRate(rate)
        DiagnosticLogger.logEngineStatus("Speech rate modified to: $rate x")
    }
    
    fun selectVoiceAndApply(voice: Voice) {
        selectedVoice.value = voice
        tts?.voice = voice
        DiagnosticLogger.logEngineStatus("Selected new engine voice: ${voice.name} (locale: ${voice.locale})")
        if (isPlaying.value) startSpeaking()
    }

    fun setSleepTimer(minutes: Int?) {
        sleepTimerMinutes.value = minutes
        sleepTimerJob?.cancel()
        if (minutes != null) {
            DiagnosticLogger.logEngineStatus("Sleep timer set to: $minutes minutes.")
            sleepTimerJob = managerScope.launch {
                var remaining = minutes
                while (remaining > 0) {
                    delay(60000)
                    remaining--
                    sleepTimerMinutes.value = remaining
                }
                DiagnosticLogger.logEngineStatus("Sleep timer expired. Automatically pausing playback.")
                pauseSpeaking()
                sleepTimerMinutes.value = null
            }
        } else {
            DiagnosticLogger.logEngineStatus("Sleep timer deactivated/cancelled.")
        }
    }

    fun loadRules() {
        val prefs = appContext.getSharedPreferences("reader_text_filters", Context.MODE_PRIVATE)
        val jsonStr = prefs.getString("rules", null)
        if (!jsonStr.isNullOrEmpty()) {
            try {
                val list = mutableListOf<FilterRule>()
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    try {
                        val obj = arr.getJSONObject(i)
                        val id = obj.optString("id", java.util.UUID.randomUUID().toString())
                        val original = obj.optString("original", "")
                        if (original.isBlank()) continue
                        val replacement = obj.optString("replacement", "")
                        val isVanish = obj.optBoolean("isVanish", true)
                        val scope = obj.optString("scope", "All Books")
                        val bookId = obj.optString("bookId", "")
                        val action = obj.optString("action", if (obj.optBoolean("isVanish", true)) TextFilter.ACTION_ERASE_TEXT else TextFilter.ACTION_REPLACE)
                        val strictMatch = obj.optBoolean("strictMatch", false)

                        list.add(
                            FilterRule(
                                id = id,
                                original = original,
                                replacement = replacement,
                                isVanish = isVanish,
                                scope = scope,
                                bookId = bookId,
                                action = action,
                                strictMatch = strictMatch
                            )
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                textFilterRules.value = list
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun saveRules(rules: List<FilterRule>) {
        textFilterRules.value = rules
        val prefs = appContext.getSharedPreferences("reader_text_filters", Context.MODE_PRIVATE)
        try {
            val arr = JSONArray()
            rules.forEach { rule ->
                val obj = JSONObject()
                obj.put("id", rule.id)
                obj.put("original", rule.original)
                obj.put("replacement", rule.replacement)
                obj.put("isVanish", rule.isVanish)
                obj.put("scope", rule.scope)
                obj.put("bookId", rule.bookId)
                obj.put("action", rule.action)
                obj.put("strictMatch", rule.strictMatch)
                arr.put(obj)
            }
            prefs.edit().putString("rules", arr.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Audio Focus listener implementation over AudioManager
    override fun onAudioFocusChange(focusChange: Int) {
        Log.d(TAG, "[AudioFocus] Focus change received: $focusChange")
        when (focusChange) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                Log.d(TAG, "[AudioFocus] AUDIOFOCUS_GAIN: restoring state. wasPlayingBeforeFocusLoss=$wasPlayingBeforeFocusLoss")
                // Undo any ducking and note that focus is ours again.
                currentVolume = 1.0f
                hasAudioFocus = true
                // FIX A6: only resume when we were actually the one paused by the
                // focus loss. The old `|| isPlaying.value` branch could re-enter
                // startSpeaking() while playback was already running, restarting
                // the current sentence from the beginning.
                if (wasPlayingBeforeFocusLoss) {
                    wasPlayingBeforeFocusLoss = false
                    startSpeaking()
                }
            }
            AudioManager.AUDIOFOCUS_LOSS -> {
                Log.d(TAG, "[AudioFocus] AUDIOFOCUS_LOSS: permanent loss, pausing and abandoning focus.")
                hasAudioFocus = false
                // Permanent loss must NOT arm an automatic resume: another app now
                // owns playback, and pauseSpeaking() abandons our focus request.
                wasPlayingBeforeFocusLoss = false
                if (isPlaying.value) {
                    pauseSpeaking()
                }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                Log.d(TAG, "[AudioFocus] AUDIOFOCUS_LOSS_TRANSIENT: transient loss, pausing but keeping focus.")
                // FIX A6: this used to call pauseSpeaking(), which ABANDONS audio
                // focus. Giving up the focus request on a *transient* loss means the
                // system never delivers AUDIOFOCUS_GAIN afterwards, so playback
                // stayed dead after a navigation prompt, a call or a short alert.
                // pauseForFocus() (which existed in the codebase with zero callers)
                // pauses the speech but keeps the focus request alive.
                if (isPlaying.value) {
                    wasPlayingBeforeFocusLoss = true
                    pauseForFocus()
                }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                Log.d(TAG, "[AudioFocus] AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK: ducking volume to 0.3f.")
                currentVolume = 0.3f
                // Keep playing, do not pause
            }
        }
    }

    private fun requestAudioFocus(): Boolean {
        if (hasAudioFocus) return true
        val am = audioManager ?: return false
        val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val playbackAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(playbackAttributes)
                .setAcceptsDelayedFocusGain(true)
                .setOnAudioFocusChangeListener(this)
                .build()
            audioFocusRequest = focusRequest
            am.requestAudioFocus(focusRequest) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                this,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            ) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        }
        if (granted) {
            hasAudioFocus = true
        }
        return granted
    }

    private fun abandonAudioFocus() {
        val am = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            am.abandonAudioFocus(this)
        }
        hasAudioFocus = false
    }

    private fun cleanSentenceForTts(text: String): String {
        if (text.isBlank()) return " "
        var s = text
        // Normalize unicode ellipsis and long dot runs to a real ellipsis (TTS pauses on it)
        s = s.replace("\u2026", "...")                 // … -> ...
        s = s.replace(Regex("\\.{3,}"), "...")          // "....." -> "..."
        s = s.replace(Regex("\\.\\.")  , "...")          // ".." -> "..."
        // Collapse long dash/underscore runs to a comma-pause instead of removing
        s = s.replace(Regex("[-\u2013\u2014]{2,}"), ", ")   // --, en/em dashes -> comma pause
        s = s.replace(Regex("_{2,}"), " ")
        s = s.replace(Regex("\\*{2,}"), " ")
        s = s.replace(Regex("={2,}"), " ")
        // Remove junk symbols that TTS spells out oddly, but KEEP . , ; : ? ! … ' " and -
        s = s.replace(Regex("[~`^|<>{}\\[\\]]+"), " ")
        s = s.replace(Regex("\\\\+"), " ")
        s = s.replace(Regex("(?<!\\w)/(?!\\w)"), " ")    // stray slashes only
        // Do NOT strip isolated . , ? ! ; : … — those create the pauses we want.
        // Collapse repeated spaces
        s = s.replace(Regex("[ \\t]{2,}"), " ")
        val trimmed = s.trim()
        // If literally nothing readable remains, return a single space
        return if (trimmed.none { it.isLetterOrDigit() }) " " else trimmed
    }
}

private data class NotificationState(
    val title: String,
    val author: String,
    val isPlaying: Boolean,
    val coverBase64: String?,
    val text: String,
    val chapterName: String
)
