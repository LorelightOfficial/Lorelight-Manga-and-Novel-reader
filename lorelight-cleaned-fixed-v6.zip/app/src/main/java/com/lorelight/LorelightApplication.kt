package com.lorelight

import android.app.ActivityManager
import android.app.Application
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi
import coil.ImageLoader
import coil.ImageLoaderFactory
import com.lorelight.manga.reader.MangaImageLoaderProvider
import com.lorelight.utils.MemoryManager
import eu.kanade.tachiyomi.data.cache.ChapterCache
import eu.kanade.tachiyomi.data.cache.CoverCache
import eu.kanade.tachiyomi.data.download.DownloadCache
import eu.kanade.tachiyomi.data.download.DownloadManager
import eu.kanade.tachiyomi.data.download.DownloadProvider
import eu.kanade.tachiyomi.di.MihonBackendAppModule
import eu.kanade.tachiyomi.di.MihonBackendDomainModule
import eu.kanade.tachiyomi.di.MihonBackendPreferenceModule
import eu.kanade.tachiyomi.extension.ExtensionManager
import eu.kanade.tachiyomi.network.NetworkHelper
import com.lorelight.manga.repo.MangaRepoToggles
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import mihon.domain.extension.interactor.AddExtensionStore
import mihon.domain.extension.interactor.GetExtensionStores
import tachiyomi.domain.source.service.SourceManager
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.InjektModule
import uy.kohesive.injekt.api.InjektRegistrar
import uy.kohesive.injekt.api.addSingleton
import uy.kohesive.injekt.api.addSingletonFactory
import uy.kohesive.injekt.api.get

/**
 * Application entry point.
 *
 * Hosts the lightweight memory monitor ([MemoryManager]) that frees heavy image
 * and EPUB allocations when the app is backgrounded or the system reports low
 * memory. Registered via android:name in AndroidManifest.xml.
 */
class LorelightApplication : Application(), ImageLoaderFactory {
    override fun newImageLoader(): ImageLoader = MangaImageLoaderProvider.getCoverImageLoader(this)

    override fun onCreate() {
        super.onCreate()
        com.lorelight.core.DevLogStore.append(this, "APP", "Lorelight started")

        // FIX B11 + C17: build the ONE shared OkHttp client before any
        // subsystem asks for it. This is also what finally installs
        // CloudflareInterceptor, which shipped in the app with zero callers.
        // AppPrefs.get() opens the canonical settings store once so the legacy
        // "lorelight_settings" keys are merged in a single, predictable place.
        com.lorelight.network.HttpClients.init(this)
        com.lorelight.data.local.AppPrefs.get(this)
        // The Injekt-built repository layer reads the per-repo on/off switches
        // and has no Context of its own, so hand it one before anything can ask.
        MangaRepoToggles.init(this)
        // Page lists are now written to disk, not just held in RAM. Without a
        // Context that store stays inert, so this must run before the reader
        // can be opened. It is what makes a downloaded chapter openable after
        // a restart, and with no network at all.
        com.lorelight.manga.reader.MangaPageListCache.init(this)
        // Page image files were never evicted by anything. Bound them once per
        // launch, off the main thread so a large cache cannot delay startup.
        Thread {
            com.lorelight.manga.reader.pruneMangaPageCache(this)
        }.apply { priority = Thread.MIN_PRIORITY }.start()
        // The Mihon extension manager registers its own install/uninstall broadcast
        // receiver automatically the first time it is created, so no manual
        // receiver registration is needed here anymore.

        Injekt.importModule(object : InjektModule {
            override fun InjektRegistrar.registerInjectables() {
                addSingleton<Application>(this@LorelightApplication)
                addSingletonFactory { NetworkHelper(this@LorelightApplication) }
                addSingletonFactory { Json { ignoreUnknownKeys = true; explicitNulls = false } }
            }
        })

        // Mihon-sourced manga backend (sources, downloads, images, library sync).
        // Registered verbatim from real Mihon's DI graph — see di/MihonBackend*Module.kt.
        Injekt.importModule(MihonBackendPreferenceModule(this))
        Injekt.importModule(MihonBackendAppModule(this))
        Injekt.importModule(MihonBackendDomainModule())

        // Eagerly resolve singletons sequentially on the calling thread before any background coroutines
        // can race for them. ChapterCache, CoverCache, DownloadProvider, DownloadManager, and DownloadCache
        // MUST be resolved before SourceManager (which spawns background coroutines accessing DownloadManager).
        try {
            Injekt.get<ChapterCache>()
            Injekt.get<CoverCache>()
            Injekt.get<DownloadProvider>()
            Injekt.get<DownloadManager>()
            Injekt.get<DownloadCache>()
            Injekt.get<SourceManager>()
            Injekt.get<ExtensionManager>()
        } catch (e: Throwable) {
            com.lorelight.core.DevLogStore.append(this, "DI", "Eager DI initialization failed: ${e.message}")
        }

        seedDefaultRepos()
        reportPreviousExit()
    }

    /**
     * Adds Keiyoushi as the default manga extension repository on first run.
     *
     * Runs at most once (guarded by a preference) and only when there are no
     * repositories at all, so it can never resurrect a repo somebody
     * deliberately removed. The protobuf index is tried first because that is
     * the compact format the backend prefers; if it cannot be fetched the JSON
     * index is tried instead, rather than leaving a new install staring at an
     * empty extension list. On total failure the seeded flag is left unset so
     * the next launch retries.
     */
    private fun seedDefaultRepos() {
        if (MangaRepoToggles.hasSeededDefaults(this)) return
        CoroutineScope(Dispatchers.IO).launch {
            try {
                if (Injekt.get<GetExtensionStores>().get().isNotEmpty()) {
                    // User already has repos - nothing to seed, and never again.
                    MangaRepoToggles.markDefaultsSeeded(this@LorelightApplication)
                    return@launch
                }

                val addStore = Injekt.get<AddExtensionStore>()
                var result = addStore(MangaRepoToggles.KEIYOUSHI_PB)
                if (result.isFailure) {
                    result = addStore(MangaRepoToggles.KEIYOUSHI_JSON)
                }

                result.onSuccess {
                    MangaRepoToggles.markDefaultsSeeded(this@LorelightApplication)
                    com.lorelight.core.DevLogStore.append(
                        this@LorelightApplication,
                        "REPO",
                        "Seeded default Keiyoushi repository"
                    )
                    runCatching { Injekt.get<ExtensionManager>().findAvailableExtensions() }
                }.onFailure { error ->
                    com.lorelight.core.DevLogStore.append(
                        this@LorelightApplication,
                        "REPO",
                        "Could not seed Keiyoushi repo, will retry next launch: ${error.message}"
                    )
                }
            } catch (e: Throwable) {
                com.lorelight.core.DevLogStore.append(
                    this@LorelightApplication,
                    "REPO",
                    "Repo seeding failed: ${e.message}"
                )
            }
        }
    }

    /**
     * Records why the *previous* process died.
     *
     * CrashReporter's uncaught-exception handler can only see failures that
     * travel up the JVM stack. It is structurally blind to the two most likely
     * ways this app disappears while scrolling manga: the low-memory killer
     * reclaiming the process, and a native abort inside an image decoder. In
     * both cases the process is simply gone - no Kotlin throwable is ever
     * thrown, so no handler runs, nothing is written to the crash file and
     * nothing reaches the dev log. That is exactly the "it crashes but nothing
     * is logged" symptom.
     *
     * The platform keeps a short history of process exits, so on the next
     * launch the real reason can be read back and written where the dev log
     * will show it. This does not prevent the death - it makes it visible, and
     * distinguishes "out of memory" from "native crash" from "ANR", which are
     * three completely different fixes.
     */
    private fun reportPreviousExit() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        try {
            reportPreviousExitApi30()
        } catch (e: Throwable) {
            // Diagnostics must never be the thing that breaks startup.
        }
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun reportPreviousExitApi30() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return
        val exits = am.getHistoricalProcessExitReasons(packageName, 0, 5)
        if (exits.isEmpty()) return

        val prefs = getSharedPreferences("lorelight_exit_reports", Context.MODE_PRIVATE)
        val lastSeen = prefs.getLong("last_seen_timestamp", 0L)
        var newest = lastSeen

        for (info in exits) {
            if (info.timestamp <= lastSeen) continue
            if (info.timestamp > newest) newest = info.timestamp

            // A clean shutdown is not worth a log line.
            if (info.reason == ApplicationExitInfo.REASON_EXIT_SELF ||
                info.reason == ApplicationExitInfo.REASON_USER_REQUESTED
            ) {
                continue
            }

            val reason = when (info.reason) {
                ApplicationExitInfo.REASON_LOW_MEMORY ->
                    "LOW_MEMORY - the system killed us to reclaim RAM"
                ApplicationExitInfo.REASON_CRASH ->
                    "CRASH - unhandled JVM exception"
                ApplicationExitInfo.REASON_CRASH_NATIVE ->
                    "CRASH_NATIVE - native abort, never reaches the Kotlin handler"
                ApplicationExitInfo.REASON_ANR ->
                    "ANR - main thread blocked"
                ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE ->
                    "EXCESSIVE_RESOURCE_USAGE"
                ApplicationExitInfo.REASON_SIGNALED ->
                    "SIGNALED - status ${info.status}"
                ApplicationExitInfo.REASON_DEPENDENCY_DIED ->
                    "DEPENDENCY_DIED"
                ApplicationExitInfo.REASON_INITIALIZATION_FAILURE ->
                    "INITIALIZATION_FAILURE"
                ApplicationExitInfo.REASON_PERMISSION_CHANGE ->
                    "PERMISSION_CHANGE"
                ApplicationExitInfo.REASON_OTHER ->
                    "OTHER"
                else -> "REASON_${info.reason}"
            }

            com.lorelight.core.DevLogStore.append(
                this,
                "PROCESS_EXIT",
                buildString {
                    append(reason)
                    append(" | importance=").append(info.importance)
                    append(" | pss=").append(info.pss / 1024L).append("MB")
                    append(" | rss=").append(info.rss / 1024L).append("MB")
                    info.description?.let { append(" | ").append(it) }
                }
            )
        }

        if (newest > lastSeen) {
            prefs.edit().putLong("last_seen_timestamp", newest).apply()
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        MemoryManager.onTrimMemory(this, level)
    }

    override fun onLowMemory() {
        super.onLowMemory()
        MemoryManager.releaseHeavyMemory(this)
    }
}
