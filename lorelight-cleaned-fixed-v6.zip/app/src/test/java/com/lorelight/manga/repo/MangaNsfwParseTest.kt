package com.lorelight.manga.repo

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class MangaNsfwParseTest {

    @Test
    fun testParseNsfwAndSafeExtensions() {
        val json = """
        {
          "extensionList": {
            "extensions": [
              {
                "name": "AHottie",
                "packageName": "eu.kanade.tachiyomi.extension.all.ahottie",
                "resources": {
                  "apkUrl": "https://cdn.jsdelivr.net/gh/yuzono/manga-repo@repo/apk/tachiyomi-all.ahottie-v1.6.4.apk",
                  "iconUrl": "https://cdn.jsdelivr.net/gh/yuzono/tachiyomi-extensions@master/src/all/ahottie/res/mipmap-xhdpi/ic_launcher.png",
                  "jarUrl": "https://raw.githubusercontent.com/yuzono/manga-repo/repo/jar/tachiyomi-all.ahottie-v1.6.4.jar"
                },
                "extensionLib": "1.6",
                "versionCode": "4",
                "versionName": "1.6.4",
                "contentWarning": "CONTENT_WARNING_NSFW",
                "sources": [
                  {
                    "id": "6289731484943315811",
                    "name": "AHottie",
                    "language": "all",
                    "homeUrl": "https://ahottie.top"
                  }
                ]
              },
              {
                "name": "Comic Growl",
                "packageName": "eu.kanade.tachiyomi.extension.all.comicgrowl",
                "resources": {
                  "apkUrl": "https://cdn.jsdelivr.net/gh/yuzono/manga-repo@repo/apk/tachiyomi-all.comicgrowl-v1.4.13.apk",
                  "iconUrl": "https://cdn.jsdelivr.net/gh/yuzono/tachiyomi-extensions@master/src/all/comicgrowl/res/mipmap-xhdpi/ic_launcher.png",
                  "jarUrl": "https://raw.githubusercontent.com/yuzono/manga-repo/repo/jar/tachiyomi-all.comicgrowl-v1.4.13.jar"
                },
                "extensionLib": "1.4",
                "versionCode": "13",
                "versionName": "1.4.13",
                "contentWarning": "CONTENT_WARNING_SAFE",
                "sources": [
                  {
                    "id": "299423548273637501",
                    "name": "Comic Growl",
                    "language": "all",
                    "homeUrl": "https://comic-growl.com"
                  }
                ]
              }
            ]
          }
        }
        """.trimIndent()

        val stats = ParseStats()
        val parsed = parseIndex(json, "https://raw.githubusercontent.com/yuzono/manga-repo/repo", stats)

        assertEquals(2, parsed.size)
        val ahottie = parsed.first { it.pkg == "eu.kanade.tachiyomi.extension.all.ahottie" }
        val comicGrowl = parsed.first { it.pkg == "eu.kanade.tachiyomi.extension.all.comicgrowl" }

        assertTrue(ahottie.nsfw)
        assertFalse(comicGrowl.nsfw)
        assertEquals(1, stats.nsfwCount)
        assertTrue(stats.summary().contains("nsfw=1"))
    }
}
