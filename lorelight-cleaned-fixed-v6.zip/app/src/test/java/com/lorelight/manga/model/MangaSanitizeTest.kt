package com.lorelight.manga.model

import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MangaSanitizeTest {

    @Test
    fun testSafeUrlAndSafeTitleOnUninitializedManga() {
        val manga = SManga.create()
        assertNull(manga.safeUrl())
        assertNull(manga.safeTitle())
    }

    @Test
    fun testSeedFromInitializesUrlAndTitle() {
        val manga = SManga.create()
        manga.seedFrom("/manga/123", "Test Title")
        assertEquals("/manga/123", manga.safeUrl())
        assertEquals("Test Title", manga.safeTitle())
    }

    @Test
    fun testSanitizedChaptersRemovesDuplicatesAndNulls() {
        val ch1 = SChapter.create().apply {
            url = "/ch1"
            name = "Chapter 1"
        }
        val ch2 = SChapter.create().apply {
            url = "/ch1" // Duplicate URL
            name = "Chapter 1 Dup"
        }
        val ch3 = SChapter.create().apply {
            url = "/ch2"
            // name left uninitialized
        }

        val chapters = listOf(ch1, ch2, ch3).sanitizedChapters()
        assertEquals(2, chapters.size)
        assertEquals("/ch1", chapters[0].safeUrl())
        assertEquals("Chapter 1", chapters[0].safeName())
        assertEquals("/ch2", chapters[1].safeUrl())
        assertEquals("Chapter", chapters[1].safeName())
    }

    @Test
    fun testSanitizedMangasRemovesDuplicatesAndEnsuresTitles() {
        val m1 = SManga.create().apply {
            url = "/m1"
            title = "Manga 1"
        }
        val m2 = SManga.create().apply {
            url = "/m1" // Duplicate
            title = "Manga 1 Dup"
        }
        val m3 = SManga.create().apply {
            url = "/m2"
            // title left uninitialized
        }

        val mangas = listOf(m1, m2, m3).sanitizedMangas()
        assertEquals(2, mangas.size)
        assertEquals("/m1", mangas[0].safeUrl())
        assertEquals("Manga 1", mangas[0].safeTitle())
        assertEquals("/m2", mangas[1].safeUrl())
        assertEquals("Unknown", mangas[1].safeTitle())
    }
}
