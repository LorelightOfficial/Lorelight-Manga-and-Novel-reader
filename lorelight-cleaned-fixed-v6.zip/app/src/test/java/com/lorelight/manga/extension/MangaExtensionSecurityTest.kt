package com.lorelight.manga.extension

import com.lorelight.manga.loader.MangaExtensionLoader
import org.junit.Assert.*
import org.junit.Test
import java.net.URI

class MangaExtensionSecurityTest {

    @Test
    fun `test resolveSourceClassNames with absolute and relative classes`() {
        val metadata = ".MangaDex;eu.kanade.tachiyomi.extension.all.mangadex.OtherSource;.Special"
        val pkg = "eu.kanade.tachiyomi.extension.all.mangadex"
        val resolved = MangaExtensionLoader.resolveSourceClassNames(metadata, pkg)

        assertEquals(3, resolved.size)
        assertEquals("eu.kanade.tachiyomi.extension.all.mangadex.MangaDex", resolved[0])
        assertEquals("eu.kanade.tachiyomi.extension.all.mangadex.OtherSource", resolved[1])
        assertEquals("eu.kanade.tachiyomi.extension.all.mangadex.Special", resolved[2])
    }

    @Test
    fun `test sanitizePkg rejects path traversal and invalid characters`() {
        assertNull(MangaExtensionManager.sanitizePkg(""))
        assertNull(MangaExtensionManager.sanitizePkg("../etc/passwd"))
        assertNull(MangaExtensionManager.sanitizePkg("eu.kanade..bad"))
        assertNull(MangaExtensionManager.sanitizePkg("eu.kanade.pkg;rm -rf /"))
        assertNull(MangaExtensionManager.sanitizePkg("eu.kanade.pkg?bad=true"))

        assertEquals("eu.kanade.tachiyomi.extension.en.mangadex", MangaExtensionManager.sanitizePkg("eu.kanade.tachiyomi.extension.en.mangadex"))
        assertEquals("com.lorelight.test_extension-v2", MangaExtensionManager.sanitizePkg("com.lorelight.test_extension-v2"))
    }

    @Test
    fun `test lib version bounds`() {
        assertTrue(1.2 >= MangaExtensionLoader.LIB_VERSION_MIN)
        assertTrue(1.5 <= MangaExtensionLoader.LIB_VERSION_MAX)
        assertTrue(1.6 <= MangaExtensionLoader.LIB_VERSION_MAX)
        assertFalse(1.1 >= MangaExtensionLoader.LIB_VERSION_MIN)
        assertFalse(1.7 <= MangaExtensionLoader.LIB_VERSION_MAX)
    }

    @Test
    fun `test blocked network addresses for security proxy`() {
        val blockedUrls = listOf(
            "http://127.0.0.1:8080/admin",
            "http://localhost:3000/secret",
            "https://localhost/api",
            "http://10.0.0.1/status",
            "http://192.168.1.1/router",
            "http://172.16.0.5:8000/meta",
            "http://172.31.255.254/internal",
            "file:///etc/hosts",
            "content://com.lorelight.provider/secret",
            "javascript:alert(1)"
        )

        for (url in blockedUrls) {
            val isSafe = isSafeUrl(url)
            assertFalse("URL $url should be blocked by security policy", isSafe)
        }

        val allowedUrls = listOf(
            "https://api.mangadex.org/v2/manga",
            "https://cdn.readdetectiveconan.com/cover.jpg",
            "http://example-manga.org/feed"
        )

        for (url in allowedUrls) {
            val isSafe = isSafeUrl(url)
            assertTrue("URL $url should be allowed", isSafe)
        }
    }

    private fun isSafeUrl(urlStr: String): Boolean {
        return try {
            val uri = URI(urlStr)
            val scheme = uri.scheme?.lowercase() ?: return false
            if (scheme != "http" && scheme != "https") return false
            val host = uri.host?.lowercase() ?: return false
            if (host == "localhost" || host == "127.0.0.1" || host == "::1" || host == "0.0.0.0") return false
            if (host.startsWith("10.") || host.startsWith("192.168.") || host.startsWith("169.254.")) return false
            if (host.matches(Regex("^172\\.(1[6-9]|2[0-9]|3[0-1])\\..*"))) return false
            true
        } catch (_: Exception) {
            false
        }
    }
}
