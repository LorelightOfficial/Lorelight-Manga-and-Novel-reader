package com.lorelight.manga

import eu.kanade.tachiyomi.network.interceptor.rateLimit
import eu.kanade.tachiyomi.network.interceptor.rateLimitHost
import eu.kanade.tachiyomi.source.model.Filter
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SChapterImpl
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.model.SMangaImpl
import eu.kanade.tachiyomi.source.online.HttpSource
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.concurrent.TimeUnit
import kotlin.coroutines.Continuation
import kotlin.time.Duration.Companion.seconds

class DexContractTest {

    private class TestSource : HttpSource() {
        override val name = "MangaDex"
        override val baseUrl = "https://mangadex.org"
        override val lang = "en"
        override val supportsLatest = true
    }

    private class TestGenre : Filter.CheckBox("Action")

    @Test
    fun testClassExistenceAndReflection() {
        val classNames = listOf(
            "eu.kanade.tachiyomi.AppInfo",
            "eu.kanade.tachiyomi.source.Source",
            "eu.kanade.tachiyomi.source.CatalogueSource",
            "eu.kanade.tachiyomi.source.ConfigurableSource",
            "eu.kanade.tachiyomi.source.SourceFactory",
            "eu.kanade.tachiyomi.source.UnmeteredSource",
            "eu.kanade.tachiyomi.source.online.HttpSource",
            "eu.kanade.tachiyomi.source.online.ParsedHttpSource",
            "eu.kanade.tachiyomi.source.online.ResolvableSource",
            "eu.kanade.tachiyomi.source.model.SManga",
            "eu.kanade.tachiyomi.source.model.SMangaImpl",
            "eu.kanade.tachiyomi.source.model.SChapter",
            "eu.kanade.tachiyomi.source.model.SChapterImpl",
            "eu.kanade.tachiyomi.source.model.SMangaUpdate",
            "eu.kanade.tachiyomi.source.model.Page",
            "eu.kanade.tachiyomi.source.model.Page\$State",
            "eu.kanade.tachiyomi.source.model.MangasPage",
            "eu.kanade.tachiyomi.source.model.FilterList",
            "eu.kanade.tachiyomi.source.model.UpdateStrategy",
            "eu.kanade.tachiyomi.source.model.Filter",
            "eu.kanade.tachiyomi.source.model.Filter\$Header",
            "eu.kanade.tachiyomi.source.model.Filter\$Separator",
            "eu.kanade.tachiyomi.source.model.Filter\$Select",
            "eu.kanade.tachiyomi.source.model.Filter\$Text",
            "eu.kanade.tachiyomi.source.model.Filter\$CheckBox",
            "eu.kanade.tachiyomi.source.model.Filter\$TriState",
            "eu.kanade.tachiyomi.source.model.Filter\$Group",
            "eu.kanade.tachiyomi.source.model.Filter\$Sort",
            "eu.kanade.tachiyomi.source.model.Filter\$Sort\$Selection",
            "eu.kanade.tachiyomi.network.NetworkHelper",
            "eu.kanade.tachiyomi.network.HttpException",
            "eu.kanade.tachiyomi.network.ProgressListener",
            "eu.kanade.tachiyomi.network.AndroidCookieJar",
            "eu.kanade.tachiyomi.network.interceptor.RateLimitInterceptor"
        )

        val failures = mutableListOf<String>()

        for (className in classNames) {
            try {
                Class.forName(className)
            } catch (e: ClassNotFoundException) {
                failures.add("Failed to load class: $className")
            }
        }

        if (failures.isNotEmpty()) {
            fail("Class loading failures:\n" + failures.joinToString("\n"))
        }

        // Assert explicitly that Filter$Checkbox (lowercase b) does NOT exist
        try {
            Class.forName("eu.kanade.tachiyomi.source.model.Filter\$Checkbox")
            fail("Filter\$Checkbox (lowercase b) should NOT exist")
        } catch (e: ClassNotFoundException) {
            // Expected
        }
    }

    @Test
    fun testHttpSourceMethodNamesAndSignatures() {
        val httpSourceClass = Class.forName("eu.kanade.tachiyomi.source.online.HttpSource")
        val declaredMethodNames = httpSourceClass.declaredMethods.map { it.name }.toSet()

        val expectedMethods = listOf(
            "getImageUrl",
            "imageUrlRequest",
            "imageRequest",
            "getImage",
            "getHomeUrl",
            "getMangaUrl",
            "getChapterUrl",
            "popularMangaRequest",
            "latestUpdatesRequest",
            "searchMangaRequest",
            "mangaDetailsRequest",
            "chapterListRequest",
            "pageListRequest"
        )

        val missingMethods = expectedMethods.filterNot { declaredMethodNames.contains(it) }
        if (missingMethods.isNotEmpty()) {
            fail("HttpSource is missing methods: " + missingMethods.joinToString(", "))
        }

        // getImageUrl is a suspend function — its last parameter type is Continuation
        val getImageUrlMethod = httpSourceClass.declaredMethods.first { it.name == "getImageUrl" }
        val parameterTypes = getImageUrlMethod.parameterTypes
        assertTrue(
            "getImageUrl should have at least one parameter (Continuation)",
            parameterTypes.isNotEmpty()
        )
        val lastParam = parameterTypes.last()
        assertTrue(
            "Last parameter of getImageUrl should be Continuation, but was ${lastParam.name}",
            Continuation::class.java.isAssignableFrom(lastParam)
        )
    }

    @Test
    fun testPageStateInterfaceAndNestedTypes() {
        val pageStateClass = Class.forName("eu.kanade.tachiyomi.source.model.Page\$State")
        assertTrue("Page.State must be an interface", pageStateClass.isInterface)
        assertFalse("Page.State must NOT be an enum", pageStateClass.isEnum)

        val nestedTypes = listOf("Queue", "LoadPage", "DownloadImage", "Ready", "Error")
        val failures = mutableListOf<String>()

        for (nested in nestedTypes) {
            try {
                Class.forName("eu.kanade.tachiyomi.source.model.Page\$State\$$nested")
            } catch (e: ClassNotFoundException) {
                failures.add("Failed to load Page.State nested type: $nested")
            }
        }

        if (failures.isNotEmpty()) {
            fail("Page.State nested type failures:\n" + failures.joinToString("\n"))
        }
    }

    @Test
    fun testModelFactories() {
        val manga = SManga.create()
        assertTrue("SManga.create() must return SMangaImpl instance", manga is SMangaImpl)

        val chapter = SChapter.create()
        assertTrue("SChapter.create() must return SChapterImpl instance", chapter is SChapterImpl)
    }

    @Test
    fun testGoldenSourceId() {
        val testSource = TestSource()
        assertEquals(2499283573021220255L, testSource.id)
    }

    @Suppress("unused")
    private fun compileTimeRateLimitCallShapes() {
        val url = "https://a.com".toHttpUrl()
        OkHttpClient.Builder().rateLimit(3)
        OkHttpClient.Builder().rateLimit(3, 2.seconds)
        OkHttpClient.Builder().rateLimit(3, 2, TimeUnit.SECONDS)
        OkHttpClient.Builder().rateLimitHost("https://a.com".toHttpUrl(), 3)
        OkHttpClient.Builder().rateLimitHost("https://a.com".toHttpUrl(), 3, 2.seconds)
        OkHttpClient.Builder().rateLimitHost("https://a.com", 3, 2.seconds)

        val genre = TestGenre()
    }
}
