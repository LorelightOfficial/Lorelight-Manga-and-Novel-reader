package com.lorelight.manga

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.IntSize
import com.lorelight.manga.reader.MangaBackground
import com.lorelight.manga.reader.MangaNavRegion
import com.lorelight.manga.reader.MangaReaderPrefs
import com.lorelight.manga.reader.MangaReadingMode
import com.lorelight.manga.reader.MangaTapInvert
import com.lorelight.manga.reader.MangaTapZoneLayout
import com.lorelight.manga.reader.calculateDoubleTapTargetOffset
import com.lorelight.manga.reader.clampOffset
import com.lorelight.manga.reader.clampPanOffset
import com.lorelight.manga.reader.focalAnchoredOffset
import com.lorelight.manga.reader.pagerIndexToTruePage
import com.lorelight.manga.reader.tapZoneFor
import com.lorelight.manga.reader.truePageToPagerIndex
import com.lorelight.manga.reader.nextImageScroll
import com.lorelight.manga.reader.webtoonContainerHeightPx
import com.lorelight.manga.reader.LoadedChapter
import com.lorelight.manga.reader.MangaFeedItem
import com.lorelight.manga.reader.buildFeedItems
import com.lorelight.manga.reader.feedItemKey
import com.lorelight.manga.reader.MangaWindow
import com.lorelight.manga.reader.PageQueueItem
import com.lorelight.manga.reader.VisibleSpan
import com.lorelight.manga.reader.canDropChapter
import com.lorelight.manga.reader.computeBackoffMs
import com.lorelight.manga.reader.computeWindow
import com.lorelight.manga.reader.lastEndVisibleIndex
import com.lorelight.manga.reader.shouldPreloadNext
import com.lorelight.manga.reader.computeRemainingDown
import com.lorelight.manga.reader.computeRemainingUp
import com.lorelight.manga.reader.computeInitialFeedIndex
import com.lorelight.manga.reader.MangaChapter
import com.lorelight.manga.reader.MangaChapterState
import eu.kanade.tachiyomi.source.model.Page
import com.lorelight.data.model.Novel
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

@RunWith(RobolectricTestRunner::class)
class MangaReaderTest {

    @Test
    fun testRtlIndexMapping() {
        val totalPages = 10
        // Given N = 10 pages:
        // true page 0 (Page 1) should map to pager index 9
        assertEquals(9, truePageToPagerIndex(0, totalPages))
        assertEquals(0, pagerIndexToTruePage(9, totalPages))

        // true page 9 (Page 10) should map to pager index 0
        assertEquals(0, truePageToPagerIndex(9, totalPages))
        assertEquals(9, pagerIndexToTruePage(0, totalPages))

        // true page 4 should map to pager index 5
        assertEquals(5, truePageToPagerIndex(4, totalPages))
        assertEquals(4, pagerIndexToTruePage(5, totalPages))
    }

    @Test
    fun testEnumFallbackOnCorruptValues() {
        val invalidMode = MangaReaderPrefs.parseEnum<MangaReadingMode>("INVALID_ENUM_STRING", MangaReadingMode.LONG_STRIP)
        assertEquals(MangaReadingMode.LONG_STRIP, invalidMode)

        val invalidBg = MangaReaderPrefs.parseEnum<MangaBackground>("CORRUPT_BG", MangaBackground.BLACK)
        assertEquals(MangaBackground.BLACK, invalidBg)

        val validMode = MangaReaderPrefs.parseEnum<MangaReadingMode>("PAGED_RTL", MangaReadingMode.LONG_STRIP)
        assertEquals(MangaReadingMode.PAGED_RTL, validMode)
    }

    @Test
    fun testReadingModeEnumValues() {
        assertEquals(4, MangaReadingMode.entries.size)
        assertEquals(MangaReadingMode.LONG_STRIP, MangaReadingMode.valueOf("LONG_STRIP"))
        assertEquals(MangaReadingMode.PAGED_LTR, MangaReadingMode.valueOf("PAGED_LTR"))
        assertEquals(MangaReadingMode.PAGED_RTL, MangaReadingMode.valueOf("PAGED_RTL"))
        assertEquals(MangaReadingMode.PAGED_VERTICAL, MangaReadingMode.valueOf("PAGED_VERTICAL"))
    }

    @Test
    fun testBackgroundEnumValues() {
        assertEquals(3, MangaBackground.entries.size)
        assertEquals(MangaBackground.BLACK, MangaBackground.valueOf("BLACK"))
        assertEquals(MangaBackground.WHITE, MangaBackground.valueOf("WHITE"))
        assertEquals(MangaBackground.GRAY, MangaBackground.valueOf("GRAY"))
    }

    @Test
    fun testPanClampingScaleLessThanOne() {
        val size = Size(1000f, 2000f)
        val inputOffset = Offset(100f, -200f)
        val clamped = clampPanOffset(inputOffset, scale = 0.8f, size = size)
        assertEquals(Offset.Zero, clamped)
    }

    @Test
    fun testPanClampingScaleTwoCoercion() {
        val size = Size(1000f, 2000f)
        val scale = 2.0f

        val excessiveOffset = Offset(800f, -1500f)
        val clamped = clampPanOffset(excessiveOffset, scale = scale, size = size)
        assertEquals(500f, clamped.x, 0.001f)
        assertEquals(-1000f, clamped.y, 0.001f)
    }

    @Test
    fun testDoubleTapExactCenterYieldsZeroOffset() {
        val size = Size(1000f, 2000f)
        val centerTap = Offset(size.width / 2f, size.height / 2f)
        val targetOffset = calculateDoubleTapTargetOffset(centerTap, size, targetScale = 2.0f)
        assertEquals(0f, targetOffset.x, 0.001f)
        assertEquals(0f, targetOffset.y, 0.001f)
    }

    @Test
    fun testRtlIndexMappingRoundTrip() {
        val totalPages = 15
        for (truePage in 0 until totalPages) {
            val pagerIdx = truePageToPagerIndex(truePage, totalPages)
            val roundTrip = pagerIndexToTruePage(pagerIdx, totalPages)
            assertEquals(truePage, roundTrip)
        }
    }

    @Test
    fun webtoonContainerHeightPx_at1x_returnsViewportHeight() {
        assertEquals(2400, webtoonContainerHeightPx(2400, 1f))
    }

    @Test
    fun webtoonContainerHeightPx_atZoomedOut_returnsExpandedHeight() {
        assertEquals(4800, webtoonContainerHeightPx(2400, 0.5f))
    }

    @Test
    fun webtoonContainerHeightPx_atZoomedIn_returnsViewportHeight() {
        assertEquals(2400, webtoonContainerHeightPx(2400, 2.5f))
    }

    @Test
    fun clampOffset_atOrBelow1x_returnsZero() {
        assertEquals(Offset.Zero, clampOffset(Offset(100f, 200f), 1080, 2400, 1.0f))
        assertEquals(Offset.Zero, clampOffset(Offset(100f, 200f), 1080, 2400, 0.5f))
    }

    @Test
    fun clampOffset_at2x_clampsToHalfDimensions() {
        val clamped = clampOffset(Offset(800f, -1500f), 1000, 2000, 2.0f)
        assertEquals(500f, clamped.x, 0.001f)
        assertEquals(-1000f, clamped.y, 0.001f)
    }

    @Test
    fun focalAnchoredOffset_keepsFocalPointInvariant() {
        val centroidFromCenter = Offset(100f, 0f)
        val currentOffset = Offset.Zero
        val oldScale = 1.0f
        val newScale = 2.0f

        val calculatedOffset = focalAnchoredOffset(centroidFromCenter, currentOffset, oldScale, newScale)

        // Initial focal point position on screen relative to center
        val initialScreenPos = centroidFromCenter.x * oldScale + currentOffset.x
        // New focal point position on screen relative to center with calculatedOffset
        val newScreenPos = centroidFromCenter.x * newScale + calculatedOffset.x

        assertEquals(initialScreenPos, newScreenPos, 0.01f)
    }

    @Test
    fun tapZoneFor_EDGE_LAYOUT_left30Percent_returnsPREV() {
        val vp = IntSize(1000, 2000)
        val action = tapZoneFor(Offset(150f, 1000f), vp, MangaTapZoneLayout.EDGE, MangaTapInvert.NONE)
        assertEquals(MangaNavRegion.NEXT, action)
    }

    @Test
    fun tapZoneFor_EDGE_LAYOUT_right30Percent_returnsNEXT() {
        val vp = IntSize(1000, 2000)
        val action = tapZoneFor(Offset(850f, 1000f), vp, MangaTapZoneLayout.EDGE, MangaTapInvert.NONE)
        assertEquals(MangaNavRegion.NEXT, action)
    }

    @Test
    fun tapZoneFor_EDGE_LAYOUT_centerRegion_returnsPREV() {
        val vp = IntSize(1000, 2000)
        val action = tapZoneFor(Offset(500f, 1500f), vp, MangaTapZoneLayout.EDGE, MangaTapInvert.NONE)
        assertEquals(MangaNavRegion.PREV, action)
    }

    @Test
    fun tapZoneFor_L_SHAPE_topStrip_returnsPREV() {
        val vp = IntSize(1000, 2000)
        val action = tapZoneFor(Offset(500f, 200f), vp, MangaTapZoneLayout.L_SHAPE, MangaTapInvert.NONE)
        assertEquals(MangaNavRegion.PREV, action)
    }

    @Test
    fun tapZoneFor_L_SHAPE_leftStrip_returnsPREV() {
        val vp = IntSize(1000, 2000)
        val action = tapZoneFor(Offset(100f, 1000f), vp, MangaTapZoneLayout.L_SHAPE, MangaTapInvert.NONE)
        assertEquals(MangaNavRegion.PREV, action)
    }

    @Test
    fun tapZoneFor_KINDLE_topZone_returnsPREV() {
        val vp = IntSize(1000, 2000)
        val action = tapZoneFor(Offset(100f, 1000f), vp, MangaTapZoneLayout.KINDLISH, MangaTapInvert.NONE)
        assertEquals(MangaNavRegion.PREV, action)
    }

    @Test
    fun tapZoneFor_KINDLE_bottomZone_returnsNEXT() {
        val vp = IntSize(1000, 2000)
        val action = tapZoneFor(Offset(500f, 1000f), vp, MangaTapZoneLayout.KINDLISH, MangaTapInvert.NONE)
        assertEquals(MangaNavRegion.NEXT, action)
    }

    // --- PART F TESTS ---
    @Test
    fun partF_1_webtoonContainerHeightPx_1x() {
        assertEquals(2000, webtoonContainerHeightPx(2000, 1f))
    }

    @Test
    fun partF_2_webtoonContainerHeightPx_0_5x() {
        assertEquals(4000, webtoonContainerHeightPx(2000, 0.5f))
    }

    @Test
    fun partF_3_webtoonContainerHeightPx_2x() {
        assertEquals(2000, webtoonContainerHeightPx(2000, 2f))
    }

    @Test
    fun partF_4_clampOffset_scaleSubOne() {
        assertEquals(Offset.Zero, clampOffset(Offset(100f, 200f), 1000, 2000, 0.8f))
        assertEquals(Offset.Zero, clampOffset(Offset(-50f, 80f), 1000, 2000, 1.0f))
    }

    @Test
    fun partF_5_clampOffset_scale2x() {
        val clamped = clampOffset(Offset(800f, -1500f), 1000, 2000, 2.0f)
        assertEquals(500f, clamped.x, 0.001f)
        assertEquals(-1000f, clamped.y, 0.001f)
    }

    @Test
    fun partF_6_focalAnchoredOffset_keepsFocalPointInvariant() {
        val centroidFromCenter = Offset(100f, 0f)
        val currentOffset = Offset.Zero
        val oldScale = 1.0f
        val newScale = 2.0f
        val calculatedOffset = focalAnchoredOffset(centroidFromCenter, currentOffset, oldScale, newScale)
        val initialScreenPos = centroidFromCenter.x * oldScale + currentOffset.x
        val newScreenPos = centroidFromCenter.x * newScale + calculatedOffset.x
        assertEquals(initialScreenPos, newScreenPos, 0.01f)
    }

    @Test
    fun partF_7_tapZoneFor_L_SHAPE_top_PREV() {
        assertEquals(MangaNavRegion.PREV, tapZoneFor(0.5f, 0.10f, MangaTapZoneLayout.L_SHAPE, MangaTapInvert.NONE))
    }

    @Test
    fun partF_8_tapZoneFor_L_SHAPE_bottom_NEXT() {
        assertEquals(MangaNavRegion.NEXT, tapZoneFor(0.5f, 0.90f, MangaTapZoneLayout.L_SHAPE, MangaTapInvert.NONE))
    }

    @Test
    fun partF_9_tapZoneFor_L_SHAPE_center_MENU() {
        assertEquals(MangaNavRegion.MENU, tapZoneFor(0.5f, 0.50f, MangaTapZoneLayout.L_SHAPE, MangaTapInvert.NONE))
    }

    @Test
    fun partF_10_tapZoneFor_RIGHT_AND_LEFT_left_LEFT() {
        assertEquals(MangaNavRegion.LEFT, tapZoneFor(0.1f, 0.5f, MangaTapZoneLayout.RIGHT_AND_LEFT, MangaTapInvert.NONE))
    }

    @Test
    fun partF_11_tapZoneFor_RIGHT_AND_LEFT_right_RIGHT() {
        assertEquals(MangaNavRegion.RIGHT, tapZoneFor(0.9f, 0.5f, MangaTapZoneLayout.RIGHT_AND_LEFT, MangaTapInvert.NONE))
    }

    @Test
    fun partF_12_tapZoneFor_RIGHT_AND_LEFT_horizontalInvert_RIGHT() {
        assertEquals(MangaNavRegion.RIGHT, tapZoneFor(0.1f, 0.5f, MangaTapZoneLayout.RIGHT_AND_LEFT, MangaTapInvert.HORIZONTAL))
    }

    @Test
    fun partF_13_tapZoneFor_DISABLED_topStrip_MENU() {
        assertEquals(MangaNavRegion.MENU, tapZoneFor(0.5f, 0.02f, MangaTapZoneLayout.DISABLED, MangaTapInvert.NONE))
    }

    @Test
    fun partF_14_tapZoneFor_DISABLED_center_MENU() {
        assertEquals(MangaNavRegion.MENU, tapZoneFor(0.5f, 0.5f, MangaTapZoneLayout.DISABLED, MangaTapInvert.NONE))
    }

    // PART H TESTS
    @Test
    fun partH_1_webtoonContainerHeightPx_scale1() {
        assertEquals(2000, webtoonContainerHeightPx(2000, 1f))
    }

    @Test
    fun partH_2_webtoonContainerHeightPx_scaleHalf() {
        assertEquals(4000, webtoonContainerHeightPx(2000, 0.5f))
    }

    @Test
    fun partH_3_webtoonContainerHeightPx_scale2() {
        assertEquals(2000, webtoonContainerHeightPx(2000, 2f))
    }

    @Test
    fun partH_4_clampOffset_returnsZero_whenScaleSubOne() {
        assertEquals(Offset.Zero, clampOffset(Offset(100f, 200f), 1000, 2000, 0.5f))
        assertEquals(Offset.Zero, clampOffset(Offset(100f, 200f), 1000, 2000, 1.0f))
    }

    @Test
    fun partH_5_clampOffset_atScale2_clampsXTo500() {
        val clampedPos = clampOffset(Offset(800f, 0f), 1000, 2000, 2.0f)
        assertEquals(500f, clampedPos.x, 0.01f)
        val clampedNeg = clampOffset(Offset(-800f, 0f), 1000, 2000, 2.0f)
        assertEquals(-500f, clampedNeg.x, 0.01f)
    }

    @Test
    fun partH_6_focalAnchoredOffset_keepsFocalPointInvariant() {
        val centroid = Offset(100f, 0f)
        val initialOffset = Offset.Zero
        val newOffset = focalAnchoredOffset(
            centroidFromCenter = centroid,
            currentOffset = initialOffset,
            oldScale = 1f,
            newScale = 2f
        )
        val focalScreenBefore = centroid
        val focalScreenAfter = centroid * 2f + newOffset
        assertEquals(focalScreenBefore.x, focalScreenAfter.x, 0.01f)
        assertEquals(focalScreenBefore.y, focalScreenAfter.y, 0.01f)
    }

    @Test
    fun partH_7_buildFeedItems_singleChapter() {
        val curr = LoadedChapter("ch1", 0, "Chapter 1", listOf(Page(0, "url1", "img1")))
        val items = buildFeedItems(prev = null, curr = curr, next = null, forceTransition = false)
        assertEquals(3, items.size)
        assertTrue(items[0] is MangaFeedItem.Transition && (items[0] as MangaFeedItem.Transition).toChapterName == null)
        assertTrue(items[1] is MangaFeedItem.Page)
        assertTrue(items[2] is MangaFeedItem.Transition && (items[2] as MangaFeedItem.Transition).toChapterName == null)
    }

    @Test
    fun partH_8_buildFeedItems_threeChapters_noForceTransition() {
        val prev = LoadedChapter("ch0", 0, "Chapter 0", listOf(Page(0, "url0", "img0")))
        val curr = LoadedChapter("ch1", 1, "Chapter 1", listOf(Page(0, "url1", "img1")))
        val next = LoadedChapter("ch2", 2, "Chapter 2", listOf(Page(0, "url2", "img2")))
        val items = buildFeedItems(prev = prev, curr = curr, next = next, forceTransition = false)
        assertEquals(3, items.size)
        assertTrue(items.all { it is MangaFeedItem.Page })
    }

    @Test
    fun partH_9_buildFeedItems_threeChapters_forceTransition() {
        val prev = LoadedChapter("ch0", 0, "Chapter 0", listOf(Page(0, "url0", "img0")))
        val curr = LoadedChapter("ch1", 1, "Chapter 1", listOf(Page(0, "url1", "img1")))
        val next = LoadedChapter("ch2", 2, "Chapter 2", listOf(Page(0, "url2", "img2")))
        val items = buildFeedItems(prev = prev, curr = curr, next = next, forceTransition = true)
        assertEquals(5, items.size)
        assertTrue(items[0] is MangaFeedItem.Page)
        assertTrue(items[1] is MangaFeedItem.Transition)
        assertTrue(items[2] is MangaFeedItem.Page)
        assertTrue(items[3] is MangaFeedItem.Transition)
        assertTrue(items[4] is MangaFeedItem.Page)
    }

    @Test
    fun partH_10_feedItemsOrder_isAlwaysPrevPrevCurrNextNext() {
        val prev = LoadedChapter("ch0", 0, "Chapter 0", listOf(Page(0, "url0", "img0")))
        val curr = LoadedChapter("ch1", 1, "Chapter 1", listOf(Page(0, "url1", "img1")))
        val next = LoadedChapter("ch2", 2, "Chapter 2", listOf(Page(0, "url2", "img2")))
        val items = buildFeedItems(prev = prev, curr = curr, next = next, forceTransition = true)
        val pPage = items[0] as MangaFeedItem.Page
        val pTrans = items[1] as MangaFeedItem.Transition
        val cPage = items[2] as MangaFeedItem.Page
        val nTrans = items[3] as MangaFeedItem.Transition
        val nPage = items[4] as MangaFeedItem.Page

        assertEquals("ch0", pPage.chapterId)
        assertEquals(MangaFeedItem.Transition.Kind.PREV, pTrans.kind)
        assertEquals("ch1", cPage.chapterId)
        assertEquals(MangaFeedItem.Transition.Kind.NEXT, nTrans.kind)
        assertEquals("ch2", nPage.chapterId)
    }

    @Test
    fun partH_11_feedItemKey_uniquenessWithDuplicateImageUrls() {
        val identicalUrl = "https://example.com/same.jpg"
        val chA = LoadedChapter("chA", 0, "Chapter A", listOf(Page(0, identicalUrl, identicalUrl)))
        val chB = LoadedChapter("chB", 1, "Chapter B", listOf(Page(0, identicalUrl, identicalUrl)))
        val items = buildFeedItems(prev = chA, curr = chB, next = null, forceTransition = true)
        val keys = items.map(::feedItemKey)
        assertEquals(keys.toSet().size, items.size)
    }

    @Test
    fun partH_12_tapZoneFor_L_SHAPE_top_PREV() {
        assertEquals(MangaNavRegion.PREV, tapZoneFor(0.5f, 0.10f, MangaTapZoneLayout.L_SHAPE, MangaTapInvert.NONE))
    }

    @Test
    fun partH_13_tapZoneFor_L_SHAPE_bottom_NEXT() {
        assertEquals(MangaNavRegion.NEXT, tapZoneFor(0.5f, 0.90f, MangaTapZoneLayout.L_SHAPE, MangaTapInvert.NONE))
    }

    @Test
    fun partH_14_tapZoneFor_L_SHAPE_center_MENU() {
        assertEquals(MangaNavRegion.MENU, tapZoneFor(0.5f, 0.50f, MangaTapZoneLayout.L_SHAPE, MangaTapInvert.NONE))
    }

    @Test
    fun partH_15_tapZoneFor_RIGHT_AND_LEFT_left_LEFT() {
        assertEquals(MangaNavRegion.LEFT, tapZoneFor(0.1f, 0.5f, MangaTapZoneLayout.RIGHT_AND_LEFT, MangaTapInvert.NONE))
    }

    @Test
    fun partH_16_tapZoneFor_RIGHT_AND_LEFT_right_RIGHT() {
        assertEquals(MangaNavRegion.RIGHT, tapZoneFor(0.9f, 0.5f, MangaTapZoneLayout.RIGHT_AND_LEFT, MangaTapInvert.NONE))
    }

    @Test
    fun partH_17_tapZoneFor_RIGHT_AND_LEFT_horizontalInvert_RIGHT() {
        assertEquals(MangaNavRegion.RIGHT, tapZoneFor(0.1f, 0.5f, MangaTapZoneLayout.RIGHT_AND_LEFT, MangaTapInvert.HORIZONTAL))
    }

    @Test
    fun partH_18_tapZoneFor_DISABLED_topStrip_MENU() {
        assertEquals(MangaNavRegion.MENU, tapZoneFor(0.5f, 0.02f, MangaTapZoneLayout.DISABLED, MangaTapInvert.NONE))
    }

    @Test
    fun partH_19_tapZoneFor_DISABLED_center_MENU() {
        assertEquals(MangaNavRegion.MENU, tapZoneFor(0.5f, 0.50f, MangaTapZoneLayout.DISABLED, MangaTapInvert.NONE))
    }

    // PART 9 / SECTION 9 TESTS
    @Test
    fun testWindow_1_firstChapter() {
        assertEquals(MangaWindow(null, null, 0, 1, 2), computeWindow(10, 0))
    }

    @Test
    fun testWindow_2_lastChapter() {
        assertEquals(MangaWindow(7, 8, 9, null, null), computeWindow(10, 9))
    }

    @Test
    fun testWindow_3_middleChapter() {
        assertEquals(MangaWindow(3, 4, 5, 6, 7), computeWindow(10, 5))
    }

    @Test
    fun testWindow_4_singleChapter() {
        assertEquals(MangaWindow(null, null, 0, null, null), computeWindow(1, 0))
    }

    @Test
    fun testWindow_5_outOfBoundsCoerces() {
        assertEquals(MangaWindow(7, 8, 9, null, null), computeWindow(10, 99))
    }

    @Test
    fun testWindow_6_canDropChapter_falseWhenVisible() {
        assertEquals(false, canDropChapter("A", setOf("A", "B")))
    }

    @Test
    fun testWindow_7_canDropChapter_trueWhenNotVisible() {
        assertEquals(true, canDropChapter("A", setOf("B", "C")))
    }

    @Test
    fun testActiveItem_8_threeItemsViewport() {
        val spans = listOf(
            VisibleSpan(0, 0, 100),
            VisibleSpan(1, 100, 100),
            VisibleSpan(2, 200, 100)
        )
        assertEquals(2, lastEndVisibleIndex(spans, 0, 300))
    }

    @Test
    fun testActiveItem_9_tallItem() {
        val spans = listOf(
            VisibleSpan(0, -400, 1000)
        )
        assertEquals(0, lastEndVisibleIndex(spans, 0, 300))
    }

    @Test
    fun testActiveItem_10_emptyList() {
        assertEquals(-1, lastEndVisibleIndex(emptyList(), 0, 300))
    }

    @Test
    fun testActiveItem_11_itemBelowViewport() {
        val spans = listOf(
            VisibleSpan(0, 400, 100)
        )
        assertEquals(-1, lastEndVisibleIndex(spans, 0, 300))
    }

    @Test
    fun testPreloadBoundary_12_falseAt14Of20() {
        assertEquals(false, shouldPreloadNext(pageIndex = 14, pageCount = 20))
    }

    @Test
    fun testPreloadBoundary_13_trueAt16Of20() {
        assertEquals(true, shouldPreloadNext(pageIndex = 16, pageCount = 20))
    }

    @Test
    fun testPreloadBoundary_14_trueAt19Of20() {
        assertEquals(true, shouldPreloadNext(pageIndex = 19, pageCount = 20))
    }

    @Test
    fun testQueuePriority_15_sortOrder() {
        val item1 = PageQueueItem(PageQueueItem.PRIORITY_RETRY, 1L, Page(0), 1L)
        val item2 = PageQueueItem(PageQueueItem.PRIORITY_DEFAULT, 2L, Page(0), 1L)
        val item3 = PageQueueItem(PageQueueItem.PRIORITY_ADJACENT, 3L, Page(0), 1L)
        
        val list = listOf(item3, item2, item1).sorted()
        assertEquals(listOf(item1, item2, item3), list)
    }

    @Test
    fun testQueuePriority_16_equalPriorityFIFO() {
        val itemA = PageQueueItem(PageQueueItem.PRIORITY_DEFAULT, 1L, Page(0), 1L)
        val itemB = PageQueueItem(PageQueueItem.PRIORITY_DEFAULT, 2L, Page(0), 1L)
        
        val list = listOf(itemB, itemA).sorted()
        assertEquals(listOf(itemA, itemB), list)
    }

    @Test
    fun testBackoff_17_strictlyIncreasing() {
        val b1 = computeBackoffMs(1)
        val b2 = computeBackoffMs(2)
        val b3 = computeBackoffMs(3)
        assertTrue(b1 < b2)
        assertTrue(b2 < b3)
    }

    @Test
    fun testBackoff_18_cappedAt30s() {
        assertEquals(30000L, computeBackoffMs(100))
    }

    @Test
    fun testKeys_19_duplicateImageUrlsKeyUniqueness() {
        val sameUrl = "https://example.com/same.jpg"
        val page1 = MangaFeedItem.Page("chA", 0, 0, 1, sameUrl)
        val page2 = MangaFeedItem.Page("chB", 1, 0, 1, sameUrl)
        val items = listOf(page1, page2)
        assertEquals(items.size, items.map(::feedItemKey).toSet().size)
    }

    @Test
    fun testKeys_20_windowShiftPreservesKeys() {
        val ch5Page = MangaFeedItem.Page("ch5", 5, 0, 10, "url5")
        val ch6Page = MangaFeedItem.Page("ch6", 6, 0, 10, "url6")
        val key5Before = feedItemKey(ch5Page)
        val key6Before = feedItemKey(ch6Page)
        
        val key5After = feedItemKey(ch5Page)
        val key6After = feedItemKey(ch6Page)
        
        assertEquals(key5Before, key5After)
        assertEquals(key6Before, key6After)
    }

    @Test
    fun testSingleFlight_21_concurrentLoadsOnce() {
        var callCount = 0
        val map = mutableMapOf<Int, Int>()

        fun loadOnce(key: Int): Int = synchronized(map) {
            map.getOrPut(key) {
                callCount++
                key
            }
        }

        val res1 = loadOnce(1)
        val res2 = loadOnce(1)

        assertEquals(1, callCount)
        assertEquals(res1, res2)
    }

    // --- PART 5C-P TESTS ---

    @Test
    fun part5CP_zoom_1_webtoonContainerHeightPx_1x() {
        assertEquals(2000, webtoonContainerHeightPx(2000, 1f))
    }

    @Test
    fun part5CP_zoom_2_webtoonContainerHeightPx_halfX() {
        assertEquals(4000, webtoonContainerHeightPx(2000, 0.5f))
    }

    @Test
    fun part5CP_zoom_3_webtoonContainerHeightPx_threeQuartersX() {
        assertEquals(2666, webtoonContainerHeightPx(2000, 0.75f))
    }

    @Test
    fun part5CP_zoom_4_webtoonContainerHeightPx_2x() {
        assertEquals(2000, webtoonContainerHeightPx(2000, 2f))
    }

    @Test
    fun part5CP_zoom_5_clampOffset_returnsZero_whenScale1OrLess() {
        assertEquals(Offset.Zero, clampOffset(Offset(100f, 100f), 1000, 2000, 1f))
        assertEquals(Offset.Zero, clampOffset(Offset(100f, 100f), 1000, 2000, 0.5f))
    }

    @Test
    fun part5CP_zoom_6_clampOffset_at2x_clampsXToHalfVpW() {
        val clampedPos = clampOffset(Offset(800f, 0f), 1000, 2000, 2f)
        assertEquals(500f, clampedPos.x, 0.01f)
        val clampedNeg = clampOffset(Offset(-800f, 0f), 1000, 2000, 2f)
        assertEquals(-500f, clampedNeg.x, 0.01f)
    }

    @Test
    fun part5CP_zoom_7_focalAnchoredOffset_keepsFocalPointInvariant() {
        val centroidFromCenter = Offset(100f, 0f)
        val currentOffset = Offset.Zero
        val newOffset = focalAnchoredOffset(centroidFromCenter, currentOffset, 1f, 2f)
        assertEquals(-100f, newOffset.x, 0.01f)
        assertEquals(0f, newOffset.y, 0.01f)
    }

    @Test
    fun part5CP_tapZone_8_left_LEFT() {
        assertEquals(MangaNavRegion.LEFT, tapZoneFor(0.1f, 0.5f, MangaTapZoneLayout.RIGHT_AND_LEFT, MangaTapInvert.NONE))
    }

    @Test
    fun part5CP_tapZone_9_right_RIGHT() {
        assertEquals(MangaNavRegion.RIGHT, tapZoneFor(0.9f, 0.5f, MangaTapZoneLayout.RIGHT_AND_LEFT, MangaTapInvert.NONE))
    }

    @Test
    fun part5CP_tapZone_10_center_MENU() {
        assertEquals(MangaNavRegion.MENU, tapZoneFor(0.5f, 0.5f, MangaTapZoneLayout.RIGHT_AND_LEFT, MangaTapInvert.NONE))
    }

    @Test
    fun part5CP_tapZone_11_left_invertedHorizontal_RIGHT() {
        assertEquals(MangaNavRegion.RIGHT, tapZoneFor(0.1f, 0.5f, MangaTapZoneLayout.RIGHT_AND_LEFT, MangaTapInvert.HORIZONTAL))
    }

    @Test
    fun part5CP_tapZone_12_defaultLayout_isRIGHT_AND_LEFT() {
        assertEquals(MangaTapZoneLayout.RIGHT_AND_LEFT, MangaTapZoneLayout.RIGHT_AND_LEFT)
    }

    @Test
    fun part5CP_tapZone_13_disabled_MENU() {
        assertEquals(MangaNavRegion.MENU, tapZoneFor(0.5f, 0.5f, MangaTapZoneLayout.DISABLED, MangaTapInvert.NONE))
    }

    @Test
    fun part5CP_tapScroll_14_tallPage_threeQuarters() {
        assertEquals(1500, nextImageScroll(5000, 2000))
    }

    @Test
    fun part5CP_tapScroll_15_shortPage_exactRemaining() {
        assertEquals(800, nextImageScroll(800, 2000))
    }

    @Test
    fun part5CP_tapScroll_16_equalPage_exact() {
        assertEquals(2000, nextImageScroll(2000, 2000))
    }

    @Test
    fun part5CP_feed_17_buildFeedItems_order() {
        val page = eu.kanade.tachiyomi.source.model.Page(0, "u1", "u1")
        val ch1 = LoadedChapter("c1", 0, "Ch 1", listOf(page))
        val ch2 = LoadedChapter("c2", 1, "Ch 2", listOf(page))
        val ch3 = LoadedChapter("c3", 2, "Ch 3", listOf(page))

        val items = buildFeedItems(ch1, ch2, ch3, forceTransition = true)

        assertTrue(items[0] is MangaFeedItem.Page)
        assertTrue(items[1] is MangaFeedItem.Transition)
        assertEquals(MangaFeedItem.Transition.Kind.PREV, (items[1] as MangaFeedItem.Transition).kind)
        assertTrue(items[2] is MangaFeedItem.Page)
        assertTrue(items[3] is MangaFeedItem.Transition)
        assertEquals(MangaFeedItem.Transition.Kind.NEXT, (items[3] as MangaFeedItem.Transition).kind)
        assertTrue(items[4] is MangaFeedItem.Page)
    }

    @Test
    fun part5CP_feed_18_identicalUrls_uniqueKeys() {
        val pageA = eu.kanade.tachiyomi.source.model.Page(0, "http://same.jpg", "http://same.jpg")
        val pageB = eu.kanade.tachiyomi.source.model.Page(0, "http://same.jpg", "http://same.jpg")
        val chA = LoadedChapter("chA", 0, "Chapter A", listOf(pageA))
        val chB = LoadedChapter("chB", 1, "Chapter B", listOf(pageB))

        val items = buildFeedItems(chA, chB, null, forceTransition = true)
        val keys = items.map(::feedItemKey).toSet()

        assertEquals(items.size, keys.size)
    }

    // --- PART 5D TESTS ---

    @Test
    fun part5D_1_remainingDown_math() {
        val rem = computeRemainingDown(itemOffset = 0, itemSize = 5000, viewportStart = 0)
        assertEquals(5000, rem)
        assertEquals(1500, nextImageScroll(rem, viewportHeightPx = 2000))

        val remBoundary = computeRemainingDown(itemOffset = 0, itemSize = 800, viewportStart = 0)
        assertEquals(800, remBoundary)
        assertEquals(800, nextImageScroll(remBoundary, viewportHeightPx = 2000))
    }

    @Test
    fun part5D_2_remainingUp_math() {
        val rem1 = computeRemainingUp(itemOffset = -3000, viewportEnd = 2000)
        assertEquals(5000, rem1)
        assertEquals(1500, nextImageScroll(rem1, viewportHeightPx = 2000))

        val rem2 = computeRemainingUp(itemOffset = 500, viewportEnd = 2000)
        assertEquals(1500, rem2)
        assertEquals(1500, nextImageScroll(rem2, viewportHeightPx = 2000))
    }

    @Test
    fun part5D_3_feed_keys_unique_across_three_loaded_chapters() {
        val page = Page(0, "http://same.jpg", "http://same.jpg")
        val ch0 = LoadedChapter("ch0", 0, "Ch 0", listOf(page))
        val ch1 = LoadedChapter("ch1", 1, "Ch 1", listOf(page))
        val ch2 = LoadedChapter("ch2", 2, "Ch 2", listOf(page))

        val items = buildFeedItems(ch0, ch1, ch2, forceTransition = true)
        val keys = items.map(::feedItemKey).toSet()
        assertEquals(items.size, keys.size)
    }

    @Test
    fun part5D_4_initialFeedIndex_formula() {
        val idxWithPrev = computeInitialFeedIndex(prevPageCount = 10, hasPrevTransition = true, savedPageIndex = 4)
        assertEquals(15, idxWithPrev)

        val idxNoPrev = computeInitialFeedIndex(prevPageCount = 0, hasPrevTransition = false, savedPageIndex = 4)
        assertEquals(4, idxNoPrev)
    }

    @Test
    fun part5D_5_window_math() {
        val winStart = computeWindow(chapterCount = 5, currIndex = 0)
        assertEquals(null, winStart.prevIndex)
        assertEquals(0, winStart.currIndex)
        assertEquals(1, winStart.nextIndex)

        val winEnd = computeWindow(chapterCount = 5, currIndex = 4)
        assertEquals(3, winEnd.prevIndex)
        assertEquals(4, winEnd.currIndex)
        assertEquals(null, winEnd.nextIndex)
    }

    @Test
    fun part5D_6_ref_before_unref_preserves_overlapping_chapters() {
        val chapter2 = MangaChapter("ch2", 2, "Ch 2", "http://url2").apply {
            state = MangaChapterState.Loaded(emptyList())
        }
        val chapter3 = MangaChapter("ch3", 3, "Ch 3", "http://url3").apply {
            state = MangaChapterState.Loaded(emptyList())
        }

        chapter2.ref()
        chapter3.ref()

        val oldSet = setOf(1, 2, 3)
        val newSet = setOf(2, 3, 4)

        chapter2.ref()
        chapter3.ref()

        val dropped = oldSet.filter { it !in newSet }
        assertEquals(listOf(1), dropped)

        assertTrue(chapter2.state is MangaChapterState.Loaded)
        assertTrue(chapter3.state is MangaChapterState.Loaded)
    }

    @Test
    fun part5D_7_rtl_mapping_and_disabled_zones() {
        val regionNormal = tapZoneFor(0.9f, 0.5f, MangaTapZoneLayout.RIGHT_AND_LEFT, MangaTapInvert.NONE, tapZonesEnabled = true)
        assertEquals(MangaNavRegion.RIGHT, regionNormal)

        val regionInverted = tapZoneFor(0.9f, 0.5f, MangaTapZoneLayout.RIGHT_AND_LEFT, MangaTapInvert.HORIZONTAL, tapZonesEnabled = true)
        assertEquals(MangaNavRegion.LEFT, regionInverted)

        val regionDisabled = tapZoneFor(0.9f, 0.5f, MangaTapZoneLayout.RIGHT_AND_LEFT, MangaTapInvert.NONE, tapZonesEnabled = false)
        assertEquals(MangaNavRegion.MENU, regionDisabled)
    }

    @Test
    fun part5D_8_twoFingerTransformGestures_zoomScale_clamp() {
        val vp = IntSize(1000, 2000)
        val clamped = clampOffset(Offset(1200f, 2500f), vp.width, vp.height, 2.0f)
        assertEquals(500f, clamped.x, 0.001f)
        assertEquals(1000f, clamped.y, 0.001f)
    }

    @Test
    fun part5D_9_pagedMode_tapZone_menuToggle() {
        val vp = IntSize(1000, 2000)
        val region = tapZoneFor(Offset(500f, 1000f), vp, MangaTapZoneLayout.RIGHT_AND_LEFT, MangaTapInvert.NONE, tapZonesEnabled = true)
        assertEquals(MangaNavRegion.MENU, region)
    }

    @Test
    fun testCrossMangaStateBleed_chapterCacheClearedOnInitNewNovel() {
        val app = org.robolectric.RuntimeEnvironment.getApplication()
        val viewModel = com.lorelight.manga.reader.MangaReaderViewModel(app)
        val novel1 = Novel(
            id = "novel_1",
            title = "Manga 1",
            currentChapter = "Chapter 1",
            lastReadTimestamp = 1000L,
            author = "Author 1",
            description = ""
        )
        viewModel.chapterCache[0] = com.lorelight.manga.reader.MangaChapter("ch0", 0, "Chapter 0", "url0")
        assertEquals(1, viewModel.chapterCache.size)

        val novel2 = Novel(
            id = "novel_2",
            title = "Manga 2",
            currentChapter = "Chapter 1",
            lastReadTimestamp = 1000L,
            author = "Author 2",
            description = ""
        )
        viewModel.init(novel2)

        assertTrue(viewModel.chapterCache.isEmpty())
    }
}


