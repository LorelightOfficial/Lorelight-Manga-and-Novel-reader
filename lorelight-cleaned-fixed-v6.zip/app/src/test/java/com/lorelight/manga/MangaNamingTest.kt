package com.lorelight.manga

import com.lorelight.manga.loader.MangaExtensionLoader
import com.lorelight.manga.loader.MangaExtensionLoader.describeChain
import com.lorelight.manga.util.MangaNamingUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MangaNamingTest {

    @Test
    fun testPluginIdRoundTrip() {
        val sourceId = 2499283573021220255L
        val pluginId = MangaNamingUtils.toPluginId(sourceId)

        assertEquals("manga:2499283573021220255", pluginId)
        assertTrue(MangaNamingUtils.isMangaPluginId(pluginId))
        assertEquals(sourceId, MangaNamingUtils.toSourceId(pluginId))
        assertFalse(MangaNamingUtils.isMangaPluginId("novel:123"))
    }

    @Test
    fun testChapterUrlFormattingAndParsing() {
        val sourceId = 2499283573021220255L
        val chapterUrl = "/title/a1b2c3d4/chapter-1?lang=en"

        val formatted = MangaNamingUtils.formatChapterUrl(sourceId, chapterUrl)
        val parsed = MangaNamingUtils.parseChapterUrl(formatted)

        assertTrue(formatted.startsWith("manga:2499283573021220255:"))
        assertEquals(sourceId, parsed?.first)
        assertEquals(chapterUrl, parsed?.second)
    }

    @Test
    fun testResolveSourceClassNamesAbsolute() {
        val result = MangaExtensionLoader.resolveSourceClassNames("com.example.Foo", "p")
        assertEquals(listOf("com.example.Foo"), result)
    }

    @Test
    fun testResolveSourceClassNamesRelative() {
        val result = MangaExtensionLoader.resolveSourceClassNames(".Foo", "eu.kanade.x")
        assertEquals(listOf("eu.kanade.x.Foo"), result)
    }

    @Test
    fun testResolveSourceClassNamesMultipleWithSpacesAndEmpty() {
        val result = MangaExtensionLoader.resolveSourceClassNames("a.A;.B; ;.C ", "p")
        assertEquals(listOf("a.A", "p.B", "p.C"), result)
    }

    @Test
    fun testResolveSourceClassNamesEmpty() {
        val result = MangaExtensionLoader.resolveSourceClassNames("", "p")
        assertTrue(result.isEmpty())
    }

    @Test
    fun testDescribeChainOutput() {
        val cause = java.lang.Exception("inner cause")
        val outer = java.lang.RuntimeException("outer error", cause)
        val chain = with(MangaExtensionLoader) { outer.describeChain() }

        assertTrue(chain.contains("java.lang.RuntimeException"))
        assertTrue(chain.contains("java.lang.Exception"))
        assertTrue(chain.contains("caused by:"))
    }

    @Test
    fun okHttpExposesKotlinDurationTimeoutOverloads() {
        val names = okhttp3.OkHttpClient.Builder::class.java.declaredMethods.map { it.name }
        val mangled = names.filter { it.contains('-') }.sorted()
        println("LL_OKHTTP_BUILDER_MANGLED=$mangled")
        for (prefix in listOf("connectTimeout-", "readTimeout-", "writeTimeout-", "callTimeout-")) {
            org.junit.Assert.assertTrue(
                "OkHttpClient.Builder has no '$prefix' (kotlin.time.Duration) overload. " +
                    "Extensions built against OkHttp 5.x will fail with NoSuchMethodError. " +
                    "Mangled methods present: $mangled",
                names.any { it.startsWith(prefix) },
            )
        }
    }

    @Test
    fun okHttpVersionIsAtLeast5() {
        val v = okhttp3.OkHttp.VERSION
        println("LL_OKHTTP_VERSION=$v")
        org.junit.Assert.assertTrue("OkHttp must be 5.x or newer, got $v", v.startsWith("5."))
    }
}
