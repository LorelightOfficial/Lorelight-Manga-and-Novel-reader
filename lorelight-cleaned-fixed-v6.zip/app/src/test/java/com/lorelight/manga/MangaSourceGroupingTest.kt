package com.lorelight.manga

import com.lorelight.manga.util.MangaSourceGrouping
import org.junit.Assert.assertEquals
import org.junit.Test

class MangaSourceGroupingTest {

    @Test
    fun collapsesToAllWhenAllSelected() {
        val entries = listOf(
            MangaSourceGrouping.Entry(1L, "com.example.pkg", "Comic Fury", "all"),
            MangaSourceGrouping.Entry(2L, "com.example.pkg", "Comic Fury", "en"),
            MangaSourceGrouping.Entry(3L, "com.example.pkg", "Comic Fury", "es")
        )
        val selectedLangs = setOf("all", "en")
        val result = MangaSourceGrouping.collapseMultiLang(entries, selectedLangs)
        assertEquals(setOf(1L), result)
    }

    @Test
    fun keepsEverythingWhenAllNotSelected() {
        val entries = listOf(
            MangaSourceGrouping.Entry(1L, "com.example.pkg", "Comic Fury", "all"),
            MangaSourceGrouping.Entry(2L, "com.example.pkg", "Comic Fury", "en"),
            MangaSourceGrouping.Entry(3L, "com.example.pkg", "Comic Fury", "es")
        )
        val selectedLangs = setOf("en")
        val result = MangaSourceGrouping.collapseMultiLang(entries, selectedLangs)
        assertEquals(setOf(1L, 2L, 3L), result)
    }

    @Test
    fun leavesGroupsWithoutAllUntouched() {
        val entries = listOf(
            MangaSourceGrouping.Entry(4L, "com.example.pkg", "Codex Zero", "es"),
            MangaSourceGrouping.Entry(5L, "com.example.pkg", "Codex Zero", "fr")
        )
        val selectedLangs = setOf("all", "es")
        val result = MangaSourceGrouping.collapseMultiLang(entries, selectedLangs)
        assertEquals(setOf(4L, 5L), result)
    }

    @Test
    fun doesNotMergeDifferentPackages() {
        val entries = listOf(
            MangaSourceGrouping.Entry(6L, "pkg.a", "Foo", "all"),
            MangaSourceGrouping.Entry(7L, "pkg.b", "Foo", "en")
        )
        val selectedLangs = setOf("all", "en")
        val result = MangaSourceGrouping.collapseMultiLang(entries, selectedLangs)
        assertEquals(setOf(6L, 7L), result)
    }

    @Test
    fun isDeterministicWithDuplicateAllEntries() {
        val entries = listOf(
            MangaSourceGrouping.Entry(9L, "com.example.pkg", "Comic Fury", "all"),
            MangaSourceGrouping.Entry(8L, "com.example.pkg", "Comic Fury", "all"),
            MangaSourceGrouping.Entry(10L, "com.example.pkg", "Comic Fury", "en")
        )
        val selectedLangs = setOf("all")
        val result = MangaSourceGrouping.collapseMultiLang(entries, selectedLangs)
        assertEquals(setOf(8L), result)
    }

    @Test
    fun handlesEmptyInput() {
        val entries = emptyList<MangaSourceGrouping.Entry>()
        val selectedLangs = setOf("all", "en")
        val result = MangaSourceGrouping.collapseMultiLang(entries, selectedLangs)
        assertEquals(emptySet<Long>(), result)
    }
}
