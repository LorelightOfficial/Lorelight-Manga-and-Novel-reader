package com.lorelight.manga.repo

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class MangaRepoParseTest {

    @Test
    fun testParseIndexValidAndFiltered() {
        val json = """
        [
            {
                "name": "Tachiyomi: MangaDex",
                "pkg": "eu.kanade.tachiyomi.extension.en.mangadex",
                "apk": "tachiyomi-en.mangadex-v1.4.1.apk",
                "lang": "en",
                "code": 100,
                "version": "1.4.1",
                "nsfw": 1,
                "sources": [
                    {
                        "id": "2499283573021220255",
                        "name": "MangaDex",
                        "lang": "en",
                        "baseUrl": "https://mangadex.org"
                    }
                ]
            },
            {
                "name": "Asura Scans",
                "pkg": "eu.kanade.tachiyomi.extension.en.asurascans",
                "apk": "tachiyomi-en.asurascans-v1.3.0.apk",
                "lang": "en",
                "code": 101,
                "version": "1.3.0",
                "nsfw": 0,
                "sources": [
                    {
                        "id": "789101112131415",
                        "name": "Asura Scans",
                        "lang": "en",
                        "baseUrl": "https://asuraclan.com"
                    }
                ]
            },
            {
                "name": "Old Ext",
                "pkg": "eu.kanade.tachiyomi.extension.en.oldext",
                "apk": "oldext-v1.1.0.apk",
                "lang": "en",
                "code": 1,
                "version": "1.1.0",
                "nsfw": 0,
                "sources": []
            },
            {
                "name": "Future Ext",
                "pkg": "eu.kanade.tachiyomi.extension.en.futureext",
                "apk": "futureext-v1.6.0.apk",
                "lang": "en",
                "code": 1,
                "version": "1.6.0",
                "nsfw": 0,
                "sources": []
            },
            "this is malformed json element"
        ]
        """.trimIndent()

        val parsed = parseIndex(json, "https://raw.githubusercontent.com/keiyoushi/extensions/repo")

        assertEquals(2, parsed.size)

        val ext1 = parsed[0]
        assertEquals("MangaDex", ext1.name)
        assertEquals("eu.kanade.tachiyomi.extension.en.mangadex", ext1.pkg)
        assertEquals("tachiyomi-en.mangadex-v1.4.1.apk", ext1.apkName)
        assertEquals("1.4.1", ext1.version)
        assertTrue(ext1.nsfw)
        assertEquals(1, ext1.sources.size)
        assertEquals(2499283573021220255L, ext1.sources[0].id)
        assertEquals("https://raw.githubusercontent.com/keiyoushi/extensions/repo/apk/tachiyomi-en.mangadex-v1.4.1.apk", ext1.apkUrl)
        assertEquals("https://raw.githubusercontent.com/keiyoushi/extensions/repo/icon/eu.kanade.tachiyomi.extension.en.mangadex.png", ext1.iconUrl)

        val ext2 = parsed[1]
        assertEquals("Asura Scans", ext2.name)
        assertFalse(ext2.nsfw)
        assertEquals(789101112131415L, ext2.sources[0].id)
    }

    @Test
    fun testEmptySourcesArrayExcluded() {
        val json = """
        [
            {
                "name": "Empty Sources Ext",
                "pkg": "eu.kanade.extension.en.empty",
                "apk": "empty-v1.4.1.apk",
                "lang": "en",
                "code": 1,
                "version": "1.4.1",
                "nsfw": 0,
                "sources": []
            }
        ]
        """.trimIndent()
        val parsed = parseIndex(json, "https://example.com/repo")
        assertEquals(0, parsed.size)
    }

    @Test
    fun testLibVersion16Included() {
        val json = """
        [
            {
                "name": "Lib 1.6 Ext",
                "pkg": "eu.kanade.extension.en.lib16",
                "apk": "lib16-v1.6.2.apk",
                "lang": "en",
                "code": 1,
                "version": "1.6.2",
                "nsfw": 0,
                "sources": [
                    {
                        "id": "12345",
                        "name": "Source 1.6",
                        "lang": "en",
                        "baseUrl": "https://example.com"
                    }
                ]
            }
        ]
        """.trimIndent()
        val parsed = parseIndex(json, "https://example.com/repo")
        assertEquals(1, parsed.size)
        assertEquals("Lib 1.6 Ext", parsed[0].name)
        assertEquals(1.6, parsed[0].libVersion, 0.001)
    }

    @Test
    fun testNoticePkgsExcluded() {
        val json = """
        [
            {
                "name": "Outdated App",
                "pkg": "eu.kanade.tachiyomi.extension.all.keiyoushi",
                "apk": "keiyoushi-v1.4.1.apk",
                "lang": "all",
                "code": 1,
                "version": "1.4.1",
                "nsfw": 0,
                "sources": [
                    {
                        "id": "1",
                        "name": "Notice",
                        "lang": "all",
                        "baseUrl": ""
                    }
                ]
            }
        ]
        """.trimIndent()
        val parsed = parseIndex(json, "https://example.com/repo")
        assertEquals(0, parsed.size)
    }

    @Test
    fun testNormalizeRepoUrl() {
        assertEquals(
            "https://raw.githubusercontent.com/keiyoushi/extensions/repo",
            MangaRepositoryManager.normalizeRepoUrl("https://raw.githubusercontent.com/keiyoushi/extensions/repo/index.min.json/")
        )
        assertEquals(
            "https://raw.githubusercontent.com/keiyoushi/extensions/repo",
            MangaRepositoryManager.normalizeRepoUrl("  https://raw.githubusercontent.com/keiyoushi/extensions/repo/  ")
        )
        assertEquals(
            "https://raw.githubusercontent.com/keiyoushi/extensions/repo",
            MangaRepositoryManager.normalizeRepoUrl("https://raw.githubusercontent.com/keiyoushi/extensions/repo/index.pb")
        )
    }

    @Test
    fun testParseProtoIndex() {
        // Helper to encode varint
        fun writeVarint(out: java.io.ByteArrayOutputStream, value: Long) {
            var v = value
            while (true) {
                if ((v and 0x7FL.inv()) == 0L) {
                    out.write(v.toInt())
                    break
                } else {
                    out.write(((v and 0x7F) or 0x80).toInt())
                    v = v ushr 7
                }
            }
        }

        fun writeField(out: java.io.ByteArrayOutputStream, fieldNum: Int, wireType: Int, data: ByteArray) {
            writeVarint(out, ((fieldNum.toLong() shl 3) or wireType.toLong()))
            if (wireType == 2) {
                writeVarint(out, data.size.toLong())
                out.write(data)
            }
        }

        fun writeVarintField(out: java.io.ByteArrayOutputStream, fieldNum: Int, value: Long) {
            writeVarint(out, ((fieldNum.toLong() shl 3) or 0L))
            writeVarint(out, value)
        }

        // Build a Source message
        val srcOut = java.io.ByteArrayOutputStream()
        writeVarintField(srcOut, 1, 987654321L) // ID
        writeField(srcOut, 2, 2, "Test Manga Source".toByteArray()) // Name
        writeField(srcOut, 3, 2, "en".toByteArray()) // Lang
        writeField(srcOut, 4, 2, "https://testmanga.com".toByteArray()) // BaseUrl

        // Build Resources message
        val resOut = java.io.ByteArrayOutputStream()
        writeField(resOut, 1, 2, "tachiyomi-en.testmanga-v1.4.2.apk".toByteArray())
        writeField(resOut, 2, 2, "icon.png".toByteArray())

        // Build Extension message
        val extOut = java.io.ByteArrayOutputStream()
        writeField(extOut, 1, 2, "Test Manga Ext".toByteArray()) // Name
        writeField(extOut, 2, 2, "eu.kanade.tachiyomi.extension.en.testmanga".toByteArray()) // Pkg
        writeField(extOut, 3, 2, resOut.toByteArray()) // Resources
        writeField(extOut, 4, 2, "1.4".toByteArray()) // LibVersion
        writeVarintField(extOut, 5, 2L) // VersionCode
        writeField(extOut, 6, 2, "1.4.2".toByteArray()) // VersionName
        writeVarintField(extOut, 7, 3L) // Flags = 3 (NSFW)
        writeField(extOut, 8, 2, srcOut.toByteArray()) // Source

        // Build Top-Level Index (field 101 contains repeated field 1)
        val extListContainer = java.io.ByteArrayOutputStream()
        writeField(extListContainer, 1, 2, extOut.toByteArray())

        val topOut = java.io.ByteArrayOutputStream()
        writeField(topOut, 1, 2, "Test Repo".toByteArray()) // Repo Name
        writeField(topOut, 101, 2, extListContainer.toByteArray()) // Extensions

        val rawPb = topOut.toByteArray()

        val parsed = parseProtoIndex(rawPb, "https://raw.githubusercontent.com/keiyoushi/extensions/repo")
        assertEquals(1, parsed.size)

        val ext = parsed[0]
        assertEquals("Test Manga Ext", ext.name)
        assertEquals("eu.kanade.tachiyomi.extension.en.testmanga", ext.pkg)
        assertEquals("tachiyomi-en.testmanga-v1.4.2.apk", ext.apkName)
        assertEquals("1.4.2", ext.version)
        assertEquals(2, ext.versionCode)
        assertTrue(ext.nsfw)
        assertEquals("en", ext.lang)
        assertEquals(1, ext.sources.size)
        assertEquals(987654321L, ext.sources[0].id)
        assertEquals("Test Manga Source", ext.sources[0].name)
        assertEquals("https://testmanga.com", ext.sources[0].baseUrl)
    }

    @Test
    fun testNoticePkgFilteredInProto() {
        fun writeVarint(out: java.io.ByteArrayOutputStream, value: Long) {
            var v = value
            while (true) {
                if ((v and 0x7FL.inv()) == 0L) {
                    out.write(v.toInt())
                    break
                } else {
                    out.write(((v and 0x7F) or 0x80).toInt())
                    v = v ushr 7
                }
            }
        }

        fun writeField(out: java.io.ByteArrayOutputStream, fieldNum: Int, wireType: Int, data: ByteArray) {
            writeVarint(out, ((fieldNum.toLong() shl 3) or wireType.toLong()))
            if (wireType == 2) {
                writeVarint(out, data.size.toLong())
                out.write(data)
            }
        }

        val srcOut = java.io.ByteArrayOutputStream()
        writeVarint(srcOut, (1L shl 3) or 0L)
        writeVarint(srcOut, 1L)
        writeField(srcOut, 2, 2, "Outdated App".toByteArray())
        writeField(srcOut, 3, 2, "all".toByteArray())
        writeField(srcOut, 4, 2, "https://keiyoushi.github.io".toByteArray())

        val resOut = java.io.ByteArrayOutputStream()
        writeField(resOut, 1, 2, "tachiyomi-all.keiyoushi-v1.4.1.apk".toByteArray())

        val extOut = java.io.ByteArrayOutputStream()
        writeField(extOut, 1, 2, "Outdated App".toByteArray())
        writeField(extOut, 2, 2, "eu.kanade.tachiyomi.extension.all.keiyoushi".toByteArray())
        writeField(extOut, 3, 2, resOut.toByteArray())
        writeField(extOut, 6, 2, "1.4.1".toByteArray())
        writeField(extOut, 8, 2, srcOut.toByteArray())

        val extListContainer = java.io.ByteArrayOutputStream()
        writeField(extListContainer, 1, 2, extOut.toByteArray())

        val topOut = java.io.ByteArrayOutputStream()
        writeField(topOut, 101, 2, extListContainer.toByteArray())

        val stats = ParseStats()
        val parsed = parseProtoIndex(topOut.toByteArray(), "https://raw.githubusercontent.com/keiyoushi/extensions/repo", stats)
        assertEquals(0, parsed.size)
        assertEquals(1, stats.rejectedNotice)
    }
}
