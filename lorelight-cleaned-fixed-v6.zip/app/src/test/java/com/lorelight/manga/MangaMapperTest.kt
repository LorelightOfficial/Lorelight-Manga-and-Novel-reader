package com.lorelight.manga

import com.lorelight.data.model.MANGA_PLUGIN_PREFIX
import com.lorelight.data.model.Novel
import com.lorelight.data.model.decodeMangaChapterUrl
import com.lorelight.data.model.encodeMangaChapterUrl
import com.lorelight.data.model.isManga
import com.lorelight.data.model.mangaSourceId
import com.lorelight.manga.model.mapMangaStatus
import com.lorelight.manga.model.toChapterNames
import com.lorelight.manga.model.toNovel
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class MangaMapperTest {

    @Test
    fun testRoundTripChapterUrlEncoding() {
        val sourceId = 2499283573021220255L
        val originalUrl = "章1/ch?a=b&c=d space"
        val encoded = encodeMangaChapterUrl(sourceId, originalUrl)
        val decoded = decodeMangaChapterUrl(encoded)

        assertNotNull(decoded)
        assertEquals(sourceId, decoded!!.first)
        assertEquals(originalUrl, decoded.second)
    }

    @Test
    fun testDecodeInvalidUrls() {
        assertNull(decodeMangaChapterUrl(""))
        assertNull(decodeMangaChapterUrl("http://x"))
        assertNull(decodeMangaChapterUrl("mangaext://"))
        assertNull(decodeMangaChapterUrl("mangaext://notanumber/foo"))
    }

    @Test
    fun testPluginIdAndSourceIdPrecision() {
        val sourceId = 2499283573021220255L
        val novel = Novel(
            title = "Test Manga",
            currentChapter = "Chapter 1",
            lastReadTimestamp = 0L,
            pluginId = MANGA_PLUGIN_PREFIX + sourceId,
            pluginNovelPath = "/manga/1"
        )

        assertEquals("manga:2499283573021220255", novel.pluginId)
        assertEquals(sourceId, novel.mangaSourceId)
    }

    @Test
    fun testIsMangaCheck() {
        val sourceId = 2499283573021220255L
        val mangaNovel = Novel(title = "Manga", currentChapter = "", lastReadTimestamp = 0L, pluginId = MANGA_PLUGIN_PREFIX + sourceId)
        val nullNovel = Novel(title = "Null", currentChapter = "", lastReadTimestamp = 0L, pluginId = null)
        val emptyNovel = Novel(title = "Empty", currentChapter = "", lastReadTimestamp = 0L, pluginId = "")
        val wuxiaNovel = Novel(title = "Wuxia", currentChapter = "", lastReadTimestamp = 0L, pluginId = "plugin_wuxia")

        assertTrue(mangaNovel.isManga)
        assertFalse(nullNovel.isManga)
        assertFalse(emptyNovel.isManga)
        assertFalse(wuxiaNovel.isManga)
    }

    @Test
    fun testChapterReversal() {
        val ch1 = SChapter.create().apply { name = "C1"; url = "c1" }
        val ch2 = SChapter.create().apply { name = "C2"; url = "c2" }
        val ch3 = SChapter.create().apply { name = "C3"; url = "c3" }
        val chapters = listOf(ch3, ch2, ch1) // Newest first

        val names = chapters.toChapterNames()
        assertEquals(listOf("C1", "C2", "C3"), names)
    }

    @Test
    fun testIdentityPreservation() {
        val sourceId = 12345L
        val existingNovel = Novel(
            id = "abc",
            title = "Old Title",
            currentChapter = "Chapter 5",
            lastReadTimestamp = 0L,
            currentParagraphIndex = 12,
            completedChapters = listOf("Chapter 1", "Chapter 2"),
            isFavorite = true,
            description = "Old Description",
            pluginId = MANGA_PLUGIN_PREFIX + sourceId,
            pluginNovelPath = "/manga/abc"
        )

        val freshManga = SManga.create().apply {
            url = "/manga/abc"
            title = "New Updated Title"
            description = "New Description"
        }

        val mapped = freshManga.toNovel(sourceId, existing = existingNovel)

        assertEquals("abc", mapped.id)
        assertEquals("Chapter 5", mapped.currentChapter)
        assertEquals(12, mapped.currentParagraphIndex)
        assertEquals(listOf("Chapter 1", "Chapter 2"), mapped.completedChapters)
        assertTrue(mapped.isFavorite)

        assertEquals("New Updated Title", mapped.title)
        assertEquals("New Description", mapped.description)
    }

    @Test
    fun testReopenReusesIdentityNoDuplicate() {
        val sourceId = 777L
        val existing = Novel(
            id = "lib-1",
            title = "Added Manga",
            currentChapter = "Chapter 3",
            lastReadTimestamp = 0L,
            pluginId = MANGA_PLUGIN_PREFIX + sourceId,
            pluginNovelPath = "/series/xyz"
        )
        // Fix 1 guarantees details.url == request url before mapping:
        val details = SManga.create().apply {
            url = "/series/xyz"
            title = "Added Manga (updated)"
        }
        val mapped = details.toNovel(sourceId, existing = existing)
        assertEquals("lib-1", mapped.id)                    // same id -> no duplicate
        assertEquals("/series/xyz", mapped.pluginNovelPath) // stable lookup key
        assertEquals(MANGA_PLUGIN_PREFIX + sourceId, mapped.pluginId)
    }

    @Test
    fun testNewMangaCreationWithoutExisting() {
        val sourceId = 12345L
        val ch1 = SChapter.create().apply { name = "Chapter 1"; url = "c1" }
        val freshManga = SManga.create().apply {
            url = "/manga/new"
            title = "Fresh Manga"
            description = "Fresh Description"
        }

        val mapped = freshManga.toNovel(sourceId, existing = null, chapters = listOf(ch1))

        assertNotNull(mapped.id)
        assertEquals("Chapter 1", mapped.currentChapter)
        assertEquals(0, mapped.currentParagraphIndex)
        assertTrue(mapped.completedChapters.isEmpty())
        assertFalse(mapped.isFavorite)
        assertEquals("Fresh Manga", mapped.title)
    }

    @Test
    fun testStatusMapping() {
        assertEquals("Unknown", mapMangaStatus(0))
        assertEquals("Ongoing", mapMangaStatus(1))
        assertEquals("Completed", mapMangaStatus(2))
        assertEquals("Unknown", mapMangaStatus(3))
        assertEquals("Completed", mapMangaStatus(4))
        assertEquals("Cancelled", mapMangaStatus(5))
        assertEquals("On Hiatus", mapMangaStatus(6))
    }
}
