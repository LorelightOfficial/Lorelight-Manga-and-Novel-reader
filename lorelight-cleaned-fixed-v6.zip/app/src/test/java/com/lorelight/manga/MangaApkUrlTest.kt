package com.lorelight.manga

import com.lorelight.manga.repo.parseIndex
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class MangaApkUrlTest {

    @Test
    fun testModernShape() {
        val json = """
        {
          "extensionList": {
            "extensions": [
              {
                "name": "AHottie",
                "packageName": "eu.kanade.tachiyomi.extension.all.ahottie",
                "resources": {
                  "apkUrl": "https://cdn.jsdelivr.net/gh/yuzono/manga-repo@repo/apk/tachiyomi-all.ahottie-v1.6.4.apk",
                  "iconUrl": "https://cdn.jsdelivr.net/gh/yuzono/manga-repo@repo/icon/eu.kanade.tachiyomi.extension.all.ahottie.png"
                },
                "extensionLib": "1.6",
                "versionCode": "4",
                "versionName": "1.6.4",
                "sources": [
                  {
                    "id": "6289731484943315811",
                    "name": "AHottie",
                    "language": "all",
                    "homeUrl": "https://ahottie.top"
                  }
                ]
              }
            ]
          }
        }
        """.trimIndent()

        val parsed = parseIndex(json, "https://raw.githubusercontent.com/yuzono/manga-repo/repo")
        assertEquals(1, parsed.size)
        val ext = parsed.first()

        assertEquals("https://cdn.jsdelivr.net/gh/yuzono/manga-repo@repo/apk/tachiyomi-all.ahottie-v1.6.4.apk", ext.apkUrl)
        assertEquals("https://cdn.jsdelivr.net/gh/yuzono/manga-repo@repo/icon/eu.kanade.tachiyomi.extension.all.ahottie.png", ext.iconUrl)
        assertEquals("tachiyomi-all.ahottie-v1.6.4.apk", ext.apkName)
        assertFalse(ext.apkUrl.contains("raw.githubusercontent"))
    }

    @Test
    fun testLegacyShape() {
        val json = """
        [
          {
            "name": "MangaDex",
            "pkg": "eu.kanade.tachiyomi.extension.en.mangadex",
            "apk": "tachiyomi-en.mangadex-v1.4.1.apk",
            "lang": "en",
            "code": 1,
            "version": "1.4.1",
            "sources": [
              {
                "id": "12345",
                "name": "MangaDex",
                "lang": "en",
                "baseUrl": "https://mangadex.org"
              }
            ]
          }
        ]
        """.trimIndent()

        val repoBaseUrl = "https://raw.githubusercontent.com/keiyoushi/extensions/repo"
        val parsed = parseIndex(json, repoBaseUrl)
        assertEquals(1, parsed.size)
        val ext = parsed.first()

        assertEquals("https://raw.githubusercontent.com/keiyoushi/extensions/repo/apk/tachiyomi-en.mangadex-v1.4.1.apk", ext.apkUrl)
    }
}
