package com.lorelight.network

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class CloudflareInterceptorTest {

    private fun createResponse(
        code: Int,
        headers: Map<String, String> = emptyMap(),
        setCookie: List<String> = emptyList(),
        body: String = ""
    ): Response {
        val request = Request.Builder().url("https://example.com").build()
        val builder = Response.Builder()
            .request(request)
            .protocol(okhttp3.Protocol.HTTP_1_1)
            .code(code)
            .message(if (code == 200) "OK" else "Error")
            .body(body.toResponseBody())

        headers.forEach { (k, v) -> builder.header(k, v) }
        setCookie.forEach { builder.addHeader("Set-Cookie", it) }

        return builder.build()
    }

    @Test
    fun testIsCloudflareChallenge_headerCfMitigated() {
        val resp = createResponse(403, headers = mapOf("cf-mitigated" to "challenge"))
        assertTrue(isCloudflareChallenge(resp))
    }

    @Test
    fun testIsCloudflareChallenge_bodyJustAMoment() {
        val resp = createResponse(403, body = "<html><head><title>Just a moment...</title></head></html>")
        assertTrue(isCloudflareChallenge(resp))
    }

    @Test
    fun testIsCloudflareChallenge_cookieCfChl() {
        val resp = createResponse(503, setCookie = listOf("cf_chl_seq_123=abc; Path=/"))
        assertTrue(isCloudflareChallenge(resp))
    }

    @Test
    fun testIsCloudflareChallenge_plain403_returnsFalse() {
        val resp = createResponse(403, body = "403 Forbidden - Access Denied")
        assertFalse(isCloudflareChallenge(resp))
    }

    @Test
    fun testIsCloudflareChallenge_200OK_returnsFalse() {
        val resp = createResponse(200, body = "Hello World")
        assertFalse(isCloudflareChallenge(resp))
    }

    @Test
    fun testDeduplication_concurrentCallsSameHost_invokesSolverOnce() {
        val app = org.robolectric.RuntimeEnvironment.getApplication()
        val solverInvocationCount = AtomicInteger(0)

        val interceptor = CloudflareInterceptor(app, customSolver = { _, _ ->
            solverInvocationCount.incrementAndGet()
            Thread.sleep(200) // Simulate delay
            true
        })

        val callCount = AtomicInteger(0)
        val client = OkHttpClient.Builder()
            .addInterceptor(interceptor)
            .addInterceptor { chain ->
                val current = callCount.incrementAndGet()
                if (current <= 2) {
                    createResponse(403, headers = mapOf("cf-mitigated" to "challenge"))
                } else {
                    createResponse(200, body = "Success")
                }
            }
            .build()

        val executor = Executors.newFixedThreadPool(2)
        val future1 = executor.submit<Response> {
            client.newCall(Request.Builder().url("https://dedupe-host.com/test1").build()).execute()
        }
        val future2 = executor.submit<Response> {
            client.newCall(Request.Builder().url("https://dedupe-host.com/test2").build()).execute()
        }

        val resp1 = future1.get(5, TimeUnit.SECONDS)
        val resp2 = future2.get(5, TimeUnit.SECONDS)

        assertEquals(1, solverInvocationCount.get())
        assertEquals(200, resp1.code)
        assertEquals(200, resp2.code)

        executor.shutdown()
    }
}
